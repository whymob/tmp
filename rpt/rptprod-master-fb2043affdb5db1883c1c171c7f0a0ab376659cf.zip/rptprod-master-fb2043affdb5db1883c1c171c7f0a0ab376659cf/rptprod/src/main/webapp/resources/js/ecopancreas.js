/**
 * 
 */

var opts = {
		  lines: 11, // The number of lines to draw
		  length: 30, // The length of each line
		  width: 13, // The line thickness
		  radius: 25, // The radius of the inner circle
		  corners: 1, // Corner roundness (0..1)
		  rotate: 0, // The rotation offset
		  direction: 1, // 1: clockwise, -1: counterclockwise
		  color: 'grey', // #rgb or #rrggbb or array of colors
		  speed: 1.5, // Rounds per second
		  trail: 60, // Afterglow percentage
		  shadow: true, // Whether to render a shadow
		  hwaccel: true, // Whether to use hardware acceleration
		  className: 'spinner', // The CSS class to assign to the spinner
		  zIndex: 2e9, // The z-index (defaults to 2000000000)
		  top: '50%', // Top position relative to parent
		  left: '50%' // Left position relative to parent
		};

function salvarpancreasbotao()
{
	var lesoes = $("#lesoespancreas").is(":checked");
	var notaspancreas = $("#notasecopancreas").val();
	var parenchymapancreas = $("#parenchymapancreas").val();
	var calcificacao = $("#calcificacao").is(":checked");
	var pancreatite = $("#pancreatite").is(":checked");
			
	if(document.getElementById("horaExamepancreas").value.length == 0)
	{
		alertify.error('Deve escolher a hora do exame');
	}
	else
	{
		var spinner = new Spinner(opts).spin(document.getElementById('spinnergif'));
		
		var data = $("#dataExamepancreas").val();
		var hora = $("#horaExamepancreas").val();
		var formatodata = data+" "+hora;
	//	var d=  Date.parse(formatodata).toString('dd/MM/yyyy, HH:mm:ss');
		var d=  new Date(Date.parse(formatodata)).toString('dd/MM/yyyy, HH:mm:ss');
		$("#datahorapancreas").val(d);
		var datahorapancreas = $("#datahorapancreas").val();
		
		$.ajax
		({
			url: 'salvarpancreas',
			type: 'POST',
			data:  {"datahorapancreas" : datahorapancreas, "lesoes" : lesoes, "notaspancreas" : notaspancreas, "parenchymapancreas" : parenchymapancreas, "calcificacao" : calcificacao, "pancreatite" : pancreatite},
			success: function(data, textStatus, jqXHR)
			{
				$("#statusecopancreas").attr("src","resources/imagens/green-check.gif");
				alertify.success('Dados gravados com sucesso');
				spinner.stop();
			},
			error: function(jqXHR, textStatus, errorThrown) 
			{
				if(textStatus=='error'){
					alertify.error('Não foi possível completar o pedido, por favor tente novamente');
				}
				spinner.stop();
			}           
		});
	}	
}

function carregarlesaopancreas()
{	
	var tipolesao = $("#tipolesaopancreas").val();
	var localizacao = $("#localizacaopancreas").val();
	var notas = $("#notaspancreas").val();
	
	if(tipolesao == 0 || localizacao == 0)
	{
		alertify.error("Dados inválidos");
	}
	else
		{
			alertify.confirm("Confirma a introdução da lesão? ", function (a) 
			{
			    if (a) 
			    {
					var spinner = new Spinner(opts).spin(document.getElementById('spinnergif'));

					 $.ajax({
					        url: 'addlesaotabelapancreas',
					        type: 'POST',
					        cache: false,
					        data: {"tipolesao" : tipolesao, "localizacao": localizacao, "notas": notas},
				            success: function(data, textStatus, jqXHR)
				            {
				            	$("#tabelalesoespancreas").html(data);
				 				alertify.success("Inserção efectuada com sucesso");
				 				spinner.stop();

				 				$("#tipolesaopancreas").val(0);
				 				$("#localizacaopancreas").val(0);
				 				$("#notaspancreas").val("");
				            },
				            error: function(jqXHR, textStatus, errorThrown) 
				            {
				 				if(textStatus=='error')
				 				{
				 					alertify.error('Não foi possível completar o pedido, por favor tente novamente');
				 				}
				 				spinner.stop();
				            }
					    });	
			    	
			    } else {
			    	//alertify.error("Processo de inserção cancelado");
			    }
			});
		}
		
}

function cancelaredicaopancreas()
{
	$("#dadosedicaopancreas").hide();
	$("#dadosinsercaopancreas").show();
}

function mudaparaedicaopancreas(id, tipolesao, localizacaolesao, notas)
{
	$("#tipolesaopancreasedicao").val(tipolesao);
	$("#localizacaopancreasedicao").val(localizacaolesao);
		
	$("#idlesaopancreas").val(id);
	$("#notasedicaopancreas").val(notas);
	
	$("#dadosedicaopancreas").show();
	$("#dadosinsercaopancreas").hide();
}

function guardaredicaopancreas()
{
	var idlesao = $("#idlesaopancreas").val();
	var tipolesao = $("#tipolesaopancreasedicao").val();
	var localizacao = $("#localizacaopancreasedicao").val();
	var notas = $("#notasedicaopancreas").val();

	var spinner = new Spinner(opts).spin(document.getElementById('spinnergif'));
	
	 $.ajax({
		 url: 'editarlesaopancreas',
	     type: 'POST',
	     cache: false,
	     data: {"idlesao": idlesao, "tipolesao" : tipolesao, "localizacao": localizacao, "notas": notas},
         success: function(data, textStatus, jqXHR)
         {
        	$("#tabelalesoespancreas").html(data);
			alertify.success("Alteração efectuada com sucesso");
			
			$("#dadosedicaopancreas").hide();
			$("#dadosinsercaopancreas").show();
			
			spinner.stop();
         },
         error: function(jqXHR, textStatus, errorThrown) 
         {
        	 if(textStatus=='error')
        	 {
				alertify.error('Não foi possível completar o pedido, por favor tente novamente');
			}
        	 spinner.stop();
         }
	    });	
}

function editalesoespancreas()
{
	var lesoespancreas = $("#lesoespancreas").is(":checked");
	
	if(lesoespancreas == false)
		document.getElementById("dadospancreas").style.display = 'none';
	else
		document.getElementById("dadospancreas").style.display = 'block';
}

function removeleasopancreas(idlesao)
{
	alertify.confirm("Confirma a eliminação da lesão? ", function (c) 
	{
		if (c) 
		{
			var spinner = new Spinner(opts).spin(document.getElementById('spinnergif'));
			
			$.ajax({
				url: 'removerlesaopancreas',
				type: 'POST',
			    cache: false,
			    data: {"idlesao": idlesao},
			    success: function(data, textStatus, jqXHR)
			    {
			    	$("#tabelalesoespancreas").html(data);
					alertify.success("Lesao removida com sucesso");
					
					$("#dadosedicaopancreas").hide();
					$("#dadosinsercaopancreas").show();
					
					spinner.stop();
			    },
			    error: function(jqXHR, textStatus, errorThrown) 
			    {
				    if(textStatus=='error')
				    {
				    	alertify.error('Não foi possível completar o pedido, por favor tente novamente');
					}
				    spinner.stop();
			    }
			});	
		}
		else 
		{
			//alertify.error("Processo de eliminação cancelado");
		}
	});
}