$(document).ready(function() {
	
	 jQuery("#d51").add("#t51").add("#u51").click(function() 
			  {
			  jQuery("#selecaocandgeral").toggle("fast");
			  jQuery("#u51").toggle();
			  jQuery("#d51").toggle();
			  });
	 
	 jQuery("#d52").add("#t52").add("#u52").click(function() 
			  {
			  jQuery("#selecaocandimuno").toggle("fast");
			  jQuery("#u52").toggle();
			  jQuery("#d52").toggle();
			  });
	 
	 jQuery("#d53").add("#t53").add("#u53").click(function() 
			  {
			  jQuery("#selecaocandcontatos").toggle("fast");
			  jQuery("#u53").toggle();
			  jQuery("#d53").toggle();
			  });
	 
	 jQuery("#d54").add("#t54").add("#u54").click(function() 
			  {
			  jQuery("#selecaocandcdc").toggle("fast");
			  jQuery("#u54").toggle();
			  jQuery("#d54").toggle();
			  });
	 
	 jQuery("#d55").add("#t55").add("#u55").click(function() 
			  {
			  jQuery("#selecaocandcitfluxo").toggle("fast");
			  jQuery("#u55").toggle();
			  jQuery("#d55").toggle();
			  });
	 
	 
	 
});