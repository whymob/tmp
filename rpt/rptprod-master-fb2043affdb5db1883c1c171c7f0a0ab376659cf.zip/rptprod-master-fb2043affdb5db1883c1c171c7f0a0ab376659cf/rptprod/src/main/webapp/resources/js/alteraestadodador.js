var opts = {
		  lines: 11, // The number of lines to draw
		  length: 30, // The length of each line
		  width: 13, // The line thickness
		  radius: 25, // The radius of the inner circle
		  corners: 1, // Corner roundness (0..1)
		  rotate: 0, // The rotation offset
		  direction: 1, // 1: clockwise, -1: counterclockwise
		  color: 'grey', // #rgb or #rrggbb or array of colors
		  speed: 1.5, // Rounds per second
		  trail: 60, // Afterglow percentage
		  shadow: true, // Whether to render a shadow
		  hwaccel: true, // Whether to use hardware acceleration
		  className: 'spinner', // The CSS class to assign to the spinner
		  zIndex: 2e9, // The z-index (defaults to 2000000000)
		  top: '50%', // Top position relative to parent
		  left: '50%' // Left position relative to parent
		};

function alteraestado2(){
	
	var iddadorpop = $("#iddadorpop").val();
	var idestadopop = $("#idestadopop").val();
	var motivopop = $("#motivopop").val();
//	alert(iddadorpop+" ,"+idestadopop+" ,"+motivopop);
	
	var spinner = new Spinner(opts).spin(document.getElementById('spinnergif'));
	 $.ajax({
	        url: 'mudaestadodadorbtns',
	        type: 'POST',
	        data: {'iddadorpop' : iddadorpop, 'idestadopop' : idestadopop, 'motivopop':motivopop},
            success: function(data, textStatus, jqXHR)
            {
            
				//actualizar tabela de dadores
		        $.ajax({
			        url: 'atualizatabdadores',
			        type: 'POST',
			        cache: false,
		            success: function(data, textStatus, jqXHR)
		            {
		            //	$("#tabeladadores",window.parent.document).dataTable().fnDestroy();
		       
		            	$("#divdadores",window.parent.document).html(data);
		            	$("#tabeladadores",window.parent.document).dataTable(  {
		            	    initComplete: function () {
		            	        var api = this.api();

		            	        api.columns().indexes().flatten().each( function ( i ) {
		            	            var column = api.column( i );
		            	            var select = $('<select><option value=""></option></select>')
		            	                .appendTo( $(column.footer()).empty() )
		            	                .on( 'change', function () {
		            	                    var val = $.fn.dataTable.util.escapeRegex(
		            	                        $(this).val()
		            	                    );

		            	                    column
		            	                        .search( val ? '^'+val+'$' : '', true, false )
		            	                        .draw();
		            	                } );

		            	            column.data().unique().sort().each( function ( d, j ) {
		            	                select.append( '<option value="'+d+'">'+d+'</option>' )
		            	            } );
		            	        } );
		            	    },
		            			        "language": {
		            	        "sProcessing":   "A processar...",
		            	        "sLengthMenu":   "_MENU_ registos por página",
		            	        "sZeroRecords":  "Não foram encontrados resultados",
		            	        "sInfo":         "A mostrar de _START_ até _END_ de _TOTAL_ registos",
		            	        "sInfoEmpty":    "A mostrar de 0 até 0 de 0 registos",
		            	        "sInfoFiltered": "(a filtrar de _MAX_ registos no total)",
		            	        "sInfoPostFix":  "",
		            	        "sSearch":       "Pesquisar:",
		            	        "sUrl":          "",
		            	        "oPaginate": {
		            	        	"sFirst":    "Primeiro",
		            	        	"sPrevious": "Anterior",
		            	        	"sNext":     "Seguinte",
		            	        	"sLast":     "Último"
		            	        }
		            	    }
		            	} );
		
		            	if(idestadopop==3){
		                		$("#textoestado",window.parent.document).text("Validado");
		                		$("#imgdadorval",window.parent.document).show();
		                		$("#imgdadornaoval",window.parent.document).hide();
//		                		$("#btnvalidado",window.parent.document).prop('disabled', true);
//		                		$("#btnvalidado",window.parent.document).css({'background-color': 'blue', 'border': '1px solid blue'});
//		                		$("#btnvalidado",window.parent.document).removeClass("validadoativo");
		                		
		                		
		                	}else if(idestadopop==5){
		                		$("#textoestado",window.parent.document).text("Não Validado");
		                		$("#imgdadornaoval",window.parent.document).show();
		                		$("#imgdadorval",window.parent.document).hide();
		                	}
		                	alertify.success("Estado alterado com sucesso, a janela irá fechar automáticamente.");
		                	
		                	setTimeout(function() {
		                		parent.$.modal().close();
		                	}, 3000);

		 				spinner.stop();
		            },
		            error: function(jqXHR, textStatus, errorThrown) 
		            {
		 				if(textStatus=='error'){
		 				//	alert("Ocorreu um erro,por favor tente novamente");
		 					alertify.error('Não foi possível completar o pedido, por favor tente novamente');
		 				//location.href="errorpage";
		 				}
					spinner.stop();
		            }
			    });
            	
		    },
		    error: function(jqXHR, textStatus, errorThrown) 
		    {
		    	if(textStatus=='error')
		 		{
		 			alertify.error('Não foi possível completar o pedido, por favor tente novamente');
		 		}
		    	spinner.stop();
		    }
	 	});
	
}