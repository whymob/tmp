$(document).ready(function() {
    $('#tabelatransplantes').dataTable(  {
        initComplete: function () {
            var api = this.api();
 
            api.columns().indexes().flatten().each( function ( i ) {
                var column = api.column( i );
                var select = $('<select style="max-width:100px;"><option value=""></option></select>')
                    .appendTo( $(column.footer()).empty() )
                    .on( 'change', function () {
                        var val = $.fn.dataTable.util.escapeRegex(
                            $(this).val()
                        );
 
                        column
                            .search( val ? '^'+val+'$' : '', true, false )
                            .draw();
                    } );
 
                column.data().unique().sort().each( function ( d, j ) {
                    select.append( '<option value="'+d+'">'+d+'</option>' )
                } );
            } );
        },
		        "language": {
            "sProcessing":   "A processar...",
            "sLengthMenu":   "_MENU_ registos por página",
            "sZeroRecords":  "Não foram encontrados resultados",
            "sInfo":         "A mostrar de _START_ até _END_ de _TOTAL_ registos",
            "sInfoEmpty":    "A mostrar de 0 até 0 de 0 registos",
            "sInfoFiltered": "(a filtrar de _MAX_ registos no total)",
            "sInfoPostFix":  "",
            "sSearch":       "Pesquisar:",
            "sUrl":          "",
            "oPaginate": {
            	"sFirst":    "Primeiro",
            	"sPrevious": "Anterior",
            	"sNext":     "Seguinte",
            	"sLast":     "Último"
            }
        }
    
    
    });
   
 // $("#tabelaorgaos_length").css({"borderTopWidth": "0", "borderRightWidth": "0" , "borderBottomWidth": "0", "borderLeftWidth": "0"});
  
} );


function abredetalhetransplante(iddador, idanalise, idorgao){
	var spinner = new Spinner(opts).spin(document.getElementById('spinnergif'));
	 $.ajax({
	        url: 'abretransplanteequipa',
	        type: 'POST',
	        cache: false,
	        data: {"iddador" : iddador, "idanalise" :idanalise, "idorgao" :idorgao},
           success: function(data, textStatus, jqXHR)
           {
        	   $("#separadortransplantesdetalhe").html(data);
        	      
        		document.getElementById("separadortransplantesgeral").style.display = 'none';
        		document.getElementById("separadortransplantesdetalhe").style.display = 'block';
				spinner.stop();
           },
           error: function(jqXHR, textStatus, errorThrown) 
           {
				if(textStatus=='error'){
				//	alert("Ocorreu um erro,por favor tente novamente");
					alertify.error('Não foi possível completar o pedido, por favor tente novamente');
				//location.href="errorpage";
				}
			spinner.stop();
           }
	    });
	
	
}

function changeclassSelected3(element)
{
	var tab = element.id;
	

	if(tab == 'dadoroferta')
	{
		
		var spinner = new Spinner(opts).spin(document.getElementById('spinnergif'));
		
		$( "#separadordador" ).load( "carregaseparadordador", function() {
		
		document.getElementById("dadoroferta").className = "selected";
		document.getElementById("analisesoferta").className = "";
		document.getElementById("ttoferta").className = "";
		document.getElementById("equipaoferta").className = "";
		document.getElementById("fichaorgaooferta").className = "";
		document.getElementById("selecaocandidatooferta").className = "";
		document.getElementById("preoperatorio").className = "";
		document.getElementById("posoperatorio").className = "";
		
		
		document.getElementById("separadorequipa").style.display = 'none';
		document.getElementById("separadoranalises").style.display = 'none';
		document.getElementById("separadortt").style.display = 'none';
		document.getElementById("separadorfichaorgao").style.display = 'none';
		document.getElementById("separadorselecaocandidato").style.display = 'none';
		document.getElementById("separadorpreoperatorio").style.display = 'none';
		document.getElementById("separadorposoperatorio").style.display = 'none';
		document.getElementById("separadordador").style.display = 'block';
		spinner.stop();
		});
	}
	else
		if(tab == 'analisesoferta')
		{
			var spinner = new Spinner(opts).spin(document.getElementById('spinnergif'));
		
			$( "#separadoranalises" ).load( "carregaseparadoranalises", function() {
			
	
			document.getElementById("dadoroferta").className = "";
			document.getElementById("analisesoferta").className = "selected";
			document.getElementById("ttoferta").className = "";
			document.getElementById("equipaoferta").className = "";
			document.getElementById("fichaorgaooferta").className = "";
			document.getElementById("selecaocandidatooferta").className = "";
			document.getElementById("preoperatorio").className = "";
			document.getElementById("posoperatorio").className = "";
			
			document.getElementById("separadorequipa").style.display = 'none';
			document.getElementById("separadordador").style.display = 'none';
			document.getElementById("separadortt").style.display = 'none';
			document.getElementById("separadorfichaorgao").style.display = 'none';
			document.getElementById("separadorselecaocandidato").style.display = 'none';
			document.getElementById("separadorpreoperatorio").style.display = 'none';
			document.getElementById("separadorposoperatorio").style.display = 'none';
			document.getElementById("separadoranalises").style.display = 'block';
			spinner.stop();
			});
		}
	
	else
		if(tab == 'preoperatorio')
		{
				
			var spinner = new Spinner(opts).spin(document.getElementById('spinnergif'));
				
			$( "#separadorpreoperatorio" ).load( "carregaseparadorpreoperatorio", function() {
						
				
			document.getElementById("dadoroferta").className = "";
			document.getElementById("analisesoferta").className = "";
			document.getElementById("preoperatorio").className = "selected";
			document.getElementById("ttoferta").className = "";
			document.getElementById("equipaoferta").className = "";
			document.getElementById("fichaorgaooferta").className = "";
			document.getElementById("selecaocandidatooferta").className = "";
			document.getElementById("posoperatorio").className = "";				
				
			document.getElementById("separadoranalises").style.display = 'none';
			document.getElementById("separadorequipa").style.display = 'none';
			document.getElementById("separadordador").style.display = 'none';
			document.getElementById("separadorfichaorgao").style.display = 'none';
			document.getElementById("separadorselecaocandidato").style.display = 'none';
			document.getElementById("separadortt").style.display = 'none';
			document.getElementById("separadorposoperatorio").style.display = 'none';
			document.getElementById("separadorpreoperatorio").style.display = 'block';
			spinner.stop();
			});
		}	

	else
	if(tab == 'ttoferta')
	{
		
		var spinner = new Spinner(opts).spin(document.getElementById('spinnergif'));
		
		$( "#separadortt" ).load( "carregaseparadortt", function() {
				
		
		document.getElementById("dadoroferta").className = "";
		document.getElementById("analisesoferta").className = "";
		document.getElementById("ttoferta").className = "selected";
		document.getElementById("equipaoferta").className = "";
		document.getElementById("fichaorgaooferta").className = "";
		document.getElementById("selecaocandidatooferta").className = "";
		document.getElementById("preoperatorio").className = "";
		document.getElementById("posoperatorio").className = "";
		
		
		document.getElementById("separadoranalises").style.display = 'none';
		document.getElementById("separadorequipa").style.display = 'none';
		document.getElementById("separadordador").style.display = 'none';
		document.getElementById("separadorfichaorgao").style.display = 'none';
		document.getElementById("separadorselecaocandidato").style.display = 'none';
		document.getElementById("separadorpreoperatorio").style.display = 'none';
		document.getElementById("separadorposoperatorio").style.display = 'none';
		document.getElementById("separadortt").style.display = 'block';
		spinner.stop();
		});
	}
	else
		if(tab == 'fichaorgaooferta')
		{
			var spinner = new Spinner(opts).spin(document.getElementById('spinnergif'));
			$( "#separadorfichaorgao" ).load( "carregaseparadorfuncaoorgaooferta", function() {
					$( "#transplante" ).load( "carregatransplante", function() {
						
						document.getElementById("dadoroferta").className = "";
						document.getElementById("analisesoferta").className = "";
						document.getElementById("ttoferta").className = "";
						document.getElementById("equipaoferta").className = "";
						document.getElementById("selecaocandidatooferta").className = "";
						document.getElementById("fichaorgaooferta").className = "selected";
						document.getElementById("preoperatorio").className = "";
						document.getElementById("posoperatorio").className = "";
						
						document.getElementById("separadordador").style.display = 'none';
						document.getElementById("separadoranalises").style.display = 'none';
						document.getElementById("separadortt").style.display = 'none';
						document.getElementById("separadorequipa").style.display = 'none';
						document.getElementById("separadorselecaocandidato").style.display = 'none';
						document.getElementById("separadorpreoperatorio").style.display = 'none';
						document.getElementById("separadorposoperatorio").style.display = 'none';
						document.getElementById("separadorfichaorgao").style.display = 'block';
						
						spinner.stop();
					});
			});
		}
		else
			if(tab == 'selecaocandidatooferta')
			{
				var spinner = new Spinner(opts).spin(document.getElementById('spinnergif'));
				$( "#separadorselecaocandidato" ).load( "carregaseparadorselecaocandidato", function() {
					
			
				document.getElementById("dadoroferta").className = "";
				document.getElementById("analisesoferta").className = "";
				document.getElementById("ttoferta").className = "";
				document.getElementById("fichaorgaooferta").className = "";
				document.getElementById("equipaoferta").className = "";
				document.getElementById("selecaocandidatooferta").className = "selected";
				document.getElementById("preoperatorio").className = "";
				document.getElementById("posoperatorio").className = "";
				
				document.getElementById("separadordador").style.display = 'none';
				document.getElementById("separadoranalises").style.display = 'none';
				document.getElementById("separadortt").style.display = 'none';
				document.getElementById("separadorfichaorgao").style.display = 'none';
				document.getElementById("separadorequipa").style.display = 'none';
				document.getElementById("separadorpreoperatorio").style.display = 'none';
				document.getElementById("separadorposoperatorio").style.display = 'none';
				document.getElementById("separadorselecaocandidato").style.display = 'block';
				
				spinner.stop();
				});
			}
	else
	if(tab == 'equipaoferta')
	{
		var spinner = new Spinner(opts).spin(document.getElementById('spinnergif'));
		$( "#separadorequipa" ).load( "carregaseparadorequipatransplante", function() {	
	
		document.getElementById("dadoroferta").className = "";
		document.getElementById("analisesoferta").className = "";
		document.getElementById("ttoferta").className = "";
		document.getElementById("fichaorgaooferta").className = "";
		document.getElementById("selecaocandidatooferta").className = "";
		document.getElementById("posoperatorio").className = "";
		document.getElementById("equipaoferta").className = "selected";
		document.getElementById("preoperatorio").className = "";
		
		document.getElementById("separadordador").style.display = 'none';
		document.getElementById("separadoranalises").style.display = 'none';
		document.getElementById("separadortt").style.display = 'none';
		document.getElementById("separadorfichaorgao").style.display = 'none';
		document.getElementById("separadorselecaocandidato").style.display = 'none';
		document.getElementById("separadorpreoperatorio").style.display = 'none';
		document.getElementById("separadorposoperatorio").style.display = 'none';
		document.getElementById("separadorequipa").style.display = 'block';
		
		spinner.stop();
		});
	}
	else
		if(tab == 'posoperatorio')
		{
			var spinner = new Spinner(opts).spin(document.getElementById('spinnergif'));
			$( "#separadorposoperatorio" ).load( "carregaseparadorposoperatorio", function() {
				
		
			document.getElementById("dadoroferta").className = "";
			document.getElementById("analisesoferta").className = "";
			document.getElementById("ttoferta").className = "";
			document.getElementById("fichaorgaooferta").className = "";
			document.getElementById("selecaocandidatooferta").className = "";
			document.getElementById("equipaoferta").className = "";
			document.getElementById("preoperatorio").className = "";
			document.getElementById("posoperatorio").className = "selected";
			
			document.getElementById("separadordador").style.display = 'none';
			document.getElementById("separadoranalises").style.display = 'none';
			document.getElementById("separadortt").style.display = 'none';
			document.getElementById("separadorfichaorgao").style.display = 'none';
			document.getElementById("separadorselecaocandidato").style.display = 'none';
			document.getElementById("separadorpreoperatorio").style.display = 'none';
			document.getElementById("separadorequipa").style.display = 'none';
			document.getElementById("separadorposoperatorio").style.display = 'block';
			spinner.stop();
			});
		}
	
}

function abrecandidatoselecao(idrecetor, event){
	
	$("#radio_"+idrecetor).prop("checked", true);	
	
	var spinner = new Spinner(opts).spin(document.getElementById('spinnergif'));
	 $.ajax({
	        url: 'abrecandidatotransplante',
	        type: 'POST',
	        cache: false,
	        data: {"idrecetor" : idrecetor},
          success: function(data, textStatus, jqXHR)
          {
          	   	$("#harmoniosselecaocandidato").fadeOut("fast", function(){
           		   
               	$("#harmoniosselecaocandidato").html(data);
               	$("#harmoniosselecaocandidato").fadeIn("slow"); 
/*               	if(estado == 0){
               	$(event).find('td:last').html("Análise");
               	}*/
           		   
           	   }); 
       		
				spinner.stop();
          },
          error: function(jqXHR, textStatus, errorThrown) 
          {
				if(textStatus=='error'){
					alertify.error('Não foi possível completar o pedido, por favor tente novamente');
				}
			spinner.stop();
          }
	    });
	
}

function abrecandidatoselecaopancreas(idrecetor){
	
	$("#radio_"+idrecetor).prop("checked", true);

	var spinner = new Spinner(opts).spin(document.getElementById('spinnergif'));
	 $.ajax({
	        url: 'abreharmonioscandidatotransplantepancreas',
	        type: 'POST',
	        cache: false,
	        data: {"idrecetor" : idrecetor},
          success: function(data, textStatus, jqXHR)
          {
       	   $("#harmoniosselecaocandidato").slideUp("fast", function(){
       		   
           	   $("#harmoniosselecaocandidato").html(data);
           	   $("#harmoniosselecaocandidato").slideDown("slow");   
       		   
       	   });
  
				spinner.stop();
          },
          error: function(jqXHR, textStatus, errorThrown) 
          {
				if(textStatus=='error'){
					alertify.error('Não foi possível completar o pedido, por favor tente novamente');
				}
			spinner.stop();
          }
	    });
}

function aceitatransporgao(){
	
	var idorgao = $("#idorgaotransplante").val();
	var orgao = "";
	if(idorgao==1){
		orgao = "Coração";
	}else if(idorgao==2){
		orgao = "Figado";
	}else if(idorgao==3){
		orgao = "Pulmões";
	}else if(idorgao==4){
		orgao = "Pulmão esquerdo";
	}else if(idorgao==5){
		orgao = "Pulmão direito";
	}else if(idorgao==6){
		orgao = "Pâncreas";
	}else if(idorgao==7){
		orgao = "Rins";
	}else if(idorgao==8){
		orgao = "Rim esquerdo";
	}else if(idorgao==9){
		orgao = "Rim direito";
	} 
	
	alertify.confirm("Confirma a aceitação do orgão "+orgao+"?", function (e) {
	    if (e) {
				var spinner = new Spinner(opts).spin(document.getElementById('spinnergif'));
				 $.ajax({
				        url: 'aceitatransplante',
				        type: 'POST',
				        cache: false,
				        data: {"aceita": true},
			         success: function(data, textStatus, jqXHR)
			         {
			        	$("#lblestadoaceitacao").html("Orgão Aceite");
			        	$("#lblestadoaceitacao").attr("Style", "color: green; font-weight: bold;");
			        	$("#btnvalidoorg").prop("disabled" , "disabled").removeClass("btnhorasval").addClass("btndisabled");
			        	$("#btninvalidoorg").removeProp("disabled").addClass("btnhorasinvalido").removeClass("btndisabled");
			        	alertify.success("Orgão confirmado com sucesso!");
						spinner.stop();
			         },
			         error: function(jqXHR, textStatus, errorThrown) 
			         {
							if(textStatus=='error'){
							//	alert("Ocorreu um erro,por favor tente novamente");
								alertify.error('Não foi possível completar o pedido, por favor tente novamente');
							//location.href="errorpage";
							}
						spinner.stop();
			         }
				    });	
	    } else {
	    	alertify.error("Processo cancelado");
	    }
	});
}

function rejeitatransporgao(){
	
	var idorgao = $("#idorgaotransplante").val();
	var orgao = "";
	if(idorgao==1){
		orgao = "Coração";
	}else if(idorgao==2){
		orgao = "Figado";
	}else if(idorgao==3){
		orgao = "Pulmões";
	}else if(idorgao==4){
		orgao = "Pulmão esquerdo";
	}else if(idorgao==5){
		orgao = "Pulmão direito";
	}else if(idorgao==6){
		orgao = "Pâncreas";
	}else if(idorgao==7){
		orgao = "Rins";
	}else if(idorgao==8){
		orgao = "Rim esquerdo";
	}else if(idorgao==9){
		orgao = "Rim direito";
	} 
	
	alertify.confirm("Confirma a rejeição do orgão "+orgao+"?", function (e) {
	    if (e) {
				var spinner = new Spinner(opts).spin(document.getElementById('spinnergif'));
				 $.ajax({
				        url: 'aceitatransplante',
				        type: 'POST',
				        cache: false,
				        data: {"aceita": false},
			         success: function(data, textStatus, jqXHR)
			         {
				        	$("#lblestadoaceitacao").html("Orgão não aceite");
				        	$("#lblestadoaceitacao").attr("Style", "color: red; font-weight: bold;");
				        	$("#btninvalidoorg").prop("disabled" , "disabled").removeClass("btnhorasinvalido").addClass("btndisabled");
				        	$("#btnvalidoorg").removeProp("disabled").addClass("btnhorasval").removeClass("btndisabled");
			        	alertify.success("Orgão rejeitado com sucesso!");
						spinner.stop();
			         },
			         error: function(jqXHR, textStatus, errorThrown) 
			         {
							if(textStatus=='error'){
							//	alert("Ocorreu um erro,por favor tente novamente");
								alertify.error('Não foi possível completar o pedido, por favor tente novamente');
							//location.href="errorpage";
							}
						spinner.stop();
			         }
				    });	
	    } else {
	    	alertify.error("Processo cancelado");
	    }
	});
}

function edtposicaocandidato(id_candidato, posicao){
	
	
	$("#idcandidatoposicao").val(id_candidato);
	$("#poscand").val(posicao);
	$("#divregposicao").slideDown();
	
	myEventHandler();
}

function myEventHandler(e)
{
    if (!e)
      e = window.event;

    //IE9 & Other Browsers
    if (e.stopPropagation) {
      e.stopPropagation();
    }
    //IE8 and Lower
    else {
      e.cancelBubble = true;
    }
}

function cancelaedicaoposicao(){
	$("#divregposicao").slideUp();
	
}

function gravaposicao(){
		
	if($("#poscand").val()==''){
		$("#poscand").val(0);
	}
	
	var pos = $("#poscand").val();	
	var cand = 	$("#idcandidatoposicao").val();

	var spinner = new Spinner(opts).spin(document.getElementById('spinnergif'));
	 $.ajax({
	        url: 'gravaposicaocandidato',
	        type: 'POST',
	        cache: false,
	        data: {"pos": pos, "cand" : cand},
        success: function(data, textStatus, jqXHR)
        {
        	$("#pos_"+cand).html(""+pos+"<img id=\"btneditgv\" title=\"Editar\" onclick=\"edtposicaocandidato("+cand+", "+pos+"); return false;\" src=\"resources/imagens/editbutton.png\" width=\"15px\" height=\"15px\" style=\"cursor:pointer; margin-left: 5px; vertical-align: bottom;\"/>");
        	cancelaedicaoposicao();
        	alertify.success("Posição editada com sucesso!");
			spinner.stop();
        },
        error: function(jqXHR, textStatus, errorThrown) 
        {
				if(textStatus=='error'){
				//	alert("Ocorreu um erro,por favor tente novamente");
					alertify.error('Não foi possível completar o pedido, por favor tente novamente');
				//location.href="errorpage";
				}
			spinner.stop();
        }
	    });	
}

function filtratransp(){
	
	var tipo = $("#pesquisatransp").val();
	var d1 = $("#data1").val();
	var d2 = $("#data2").val();
	var dataum=  new Date(Date.parse(d1)).toString('dd/MM/yyyy');
	var datadois=  new Date(Date.parse(d2)).toString('dd/MM/yyyy');
	if((d1 == "" || d2 == "") && tipo == 2)
		alertify.error('Deve escolher as datas para filtragem');
	else
	{
		if(tipo == 1){
			$("#data1").val("");
			$("#data2").val("");
		}
		var spinner = new Spinner(opts).spin(document.getElementById('spinnergif'));
			
		$.post("filtratransplantes", {'tipo' : tipo, "dataum" : dataum, "datadois" : datadois}, function(resposta) {
			$('#tabelatransplantes').DataTable().destroy();
			$("#tabelatransplantes").replaceWith(resposta);

			spinner.stop();
		});
	}
}