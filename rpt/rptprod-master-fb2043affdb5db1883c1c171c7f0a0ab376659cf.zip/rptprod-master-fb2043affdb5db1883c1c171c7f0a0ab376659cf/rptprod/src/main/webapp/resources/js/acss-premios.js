/**
 * Script Página IPST
 */

$(document).ready(function() {
    $('#tabelapremios').dataTable(  {
        initComplete: function () {
            var api = this.api();
 
            api.columns().indexes().flatten().each( function ( i ) {
                var column = api.column( i );
                var select = $('<select style="max-width: 50px; margin:auto;"><option value=""></option></select>')
                    .appendTo( $(column.footer()).empty() )
                    .on( 'change', function () {
                        var val = $.fn.dataTable.util.escapeRegex(
                            $(this).val()
                        );
 
                        column
                            .search( val ? '^'+val+'$' : '', true, false )
                            .draw();
                    } );
 
                column.data().unique().sort().each( function ( d, j ) {
                    select.append( '<option value="'+d+'">'+d+'</option>' )
                } );
            } );
        },
		        "language": {
            "sProcessing":   "A processar...",
            "sLengthMenu":   "_MENU_ registos por página",
            "sZeroRecords":  "Não foram encontrados resultados",
            "sInfo":         "A mostrar de _START_ até _END_ de _TOTAL_ registos",
            "sInfoEmpty":    "A mostrar de 0 até 0 de 0 registos",
            "sInfoFiltered": "(a filtrar de _MAX_ registos no total)",
            "sInfoPostFix":  "",
            "sSearch":       "Pesquisar:",
            "sUrl":          "",
            "oPaginate": {
            	"sFirst":    "Primeiro",
            	"sPrevious": "Anterior",
            	"sNext":     "Seguinte",
            	"sLast":     "Último"
            }
        }
    
    
} );
   
  $("#tabelapremios_length").css({"borderTopWidth": "0", "borderRightWidth": "0" , "borderBottomWidth": "0", "borderLeftWidth": "0"});
} );

function salvacompunico()
{
	var ano =  $("#selano").val();
	var entidade = $("#entidadeinputcompunico").val();
	var localinput = $("#localinput").val();
	var orgpremio = $("#orgpremio").val();
	var valorpremio = $("#valorpremio").val();
	var compromissopremio = $("#compromissopremio").val();
	var faturapremio = $("#faturapremio").val();
	var pagamentopremio = $("#pagamentopremio").val();
	var notaspremio = $("#notaspremio").val();
	

	if(valorpremio <= 0 || entidade ==0 || orgpremio == 0 || localinput ==0)
	{
		alertify.error('Deve preencher os campos necessários');
		return;
	}
	
	if(pagamentopremio.length !=0){
	var pagamentopremio=  new Date(Date.parse($("#pagamentopremio").val())).toString('dd/MM/yyyy');
	}
	if($("#idpremio").val()==0){
	
	alertify.confirm("Confirma criar prémio?", function (e) 
	{
	    if (e) 
	    {
			var spinner = new Spinner(opts).spin(document.getElementById('spinnergif'));

			 $.ajax({
			        url: 'criarpremio',
			        type: 'POST',
			        cache: false,
			        data: {"ano": ano, "identidade" : entidade, "localinput" : localinput, "orgao": orgpremio, "valorpremio" : valorpremio ,
			        	"compromissopremio" : compromissopremio , "faturapremio"  :faturapremio , "pagamentopremio" : pagamentopremio, "notaspremio" : notaspremio
			        },
		          success: function(data, textStatus, jqXHR)
		          {
		        	  $("#separadortabpremios").html(data);
		        	  
		        	  cancelacompunico();
		          },
		          error: function(jqXHR, textStatus, errorThrown) 
		          {
						if(textStatus=='error')
							alertify.error('Não foi possível completar o pedido, por favor tente novamente');
						spinner.stop();
		          }
			 });
	    }
	});
	}else{
		
		var spinner = new Spinner(opts).spin(document.getElementById('spinnergif'));

		 $.ajax({
		        url: 'gravapremio',
		        type: 'POST',
		        cache: false,
		        data: {"id": $("#idpremio").val(), "ano": ano, "identidade" : entidade, "localinput" : localinput, "orgao": orgpremio, "valorpremio" : valorpremio ,
		        	"compromissopremio" : compromissopremio , "faturapremio"  :faturapremio , "pagamentopremio" : pagamentopremio, "notaspremio" : notaspremio
		        },
	          success: function(data, textStatus, jqXHR)
	          {
	        	  $("#separadortabpremios").html(data);
	        	  
	        	  
	        	  cancelacompunico();
	          },
	          error: function(jqXHR, textStatus, errorThrown) 
	          {
					if(textStatus=='error')
						alertify.error('Não foi possível completar o pedido, por favor tente novamente');
					spinner.stop();
	          }
		 });
		
	}
}

function cancelacompunico()
{	
		$("#entidadeinputcompunico").val(0);
		$("#idpremio").val(0);
		$("#selano").val(new Date().getFullYear());
		$("#localinput").val(0);
		$("#orgpremio").val(0);
		$("#valorpremio").val(0);
		$("#compromissopremio").val("");
		$("#faturapremio").val("");
		$("#pagamentopremio").val("");
		$("#notaspremio").val("");
	
}

function mudalocal()
{
	var spinner = new Spinner(opts).spin(document.getElementById('spinnergif'));
	
	$.ajax({
        url: 'carregalocais',
        type: 'POST',
        cache: false,
        data: {"id":$("#entidadeinputcompunico").val()},
      success: function(data, textStatus, jqXHR)
      {
    	    $("#localinput").html(data);
			spinner.stop();
      },
      error: function(jqXHR, textStatus, errorThrown) 
      {
			if(textStatus=='error'){
				alertify.error('Não foi possível completar o pedido, por favor tente novamente');
			}
		spinner.stop();
      }
    });
	
	$("#localinput").removeAttr('disabled');
}


function editarpremio(id, identidade, idlocal, orgao, pagamento, event){
	
	$("#idpremio").val(id);
	$("#selano").val($(event).closest("tr").find('td:eq(0)').text());
	$("#entidadeinputcompunico").val(identidade);
		$.ajax({
	        url: 'carregalocais',
	        type: 'POST',
	        cache: false,
	        data: {"id":$("#entidadeinputcompunico").val()},
	      success: function(data, textStatus, jqXHR)
	      {
	    	    $("#localinput").replaceWith(data);
	    	    $("#localinput").val(idlocal);
			
	      },
	      error: function(jqXHR, textStatus, errorThrown) 
	      {
				if(textStatus=='error'){
					alertify.error('Não foi possível completar o pedido, por favor tente novamente');
				}
			spinner.stop();
	      }
	    });	
	
	$("#orgpremio").val(orgao);
	$("#valorpremio").val($(event).closest("tr").find('td:eq(4)').text());
	$("#compromissopremio").val($(event).closest("tr").find('td:eq(5)').text());
	$("#faturapremio").val($(event).closest("tr").find('td:eq(6)').text());
	$("#pagamentopremio").val(pagamento);
	$("#notaspremio").val($(event).closest("tr").find('td:eq(8)').text());
	
	
}