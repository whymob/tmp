function gravarequipalocal(){
	
	var idlocal = $("#local").val();
	var sala = $("#sala").val();
	var d = $("#data").val();
	


	if(d.length !=0){
		var d=  new Date(Date.parse(d)).toString('dd/MM/yyyy');
		}
	
	var spinner = new Spinner(opts).spin(document.getElementById('spinnergif'));
		 $.ajax({
		        url: 'gravarequipalocal',
		        type: 'POST',
		        cache: false,
		        data: {"idlocal":idlocal, "sala":sala, "data":d},
	      success: function(data, textStatus, jqXHR)
	      {	    	  
	    	  alertify.success('Registo gravado com sucesso');
					spinner.stop();
	      },
	      error: function(jqXHR, textStatus, errorThrown) 
	      {
					if(textStatus=='error'){
						alertify.error('Não foi possível completar o pedido, por favor tente novamente');
					}
	   				spinner.stop();
	      }
		    });
}

function comboregeqcirurgia(){
	
	if($("#fasecirurgia").val()!=99){
/*		$("#cirurgiao").animate({width:'show'},200, function(){	
			$("#nomecirurgiao").animate({width:'show'},200, function(){	
				$("#regprincipal").animate({width:'show'},200, function(){
					$("#lblregprincipal").show();
					$("#ordemcirurgiao").animate({width:'show'},200, function(){	
						$("#nummeccirurgiao").animate({width:'show'},200, function(){	
							$("#contatocirurgiao").animate({width:'show'},200, function(){	
								$("#transportecirurgiao").animate({width:'show'},200);	
							});
						});
					});
				});	
			});
		});*/
		
		$("#transportecirurgiao").show();
		$("#contatocirurgiao").show();
		$("#nummeccirurgiao").show();
		$("#ordemcirurgiao").show();
		$("#regprincipal").show();
		$("#lblregprincipal").show();
		$("#nomecirurgiao").show();
		$("#cirurgiao").show();
	}else{
		
		
/*		$("#transportecirurgiao").animate({width:'hide'},100, function(){	
			$("#contatocirurgiao").animate({width:'hide'},100, function(){	
				$("#nummeccirurgiao").animate({width:'hide'},100, function(){	
					$("#ordemcirurgiao").animate({width:'hide'},100, function(){
						$("#lblregprincipal").hide();
						    $("#regprincipal").animate({width:'hide'},200, function(){	
								$("#nomecirurgiao").animate({width:'hide'},100, function(){	
									$("#cirurgiao").animate({width:'hide'},100);
									});
						    });
					});
				});
			});
		});*/
		
		
		$("#transportecirurgiao").hide();
		$("#contatocirurgiao").hide();
		$("#nummeccirurgiao").hide();
		$("#ordemcirurgiao").hide();
		$("#lblregprincipal").hide();
		$("#regprincipal").hide();
		$("#nomecirurgiao").hide();
		$("#cirurgiao").hide();
	}
}

function buscadetalhescirurgiao(){
	
	if($("#cirurgiao").val()!=0){
		var iduser = $("#cirurgiao").val();
		var spinner = new Spinner(opts).spin(document.getElementById('spinnergif'));
		 $.ajax({
		        url: 'carregadadoscirurgiao',
		        type: 'POST',
		        dataType:'json',
		        data: {"iduser":iduser},	
	      success: function(data, textStatus, jqXHR)
	      {	    	  
	    	 //colocar resultado nos componentes
	    	//  alert(data[0]+","+data[1]);
	    	
	    	  $("#nomecirurgiao").val(data[0]);	
	    	  $("#contatocirurgiao").val(data[1]);
	    		
					spinner.stop();
	      },
	      error: function(jqXHR, textStatus, errorThrown) 
	      {
					if(textStatus=='error'){
						alertify.error('Não foi possível completar o pedido, por favor tente novamente');
					}
					alert("erro : "+errorThrown);
	   				spinner.stop();
	      }
		    });
		
	}
	
}


function existe(textInput){
	
	
	var flag = false;
		
		$.each($("#tabelahoras tbody tr").find("td:eq(0)"), function() {
			
			
			 if ($(this).text() == textInput) {
		           flag = true;
		        } 
			         
	    });
	return flag;
		
	}

function gravaequipacirurgia(){
	
	var fase = $("#fasecirurgia").val();
	var horafase = $("#horaequipacirurg").val();
	
	var hora=  new Date(Date.parse(horafase)).toString('HH:mm');
	
	var nome = $("#fasecirurgia option:selected").text();
	
	if(existe(nome)&& fase=='99'){
		alertify.error("Já foi introduzida a hora de inicio");
	}else{
		//gravar dados fase com orgao
		var spinner = new Spinner(opts).spin(document.getElementById('spinnergif'));
		
		if($("#ordemcirurgiao").val()==''){
			$("#ordemcirurgiao").val("0");
		}
		if($("#contatocirurgiao").val()==''){
			$("#contatocirurgiao").val("0");
		}		
		
		var transporte 	= $("#transportecirurgiao").val();	
		var contato		= $("#contatocirurgiao").val();	
		var nummec		= $("#nummeccirurgiao").val();	
		var om 			= $("#ordemcirurgiao").val();	
		var nome		= $("#nomecirurgiao").val();	
		var iduser		= $("#cirurgiao").val();	
		var principal 	= $("#regprincipal").is(":checked");
		
		 $.ajax({
		        url: 'gravartabelafase',
		        type: 'POST',
		        cache: false,
		        data: {"fase":fase, "hora":hora, "iduser":iduser, "nome":nome, "om":om, "nummec":nummec, "contato": contato, "transporte": transporte, 
		        	"principal":principal},
	      success: function(data, textStatus, jqXHR)
	      {	    	
	    	  
	    	  $("#tabelahoras").html(data);
	    	  //limpar campos e encolher
	  		$("#transportecirurgiao").hide();
			$("#contatocirurgiao").hide();
			$("#nummeccirurgiao").hide();
			$("#ordemcirurgiao").hide();
			$("#lblregprincipal").hide();
			$("#regprincipal").hide();
			$("#nomecirurgiao").hide();
			$("#cirurgiao").hide();
			
			
			  $("#fasecirurgia").val(99);
		  	  $("#cirurgiao").val(0);
		  	  $("#nomecirurgiao").val("");
		  	  $("#regprincipal").val("");
		  	  $("#ordemcirurgiao").val(""); 
		  	  $("#nummeccirurgiao").val(""); 
		  	  $("#contatocirurgiao").val(""); 
		  	  $("#transportecirurgiao").val("");
		  	  $("#regprincipal").prop('checked', false);
	    	  
	    	  alertify.success('Registo gravado com sucesso');
					spinner.stop();
	      },
	      error: function(jqXHR, textStatus, errorThrown) 
	      {
					if(textStatus=='error'){
						alertify.error('Não foi possível completar o pedido, por favor tente novamente');
					}
	   				spinner.stop();
	      }
		    });	
	}
}

function delequipacirurg(idequipacirurg, e){
	

	e.stopPropagation();
	
	alertify.confirm("Confirma a eliminação  desta fase?", function (e) {
	    if (e) {
	        // user clicked "ok"
	    	
	    	var spinner = new Spinner(opts).spin(document.getElementById('spinnergif'));
	   	 $.ajax({
	   	        url: 'eliminaequipacirurgia',
	   	        type: 'POST',
	   	        cache: false,
	   	        data: {"idequipacirurg": idequipacirurg},
	       success: function(data, textStatus, jqXHR)
	       {
	       		$("#horasequiparow_"+idequipacirurg).remove();
	       		cancelaguardarequipacirurgia();
				alertify.success("Registo removido com sucesso");
	   			spinner.stop();
	       },
	       error: function(jqXHR, textStatus, errorThrown) 
	       {
	   				if(textStatus=='error'){
	   					alertify.error('Não foi possível completar o pedido, por favor tente novamente');
	   				}
	   				spinner.stop();
	       }
	   	    });
	    	
	    } else {
	    	alertify.error("Processo de eliminação cancelado");
	    }
	});	
}

function cancelaguardarequipacirurgia(){
	
	$("#registarequipacirurg").show();
	$("#editarequipacirurg").hide();	

}

function edtequipacirurg(idorgfase, hora, iduser,  idequipacirurg, principal, event){
	
	
	if(idorgfase==99){
		$("#transportecirurgiaoedt").hide();	
		$("#contatocirurgiaoedt").hide();
		$("#lbledtprincipal").hide();
		$("#edtprincipal").hide();
		$("#nummeccirurgiaoedt").hide();	
		$("#ordemcirurgiaoedt").hide();	
		$("#nomecirurgiaoedt").hide();	
		$("#cirurgiaoedt").hide();
	}else{
		$("#transportecirurgiaoedt").show();	
		$("#contatocirurgiaoedt").show();
		$("#lbledtprincipal").show();
		$("#edtprincipal").show();
		$("#nummeccirurgiaoedt").show();	
		$("#ordemcirurgiaoedt").show();	
		$("#nomecirurgiaoedt").show();	
		$("#cirurgiaoedt").show();	
	}
	
	$("#idequipacirurg").val(idequipacirurg);
	
	$("#fasecirurgiaedt").val(idorgfase);
	$("#horaequipacirurgedt").val(hora);
	$("#edtprincipal").prop('checked', principal);
	$("#edtprincipal").attr('checked', principal);

	
	$("#nomecirurgiaoedt").val($(event).closest("tr").find('td:eq(2)').text());
	$("#ordemcirurgiaoedt").val($(event).closest("tr").find('td:eq(4)').text());
	$("#nummeccirurgiaoedt").val($(event).closest("tr").find('td:eq(5)').text());
	$("#contatocirurgiaoedt").val($(event).closest("tr").find('td:eq(6)').text());
	$("#transportecirurgiaoedt").val($(event).closest("tr").find('td:eq(7)').text());
	
	if(iduser==''){
		$("#cirurgiaoedt").val(0);	
	}else{
		$("#cirurgiaoedt").val(iduser);
		
	}
	
	$("#registarequipacirurg").hide();
	$("#editarequipacirurg").show();
}

function comboedteqcirurgia(){
		
		if($("#fasecirurgiaedt").val()!=99){
			$("#cirurgiaoedt").show();	
			$("#nomecirurgiaoedt").show();
			$("#edtprincipal").show();
			$("#lbledtprincipal").show();
			$("#ordemcirurgiaoedt").show();
			$("#nummeccirurgiaoedt").show();	
			$("#contatocirurgiaoedt").show();
			$("#transportecirurgiaoedt").show();	

		}else{
			$("#transportecirurgiaoedt").hide();	
			$("#contatocirurgiaoedt").hide();
			$("#nummeccirurgiaoedt").hide();
			$("#ordemcirurgiaoedt").hide();
			$("#edtprincipal").hide();
			$("#lbledtprincipal").hide();
			$("#nomecirurgiaoedt").hide();	
			$("#cirurgiaoedt").hide();
						
			
		}	
}

function alteraequipacirurgia(){
	
	var idequipacirurg = $("#idequipacirurg").val();
	var fase = $("#fasecirurgiaedt").val();
	var horafase = $("#horaequipacirurgedt").val();
	
	var hora=  new Date(Date.parse(horafase)).toString('HH:mm');
	
		//gravar dados fase com orgao
		var spinner = new Spinner(opts).spin(document.getElementById('spinnergif'));
		
		if($("#ordemcirurgiaoedt").val()==''){
			$("#ordemcirurgiaoedt").val("0");
		}
		if($("#contatocirurgiaoedt").val()==''){
			$("#contatocirurgiaoedt").val("0");
		}		
		
		var transporte 	= $("#transportecirurgiaoedt").val();	
		var contato		= $("#contatocirurgiaoedt").val();	
		var nummec		= $("#nummeccirurgiaoedt").val();	
		var om 			= $("#ordemcirurgiaoedt").val();	
		var nome		= $("#nomecirurgiaoedt").val();	
		var iduser		= $("#cirurgiaoedt").val();	
		var principal 	= $("#edtprincipal").prop('checked');	
		 $.ajax({
		        url: 'atualizatabelafase',
		        type: 'POST',
		        cache: false,
		        data: {"idequipacirurg": idequipacirurg, "fase":fase, "hora":hora, "iduser":iduser, "nome":nome, "om":om, "nummec":nummec, "contato": contato, "transporte": transporte, 
		        	"principal": principal},
	      success: function(data, textStatus, jqXHR)
	      {	    	
	    	  
	    	  $("#tabelahoras").html(data);
	    	  cancelaguardarequipacirurgia();
	    	  alertify.success('Registo atualizado com sucesso');
					spinner.stop();
	      },
	      error: function(jqXHR, textStatus, errorThrown) 
	      {
					if(textStatus=='error'){
						alertify.error('Não foi possível completar o pedido, por favor tente novamente');
					}
	   				spinner.stop();
	      }
		    });	
}

//--------------------------Equipa Suporte Local--------------------------//

function gravaequipasuporte(){
	
	var spinner = new Spinner(opts).spin(document.getElementById('spinnergif'));
	 $.ajax({
	        url: 'regequipasuportelocal',
	        type: 'POST',
	        cache: false,
	        data: $("#formregeqsuporte").serialize(),
     success: function(data, textStatus, jqXHR)
     {	   
    	  $("#tabelasuportelocal").html(data);
    	  alertify.success('Registo gravado com sucesso');
    	  $("#nomereg").val("");
    	  $("#ordemreg").val("");
    	  $("#funcaoreg").val("");
    	  $("#contatosreg").val("");  
		  spinner.stop();
     },
     error: function(jqXHR, textStatus, errorThrown) 
     {
				if(textStatus=='error'){
					alertify.error('Não foi possível completar o pedido, verifique que todos os campos estão corretamente preenchidos e tente de novo');
				}
  				spinner.stop();
     }
	    });
}

function edtequipasuporte(ideqsuporte, event){
	$("#nomeedt").val($(event).closest("tr").find('td:eq(0)').text());
	$("#ordemedt").val($(event).closest("tr").find('td:eq(1)').text());
	$("#funcaoedt").val($(event).closest("tr").find('td:eq(2)').text());
	$("#contatosedt").val($(event).closest("tr").find('td:eq(3)').text());
	$("#ideqsuporte").val(ideqsuporte);
	
	$("#editarequipasuporte").show();
	$("#registarequipasuporte").hide();
}

function cancelareditareqsuporte(){
	$("#editarequipasuporte").hide();
	$("#registarequipasuporte").show();
}

function atualizarequipasuporte(){
	
	var spinner = new Spinner(opts).spin(document.getElementById('spinnergif'));
	 $.ajax({
	        url: 'atualizaequipasuportelocal',
	        type: 'POST',
	        cache: false,
	        data: $("#formedteqsuporte").serialize(),
    success: function(data, textStatus, jqXHR)
    {	   
   	  $("#tabelasuportelocal").html(data);
   	cancelareditareqsuporte();
  	  alertify.success('Registo atualizado com sucesso');
				spinner.stop();
    },
    error: function(jqXHR, textStatus, errorThrown) 
    {
				if(textStatus=='error'){
					alertify.error('Não foi possível completar o pedido, por favor tente novamente');
				}
 				spinner.stop();
    }
	    });
	
}


function delequipasuporte(idequipasuporte, e){
		

		e.stopPropagation();
		
		alertify.confirm("Confirma a eliminação  deste suporte local?", function (e) {
		    if (e) {
		        // user clicked "ok"
		    	
		    	var spinner = new Spinner(opts).spin(document.getElementById('spinnergif'));
		   	 $.ajax({
		   	        url: 'eliminaequipasuportelocal',
		   	        type: 'POST',
		   	        cache: false,
		   	        data: {"idequipasuporte": idequipasuporte},
		       success: function(data, textStatus, jqXHR)
		       {
		       		$("#equipasuporte_"+idequipasuporte).remove();
		       		cancelareditareqsuporte();
					alertify.success("Registo removido com sucesso");
		   			spinner.stop();
		       },
		       error: function(jqXHR, textStatus, errorThrown) 
		       {
		   				if(textStatus=='error'){
		   					alertify.error('Não foi possível completar o pedido, por favor tente novamente');
		   				}
		   				spinner.stop();
		       }
		   	    });
		    	
		    } else {
		    	alertify.error("Processo de eliminação cancelado");
		    }
		});	
	}

//----------------------------TRANSPORTE----------------------------------//

function gravatransporte(){
	
	var horaprev = $("#horaprevistareg").val();
	var horatransp = $("#horatransplreg").val();
	
	var horaprevista = new Date(Date.parse(horaprev)).toString('dd/MM/yyyy HH:mm');
	$("#horaprevistareg").val(horaprevista);
	var horatransplante = new Date(Date.parse(horatransp)).toString('dd/MM/yyyy HH:mm');
	$("#horatransplreg").val(horatransplante);
	
	//alert($("#formregtransporte").serialize());
	
	var spinner = new Spinner(opts).spin(document.getElementById('spinnergif'));
	 $.ajax({
	        url: 'regtransporte',
	        type: 'POST',
	        cache: false,
	        data: $("#formregtransporte").serialize(),
    success: function(data, textStatus, jqXHR)
    {	   
   	  $("#tabelatransporte").html(data);
  	  alertify.success('Registo gravado com sucesso');
  	  //limpar campos
	  	  $("#orgaotranspreg").val(0);
	  	  $("#transportadorreg").val("");
	  	  $("#contatotranspreg").val("");
	  	  $("#horaprevistareg").val("");
	  	  $("#destinotranspreg").val(""); 
	  	  $("#horatransplreg").val(""); 
		spinner.stop();
    },
    error: function(jqXHR, textStatus, errorThrown) 
    {
				if(textStatus=='error'){
					alertify.error('Não foi possível completar o pedido, por favor tente novamente');
				}
 				spinner.stop();
    }
	    });

}

function cancelareditartransporte(){
	$("#diveditartransporte").hide();
	$("#divregistartransporte").show();
}

function edttransporte(idtransporte, id_assignacao, event){

	$("#orgaotranspedt").val(id_assignacao);
	$("#transportadoredt").val($(event).closest("tr").find('td:eq(1)').text());
	$("#contatotranspedt").val($(event).closest("tr").find('td:eq(2)').text());
	var hp = $(event).closest("tr").find('td:eq(3)').text();
	var horaprevista = new Date(Date.parse(hp)).toString('dd/MM/yyyy HH:mm');
	$("#horaprevistaedt").val(horaprevista);
	$("#destinotranspedt").val($(event).closest("tr").find('td:eq(4)').text());
	var ht = $(event).closest("tr").find('td:eq(5)').text();
	var horatransplante = new Date(Date.parse(ht)).toString('dd/MM/yyyy HH:mm');
	$("#horatranspledt").val(horatransplante);
	$("#idtranspequipa").val(idtransporte);
	
	$("#diveditartransporte").show();
	$("#divregistartransporte").hide();
	
}

function atualizartransporte(){
	
	var horaprev = $("#horaprevistaedt").val();
	var horatransp = $("#horatranspledt").val();
	
	var horaprevista = new Date(Date.parse(horaprev)).toString('dd/MM/yyyy HH:mm');
	$("#horaprevistaedt").val(horaprevista);
	var horatransplante = new Date(Date.parse(horatransp)).toString('dd/MM/yyyy HH:mm');
	$("#horatranspledt").val(horatransplante);
	
	var spinner = new Spinner(opts).spin(document.getElementById('spinnergif'));
	 $.ajax({
	        url: 'atualizatransporte',
	        type: 'POST',
	        cache: false,
	        data: $("#formedttransporte").serialize(),
   success: function(data, textStatus, jqXHR)
   {	   
  	  $("#tabelatransporte").html(data);
 	  alertify.success('Registo atualizado com sucesso');
 	  //limpar campos
 	  cancelareditartransporte();
 	  spinner.stop();
   },
   error: function(jqXHR, textStatus, errorThrown) 
   {
				if(textStatus=='error'){
					alertify.error('Não foi possível completar o pedido, por favor tente novamente');
				}
				spinner.stop();
   }
	    });
}

function deltransporte(idtransporte, e){
	
	
	e.stopPropagation();
	
	alertify.confirm("Confirma a eliminação  deste transporte?", function (e) {
	    if (e) {
	        // user clicked "ok"
	    	
	    	var spinner = new Spinner(opts).spin(document.getElementById('spinnergif'));
	   	 $.ajax({
	   	        url: 'eliminatransporte',
	   	        type: 'POST',
	   	        cache: false,
	   	        data: {"idtransporte": idtransporte},
	       success: function(data, textStatus, jqXHR)
	       {
	       		$("#transpequipa_"+idtransporte).remove();
	       		cancelareditartransporte();
				alertify.success("Registo removido com sucesso");
	   			spinner.stop();
	       },
	       error: function(jqXHR, textStatus, errorThrown) 
	       {
	   				if(textStatus=='error'){
	   					alertify.error('Não foi possível completar o pedido, por favor tente novamente');
	   				}
	   				spinner.stop();
	       }
	   	    });
	    	
	    } else {
	    	alertify.error("Processo de eliminação cancelado");
	    }
	});	
	
	
}


