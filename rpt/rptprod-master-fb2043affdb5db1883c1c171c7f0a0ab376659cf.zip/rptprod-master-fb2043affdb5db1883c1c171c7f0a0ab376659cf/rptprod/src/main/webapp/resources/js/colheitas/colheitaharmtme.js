function registahorastme(tipo){
	
	var spinner = new Spinner(opts).spin(document.getElementById('spinnergif'));
	 $.ajax({
	        url: 'registahorastme',
	        type: 'POST',
	        cache: false,
	        data:  {"tipo" : tipo},
          success: function(data, textStatus, jqXHR)
          {
        	  var d = Date.parse(data).toString('dd/MM/yyyy HH:mm');
        	  
        	  if(tipo==1){
        		  $("#iniciotme").html(d);    
        	  }else if(tipo==2){
        		  $("#fimtme").html(d);	  
        	  }
				spinner.stop();
          },
          error: function(jqXHR, textStatus, errorThrown) 
          {

				alertify.error('Não foi possível completar o pedido, por favor tente novamente');
				spinner.stop();
          }
	    });
}

function gravaharmoniotme(){
	
		var coddador = $("#dadorcod").text();
		var codigogerado = 0;
		
		$('.codtme').each(function(){
			if($(this).closest("tr").find('td:eq(3)').find('input').is(":checked"))
			{
				$(this).val(coddador+'-'+$(this).attr('class').split(' ')[1])	
				codigogerado++;
				
			}else{
				$(this).val('');	
				
			}			
		});
	
	
	var val = $("#validade").val();
	var d = new Date(Date.parse(val)).toString('dd/MM/yyyy');
	$("#validade2").val(d);
	
	if(codigogerado>0){
		$("#tmecod").val(coddador+"-TME");
	}else{
		$("#tmecod").val("");	
	}
	var spinner = new Spinner(opts).spin(document.getElementById('spinnergif'));
	 $.ajax({
	        url: 'gravacolheitaharmoniotme',
	        type: 'POST',
	        cache: false,
	        data: $("#formtme").serialize(),
         success: function(data, textStatus, jqXHR)
         {
        	 if(codigogerado>0){
        		 $("#lblcodtme").text(coddador+"-TME");
        	 }else{
        		 $("#lblcodtme").text("");
        	 }
        	 alertify.success("Dados gravados com sucesso!");
				spinner.stop();
         },
         error: function(jqXHR, textStatus, errorThrown) 
         {
				if(textStatus=='error'){
				//	alert("Ocorreu um erro,por favor tente novamente");
					alertify.error('Não foi possível completar o pedido, por favor tente novamente');
				//location.href="errorpage";
				}
			spinner.stop();
         }
	    });	
}