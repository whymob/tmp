$(document).ready(function() {
    
    $('#tabelaexplantes').dataTable(  {
        initComplete: function () {
            var api = this.api();
 
            api.columns().indexes().flatten().each( function ( i ) {
                var column = api.column( i );
                var select = $('<select><option value=""></option></select>')
                    .appendTo( $(column.footer()).empty() )
                    .on( 'change', function () {
                        var val = $.fn.dataTable.util.escapeRegex(
                            $(this).val()
                        );
 
                        column
                            .search( val ? '^'+val+'$' : '', true, false )
                            .draw();
                    } );
 
                column.data().unique().sort().each( function ( d, j ) {
                    select.append( '<option value="'+d+'">'+d+'</option>' )
                } );
            } );
        },
		        "language": {
            "sProcessing":   "A processar...",
            "sLengthMenu":   "_MENU_ registos por página",
            "sZeroRecords":  "Não foram encontrados resultados",
            "sInfo":         "A mostrar de _START_ até _END_ de _TOTAL_ registos",
            "sInfoEmpty":    "A mostrar de 0 até 0 de 0 registos",
            "sInfoFiltered": "(a filtrar de _MAX_ registos no total)",
            "sInfoPostFix":  "",
            "sSearch":       "Pesquisar:",
            "sUrl":          "",
            "oPaginate": {
            	"sFirst":    "Primeiro",
            	"sPrevious": "Anterior",
            	"sNext":     "Seguinte",
            	"sLast":     "Último"
            }
        }
    
    
} );
   
 // $("#tabelaorgaos_length").css({"borderTopWidth": "0", "borderRightWidth": "0" , "borderBottomWidth": "0", "borderLeftWidth": "0"});
  
} );

var opts = {
		  lines: 11, // The number of lines to draw
		  length: 30, // The length of each line
		  width: 13, // The line thickness
		  radius: 25, // The radius of the inner circle
		  corners: 1, // Corner roundness (0..1)
		  rotate: 0, // The rotation offset
		  direction: 1, // 1: clockwise, -1: counterclockwise
		  color: 'grey', // #rgb or #rrggbb or array of colors
		  speed: 1.5, // Rounds per second
		  trail: 60, // Afterglow percentage
		  shadow: true, // Whether to render a shadow
		  hwaccel: true, // Whether to use hardware acceleration
		  className: 'spinner', // The CSS class to assign to the spinner
		  zIndex: 2e9, // The z-index (defaults to 2000000000)
		  top: '50%', // Top position relative to parent
		  left: '50%' // Left position relative to parent
		};


function abredadosutilizador()
{
	var spinner = new Spinner(opts).spin(document.getElementById('spinnergif'));
	$.post("editautilizadorPPTrans", {}, function(resposta) {
			$("#separadordadosutilizador").html(resposta);
			
			$("#separadortransplantes").empty().hide();
			$("#separadorexplantes").empty().hide();
	        	   
	        	   
				document.getElementById("colheitas").className = "";
				document.getElementById("transplantes").className = "";
	    		document.getElementById("separadordadosutilizador").style.display = 'block';   
			spinner.stop();
		});	
}



function abredetalheexplante(iddador, idanalise){
	
	var spinner = new Spinner(opts).spin(document.getElementById('spinnergif'));
	 $.ajax({
	        url: 'abreexplanteequipaexplante',
	        type: 'POST',
	        cache: false,
	        data: {"iddador" : iddador, "idanalise" :idanalise},
           success: function(data, textStatus, jqXHR)
           {
        	   $("#separadorexplantesdetalhe").html(data);
        	   
        	   
        		document.getElementById("separadorexplantesgeral").style.display = 'none';
        		document.getElementById("separadorexplantesdetalhe").style.display = 'block';
				spinner.stop();
           },
           error: function(jqXHR, textStatus, errorThrown) 
           {
				if(textStatus=='error'){
				//	alert("Ocorreu um erro,por favor tente novamente");
					alertify.error('Não foi possível completar o pedido, por favor tente novamente');
				//location.href="errorpage";
				}
			spinner.stop();
           }
	    });
	
	
}

function changeclassSelected(element)
{
	var tab = element.id;
	
	if(tab == 'colheitas')
	{
		document.getElementById("colheitas").className = "selected";
		document.getElementById("transplantes").className = "";
		//document.getElementById("separadorexplantesgeral").style.display = 'block';		
	//	$("#separadorexplantesdetalhe").empty().hide();
		
		//carregar e mostrar div explantes
		
		//carregar e mostrar div transplantes
		var spinner = new Spinner(opts).spin(document.getElementById('spinnergif'));
		 $.ajax({
		        url: 'abreexplantes',
		        type: 'POST',
		        cache: false,
	           success: function(data, textStatus, jqXHR)
	           {
	        	   $("#separadorexplantes").html(data).show();
					spinner.stop();
	           },
	           error: function(jqXHR, textStatus, errorThrown) 
	           {
					if(textStatus=='error'){
					//	alert("Ocorreu um erro,por favor tente novamente");
						alertify.error('Não foi possível completar o pedido, por favor tente novamente');
					//location.href="errorpage";
					}
				spinner.stop();
	           }
		    });
		$("#separadordadosutilizador").empty().hide();
		$("#separadortransplantes").empty().hide();
	}
	
	
	if(tab == 'transplantes')
	{
		document.getElementById("transplantes").className = "selected";
		document.getElementById("colheitas").className = "";
	//	document.getElementById("separadortransplantesgeral").style.display = 'block';		
	//	$("#separadortransplantesdetalhe").empty().hide();
		
		//carregar e mostrar div transplantes
		var spinner = new Spinner(opts).spin(document.getElementById('spinnergif'));
		 $.ajax({
		        url: 'abretransplantes', //está no LoginController pq antes era independente
		        type: 'POST',
		        cache: false,
	           success: function(data, textStatus, jqXHR)
	           {
	        	   	$("#separadortransplantes").html(data).show();
	       			$("#separadordadosutilizador").empty().hide();
	       			$("#separadorexplantes").empty().hide();
					spinner.stop();
	           },
	           error: function(jqXHR, textStatus, errorThrown) 
	           {
					if(textStatus=='error'){
					//	alert("Ocorreu um erro,por favor tente novamente");
						alertify.error('Não foi possível completar o pedido, por favor tente novamente');
					//location.href="errorpage";
					}
				spinner.stop();
	           }
		    });
	}
}

function changeclassSelected2(element)
{
	var tab = element.id;
	

	if(tab == 'dador')
	{
		
		var spinner = new Spinner(opts).spin(document.getElementById('spinnergif'));
		
		$( "#separadordador" ).load( "carregaseparadordador", function() {
		
		document.getElementById("dador").className = "selected";
		document.getElementById("analises").className = "";
		document.getElementById("tt").className = "";
		document.getElementById("equipa").className = "";
		document.getElementById("colheitadadorcadaver").className = "";
		document.getElementById("exames").className = "";
		document.getElementById("posop").className = "";
		
		document.getElementById("separadorposop").style.display = 'none';
		document.getElementById("separadorequipa").style.display = 'none';
		document.getElementById("separadoranalises").style.display = 'none';
		document.getElementById("separadorexames").style.display = 'none';
		document.getElementById("separadortt").style.display = 'none';
		document.getElementById("separadorcolheitadadorcadaver").style.display = 'none';
		document.getElementById("separadordador").style.display = 'block';
		spinner.stop();
		});
	}
	else
		if(tab == 'analises')
		{
			var spinner = new Spinner(opts).spin(document.getElementById('spinnergif'));
		
			$( "#separadoranalises" ).load( "carregaseparadoranalises", function() {
			
	
			document.getElementById("dador").className = "";
			document.getElementById("analises").className = "selected";
			document.getElementById("tt").className = "";
			document.getElementById("equipa").className = "";
			document.getElementById("colheitadadorcadaver").className = "";
			document.getElementById("exames").className = "";
			document.getElementById("posop").className = "";
			
			document.getElementById("separadorposop").style.display = 'none';
			document.getElementById("separadorequipa").style.display = 'none';
			document.getElementById("separadordador").style.display = 'none';
			document.getElementById("separadorexames").style.display = 'none';
			document.getElementById("separadortt").style.display = 'none';
			document.getElementById("separadorcolheitadadorcadaver").style.display = 'none';
			document.getElementById("separadoranalises").style.display = 'block';
			spinner.stop();
			});
		}

	else
	if(tab == 'tt')
	{
		
		var spinner = new Spinner(opts).spin(document.getElementById('spinnergif'));
		
		$( "#separadortt" ).load( "carregaseparadortt", function() {
				
		
		document.getElementById("dador").className = "";
		document.getElementById("analises").className = "";
	    document.getElementById("exames").className = "";
		document.getElementById("tt").className = "selected";
		document.getElementById("equipa").className = "";
		document.getElementById("colheitadadorcadaver").className = "";		
		document.getElementById("posop").className = "";
		
		document.getElementById("separadorposop").style.display = 'none';
		document.getElementById("separadoranalises").style.display = 'none';
		document.getElementById("separadorequipa").style.display = 'none';
		document.getElementById("separadordador").style.display = 'none';
		document.getElementById("separadorexames").style.display = 'none';
		document.getElementById("separadorcolheitadadorcadaver").style.display = 'none';
		document.getElementById("separadortt").style.display = 'block';
		spinner.stop();
		});
	}
	else
		if(tab == 'colheitadadorcadaver')
		{
			var spinner = new Spinner(opts).spin(document.getElementById('spinnergif'));
			$( "#separadorcolheitadadorcadaver" ).load( "carregacolheitadadorcadaver", function() {
				
		
			document.getElementById("dador").className = "";
			document.getElementById("analises").className = "";
			document.getElementById("exames").className = "";
			document.getElementById("tt").className = "";
			document.getElementById("equipa").className = "";
			document.getElementById("colheitadadorcadaver").className = "selected";
			document.getElementById("posop").className = "";
			
			document.getElementById("separadorposop").style.display = 'none';
			document.getElementById("separadoranalises").style.display = 'none';
			document.getElementById("separadorequipa").style.display = 'none';
			document.getElementById("separadordador").style.display = 'none';
			document.getElementById("separadorexames").style.display = 'none';
			document.getElementById("separadorcolheitadadorcadaver").style.display = 'block';
			document.getElementById("separadortt").style.display = 'none';
			
			spinner.stop();
			});
		}
	else
	if(tab == 'equipa')
	{
		var spinner = new Spinner(opts).spin(document.getElementById('spinnergif'));
		$( "#separadorequipa" ).load( "carregaseparadorequipaeqexplante", function() {
			
	
		document.getElementById("dador").className = "";
		document.getElementById("analises").className = "";
		document.getElementById("exames").className = "";
		document.getElementById("tt").className = "";
		document.getElementById("equipa").className = "selected";
		document.getElementById("colheitadadorcadaver").className = "";
		document.getElementById("posop").className = "";
		
		document.getElementById("separadorposop").style.display = 'none';
		document.getElementById("separadoranalises").style.display = 'none';
		document.getElementById("separadorequipa").style.display = 'block';
		document.getElementById("separadordador").style.display = 'none';
		document.getElementById("separadorexames").style.display = 'none';
		document.getElementById("separadorcolheitadadorcadaver").style.display = 'none';
		document.getElementById("separadortt").style.display = 'none';
		
		spinner.stop();
		});
	}
	else
		if(tab == 'exames')
		{
			
			var spinner = new Spinner(opts).spin(document.getElementById('spinnergif'));
			
			$( "#separadorexames" ).load( "carregaseparadorexames", function() {
				
			
				document.getElementById("dador").className = "";
				document.getElementById("analises").className = "";
				document.getElementById("exames").className = "selected";
				document.getElementById("tt").className = "";
				document.getElementById("equipa").className = "";
				document.getElementById("colheitadadorcadaver").className = "";
				document.getElementById("posop").className = "";
				
				document.getElementById("separadorposop").style.display = 'none';
				document.getElementById("separadoranalises").style.display = 'none';
				document.getElementById("separadorequipa").style.display = 'none';
				document.getElementById("separadordador").style.display = 'none';
				document.getElementById("separadorexames").style.display = 'block';
				document.getElementById("separadorcolheitadadorcadaver").style.display = 'none';
				document.getElementById("separadortt").style.display = 'none';
			spinner.stop();
			});
			
		}
		else
			if(tab == 'posop')
			{
				
				var spinner = new Spinner(opts).spin(document.getElementById('spinnergif'));
				
				$( "#separadorposop" ).load( "carregaseparadorposoperatorioexplante", function() {
					
				
					document.getElementById("dador").className = "";
					document.getElementById("analises").className = "";
					document.getElementById("exames").className = "";
					document.getElementById("posop").className = "selected";
					document.getElementById("tt").className = "";
					document.getElementById("equipa").className = "";
					document.getElementById("colheitadadorcadaver").className = "";
					
				
					document.getElementById("separadoranalises").style.display = 'none';
					document.getElementById("separadorequipa").style.display = 'none';
					document.getElementById("separadordador").style.display = 'none';
					document.getElementById("separadorexames").style.display = 'none';
					document.getElementById("separadorposop").style.display = 'block';
					document.getElementById("separadorcolheitadadorcadaver").style.display = 'none';
					document.getElementById("separadortt").style.display = 'none';
				spinner.stop();
				});
				
			}
}
