$(document).ready(function() {
	
	
	 jQuery("#d10").add("#t10").add("#u10").click(function() 
			  {
			  jQuery("#possiveldador").toggle("fast");
			  jQuery("#u10").toggle();
			  jQuery("#d10").toggle();
			  });
	 
	 jQuery("#d11").add("#t11").add("#u11").click(function() 
			  {
			  jQuery("#examefisico").toggle("fast");
			  jQuery("#u11").toggle();
			  jQuery("#d11").toggle();
			  });
	 
	 jQuery("#d12").add("#t12").add("#u12").click(function() 
			  {
			  jQuery("#geral").toggle("fast");
			  jQuery("#u12").toggle();
			  jQuery("#d12").toggle();
			  });
	 
	 jQuery("#d13").add("#t13").add("#u13").click(function() 
			  {
			  jQuery("#preexistentes").toggle("fast");
			  jQuery("#u13").toggle();
			  jQuery("#d13").toggle();
			  });
	 
	 jQuery("#d14").add("#t14").add("#u14").click(function() 
			  {
			  jQuery("#sitrisco").toggle("fast");
			  jQuery("#u14").toggle();
			  jQuery("#d14").toggle();
			  });
	
	 jQuery("#d16").add("#t16").add("#u16").click(function() 
			  {
			  jQuery("#avainicial").toggle("fast");
			  jQuery("#u16").toggle();
			  jQuery("#d16").toggle();
			  });

			  jQuery("#d17").add("#t17").click(function() 
			  {
			  	if($("#ctrlRENNDA").val()=='0'){
			  		alertify.alert('Não é possível prosseguir com a avaliação porque o possível dador foi assinalado como constando no RENNDA');
			  	}
			  	else{
			  jQuery("#orgaos").toggle("fast");
			  jQuery("#u17").toggle();
			  jQuery("#d17").toggle();
			  	}
			  });

			  jQuery("#u17").click(function() 
			  {
			  jQuery("#orgaos").toggle("fast");
			  jQuery("#d17").toggle();
			  jQuery("#u17").toggle();
			  });

			  jQuery("#d18").add("#t18").click(function() 
			  {
			  	if($("#ctrlRENNDA").val()=='0'){
			  		alertify.alert('Não é possível prosseguir com a avaliação porque o possível dador foi assinalado como constando no RENNDA');
			  	}
			  	else{
			  jQuery("#fichapessoaldador").toggle("fast");
			  jQuery("#u18").toggle();
			  jQuery("#d18").toggle();
			  	}
			  });

			  jQuery("#u18").click(function() 
			  {
			  jQuery("#fichapessoaldador").toggle("fast");
			  jQuery("#d18").toggle();
			  jQuery("#u18").toggle();
			  });
	
	
});