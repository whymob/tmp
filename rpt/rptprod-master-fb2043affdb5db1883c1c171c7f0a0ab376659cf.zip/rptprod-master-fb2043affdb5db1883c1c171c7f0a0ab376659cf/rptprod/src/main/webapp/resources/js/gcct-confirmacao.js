$('#tabelaconfirmacao').dataTable(  {
    initComplete: function () {
        var api = this.api();

        api.columns().indexes().flatten().each( function ( i ) {
            var column = api.column( i );
            var select = $('<select style="max-width: 66px; margin:auto;"><option value=""></option></select>')
                .appendTo( $(column.footer()).empty() )
                .on( 'change', function () {
                    var val = $.fn.dataTable.util.escapeRegex(
                        $(this).val()
                    );

                    column
                        .search( val ? '^'+val+'$' : '', true, false )
                        .draw();
                } );

            column.data().unique().sort().each( function ( d, j ) {
                select.append( '<option value="'+d+'">'+d+'</option>' )
            } );
        } );
    },
		        "language": {
        "sProcessing":   "A processar...",
        "sLengthMenu":   "_MENU_ registos por página",
        "sZeroRecords":  "Não foram encontrados resultados",
        "sInfo":         "A mostrar de _START_ até _END_ de _TOTAL_ registos",
        "sInfoEmpty":    "A mostrar de 0 até 0 de 0 registos",
        "sInfoFiltered": "(a filtrar de _MAX_ registos no total)",
        "sInfoPostFix":  "",
        "sSearch":       "Pesquisar:",
        "sUrl":          "",
        "oPaginate": {
        	"sFirst":    "Primeiro",
        	"sPrevious": "Anterior",
        	"sNext":     "Seguinte",
        	"sLast":     "Último"
        }
    }
} );

function filtrarincompletos()
{
	$("#incompletos").is(":checked");
	
	alert("AKI FALTA ACABAR");
}

function filtrarvalidar()
{
	if($("#apenasvalidar").is(":checked"))
	{
		var spinner = new Spinner(opts).spin(document.getElementById('spinnergif'));
		
		 $.ajax({
		        url: 'buscaapenasvalidar',
		        type: 'POST',
		        cache: false,
	           success: function(data, textStatus, jqXHR)
	           {
	           		$("#separadorconfirmacaogeral").html(data);
	           		
	           		document.getElementById("separadorconfirmacaodetalhe").style.display = 'none';
	           	
	           		spinner.stop();
	           },
	           error: function(jqXHR, textStatus, errorThrown) 
	           {
					if(textStatus=='error')
						alertify.error('Não foi possível completar o pedido, por favor tente novamente');
					spinner.stop();
	           }
		    });
	}
	else
	{
		var spinner = new Spinner(opts).spin(document.getElementById('spinnergif'));
		
		 $.ajax({
		        url: 'buscatodos',
		        type: 'POST',
		        cache: false,
	           success: function(data, textStatus, jqXHR)
	           {
	           		$("#separadorconfirmacaogeral").html(data);
	           	
	           		spinner.stop();
	           },
	           error: function(jqXHR, textStatus, errorThrown) 
	           {
					if(textStatus=='error')
						alertify.error('Não foi possível completar o pedido, por favor tente novamente');
					spinner.stop();
	           }
		    });
	}
}

function filtracolheitagcct()
{
	var ano = $("#anopesquisa").val();
	var mes = $("#mespesquisa").val();
	
	if(ano == 0 || mes == 0)
	{
		alertify.error('Selecionar ano e mês para filtragem');
		return;
	}
		
	var spinner = new Spinner(opts).spin(document.getElementById('spinnergif'));
	
	 $.ajax({
	        url: 'buscacolheitafiltrada',
	        type: 'POST',
	        cache: false,
	        data: {"ano":ano, "mes":mes},
           success: function(data, textStatus, jqXHR)
           {
           		$("#separadorconfirmacaogeral").html(data);
           		
           		document.getElementById("separadorconfirmacaodetalhe").style.display = 'none';
           	
           		spinner.stop();
           },
           error: function(jqXHR, textStatus, errorThrown) 
           {
				if(textStatus=='error')
					alertify.error('Não foi possível completar o pedido, por favor tente novamente');
				spinner.stop();
           }
	    });	
}

function validagcct(idcolheita)
{
	alertify.confirm("Confirma a validação da colheita?", function (e) 
	{
	    if (e) 
	    {
			var spinner = new Spinner(opts).spin(document.getElementById('spinnergif'));
			
			 $.ajax({
			        url: 'validacolheitagcct',
			        type: 'POST',
			        cache: false,
			        data: {"idcolheita":idcolheita},
		            success: function(data, textStatus, jqXHR)
		            {
		            	alertify.success("Validação concluída");
		            	$("#linhacolheita_"+idcolheita).replaceWith(data);
		            	
		 				spinner.stop();
		            },
		            error: function(jqXHR, textStatus, errorThrown) 
		            {
		 				if(textStatus=='error')
		 					alertify.error('Não foi possível completar o pedido, por favor tente novamente');
		 				spinner.stop();
		            }
			    });	
	    } 
	    else 
	    {
	    	$("#colheita_"+idcolheita).prop('checked', false);
	    	
	    	alertify.error("Validação cancelada");
	    }
	});
}

function abredetalheconfirmacao(idgcctcolheita)
{
	var spinner = new Spinner(opts).spin(document.getElementById('spinnergif'));
	
	 $.ajax({
	        url: 'abredetalheconfirmacao',
	        type: 'POST',
	        cache: false,
	        data: {"idgcctcolheita":idgcctcolheita},
           success: function(data, textStatus, jqXHR)
           {
        	   $("#separadorconfirmacaodetalhe").html(data);
        	   
	    		document.getElementById("separadorconfirmacaodetalhe").style.display = 'block';
	    		
				spinner.stop();
           },
           error: function(jqXHR, textStatus, errorThrown) 
           {
				if(textStatus=='error'){
					alertify.error('Não foi possível completar o pedido, por favor tente novamente');
				}
			spinner.stop();
           }
	    });
}