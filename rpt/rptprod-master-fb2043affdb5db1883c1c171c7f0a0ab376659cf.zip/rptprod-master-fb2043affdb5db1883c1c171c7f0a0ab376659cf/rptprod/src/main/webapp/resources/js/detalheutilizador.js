$(document).ready(function() {
    $('#tabeditpermissaouser').dataTable(  {
        initComplete: function () {
            var api = this.api();
 
            api.columns().indexes().flatten().each( function ( i ) {
                var column = api.column( i );
                var select = $('<select><option value=""></option></select>')
                    .appendTo( $(column.footer()).empty() )
                    .on( 'change', function () {
                        var val = $.fn.dataTable.util.escapeRegex(
                            $(this).val()
                        );
 
                        column
                            .search( val ? '^'+val+'$' : '', true, false )
                            .draw();
                    } );
 
                column.data().unique().sort().each( function ( d, j ) {
                    select.append( '<option value="'+d+'">'+d+'</option>' )
                } );
            } );
        },
		        "language": {
            "sProcessing":   "A processar...",
            "sLengthMenu":   "_MENU_ registos por página",
            "sZeroRecords":  "Não foram encontrados resultados",
            "sInfo":         "A mostrar de _START_ até _END_ de _TOTAL_ registos",
            "sInfoEmpty":    "A mostrar de 0 até 0 de 0 registos",
            "sInfoFiltered": "(a filtrar de _MAX_ registos no total)",
            "sInfoPostFix":  "",
            "sSearch":       "Pesquisar:",
            "sUrl":          "",
            "oPaginate": {
            	"sFirst":    "Primeiro",
            	"sPrevious": "Anterior",
            	"sNext":     "Seguinte",
            	"sLast":     "Último"
            }
        },"bSort" : false  
} );   
       
} );


function adicionarhospitalpermissao(){
	
	if($("#novohospitalpermissao").val()!=0 && $("#novaposicaopermissao").val()!=0 ){
		
		var iduser = $("#ID_Utilizador").val();
		var idhospital = $("#novohospitalpermissao").val();
		var posicao = $("#novaposicaopermissao").val();
		var permissao = $("#permleituraescrita").val();
		
		var spinner = new Spinner(opts).spin(document.getElementById('spinnergif'));
		 $.ajax({
		        url: 'adicionarhospitalpermissoesuser',
		        type: 'POST',
		        cache: false,
		        data: {"iduser": iduser, "idhospital": idhospital, "posicao" : posicao, "permissao" :permissao},
	        success: function(data, textStatus, jqXHR)
	        {
		      	$("#divtabelapermissao").html(data);  
		      	cancelaraddhospital();
		      	alertify.success("Posição adicionada com sucesso.");

					spinner.stop();
	        },
	        error: function(jqXHR, textStatus, errorThrown) 
	        {
					if(textStatus=='error'){
					//	alert("Ocorreu um erro,por favor tente novamente");
						alertify.error('Não foi possível completar o pedido, por favor tente novamente');
					//location.href="errorpage";
					}
					spinner.stop();
	        }
		    });
		
		
		
	}else{
		
		alertify.error('Escolha um hospital e uma permissão a adicionar');	
	}
	
	
}

function cancelaraddhospital(){	
		$("#divaddhospitaluser").slideUp(function(){
			$("#divaddhospitaluser").empty();
			$("#btnaddhospitaluser").slideDown();
       		$("#divconteudopermissões").slideDown();
   		});
}

function abriraddhospitaluser(iduser){
	
	var spinner = new Spinner(opts).spin(document.getElementById('spinnergif'));
	 $.ajax({
	        url: 'carregahospitaisdisponiveispermissao',
	        type: 'POST',
	        cache: false,
	        data: {"iduser" : iduser},
        success: function(data, textStatus, jqXHR)
        {
       		$("#divaddhospitaluser").html(data);
       		$("#btnaddhospitaluser").slideUp();
       		$("#divconteudopermissões").slideUp(function(){
           		$("#divaddhospitaluser").fadeIn();
       		});

				spinner.stop();
        },
        error: function(jqXHR, textStatus, errorThrown) 
        {
				if(textStatus=='error'){
				//	alert("Ocorreu um erro,por favor tente novamente");
					alertify.error('Não foi possível completar o pedido, por favor tente novamente');
				//location.href="errorpage";
				}
				spinner.stop();
        }
	    });
	
}

function editapermissaouser(id_hospital, nomehospital){
	
	var idutilizador = $("#ID_Utilizador").val();
	//alert(id_hospital+", "+idutilizador);
	$("#nomehospital").val(nomehospital);
	$("#idhospital").text(nomehospital);
	$("#idhospital2").val(id_hospital);
	
	var spinner = new Spinner(opts).spin(document.getElementById('spinnergif'));
	 $.ajax({
	        url: 'carregaedicaopermissaohospital',
	        type: 'POST',
	        cache: false,
	        data: {"id_hospital" : id_hospital, "idutilizador":idutilizador},
         success: function(data, textStatus, jqXHR)
         {
        		$("#diveditaposicaopermissao").html(data);
				spinner.stop();
         },
         error: function(jqXHR, textStatus, errorThrown) 
         {
				if(textStatus=='error'){
				//	alert("Ocorreu um erro,por favor tente novamente");
					alertify.error('Não foi possível completar o pedido, por favor tente novamente');
				//location.href="errorpage";
				}
				spinner.stop();
         }
	    });
	
	
}

function editapermissaoposicao(id_Posicao, event){
	
	$("#posicaopermissao tbody tr").css("background-color", "#eeece1");
	$(event).css("background-color", "#e47c80");
	
	
	$("#idposicaohospital").val(id_Posicao); //para valor de combo seguinte para gravar
	var idutilizador = $("#ID_Utilizador").val();
	var idhospital = $("#idhospital2").val();
//	alert("posicao: "+id_Posicao+" user: "+idutilizador+" hospital: "+idhospital);
	
	var spinner = new Spinner(opts).spin(document.getElementById('spinnergif'));
	 $.ajax({
	        url: 'carregapermissaoposicao',
	        type: 'POST',
	        cache: false,
	        data: {"id_hospital" : idhospital, "idutilizador":idutilizador, "id_Posicao": id_Posicao},
        success: function(data, textStatus, jqXHR)
        {
       		$("#divpermissaoposicaohospital").html(data);
        	//alertify.success(data);
				spinner.stop();
        },
        error: function(jqXHR, textStatus, errorThrown) 
        {
				if(textStatus=='error'){
				//	alert("Ocorreu um erro,por favor tente novamente");
					alertify.error('Não foi possível completar o pedido, por favor tente novamente');
				}
				spinner.stop();
        }
	    });
}


function guardarpermhospital(){
	
	var idposicao = $("#idposicaohospital").val();
	var idutilizador = $("#ID_Utilizador").val();
	var idhospital = $("#idhospital2").val();
	var permissao = $("#permissaoposicao").val();
	var le = $("#permissaoposicao option:selected").val();
	

	var spinner = new Spinner(opts).spin(document.getElementById('spinnergif'));
	
	 $.ajax({
	        url: 'guardapermissaoposicao',
	        type: 'POST',
	        cache: false,
	        data: {"idhospital" : idhospital, "idutilizador":idutilizador, "id_Posicao": idposicao, "le":le},
     success: function(data, textStatus, jqXHR)
     {
		    	 $.ajax({
		 	        url: 'actualizartabelapermissoes',
		 	        type: 'POST',
		 	        cache: false,
		 	        data: {"idutilizador":idutilizador},
		      success: function(data, textStatus, jqXHR)
		      {
		      	$("#divtabelapermissao").html(data);  
		      	alertify.success("Permisssão guardada com sucesso.");
		 				spinner.stop();
		      },
		      error: function(jqXHR, textStatus, errorThrown) 
		      {
		 				if(textStatus=='error'){
		 				//	alert("Ocorreu um erro,por favor tente novamente");
		 					alertify.error('Não foi possível completar o pedido, por favor tente novamente');
		 				}
		 				spinner.stop();
		      }
		 	    });
			
     },
     error: function(jqXHR, textStatus, errorThrown) 
     {
				if(textStatus=='error'){
				//	alert("Ocorreu um erro,por favor tente novamente");
					alertify.error('Não foi possível completar o pedido, por favor tente novamente');
				}
     }
	    });
	
}

function adicionarpermhospital(){
	
	var posicao = $("#novaposicaohospital").val();
	var idutilizador = $("#ID_Utilizador").val();
	var idhospital = $("#idhospital2").val();
	var tipopermissao = $("#novapermposicao").val();
	
	if(posicao == 0){
		alertify.error('É necessário seleccionar uma posição a adicionar!');
	}else{
		
		alertify.confirm("Confirma a adição da posição "+$("#novaposicaohospital option:selected").text(), function (e) {
		    if (e) {
		      
		    	//adiciona posição e carrega de novo div com combo e tabela posições actualizadas
		    	var spinner = new Spinner(opts).spin(document.getElementById('spinnergif'));
		    	 $.ajax({
			 	        url: 'adicionaposicaohospital',
			 	        type: 'POST',
			 	        cache: false,
			 	        data: {"idutilizador":idutilizador, "id_hospital":idhospital, "posicao":posicao, "tipopermissao":tipopermissao},
			      success: function(data, textStatus, jqXHR)
			      {
			  		$("#diveditaposicaopermissao").html(data);
			    	 $.ajax({
				 	        url: 'actualizartabelapermissoes',
				 	        type: 'POST',
				 	        cache: false,
				 	        data: {"idutilizador":idutilizador},
				      success: function(data, textStatus, jqXHR)
				      {
				      	$("#divtabelapermissao").html(data);  
				      	alertify.success("Posição adicionada com sucesso.");
				 				spinner.stop();
				      },
				      error: function(jqXHR, textStatus, errorThrown) 
				      {
				 				if(textStatus=='error'){
				 				//	alert("Ocorreu um erro,por favor tente novamente");
				 					alertify.error('Não foi possível completar o pedido, por favor tente novamente');
				 				}
				 				spinner.stop();
				      }
				 	    });

			      },
			      error: function(jqXHR, textStatus, errorThrown) 
			      {
			 				if(textStatus=='error'){
			 				//	alert("Ocorreu um erro,por favor tente novamente");
			 					alertify.error('Não foi possível completar o pedido, por favor tente novamente');
			 				}
			 				spinner.stop();
			      }
			 	    });
		    	
		    } else {
		    	alertify.error("Processo de inserção cancelado");
		    }
		});
		
		
	}
	
}

function eliminarposicaohospital(posicao, nomeposicao){
	
	var idutilizador = $("#ID_Utilizador").val();
	var idhospital = $("#idhospital2").val();
	
	alertify.confirm("Confirma a remoção da permissao ao hospital para a posição "+nomeposicao, function (e) {
	    if (e) {
	      
	    	//adiciona posição e carrega de novo div com combo e tabela posições actualizadas
	    	var spinner = new Spinner(opts).spin(document.getElementById('spinnergif'));
	    	 $.ajax({
		 	        url: 'removerposicaohospital',
		 	        type: 'POST',
		 	        cache: false,
		 	        data: {"idutilizador":idutilizador, "id_hospital":idhospital, "posicao":posicao},
		      success: function(data, textStatus, jqXHR)
		      {
		  		$("#diveditaposicaopermissao").html(data);
		    	 $.ajax({
			 	        url: 'actualizartabelapermissoes',
			 	        type: 'POST',
			 	        cache: false,
			 	        data: {"idutilizador":idutilizador},
			      success: function(data, textStatus, jqXHR)
			      {
			      	$("#divtabelapermissao").html(data);  
			      	alertify.success("Posição removida com sucesso.");
			 				spinner.stop();
			      },
			      error: function(jqXHR, textStatus, errorThrown) 
			      {
			 				if(textStatus=='error'){
			 				//	alert("Ocorreu um erro,por favor tente novamente");
			 					alertify.error('Não foi possível completar o pedido, por favor tente novamente');
			 				}
			 				spinner.stop();
			      }
			 	    });

		      },
		      error: function(jqXHR, textStatus, errorThrown) 
		      {
		 				if(textStatus=='error'){
		 				//	alert("Ocorreu um erro,por favor tente novamente");
		 					alertify.error('Não foi possível completar o pedido, por favor tente novamente');
		 				}
		      }
		 	    });
	    	
	    } else {
	    	alertify.error("Processo de remoção cancelado");
	    }
	});
	
}