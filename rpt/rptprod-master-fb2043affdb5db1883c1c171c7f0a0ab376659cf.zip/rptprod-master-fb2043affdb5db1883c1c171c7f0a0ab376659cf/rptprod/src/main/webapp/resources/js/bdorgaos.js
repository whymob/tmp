$(document).ready(function(){
//
//	if(document.getElementsByName("rimpar")[0].checked==true){
//		
//		document.getElementsByName("rimEsquerdo")[0].checked = true;
//		document.getElementsByName("rimDireito")[0].checked = true;
//		
//	}
});



function salvarorgaos()
{
	var spinner = new Spinner(opts).spin(document.getElementById('spinnergif'));

	
		 $.ajax({
		        url: 'gravarorgaos',
		        type: 'POST',
		        cache: false,
		        data: $("#orgaosdador").serialize(),
	            success: function(data, textStatus, jqXHR)
	            {
	            	$("#statusbdorgaos").attr("src","resources/imagens/green-check.gif");
	    			alertify.success('Dados gravados com sucesso');
	    			spinner.stop();
	            },
	            error: function(jqXHR, textStatus, errorThrown) 
	            {
	 				if(textStatus=='error'){
	 				//	alert("Ocorreu um erro,por favor tente novamente");
	 					alertify.error('Não foi possível completar o pedido, por favor tente novamente');
	 				//location.href="errorpage";
	 				}
				spinner.stop();
	            }
		    });
}

function alterapulmoes(p){
	
	if(p.checked==false)
	{
		document.getElementsByName("pulmaoEsq")[0].checked = false;
		document.getElementsByName("pulmaoDir")[0].checked = false;
	}else if(p.checked==true){
		document.getElementsByName("pulmaoEsq")[0].checked = true;
		document.getElementsByName("pulmaoDir")[0].checked = true;
	}
}


function verificapulmoes(){
	
	if(document.getElementsByName("pulmaoEsq")[0].checked && document.getElementsByName("pulmaoDir")[0].checked){
		document.getElementsByName("pulmoes")[0].checked = true;
	}else{
		
		document.getElementsByName("pulmoes")[0].checked = false;
	}	
}

function alterarimpar(cb){
	
	if(cb.checked==false)
	{
		document.getElementsByName("rimEsquerdo")[0].checked = false;
		document.getElementsByName("rimDireito")[0].checked = false;
	}else if(cb.checked==true){
		document.getElementsByName("rimEsquerdo")[0].checked = true;
		document.getElementsByName("rimDireito")[0].checked = true;
	}
}

function verificarins(){
	
	if(document.getElementsByName("rimEsquerdo")[0].checked && document.getElementsByName("rimDireito")[0].checked){
		document.getElementsByName("rimpar")[0].checked = true;
	}else{
		
		document.getElementsByName("rimpar")[0].checked = false;
	}
	
}