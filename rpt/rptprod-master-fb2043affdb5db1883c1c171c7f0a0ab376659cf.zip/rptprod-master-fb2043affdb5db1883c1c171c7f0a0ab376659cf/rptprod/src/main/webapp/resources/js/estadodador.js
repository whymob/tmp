/**
 * 
 */

var opts = {
		  lines: 11, // The number of lines to draw
		  length: 30, // The length of each line
		  width: 13, // The line thickness
		  radius: 25, // The radius of the inner circle
		  corners: 1, // Corner roundness (0..1)
		  rotate: 0, // The rotation offset
		  direction: 1, // 1: clockwise, -1: counterclockwise
		  color: 'grey', // #rgb or #rrggbb or array of colors
		  speed: 1.5, // Rounds per second
		  trail: 60, // Afterglow percentage
		  shadow: true, // Whether to render a shadow
		  hwaccel: true, // Whether to use hardware acceleration
		  className: 'spinner', // The CSS class to assign to the spinner
		  zIndex: 2e9, // The z-index (defaults to 2000000000)
		  top: '50%', // Top position relative to parent
		  left: '50%' // Left position relative to parent
		};

function mudaestadodador(estado)
{
	
	if($("#ctrlRENNDA").val()==0 && estado ==3){
		alertify.alert('Não é possivel validar o dador porque se encontra como constando no RENNDA no separador Base Dador, Avaliação Inicial.');
	}else if($("#ctrlRENNDA").val()==0 && estado ==5){
		alertify.error('O dador já se encontra no estado inválido para doação.');
	}else{
	
		if(($("#textoestado").text()=='Validado')&& estado ==3){
			alertify.error('Dador já se encontra validado!');
		}else if(($("#textoestado").text()=='Não Validado')&& estado ==5){
			alertify.error('Dador já se encontra invalidado!');
		}else if(($("#textoestado").text()=='Colheita')&& estado ==3){
			alertify.alert('Dador já sofreu colheita de orgãos! <br> Apenas é necessária alteração de estado no caso de o dador ser dado como inválido');
		}else {
			if(($("#textoestado").text()=='Colheita')&& estado ==5){
				alertify.alert('Dador já sofreu colheita de orgãos! Deve tomar as medidas estipuladas para esta situação.');
			}
		var iddador = $('#dador_id').val();
		 href ="validarestado?iddador="+iddador+"&estado="+estado;
		$(this).modal({width:460, height:250}).open();
		
		return false;
		}
	}
}

function abremotivo(iddador){

	var spinner = new Spinner(opts).spin(document.getElementById('spinnergif'));
    $.ajax({
        url: 'carregamotivoestado',
        type: 'POST',
        data:  {"iddador":iddador},
        cache: false,
        success: function(data, textStatus, jqXHR)
        {    	
        	alertify.alert("Motivo: "+data);
				spinner.stop();
        },
        error: function(jqXHR, textStatus, errorThrown) 
        {
				if(textStatus=='error'){
				//	alert("Ocorreu um erro,por favor tente novamente");
					alertify.error('Não foi possível completar o pedido, por favor tente novamente');
				//location.href="errorpage";
				}
		spinner.stop();
        }
    });
}