function abreassignacaohosp(idassignacaoorg, idorgao, idstatusorg, statussemaforo){
	
	$("#radio_"+idassignacaoorg).prop("checked", true);
	//abrir hospitais de atribuição para esse orgão
	
	var spinner = new Spinner(opts).spin(document.getElementById('spinnergif'));
	 $.ajax({
	        url: 'abrirhospitaisassignacao',
	        type: 'POST',
	        cache: false,
	        data: {"idassignacaoorg":idassignacaoorg, "idorgao": idorgao},
        success: function(data, textStatus, jqXHR)
        {
       	 $("#divhospassignacao").html(data);
       	 
       	 //if(idorgao=='7'||idorgao=='8'||idorgao=='9'||idstatusorg==5||statussemaforo == '1'){ //disabled para rins
       	if(idstatusorg==5||statussemaforo == '1'){
       		$('#tabelaunidadetransp input').prop('disabled', true);
       	 }
       	if(idorgao=='7'||idorgao=='8'||idorgao=='9'){
       		alertify.alert("É da responsabilidade do CST a oferta de rins!");
       	}
       	
				spinner.stop();
        },
        error: function(jqXHR, textStatus, errorThrown) 
        {
				if(textStatus=='error'){
					alertify.error('Não foi possível completar o pedido, por favor tente de novo');
				//location.href="errorpage";
				}
  				spinner.stop();
        }
	    });	
}

function alteradadoscompletos(){
	
	var combo = $("#dadoscompletostransp").val();
	var spinner = new Spinner(opts).spin(document.getElementById('spinnergif'));
	 $.ajax({
	        url: 'gravacombodadoscompletosassig',
	        type: 'POST',
	        cache: false,
	        data: {"combo":combo},
       success: function(data, textStatus, jqXHR)
       {

    	   alertify.success('Status alterado com sucesso');
    	   spinner.stop();
       },
       error: function(jqXHR, textStatus, errorThrown) 
       {
				if(textStatus=='error'){
					alertify.error('Não foi possível completar o pedido, por favor tente de novo');
				//location.href="errorpage";
				}
 				spinner.stop();
       }
	    });	
}


/*function verificaorgaosmultiplos(){
	
	var valores = [];
	$("#tabelaorgao .semaforo").each(function(index, value){
					if(($(this).find('circle').attr('fill')!="#FAFAFA")  && ($(this).attr('id')== "semaforo_3")){
						valores.push("1");
					}else if(($(this).find('circle').attr('fill')!="#FAFAFA")  && ($(this).attr('id')== "semaforo_4")){
						
						valores.push("2");
					}else if(($(this).find('circle').attr('fill')!="#FAFAFA")  && ($(this).attr('id')== "semaforo_5")){
						valores.push("3");
					}
		});
//alert(valores);
//alert($("#semaforo_3").parent().attr('onclick'));
if(valores.length >0){

	 if(jQuery.inArray("1",valores)>=0){

		if ($("#semaforo_4").length){
			$("#semaforo_4").parent().removeProp('onclick');
			$("#semaforo_4").parent().find('input').prop('disabled', true);
		//	$("#semaforo_3").parent().prop('onclick');
		//	$("#semaforo_3").parent().find('input').prop('disabled', false);
		}
		if ($("#semaforo_5").length){
			$("#semaforo_5").parent().removeProp('onclick');
			$("#semaforo_5").parent().find('input').prop('disabled', true);
		//	$("#semaforo_3").parent().prop('onclick');
		//	$("#semaforo_3").parent().find('input').prop('disabled', false);
		}
		
		
	}else if((jQuery.inArray("2",valores)>=0 && jQuery.inArray("3",valores)>=0)|| (jQuery.inArray("2",valores)>=0 && jQuery.inArray("3",valores)==-1)|| (jQuery.inArray("2",valores)==-1 && jQuery.inArray("3",valores)>=0)){

		if ($("#semaforo_3").length){
			$("#semaforo_3").parent().removeProp('onclick');
			$("#semaforo_3").parent().find('input').prop('disabled', true);
			
			if ($("#semaforo_4").length){
				$("#semaforo_4").parent().on('click', eval($("#semaforo_4").parent().attr('onclick')));
				$("#semaforo_4").parent().find('input').prop('disabled', false);
			}
			if ($("#semaforo_5").length){
				$("#semaforo_5").parent().on('click', $("#semaforo_5").parent().attr('onclick'));
				$("#semaforo_5").parent().find('input').prop('disabled', false);
			}
			
			
		}
	} 
}else{
	if ($("#semaforo_3").length){
		alert("ativar click");
		$("#semaforo_3").parent().on('click', $("#semaforo_3").parent().attr('onclick'));
		$("#semaforo_3").parent().find('input').prop('disabled', false);
	}
	if ($("#semaforo_4").length){
		$("#semaforo_4").parent().on('click', $("#semaforo_4").parent().attr('onclick'));
		$("#semaforo_4").parent().find('input').prop('disabled', false);
	}
	if ($("#semaforo_5").length){
		alert("3");
		$("#semaforo_5").parent().on('click', eval($("#semaforo_5").parent().attr('onclick')));
		$("#semaforo_5").parent().find('input').prop('disabled', false);
	}
	
}
}*/