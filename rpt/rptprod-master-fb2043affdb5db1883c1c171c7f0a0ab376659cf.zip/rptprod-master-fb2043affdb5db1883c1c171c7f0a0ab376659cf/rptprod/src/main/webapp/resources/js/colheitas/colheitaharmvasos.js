function registahorasvasos(tipo){
	
	var spinner = new Spinner(opts).spin(document.getElementById('spinnergif'));
	 $.ajax({
	        url: 'registahorasvasos',
	        type: 'POST',
	        cache: false,
	        data:  {"tipo" : tipo},
          success: function(data, textStatus, jqXHR)
          {
        	  var d = Date.parse(data).toString('dd/MM/yyyy HH:mm');
        	  
        	  if(tipo==1){
        		  $("#iniciovasos").html(d);    
        	  }else if(tipo==2){
        		  $("#fimvasos").html(d);	  
        	  }
				spinner.stop();
          },
          error: function(jqXHR, textStatus, errorThrown) 
          {

				alertify.error('Não foi possível completar o pedido, por favor tente novamente');
				spinner.stop();
          }
	    });
}

function gravaharmoniovasos(){
	
	var coddador = $("#dadorcod").text();
	
	var codigogerado = 0;
	
	$('.vasos').each(function(){
		if($(this).is(":checked"))
		{	
			codigogerado++;
		}			
	});
	
	if(codigogerado>0){
		$("#vasoscod").val(coddador+"-VAS");
	}else{
		$("#vasoscod").val("");	
	}
	
	
	var spinner = new Spinner(opts).spin(document.getElementById('spinnergif'));
	 $.ajax({
	        url: 'gravacolheitaharmoniovasos',
	        type: 'POST',
	        cache: false,
	        data: $("#formvasos").serialize(),
         success: function(data, textStatus, jqXHR)
         {
        		if(codigogerado>0){
        			$("#lblcodvasos").text(coddador+"-VAS");
        		}else{
        			$("#lblcodvasos").text("");
        		}
        	 alertify.success("Dados gravados com sucesso!");
				spinner.stop();
         },
         error: function(jqXHR, textStatus, errorThrown) 
         {
				if(textStatus=='error'){
				//	alert("Ocorreu um erro,por favor tente novamente");
					alertify.error('Não foi possível completar o pedido, por favor tente novamente');
				//location.href="errorpage";
				}
			spinner.stop();
         }
	    });	
}