$('#tabelaobjetivos').dataTable(  {
    initComplete: function () {
        var api = this.api();

        api.columns().indexes().flatten().each( function ( i ) {
            var column = api.column( i );
            var select = $('<select style="max-width: 77px; margin:auto;"><option value=""></option></select>')
                .appendTo( $(column.footer()).empty() )
                .on( 'change', function () {
                    var val = $.fn.dataTable.util.escapeRegex(
                        $(this).val()
                    );

                    column
                        .search( val ? '^'+val+'$' : '', true, false )
                        .draw();
                } );

            column.data().unique().sort().each( function ( d, j ) {
                select.append( '<option value="'+d+'">'+d+'</option>' )
            } );
        } );
    },
		        "language": {
        "sProcessing":   "A processar...",
        "sLengthMenu":   "_MENU_ registos por página",
        "sZeroRecords":  "Não foram encontrados resultados",
        "sInfo":         "A mostrar de _START_ até _END_ de _TOTAL_ registos",
        "sInfoEmpty":    "A mostrar de 0 até 0 de 0 registos",
        "sInfoFiltered": "(a filtrar de _MAX_ registos no total)",
        "sInfoPostFix":  "",
        "sSearch":       "Pesquisar:",
        "sUrl":          "",
        "oPaginate": {
        	"sFirst":    "Primeiro",
        	"sPrevious": "Anterior",
        	"sNext":     "Seguinte",
        	"sLast":     "Último"
        }
    }
} );

function filtracomobjetivos()
{
	if($("#comobjetivos").is(":checked"))
	{
		var spinner = new Spinner(opts).spin(document.getElementById('spinnergif'));
		
		 $.ajax({
		        url: 'buscacomobjetivos',
		        type: 'POST',
		        cache: false,
	           success: function(data, textStatus, jqXHR)
	           {
	           		$("#separadortabobjetivos").html(data);
	           	
	           		spinner.stop();
	           },
	           error: function(jqXHR, textStatus, errorThrown) 
	           {
					if(textStatus=='error')
						alertify.error('Não foi possível completar o pedido, por favor tente novamente');
					spinner.stop();
	           }
		    });
	}
	else
	{
		var spinner = new Spinner(opts).spin(document.getElementById('spinnergif'));
		
		 $.ajax({
		        url: 'buscatodosobjetivos',
		        type: 'POST',
		        cache: false,
	           success: function(data, textStatus, jqXHR)
	           {
	           		$("#separadortabobjetivos").html(data);
	           	
	           		spinner.stop();
	           },
	           error: function(jqXHR, textStatus, errorThrown) 
	           {
					if(textStatus=='error')
						alertify.error('Não foi possível completar o pedido, por favor tente novamente');
					spinner.stop();
	           }
		    });
	}
}

function abrecriarnovoobjetivo()
{
	document.getElementById("valoresobjetivos2").style.display = 'none';
	
	var spinner = new Spinner(opts).spin(document.getElementById('spinnergif'));
	
	$.ajax({
        url: 'buscaultimoanoobjetivos',
        type: 'POST',
        datatype: 'json',
        cache: false,
      success: function(data, textStatus, jqXHR)
      {
    	  $("#anoinput").val(data[0]);
    		
    	  document.getElementById("valoresobjetivos").style.display = 'block';
    	  
    	  spinner.stop();
      },
      error: function(jqXHR, textStatus, errorThrown) 
      {
			if(textStatus=='error'){
				alertify.error('Não foi possível completar o pedido, por favor tente novamente');
			}
		spinner.stop();
      }
    });
}

function copiaranoanterior()
{
	alertify.confirm("Confirma criar valores para o ano seguinte?", function (e) 
			{
			    if (e) 
			    {
			    	var spinner = new Spinner(opts).spin(document.getElementById('spinnergif'));
			    	
			    	$.ajax({
				        url: 'criarvaloresnovoanoobjetivos',
				        type: 'POST',
				        cache: false,
				        success: function(data, textStatus, jqXHR)
				        {
			        	  if(data === "true")
			        	  {
			        		  alertify.success("Novos valores criados");
			        		  
			        		  $.ajax({
			      		        url: 'carregaseparadorobjetivos2',
			      		        type: 'POST',
			      		        cache: false,
			      	           success: function(data, textStatus, jqXHR)
			      	           {
			      	        	 $("#separadortabobjetivos").html(data);
			      	        	   
			      	        	   spinner.stop();
			      	           },
			      	           error: function(jqXHR, textStatus, errorThrown) 
			      	           {
			      					if(textStatus=='error'){
			      						alertify.error('Não foi possível completar o pedido, por favor tente novamente');
			      					}
			      				spinner.stop();
			      	           }
			      		    });
			        	  }
			        	  else
			        	  {
			        		  alertify.error("Valores para o ano seguinte já criados");
				        	  	
			        		  spinner.stop();
			        	  }
			        	  	
				        },
				        error: function(jqXHR, textStatus, errorThrown) 
				        {
							if(textStatus=='error'){
								alertify.error('Não foi possível completar o pedido, por favor tente novamente');
							}
							spinner.stop();
				        }
				    });
			    }
			});
}

function guardaobjetivo(tipo)
{
	if(tipo == 1)
	{
		if($("#objetivoinput").val().length == 0){
			$("#objetivoinput").val(0);
		}
		if($("#objetivorefinput").val().length == 0){
			$("#objetivorefinput").val(0);
		}
			
			var spinner = new Spinner(opts).spin(document.getElementById('spinnergif'));
			
			$.ajax({
		        url: 'crianovoobjetivo',
		        type: 'POST',
		        cache: false,
		        data: {"ano":$("#anoinput").val(), "entidade":$("#entidadeinput").val(), "local":$("#localinput").val(), "orgao":$("#orgaoinput").val(), "objetivo":$("#objetivoinput").val(), "objetivoref":$("#objetivorefinput").val()},
		      success: function(data, textStatus, jqXHR)
		      {
		    	  	$("#idobjetivo").val("");
		    		$("#anoinput").val(2015);
		    		$("#objetivoinput").val("");
		    		$("#objetivorefinput").val("");
		    		$("#localinput").val(0);
		    		$("#entidadeinput").val(0);
		    		$("#orgaoinput").val(0);
		    		
		    		document.getElementById("valoresobjetivos").style.display = 'none';
		    		
		    	    $("#separadortabobjetivos").html(data);
	
					spinner.stop();
		      },
		      error: function(jqXHR, textStatus, errorThrown) 
		      {
					if(textStatus=='error'){
						alertify.error('Não foi possível completar o pedido, por favor tente novamente');
					}
				spinner.stop();
		      }
		    });
		
	}
	else
	{
		if($("#objetivoinput2").val().length == 0 || $("#realizadoinput2").val().length == 0)
			alertify.error('Deve preencher o objetivo/realizado');
		else
		{
			var spinner = new Spinner(opts).spin(document.getElementById('spinnergif'));
			
			$.ajax({
		        url: 'gravaobjetivo',
		        type: 'POST',
		        cache: false,
		        data: {"ano":$("#anoinput2").val(), "entidade":$("#entidadeinput2").val(), "local":$("#localinput2").val(), "orgao":$("#orgaoinput2").val(), 
		        	"objetivo":$("#objetivoinput2").val(), "realizado":$("#realizadoinput2").val(), "id":$("#idobjetivo2").val(), "objetivoref":$("#objetivorefinput2").val()},
		      success: function(data, textStatus, jqXHR)
		      {
		    	  	$("#idobjetivo2").val("");
		    		$("#anoinput2").val(2015);
		    		$("#objetivoinput2").val("");
		    		$("#objetivorefinput2").val("");
		    		$("#localinput2").val(0);
		    		$("#entidadeinput2").val(0);
		    		$("#orgaoinput2").val(0);
		    		$("#realizadoinput2").val("");
		    		
		    		document.getElementById("valoresobjetivos2").style.display = 'none';
		    		
		    	    $("#separadortabobjetivos").html(data);
	
					spinner.stop();
		      },
		      error: function(jqXHR, textStatus, errorThrown) 
		      {
					if(textStatus=='error'){
						alertify.error('Não foi possível completar o pedido, por favor tente novamente');
					}
				spinner.stop();
		      }
		    });
		}
	}
}

function cancelanovoobjetivo()
{
	$("#idobjetivo").val("");
	$("#anoinput").val(2015);
	$("#objetivoinput").val("");
	$("#localinput").val(0);
	$("#entidadeinput").val(0);
	$("#orgaoinput").val(0);
	
	$("#localinput").attr('disabled', true);
	
	document.getElementById("valoresobjetivos").style.display = 'none';
}

function mudalocal()
{
	var spinner = new Spinner(opts).spin(document.getElementById('spinnergif'));
	
	$.ajax({
        url: 'carregalocais',
        type: 'POST',
        cache: false,
        data: {"id":$("#entidadeinput").val()},
      success: function(data, textStatus, jqXHR)
      {
    	    $("#localinput").html(data);
			spinner.stop();
      },
      error: function(jqXHR, textStatus, errorThrown) 
      {
			if(textStatus=='error'){
				alertify.error('Não foi possível completar o pedido, por favor tente novamente');
			}
		spinner.stop();
      }
    });
	
	$("#localinput").removeAttr('disabled');
}

function cancelaobjetivo()
{
	$("#idobjetivo2").val("");
	$("#anoinput2").val(2015);
	$("#objetivoinput2").val("");
	$("#localinput2").val(0);
	$("#entidadeinput2").val(0);
	$("#orgaoinput2").val(0);
	$("#realizadoinput2").val("");
	$("#objetivorefinput2").val("");

	document.getElementById("valoresobjetivos2").style.display = 'none';
}

function abredetalheobjetivo(id, objetivo, ano, entidade, orgao, hosp, realizado, objref)
{
	$("#idobjetivo2").val(id);
	$("#objetivoinput2").val(objetivo);
	$("#objetivorefinput2").val(objref);
	$("#anoinput2").val(ano);
	$("#entidadeinput2").val(entidade);
	$("#orgaoinput2").val(orgao);
	$("#realizadoinput2").val(realizado);
	
	var spinner = new Spinner(opts).spin(document.getElementById('spinnergif'));
	
	$.ajax({
        url: 'carregalocais',
        type: 'POST',
        cache: false,
        data: {"id":entidade},
      success: function(data, textStatus, jqXHR)
      {
    	    $("#localinput2").html(data);
    	    $("#localinput2").val(hosp);
    	    
			spinner.stop();
      },
      error: function(jqXHR, textStatus, errorThrown) 
      {
			if(textStatus=='error'){
				alertify.error('Não foi possível completar o pedido, por favor tente novamente');
			}
		spinner.stop();
      }
    });
	
	document.getElementById("valoresobjetivos2").style.display = 'block';
	document.getElementById("valoresobjetivos").style.display = 'none';
}

function pagaobjetivoipst(id)
{
	alertify.confirm("Confirma o pagamneto do objetivo?", function (e) 
	{
		if (e) 
		{
			var spinner = new Spinner(opts).spin(document.getElementById('spinnergif'));
			
			$.ajax({
		        url: 'pagaobjetivoipst',
		        type: 'POST',
		        cache: false,
		        data: {"id":id},
		      success: function(data, textStatus, jqXHR)
		      {
		    	    $("#linhaobjetivo_"+id).replaceWith(data);
					spinner.stop();
		      },
		      error: function(jqXHR, textStatus, errorThrown) 
		      {
					if(textStatus=='error'){
						alertify.error('Não foi possível completar o pedido, por favor tente novamente');
					}
				spinner.stop();
		      }
		    });
		}
		else 
	    {
	    	$("#check_"+id).prop('checked', false);
	    	
	    	alertify.error("Validação cancelada");
	    }
	});
}