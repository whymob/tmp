function registahorascorneas(tipo){
	
	var spinner = new Spinner(opts).spin(document.getElementById('spinnergif'));
	 $.ajax({
	        url: 'registahorascorneas',
	        type: 'POST',
	        cache: false,
	        data:  {"tipo" : tipo},
          success: function(data, textStatus, jqXHR)
          {
        	  var d = Date.parse(data).toString('dd/MM/yyyy HH:mm');
        	  
        	  if(tipo==1){
        		  $("#iniciocorneas").html(d);    
        	  }else if(tipo==2){
        		  $("#fimcorneas").html(d);	  
        	  }
				spinner.stop();
          },
          error: function(jqXHR, textStatus, errorThrown) 
          {

				alertify.error('Não foi possível completar o pedido, por favor tente novamente');
				spinner.stop();
          }
	    });
}

function gravaharmoniocorneas(){
	
	var coddador = $("#dadorcod").text();
	
	var codigogerado = 0;
	
	$('.codcorneas').each(function(){
		if($(this).closest("tr").find('td:eq(1)').find('input').is(":checked"))
		{
			$(this).val(coddador+'-'+$(this).attr('class').split(' ')[1])	
			codigogerado++;
			
		}else{
			$(this).val('');	
			
		}			
	});
	
	if(codigogerado>0){
		$("#estadocorneas").val(1);
	}else{
		$("#estadocorneas").val(0);	
	}
	
	var estadocorneas = $("#estadocorneas").val();
	
	if(estadocorneas!=0){
		$("#corneascod").val(coddador+"-COR");
		$("#lblcodcorneas").text(coddador+"-COR");
		}
	else{
		$("#corneascod").val("");
		$("#lblcodcorneas").text("");
	}
	
	var spinner = new Spinner(opts).spin(document.getElementById('spinnergif'));
	 $.ajax({
	        url: 'gravacolheitaharmoniocorneas',
	        type: 'POST',
	        cache: false,
	        data: $("#formcorneas").serialize(),
         success: function(data, textStatus, jqXHR)
         {

        	 alertify.success("Dados gravados com sucesso!");
				spinner.stop();
         },
         error: function(jqXHR, textStatus, errorThrown) 
         {
				if(textStatus=='error'){
				//	alert("Ocorreu um erro,por favor tente novamente");
					alertify.error('Não foi possível completar o pedido, por favor tente novamente');
				//location.href="errorpage";
				}
			spinner.stop();
         }
	    });	
}