/**
 * Script Página IPST
 */

$(document).ready(function() {
    $('#tabelaatos').dataTable(  {
        initComplete: function () {
            var api = this.api();
 
            api.columns().indexes().flatten().each( function ( i ) {
                var column = api.column( i );
                var select = $('<select style="max-width: 66px; margin:auto;"><option value=""></option></select>')
                    .appendTo( $(column.footer()).empty() )
                    .on( 'change', function () {
                        var val = $.fn.dataTable.util.escapeRegex(
                            $(this).val()
                        );
 
                        column
                            .search( val ? '^'+val+'$' : '', true, false )
                            .draw();
                    } );
 
                column.data().unique().sort().each( function ( d, j ) {
                    select.append( '<option value="'+d+'">'+d+'</option>' )
                } );
            } );
        },
		        "language": {
            "sProcessing":   "A processar...",
            "sLengthMenu":   "_MENU_ registos por página",
            "sZeroRecords":  "Não foram encontrados resultados",
            "sInfo":         "A mostrar de _START_ até _END_ de _TOTAL_ registos",
            "sInfoEmpty":    "A mostrar de 0 até 0 de 0 registos",
            "sInfoFiltered": "(a filtrar de _MAX_ registos no total)",
            "sInfoPostFix":  "",
            "sSearch":       "Pesquisar:",
            "sUrl":          "",
            "oPaginate": {
            	"sFirst":    "Primeiro",
            	"sPrevious": "Anterior",
            	"sNext":     "Seguinte",
            	"sLast":     "Último"
            }
        }
    
    
} );
   
  $("#tabelaatos_length").css({"borderTopWidth": "0", "borderRightWidth": "0" , "borderBottomWidth": "0", "borderLeftWidth": "0"});
} );

var opts = {
		  lines: 11, // The number of lines to draw
		  length: 30, // The length of each line
		  width: 13, // The line thickness
		  radius: 25, // The radius of the inner circle
		  corners: 1, // Corner roundness (0..1)
		  rotate: 0, // The rotation offset
		  direction: 1, // 1: clockwise, -1: counterclockwise
		  color: 'grey', // #rgb or #rrggbb or array of colors
		  speed: 1.5, // Rounds per second
		  trail: 60, // Afterglow percentage
		  shadow: true, // Whether to render a shadow
		  hwaccel: true, // Whether to use hardware acceleration
		  className: 'spinner', // The CSS class to assign to the spinner
		  zIndex: 2e9, // The z-index (defaults to 2000000000)
		  top: '50%', // Top position relative to parent
		  left: '50%' // Left position relative to parent
		};

function start()
{
	document.getElementById("atos").className = "selected";
	document.getElementById("compromissos").className = "";
	document.getElementById("faturas").className = "";
	document.getElementById("premios").className = "";
}

function filtracolheitaacss()
{
	var ano = $("#anopesquisaacss").val();
	var mes = $("#mespesquisaacss").val();
	
	if(ano == 0 || mes == 0)
	{
		alertify.error('Selecionar ano e mês para filtragem');
		return;
	}
		
	var spinner = new Spinner(opts).spin(document.getElementById('spinnergif'));
	
	 $.ajax({
	        url: 'buscacolheitafiltradaacss',
	        type: 'POST',
	        cache: false,
	        data: {"ano":ano, "mes":mes},
           success: function(data, textStatus, jqXHR)
           {
           		$("#separadortabelaatos").html(data);
           	
           		spinner.stop();
           },
           error: function(jqXHR, textStatus, errorThrown) 
           {
				if(textStatus=='error')
					alertify.error('Não foi possível completar o pedido, por favor tente novamente');
				spinner.stop();
           }
	    });	
}

function abredetalheacss(id)
{
	var spinner = new Spinner(opts).spin(document.getElementById('spinnergif'));
	
	 $.ajax({
	        url: 'carregaseparadordetalheato',
	        type: 'POST',
	        cache: false,
	        data: {"id":id},
	          success: function(data, textStatus, jqXHR)
	          {
	        	  $("#separadortabelaatosdetalhe").html(data);
	       	   
	        	  document.getElementById("separadortabelaatosdetalhe").style.display = 'block';
	       	
	        	  spinner.stop();
	          },
	          error: function(jqXHR, textStatus, errorThrown) 
	          {
	        	  if(textStatus=='error'){
	        		  alertify.error('Não foi possível completar o pedido, por favor tente novamente');
	        	  }
	        	  spinner.stop();
	          }
	    });
}

function changeclassSelected(element)
{
	var tab = element.id;
	
	if(tab == 'atos')
	{
		document.getElementById("atos").className = "selected";
		document.getElementById("compromissos").className = "";
		document.getElementById("faturas").className = "";
		document.getElementById("premios").className = "";
		
		document.getElementById("separadoratos").style.display = 'block';
		document.getElementById("separadorcompromissos").style.display = 'none';
		document.getElementById("separadorfaturas").style.display = 'none';
		document.getElementById("separadorpremios").style.display = 'none';
	}
	else
	if(tab == 'compromissos')
	{
		var spinner = new Spinner(opts).spin(document.getElementById('spinnergif'));
		$.ajax({
		        url: 'carregaseparadorcompromissos',
		        type: 'POST',
		        cache: false,
	           success: function(data, textStatus, jqXHR)
	           {
	        	    $("#separadorcompromissos").html(data);
	        	   
	        	    spinner.stop();
	        	   
	        	    document.getElementById("atos").className = "";
	        		document.getElementById("compromissos").className = "selected";
	        		document.getElementById("faturas").className = "";
	        		document.getElementById("premios").className = "";
	        		
	        		document.getElementById("separadoratos").style.display = 'none';
	        		document.getElementById("separadorfaturas").style.display = 'none';
	        		document.getElementById("separadorpremios").style.display = 'none';
	        		document.getElementById("separadorcompromissos").style.display = 'block';
	           },
	           error: function(jqXHR, textStatus, errorThrown) 
	           {
					if(textStatus=='error')
						alertify.error('Não foi possível completar o pedido, por favor tente novamente');
				
					spinner.stop();
	           }
		});
	}
	else
	if(tab == 'faturas')
	{
		var spinner = new Spinner(opts).spin(document.getElementById('spinnergif'));
		$.ajax({
		        url: 'carregaseparadorfaturas',
		        type: 'POST',
		        cache: false,
	           success: function(data, textStatus, jqXHR)
	           {
	        	    $("#separadorfaturas").html(data);
	        	   
	        	    spinner.stop();
	        	   
	        	    document.getElementById("atos").className = "";
	        		document.getElementById("compromissos").className = "";
	        		document.getElementById("faturas").className = "selected";
	        		document.getElementById("premios").className = "";
	        		
	        		document.getElementById("separadoratos").style.display = 'none';
	        		document.getElementById("separadorpremios").style.display = 'none';
	        		document.getElementById("separadorcompromissos").style.display = 'none';
	        		document.getElementById("separadorfaturas").style.display = 'block';
	           },
	           error: function(jqXHR, textStatus, errorThrown) 
	           {
					if(textStatus=='error')
						alertify.error('Não foi possível completar o pedido, por favor tente novamente');
				
					spinner.stop();
	           }
		});
	}
	else
	if(tab == 'premios')
	{
		var spinner = new Spinner(opts).spin(document.getElementById('spinnergif'));
		$.ajax({
		        url: 'carregaseparadorpremios',
		        type: 'POST',
		        cache: false,
	           success: function(data, textStatus, jqXHR)
	           {
	        	    $("#separadorpremios").html(data);
	        	   
	        	    spinner.stop();
	        	   
	        	    document.getElementById("atos").className = "";
	        		document.getElementById("compromissos").className = "";
	        		document.getElementById("faturas").className = "";
	        		document.getElementById("premios").className = "selected";
	        		
	        		document.getElementById("separadoratos").style.display = 'none';
	        		document.getElementById("separadorcompromissos").style.display = 'none';
	        		document.getElementById("separadorfaturas").style.display = 'none';
	        		document.getElementById("separadorpremios").style.display = 'block';
	           },
	           error: function(jqXHR, textStatus, errorThrown) 
	           {
					if(textStatus=='error')
						alertify.error('Não foi possível completar o pedido, por favor tente novamente');
				
					spinner.stop();
	           }
		});
	}
}