function registahorascoracao(tipo){
	
	var spinner = new Spinner(opts).spin(document.getElementById('spinnergif'));
	 $.ajax({
	        url: 'registahorascoracao',
	        type: 'POST',
	        cache: false,
	        data:  {"tipo" : tipo},
          success: function(data, textStatus, jqXHR)
          {
        	  var d = Date.parse(data).toString('dd/MM/yyyy HH:mm');
        	  
        	  if(tipo==1){
        		  $("#iniciocoracao").html(d);    
        	  }else if(tipo==2){
        		  $("#fimcoracao").html(d);	  
        	  }
				spinner.stop();
          },
          error: function(jqXHR, textStatus, errorThrown) 
          {

				alertify.error('Não foi possível completar o pedido, por favor tente novamente');
				spinner.stop();
          }
	    });
}

function gravaharmoniocoracao(){
	
	var coddador = $("#dadorcod").text();
	var estadocoracao = $("#estadocoracao").val();
	
	$("#coracaocod").val("");
	$("#lblcodcoracao").text("");
	
	if(estadocoracao!=2 && estadocoracao!=0){
	$("#coracaocod").val(coddador+"-CO");
	$("#lblcodcoracao").text(coddador+"-CO");
	}
	
	var spinner = new Spinner(opts).spin(document.getElementById('spinnergif'));
	 $.ajax({
	        url: 'gravacolheitaharmoniocoracao',
	        type: 'POST',
	        cache: false,
	        data: $("#formcoracao").serialize(),
         success: function(data, textStatus, jqXHR)
         {

        	 alertify.success("Dados gravados com sucesso!");
				spinner.stop();
         },
         error: function(jqXHR, textStatus, errorThrown) 
         {
				if(textStatus=='error'){
				//	alert("Ocorreu um erro,por favor tente novamente");
					alertify.error('Não foi possível completar o pedido, por favor tente novamente');
				//location.href="errorpage";
				}
			spinner.stop();
         }
	    });	
}

function coracaoalteraestado(estado){
	
	if(estado==1){
		var frase = "validado";
	}else if(estado==3){
		var frase = "não validado";
	}
		
		alertify.confirm("Confirma a alteração do estado do orgão para "+frase+"?", function (e) {
		    if (e) {
					var spinner = new Spinner(opts).spin(document.getElementById('spinnergif'));
					 $.ajax({
					        url: 'gravacolheitaestadocoracao',
					        type: 'POST',
					        cache: false,
					        data: {"estado": estado},
				         success: function(data, textStatus, jqXHR)
				         {
				        	 if(data=='OK'){
						        	 if(estado==1){
							        		 $("#divestadocoracao").html("<label style=\"color: green;\"><b>Orgão válido </b></label><img alt=\"Orgão validado\" src=\"resources/imagens/green-check.gif\" style=\"width: 20px; height: 20px; vertical-align: bottom;\">");
							        		 $("#estadocoracao").val(1);
						        	 }else if(estado==3){
							        		 $("#divestadocoracao").html("<label style=\"color: red;\"><b>Orgão não válido </b></label><img alt=\"Orgão não válido\" src=\"resources/imagens/SA1.png\" style=\"width: 20px; height: 20px; vertical-align: bottom;\">");
							        		 $("#estadocoracao").val(2);
						        	 }
						        	 
						        	 
						        	// gravaharmoniocoracao();
						        	 
						        	 	var coddador = $("#dadorcod").text();
						        		var estadocoracao = $("#estadocoracao").val();
						        		
						        		$("#coracaocod").val("");
						        		$("#lblcodcoracao").text("");
						        		
						        		if(estadocoracao!=2 && estadocoracao!=0){
						        		$("#coracaocod").val(coddador+"-CO");
						        		$("#lblcodcoracao").text(coddador+"-CO");
						        		}
						        		
						        	
						        		 $.ajax({
						        		        url: 'gravacolheitaharmoniocoracao',
						        		        type: 'POST',
						        		        cache: false,
						        		        data: $("#formcoracao").serialize(),
						        	         success: function(data, textStatus, jqXHR)
						        	         {

						        	        	 alertify.success("Estado do coracao alterado com sucesso!");
						        					spinner.stop();
						        	         },
						        	         error: function(jqXHR, textStatus, errorThrown) 
						        	         {
						        					if(textStatus=='error'){
						        					//	alert("Ocorreu um erro,por favor tente novamente");
						        						alertify.error('Não foi possível completar o pedido, por favor tente novamente');
						        					//location.href="errorpage";
						        					}
						        				spinner.stop();
						        	         }
						        		    });	
				        	 }
								spinner.stop();
				         },
				         error: function(jqXHR, textStatus, errorThrown) 
				         {
								if(textStatus=='error'){
								//	alert("Ocorreu um erro,por favor tente novamente");
									alertify.error('Não foi possível completar o pedido, por favor tente novamente');
								//location.href="errorpage";
								}
							spinner.stop();
				         }
					    });	
		    } else {
		    	alertify.error("Processo cancelado");
		    }
		});
	
}


function registatempoassistoliacoracao(){
	//alert("grava assistolia tempo");
	
	var spinner = new Spinner(opts).spin(document.getElementById('spinnergif'));
	 $.ajax({
	        url: 'registatempoassistoliacoracao',
	        type: 'POST',
	        cache: false,
         success: function(data, textStatus, jqXHR)
         {
        	 
        	 
        	// alert("data: "+data[0]+", tempo decorrido: "+data[1]);
        	 var d = Date.parse(data[0]).toString('HH:mm');
       	  	//var d = Date.parse(data).toString('HH:mm');
       		$("#horaassistolia").html(d);  
       		$("#tempocoracao").html(data[1]);
       		spinner.stop();
         },
         error: function(jqXHR, textStatus, errorThrown) 
         {

				alertify.error('Não foi possível completar o pedido, por favor tente novamente');
				spinner.stop();
         }
	    });
	
}