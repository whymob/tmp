$(document).ready(function() {
  $('#tabelacompromissodetalhe').dataTable(  {
      initComplete: function () {
          var api = this.api();

          api.columns().indexes().flatten().each( function ( i ) {
              var column = api.column( i );
              var select = $('<select style="max-width: 77px; margin:auto;"><option value=""></option></select>')
                  .appendTo( $(column.footer()).empty() )
                  .on( 'change', function () {
                      var val = $.fn.dataTable.util.escapeRegex(
                          $(this).val()
                      );

                      column
                          .search( val ? '^'+val+'$' : '', true, false )
                          .draw();
                  } );

              column.data().unique().sort().each( function ( d, j ) {
                  select.append( '<option value="'+d+'">'+d+'</option>' )
              } );
          } );
      },
		        "language": {
          "sProcessing":   "A processar...",
          "sLengthMenu":   "_MENU_ registos por página",
          "sZeroRecords":  "Não foram encontrados resultados",
          "sInfo":         "A mostrar de _START_ até _END_ de _TOTAL_ registos",
          "sInfoEmpty":    "A mostrar de 0 até 0 de 0 registos",
          "sInfoFiltered": "(a filtrar de _MAX_ registos no total)",
          "sInfoPostFix":  "",
          "sSearch":       "Pesquisar:",
          "sUrl":          "",
          "oPaginate": {
          	"sFirst":    "Primeiro",
          	"sPrevious": "Anterior",
          	"sNext":     "Seguinte",
          	"sLast":     "Último"
          }
      },"bPaginate": false
  
  
} );
 
$("#tabelacompromissodetalhe_length").css({"borderTopWidth": "0", "borderRightWidth": "0" , "borderBottomWidth": "0", "borderLeftWidth": "0"});
} );