﻿/**
 * 
 */

var opts = {
		  lines: 11, // The number of lines to draw
		  length: 30, // The length of each line
		  width: 13, // The line thickness
		  radius: 25, // The radius of the inner circle
		  corners: 1, // Corner roundness (0..1)
		  rotate: 0, // The rotation offset
		  direction: 1, // 1: clockwise, -1: counterclockwise
		  color: 'grey', // #rgb or #rrggbb or array of colors
		  speed: 1.5, // Rounds per second
		  trail: 60, // Afterglow percentage
		  shadow: true, // Whether to render a shadow
		  hwaccel: true, // Whether to use hardware acceleration
		  className: 'spinner', // The CSS class to assign to the spinner
		  zIndex: 2e9, // The z-index (defaults to 2000000000)
		  top: '50%', // Top position relative to parent
		  left: '50%' // Left position relative to parent
		};

function editalesoesbroncoescopia()
{
	var lesoesbronco = $("#lesoesbronco").is(":checked");
	
	if(lesoesbronco == false)
		document.getElementById("dadosbroncoescopia").style.display = 'none';
	else
		document.getElementById("dadosbroncoescopia").style.display = 'block';
}

function salvarbroncobotao()
{
	var traqueia = $("#traqueia").val();
	var brdireito = $("#brdireito").val();
	var bresquerdo = $("#bresquerdo").val();
	var brsuplementar = $("#brsuplementar").val(); 
	var secrecaobrdireito = $("#secrecaobrdireito").val();
	var secrecaobresquerdo = $("#secrecaobresquerdo").val();
	var secrecaobrsuplementar = $("#secrecaobrsuplementar").val();
	var orificiosbrdireito =  $("#orificiosbrdireito").val();
	var orificiosbresquerdo =  $("#orificiosbresquerdo").val();
	var orificiosbrsuplementar =  $("#orificiosbrsuplementar").val();
	var aspiracao =  $("#aspiracao").val();
	var amostralab = $("#amostralabbronco").is(":checked");
	var lesoes = $("#lesoesbronco").is(":checked");
	var notasbronco = $("#notasbronco").val();
	
	if(document.getElementById("horaExamebronco").value.length == 0)
	{
		alertify.error('Deve escolher a hora do exame');
	}
	else
	{
		var spinner = new Spinner(opts).spin(document.getElementById('spinnergif'));
		
		var data = $("#dataExamebronco").val();
		var hora = $("#horaExamebronco").val();
		var formatodata = data+" "+hora;
	//	var d=  Date.parse(formatodata).toString('dd/MM/yyyy, HH:mm:ss');
		var d=  new Date(Date.parse(formatodata)).toString('dd/MM/yyyy, HH:mm:ss');
		$("#datahorabronco").val(d);
		var datahorabronco = $("#datahorabronco").val();
		
		$.ajax
		({
			url: 'salvarbronco',
			type: 'POST',
			data: {"datahorabronco" : datahorabronco, "traqueia" : traqueia, "brdireito" : brdireito, "bresquerdo" : bresquerdo, "brsuplementar" : brsuplementar, "secrecaobrdireito" : secrecaobrdireito, 
				"secrecaobresquerdo" : secrecaobresquerdo, "secrecaobrsuplementar" : secrecaobrsuplementar, "orificiosbrdireito" : orificiosbrdireito, "amostralab" : amostralab, "lesoes" : lesoes, 
				"orificiosbresquerdo" : orificiosbresquerdo, "orificiosbrsuplementar" : orificiosbrsuplementar, "notasbronco" : notasbronco, "aspiracao" : aspiracao},
			success: function(data, textStatus, jqXHR)
			{
				$("#statusbronco").attr("src","resources/imagens/green-check.gif");
				alertify.success('Dados gravados com sucesso');
				spinner.stop();
			},
			error: function(jqXHR, textStatus, errorThrown) 
			{
				if(textStatus=='error'){
					alertify.error('Não foi possível completar o pedido, por favor tente novamente');
				}
				spinner.stop();
			}           
		});
	}	
}

function carregarlesaobroncoescopia()
{	
	var patologia = $("#patologia").val();
	var t = $("#T").is(":checked");
	var bd = $("#BD").is(":checked");
	var be = $("#BE").is(":checked");
	var bs = $("#BS").is(":checked");
	
	if(t === false && bd === false && be === false)
	{
		alertify.error("É necessário seleccionar o local da patologia");
	}
	else
		{
			alertify.confirm("Confirma a introdução da patologia? ", function (a) 
			{
			    if (a) 
			    {
					var spinner = new Spinner(opts).spin(document.getElementById('spinnergif'));

					 $.ajax({
					        url: 'addlesaotabelabroncoescopia',
					        type: 'POST',
					        cache: false,
					        data: {"patologia" : patologia, "t": t, "bd": bd, "be": be, "bs": bs},
				            success: function(data, textStatus, jqXHR)
				            {
				            	$("#tabelapatologia").html(data);
				 				alertify.success("Inserção efectuada com sucesso");
				 				spinner.stop();

				 				$("#patologia").val("Normal");
				 				$('#T').prop('checked', false);
				 				$('#BD').prop('checked', false);
				 				$('#BE').prop('checked', false);
				            },
				            error: function(jqXHR, textStatus, errorThrown) 
				            {
				 				if(textStatus=='error')
				 				{
				 					alertify.error('Não foi possível completar o pedido, por favor tente novamente');
				 				}
				 				spinner.stop();
				            }
					    });	
			    	
			    } else {
			    	//alertify.error("Processo de inserção cancelado");
			    }
			});
		}
		
}

function cancelaredicaobroncoescopia()
{
	$("#dadosedicaobroncoescopia").hide();
	$("#dadosinsercaobroncoescopia").show();
}

function mudaparaedicaobroncoescopia(id, patologia, t, bd, be, bs)
{
	$("#nomepatologia").val(patologia);
	$("#idbroncoescopia").val(id);
	$('#TE').prop('checked', false);
	$('#BDE').prop('checked', false);
	$('#BEE').prop('checked', false);
	$('#BSE').prop('checked', false);
	
	if(t === 'true')
		$('#TE').prop('checked', true);
	if(bd === 'true')
		$('#BDE').prop('checked', true);
	if(be === 'true')
		$('#BEE').prop('checked', true);
	if(bs === 'true')
		$('#BSE').prop('checked', true);
	
	$("#dadosedicaobroncoescopia").show();
	$("#dadosinsercaobroncoescopia").hide();
}

function guardaredicaobroncoescopia()
{
	var idbroncoescopia = $("#idbroncoescopia").val();
	var patologia = $("#nomepatologia").val();
	var t = $("#TE").is(":checked");
	var bd = $("#BDE").is(":checked");
	var be = $("#BEE").is(":checked");
	var bs = $("#BSE").is(":checked");

	if(t === false && bd === false && be === false)
	{
		alertify.error("É necessário seleccionar o local da patologia");
	}
	else
		{
			alertify.confirm("Confirma a alteração da patologia? ", function (a) 
			{
			    if (a) 
			    {
					var spinner = new Spinner(opts).spin(document.getElementById('spinnergif'));

					 $.ajax({
						 url: 'editarlesaobroncoescopia',
					     type: 'POST',
					     cache: false,
					     data: {"idbroncoescopia": idbroncoescopia, "patologia" : patologia, "t": t, "bd": bd, "be": be, "bs": bs},
				         success: function(data, textStatus, jqXHR)
				         {
				        	$("#tabelapatologia").html(data);
							alertify.success("Alteração efectuada com sucesso");
							
							$("#dadosedicaobroncoescopia").hide();
							$("#dadosinsercaobroncoescopia").show();
							
							spinner.stop();
				         },
				         error: function(jqXHR, textStatus, errorThrown) 
				         {
				        	 if(textStatus=='error')
				        	 {
								alertify.error('Não foi possível completar o pedido, por favor tente novamente');
							}
				        	 spinner.stop();
				         }
					 });	
			    }
			});
		}
}

function removeleasobroncoescopia(idbroncoescopia)
{
	alertify.confirm("Confirma a eliminação da patologia? ", function (v) 
	{
		if (v) 
		{
			var spinner = new Spinner(opts).spin(document.getElementById('spinnergif'));
			
			$.ajax({
				url: 'removerlesaobroncoescopia',
				type: 'POST',
			    cache: false,
			    data: {"idbroncoescopia": idbroncoescopia},
			    success: function(data, textStatus, jqXHR)
			    {
			    	$("#tabelapatologia").html(data);
					alertify.success("Patologia removida com sucesso");
					
					$("#dadosedicaobroncoescopia").hide();
					$("#dadosinsercaobroncoescopia").show();
					
					spinner.stop();
			    },
			    error: function(jqXHR, textStatus, errorThrown) 
			    {
				    if(textStatus=='error')
				    {
				    	alertify.error('Não foi possível completar o pedido, por favor tente novamente');
					}
				    spinner.stop();
			    }
			});	
		}
		else 
		{
			//alertify.error("Processo de eliminação cancelado");
		}
	});
}