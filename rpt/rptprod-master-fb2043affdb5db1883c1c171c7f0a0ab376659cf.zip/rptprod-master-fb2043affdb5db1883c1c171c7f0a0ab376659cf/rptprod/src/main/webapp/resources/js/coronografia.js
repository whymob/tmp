/**
 * 
 */

var opts = {
		  lines: 11, // The number of lines to draw
		  length: 30, // The length of each line
		  width: 13, // The line thickness
		  radius: 25, // The radius of the inner circle
		  corners: 1, // Corner roundness (0..1)
		  rotate: 0, // The rotation offset
		  direction: 1, // 1: clockwise, -1: counterclockwise
		  color: 'grey', // #rgb or #rrggbb or array of colors
		  speed: 1.5, // Rounds per second
		  trail: 60, // Afterglow percentage
		  shadow: true, // Whether to render a shadow
		  hwaccel: true, // Whether to use hardware acceleration
		  className: 'spinner', // The CSS class to assign to the spinner
		  zIndex: 2e9, // The z-index (defaults to 2000000000)
		  top: '50%', // Top position relative to parent
		  left: '50%' // Left position relative to parent
		};


$(document).ready(function () {
    var charReg = /^\s*[a-zA-Z0-9,.\s]+\s*$/;
    $(".warning").hide();
    $('#nomecoronografia').keyup(function () {
        var inputVal = $(this).val();
        if (!charReg.test(inputVal)) {
            $(this).parent().find(".warning").show();
        } else {
            $(this).parent().find(".warning").hide();
        }
    });
    
    
    
    
    //tamanho do ficheiro para upload
    $("#ficheirocoronografia").change(function (){
    		     var iSize = ($("#ficheirocoronografia")[0].files[0].size / 1024);
    		     if (iSize / 1024 > 1)
    		     {
    		        if (((iSize / 1024) / 1024) > 1)
    		        {
    		            iSize = (Math.round(((iSize / 1024) / 1024) * 100) / 100);
    		            $("#lbltamanho4").html( iSize + "Gb");
    		        }
    		        else
    		        {
    		            iSize = (Math.round((iSize / 1024) * 100) / 100)
    		            if(iSize<=10){
    		            	$("#lbltamanho4").html( iSize + "Mb");
    		            }else{
    		            	$("#lbltamanho4").html( iSize + "Mb");
    		        		alertify.error('O ficheiro escolhido excede o limite de 10Mb, por favor escolha um ficheiro dentro do limite imposto');	
    		            }
    		        }
    		     }
    		     else
    		     {
    		        iSize = (Math.round(iSize * 100) / 100)
    		        $("#lbltamanho4").html( iSize  + "kb");
    		     }   
    });
});


function salvarcoronabotao()
{
	var notascorona = $("#notascorona").val();
	var notascorona = $("#notascorona").val();
			
	if(document.getElementById("horaExamecorona").value.length == 0)
	{
		alertify.error('Deve escolher a hora do exame');
	}
	else
	{
		var spinner = new Spinner(opts).spin(document.getElementById('spinnergif'));
		
		var data = $("#dataExamecorona").val();
		var hora = $("#horaExamecorona").val();
		var formatodata = data+" "+hora;
		//var d= new Date(formatodata);
		//var d=  Date.parse(formatodata);
		var d=  new Date(Date.parse(formatodata)).toString('dd/MM/yyyy, HH:mm:ss');
		//var d=  Date.parse(formatodata).toString('dd/MM/yyyy, HH:mm:ss');
		$("#datahoracorona").val(d);
		var datahoracorona = $("#datahoracorona").val();
		
		$.ajax
		({
			url: 'salvarcorona',
			type: 'POST',
			data:  {"datahoracorona" : datahoracorona, "notascorona" : notascorona},
			success: function(data, textStatus, jqXHR)
			{
				$("#statuscoron").attr("src","resources/imagens/green-check.gif");
				alertify.success('Dados gravados com sucesso');
				spinner.stop();
			},
			error: function(jqXHR, textStatus, errorThrown) 
			{
				if(textStatus=='error'){
					alertify.error('Não foi possível completar o pedido, por favor tente novamente');
				}
				spinner.stop();
			}           
		});
	}	
}

function carregarlesaocoronografia()
{	
	var arteria = $("#arteria").val();
	var estenose = $("#estenose").val();
	var severidade = $("#severidade").val();
	
	if(arteria == 0 || estenose == 0 || severidade == 0)
	{
		alertify.error("Dados inválidos");
	}
	else
		{
			alertify.confirm("Confirma a introdução da lesão? ", function (a) 
			{
			    if (a) 
			    {
					var spinner = new Spinner(opts).spin(document.getElementById('spinnergif'));

					 $.ajax({
					        url: 'addlesaotabelacoronografia',
					        type: 'POST',
					        cache: false,
					        data: {"arteria" : arteria, "estenose": estenose, "severidade": severidade},
				            success: function(data, textStatus, jqXHR)
				            {
				       
				            	$("#tabelacoronografia").html(data);
				 				alertify.success("Inserção efectuada com sucesso");
				 				spinner.stop();

				 				$("#arteria").val(0);
				 				$("#estenose").val(0);
				 				$("#severidade").val(0);
				            },
				            error: function(jqXHR, textStatus, errorThrown) 
				            {
				       
				 				if(textStatus=='error')
				 				{
				 					alertify.error('Não foi possível completar o pedido, por favor tente novamente');
				 				}
				 				spinner.stop();
				            }
					    });	
			    	
			    } else {
			    	//alertify.error("Processo de inserção cancelado");
			    }
			});
		}
		
}

function cancelaredicaocoronografia()
{
	$("#dadosedicaocoronografia").hide();
	$("#dadosinsercaocoronografia").show();
}

function mudaparaedicaocoronografia(id, arteria, estenose, severidade)
{
	$("#arteriaedicao").val(arteria);
	$("#estenoseedicao").val(estenose);
	$("#severidadeedicao").val(severidade);
	$("#idcoronografia").val(id);
	$("#dadosedicaocoronografia").show();
	$("#dadosinsercaocoronografia").hide();
}

function guardaredicaocoronografia()
{
	var idcoronografia = $("#idcoronografia").val();
	var arteria = $("#arteriaedicao").val();
	var estenose = $("#estenoseedicao").val();
	var severidade = $("#severidadeedicao").val();

	var spinner = new Spinner(opts).spin(document.getElementById('spinnergif'));
	
	 $.ajax({
		 url: 'editarlesaocoronografia',
	     type: 'POST',
	     cache: false,
	     data: {"idcoronografia": idcoronografia, "arteria" : arteria, "estenose": estenose, "severidade": severidade},
         success: function(data, textStatus, jqXHR)
         {
        	$("#tabelacoronografia").html(data);
			alertify.success("Alteração efectuada com sucesso");
			
			$("#dadosedicaocoronografia").hide();
			$("#dadosinsercaocoronografia").show();
			
			spinner.stop();
         },
         error: function(jqXHR, textStatus, errorThrown) 
         {
        	 if(textStatus=='error')
        	 {
				alertify.error('Não foi possível completar o pedido, por favor tente novamente');
			}
        	 spinner.stop();
         }
	    });	
}

function removeleasocoronografia(idcoronografia)
{
	//var idcoronografia = $("#idcoronografia").val();
//	var arteria = $("#arteriaedicao").val();
//	var estenose = $("#estenoseedicao").val();
//	var severidade = $("#severidadeedicao").val();
	
//	, "arteria" : arteria, "estenose": estenose, "severidade": severidade

	alertify.confirm("Confirma a eliminação da lesão? ", function (v) 
	{
		if (v) 
		{
			var spinner = new Spinner(opts).spin(document.getElementById('spinnergif'));
			
			$.ajax({
				url: 'removerlesaocoronografia',
				type: 'POST',
			    cache: false,
			    data: {"idcoronografia": idcoronografia},
			    success: function(data, textStatus, jqXHR)
			    {
			    	$("#tabelacoronografia").html(data);
					alertify.success("Lesao removida com sucesso");
					
					$("#dadosedicaocoronografia").hide();
					$("#dadosinsercaocoronografia").show();
					
					spinner.stop();
			    },
			    error: function(jqXHR, textStatus, errorThrown) 
			    {
				    if(textStatus=='error')
				    {
				    	alertify.error('Não foi possível completar o pedido, por favor tente novamente');
					}
				    spinner.stop();
			    }
			});	
		}
		else 
		{
			//alertify.error("Processo de eliminação cancelado");
		}
	});
}

function alterafilecoronografia()
{	
	//atualizar input nome ficheiro para possibilitar escolher nome
	var n = $('#ficheirocoronografia').val().replace(/C:\\fakepath\\/i, '');
	var nome = n.replace(/[^a-z0-9.\s]/gi, '').replace(/[_\s]/g, ' ');
	$('#nomecoronografia').val(nome);
}

function uploadcoronografia(event)
{	
	$('#id_coronografia').val($('#coronografiaobj').val());
	
	if($('#nomecoronografia').val()=="")
	{
		alertify.error('É necessário seleccionar um ficheiro');	
	}
	else
	{
	
	function getDoc(frame) 
	{
	     var doc = null;

	     try 
	     {
	         if (frame.contentWindow) 
	         {
	             doc = frame.contentWindow.document;
	         }
	     }
	     catch(err) 
	     {
	     }
	 
	     if (doc) 
	     {
	         return doc;
	     }
	 
	     try 
	     { 
	         doc = frame.contentDocument ? frame.contentDocument : frame.document;
	     }
	     catch(err) 
	     {
	         doc = frame.document;
	     }
	     return doc;
	 }
	$("#enviarficheirocoronografia").submit(function(e)
	{
	    var formObj = $(this);
	    var formURL = formObj.attr("action");
	   
	    if(window.FormData !== undefined)  // para browsers HTML5
	    {
	        var formData = new FormData(this);
	        $.ajax({
	            url: formURL,
	            type: 'POST',
	            data:  formData,
	            mimeType:"multipart/form-data",
	            contentType: false,
	            cache: false,
	            processData:false,
	            success: function(data, textStatus, jqXHR)
	            {
	 				alertify.success(data);
	 				
	 				var player1 = videojs('coronogvid');
	 				var idcoronografia = $('#coronografiaobj').val();
	 				$.post("carreganomedoccoronografia", {'idcoronografia' : idcoronografia}, function(resposta) {
	 					player1.dispose();
	 					$("#videocoronografia").html(resposta);
	 					player1 = videojs('coronogvid');
	 				//	$("#caminhodoccoronografia").html(resposta);
	 				});
	 				
//	 				$.post("carregaficheirocoronografia", {'idcoronografia' : idcoronografia}, function(resposta) {
//	 					$("#imagemcoronografia").html(resposta);
//	 				});
	 				
	 			//	$('#nomecoronografia').val("");
	            },
	            error: function(jqXHR, textStatus, errorThrown) 
	            {
	 				if(textStatus=='error')
	 				{
	 					alertify.error('Não foi possível completar o pedido, por favor tente novamente');
	 				}
	            }           
	       });
	        e.preventDefault();
	     //   e.unbind();
	        e.stopImmediatePropagation();
	   }
	   else
	    {
	        //gerar um id aleatório
	        var  iframeId = 'unique' + (new Date().getTime());
	 
	        //criar um iframe vazio
	        var iframe = $('<iframe src="javascript:false;" name="'+iframeId+'" />');
	 
	        //esconder o iframe
	        iframe.hide();
	 
	        //definir o alvo do form para o iframe
	        formObj.attr('target',iframeId);
	 
	        //Adicionar o iframe ao body
	        iframe.appendTo('body');
	        iframe.load(function(e)
	        {
	            var doc = getDoc(iframe[0]);
	            var docRoot = doc.body ? doc.body : doc.documentElement;
	            var data = docRoot.innerHTML;
	        });
	 
	    }     
	});
	$("#enviarficheirocoronografia").submit();
	}
}