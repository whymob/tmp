﻿/**
 * Script Div Morte Cerebral
 */

$(document).ready(function () {
    var charReg = /^\s*[a-zA-Z0-9,.\s]+\s*$/;
    $(".warning2").hide();
    $('#nome2').keyup(function () {
        var inputVal = $(this).val();
        if (!charReg.test(inputVal)) {
            $(this).parent().find(".warning2").show();
        } else {
            $(this).parent().find(".warning2").hide();
        }

    });
    
    
    
    //tamanho do ficheiro para upload
    $("#ficheiro2").change(function (){
    		     var iSize = ($("#ficheiro2")[0].files[0].size / 1024);
    		     if (iSize / 1024 > 1)
    		     {
    		        if (((iSize / 1024) / 1024) > 1)
    		        {
    		            iSize = (Math.round(((iSize / 1024) / 1024) * 100) / 100);
    		            $("#lbltamanho2").html( iSize + "Gb");
    		        }
    		        else
    		        {
    		            iSize = (Math.round((iSize / 1024) * 100) / 100)
    		            if(iSize<=10){
    		            	$("#lbltamanho2").html( iSize + "Mb");
    		            }else{
    		            	$("#lbltamanho2").html( iSize + "Mb");
    		        		alertify.error('O ficheiro escolhido excede o limite de 10Mb, por favor escolha um ficheiro dentro do limite imposto');	
    		            }
    		        }
    		     }
    		     else
    		     {
    		        iSize = (Math.round(iSize * 100) / 100)
    		        $("#lbltamanho2").html( iSize  + "kb");
    		     }   
    });
    
    
    
    
});

function mudadataprova()
{
	var data = document.getElementById("p1_datad").value;
	var hora = document.getElementById("p1_datah").value;
	
	var formatodata = data+" "+hora;
//	var d= new Date(formatodata);
	var d=  Date.parse(formatodata).toString('dd/MM/yyyy, HH:mm:ss');

	$(datahora1).val(d);
}

function mudadataprova2()
{
	var data = document.getElementById("p2_datad").value;
	var hora = document.getElementById("p2_datah").value;
	
	var formatodata = data+" "+hora;
	//var d= new Date(formatodata);
	var d=  Date.parse(formatodata).toString('dd/MM/yyyy, HH:mm:ss');
	$(datahora2).val(d);
}

function salvarmortecerebral()
{
	
	if($("#dadosmortecerebral").validate({
		rules:{
			reanimacoes:{digits: true
			},
			duracaoparagem:{
				"time24": true
				},
			duracaoultimareanimacao: {
				"time24": true    
			    },
			p1_om1: {
			    digits: true
		    },
			p1_om2: {
			    digits: true
		    },
		    p2_om1: {
			    digits: true
		    },
		    p2_om2: {
			    digits: true
		    },
		},
		  messages: {
			  reanimacoes:{
				  digits: "<font color=\"red\">O campo Reanimações só permite digitos</font>" 
			  },
			  p1_om1: {
				  digits: "<font color=\"red\">O campo OM só permite digitos</font>",
				},
			  p1_om2: {
					digits: "<font color=\"red\">O campo OM só permite digitos</font>",
					},
			  p2_om1: {
					digits: "<font color=\"red\">O campo OM só permite digitos</font>",
					},
			  p2_om2: {
					digits: "<font color=\"red\">O campo OM só permite digitos</font>",
				},
			  },
		errorLabelContainer: '#errosmortecerebral',
		wrapper: "li"
		}).form()){
	
	
	
	if(document.getElementById("p1_datah").value.length == 0 || document.getElementById("p1_medico1").value.length == 0 || document.getElementById("p1_medico2").value.length == 0 || document.getElementById("p1_om1").value == 0 || document.getElementById("p1_om2").value == 0){
		alertify.error('É necessário preencher todos os dados da prova 1.');
	}
	else if((document.getElementById("p2_datah").value.length == 0 && document.getElementById("p2_medico1").value.length == 0 && document.getElementById("p2_medico2").value.length == 0 && document.getElementById("p2_om1").value == 0 && document.getElementById("p2_om2").value == 0) && (document.getElementById("p1_datah").value.length > 0 && document.getElementById("p1_medico1").value.length > 0 && document.getElementById("p1_medico2").value.length > 0 && document.getElementById("p1_om1").value > 0 && document.getElementById("p1_om2").value > 0))
		{
			var data = document.getElementById("p1_datad").value;
			var hora = document.getElementById("p1_datah").value;
			var formatodata = data+" "+hora;
			var d=  Date.parse(formatodata).toString('dd/MM/yyyy, HH:mm:ss');
			$("#datahora1").val(d);


			var spinner = new Spinner(opts).spin(document.getElementById('spinnergif'));			
			
			$.ajax
			({
	            url: 'salvamortecerebral',
	            type: 'POST',
	            data:  $("#dadosmortecerebral").serialize(),
	            mimeType:"multipart/form-data",
	            success: function(data, textStatus, jqXHR)
	            {
	            	alertify.success('Dados gravados com sucesso');
	 				spinner.stop();
	            },
	            error: function(jqXHR, textStatus, errorThrown) 
	            {
	 				if(textStatus=='error'){
	 					alertify.error('Não foi possível completar o pedido, por favor tente novamente');
	 				}
	 				spinner.stop();
	            }           
	        });
		}
		else if((document.getElementById("p2_datah").value.length == 0 || document.getElementById("p2_medico1").value.length == 0 || document.getElementById("p2_medico2").value.length == 0 || document.getElementById("p2_om1").value == 0 || document.getElementById("p2_om2").value == 0) && (document.getElementById("p1_datah").value.length > 0 && document.getElementById("p1_medico1").value.length > 0 && document.getElementById("p1_medico2").value.length > 0 && document.getElementById("p1_om1").value > 0 && document.getElementById("p1_om2").value > 0))
		{
			alertify.error('É necessário preencher todos os dados da prova 2.');
		}
		else if((document.getElementById("p2_datah").value.length > 0 && document.getElementById("p2_medico1").value.length > 0 && document.getElementById("p2_medico2").value.length > 0 && document.getElementById("p2_om1").value > 0 && document.getElementById("p2_om2").value > 0) && (document.getElementById("p1_datah").value.length > 0 && document.getElementById("p1_medico1").value.length > 0 && document.getElementById("p1_medico2").value.length > 0 && document.getElementById("p1_om1").value > 0 && document.getElementById("p1_om2").value > 0))
		{
			
			
			var data = document.getElementById("p1_datad").value;
			var hora = document.getElementById("p1_datah").value;
			var formatodata = data+" "+hora;
			var d=  Date.parse(formatodata).toString('dd/MM/yyyy, HH:mm:ss');
			$("#datahora1").val(d);
			
			var data = document.getElementById("p2_datad").value;
			var hora = document.getElementById("p2_datah").value;
			var formatodata2 = data+" "+hora;
	
			var d=  Date.parse(formatodata2).toString("dd/MM/yyyy, HH:mm:ss");

			$("#datahora2").val(d.toLocaleString());
			
			var spinner = new Spinner(opts).spin(document.getElementById('spinnergif'));

			$.ajax
			({
	            url: 'salvamortecerebral2',
	            type: 'POST',
	            data:  $("#dadosmortecerebral").serialize(),
	            mimeType:"multipart/form-data",
	            success: function(data, textStatus, jqXHR)
	            {
	            	alertify.success('Dados gravados com sucesso');
	 				spinner.stop();
	            },
	            error: function(jqXHR, textStatus, errorThrown) 
	            {
	 				if(textStatus=='error'){
	 					alertify.error('Não foi possível completar o pedido, por favor tente novamente');
	 				}
	 				spinner.stop();
	            }           
	        });
		}	

	}else{
		alertify.error('Existem campos que não foram validados, por favor confirme os dados');
	}
}

function alterafile2(){
	
	//atualizar input nome ficheiro para possibilitar escolher nome
	var n = $('#ficheiro2').val().replace(/C:\\fakepath\\/i, '');
	var nome = n.replace(/[^a-z0-9.\s]/gi, '').replace(/[_\s]/g, ' ');
	$('#nome2').val(nome);
}

function upload2(){
	

	//var nome = $('#ficheiro').val().replace(/C:\\fakepath\\/i, '');
	//$('#id_dador').val($('#dador_id').val());
	
	if($('#nome2').val()==""){
			alertify.error('É necessário seleccionar um ficheiro');	
	}else{
	
	
	function getDoc(frame) {
	     var doc = null;
	 
	     // IE8 verificação do acesso em cascata
	     try {
	         if (frame.contentWindow) {
	             doc = frame.contentWindow.document;
	         }
	     } catch(err) {
	     }
	 
	     if (doc) { // conteudo obtido com sucesso
	         return doc;
	     }
	 
	     try { 
	         doc = frame.contentDocument ? frame.contentDocument : frame.document;
	     } catch(err) {
	         // ultima tentativa
	         doc = frame.document;
	     }
	     return doc;
	 }
	$("#enviarficheiromc").submit(function(e)
	{
	 
	    var formObj = $(this);
	    var formURL = formObj.attr("action");
	 
	    if(window.FormData !== undefined)  // para browsers HTML5
	    {
	    	var spinner = new Spinner(opts).spin(document.getElementById('spinnergif'));
	        var formData = new FormData(this);
	        $.ajax({
	            url: formURL,
	            type: 'POST',
	            data:  formData,
	            mimeType:"multipart/form-data",
	            contentType: false,
	            cache: false,
	            processData:false,
	            success: function(data, textStatus, jqXHR)
	            {
	 				alertify.success(data);
	 				var id_MorteCerebral = $('#id_mc').val();
	 				$.post("carreganomedocmc", {'id_MorteCerebral' : id_MorteCerebral}, function(resposta) {
	 					$("#caminhodocmc").html(resposta);
	 					spinner.stop();
	 				});
	            },
	            error: function(jqXHR, textStatus, errorThrown) 
	            {
	 				if(textStatus=='error'){
	 				//	alert("Ocorreu um erro,por favor tente novamente");
	 					alertify.error('Não foi possível completar o pedido, por favor tente novamente');
	 				//location.href="errorpage";
	 				}
	 				spinner.stop();
	            }           
	       });
	        e.preventDefault();
	        //e.unbind(); // não usar, antes o stopImmediatePropagation()
	        e.stopImmediatePropagation();
	   }
	   else  //para browsers antigos
	    {
	        //gerar um id aleatório
	        var  iframeId = 'unique' + (new Date().getTime());
	 
	        //criar um iframe vazio
	        var iframe = $('<iframe src="javascript:false;" name="'+iframeId+'" />');
	 
	        //esconder o iframe
	        iframe.hide();
	 
	        //definir o alvo do form para o iframe
	        formObj.attr('target',iframeId);
	 
	        //Adicionar o iframe ao body
	        iframe.appendTo('body');
	        iframe.load(function(e)
	        {
	            var doc = getDoc(iframe[0]);
	            var docRoot = doc.body ? doc.body : doc.documentElement;
	            var data = docRoot.innerHTML;
	            //dados do servidor server.
	 
	        });
	 
	    }     
	});
	$("#enviarficheiromc").submit();
	}
	

}