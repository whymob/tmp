/**
 * 
 */

function salvargs()
{
//	event.preventDefault();
	
	var spinner = new Spinner(opts).spin(document.getElementById('spinnergif'));

	$.ajax
	({
        url: 'salvags',
        type: 'POST',
        data:  $("#dadosgs").serialize(),
        mimeType:"multipart/form-data",
        success: function(data, textStatus, jqXHR)
        {
        	$("#statusgruposang").attr("src","resources/imagens/green-check.gif");
        	alertify.success('Dados gravados com sucesso');
			spinner.stop();
        },
        error: function(jqXHR, textStatus, errorThrown) 
        {
				if(textStatus=='error'){
					alertify.error('Não foi possível completar o pedido, por favor tente novamente');
				}
   				spinner.stop();
        }           
    });	
}