/**
 * Script Página Pesquisa dador
 */

var opts = {
		  lines: 11, // The number of lines to draw
		  length: 30, // The length of each line
		  width: 13, // The line thickness
		  radius: 25, // The radius of the inner circle
		  corners: 1, // Corner roundness (0..1)
		  rotate: 0, // The rotation offset
		  direction: 1, // 1: clockwise, -1: counterclockwise
		  color: 'grey', // #rgb or #rrggbb or array of colors
		  speed: 1.5, // Rounds per second
		  trail: 60, // Afterglow percentage
		  shadow: true, // Whether to render a shadow
		  hwaccel: true, // Whether to use hardware acceleration
		  className: 'spinner', // The CSS class to assign to the spinner
		  zIndex: 2e9, // The z-index (defaults to 2000000000)
		  top: '50%', // Top position relative to parent
		  left: '50%' // Left position relative to parent
		};

function abredetalheorgao(id)
{
	var spinner = new Spinner(opts).spin(document.getElementById('spinnergif'));
	$.post("abreorgaos", {'id' : id}, function(resposta) {
			$("#detalheorgaos").html(resposta);
			spinner.stop();
	
	document.getElementById("detalheorgaos").style.display = 'block';
	document.getElementById("cabecalhoorgao").style.display = 'none';
	});
}

function mudaedicao()
{
	document.getElementById("alteracao").style.display = 'block';
	document.getElementById("leitura").style.display = 'none';
}

function abrirdetalheavaliacao(id)
{
	var spinner = new Spinner(opts).spin(document.getElementById('spinnergif'));
	$.post("abreavaliacaocoord", {'id' : id}, function(resposta) {
			$("#detalheavaliacao").html(resposta);
			spinner.stop();

	document.getElementById("detalheavaliacao").style.display = 'block';
	document.getElementById("cabecalhoavaliacao").style.display = 'none';
	document.getElementById("basedador").className = "selected";

	document.getElementById("harmonioshclinica").style.display = 'none';
	document.getElementById("harmoniosanalises").style.display = 'none';
	document.getElementById("harmoniosexames").style.display = 'none';
	document.getElementById("harmoniosavainicial").style.display = 'block';
	document.getElementById("harmoniosterapeuticas").style.display = 'none';
	
	jQuery("#avainicial").toggle("fast");
	jQuery("#d16").toggle();
	jQuery("#u16").toggle();
	});
}

function start()
{
	document.getElementById("dador").className = "selected";
	document.getElementById("orgaoscoord").className = "";
	document.getElementById("reports").className = "";
	document.getElementById("ofertas").className = "";
	
	document.getElementById("separadoravaliacao").style.display = 'block';
	document.getElementById("separadorreporte").style.display = 'none';
	document.getElementById("separadororgaos").style.display = 'none';
	document.getElementById("separadorofertas").style.display = 'none';
}

function changeclassSelected2(element)
{
	var tab = element.id;
	
	if(tab == 'historial')
	{
		$("#examefisico").load( "carregaexamefisico", function() {
			$("#geral").load( "carregargeral", function() {
				$("#doencprexistentes").load( "carregaprexistentes", function() {
					$("#sitrisco").load( "carregasitrisco", function() {
						
		document.getElementById("historial").className = "selected";
		document.getElementById("basedador").className = "";
		document.getElementById("analises").className = "";
		document.getElementById("exames").className = "";
		document.getElementById("terapeuticas").className = "";
		
		document.getElementById("harmonioshclinica").style.display = 'block';
		document.getElementById("harmoniosanalises").style.display = 'none';
		document.getElementById("harmoniosavainicial").style.display = 'none';
		document.getElementById("harmoniosexames").style.display = 'none';
		document.getElementById("harmoniosterapeuticas").style.display = 'none';
					});
				});
				});
				});
	}
	else
		if(tab == 'basedador')
		{
			document.getElementById("historial").className = "";
			document.getElementById("basedador").className = "selected";
			document.getElementById("analises").className = "";
			document.getElementById("exames").className = "";
			document.getElementById("terapeuticas").className = "";
			
			document.getElementById("harmonioshclinica").style.display = 'none';
			document.getElementById("harmoniosanalises").style.display = 'none';
			document.getElementById("harmoniosavainicial").style.display = 'block';
			document.getElementById("harmoniosexames").style.display = 'none';
			document.getElementById("harmoniosterapeuticas").style.display = 'none';
		}
		else
			if(tab == 'analises')
			{
				$("#funcorgao").load( "carregafuncoesorgao", function() {
					$("#microbiologia").load( "carregamicrobiologia", function() {
						$("#viro").load( "carregavirologia", function() {
							$("#imunologia").load( "carregaimunologia", function() {
								$("#grupos").load( "carregagruposanguineo", function() {
									
				document.getElementById("historial").className = "";
				document.getElementById("basedador").className = "";
				document.getElementById("analises").className = "selected";
				document.getElementById("exames").className = "";
				document.getElementById("terapeuticas").className = "";
				
				document.getElementById("harmonioshclinica").style.display = 'none';
				document.getElementById("harmoniosanalises").style.display = 'block';
				document.getElementById("harmoniosavainicial").style.display = 'none';
				document.getElementById("harmoniosexames").style.display = 'none';
				document.getElementById("harmoniosterapeuticas").style.display = 'none';
								});
							});
						});
					});
				});
			}
			else
				if(tab == 'exames')
				{
					$("#outrosexamesespecificos").load( "carregaoutrosexamesespecificos", function() {
						$("#gasimetriaeventilacao").load( "carregagasimetriaeventilacao", function() {
					document.getElementById("historial").className = "";
					document.getElementById("basedador").className = "";
					document.getElementById("analises").className = "";
					document.getElementById("exames").className = "selected";
					document.getElementById("terapeuticas").className = "";
					
					document.getElementById("harmonioshclinica").style.display = 'none';
					document.getElementById("harmoniosanalises").style.display = 'none';
					document.getElementById("harmoniosavainicial").style.display = 'none';
					document.getElementById("harmoniosexames").style.display = 'block';
					document.getElementById("harmoniosterapeuticas").style.display = 'none';
						});
					});
				}
				else
					if(tab == 'terapeuticas')
					{
						$("#transfusao").load( "carregatransfusao", function() {
							$("#divterapeuticas").load( "carregadivterapeuticas", function() {
						document.getElementById("historial").className = "";
						document.getElementById("basedador").className = "";
						document.getElementById("analises").className = "";
						document.getElementById("exames").className = "";
						document.getElementById("terapeuticas").className = "selected";

						document.getElementById("harmonioshclinica").style.display = 'none';
						document.getElementById("harmoniosanalises").style.display = 'none';
						document.getElementById("harmoniosavainicial").style.display = 'none';
						document.getElementById("harmoniosexames").style.display = 'none';
						document.getElementById("harmoniosterapeuticas").style.display = 'block';

							});
						});
					}
}

function changeclassSelected(element)
{
	var tab = element.id;
	
	if(tab == 'dador')
	{
		document.getElementById("separadoravaliacao").style.display = 'block';
		document.getElementById("cabecalhoavaliacao").style.display = 'block';
		document.getElementById("separadorreporte").style.display = 'none';
		document.getElementById("separadororgaos").style.display = 'none';
		document.getElementById("separadorofertas").style.display = 'none';
		document.getElementById("detalheavaliacao").style.display = 'none';
		document.getElementById("detalheorgaos").style.display = 'none';
		document.getElementById("cabecalhoorgao").style.display = 'none';
		document.getElementById("dador").className = "selected";
		document.getElementById("orgaoscoord").className = "";
		document.getElementById("reports").className = "";
		document.getElementById("ofertas").className = "";
	}
	else
	if(tab == 'orgaoscoord')
	{
		document.getElementById("dador").className = "";
		document.getElementById("orgaoscoord").className = "selected";
		document.getElementById("reports").className = "";
		document.getElementById("ofertas").className = "";
		document.getElementById("separadoravaliacao").style.display = 'none';
		document.getElementById("separadororgaos").style.display = 'block';
		document.getElementById("separadorofertas").style.display = 'none';	
		document.getElementById("separadorreporte").style.display = 'none';
		document.getElementById("detalheavaliacao").style.display = 'none';
		document.getElementById("cabecalhoorgao").style.display = 'block';
		document.getElementById("detalheorgaos").style.display = 'none';
	}
	else
		if(tab == 'ofertas')
		{
			document.getElementById("dador").className = "";
			document.getElementById("orgaoscoord").className = "";
			document.getElementById("ofertas").className = "selected";
			document.getElementById("reports").className = "";
			
			document.getElementById("separadoravaliacao").style.display = 'none';
			document.getElementById("separadororgaos").style.display = 'none';
			document.getElementById("separadorofertas").style.display = 'block';	
			document.getElementById("separadorreporte").style.display = 'none';
			document.getElementById("detalheavaliacao").style.display = 'none';
			document.getElementById("detalheorgaos").style.display = 'none';
			document.getElementById("cabecalhoavaliacao").style.display = 'none';
		}
	else
	if(tab == 'reports')
	{
		document.getElementById("dador").className = "";
		document.getElementById("orgaoscoord").className = "";
		document.getElementById("ofertas").className = "";
		document.getElementById("reports").className = "selected";
		
		document.getElementById("separadoravaliacao").style.display = 'none';
		document.getElementById("separadororgaos").style.display = 'none';
		document.getElementById("separadorofertas").style.display = 'block';	
		document.getElementById("separadorreporte").style.display = 'none';
		document.getElementById("detalheavaliacao").style.display = 'none';
		document.getElementById("detalheorgaos").style.display = 'none';
		document.getElementById("cabecalhoavaliacao").style.display = 'none';
	}
}

jQuery(document).ready(function() 
{	
jQuery("#d").click(function() 
{
jQuery("#funcorgao").toggle("fast");
jQuery("#u").toggle();
jQuery("#d").toggle();
});

jQuery("#u").click(function() 
{
jQuery("#funcorgao").toggle("fast");
jQuery("#d").toggle();
jQuery("#u").toggle();
});

jQuery("#d2").click(function() 
{
jQuery("#microbiologia").toggle("fast");
jQuery("#u2").toggle();
jQuery("#d2").toggle();
});

jQuery("#u2").click(function() 
{
jQuery("#microbiologia").toggle("fast");
jQuery("#d2").toggle();
jQuery("#u2").toggle();
});

jQuery("#d3").click(function() 
{
jQuery("#viro").toggle("fast");
jQuery("#u3").toggle();
jQuery("#d3").toggle();
});

jQuery("#u3").click(function() 
{
jQuery("#viro").toggle("fast");
jQuery("#d3").toggle();
jQuery("#u3").toggle();
});

jQuery("#d4").click(function() 
{
jQuery("#imunologia").toggle("fast");
jQuery("#u4").toggle();
jQuery("#d4").toggle();
});

jQuery("#u4").click(function() 
{
jQuery("#imunologia").toggle("fast");
jQuery("#d4").toggle();
jQuery("#u4").toggle();
});

jQuery("#d5").click(function() 
{
jQuery("#grupos").toggle("fast");
jQuery("#u5").toggle();
jQuery("#d5").toggle();
});

jQuery("#u5").click(function() 
{
jQuery("#grupos").toggle("fast");
jQuery("#d5").toggle();
jQuery("#u5").toggle();
});

jQuery("#d11").click(function() 
{
jQuery("#examefisico").toggle("fast");
jQuery("#u11").toggle();
jQuery("#d11").toggle();
});

jQuery("#u11").click(function() 
{
jQuery("#examefisico").toggle("fast");
jQuery("#d11").toggle();
jQuery("#u11").toggle();
});

jQuery("#d12").click(function() 
{
jQuery("#geral").toggle("fast");
jQuery("#u12").toggle();
jQuery("#d12").toggle();
});

jQuery("#u12").click(function() 
{
jQuery("#geral").toggle("fast");
jQuery("#d12").toggle();
jQuery("#u12").toggle();
});

jQuery("#d13").click(function() 
{
jQuery("#doencprexistentes").toggle("fast");
jQuery("#u13").toggle();
jQuery("#d13").toggle();
});

jQuery("#u13").click(function() 
{
jQuery("#doencprexistentes").toggle("fast");
jQuery("#d13").toggle();
jQuery("#u13").toggle();
});

jQuery("#d14").click(function() 
{
jQuery("#sitrisco").toggle("fast");
jQuery("#u14").toggle();
jQuery("#d14").toggle();
});

jQuery("#u14").click(function() 
{
jQuery("#sitrisco").toggle("fast");
jQuery("#d14").toggle();
jQuery("#u14").toggle();
});

jQuery("#d16").click(function() 
		{
		jQuery("#avainicial").toggle("fast");
		jQuery("#u16").toggle();
		jQuery("#d16").toggle();
		});

		jQuery("#u16").click(function() 
		{
		jQuery("#avainicial").toggle("fast");
		jQuery("#d16").toggle();
		jQuery("#u16").toggle();
		});

		jQuery("#d17").click(function() 
		{
		jQuery("#orgaos").toggle("fast");
		jQuery("#u17").toggle();
		jQuery("#d17").toggle();
		});

		jQuery("#u17").click(function() 
		{
		jQuery("#orgaos").toggle("fast");
		jQuery("#d17").toggle();
		jQuery("#u17").toggle();
		});

		jQuery("#d18").click(function() 
		{
		jQuery("#fichapessoaldador").toggle("fast");
		jQuery("#u18").toggle();
		jQuery("#d18").toggle();
		});

		jQuery("#u18").click(function() 
		{
		jQuery("#fichapessoaldador").toggle("fast");
		jQuery("#d18").toggle();
		jQuery("#u18").toggle();
		});

jQuery("#d19").click(function() 
{
jQuery("#outrosexamesespecificos").toggle("fast");
jQuery("#u19").toggle();
jQuery("#d19").toggle();
});

jQuery("#u19").click(function() 
{
jQuery("#outrosexamesespecificos").toggle("fast");
jQuery("#d19").toggle();
jQuery("#u19").toggle();
});

jQuery("#d20").click(function() 
{
jQuery("#gasimetriaeventilacao").toggle("fast");
jQuery("#u20").toggle();
jQuery("#d20").toggle();
});

jQuery("#u20").click(function() 
{
jQuery("#gasimetriaeventilacao").toggle("fast");
jQuery("#d20").toggle();
jQuery("#u20").toggle();
});

jQuery("#d30").click(function() 
{
jQuery("#transfusao").toggle("fast");
jQuery("#u30").toggle();
jQuery("#d30").toggle();
});

jQuery("#u30").click(function() 
{
jQuery("#transfusao").toggle("fast");
jQuery("#d30").toggle();
jQuery("#u30").toggle();
});

jQuery("#d31").click(function() 
{
jQuery("#divterapeuticas").toggle("fast");
jQuery("#u31").toggle();
jQuery("#d31").toggle();
});

jQuery("#u31").click(function() 
{
jQuery("#divterapeuticas").toggle("fast");
jQuery("#d31").toggle();
jQuery("#u31").toggle();
});
});