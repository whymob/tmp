$('.float').keypress(function(event) {
	
	var charCode = (event.which) ? event.which : event.keyCode;

	if(charCode == 44){   
		//substituir virgula por ponto
    		event.preventDefault();
    		 if($(this).val().indexOf('.') == -1){
				$(this).val($(this).val() + '.');
    		 }
		}else if(charCode==8){
		//apagar
		}else if(charCode < 46 
    || charCode > 59) {
	
        event.preventDefault();
    } 

	//permite só um ponto
    if(charCode == 46
    && $(this).val().indexOf('.') != -1) {
        event.preventDefault();
    } 
});

function registahorasrins(tipo){
	
	var spinner = new Spinner(opts).spin(document.getElementById('spinnergif'));
	 $.ajax({
	        url: 'registahorasrins',
	        type: 'POST',
	        cache: false,
	        data:  {"tipo" : tipo},
          success: function(data, textStatus, jqXHR)
          {
        	  var d = Date.parse(data).toString('dd/MM/yyyy HH:mm');
        	  
        	  if(tipo==1){
        		  $("#iniciorins").html(d);    
        	  }else if(tipo==2){
        		  $("#fimrins").html(d);	  
        	  }
				spinner.stop();
          },
          error: function(jqXHR, textStatus, errorThrown) 
          {
				if(textStatus=='error'){
				//	alert("Ocorreu um erro,por favor tente novamente");
					alertify.error('Não foi possível completar o pedido, por favor tente novamente');
				//location.href="errorpage";
				}
			spinner.stop();
          }
	    });
}


function gravaharmoniorins(){
	
	
	var coddador = $("#dadorcod").text();
	var estadorimesq = $("#estadorimesq").val();
	var estadorimdir = $("#estadorimdir").val();
	
	//Inicializar vazio
	$("#rimesqcod").val("");
	$("#lblcodrimesq").text("");
	$("#rimdircod").val("");
	$("#lblcodrimdir").text("");
	
	
	if(estadorimesq!=3 && estadorimesq!=0){
	$("#rimesqcod").val(coddador+"-RE");
	$("#lblcodrimesq").text(coddador+"-RE");
	}
	if(estadorimdir!=3 && estadorimdir!=0){
	$("#rimdircod").val(coddador+"-RD");
	$("#lblcodrimdir").text(coddador+"-RD");
	}
	
	var spinner = new Spinner(opts).spin(document.getElementById('spinnergif'));
	 $.ajax({
	        url: 'gravacolheitaharmoniorins',
	        type: 'POST',
	        cache: false,
	        data: $("#formrins").serialize(),
         success: function(data, textStatus, jqXHR)
         {
        	alertify.success("Dados gravados com sucesso!");
			spinner.stop();
         },
         error: function(jqXHR, textStatus, errorThrown) 
         {
				if(textStatus=='error'){
				//	alert("Ocorreu um erro,por favor tente novamente");
					alertify.error('Não foi possível completar o pedido, por favor tente novamente');
				//location.href="errorpage";
				}
			spinner.stop();
         }
	    });	
}

function rimalteraestado(lado, estado){
	
	if(estado==1){
		var frase = "validado";
	}else if(estado==2){
		
		var frase = "condicional";
	}else if(estado==3){
		var frase = "não validado";
	}
		
		alertify.confirm("Confirma a alteração do estado do orgão para "+frase+"?", function (e) {
		    if (e) {
					var spinner = new Spinner(opts).spin(document.getElementById('spinnergif'));
					 $.ajax({
					        url: 'gravacolheitaestadorim',
					        type: 'POST',
					        cache: false,
					        data: {"lado" : lado, "estado": estado},
				         success: function(data, textStatus, jqXHR)
				         {
				        	 if(data=='OK'){
						        	 if(estado==1){
							        	 if(lado==1){
							        		 $("#divestadorimesq").html("<label style=\"color: green;\"><b>Orgão válido </b></label><img alt=\"Orgão validado\" src=\"resources/imagens/green-check.gif\" style=\"width: 20px; height: 20px; vertical-align: bottom;\">");
							        		 $("#estadorimesq").val(1);
							        	 }else{
							        		 $("#divestadorimdir").html("<label style=\"color: green;\"><b>Orgão válido </b></label><img alt=\"Orgão validado\" src=\"resources/imagens/green-check.gif\" style=\"width: 20px; height: 20px; vertical-align: bottom;\">");	 
							        		 $("#estadorimdir").val(1);
							        	 }
						        	 }else if(estado==2){
						        		 if(lado==1){
							        		 $("#divestadorimesq").html("<label style=\"color: orange;\"><b>Orgão estado condicional </b></label><img alt=\"Orgão estado condicional\" src=\"resources/imagens/warning.png\" style=\"width: 20px; height: 20px; vertical-align: bottom;\">");
							        		 $("#estadorimesq").val(2);
							        	 }else{
							        		 $("#divestadorimdir").html("<label style=\"color: orange;\"><b>Orgão estado condicional </b></label><img alt=\"Orgão estado condicional\" src=\"resources/imagens/warning.png\" style=\"width: 20px; height: 20px; vertical-align: bottom;\">");
							        		 $("#estadorimdir").val(2);
							        	 } 
						        	 }
						        	 else if(estado==3){
						        		 if(lado==1){
							        		 $("#divestadorimesq").html("<label style=\"color: red;\"><b>Orgão não válido </b></label><img alt=\"Orgão não válido\" src=\"resources/imagens/SA1.png\" style=\"width: 20px; height: 20px; vertical-align: bottom;\">");
							        		 $("#estadorimesq").val(3);
							        	 }else{
							        		 $("#divestadorimdir").html("<label style=\"color: red;\"><b>Orgão não válido </b></label><img alt=\"Orgão não válido\" src=\"resources/imagens/SA1.png\" style=\"width: 20px; height: 20px; vertical-align: bottom;\">");
							        		 $("#estadorimdir").val(3);
							        	 } 
						        	 }
						        	 
						        	 alertify.success("Estado do rim alterado com sucesso!");
				        	 }
								spinner.stop();
				         },
				         error: function(jqXHR, textStatus, errorThrown) 
				         {
								if(textStatus=='error'){
								//	alert("Ocorreu um erro,por favor tente novamente");
									alertify.error('Não foi possível completar o pedido, por favor tente novamente');
								//location.href="errorpage";
								}
							spinner.stop();
				         }
					    });	
		    } else {
		    	alertify.error("Processo cancelado");
		    }
		});
	
}


//-------------------------Inicio Tabela perfusao rins-----------------------------------------------//
function adicionaperfrins(){
	
	var perfusao = $("#regperfrinsperfusao").val();
	var tipo = $("#regperfrinstipo").val();
	//var via = $("#regperfabdomvia").val();
	var volume = $("#regperfrinsvolume").val();
	var inicio = $("#regperfrinsinicio").val();
	var fim = $("#regperfrinsfim").val();
	var qualidade = $("#regperfrinsqualidade").val();
	var lote = $("#regperfrinslote").val();
	var teste = $("#regperfrinsteste").is(":checked");
	
	
	var spinner = new Spinner(opts).spin(document.getElementById('spinnergif'));
	 $.ajax({
	        url: 'adicionaperfharmoniorins',
	        type: 'POST',
	        cache: false,
	        data: {"perfusao" : perfusao, "tipo" : tipo, "volume" : volume, "inicio" : inicio, "fim" : fim, "qualidade" : qualidade, "lote" : lote, "teste" : teste},
        success: function(data, textStatus, jqXHR)
        {
        	$("#tabperfusaorins tr:last").after(data);
        	cancelagravaperfrins();
        	
       	 alertify.success("Dados gravados com sucesso!");
				spinner.stop();
        },
        error: function(jqXHR, textStatus, errorThrown) 
        {
				if(textStatus=='error'){
				//	alert("Ocorreu um erro,por favor tente novamente");
					alertify.error('Não foi possível completar o pedido, por favor verifique se todos os campos estão preenchidos corretamente.');
				//location.href="errorpage";
				}
			spinner.stop();
        }
	    });	
}

function cancelagravaperfrins(){
	$("#divregperfrins input").val("");
	$("#divregperfrins select").val(1);
	$("#regperfrinsteste").prop('checked', false);
	$("#diveditperfrins").fadeOut(function(){
		$("#divregperfrins").fadeIn();	
	});
}

function editperfrins(idperfrins, perfusao, tipo, qualidade, teste, event){
	
	$("#editidperfrins").val(idperfrins);
	$("#editperfrinsperfusao").val(perfusao);
	$("#editperfrinstipo").val(tipo);
	//$("#editperfabdomvia").val(via);
	$("#editerfrinsvolume").val($(event).closest("tr").find('td:eq(2)').text());
	$("#editperfrinsinicio").val($(event).closest("tr").find('td:eq(3)').text());
	$("#editperfrinsfim").val($(event).closest("tr").find('td:eq(4)').text());
	$("#editperfrinsqualidade").val(qualidade);
	$("#editperfrinslote").val($(event).closest("tr").find('td:eq(6)').text());
	$("#editperfrinsteste").prop('checked', teste);

	
	$("#divregperfrins").fadeOut(function(){
		$("#diveditperfrins").fadeIn();	
	});
	
}


function gravaperfrins(){
	
	var idperfrins = 	$("#editidperfrins").val();
	var perfusao = $("#editperfrinsperfusao").val();
	var tipo = $("#editperfrinstipo").val();
	//var via = $("#editperfabdomvia").val();
	var volume = $("#editerfrinsvolume").val();
	var inicio = $("#editperfrinsinicio").val();
	var fim = $("#editperfrinsfim").val();
	var qualidade = $("#editperfrinsqualidade").val();
	var lote = $("#editperfrinslote").val();
	var teste = $("#editperfrinsteste").is(":checked");

	
	var spinner = new Spinner(opts).spin(document.getElementById('spinnergif'));
	 $.ajax({
	        url: 'gravaperfharmoniorins',
	        type: 'POST',
	        cache: false,
	        data: {"idperfrins" : idperfrins, "perfusao" : perfusao, "tipo" : tipo, "volume" : volume, "inicio" : inicio, "fim" : fim, "qualidade" : qualidade, "lote" : lote, "teste" : teste},
       success: function(data, textStatus, jqXHR)
       {
    	   
    	   
    	   //alterar linha
    	   $("#perfrins_"+idperfrins).replaceWith(data);
    	   
       //	$("#tabterapgeral tr:last").after(data);
    	   cancelagravaperfrins();
      	 alertify.success("Dados gravados com sucesso!");
				spinner.stop();
       },
       error: function(jqXHR, textStatus, errorThrown) 
       {
				if(textStatus=='error'){
				//	alert("Ocorreu um erro,por favor tente novamente");
					alertify.error('Não foi possível completar o pedido, por favor tente novamente');
				//location.href="errorpage";
				}
			spinner.stop();
       }
	    });	
}



function delperfrins(idperfrins, event){
	
	alertify.confirm("Confirma a eliminação  da perfusão "+$(event).closest("tr").find('td:eq(0)').text()+"?", function (e) {
	    if (e) {
			var spinner = new Spinner(opts).spin(document.getElementById('spinnergif'));
			$.ajax
			({
				url: 'delperfrins',
				type: 'POST',
				data:  {"idperfrins" : idperfrins},
				success: function(data, textStatus, jqXHR)
				{
					//  $("#tabcomorbilidades").html(data);
					 $("#perfrins_"+idperfrins).remove();
					 cancelagravaperfrins();
					  alertify.success('Perfusão eliminada com sucesso');
					  spinner.stop();
				},
				error: function(jqXHR, textStatus, errorThrown) 
				{
					if(textStatus=='error'){
						alertify.error('Não foi possível completar o pedido, por favor tente novamente');
					}
					  spinner.stop();
				} 
			});	
	    }
	else {
    	alertify.error("Processo de eliminação cancelado");
    }
});
	
}

//-------------------------Fim Tabela perfusao rins-----------------------------------------------//

//-------------------------Inicio Tabela terapeuticas-----------------------------------------------//

function adicionaterapeuticarins(){
	
	var terapeutica = $("#regterapeuticarins").val();
	var observacaoterap = $("#regobsterapeuticarins").val();
	
	var spinner = new Spinner(opts).spin(document.getElementById('spinnergif'));
	 $.ajax({
	        url: 'adicionaterapeuticaharmoniorins',
	        type: 'POST',
	        cache: false,
	        data: {"terapeutica" : terapeutica, "observacaoterap" : observacaoterap},
        success: function(data, textStatus, jqXHR)
        {
        	$("#tabteraprins tr:last").after(data);
        	cancelagravateraprins();
       	 alertify.success("Dados gravados com sucesso!");
				spinner.stop();
        },
        error: function(jqXHR, textStatus, errorThrown) 
        {
				if(textStatus=='error'){
				//	alert("Ocorreu um erro,por favor tente novamente");
					alertify.error('Não foi possível completar o pedido, por favor tente novamente');
				//location.href="errorpage";
				}
			spinner.stop();
        }
	    });	
}

function editteraprins(idcolheitaterapeutica, terapeutica, event){
	$("#editterapeuticarins").val(terapeutica);
	$("#editobsterapeuticarins").val($(event).closest("tr").find('td:eq(1)').text());
	$("#editidterapeuticarins").val(idcolheitaterapeutica);
	$("#divregteraprins").fadeOut(function(){
		$("#diveditteraprins").fadeIn();	
	});
	
}

function cancelagravateraprins(){
	$("#regterapeuticarins").val(1);
	$("#regobsterapeuticarins").val("");
	$("#editidterapeuticarins").val("");
	$("#diveditteraprins").fadeOut(function(){
		$("#divregteraprins").fadeIn();	
	});
}

function gravaterapeuticarins(){
	var terapeutica = 		$("#editterapeuticarins").val();
	var observacaoterap = 	$("#editobsterapeuticarins").val();
	var idcolheitaterap = 	$("#editidterapeuticarins").val();
	
	var spinner = new Spinner(opts).spin(document.getElementById('spinnergif'));
	 $.ajax({
	        url: 'gravaterapeuticaharmoniorins',
	        type: 'POST',
	        cache: false,
	        data: {"terapeutica" : terapeutica, "observacaoterap" : observacaoterap, "idcolheitaterap" : idcolheitaterap},
       success: function(data, textStatus, jqXHR)
       {
    	   
    	   
    	   //alterar linha
    	   $("#terrins_"+idcolheitaterap).replaceWith(data);
    	   
       //	$("#tabterapgeral tr:last").after(data);
       	cancelagravateraprins();
      	 alertify.success("Dados gravados com sucesso!");
				spinner.stop();
       },
       error: function(jqXHR, textStatus, errorThrown) 
       {
				if(textStatus=='error'){
				//	alert("Ocorreu um erro,por favor tente novamente");
					alertify.error('Não foi possível completar o pedido, por favor tente novamente');
				//location.href="errorpage";
				}
			spinner.stop();
       }
	    });	
}

function delteraprins(idcolheitaterap, event){
	
	alertify.confirm("Confirma a eliminação  da terapêutica "+$(event).closest("tr").find('td:eq(0)').text()+"?", function (e) {
	    if (e) {
			var spinner = new Spinner(opts).spin(document.getElementById('spinnergif'));
			$.ajax
			({
				url: 'delterapeuticarins',
				type: 'POST',
				data:  {"idcolheitaterap" : idcolheitaterap},
				success: function(data, textStatus, jqXHR)
				{
					//  $("#tabcomorbilidades").html(data);
					 $("#terrins_"+idcolheitaterap).remove();
					 cancelagravateraprins();
					  alertify.success('Terapêutica eliminada com sucesso');
					  spinner.stop();
				},
				error: function(jqXHR, textStatus, errorThrown) 
				{
					if(textStatus=='error'){
						alertify.error('Não foi possível completar o pedido, por favor tente novamente');
					}
					  spinner.stop();
				} 
			});	
	    }
	else {
    	alertify.error("Processo de eliminação cancelado");
    }
});
	
}

//-------------------------Fim Tabela terapeuticas-----------------------------------------------//

