﻿/**
 * Script Página Gerir Utilizadores
 */

$(document).ready(function() {
    $('#tabelautilizadores').dataTable(  {
        initComplete: function () {
            var api = this.api();
 
            api.columns().indexes().flatten().each( function ( i ) {
                var column = api.column( i );
                var select = $('<select style="max-width: 220px; margin:auto;"><option value=""></option></select>')
                    .appendTo( $(column.footer()).empty() )
                    .on( 'change', function () {
                        var val = $.fn.dataTable.util.escapeRegex(
                            $(this).val()
                        );
 
                        column
                            .search( val ? '^'+val+'$' : '', true, false )
                            .draw();
                    } );
 
                column.data().unique().sort().each( function ( d, j ) {
                    select.append( '<option value="'+d+'">'+d+'</option>' )
                } );
            } );
        },
		        "language": {
            "sProcessing":   "A processar...",
            "sLengthMenu":   "_MENU_ registos por página",
            "sZeroRecords":  "Não foram encontrados resultados",
            "sInfo":         "A mostrar de _START_ até _END_ de _TOTAL_ registos",
            "sInfoEmpty":    "A mostrar de 0 até 0 de 0 registos",
            "sInfoFiltered": "(a filtrar de _MAX_ registos no total)",
            "sInfoPostFix":  "",
            "sSearch":       "Pesquisar:",
            "sUrl":          "",
            "oPaginate": {
            	"sFirst":    "Primeiro",
            	"sPrevious": "Anterior",
            	"sNext":     "Seguinte",
            	"sLast":     "Último"
            }
        }
    
    
} );
   
  $("#tabelautilizadores_length").css({"borderTopWidth": "0", "borderRightWidth": "0" , "borderBottomWidth": "0", "borderLeftWidth": "0" });
  
  $('#tabelautilizadoresB').dataTable(  {
      initComplete: function () {
          var api = this.api();

          api.columns().indexes().flatten().each( function ( i ) {
              var column = api.column( i );
              var select = $('<select><option value=""></option></select>')
                  .appendTo( $(column.footer()).empty() )
                  .on( 'change', function () {
                      var val = $.fn.dataTable.util.escapeRegex(
                          $(this).val()
                      );

                      column
                          .search( val ? '^'+val+'$' : '', true, false )
                          .draw();
                  } );

              column.data().unique().sort().each( function ( d, j ) {
                  select.append( '<option value="'+d+'">'+d+'</option>' )
              } );
          } );
      },
		        "language": {
          "sProcessing":   "A processar...",
          "sLengthMenu":   "_MENU_ registos por página",
          "sZeroRecords":  "Não foram encontrados resultados",
          "sInfo":         "A mostrar de _START_ até _END_ de _TOTAL_ registos",
          "sInfoEmpty":    "A mostrar de 0 até 0 de 0 registos",
          "sInfoFiltered": "(a filtrar de _MAX_ registos no total)",
          "sInfoPostFix":  "",
          "sSearch":       "Pesquisar:",
          "sUrl":          "",
          "oPaginate": {
          	"sFirst":    "Primeiro",
          	"sPrevious": "Anterior",
          	"sNext":     "Seguinte",
          	"sLast":     "Último"
          }
      }
} );
  $("#tabelautilizadoresB_length").css({"borderTopWidth": "0", "borderRightWidth": "0" , "borderBottomWidth": "0", "borderLeftWidth": "0" });
 
} );





var opts = {
		  lines: 11, // The number of lines to draw
		  length: 30, // The length of each line
		  width: 13, // The line thickness
		  radius: 25, // The radius of the inner circle
		  corners: 1, // Corner roundness (0..1)
		  rotate: 0, // The rotation offset
		  direction: 1, // 1: clockwise, -1: counterclockwise
		  color: 'grey', // #rgb or #rrggbb or array of colors
		  speed: 1.5, // Rounds per second
		  trail: 60, // Afterglow percentage
		  shadow: true, // Whether to render a shadow
		  hwaccel: true, // Whether to use hardware acceleration
		  className: 'spinner', // The CSS class to assign to the spinner
		  zIndex: 2e9, // The z-index (defaults to 2000000000)
		  top: '50%', // Top position relative to parent
		  left: '50%' // Left position relative to parent
		};


function adicionahospital()
{
	var hospital = $('#idhospital').val();
	var utilizador = $('#utilizadoruti').val(); 
	var posicao = $('#posicaouti').val();
	
	$.ajax({
        url: 'adicionarhospital',
        type: 'POST',
        cache: false,
        data: {'hospital' : hospital, 'utilizador' : utilizador, 'posicao' : posicao},
        success: function(data, textStatus, jqXHR)
        {
			$( "#tabpermissoes" ).load( "carregatabelapermissoes", function() {
				alertify.success("Hospital adicionado com sucesso");
				spinner.stop();
			});
        },
        error: function(jqXHR, textStatus, errorThrown) 
        {
				if(textStatus=='error')
				{
					alertify.error('Não foi possível completar o pedido, por favor tente novamente');
				}
   				spinner.stop();
        }
    });
}

function filtratabela()
{
	var filtro = $('#pesquisatipo').val();
	
	if(filtro == 1)
	{
		document.getElementById("utilizadoresA").style.display = 'block';
		document.getElementById("utilizadoresB").style.display = 'none';
	}
	else
	{
		document.getElementById("utilizadoresB").style.display = 'block';
		document.getElementById("utilizadoresA").style.display = 'none';
	}
}


function abredadospassword()
{
	document.getElementById("mudapassword").style.display = 'block';
	document.getElementById("refmudapassword").style.display = 'none';
	document.getElementById("checkeditapass").value=1;
}

function abredadospasswordb()
{
	document.getElementById("mudapasswordb").style.display = 'block';
	document.getElementById("refmudapasswordb").style.display = 'none';
	document.getElementById("checkeditapassb").value=1;
}

function start()
{
	document.getElementById("dadosmestre").className = "";
	document.getElementById("utilizadores").className = "selected";
	document.getElementById("reporte").className = "";
	document.getElementById("separadorgeral").style.display = 'block';
	document.getElementById("separadordetalhe").style.display = 'none';
}


function voltaruser(filtro)
{
	
	if(filtro == 1)
	{
		document.getElementById("utilizadoresA").style.display = 'block';
		document.getElementById("separadorgeral").style.display = 'block';
		$("#separadorgeral").hide();
		document.getElementById("separadordetalhe").style.display = 'none';
		document.getElementById("separadornovouser").style.display = 'none';
		$("#separadordetalhe").empty();
		$("#separadornovouser").empty();
		$("#separadorgeral").fadeIn(500);
	}
	else
	{
		document.getElementById("separadordetalhetipob").style.display = 'none';
		document.getElementById("separadorgeral").style.display = 'block';
		$("#separadorgeral").hide();
		document.getElementById("utilizadoresB").style.display = 'block';
		$("#separadordetalhetipob").empty();
		$("#separadorgeral").fadeIn(500);
	}	
}

function changeclassSelected(element)
{
	var tab = element.id;
	
	if(tab == 'dadosmestre')
	{
		$("#separadordetalhe").empty();
		$("#separadornovouser").empty();
		$("#separadordetalhedadosmestre").empty();
		document.getElementById("dadosmestre").className = "selected";
		document.getElementById("utilizadores").className = "";
		document.getElementById("reporte").className = "";
		document.getElementById("separadorgeral").style.display = 'none';
		document.getElementById("separadordetalhe").style.display = 'none';
		document.getElementById("separadordetalhetipob").style.display = 'none';
		document.getElementById("separadornovouser").style.display = 'none';
		//document.getElementById("separadordadosmestre").style.display = 'block';
		$("#separadordadosmestre").hide();
		$("#separadordadosmestre").fadeIn(500);
		document.getElementById("separadordetalhedadosmestre").style.display = 'none';
	}
	else
	if(tab == 'utilizadores')
	{
		$("#separadordetalhe").empty();
		$("#separadornovouser").empty();
		$("#separadordetalhetipob").empty();
		document.getElementById("dadosmestre").className = "";
		document.getElementById("reporte").className = "";
		document.getElementById("utilizadores").className = "selected";
		//document.getElementById("separadorgeral").style.display = 'block';
		$("#separadorgeral").hide();
		$("#separadorgeral").fadeIn(500);
		document.getElementById("separadordetalhe").style.display = 'none';
		document.getElementById("separadornovouser").style.display = 'none';
		document.getElementById("separadordadosmestre").style.display = 'none';
		document.getElementById("separadordetalhedadosmestre").style.display = 'none';
		document.getElementById("separadordetalhetipob").style.display = 'none';
	}
	else
		if(tab == 'reporte')
		{
			$("#separadordetalhetipob").empty();
			$("#separadornovouser").empty();
			$("#separadordetalhetipob").empty();
			document.getElementById("dadosmestre").className = "";
			document.getElementById("utilizadores").className = "";
			document.getElementById("reporte").className = "selected";
			document.getElementById("separadorgeral").style.display = 'none';
			document.getElementById("separadordetalhe").style.display = 'none';
			document.getElementById("separadordadosmestre").style.display = 'none';
			document.getElementById("separadordetalhedadosmestre").style.display = 'none';
			document.getElementById("separadordetalhetipob").style.display = 'none';
		}
}

function abredetalheutilizador(id)
{
	var spinner = new Spinner(opts).spin(document.getElementById('spinnergif'));
	$.post("editautilizador", {'id' : id}, function(resposta) {
		$("#separadorgeral").fadeOut(500);
		$("#separadorgeral").hide();
			$("#separadordetalhe").hide();
			$("#separadordetalhe").html(resposta);
			$("#separadordetalhe").fadeIn(500);
			spinner.stop();
		});
	
//	document.getElementById("separadorgeral").style.display = 'none';
//	document.getElementById("separadordetalhe").style.display = 'block';
}

function abredetalheutilizadorB(id)
{
	var spinner = new Spinner(opts).spin(document.getElementById('spinnergif'));
	$.post("editautilizadorB", {'id' : id}, function(resposta) {
		$("#separadorgeral").fadeOut(500);
		$("#separadorgeral").hide();
			$("#separadordetalhetipob").hide();
			$("#separadordetalhetipob").html(resposta);
			$("#separadordetalhetipob").fadeIn(500);
			spinner.stop();
		});
	
//	document.getElementById("separadorgeral").style.display = 'none';
//	document.getElementById("separadordetalhetipob").style.display = 'block';
}

function voltar()
{
	location.href = "voltar";
//	voltaruser(1);
}

function abreformnovouser()
{
	  var spinner = new Spinner(opts).spin(document.getElementById('spinnergif'));
	  var posting = $.post("carregaformuser");
	  posting.done(function(data) {
		  $("#separadornovouser").html(data);
			//$("#separadorgeral").fadeOut(3000);
			$("#separadorgeral").hide();
		//	$("#separadordetalhe").fadeOut(500);
			//$("#separadordetalhe").hide();
			
			$("#separadornovouser").fadeIn(500);
			spinner.stop();
	  });
	  
	//document.getElementById("separadorgeral").style.display = 'none';
	document.getElementById("separadordetalhe").style.display = 'none';	  
//	document.getElementById("separadornovouser").style.display = 'block';
}

function editautilizador()
{
	
	$("#formeditarutilizador").submit(function(event) {
		 event.preventDefault();
		 event.stopImmediatePropagation();
		 
		 var passw = /^(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{6,}$/;
	if(document.getElementById("checkeditapass").value=="1") {
		if(document.getElementById("login").value.length<5) {
			alertify.error('Nome de Utilizador de sistema deve ter no minimo 5 caracteres');
		}else if(document.getElementById("senha").value!=document.getElementById("confsenha").value){
		alertify.error('Password e Confirmar Password devem corresponder');
		}else if(!($("#utilizador").val().match(/^[a-zA-ZâàáãòóôõéèíìëïçäöüÄÖÜÇ\s]*$/))){
			alertify.error('O nome de utilizador só pode conter letras');
		}else if(($("#telemovel").val()!='') &&(!($("#telemovel").val().match(/[0-9 -()+]+$/)))){
			alertify.error('O campo telemóvel só pode conter digitos');
			
		}else if(($("#telefone").val()!='') &&(!($("#telefone").val().match(/[0-9 -()+]+$/)))){
			alertify.error('O campo telefone só pode conter digitos');	
		//}else if(!(($("#senha").val().match(/[A-z]/))&&($("#senha").val().match(/[A-z]/g).length>5)&&($("#senha").val().match(/[A-Z]/))&&($("#senha").val().match(/\d/)))){
		}else if(!($("#senha").val().match(passw))){
			alertify.error('A password deve conter pelo menos 6 caracteres, 1 maiúscula e 1 digito.');
		}
		else{
			gravauser();
		    }
	}
	else{
		if(document.getElementById("login").value.length<5) {
			alertify.error('Nome de Utilizador de sistema deve ter no minimo 5 caracteres');
			//alert("Password deve ter no minimo 5 caracteres");
		}else if(!($("#utilizador").val().match(/^[a-zA-ZàáãòóôõéèíìëïâçäöüÄÖÜÇ\s]*$/))){
			alertify.error('O nome de utilizador só pode conter letras');
		}else if(($("#telemovel").val()!='') &&(!($("#telemovel").val().match(/[0-9 -()+]+$/)))){
			alertify.error('O campo telemóvel só pode conter digitos');
			
		}else if(($("#telefone").val()!='') &&(!($("#telefone").val().match(/[0-9 -()+]+$/)))){
			alertify.error('O campo telefone só pode conter digitos');
			
		}		
		else{
		gravauser();
		}
	}
	
	});
//	  e.stopImmediatePropagation();
}

function gravauser(){
	
	var id= document.getElementById("ID_Utilizador").value;
	//alert("sem pass");
	var spinner = new Spinner(opts).spin(document.getElementById('spinnergif'));
	  var posting = $.post( "gravareditarutilizador", $("#formeditarutilizador").serialize());
	  posting.done(function(data) {
			$("#utilizador_"+id).html(data);
			spinner.stop();
			alertify.success('Alteração efectuada com sucesso');
			$("#nomeutilizador").text($("#login").val());
			//alert("Alteração efectuada com sucesso");
	  });
	
	
}


function registarnovoutilizador(){
	
	//var t = document.getElementById("tabelanovoutilizador");
/*	var t = $("#tabelanovoutilizador").dataTable().fnGetFilteredNodes();
	var rows = t.rows;*/
	var valores = [];
	
	if(document.getElementById("emailnovouser").value<1){
		alertify.error('O campo email é obrigatório');
	}
	else{

   // var permissao = t.getElementsByTagName("input");
		
		 var permissao = $('input', $("#tabelanovoutilizador").dataTable().fnGetNodes());
		
		 for(var i=0; i < permissao.length; i++)
		 {
   // for (k = 0; k < permissao.length; k++)
   // {
		
        if(permissao[i].checked)
        {
         var nome = permissao[i].name;

         var valor = permissao[i].value;
 
         if(valor!=="0"){

          valores.push(nome+':'+valor);
     
        }
        }
    }
       if(valores.length==0){
    	   alertify.error('Não foram definidos locais com acessos, por favor defina posições com algum acesso de leitura ou escrita.');
       }
       else{
    	   

    var spinner = new Spinner(opts).spin(document.getElementById('spinnergif'));
    
	var email = document.getElementById("emailnovouser").value;
	var telemovel = document.getElementById("telnovouser").value;
	var pin = document.getElementById('numpin').innerHTML;
	
	 $.ajax({
	        url: 'gravapermissoes',
	        type: 'POST',
	        cache: false,
	        data: {"valores": valores, "email":email,"pin":pin, "telemovel": telemovel},
      success: function(data, textStatus, jqXHR)
      {
    	  if(data==="true"){
				alertify.success('Email enviado com sucesso');
		  }else{ 
			  alertify.error('Já existe um utilizador com esse email no sistema');
			}
		  spinner.stop();
      	
      },
      error: function(jqXHR, textStatus, errorThrown) 
      {
				if(textStatus=='error'){
					alertify.error('Não foi possível completar o pedido, por favor tente novamente');
				}
   				spinner.stop();
      }
	    });	
      }
	}
}

function editautilizadorb()
{
	$("#formeditarutilizadorb").submit(function(event) 
	{
		 event.preventDefault();
		 event.stopImmediatePropagation();

	if(document.getElementById("checkeditapassb").value==="1") 
	{
		if(document.getElementById("pin").value!=document.getElementById("confpin").value)
		{
			alertify.error('Password e Confirmar Password devem corresponder');
		}
		else 
			if(document.getElementById("pin").value.length<5) 
			{
				alertify.error('Password deve ter no minimo 5 caracteres');
			}
			else
			{
				var id= document.getElementById("id_UtilizadorB").value;
				var spinner = new Spinner(opts).spin(document.getElementById('spinnergif'));
				  var posting = $.post( "gravareditarutilizadorB", $("#formeditarutilizadorb").serialize());
				  posting.done(function(data) 
				  {
						$("#utilizadorB_"+id).html(data);
						spinner.stop();
						alertify.success('Alteração efectuada com sucesso');
						
						document.getElementById("pin").value = "";
						document.getElementById("confpin").value = "";
						document.getElementById("checkeditapassb").value = "";
				  });
			}
	}
	else{
		var id= document.getElementById("id_UtilizadorB").value;

		document.getElementById("pin").value = 99999;
		document.getElementById("confpin").value = 99999;
		
		var spinner2 = new Spinner(opts).spin(document.getElementById('spinnergif'));
		  var posting2 = $.post( "gravareditarutilizadorB", $("#formeditarutilizadorb").serialize());
		  posting2.done(function(data2) {
				$("#utilizadorB_"+id).html(data2);
				spinner2.stop();
				alertify.success('Alteração efectuada com sucesso');
				
				document.getElementById("pin").value = "";
				document.getElementById("confpin").value = "";
				document.getElementById("checkeditapassb").value = "";
		  });	
	}
	});
	//  event.stopImmediatePropagation();
}