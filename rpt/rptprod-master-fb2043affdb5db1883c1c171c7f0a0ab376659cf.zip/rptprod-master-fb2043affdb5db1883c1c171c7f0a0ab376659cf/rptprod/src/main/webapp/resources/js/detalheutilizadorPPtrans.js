$('#tabelalocalizacoesuser').dataTable(  {
    initComplete: function () {
        var api = this.api();

        api.columns().indexes().flatten().each( function ( i ) {
            var column = api.column( i );
            var select = $('<select><option value=""></option></select>')
                .appendTo( $(column.footer()).empty() )
                .on( 'change', function () {
                    var val = $.fn.dataTable.util.escapeRegex(
                        $(this).val()
                    );

                    column
                        .search( val ? '^'+val+'$' : '', true, false )
                        .draw();
                } );

            column.data().unique().sort().each( function ( d, j ) {
                select.append( '<option value="'+d+'">'+d+'</option>' )
            } );
        } );
    },
		        "language": {
        "sProcessing":   "A processar...",
        "sLengthMenu":   "_MENU_ registos por página",
        "sZeroRecords":  "Não foram encontrados resultados",
        "sInfo":         "A mostrar de _START_ até _END_ de _TOTAL_ registos",
        "sInfoEmpty":    "A mostrar de 0 até 0 de 0 registos",
        "sInfoFiltered": "(a filtrar de _MAX_ registos no total)",
        "sInfoPostFix":  "",
        "sSearch":       "Pesquisar:",
        "sUrl":          "",
        "oPaginate": {
        	"sFirst":    "Primeiro",
        	"sPrevious": "Anterior",
        	"sNext":     "Seguinte",
        	"sLast":     "Último"
        }
    }
} );




function editautilizador()
{
	$("#formeditarutilizador").submit(function(event) {
		 event.preventDefault();
		 event.stopImmediatePropagation();
		 
		 var passw = /^(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{6,}$/; 
		 
	if(document.getElementById("checkeditapass").value==="1") {
		//alert("com pass");
		 
	if(document.getElementById("senha").value!=document.getElementById("confsenha").value){
		alertify.error('Password e Confirmar Password devem corresponder');
	    	//alert("Password e Confirmar Password devem corresponder");
	}
	else if(document.getElementById("senha").value.length<5) {
		alertify.error('Password deve ter no minimo 5 caracteres');
		//alert("Password deve ter no minimo 5 caracteres");
	}else if(!($("#senha").val().match(passw))){
		alertify.error('A password deve conter pelo menos 6 caracteres, 1 maiúscula e 1 digito.');
	}
	else{
		var id= document.getElementById("ID_Utilizador").value;
		var spinner = new Spinner(opts).spin(document.getElementById('spinnergif'));
		  var posting = $.post( "gravareditarutilizador", $("#formeditarutilizador").serialize());
		  posting.done(function(data) {
				$("#utilizador_"+id).html(data);
				spinner.stop();
				alertify.success('Alteração efectuada com sucesso');
				//alert("Alteração efectuada com sucesso");
		  });
	    }
	}
	else{
		var id= document.getElementById("ID_Utilizador").value;
		//alert("sem pass");
		var spinner = new Spinner(opts).spin(document.getElementById('spinnergif'));
		  var posting = $.post( "gravareditarutilizador", $("#formeditarutilizador").serialize());
		  posting.done(function(data) {
				$("#utilizador_"+id).html(data);
				spinner.stop();
				alertify.success('Alteração efectuada com sucesso');
				//alert("Alteração efectuada com sucesso");
		  });
		
	}
	
	});
//	  e.stopImmediatePropagation();
}

function abredadospassword()
{
	document.getElementById("mudapassword").style.display = 'block';
	document.getElementById("refmudapassword").style.display = 'none';
	document.getElementById("checkeditapass").value=1;
}

function abreformnovouser()
{
	  var spinner = new Spinner(opts).spin(document.getElementById('spinnergif'));
	  var posting = $.post("carregaformuser2");
	  posting.done(function(data) {
			$("#separadornovouser").html(data);
			spinner.stop();
	  });
	  
	document.getElementById("separadordetalhe2").style.display = 'none';	  
	document.getElementById("separadornovouser").style.display = 'block';
}

function voltar2(){
	
	document.getElementById("separadordetalhe2").style.display = 'block';	  
	document.getElementById("separadornovouser").style.display = 'none';
	
}

function registarnovoutilizador(){
	

	var valores = [];
	
	if(document.getElementById("emailnovouser").value<1){
		alertify.error('O campo email é obrigatório');
	}
	else{
		 var permissao = $('input', $("#tabelanovoutilizador").dataTable().fnGetNodes());
		
		 for(var i=0; i < permissao.length; i++)
		 {

		
	        if(permissao[i].checked)
	        {
		         var nome = permissao[i].name;
		
		         var valor = permissao[i].value;
		 
		         if(valor!=="0"){
		
		        	 valores.push(nome+':'+valor);
		     
		        }
	        }
    }
       if(valores.length==0){
    	   alertify.error('Não foram definidos locais com acessos, por favor defina posições com algum acesso de leitura ou escrita.');
       }
       else{
    	   

    var spinner = new Spinner(opts).spin(document.getElementById('spinnergif'));
    
	var email = document.getElementById("emailnovouser").value;
	var telemovel = document.getElementById("telnovouser").value;
	var pin = document.getElementById('numpin').innerHTML;
	
	 $.ajax({
	        url: 'gravapermissoes',
	        type: 'POST',
	        cache: false,
	        data: {"valores": valores, "email":email,"pin":pin, "telemovel": telemovel},
      success: function(data, textStatus, jqXHR)
      {
    	  if(data==="true"){
				alertify.success('Email enviado com sucesso');
		  }else{ 
			  alertify.error('Já existe um utilizador com esse email no sistema');
			}
		  spinner.stop();
      	
      },
      error: function(jqXHR, textStatus, errorThrown) 
      {
				if(textStatus=='error'){
					alertify.error('Não foi possível completar o pedido, por favor tente novamente');
				}
   				spinner.stop();
      }
	    });	
      }
	}
}