/**
 * Script Página IPST
 */

$(document).ready(function() {
    $('#tabelafaturas').dataTable(  {
        initComplete: function () {
            var api = this.api();
 
            api.columns().indexes().flatten().each( function ( i ) {
                var column = api.column( i );
                var select = $('<select style="max-width: 45px; margin:auto;"><option value=""></option></select>')
                    .appendTo( $(column.footer()).empty() )
                    .on( 'change', function () {
                        var val = $.fn.dataTable.util.escapeRegex(
                            $(this).val()
                        );
 
                        column
                            .search( val ? '^'+val+'$' : '', true, false )
                            .draw();
                    } );
 
                column.data().unique().sort().each( function ( d, j ) {
                    select.append( '<option value="'+d+'">'+d+'</option>' )
                } );
            } );
        },
		        "language": {
            "sProcessing":   "A processar...",
            "sLengthMenu":   "_MENU_ registos por página",
            "sZeroRecords":  "Não foram encontrados resultados",
            "sInfo":         "A mostrar de _START_ até _END_ de _TOTAL_ registos",
            "sInfoEmpty":    "A mostrar de 0 até 0 de 0 registos",
            "sInfoFiltered": "(a filtrar de _MAX_ registos no total)",
            "sInfoPostFix":  "",
            "sSearch":       "Pesquisar:",
            "sUrl":          "",
            "oPaginate": {
            	"sFirst":    "Primeiro",
            	"sPrevious": "Anterior",
            	"sNext":     "Seguinte",
            	"sLast":     "Último"
            }
        }
    
    
} );
   
  $("#tabelafaturas_length").css({"borderTopWidth": "0", "borderRightWidth": "0" , "borderBottomWidth": "0", "borderLeftWidth": "0"});
} );

function filtrafaturas()
{
	if($("#semfatura").is(':checked'))
	{
		var spinner = new Spinner(opts).spin(document.getElementById('spinnergif'));
		$.ajax({
		        url: 'abrefaturasfilt',
		        type: 'POST',
		        cache: false,
	           success: function(data, textStatus, jqXHR)
	           {
	        	   $("#separadortabfaturas").html(data);
	        	   
	        	   spinner.stop();
	           },
	           error: function(jqXHR, textStatus, errorThrown) 
	           {
					if(textStatus=='error')
						alertify.error('Não foi possível completar o pedido, por favor tente novamente');
				
					spinner.stop();
	           }
		});
	}
	else
	{
		var spinner = new Spinner(opts).spin(document.getElementById('spinnergif'));
		$.ajax({
		        url: 'abrefaturas',
		        type: 'POST',
		        cache: false,
	           success: function(data, textStatus, jqXHR)
	           {
	        	   $("#separadortabfaturas").html(data);
	        	   
	        	   spinner.stop();
	           },
	           error: function(jqXHR, textStatus, errorThrown) 
	           {
					if(textStatus=='error')
						alertify.error('Não foi possível completar o pedido, por favor tente novamente');
				
					spinner.stop();
	           }
		});
	}
}

function crianovafatura()
{
	var idcomp = $("#idcomp").val();
	var numfat =  $("#numfatu").val();
	var datafat = $("#datafatura").val();
	var datapag = $("#datapagamentofatura").val();
	var notas = $("#notasfatura").val();
	var prob = $("#probfatura").is(':checked');
	var pag = $("#pagafatura").is(':checked');
	
	if(numfat.length == 0 || datafat.length == 0 || datapag.length == 0 || idcomp.length == 0)
	{
		alertify.error('Deve preencher os campos necessários');
		return;
	}

	if($("#idfat").val() > 0)
	{
		var spinner = new Spinner(opts).spin(document.getElementById('spinnergif'));

		 $.ajax({
		        url: 'editafatura',
		        type: 'POST',
		        cache: false,
		        data: {"numfat":numfat, "datafat": datafat, "datapag":datapag, "prob":prob, "pag":pag, "notas":notas, "idfat":$("#idfat").val()},
	         success: function(data, textStatus, jqXHR)
	         {
	        	 
	         	if(!($('#nome2').val()=="")){
		        	 upload2($("#id_novafatura").val());
		        	}
	        	$("#separadortabfaturas").html(data);
	        	 

	        	$("#numfatu").val("");
	        	$("#datafatura").val("");
	        	$("#datapagamentofatura").val("");
	        	$("#notasfatura").val("");
	        	$("#idcomp").val("");
	        	$("#idfat").val("");
	        	$("#nome2").val("");
	        	$("#ficheiro2").val("");

	        	$('#probfatura').prop("checked", false);
	        	$('#pagafatura').prop("checked", false);

	        	alertify.success("Fatura alterada com sucesso");
	        	
	        	spinner.stop();
	         },
	         error: function(jqXHR, textStatus, errorThrown) 
	         {
					if(textStatus=='error')
						alertify.error('Não foi possível completar o pedido, por favor tente novamente');
					spinner.stop();
	         }
		 });
	}
	else
	{
		var spinner = new Spinner(opts).spin(document.getElementById('spinnergif'));
	
		 $.ajax({
		        url: 'criafatura',
		        type: 'POST',
		        cache: false,
		        data: {"idcomp":idcomp, "numfat":numfat, "datafat": datafat, "datapag":datapag, "prob":prob, "pag":pag, "notas":notas},
	         success: function(data, textStatus, jqXHR)
	         {
	        	 	        	 
	        	$("#separadortabfaturas").html(data);
	        	
	        	if(!($('#nome2').val()=="")){
	        	 upload2($("#id_novafatura").val());
	        	}
	        	
	        	$("#numfatu").val("");
	        	$("#datafatura").val("");
	        	$("#datapagamentofatura").val("");
	        	$("#notasfatura").val("");
	        	$("#idcomp").val("");
	        	$("#idfat").val("");
	        	$("#nome2").val("");
	        	$("#ficheiro2").val("");
	        	
	        	$('#probfatura').prop("checked", false);
	        	$('#pagafatura').prop("checked", false);
	
	        	alertify.success("Fatura criada com sucesso");
	        	
	        	spinner.stop();
	         },
	         error: function(jqXHR, textStatus, errorThrown) 
	         {
					if(textStatus=='error')
						alertify.error('Não foi possível completar o pedido, por favor tente novamente');
					spinner.stop();
	         }
		 });
	}
}

function cancelanovafatura()
{
	$("#numfatu").val("");
	$("#datafatura").val("");
	$("#datapagamentofatura").val("");
	$("#notasfatura").val("");
	$("#idcomp").val("");
	$("#idfat").val("");

	$('#probfatura').prop("checked", false);
	$('#pagafatura').prop("checked", false);
}

function editacomp(id, fat, notas, paga, prob, datafat, datapag, idfat)
{
	$("#idcomp").val(id);
	$("#idfat").val(idfat);
	$("#id_novafatura").val(idfat);

	if(prob == 1)
		$('#probfatura').prop("checked", true);
	else
		$('#probfatura').prop("checked", false);
	
	if(paga == 1)
		$('#pagafatura').prop("checked", true);
	else
		$('#pagafatura').prop("checked", false);
		
	if(fat != 0)
		$("#numfatu").val(fat);
	else
		$("#numfatu").val("");

	if(notas.length > 0)
		$("#notasfatura").val(notas);
	else
		$("#notasfatura").val("");
	
	$("#datafatura").val(datafat);
	$("#datapagamentofatura").val(datapag);
}

//------------------------------------UPLOAD---------------------------//

function alterafile2(){
	
	//atualizar input nome ficheiro para possibilitar escolher nome
	var n = $('#ficheiro2').val().replace(/C:\\fakepath\\/i, '');
	var nome = n.replace(/[^a-z0-9.\s]/gi, '').replace(/[_\s]/g, ' ');
	$('#nome2').val(nome);
}

function upload2(id_fatura){
	
	$("#id_fatura").val(id_fatura);
	$("#cod_fatura").val($("#numfatu").val());
	
//	alert("idfatura: "+id_fatura+", codfatura: "+ $("#numfatu").val());
	function getDoc(frame) {
	     var doc = null;
	 
	     // IE8 verificação do acesso em cascata
	     try {
	         if (frame.contentWindow) {
	             doc = frame.contentWindow.document;
	         }
	     } catch(err) {
	     }
	 
	     if (doc) { // conteudo obtido com sucesso
	         return doc;
	     }
	 
	     try { 
	         doc = frame.contentDocument ? frame.contentDocument : frame.document;
	     } catch(err) {
	         // ultima tentativa
	         doc = frame.document;
	     }
	     return doc;
	 }
	$("#enviarficheirofatura").submit(function(e)
	{
	 
	    var formObj = $(this);
	    var formURL = formObj.attr("action");
	 
	    if(window.FormData !== undefined)  // para browsers HTML5
	    {
	    	var spinner = new Spinner(opts).spin(document.getElementById('spinnergif'));
	        var formData = new FormData(this);
	        $.ajax({
	            url: formURL,
	            type: 'POST',
	            data:  formData,
	            mimeType:"multipart/form-data",
	            contentType: false,
	            cache: false,
	            processData:false,
	            success: function(data, textStatus, jqXHR)
	            {
	 				alertify.success(data);
/*	 				$.post("carreganomedocfatura", {'id_fatura' : id_fatura}, function(resposta) {
	 					$("#caminhodocfatura").html(resposta);
	 					spinner.stop();
	 				});*/
	            },
	            error: function(jqXHR, textStatus, errorThrown) 
	            {
	 				if(textStatus=='error'){
	 				//	alert("Ocorreu um erro,por favor tente novamente");
	 					alertify.error('Não foi possível completar o pedido, por favor tente novamente');
	 				//location.href="errorpage";
	 				}
	 				spinner.stop();
	            }           
	       });
	        e.preventDefault();
	        //e.unbind(); // não usar, antes o stopImmediatePropagation()
	        e.stopImmediatePropagation();
	   }
	   else  //para browsers antigos
	    {
	        //gerar um id aleatório
	        var  iframeId = 'unique' + (new Date().getTime());
	 
	        //criar um iframe vazio
	        var iframe = $('<iframe src="javascript:false;" name="'+iframeId+'" />');
	 
	        //esconder o iframe
	        iframe.hide();
	 
	        //definir o alvo do form para o iframe
	        formObj.attr('target',iframeId);
	 
	        //Adicionar o iframe ao body
	        iframe.appendTo('body');
	        iframe.load(function(e)
	        {
	            var doc = getDoc(iframe[0]);
	            var docRoot = doc.body ? doc.body : doc.documentElement;
	            var data = docRoot.innerHTML;
	            //dados do servidor server.
	 
	        });
	 
	    }     
	});
	$("#enviarficheirofatura").submit();
	
	

}