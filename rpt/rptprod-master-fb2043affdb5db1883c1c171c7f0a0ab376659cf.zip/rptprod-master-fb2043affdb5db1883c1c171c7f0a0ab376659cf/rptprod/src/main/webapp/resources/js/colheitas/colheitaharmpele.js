function registahoraspele(tipo){
	
	var spinner = new Spinner(opts).spin(document.getElementById('spinnergif'));
	 $.ajax({
	        url: 'registahoraspele',
	        type: 'POST',
	        cache: false,
	        data:  {"tipo" : tipo},
          success: function(data, textStatus, jqXHR)
          {
        	  var d = Date.parse(data).toString('dd/MM/yyyy HH:mm');
        	  
        	  if(tipo==1){
        		  $("#iniciopele").html(d);    
        	  }else if(tipo==2){
        		  $("#fimpele").html(d);	  
        	  }
				spinner.stop();
          },
          error: function(jqXHR, textStatus, errorThrown) 
          {

				alertify.error('Não foi possível completar o pedido, por favor tente novamente');
				spinner.stop();
          }
	    });
}

function gravaharmoniopele(){
	
	var coddador = $("#dadorcod").text();
	
	var totalpele = $("#totalpele").val();
	
	if(totalpele>0){
	$("#pelecod").val(coddador+"-PEL");
	}else{
		$("#pelecod").val("");	
	}
	
	$("#tabelapele tr td:nth-child(3)").each(function(index, value){		
			if($(this).find('input').val()==''){
				$(this).find('input').val(0);
			}
});
		
		
	
	
	
	var spinner = new Spinner(opts).spin(document.getElementById('spinnergif'));
	 $.ajax({
	        url: 'gravacolheitaharmoniopele',
	        type: 'POST',
	        cache: false,
	        data: $("#formpele").serialize(),
         success: function(data, textStatus, jqXHR)
         {
        		if(totalpele>0){
        			 $("#lblcodpele").text(coddador+"-PEL");
        		}else{
        			$("#lblcodpele").text("");
        		}
        	 alertify.success("Dados gravados com sucesso!");
				spinner.stop();
         },
         error: function(jqXHR, textStatus, errorThrown) 
         {
				if(textStatus=='error'){
				//	alert("Ocorreu um erro,por favor tente novamente");
					alertify.error('Não foi possível completar o pedido, por favor tente novamente');
				//location.href="errorpage";
				}
			spinner.stop();
         }
	    });	
}