/**
 * 
 */

var opts = {
		  lines: 11, // The number of lines to draw
		  length: 30, // The length of each line
		  width: 13, // The line thickness
		  radius: 25, // The radius of the inner circle
		  corners: 1, // Corner roundness (0..1)
		  rotate: 0, // The rotation offset
		  direction: 1, // 1: clockwise, -1: counterclockwise
		  color: 'grey', // #rgb or #rrggbb or array of colors
		  speed: 1.5, // Rounds per second
		  trail: 60, // Afterglow percentage
		  shadow: true, // Whether to render a shadow
		  hwaccel: true, // Whether to use hardware acceleration
		  className: 'spinner', // The CSS class to assign to the spinner
		  zIndex: 2e9, // The z-index (defaults to 2000000000)
		  top: '50%', // Top position relative to parent
		  left: '50%' // Left position relative to parent
		};

function buscardadoslaboratorio()
{
	alert("Em desenvolvimento");
	
	//DEPOIS DE CONSULTAR COLOCAR STATUS DO HARMONIO COMO PREENCHIDO SINALÉTICA
	
}

function salvarimunologia()
{
	var spinner = new Spinner(opts).spin(document.getElementById('spinnergif'));

	var aum =$('#a1').val();
	var adois =$('#a2').val();
	var bum =$('#b1').val();
	var bdois =$('#b2').val();
	var cum =$('#c1').val();
	var cdois =$('#c2').val();
	var drum =$('#dr1').val();
	var drdois =$('#dr2').val();
	var dqum =$('#dq1').val();
	var dqdois =$('#dq2').val();

	$.ajax({
        url: 'salvarimunologia',
        type: 'POST',
        cache: false,
        data: {"aum" : aum, "adois" : adois, "bum" : bum, "bdois" : bdois, "cum" : cum, "cdois" : cdois, "drum" : drum, "drdois" : drdois, "dqum" : dqum, "dqdois"  :dqdois},
        success: function(data, textStatus, jqXHR)
        {
        	$("#statusimuno").attr("src","resources/imagens/green-check.gif");
        	alertify.success('Dados gravados com sucesso');
			spinner.stop();
        },
        error: function(jqXHR, textStatus, errorThrown) 
        {
				if(textStatus=='error')
				{
					alertify.error('Não foi possível completar o pedido, por favor tente novamente');
				}
   				spinner.stop();
        }
    });	
}