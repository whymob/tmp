$(document).ready(function () {
    var charReg = /^\s*[a-zA-Z0-9,.\s]+\s*$/;
    $(".warning2").hide();
    $('#nomerenal').keyup(function () {
        var inputVal = $(this).val();
        if (!charReg.test(inputVal)) {
            $(this).parent().find(".warning2").show();
        } else {
            $(this).parent().find(".warning2").hide();
        }

    });
    
    
    
    //tamanho do ficheiro para upload
    $("#ficheirorenal").change(function (){
    		     var iSize = ($("#ficheirorenal")[0].files[0].size / 1024);
    		     if (iSize / 1024 > 1)
    		     {
    		        if (((iSize / 1024) / 1024) > 1)
    		        {
    		            iSize = (Math.round(((iSize / 1024) / 1024) * 100) / 100);
    		            $("#lbltamanhorenal").html( iSize + "Gb");
    		        }
    		        else
    		        {
    		            iSize = (Math.round((iSize / 1024) * 100) / 100)
    		            if(iSize<=10){
    		            	$("#lbltamanhorenal").html( iSize + "Mb");
    		            }else{
    		            	$("#lbltamanhorenal").html( iSize + "Mb");
    		        		alertify.error('O ficheiro escolhido excede o limite de 10Mb, por favor escolha um ficheiro dentro do limite imposto');	
    		            }
    		        }
    		     }
    		     else
    		     {
    		        iSize = (Math.round(iSize * 100) / 100)
    		        $("#lbltamanhorenal").html( iSize  + "kb");
    		     }   
    });
    
    
    
    
});



function gravarbiopsiarenal(){

	var d=  new Date(Date.parse($("#databiopsiarenal").val())).toString('dd/MM/yyyy, HH:mm:ss');
	$("#data").val(d);
	
	if($("#formbiorenal").validate({
		rules:{
			dimensaoesq: {
			      digits: true
		    },
			dimensaodir: {
			      digits: true
		    },
		},
		  ignore: ".ignore",
		  messages: {

			  dimensaoesq: {
				    	digits: "<font color=\"red\">O campo dimensão só permite digitos</font>",
					    },
			  dimensaodir: {
			    	digits: "<font color=\"red\">O campo dimensão só permite digitos</font>",
			    },
			  },
		errorLabelContainer: '#errosdetalhebiorenal',
		wrapper: "li"
		}).form()){
	
	var spinner = new Spinner(opts).spin(document.getElementById('spinnergif'));
	
	 $.ajax({
	        url: 'gravarbiopsiarenal',
	        type: 'POST',
	        cache: false,
	        data: $("#formbiorenal").serialize(),
          success: function(data, textStatus, jqXHR)
          {
        	  $("#statusbiorenal").attr("src","resources/imagens/green-check.gif");
        	  alertify.success('Biópsia Renal guardada com sucesso.');
				spinner.stop();
          },
          error: function(jqXHR, textStatus, errorThrown) 
          {
				if(textStatus=='error'){
					alertify.error('Não foi possível gravar a biopsia, por favor tente de novo mais tarde');
				}
				spinner.stop();
          }
	    });	
	}else{
		alertify.error('Existem campos que não passaram nas validações de dados, por favor confirme os dados.');
	}
}


function eliminarbiorenal(iditem, event){
	

	var item = ""+$(event).closest("tr").find('td:eq(0)').text();
	alertify.confirm("Confirma a eliminação  do Item "+item+" da Biópsia Renal?", function (e) {
	    if (e) {
	    	
	    
	var spinner = new Spinner(opts).spin(document.getElementById('spinnergif'));
	
	 $.ajax({
	        url: 'removerbiopsiarenalitem',
	        type: 'POST',
	        cache: false,
	        data: {"iditem": iditem},
         success: function(data, textStatus, jqXHR)
         {
       	  alertify.success('Biópsia Renal removida com sucesso.');
       	  $("#biorenalitem_"+iditem).remove();
       	 $("#biorenalitem_"+iditem).remove();
				spinner.stop();
         },
         error: function(jqXHR, textStatus, errorThrown) 
         {
				if(textStatus=='error'){
					alertify.error('Não foi possível remover o item, por favor tente de novo mais tarde');
				}
				spinner.stop();
         }
	    });	
	 } else {
	    	alertify.error("Processo de eliminação cancelado");
	    }
	});	
	
}

function adicionartabbiorenalesq(){
	
	
//	alert("adicionar esquerdo");
	var item = $("#regitembiorenalesq").val();
    var qtd = $("#regqtdbiorenalesq").val();
    
	var spinner = new Spinner(opts).spin(document.getElementById('spinnergif'));
	
	 $.ajax({
	        url: 'adicionarbiopsiarenalitem',
	        type: 'POST',
	        cache: false,
	        data: {"item": item, "qtd":qtd, "diresq":false},
        success: function(data, textStatus, jqXHR)
        {
        	 $("#tabbiorenalitemesq").replaceWith(data);
      	  alertify.success('Item adicionado com sucesso.');
				spinner.stop();
        },
        error: function(jqXHR, textStatus, errorThrown) 
        {
				if(textStatus=='error'){
					alertify.error('Não foi possível adicionar o item, por favor tente de novo mais tarde');
				}
				spinner.stop();
        }
	    });
	
}


function adicionartabbiorenaldir(){
	
	
//	alert("adicionar direito");
	var item = $("#regitembiorenaldir").val();
    var qtd = $("#regqtdbiorenaldir").val();
    
	var spinner = new Spinner(opts).spin(document.getElementById('spinnergif'));
	
	 $.ajax({
	        url: 'adicionarbiopsiarenalitem',
	        type: 'POST',
	        cache: false,
	        data: {"item": item, "qtd":qtd, "diresq":true},
       success: function(data, textStatus, jqXHR)
       {
    	   $("#tabbiorenalitemdir").replaceWith(data);
     	  alertify.success('Item adicionado com sucesso.');
				spinner.stop();
       },
       error: function(jqXHR, textStatus, errorThrown) 
       {
				if(textStatus=='error'){
					alertify.error('Não foi possível adicionar o item, por favor tente de novo mais tarde');
				}
				spinner.stop();
       }
	    });
	
}

function uploadrenal(){
	
	if($('#nomerenal').val()==""){
			alertify.error('É necessário seleccionar um ficheiro');	
	}else{
	
	
	function getDoc(frame) {
	     var doc = null;
	 
	     // IE8 verificação do acesso em cascata
	     try {
	         if (frame.contentWindow) {
	             doc = frame.contentWindow.document;
	         }
	     } catch(err) {
	     }
	 
	     if (doc) { // conteudo obtido com sucesso
	         return doc;
	     }
	 
	     try { 
	         doc = frame.contentDocument ? frame.contentDocument : frame.document;
	     } catch(err) {
	         // ultima tentativa
	         doc = frame.document;
	     }
	     return doc;
	 }
	$("#enviarficheirorenal").submit(function(e)
	{
	 
	    var formObj = $(this);
	    var formURL = formObj.attr("action");
	 
	    if(window.FormData !== undefined)  // para browsers HTML5
	    {
	    	var spinner = new Spinner(opts).spin(document.getElementById('spinnergif'));
	        var formData = new FormData(this);
	        $.ajax({
	            url: formURL,
	            type: 'POST',
	            data:  formData,
	            mimeType:"multipart/form-data",
	            contentType: false,
	            cache: false,
	            processData:false,
	            success: function(data, textStatus, jqXHR)
	            {
	 				alertify.success(data);
	 				var id_biorenal = $('#id_renal').val();
	 				$.post("carreganomedocbiorenal", {'id_biorenal' : id_biorenal}, function(resposta) {
	 					$("#caminhodocbiorenal").html(resposta);
	 					spinner.stop();
	 				});
	            },
	            error: function(jqXHR, textStatus, errorThrown) 
	            {
	 				if(textStatus=='error'){
	 				//	alert("Ocorreu um erro,por favor tente novamente");
	 					alertify.error('Não foi possível completar o pedido, por favor tente novamente');
	 				//location.href="errorpage";
	 				}
	 				spinner.stop();
	            }           
	       });
	        e.preventDefault();
	        //e.unbind(); // não usar, antes o stopImmediatePropagation()
	        e.stopImmediatePropagation();
	   }
	   else  //para browsers antigos
	    {
	        //gerar um id aleatório
	        var  iframeId = 'unique' + (new Date().getTime());
	 
	        //criar um iframe vazio
	        var iframe = $('<iframe src="javascript:false;" name="'+iframeId+'" />');
	 
	        //esconder o iframe
	        iframe.hide();
	 
	        //definir o alvo do form para o iframe
	        formObj.attr('target',iframeId);
	 
	        //Adicionar o iframe ao body
	        iframe.appendTo('body');
	        iframe.load(function(e)
	        {
	            var doc = getDoc(iframe[0]);
	            var docRoot = doc.body ? doc.body : doc.documentElement;
	            var data = docRoot.innerHTML;
	            //dados do servidor server.
	 
	        });
	 
	    }     
	});
	$("#enviarficheirorenal").submit();
	}
	
}

function alterafilerenal(){
	
	//atualizar input nome ficheiro para possibilitar escolher nome
	var n = $('#ficheirorenal').val().replace(/C:\\fakepath\\/i, '');
	var nome = n.replace(/[^a-z0-9.\s]/gi, '').replace(/[_\s]/g, ' ');
	$('#nomerenal').val(nome);
}