/**
 * Script Página Avaliacao
 */

$(document).ready(function() {
    var date = new Date();

    var day = date.getDate();
    var month = date.getMonth() + 1;
    var year = date.getFullYear();

    if (month < 10) month = "0" + month;
    if (day < 10) day = "0" + day;

    var today = year + "-" + month + "-" + day;       
    $("#Data").attr("value", today);
	$("#datahora1m1p").attr("value", today);
	$("#datahora2m1p").attr("value", today);
	$("#datahora1m2p").attr("value", today);
	$("#datahora2m2p").attr("value", today);
	$("#DataGasimetria").attr("value", today);
	$("#DataTerapeuticas").attr("value", today);
});

function start()
{
	document.getElementById("avaliacao").className = "selected";
	document.getElementById("basedador").className = "selected";
	document.getElementById("harmonioshclinica").style.display = 'none';
	document.getElementById("harmoniosanalises").style.display = 'none';
	document.getElementById("harmoniosexames").style.display = 'none';
	document.getElementById("harmoniosmortecerebral").style.display = 'none';
	document.getElementById("harmoniosavainicial").style.display = 'block';
	document.getElementById("harmoniosterapeuticas").style.display = 'none';
	
	novahemodiluicao();
}

function calculohemodiluicao()
{
	if(2 == 1)
	{
		alert("Amostra válida!");
	}
	else
	{
		alert("Amostra não válida!");
		
		if (confirm("Tem amostras anteriores à transfusão?") == true) 
		{
			alert("Utilizar amostra para virologia");
		}
		else 
		{
			alert("Mensagem");
		}
	}
}

function apagahemodiluicao()
{
	$('#tabelahemodiluicao tbody').remove();
	novahemodiluicao();
}

function novahemodiluicao()
{
	$("#tabelahemodiluicao").css("background-color", "#eeece1");
	$("#tabelahemodiluicao").append("<tr>"+"<td><span>Concentrado eritrocitário</span></td>"+"<td><span>A</span></td>"+"<td><span>48</span></td>"+"<td><input type='text'/></td>"+"<td><input type='number'/></td>"+"<td><span></span></td>"+"</tr>");
	$("#tabelahemodiluicao").append("<tr>"+"<td><span>Sangue total</span></td>"+"<td><span>A</span></td>"+"<td><span>48</span></td>"+"<td><input type='text'/></td>"+"<td><input type='number'/></td>"+"<td><span></span></td>"+"</tr>");
	$("#tabelahemodiluicao").append("<tr>"+"<td><span>Reconstituted Blood</span></td>"+"<td><span>A</span></td>"+"<td><span>48</span></td>"+"<td><input type='text'/></td>"+"<td><input type='number'/></td>"+"<td><span></span></td>"+"</tr>");
	$("#tabelahemodiluicao").append("<tr>"+"<td><span>Dextranos</span></td>"+"<td><span>B</span></td>"+"<td><span>48</span></td>"+"<td><input type='text'/></td>"+"<td><input type='number'/></td>"+"<td><span></span></td>"+"</tr>");
	$("#tabelahemodiluicao").append("<tr>"+"<td><span>Plasmas</span></td>"+"<td><span>B</span></td>"+"<td><span>48</span></td>"+"<td><input type='text'/></td>"+"<td><input type='number'/></td>"+"<td><span></span></td>"+"</tr>");
	$("#tabelahemodiluicao").append("<tr>"+"<td><span>Plaquetas</span></td>"+"<td><span>B</span></td>"+"<td><span>48</span></td>"+"<td><input type='text'/></td>"+"<td><input type='number'/></td>"+"<td><span></span></td>"+"</tr>");
	$("#tabelahemodiluicao").append("<tr>"+"<td><span>Albumina</span></td>"+"<td><span>B</span></td>"+"<td><span>48</span></td>"+"<td><input type='text'/></td>"+"<td><input type='number'/></td>"+"<td><span></span></td>"+"</tr>");
	$("#tabelahemodiluicao").append("<tr>"+"<td><span>Outros</span></td>"+"<td><span>B</span></td>"+"<td><span>48</span></td>"+"<td><input type='text'/></td>"+"<td><input type='number'/></td>"+"<td><span></span></td>"+"</tr>");
}

function changeclassSelected(element)
{
	var tab = element.id;
	
	if(tab == 'avaliacao')
	{
		document.getElementById("avaliacao").className = "selected";
		document.getElementById("referenciar").className = "";
		document.getElementById("reports").className = "";
	}
	else
	if(tab == 'referenciar')
	{
		document.getElementById("avaliacao").className = "";
		document.getElementById("referenciar").className = "selected";
		document.getElementById("reports").className = "";
	}
	else
	if(tab == 'reports')
	{
		document.getElementById("avaliacao").className = "";
		document.getElementById("referenciar").className = "";
		document.getElementById("reports").className = "selected";
	}
}

function changeclassSelected2(element)
{
	var tab = element.id;
	
	if(tab == 'basedador')
	{
		document.getElementById("historial").className = "";
		document.getElementById("mortecerebral").className = "";
		document.getElementById("analises").className = "";
		document.getElementById("eventos").className = "";
		document.getElementById("mcdt").className = "";
		document.getElementById("basedador").className = "selected";
		document.getElementById("terapeuticas").className = "";
		document.getElementById("harmonioshclinica").style.display = 'none';
		document.getElementById("harmoniosanalises").style.display = 'none';
		document.getElementById("harmoniosmortecerebral").style.display = 'none';
		document.getElementById("harmoniosavainicial").style.display = 'block';
		document.getElementById("harmoniosexames").style.display = 'none';
		document.getElementById("harmoniosterapeuticas").style.display = 'none';
	}
	else
	if(tab == 'historial')
	{
		document.getElementById("mortecerebral").className = "";
		document.getElementById("analises").className = "";
		document.getElementById("eventos").className = "";
		document.getElementById("mcdt").className = "";
		document.getElementById("terapeuticas").className = "";
		document.getElementById("basedador").className = "";
		document.getElementById("historial").className = "selected";
		document.getElementById("harmonioshclinica").style.display = 'block';
		document.getElementById("harmoniosanalises").style.display = 'none';
		document.getElementById("harmoniosavainicial").style.display = 'none';
		document.getElementById("harmoniosexames").style.display = 'none';
		document.getElementById("harmoniosmortecerebral").style.display = 'none';
		document.getElementById("harmoniosterapeuticas").style.display = 'none';
	}
	else
	if(tab == 'mortecerebral')
	{
		document.getElementById("basedador").className = "";
		document.getElementById("historial").className = "";
		document.getElementById("mortecerebral").className = "selected";
		document.getElementById("analises").className = "";
		document.getElementById("mcdt").className = "";
		document.getElementById("terapeuticas").className = "";
		document.getElementById("eventos").className = "";
		document.getElementById("harmonioshclinica").style.display = 'none';
		document.getElementById("harmoniosanalises").style.display = 'none';
		document.getElementById("harmoniosavainicial").style.display = 'none';
		document.getElementById("harmoniosexames").style.display = 'none';
		document.getElementById("harmoniosmortecerebral").style.display = 'block';
		document.getElementById("harmoniosterapeuticas").style.display = 'none';
	}
	else
	if(tab == 'analises')
	{
		document.getElementById("basedador").className = "";
		document.getElementById("historial").className = "";
		document.getElementById("mortecerebral").className = "";
		document.getElementById("analises").className = "selected";
		document.getElementById("mcdt").className = "";
		document.getElementById("terapeuticas").className = "";
		document.getElementById("eventos").className = "";
		document.getElementById("harmonioshclinica").style.display = 'none';
		document.getElementById("harmoniosanalises").style.display = 'block';
		document.getElementById("harmoniosavainicial").style.display = 'none';
		document.getElementById("harmoniosexames").style.display = 'none';
		document.getElementById("harmoniosmortecerebral").style.display = 'none';
		document.getElementById("harmoniosterapeuticas").style.display = 'none';
	}
	else
	if(tab == 'mcdt')
	{
		document.getElementById("basedador").className = "";
		document.getElementById("historial").className = "";
		document.getElementById("mortecerebral").className = "";
		document.getElementById("analises").className = "";
		document.getElementById("terapeuticas").className = "";
		document.getElementById("eventos").className = "";
		document.getElementById("mcdt").className = "selected";
		document.getElementById("harmonioshclinica").style.display = 'none';
		document.getElementById("harmoniosanalises").style.display = 'none';
		document.getElementById("harmoniosavainicial").style.display = 'none';
		document.getElementById("harmoniosexames").style.display = 'block';
		document.getElementById("harmoniosmortecerebral").style.display = 'none';
		document.getElementById("harmoniosterapeuticas").style.display = 'none';
	}
	else
	if(tab == 'terapeuticas')
	{
		document.getElementById("basedador").className = "";
		document.getElementById("historial").className = "";
		document.getElementById("mortecerebral").className = "";
		document.getElementById("analises").className = "";
		document.getElementById("mcdt").className = "";
		document.getElementById("eventos").className = "";
		document.getElementById("terapeuticas").className = "selected";
		document.getElementById("harmonioshclinica").style.display = 'none';
		document.getElementById("harmoniosanalises").style.display = 'none';
		document.getElementById("harmoniosavainicial").style.display = 'none';
		document.getElementById("harmoniosexames").style.display = 'none';
		document.getElementById("harmoniosmortecerebral").style.display = 'none';
		document.getElementById("harmoniosterapeuticas").style.display = 'block';
		
	}
	else
	if(tab == 'eventos')
	{
		document.getElementById("basedador").className = "";
		document.getElementById("historial").className = "";
		document.getElementById("mortecerebral").className = "";
		document.getElementById("analises").className = "";
		document.getElementById("mcdt").className = "";
		document.getElementById("terapeuticas").className = "";
		document.getElementById("eventos").className = "selected";
		document.getElementById("harmonioshclinica").style.display = 'none';
		document.getElementById("harmoniosanalises").style.display = 'none';
		document.getElementById("harmoniosavainicial").style.display = 'none';
		document.getElementById("harmoniosmortecerebral").style.display = 'none';
		document.getElementById("harmoniosexames").style.display = 'none';
		document.getElementById("harmoniosterapeuticas").style.display = 'none';
	}
}

jQuery(document).ready(function() 
{
jQuery("#d").click(function() 
{
jQuery("#funcorgao").toggle("fast");
jQuery("#u").toggle();
jQuery("#d").toggle();
});

jQuery("#u").click(function() 
{
jQuery("#funcorgao").toggle("fast");
jQuery("#d").toggle();
jQuery("#u").toggle();
});

jQuery("#d2").click(function() 
{
jQuery("#microbiologia").toggle("fast");
jQuery("#u2").toggle();
jQuery("#d2").toggle();
});

jQuery("#u2").click(function() 
{
jQuery("#microbiologia").toggle("fast");
jQuery("#d2").toggle();
jQuery("#u2").toggle();
});

jQuery("#d3").click(function() 
{
jQuery("#viro").toggle("fast");
jQuery("#u3").toggle();
jQuery("#d3").toggle();
});

jQuery("#u3").click(function() 
{
jQuery("#viro").toggle("fast");
jQuery("#d3").toggle();
jQuery("#u3").toggle();
});

jQuery("#d4").click(function() 
{
jQuery("#imunologia").toggle("fast");
jQuery("#u4").toggle();
jQuery("#d4").toggle();
});

jQuery("#u4").click(function() 
{
jQuery("#imunologia").toggle("fast");
jQuery("#d4").toggle();
jQuery("#u4").toggle();
});

jQuery("#d5").click(function() 
{
jQuery("#grupos").toggle("fast");
jQuery("#u5").toggle();
jQuery("#d5").toggle();
});

jQuery("#u5").click(function() 
{
jQuery("#grupos").toggle("fast");
jQuery("#d5").toggle();
jQuery("#u5").toggle();
});

jQuery("#d11").click(function() 
{
jQuery("#examefisico").toggle("fast");
jQuery("#u11").toggle();
jQuery("#d11").toggle();
});

jQuery("#u11").click(function() 
{
jQuery("#examefisico").toggle("fast");
jQuery("#d11").toggle();
jQuery("#u11").toggle();
});

jQuery("#d12").click(function() 
{
jQuery("#geral").toggle("fast");
jQuery("#u12").toggle();
jQuery("#d12").toggle();
});

jQuery("#u12").click(function() 
{
jQuery("#geral").toggle("fast");
jQuery("#d12").toggle();
jQuery("#u12").toggle();
});

jQuery("#d13").click(function() 
{
jQuery("#doencprexistentes").toggle("fast");
jQuery("#u13").toggle();
jQuery("#d13").toggle();
});

jQuery("#u13").click(function() 
{
jQuery("#doencprexistentes").toggle("fast");
jQuery("#d13").toggle();
jQuery("#u13").toggle();
});

jQuery("#d14").click(function() 
{
jQuery("#sitrisco").toggle("fast");
jQuery("#u14").toggle();
jQuery("#d14").toggle();
});

jQuery("#u14").click(function() 
{
jQuery("#sitrisco").toggle("fast");
jQuery("#d14").toggle();
jQuery("#u14").toggle();
});

jQuery("#d16").click(function() 
{
jQuery("#avainicial").toggle("fast");
jQuery("#u16").toggle();
jQuery("#d16").toggle();
});

jQuery("#u16").click(function() 
{
jQuery("#avainicial").toggle("fast");
jQuery("#d16").toggle();
jQuery("#u16").toggle();
});

jQuery("#d17").click(function() 
{
jQuery("#orgaos").toggle("fast");
jQuery("#u17").toggle();
jQuery("#d17").toggle();
});

jQuery("#u17").click(function() 
{
jQuery("#orgaos").toggle("fast");
jQuery("#d17").toggle();
jQuery("#u17").toggle();
});

jQuery("#d18").click(function() 
{
jQuery("#fichapessoaldador").toggle("fast");
jQuery("#u18").toggle();
jQuery("#d18").toggle();
});

jQuery("#u18").click(function() 
{
jQuery("#fichapessoaldador").toggle("fast");
jQuery("#d18").toggle();
jQuery("#u18").toggle();
});

jQuery("#d19").click(function() 
{
jQuery("#outrosexamesespecificos").toggle("fast");
jQuery("#u19").toggle();
jQuery("#d19").toggle();
});

jQuery("#u19").click(function() 
{
jQuery("#outrosexamesespecificos").toggle("fast");
jQuery("#d19").toggle();
jQuery("#u19").toggle();
});

jQuery("#d20").click(function() 
{
jQuery("#gasimetriaeventilacao").toggle("fast");
jQuery("#u20").toggle();
jQuery("#d20").toggle();
});

jQuery("#u20").click(function() 
{
jQuery("#gasimetriaeventilacao").toggle("fast");
jQuery("#d20").toggle();
jQuery("#u20").toggle();
});

jQuery("#d30").click(function() 
{
jQuery("#transfusao").toggle("fast");
jQuery("#u30").toggle();
jQuery("#d30").toggle();
});

jQuery("#u30").click(function() 
{
jQuery("#transfusao").toggle("fast");
jQuery("#d30").toggle();
jQuery("#u30").toggle();
});

jQuery("#d31").click(function() 
{
jQuery("#divterapeuticas").toggle("fast");
jQuery("#u31").toggle();
jQuery("#d31").toggle();
});

jQuery("#u31").click(function() 
{
jQuery("#divterapeuticas").toggle("fast");
jQuery("#d31").toggle();
jQuery("#u31").toggle();
});
});