$(document).ready(function() {
    $('#tabelaorgaos').dataTable(  {
        initComplete: function () {
            var api = this.api();
 
            api.columns().indexes().flatten().each( function ( i ) {
                var column = api.column( i );
                var select = $('<select style="max-width: 180px;"><option value=""></option></select>')
                    .appendTo( $(column.footer()).empty() )
                    .on( 'change', function () {
                        var val = $.fn.dataTable.util.escapeRegex(
                            $(this).val()
                        );
 
                        column
                            .search( val ? '^'+val+'$' : '', true, false )
                            .draw();
                    } );
 
                column.data().unique().sort().each( function ( d, j ) {
                    select.append( '<option  value="'+d+'">'+d+'</option>' )
                } );
            } );
        },
		        "language": {
            "sProcessing":   "A processar...",
            "sLengthMenu":   "_MENU_ registos por página",
            "sZeroRecords":  "Não foram encontrados resultados",
            "sInfo":         "A mostrar de _START_ até _END_ de _TOTAL_ registos",
            "sInfoEmpty":    "A mostrar de 0 até 0 de 0 registos",
            "sInfoFiltered": "(a filtrar de _MAX_ registos no total)",
            "sInfoPostFix":  "",
            "sSearch":       "Pesquisar:",
            "sUrl":          "",
            "oPaginate": {
            	"sFirst":    "Primeiro",
            	"sPrevious": "Anterior",
            	"sNext":     "Seguinte",
            	"sLast":     "Último"
            }
        }
    
    
} );
   
  $("#tabelaorgaos_length").css({"borderTopWidth": "0", "borderRightWidth": "0" , "borderBottomWidth": "0", "borderLeftWidth": "0"});
} );

var opts = {
		  lines: 11, // The number of lines to draw
		  length: 30, // The length of each line
		  width: 13, // The line thickness
		  radius: 25, // The radius of the inner circle
		  corners: 1, // Corner roundness (0..1)
		  rotate: 0, // The rotation offset
		  direction: 1, // 1: clockwise, -1: counterclockwise
		  color: 'grey', // #rgb or #rrggbb or array of colors
		  speed: 1.5, // Rounds per second
		  trail: 60, // Afterglow percentage
		  shadow: true, // Whether to render a shadow
		  hwaccel: true, // Whether to use hardware acceleration
		  className: 'spinner', // The CSS class to assign to the spinner
		  zIndex: 2e9, // The z-index (defaults to 2000000000)
		  top: '50%', // Top position relative to parent
		  left: '50%' // Left position relative to parent
		};



function abredadosutilizador()
{
	var spinner = new Spinner(opts).spin(document.getElementById('spinnergif'));
	$.post("editautilizadorPPTrans", {}, function(resposta) {
			$("#separadordadosutilizador").html(resposta);
				   $("#separadorofertas").empty().hide();
	    		   $("#separadorconfirmacao").empty().hide();
	        	   $("#separadoratribuicao").empty().hide();
	        	   
	        	   
	        	document.getElementById("atribuicao").className = "";
	    		document.getElementById("ofertas").className = "";
	    		document.getElementById("confirmacao").className = "";
	    		document.getElementById("separadordadosutilizador").style.display = 'block';   
			spinner.stop();
		});	

}

function start()
{
	document.getElementById("atribuicao").className = "selected";
	document.getElementById("ofertas").className = "";
	document.getElementById("confirmacao").className = "";
}

function abredetalheorgao(iddador, idanalise)
{

	
	
	var spinner = new Spinner(opts).spin(document.getElementById('spinnergif'));
	 $.ajax({
	        url: 'abreofertaorgao',
	        type: 'POST',
	        cache: false,
	        data: {"iddador" : iddador, "idanalise" :idanalise},
           success: function(data, textStatus, jqXHR)
           {
        	   $("#separadoratribuicaodetalhe").html(data);
        		document.getElementById("separadoratribuicaogeral").style.display = 'none';
        		document.getElementById("separadoratribuicaodetalhe").style.display = 'block';
				spinner.stop();
           },
           error: function(jqXHR, textStatus, errorThrown) 
           {
				if(textStatus=='error'){
				//	alert("Ocorreu um erro,por favor tente novamente");
					alertify.error('Não foi possível completar o pedido, por favor tente novamente');
				//location.href="errorpage";
				}
			spinner.stop();
           }
	    });
	
//	$.post("abreofertaorgao", function(resposta) 
//	{
//		$("#separadoratribuicaodetalhe").html(resposta);
//	});
}

function changeclassSelected(element)
{
	var tab = element.id;
	
	if(tab == 'atribuicao')
	{
		
		
		var spinner = new Spinner(opts).spin(document.getElementById('spinnergif'));
		 $.ajax({
		        url: 'carregagcctatribuicao',
		        type: 'POST',
		        cache: false,
	           success: function(data, textStatus, jqXHR)
	           {
	        	   $("#separadoratribuicao").html(data);
	        	   
	       		document.getElementById("atribuicao").className = "selected";
	    		document.getElementById("ofertas").className = "";
	    		document.getElementById("confirmacao").className = "";
	    		
	    		document.getElementById("separadorofertas").style.display = 'none';
	    		document.getElementById("separadoratribuicaodetalhe").style.display = 'none';
	    		document.getElementById("separadorconfirmacao").style.display = 'none';
	    		
	    		document.getElementById("separadoratribuicao").style.display = 'block';
	    		document.getElementById("separadoratribuicaogeral").style.display = 'block';
	    		
	    		   $("#separadorofertas").empty().hide();
	    		   $("#separadorconfirmacao").empty().hide();
	    		   $("#separadordadosutilizador").empty().hide();
	        	   spinner.stop();
	           },
	           error: function(jqXHR, textStatus, errorThrown) 
	           {
					if(textStatus=='error'){
					//	alert("Ocorreu um erro,por favor tente novamente");
						alertify.error('Não foi possível completar o pedido, por favor tente novamente');
					//location.href="errorpage";
					}
				spinner.stop();
	           }
		    });  
		
	}
	else
	if(tab == 'ofertas')
	{
		document.getElementById("atribuicao").className = "";
		document.getElementById("ofertas").className = "selected";
		document.getElementById("confirmacao").className = "";
		
		document.getElementById("separadoratribuicao").style.display = 'none';
		document.getElementById("separadorconfirmacao").style.display = 'none';
		
		//carregar tabela ofertas
		var spinner = new Spinner(opts).spin(document.getElementById('spinnergif'));
		 $.ajax({
		        url: 'carregaseparadorofertas',
		        type: 'POST',
		        cache: false,
	           success: function(data, textStatus, jqXHR)
	           {
	        	   $("#separadorofertas").html(data);
	        	   $("#separadoratribuicao").empty().hide();
	    		   $("#separadorconfirmacao").empty().hide();
	    		   $("#separadordadosutilizador").empty().hide();
					spinner.stop();
	           },
	           error: function(jqXHR, textStatus, errorThrown) 
	           {
					if(textStatus=='error'){
					//	alert("Ocorreu um erro,por favor tente novamente");
						alertify.error('Não foi possível completar o pedido, por favor tente novamente');
					//location.href="errorpage";
					}
				spinner.stop();
	           }
		    });
		
		
		
		 $("#separadorofertadetalhe").empty();
		
		document.getElementById("separadorofertas").style.display = 'block';
	}
	else
	if(tab == 'confirmacao')
	{
		document.getElementById("atribuicao").className = "";
		document.getElementById("ofertas").className = "";
		document.getElementById("confirmacao").className = "selected";
		
		document.getElementById("separadoratribuicao").style.display = 'none';
		document.getElementById("separadorofertas").style.display = 'none';
		
		//carregar tabela confirmacao
		var spinner = new Spinner(opts).spin(document.getElementById('spinnergif'));
		
		 $.ajax({
		        url: 'carregaseparadorconfirmacao',
		        type: 'POST',
		        cache: false,
	           success: function(data, textStatus, jqXHR)
	           {
	        	   $("#separadorconfirmacao").html(data);
	        	   $("#separadoratribuicao").empty().hide();
	        	   $("#separadorofertas").empty().hide();
	        	   $("#separadordadosutilizador").empty().hide();
	        	   spinner.stop();
	           },
	           error: function(jqXHR, textStatus, errorThrown) 
	           {
					if(textStatus=='error'){
						alertify.error('Não foi possível completar o pedido, por favor tente novamente');
					}
				spinner.stop();
	           }
		    });
		
		$("#separadorconfirmacaodetalhe").empty();
		
		document.getElementById("separadorconfirmacao").style.display = 'block';
	}
}

function changeclassSelected2(element)
{
	var tab = element.id;
	
	if(tab == 'assignacao')
	{
		document.getElementById("assignacao").className = "selected";
		document.getElementById("dador").className = "";
		document.getElementById("analises").className = "";
		//document.getElementById("ficha").className = "";
		//document.getElementById("selecao").className = "";
		document.getElementById("equipa").className = "";
		//document.getElementById("complicacoes").className = "";
		
		document.getElementById("separadoranalises").style.display = 'none';
		document.getElementById("separadorequipa").style.display = 'none';
		document.getElementById("separadordador").style.display = 'none';
		document.getElementById("separadorexames").style.display = 'none';
		document.getElementById("separadortt").style.display = 'none';
		document.getElementById("separadorassignacao").style.display = 'block';
	}
	else
	if(tab == 'dador')
	{
		
		var spinner = new Spinner(opts).spin(document.getElementById('spinnergif'));
		
		$( "#separadordador" ).load( "carregaseparadordador", function() {
		document.getElementById("assignacao").className = "";
		document.getElementById("dador").className = "selected";
		document.getElementById("analises").className = "";
		document.getElementById("exames").className = "";
		document.getElementById("tt").className = "";
		document.getElementById("equipa").className = "";
		//document.getElementById("complicacoes").className = "";
		
		document.getElementById("separadorassignacao").style.display = 'none';
		document.getElementById("separadorequipa").style.display = 'none';
		document.getElementById("separadoranalises").style.display = 'none';
		document.getElementById("separadorexames").style.display = 'none';
		document.getElementById("separadortt").style.display = 'none';
		document.getElementById("separadordador").style.display = 'block';
		spinner.stop();
		});
	}
	else
	if(tab == 'analises')
	{
		var spinner = new Spinner(opts).spin(document.getElementById('spinnergif'));
	
		$( "#separadoranalises" ).load( "carregaseparadoranalises", function() {
		
		document.getElementById("assignacao").className = "";
		document.getElementById("dador").className = "";
		document.getElementById("analises").className = "selected";
		document.getElementById("exames").className = "";
		document.getElementById("tt").className = "";
		document.getElementById("equipa").className = "";
		//document.getElementById("complicacoes").className = "";
		
		document.getElementById("separadorassignacao").style.display = 'none';
		document.getElementById("separadorequipa").style.display = 'none';
		document.getElementById("separadordador").style.display = 'none';
		document.getElementById("separadorexames").style.display = 'none';
		document.getElementById("separadortt").style.display = 'none';
		document.getElementById("separadoranalises").style.display = 'block';
		spinner.stop();
		});
	}
	else
	if(tab == 'exames')
	{
		
		var spinner = new Spinner(opts).spin(document.getElementById('spinnergif'));
		
		$( "#separadorexames" ).load( "carregaseparadorexames", function() {
			
		
		document.getElementById("assignacao").className = "";
		document.getElementById("dador").className = "";
		document.getElementById("analises").className = "";
		document.getElementById("exames").className = "selected";
		document.getElementById("tt").className = "";
		document.getElementById("equipa").className = "";
		//document.getElementById("complicacoes").className = "";
		
		document.getElementById("separadoranalises").style.display = 'none';
		document.getElementById("separadorassignacao").style.display = 'none';
		document.getElementById("separadorequipa").style.display = 'none';
		document.getElementById("separadordador").style.display = 'none';
		document.getElementById("separadortt").style.display = 'none';
		document.getElementById("separadorexames").style.display = 'block';
		spinner.stop();
		});
		
	}
	else
	if(tab == 'tt')
	{
		
		var spinner = new Spinner(opts).spin(document.getElementById('spinnergif'));
		
		$( "#separadortt" ).load( "carregaseparadortt", function() {
				
		document.getElementById("assignacao").className = "";
		document.getElementById("dador").className = "";
		document.getElementById("analises").className = "";
		document.getElementById("exames").className = "";
		document.getElementById("tt").className = "selected";
		document.getElementById("equipa").className = "";
		//document.getElementById("complicacoes").className = "";
		
		document.getElementById("separadoranalises").style.display = 'none';
		document.getElementById("separadorassignacao").style.display = 'none';
		document.getElementById("separadorequipa").style.display = 'none';
		document.getElementById("separadordador").style.display = 'none';
		document.getElementById("separadorexames").style.display = 'none';
		document.getElementById("separadortt").style.display = 'block';
		spinner.stop();
		});
	}
	else
	if(tab == 'equipa')
	{
		var spinner = new Spinner(opts).spin(document.getElementById('spinnergif'));
		$( "#separadorequipa" ).load( "carregaseparadorequipa", function() {
			
		document.getElementById("assignacao").className = "";
		document.getElementById("dador").className = "";
		document.getElementById("analises").className = "";
		document.getElementById("exames").className = "";
		document.getElementById("tt").className = "";
		document.getElementById("equipa").className = "selected";
		//document.getElementById("complicacoes").className = "";
		
		document.getElementById("separadordador").style.display = 'none';
		document.getElementById("separadorassignacao").style.display = 'none';
		document.getElementById("separadoranalises").style.display = 'none';
		document.getElementById("separadorexames").style.display = 'none';
		document.getElementById("separadortt").style.display = 'none';
		document.getElementById("separadorequipa").style.display = 'block';
		
		spinner.stop();
		});
	}
	else
	if(tab == 'complicacoes')
	{
		document.getElementById("assignacao").className = "";
		document.getElementById("dador").className = "";
		document.getElementById("analises").className = "";
		document.getElementById("exames").className = "";
		document.getElementById("tt").className = "";
		document.getElementById("equipa").className = "";
		//document.getElementById("complicacoes").className = "selected";
	}
	
	//-------------- TAB OFERTAS----------------------//
		else
			if(tab == 'dadoroferta')
			{
				
				var spinner = new Spinner(opts).spin(document.getElementById('spinnergif'));
				
				$( "#separadordador" ).load( "carregaseparadordador", function() {
				
				document.getElementById("dadoroferta").className = "selected";
				document.getElementById("analisesoferta").className = "";
				//document.getElementById("examesoferta").className = "";
				document.getElementById("ttoferta").className = "";
				document.getElementById("equipaoferta").className = "";
				document.getElementById("fichaorgaooferta").className = "";
				document.getElementById("selecaocandidatooferta").className = "";
				//document.getElementById("complicacoes").className = "";
				
				
				document.getElementById("separadorequipa").style.display = 'none';
				document.getElementById("separadoranalises").style.display = 'none';
				//document.getElementById("separadorexames").style.display = 'none';
				document.getElementById("separadortt").style.display = 'none';
				document.getElementById("separadorfichaorgao").style.display = 'none';
				document.getElementById("separadorselecaocandidato").style.display = 'none';
				document.getElementById("separadordador").style.display = 'block';
				spinner.stop();
				});
			}
			else
				if(tab == 'analisesoferta')
				{
					var spinner = new Spinner(opts).spin(document.getElementById('spinnergif'));
				
					$( "#separadoranalises" ).load( "carregaseparadoranalises", function() {
					
			
					document.getElementById("dadoroferta").className = "";
					document.getElementById("analisesoferta").className = "selected";
				//	document.getElementById("examesoferta").className = "";
					document.getElementById("ttoferta").className = "";
					document.getElementById("equipaoferta").className = "";
					document.getElementById("fichaorgaooferta").className = "";
					document.getElementById("selecaocandidatooferta").className = "";
					//document.getElementById("complicacoes").className = "";
					
					document.getElementById("separadorequipa").style.display = 'none';
					document.getElementById("separadordador").style.display = 'none';
					//document.getElementById("separadorexames").style.display = 'none';
					document.getElementById("separadortt").style.display = 'none';
					document.getElementById("separadorfichaorgao").style.display = 'none';
					document.getElementById("separadorselecaocandidato").style.display = 'none';
					document.getElementById("separadoranalises").style.display = 'block';
					spinner.stop();
					});
				}
	//exames verificar qual o orgão e abrir só os exames desse orgão como ficha orgão
	
//			else
//			if(tab == 'examesoferta')
//			{
//				
//				var spinner = new Spinner(opts).spin(document.getElementById('spinnergif'));
//				
//				$( "#separadorexames" ).load( "carregaseparadorexames", function() {
//					
//				
//				
//				document.getElementById("dadoroferta").className = "";
//				document.getElementById("analisesoferta").className = "";
//				document.getElementById("examesoferta").className = "selected";
//				document.getElementById("ttoferta").className = "";
//				document.getElementById("equipaoferta").className = "";
//				document.getElementById("fichaorgaooferta").className = "";
//				document.getElementById("selecaocandidatooferta").className = "";
//				
//				document.getElementById("separadoranalises").style.display = 'none';
//				document.getElementById("separadorequipa").style.display = 'none';
//				document.getElementById("separadordador").style.display = 'none';
//				document.getElementById("separadortt").style.display = 'none';
//				document.getElementById("separadorfichaorgao").style.display = 'none';
//				document.getElementById("separadorselecaocandidato").style.display = 'none';
//				document.getElementById("separadorexames").style.display = 'block';
//				spinner.stop();
//				});
//				
//			}
			else
			if(tab == 'ttoferta')
			{
				
				var spinner = new Spinner(opts).spin(document.getElementById('spinnergif'));
				
				$( "#separadortt" ).load( "carregaseparadortt", function() {
						
				
				document.getElementById("dadoroferta").className = "";
				document.getElementById("analisesoferta").className = "";
			//	document.getElementById("examesoferta").className = "";
				document.getElementById("ttoferta").className = "selected";
				document.getElementById("equipaoferta").className = "";
				document.getElementById("fichaorgaooferta").className = "";
				document.getElementById("selecaocandidatooferta").className = "";
				//document.getElementById("complicacoes").className = "";
				
				
				document.getElementById("separadoranalises").style.display = 'none';
				document.getElementById("separadorequipa").style.display = 'none';
				document.getElementById("separadordador").style.display = 'none';
			//	document.getElementById("separadorexames").style.display = 'none';
				document.getElementById("separadorfichaorgao").style.display = 'none';
				document.getElementById("separadorselecaocandidato").style.display = 'none';
				document.getElementById("separadortt").style.display = 'block';
				spinner.stop();
				});
			}
			else
				if(tab == 'fichaorgaooferta')
				{
					var spinner = new Spinner(opts).spin(document.getElementById('spinnergif'));
					$( "#separadorfichaorgao" ).load( "carregaseparadorfuncaoorgaooferta", function() {
					//	$( "#explante" ).load( "carregacolheitadadorcadaver", function() {
							$( "#transplante" ).load( "carregatransplante", function() {
				
					document.getElementById("dadoroferta").className = "";
					document.getElementById("analisesoferta").className = "";
			//		document.getElementById("examesoferta").className = "";
					document.getElementById("ttoferta").className = "";
					document.getElementById("equipaoferta").className = "";
					document.getElementById("selecaocandidatooferta").className = "";
					document.getElementById("fichaorgaooferta").className = "selected";
					//document.getElementById("complicacoes").className = "";
					
					document.getElementById("separadordador").style.display = 'none';
					document.getElementById("separadoranalises").style.display = 'none';
			//		document.getElementById("separadorexames").style.display = 'none';
					document.getElementById("separadortt").style.display = 'none';
					document.getElementById("separadorequipa").style.display = 'none';
					document.getElementById("separadorselecaocandidato").style.display = 'none';
					document.getElementById("separadorfichaorgao").style.display = 'block';
					
					spinner.stop();
							});
				//		});
					});
				}
			else
			if(tab == 'equipaoferta')
			{
				var spinner = new Spinner(opts).spin(document.getElementById('spinnergif'));
				
				$( "#separadorequipa" ).load( "carregaseparadorequipaoferta", function() {
					
			
				document.getElementById("dadoroferta").className = "";
				document.getElementById("analisesoferta").className = "";
			//	document.getElementById("examesoferta").className = "";
				document.getElementById("ttoferta").className = "";
				document.getElementById("fichaorgaooferta").className = "";
				document.getElementById("selecaocandidatooferta").className = "";
				document.getElementById("equipaoferta").className = "selected";
				//document.getElementById("complicacoes").className = "";
				
				document.getElementById("separadordador").style.display = 'none';
				document.getElementById("separadoranalises").style.display = 'none';
		//		document.getElementById("separadorexames").style.display = 'none';
				document.getElementById("separadortt").style.display = 'none';
				document.getElementById("separadorfichaorgao").style.display = 'none';
				document.getElementById("separadorselecaocandidato").style.display = 'none';
				document.getElementById("separadorequipa").style.display = 'block';
				
				spinner.stop();
				});
			}
			else
				if(tab == 'selecaocandidatooferta')
				{
					var spinner = new Spinner(opts).spin(document.getElementById('spinnergif'));
					$( "#separadorselecaocandidato" ).load( "carregaseparadorselecaocandidato", function() {
						
				
					document.getElementById("dadoroferta").className = "";
					document.getElementById("analisesoferta").className = "";
			//		document.getElementById("examesoferta").className = "";
					document.getElementById("ttoferta").className = "";
					document.getElementById("fichaorgaooferta").className = "";
					document.getElementById("equipaoferta").className = "";
					document.getElementById("selecaocandidatooferta").className = "selected";
					//document.getElementById("complicacoes").className = "";
					
					document.getElementById("separadordador").style.display = 'none';
					document.getElementById("separadoranalises").style.display = 'none';
			//		document.getElementById("separadorexames").style.display = 'none';
					document.getElementById("separadortt").style.display = 'none';
					document.getElementById("separadorfichaorgao").style.display = 'none';
					document.getElementById("separadorequipa").style.display = 'none';
					document.getElementById("separadorselecaocandidato").style.display = 'block';
					
					spinner.stop();
					});
				}
	
}

function abrecandidatoselecaofigado(idrecetor){//igual ao do eqtransplante.js
	
	
	$("#radio_"+idrecetor).prop("checked", true);
	
	var spinner = new Spinner(opts).spin(document.getElementById('spinnergif'));
	 $.ajax({
	        url: 'abreharmonioscandidatotransplantefigado',
	        type: 'POST',
	        cache: false,
	        data: {"idrecetor" : idrecetor},
          success: function(data, textStatus, jqXHR)
          {
          	   $("#harmoniosselecaocandidato").slideUp("fast", function(){
           		   
               	   $("#harmoniosselecaocandidato").html(data);
               	   $("#harmoniosselecaocandidato").slideDown("slow");   
           		   
           	   }); 
       		
				spinner.stop();
          },
          error: function(jqXHR, textStatus, errorThrown) 
          {
				if(textStatus=='error'){
				//	alert("Ocorreu um erro,por favor tente novamente");
					alertify.error('Não foi possível completar o pedido, por favor tente novamente');
				//location.href="errorpage";
				}
			spinner.stop();
          }
	    });
	
}