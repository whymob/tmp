function registahorastc(tipo){
	
	var spinner = new Spinner(opts).spin(document.getElementById('spinnergif'));
	 $.ajax({
	        url: 'registahorastc',
	        type: 'POST',
	        cache: false,
	        data:  {"tipo" : tipo},
          success: function(data, textStatus, jqXHR)
          {
        	  var d = Date.parse(data).toString('dd/MM/yyyy HH:mm');
        	  
        	  if(tipo==1){
        		  $("#iniciotc").html(d);    
        	  }else if(tipo==2){
        		  $("#fimtc").html(d);	  
        	  }
				spinner.stop();
          },
          error: function(jqXHR, textStatus, errorThrown) 
          {

				alertify.error('Não foi possível completar o pedido, por favor tente novamente');
				spinner.stop();
          }
	    });
}

function gravaharmoniotc(){
	
	var coddador = $("#dadorcod").text();
	
	
	
	var codigogerado = 0;
	
	$('.tc').each(function(){
		if($(this).is(":checked"))
		{	
			codigogerado++;
		}			
	});
	
	if(codigogerado>0){
		$("#tccod").val(coddador+"-CVA");
	}else{
		$("#tccod").val("");	
	}
	
	var spinner = new Spinner(opts).spin(document.getElementById('spinnergif'));
	 $.ajax({
	        url: 'gravacolheitaharmoniotc',
	        type: 'POST',
	        cache: false,
	        data: $("#formtc").serialize(),
         success: function(data, textStatus, jqXHR)
         {
        	 if(codigogerado>0){
        		 $("#lblcodtc").text(coddador+"-CVA");
        	 }else{
        		 $("#lblcodtc").text("");	 
        	 }
        	 alertify.success("Dados gravados com sucesso!");
				spinner.stop();
         },
         error: function(jqXHR, textStatus, errorThrown) 
         {
				if(textStatus=='error'){
				//	alert("Ocorreu um erro,por favor tente novamente");
					alertify.error('Não foi possível completar o pedido, por favor tente novamente');
				//location.href="errorpage";
				}
			spinner.stop();
         }
	    });	
}