
function existemb(textInput){

	var flag = false;
		$.each($("#tabelamicrobiologia tbody tr").find("td:eq(0)"), function() {
			
			 if ($(this).text() == textInput) {
		           flag = true;
		        }       
	    });
	return flag;
	}


function registarmbanalise(){
	
	//formatar e carregar datas completas para caixa data escondida
	var data = $("#dataamostramb").val();
	var hora = $("#horaamostramb").val();
	var formatodata = data+" "+hora;
	var d=  new Date(Date.parse(formatodata)).toString('dd/MM/yyyy, HH:mm:ss');
	$("#datahoraamostraregmb").val(d);
	
	
	var data1 = $("#dataamostrambreult").val();
	var hora1 = $("#horaamostrambresult").val();
	if(data1=='' || hora1 == ''){
		$("#datahoraresultamostraregmb").val("NA");	
	}else{
		var formatodata1 = data1+" "+hora1;
		var d1=  new Date(Date.parse(formatodata1)).toString('dd/MM/yyyy, HH:mm:ss');
		
		$("#datahoraresultamostraregmb").val(d1);	
	}
	
	var analisemb = $("#amostrambintroduzir").val();
	
	if(analisemb == "0"){
		//alert("É necessário seleccionar uma amostra a introduzir");
		alertify.error("É necessário seleccionar um tipo de amostra a registar");
	}else{	
		
		var data = $("#datahoraamostraregmb").val();
		var dataresult = $("#datahoraresultamostraregmb").val();
		var nome = $("#amostrambintroduzir  option:selected").text();
		var posneg = $("#posnegamostramb").val();
		var observ = $("#mbobserv").val();
			
//		if(existemb(nome)){
//			alertify.error("Já foi introduzido esse indice de amostra");
//		}else{
		// confirmar introdução
		alertify.confirm("Confirma a introdução da análise "+nome, function (e) {
		    if (e) {
		        // clicou "ok"
				var spinner = new Spinner(opts).spin(document.getElementById('spinnergif'));
				 $.ajax({
				        url: 'addanalisetabelamb',
				        type: 'POST',
				        cache: false,
				        data: {"analisemb" : analisemb, "data":data, "posneg":posneg, "observ": observ, "dataresult":dataresult},
			            success: function(data, textStatus, jqXHR)
			            {
		           	$("#tabelamicrobiologia").html(data);
			//            	$.post("carregacomboamostras", function(resposta) {
			 //       			$("#comboamostras").html(resposta);
			//        		});
		           			$("#amostrambintroduzir").val(0);
		           			$("#posnegamostramb").val("1");
		           			$("#mbobserv").val("");
		           			$("#statusmicrobio").attr("src","resources/imagens/green-check.gif");
			 				alertify.success("inserção efectuada com sucesso");
			 				spinner.stop();
			            },
			            error: function(jqXHR, textStatus, errorThrown) 
			            {
			 				if(textStatus=='error'){
			 				//	alert("Ocorreu um erro,por favor tente novamente");
			 					alertify.error('Não foi possível completar o pedido, por favor verifique o formato dos dados e tente novamente');
			 				//location.href="errorpage";
			 				}
			   				spinner.stop();
			            }
				    });	
		    	
		    } else {
		    	alertify.error("Processo de inserção cancelado");
		    }
		});
	
		//}
	}
}
function cancelaregistarmb(){
	$("#registaramostramb").show();
	$("#editaramostramb").hide();			
}


function editaramostramb(event, id, tipo, posneg, idtipo, observmicro, data, dataresult){
	event.stopPropagation();
	$("#editidmbanalise").val(id);
	$("#editnomeamostramb").val(tipo);
	$("#editposnegamostramb").val(posneg);
	$("#editobservmb").val(observmicro);
	$("#editidtipombanalise").val(idtipo);

	if(data!=''){	
	var d = Date.parse(data);
	var datacolh = d.toString('yyyy-MM-dd');
	var horacolh = d.toString('HH:mm');
	$("#editdataamostramb").val(datacolh);
	$("#edithoraamostramb").val(horacolh);
	}else{
		$("#editdataamostramb").val("");
		$("#edithoraamostramb").val("");	
	}
	//se não houver data resultado
	if(dataresult!=''){
	var dres = Date.parse(dataresult);
	var datares = dres.toString('yyyy-MM-dd');
	var horares = dres.toString('HH:mm');
	
	$("#editdataamostrambreult").val(datares);
	$("#edithoraamostrambresult").val(horares);
	}else{
		
		$("#editdataamostrambreult").val("");
		$("#edithoraamostrambresult").val("");
	}
	$("#registaramostramb").hide();
	$("#editaramostramb").show();	
}

function tratadataeditaamostramb(){

	var data2 = $("#editdataamostramb").val();
	var hora2 = $("#edithoraamostramb").val();
	var formatodata2 = data2+" "+hora2;
	var d2=  new Date(Date.parse(formatodata2)).toString('dd/MM/yyyy, HH:mm:ss');
	$("#editdatambanalise").val(d2);
	
	
	var data3 = $("#editdataamostrambreult").val();
	var hora3 = $("#edithoraamostrambresult").val();
	if(data3=='' || hora3 == ''){
		$("#editdataresultmbanalise").val("NA");	
	}else{
		var formatodata3 = data3+" "+hora3;
		var d3=  new Date(Date.parse(formatodata3)).toString('dd/MM/yyyy, HH:mm:ss');
		
		$("#editdataresultmbanalise").val(d3);	
	}

}

function guardaramostramb(){

	tratadataeditaamostramb();
	
	var idmb = $("#editidmbanalise").val();
	var tipomb = $("#editidtipombanalise").val();
	var posneg = $("#editposnegamostramb").val();
	var datamb = $("#editdatambanalise").val();
	var observmb = $("#editobservmb").val();
	var dataresult = $("#editdataresultmbanalise").val();
	//guardar e qd guardar recarregar a tabela com a função que foi usada para recarregar qd introduz novo indice de amostras
	$("#editaramostramb").hide();
	$("#registaramostramb").show();
	var spinner = new Spinner(opts).spin(document.getElementById('spinnergif'));
	 $.ajax({
	        url: 'editardadosanaliseamb',
	        type: 'POST',
	        cache: false,
	        data: {"idmb":idmb, "tipomb":tipomb,  "posneg":posneg, "datamb":datamb, "dataresult":dataresult ,"observmb":observmb},
         success: function(data, textStatus, jqXHR)
         {

//colocar resposta que é a linha atualizada na linha correspondente
        	 $("#tabelamicrobiologia").html(data);
        	 $("#tabmicrorg").hide();
        	 $("#tabsens").hide();
				alertify.success("alteração efectuada com sucesso");
				spinner.stop();
         },
         error: function(jqXHR, textStatus, errorThrown) 
         {
				if(textStatus=='error'){
					alertify.error('Não foi possível completar o pedido, por favor verifique o formato dos dados e tente novamente');
				//location.href="errorpage";
				}
   				spinner.stop();
         }
	    });	
}


function abremicrorganismos(idmbanalise, event){
	
	 var estado = $(event).find('td:eq(5)').text();
	
	 if(estado==1 || estado==2){
			alertify.success("O registo de microorganismos e sensibilidades só é válido para colheitas com resultado positivo.");
	 }else{

		//$("#tabelamicrobiologia tbody tr").css("background-color", "#eeece1");
		$("#tabelamicrobiologia tbody tr").css("background-color", "");
		$(event).css("background-color", "#e47c80");
		
		var spinner = new Spinner(opts).spin(document.getElementById('spinnergif'));
		 $.ajax({
		        url: 'buscamicrorganalise',
		        type: 'POST',
		        cache: false,
		        data: {"mbanalise":idmbanalise},
	     success: function(data, textStatus, jqXHR)
	     {
	    	$("#tabmicrorg").html(data);
			//		alertify.success("alteração efectuada com sucesso");
	   	 $("#tabmicrorg").show();
		 $("#tabsens").hide();
					spinner.stop();
	     },
	     error: function(jqXHR, textStatus, errorThrown) 
	     {
					if(textStatus=='error'){
						alertify.error('Não foi possível completar o pedido, por favor tente novamente');
					}
	   				spinner.stop();
	     }
		    });
		 
		 $("#filtratipomicro").attr('disabled', false);
		 $("#filtratipomicro").val(0);	 
	 }
}


function alteratipomicro(){
	var tipo = $("#filtratipomicro").val();
	if(tipo>0){

        $.each($("#tabmicrorg tbody tr").find("td:eq(2)"), function() {
			
			
			 if ($(this).text() !== tipo) {
				 $(this).parent().hide();
		        }else{
		        	 $(this).parent().show();	
		        }
			         
	    });
	}else{
        $.each($("#tabmicrorg tbody tr").find("td:eq(2)"), function() {
		        	 $(this).parent().show();	         
	    });	
		
	}
	
	
}


//****Microorganismos****//
function gravarmicrorg(mbanalise, microorganalise, idmicrorg, event){
	
	if(event.value=='False')
		{
		event.value='True';
	event.checked = true;
		}else if(event.value=='True'){
			event.value='False';
			event.checked = false;
		}
	
	var valor = event.value;
	
	
	// alert($(event).parent().parent().children().html());
	 
	if(microorganalise==''){
		

		//inserção microorg novo na analise seleccionada
		var spinner = new Spinner(opts).spin(document.getElementById('spinnergif'));
		 $.ajax({
		        url: 'inseremicroorganalise',
		        type: 'POST',
		        cache: false,
		        data: {"mbanalise":mbanalise, "idmicrorg":idmicrorg, "valor":valor},
	      success: function(data, textStatus, jqXHR)
	      {
    	  
	    	  $(event).attr("onclick", "gravarmicrorg("+mbanalise+", '"+data+"', "+idmicrorg+", this);");    	 
	    	  $(event).closest("tr").find('td:eq(0)').attr("onclick", "abresensibilidades('"+data+"',true, this);");
	    	  abresensibilidades(data, valor, event);
	    	  $(event).closest("tr").find('td').css("background-color", "#e47c80");
					spinner.stop();
	      },
	      error: function(jqXHR, textStatus, errorThrown) 
	      {
					if(textStatus=='error'){
						alertify.error('Não foi possível completar o pedido, por favor tente novamente');			
					}
	   				spinner.stop();
	      }
		    });

	
	}else{
	
	//fazer alteração do registro
	var spinner = new Spinner(opts).spin(document.getElementById('spinnergif'));
	 $.ajax({
	        url: 'editamicroorganalise',
	        type: 'POST',
	        cache: false,
	        data: {"mbanalise":mbanalise, "microorganalise":microorganalise, "idmicrorg":idmicrorg, "valor":valor},
     success: function(data, textStatus, jqXHR)
     {
    	// $("#micro_"+idmicrorg).html(data);
 
    	 if(valor=='False'){
    		 $(event).closest("tr").find('td:eq(0)').attr("onclick", "abresensibilidades('"+microorganalise+"',false, this);");
    		 $("#tabsens").hide(); 
    		 $("#tabmicrorg tbody tr td").css("background-color", "");
    		 
    	 }else{
    		 $(event).closest("tr").find('td:eq(0)').attr("onclick", "abresensibilidades('"+microorganalise+"',true, this);");
    		 abresensibilidades(microorganalise, valor, event);
    	 }
    	 
				spinner.stop();
     },
     error: function(jqXHR, textStatus, errorThrown) 
     {
				if(textStatus=='error'){
					alertify.error('Não foi possível completar o pedido, por favor tente novamente');
				}
   				spinner.stop();
     }
	    });
	}
}

//sensibilidades

function abresensibilidades(idmicroorg, valor, event){

//	alert(idmbanalise);
if(valor==false){
	
}else{
	
	$("#tabmicrorg tbody tr td").css("background-color", "");
	$(event).closest("tr").find('td').css("background-color", "#e47c80");
	
	var spinner = new Spinner(opts).spin(document.getElementById('spinnergif'));
	 $.ajax({
	        url: 'abresensmicroanalise',
	        type: 'POST',
	        cache: false,
	        data: {"idmicroorg":idmicroorg},
     success: function(data, textStatus, jqXHR)
     {
    	$("#tabsens").html(data);
		//		alertify.success("alteração efectuada com sucesso");
    	$("#tabsens").show();
				spinner.stop();
     },
     error: function(jqXHR, textStatus, errorThrown) 
     {
				if(textStatus=='error'){
					alertify.error('Não foi possível completar o pedido, por favor tente novamente');
				}
   				spinner.stop();
     }
	    });
//		event.stopPropagation();
}
}


function gravasensib(microorganismo, idsens, sensmicro, event){

		
		if(event.value=='False')
			{
			event.value='True';
		event.checked = true;
			}else if(event.value=='True'){
				event.value='False';
				event.checked = false;
			}
		
		var valor = event.value;

		if(sensmicro==''){
			

		//inserção microorg novo na analise seleccionada
		var spinner = new Spinner(opts).spin(document.getElementById('spinnergif'));
		 $.ajax({
		        url: 'inseresensmicroanalise',
		        type: 'POST',
		        cache: false,
		        data: {"microorganismo":microorganismo, "idsens":idsens, "valor":valor},
	      success: function(data, textStatus, jqXHR)
	      {
	    	//  $("#tabsens").html(data);
	    	  //atualizar id inserido
	    	  $(event).attr("onclick", "gravasensib(1, 1, '"+data+"', this);");
					spinner.stop();
	      },
	      error: function(jqXHR, textStatus, errorThrown) 
	      {
					if(textStatus=='error'){
						alertify.error('Não foi possível completar o pedido, por favor tente novamente');
					}
	   				spinner.stop();
	      }
		    });
		
		}else{
		
		//fazer alteração do registro
		var spinner = new Spinner(opts).spin(document.getElementById('spinnergif'));
		 $.ajax({
		        url: 'editasensmicroanalise',
		        type: 'POST',
		        cache: false,
		        data: {"sensmicro":sensmicro, "microorganismo":microorganismo, "idsens":idsens, "valor":valor},
	     success: function(data, textStatus, jqXHR)
	     {
					spinner.stop();
	     },
	     error: function(jqXHR, textStatus, errorThrown) 
	     {
					if(textStatus=='error'){
						alertify.error('Não foi possível completar o pedido, por favor tente novamente');
					}
	   				spinner.stop();
	     }
		    });
		}
	//	event.stopPropagation();
}	

function eliminaramostramb(id_mbanalise, e){

	e.stopPropagation();
	
	alertify.confirm("Confirma a eliminação  da amostra?", function (e) {
	    if (e) {
	        // user clicked "ok"
	    	
	    	var spinner = new Spinner(opts).spin(document.getElementById('spinnergif'));
	   	 $.ajax({
	   	        url: 'eliminaanalisemb',
	   	        type: 'POST',
	   	        cache: false,
	   	        data: {"id_mbanalise": id_mbanalise},
	       success: function(data, textStatus, jqXHR)
	       {
	        	$("#tabmicrorg").hide();
	       		$("#tabsens").hide();
	       		$("#microbiologia_"+id_mbanalise).remove();
	       		$("#editaramostramb").hide();
	       		$("#registaramostramb").show();
	   			spinner.stop();
	       },
	       error: function(jqXHR, textStatus, errorThrown) 
	       {
	   				if(textStatus=='error'){
	   					alertify.error('Não foi possível completar o pedido, por favor tente novamente');
	   				}
	   				spinner.stop();
	       }
	   	    });
	    	
	    } else {
	    	alertify.error("Processo de eliminação cancelado");
	    }
	});

}
	 	
	

