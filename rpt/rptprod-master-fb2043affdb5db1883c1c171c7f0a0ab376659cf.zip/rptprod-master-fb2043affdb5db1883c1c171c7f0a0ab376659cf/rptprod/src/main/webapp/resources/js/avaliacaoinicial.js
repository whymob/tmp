﻿/**
 * Script Div AvaliacaoInicial da tab Base Dador
 */

$(document).ready(function () {
    var charReg = /^\s*[a-zA-Z0-9,.\s]+\s*$/;
    $(".warning").hide();
    $('#nome').keyup(function () {
        var inputVal = $(this).val();
        if (!charReg.test(inputVal)) {
            $(this).parent().find(".warning").show();
        } else {
            $(this).parent().find(".warning").hide();
        }

    });
    
    //tamanho do ficheiro para upload
    $("#ficheiro").change(function (){
    		     var iSize = ($("#ficheiro")[0].files[0].size / 1024);
    		     if (iSize / 1024 > 1)
    		     {
    		        if (((iSize / 1024) / 1024) > 1)
    		        {
    		            iSize = (Math.round(((iSize / 1024) / 1024) * 100) / 100);
    		            $("#lbltamanho").html( iSize + "Gb");
    		        }
    		        else
    		        {
    		            iSize = (Math.round((iSize / 1024) * 100) / 100)
    		            if(iSize<=10){
    		            	$("#lbltamanho").html( iSize + "Mb");
    		            }else{
    		            	$("#lbltamanho").html( iSize + "Mb");
    		        		alertify.error('O ficheiro escolhido excede o limite de 10Mb, por favor escolha um ficheiro dentro do limite imposto');	
    		            }
    		        }
    		     }
    		     else
    		     {
    		        iSize = (Math.round(iSize * 100) / 100)
    		        $("#lbltamanho").html( iSize  + "kb");
    		     }   
    });
});


function salvaravinicial()
{
/*	if(document.getElementById("datadaconsulta").value == "" || document.getElementById("horadaconsulta").value == "")
		alertify.error('Escolher data e hora da consulta');
	else*/
/*		if(document.getElementById("datadaconsulta").value.length > 0 || document.getElementById("horadaconsulta").value.length > 0)
		{*/
		//	e.preventDefault();

		if ((document.getElementById("datadaconsulta").value == "" && document.getElementById("horadaconsulta").value.length > 0) || 
				(document.getElementById("datadaconsulta").value.length > 0 && document.getElementById("horadaconsulta").value == "")){
			alertify.error('Data ou hora da consulta em falta ou incorrectos');
		}else{
			
			var d = "";

			if(document.getElementById("datadaconsulta").value.length > 0 && document.getElementById("horadaconsulta").value.length > 0){
				var data = document.getElementById("datadaconsulta").value;
				var hora = document.getElementById("horadaconsulta").value;
				var formatodata = data+" "+hora;
				 d=  new Date(Date.parse(formatodata)).toString('dd/MM/yyyy, HH:mm:ss');
			}
			
			if($('input[name=STATUSRENNDA]:checked').val()=='2'){
				$("#ctrlRENNDA").val(0);
				jQuery("#fichapessoaldador").hide("fast");
				jQuery("#d18").show();
				jQuery("#u18").hide();
				jQuery("#orgaos").hide("fast");
				jQuery("#d17").show();
				jQuery("#u17").hide();
		
			}else{
				$("#ctrlRENNDA").val(1);
		
			}
			
			$("#datahoraconsulta").val(d);
			var spinner = new Spinner(opts).spin(document.getElementById('spinnergif'));
	
		var data2 = ""+$("#avinicial").serialize()+"&observacoes="+$("#observacoes").val()+"&RENNDA="+$("#ctrlRENNDA").val();
			$.ajax
			({
		        url: 'salvaavinicial',
		        type: 'POST',
		        data:  data2,
		        success: function(data, textStatus, jqXHR)
		        {
		        //	alertify.success('Dados gravados com sucesso');					
					//actualizar tabela de dadores
					        $.ajax({
						        url: 'atualizatabdadores',
						        type: 'POST',
						        cache: false,
					            success: function(data, textStatus, jqXHR)
					            {
					            	if($("#ctrlRENNDA").val()==0){
				                		$("#imgdadorval").hide();
				                		$("#imgdadornaoval").show();
				                		$("#textoestado",window.parent.document).text("Não Validado");
					            		
					            	}else if($("#ctrlRENNDA").val()==1){
				                		$("#imgdadorval").hide();
				                		$("#imgdadornaoval").hide();	
				                		$("#textoestado",window.parent.document).text("");
					            	}
					            	
					            	
					            	$("#divdadores").html(data);
					            	$("#statusavinicial").attr("src","resources/imagens/green-check.gif");
					            	alertify.success('Dados gravados com sucesso');
					 				spinner.stop();
					            },
					            error: function(jqXHR, textStatus, errorThrown) 
					            {
					 				if(textStatus=='error'){
					 				//	alert("Ocorreu um erro,por favor tente novamente");
					 					alertify.error('Não foi possível completar o pedido, por favor tente novamente');
					 				//location.href="errorpage";
					 				}
								spinner.stop();
					            }
						    });
					
					
		        },
		        error: function(jqXHR, textStatus, errorThrown) 
		        {
						if(textStatus=='error'){
							alertify.error('Não foi possível completar o pedido, por favor tente novamente');
						}
						spinner.stop();
		        }           
		    });
		}	
}

function alteraestadoform(){
	
	 if (($('#STATUSRENNDA3').is(':checked') && $('#STATUSRENNDA3').val() == 2)||($('#STATUSRENNDA2').is(':checked') && $('#STATUSRENNDA2').val() == 1)) {
		 $('#forminsereficheiroaval').show();
     } else{
    	 $('#forminsereficheiroaval').hide();
	 }
}


function ola2(){
	var data = document.getElementById("datadaconsulta").value;
	var hora = document.getElementById("horadaconsulta").value;
	
	var formatodata = data+" "+hora;

	var d= new Date(formatodata);
	
	if(isNaN(d)){
		alert("não tem data");
	}else{
		//alert(d.toLocaleString());
		$("#datahoraconsulta").val(d.toLocaleString());
		//(d.getFullYear())+ '-' + (d.getMonth() + 1) + '-' + (d.getDate())
	}
}

function alterafile(){
	
	//atualizar input nome ficheiro para possibilitar escolher nome
	var n = $('#ficheiroaval').val().replace(/C:\\fakepath\\/i, '');
	var nome = n.replace(/[^a-z0-9.\s]/gi, '').replace(/[_\s]/g, ' ');
	$('#nomeav').val(nome);
	//$('#nome').val($('#ficheiro').val().replace(/C:\\fakepath\\/i, ''));
	//$('#nome').val().replace(/[^a-z0-9\s]/gi, '').replace(/[_\s]/g, ' ');
}

function uploadavinicial(event){
	
	//var nome = $('#ficheiro').val().replace(/C:\\fakepath\\/i, '');
	$('#id_av_inicial').val($('#bdavalinicial').val());
	
	
	if($('#nomeav').val()==""){
			alertify.error('É necessário seleccionar um ficheiro');	
	}else{
	
	
	function getDoc(frame) {
	     var doc = null;
	 
	     // IE8 verificação do acesso em cascata
	     try {
	         if (frame.contentWindow) {
	             doc = frame.contentWindow.document;
	         }
	     } catch(err) {
	     }
	 
	     if (doc) { // conteudo obtido com sucesso
	         return doc;
	     }
	 
	     try { 
	         doc = frame.contentDocument ? frame.contentDocument : frame.document;
	     } catch(err) {
	         // ultima tentativa
	         doc = frame.document;
	     }
	     return doc;
	 }
	$("#enviarficheiroaval").submit(function(e)
	{
	 
	    var formObj = $(this);
	    var formURL = formObj.attr("action");
	 	    
	    if(window.FormData !== undefined)  // para browsers HTML5
	    {
	 
	    	var spinner = new Spinner(opts).spin(document.getElementById('spinnergif'));
	        var formData = new FormData(this);
	        $.ajax({
	            url: formURL,
	            type: 'POST',
	            data:  formData,
	            mimeType:"multipart/form-data",
	            contentType: false,
	            cache: false,
	            processData:false,
	            success: function(data, textStatus, jqXHR)
	            {
	 				alertify.success(data);
	 				var idavalinic = $('#bdavalinicial').val();
	 				$.post("carreganomedoc", {'idavalinic' : idavalinic}, function(resposta) {
	 					$("#caminhodoc").html(resposta);
	 				});
	 				spinner.stop();
	            },
	            error: function(jqXHR, textStatus, errorThrown) 
	            {
	 				if(textStatus=='error'){
	 				//	alert("Ocorreu um erro,por favor tente novamente");
	 					alertify.error('Não foi possível completar o pedido, por favor tente novamente');
	 				//location.href="errorpage";
	 				}
	 				spinner.stop();
	            }           
	       });
	        e.preventDefault();
	        
	        $("#enviarficheiroaval").unbind();
	       // e.unbind();

	   }
	   else  //para browsers antigos
	    {
	        //gerar um id aleatório
	        var  iframeId = 'unique' + (new Date().getTime());
	 
	        //criar um iframe vazio
	        var iframe = $('<iframe src="javascript:false;" name="'+iframeId+'" />');
	 
	        //esconder o iframe
	        iframe.hide();
	 
	        //definir o alvo do form para o iframe
	        formObj.attr('target',iframeId);
	 
	        //Adicionar o iframe ao body
	        iframe.appendTo('body');
	        iframe.load(function(e)
	        {
	            var doc = getDoc(iframe[0]);
	            var docRoot = doc.body ? doc.body : doc.documentElement;
	            var data = docRoot.innerHTML;
	            //dados do servidor server.
	 
	        });
	 
	    }     
	});
	$("#enviarficheiroaval").submit();
	}
	

}