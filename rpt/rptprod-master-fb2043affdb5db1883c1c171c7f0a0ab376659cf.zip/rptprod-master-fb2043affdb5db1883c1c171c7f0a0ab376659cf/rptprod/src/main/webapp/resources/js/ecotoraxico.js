var opts = {
		  lines: 11, // The number of lines to draw
		  length: 30, // The length of each line
		  width: 13, // The line thickness
		  radius: 25, // The radius of the inner circle
		  corners: 1, // Corner roundness (0..1)
		  rotate: 0, // The rotation offset
		  direction: 1, // 1: clockwise, -1: counterclockwise
		  color: 'grey', // #rgb or #rrggbb or array of colors
		  speed: 1.5, // Rounds per second
		  trail: 60, // Afterglow percentage
		  shadow: true, // Whether to render a shadow
		  hwaccel: true, // Whether to use hardware acceleration
		  className: 'spinner', // The CSS class to assign to the spinner
		  zIndex: 2e9, // The z-index (defaults to 2000000000)
		  top: '50%', // Top position relative to parent
		  left: '50%' // Left position relative to parent
		};

$(document).ready(function () {
    var charReg = /^\s*[a-zA-Z0-9,.\s]+\s*$/;
    $(".warning").hide();
    $('#nometoraxico').keyup(function () {
        var inputVal = $(this).val();
        if (!charReg.test(inputVal)) {
            $(this).parent().find(".warning").show();
        } else {
            $(this).parent().find(".warning").hide();
        }
    });
    
    
    //tamanho do ficheiro para upload
    $("#ficheirotoraxico").change(function (){
    		     var iSize = ($("#ficheirotoraxico")[0].files[0].size / 1024);
    		     if (iSize / 1024 > 1)
    		     {
    		        if (((iSize / 1024) / 1024) > 1)
    		        {
    		            iSize = (Math.round(((iSize / 1024) / 1024) * 100) / 100);
    		            $("#lbltamanho6").html( iSize + "Gb");
    		        }
    		        else
    		        {
    		            iSize = (Math.round((iSize / 1024) * 100) / 100)
    		            if(iSize<=10){
    		            	$("#lbltamanho6").html( iSize + "Mb");
    		            }else{
    		            	$("#lbltamanho6").html( iSize + "Mb");
    		        		alertify.error('O ficheiro escolhido excede o limite de 10Mb, por favor escolha um ficheiro dentro do limite imposto');	
    		            }
    		        }
    		     }
    		     else
    		     {
    		        iSize = (Math.round(iSize * 100) / 100)
    		        $("#lbltamanho6").html( iSize  + "kb");
    		     }   
    });
    
    
    
});

function abreinsestenose(valvula)
{
	if(valvula == 1)
	{
		var valor = $("#aorticaEstadoUm").val();
	
		if(valor == 2 || valor == 3)
		{
			document.getElementById("aorticamorfo").style.display = 'none';
			document.getElementById("aorticainsestenose").style.display = 'block';
			document.getElementById("titulogravidade").style.display = 'block';
		}
		else if(valor == 4)
		{
			document.getElementById("aorticainsestenose").style.display = 'none';
			document.getElementById("aorticamorfo").style.display = 'block';
			document.getElementById("titulogravidade").style.display = 'block';
		}
		else
			{
				document.getElementById("aorticainsestenose").style.display = 'none';
				document.getElementById("aorticamorfo").style.display = 'none';	
			}
	}
	else if(valvula == 2)
	{
		var valor = $("#mitralEstadoUm").val();
		
		if(valor == 2 || valor == 3)
		{
			document.getElementById("mitralmorfo").style.display = 'none';
			document.getElementById("mitralestenose").style.display = 'block';
			document.getElementById("titulogravidade").style.display = 'block';
		}
		else if(valor == 4)
		{
			document.getElementById("mitralestenose").style.display = 'none';
			document.getElementById("mitralmorfo").style.display = 'block';
			document.getElementById("titulogravidade").style.display = 'block';
		}
		else
			{
				document.getElementById("mitralestenose").style.display = 'none';
				document.getElementById("mitralmorfo").style.display = 'none';
			}
	}
	else if(valvula == 3)
	{
		var valor = $("#tricuspidalEstadoUm").val();
		
		if(valor == 2 || valor == 3)
		{
			document.getElementById("tricuspidalmorfo").style.display = 'none';
			document.getElementById("tricuspidalestenose").style.display = 'block';
			document.getElementById("titulogravidade").style.display = 'block';
		}
		else if(valor == 4)
		{
			document.getElementById("tricuspidalestenose").style.display = 'none';
			document.getElementById("tricuspidalmorfo").style.display = 'block';
			document.getElementById("titulogravidade").style.display = 'block';
		}
		else
			{
				document.getElementById("tricuspidalestenose").style.display = 'none';
				document.getElementById("tricuspidalmorfo").style.display = 'none';
			}
	}
	else if(valvula == 4)
	{
		var valor = $("#pulmonarEstadoUm").val();
		
		if(valor == 2 || valor == 3)
		{
			document.getElementById("pulmonarmorfo").style.display = 'none';
			document.getElementById("pulmonarestenose").style.display = 'block';
			document.getElementById("titulogravidade").style.display = 'block';

		}
		else if(valor == 4)
		{
			document.getElementById("pulmonarestenose").style.display = 'none';
			document.getElementById("pulmonarmorfo").style.display = 'block';
			document.getElementById("titulogravidade").style.display = 'block';
		}
		else
			{
				document.getElementById("pulmonarestenose").style.display = 'none';
				document.getElementById("pulmonarmorfo").style.display = 'none';
			}
	}

	if($("#pulmonarEstadoUm").val() == 1 && $("#tricuspidalEstadoUm").val() == 1 && $("#mitralEstadoUm").val() == 1 && $("#aorticaEstadoUm").val() == 1)	
	{
		document.getElementById("titulogravidade").style.display = 'none';
	}
}

function abreseveridade()
{
	var valor = $("#morfologiatoraxico").val();
		
	if(valor == 2 || valor == 3)
		document.getElementById("grav").style.display = 'block';
	else
		document.getElementById("grav").style.display = 'none';
}

function salvartorabotao()
{
	var exame = $("#exame").is(":checked");
	var vasopressores = $("#vasopressores").is(":checked");
	var efusaoPericardial = $("#efusaoPericardial").is(":checked");
	var vizualizacao = $("#vizualizacao").is(":checked");
	var vizualizacao2 = $("#vizualizacao2").is(":checked");
	var vizualizacao3 = $("#vizualizacao3").is(":checked");
	var LVEDD = $("#LVEDD").val();
	var LVPWD = $("#LVPWD").val();
	var morfologia = $("#morfologiatoraxico").val();
	var LA = $("#LA").val();
	var LVESD = $("#LVESD").val();
	var LVPWS = $("#LVPWS").val();
	var IVSS = $("#IVSS").val();
	var LVEFS = $("#LVEFS").val();
	var IVSD = $("#IVSD").val();
	var LVEFT = $("#LVEFT").val();
	var LVFS = $("#LVFS").val();
	var LVFD = $("#LVFD").val();
	var LVWMD = $("#LVWMD").val();
	var RVESD = $("#RVESD").val();
	var RVEDD = $("#RVEDD").val();
	var RVTAPASE = $("#RVTAPASE").val();
	var RA = $("#RA").val();
	var RVF = $("#RVF").val();
	var RVM = $("#RVM").val();
	var RVD = $("#RVD").val();
	var aortaDiametro = $("#aortaDiametro").val();
	var aortaAscedente = $("#aortaAscedente").val();
	var aortaObservacoes = $("#aortaObservacoes").val();
	var MAP = $("#MAP").val();
	var CVP = $("#CVP").val();
	var aorticaEstadoUm = $("#aorticaEstadoUm").val();
	var mitralEstadoUm = $("#mitralEstadoUm").val();
	var tricuspidalEstadoUm = $("#tricuspidalEstadoUm").val();
	var pulmonarEstadoUm = $("#pulmonarEstadoUm").val();
	var notasecotoraxicoexame = $("#notasecotoraxicoexame").val();
	var BPM = $("#BPM").val();
	var severidadeve = $("#severidadeve").val();
	var viz;
	
	if(aorticaEstadoUm == 2 || aorticaEstadoUm == 3)
		var aorticaEstadoDois = $("#aorticaEstadoDoise").val();
	else if(aorticaEstadoUm == 4)
		var aorticaEstadoDois = $("#aorticaEstadoDoism").val();
	else 
		var aorticaEstadoDois = 1;

	if(mitralEstadoUm == 2 || mitralEstadoUm == 3)
		var mitralEstadoDois = $("#mitralEstadoDoise").val();
	else if(mitralEstadoUm == 4)
		var mitralEstadoDois = $("#mitralEstadoDoism").val();
	else
		var mitralEstadoDois = 1;
	
	if(tricuspidalEstadoUm == 2 || tricuspidalEstadoUm == 3)
		var tricuspidalEstadoDois = $("#tricuspidalEstadoDoise").val();
	else if(tricuspidalEstadoUm == 4)
		var tricuspidalEstadoDois = $("#tricuspidalEstadoDoism").val();
	else
		var tricuspidalEstadoDois = 1;
	
	if(pulmonarEstadoUm == 2 || pulmonarEstadoUm == 3)
		var pulmonarEstadoDois = $("#pulmonarEstadoDoise").val();
	else if(pulmonarEstadoUm == 4)
		var pulmonarEstadoDois = $("#pulmonarEstadoDoism").val();
	else
		var pulmonarEstadoDois = 1;
	
	if(vizualizacao == true)
		viz = 1;
	else if(vizualizacao2 == true)
		viz = 2;
	else
		viz = 3;
	
	if(document.getElementById("horaExametora").value.length == 0)
	{
		alertify.error('Deve escolher a hora do exame');
	}
	else
	{
		var spinner = new Spinner(opts).spin(document.getElementById('spinnergif'));
		
		var data = document.getElementById("dataExametora").value;
		var hora = document.getElementById("horaExametora").value;
		var formatodata = data+" "+hora;
	//	var d=  Date.parse(formatodata).toString('dd/MM/yyyy, HH:mm:ss');
		var d=  new Date(Date.parse(formatodata)).toString('dd/MM/yyyy, HH:mm:ss');
		$("#datahoratora").val(d);
		var datahoratora = $("#datahoratora").val();
		
		$.ajax
		({
			url: 'salvartora',
			type: 'POST',
			data:  {"datahoratora" : datahoratora, "exame" : exame, "vasopressores" : vasopressores, "efusaoPericardial" : efusaoPericardial, "vizualizacao" : viz, "LVEDD" : LVEDD, "LVPWD" : LVPWD,
				"Morfologia" : morfologia, "LA" : LA, "LVESD" : LVESD, "LVPWS" : LVPWS, "IVSS" : IVSS, "LVEFS" : LVEFS, "IVSD" : IVSD, "LVEFT" : LVEFT, "LVFS" : LVFS, "LVFD" : LVFD, "LVWMD" : LVWMD, "RVESD" : RVESD,
				"RVEDD" : RVEDD, "RVTAPASE" : RVTAPASE, "RA" : RA, "RVF" : RVF,	"RVM" : RVM, "RVD" : RVD, "aortaDiametro" : aortaDiametro, "aortaAscedente" : aortaAscedente, 
				"aortaObservacoes" : aortaObservacoes, "MAP" : MAP, "CVP" : CVP, "aorticaEstadoUm" : aorticaEstadoUm, "aorticaEstadoDois" : aorticaEstadoDois,
				"mitralEstadoUm" : mitralEstadoUm, "mitralEstadoDois" : mitralEstadoDois, "tricuspidalEstadoUm" : tricuspidalEstadoUm, 
				"tricuspidalEstadoDois" : tricuspidalEstadoDois, "pulmonarEstadoUm" : pulmonarEstadoUm, "pulmonarEstadoDois" : pulmonarEstadoDois, "BPM" : BPM, "notasecotoraxicoexame" : notasecotoraxicoexame, "severidadeve" : severidadeve},
			success: function(data, textStatus, jqXHR)
			{
				$("#statusecocardio").attr("src","resources/imagens/green-check.gif");
				alertify.success('Dados gravados com sucesso');
				spinner.stop();
			},
			error: function(jqXHR, textStatus, errorThrown) 
			{
				if(textStatus=='error'){
					alertify.error('Não foi possível completar o pedido, por favor tente novamente');
				}
				spinner.stop();
			}           
		});
	}	
}

function alterafiletoraxico()
{	
	//atualizar input nome ficheiro para possibilitar escolher nome
	var n = $('#ficheirotoraxico').val().replace(/C:\\fakepath\\/i, '');
	var nome = n.replace(/[^a-z0-9.\s]/gi, '').replace(/[_\s]/g, ' ');
	$('#nometoraxico').val(nome);
}

function uploadtoraxico(event)
{	
	$('#id_toraxico').val($('#toraxicoobj').val());
	
	if($('#nometoraxico').val()=="")
	{
		alertify.error('É necessário seleccionar um ficheiro');	
	}
	else
	{
	
	function getDoc(frame) 
	{
	     var doc = null;

	     try 
	     {
	         if (frame.contentWindow) 
	         {
	             doc = frame.contentWindow.document;
	         }
	     }
	     catch(err) 
	     {
	     }
	 
	     if (doc) 
	     {
	         return doc;
	     }
	 
	     try 
	     { 
	         doc = frame.contentDocument ? frame.contentDocument : frame.document;
	     }
	     catch(err) 
	     {
	         doc = frame.document;
	     }
	     return doc;
	 }
	$("#enviarficheirotoraxico").submit(function(e)
	{
	    var formObj = $(this);
	    var formURL = formObj.attr("action");
	   
	    if(window.FormData !== undefined)  // para browsers HTML5
	    {
	        var formData = new FormData(this);
	        var spinner = new Spinner(opts).spin(document.getElementById('spinnergif'));
	        $.ajax({
	            url: formURL,
	            type: 'POST',
	            data:  formData,
	            mimeType:"multipart/form-data",
	            contentType: false,
	            cache: false,
	            processData:false,
	            success: function(data, textStatus, jqXHR)
	            {
	 				alertify.success(data);
	 				var player2 = videojs('toraxicovid');
	 				var idtoraxico = $('#toraxicoobj').val();
	 				$.post("carreganomedoctoraxico", {'idtoraxico' : idtoraxico}, function(resposta) {
	 					player2.dispose();
	 					$("#videotoraxico").html(resposta);
	 					player2 = videojs('toraxicovid');
	 				});
	 				spinner.stop();
	            },
	            error: function(jqXHR, textStatus, errorThrown) 
	            {
	 				if(textStatus=='error')
	 				{
	 					alertify.error('Não foi possível completar o pedido, por favor tente novamente');
	 				}
	 				spinner.stop();
	            }           
	       });
	        e.preventDefault();
	      //  e.unbind();
	        e.stopImmediatePropagation();
	   }
	   else
	    {
	        //gerar um id aleatório
	        var  iframeId = 'unique' + (new Date().getTime());
	 
	        //criar um iframe vazio
	        var iframe = $('<iframe src="javascript:false;" name="'+iframeId+'" />');
	 
	        //esconder o iframe
	        iframe.hide();
	 
	        //definir o alvo do form para o iframe
	        formObj.attr('target',iframeId);
	 
	        //Adicionar o iframe ao body
	        iframe.appendTo('body');
	        iframe.load(function(e)
	        {
	            var doc = getDoc(iframe[0]);
	            var docRoot = doc.body ? doc.body : doc.documentElement;
	            var data = docRoot.innerHTML;
	        });
	 
	    }     
	});
	$("#enviarficheirotoraxico").submit();
	}
}