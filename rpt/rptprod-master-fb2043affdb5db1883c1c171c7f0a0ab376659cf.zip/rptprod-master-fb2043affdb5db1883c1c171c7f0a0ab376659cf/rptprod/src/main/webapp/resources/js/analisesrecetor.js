$(document).ready(function(){
	$('.float').keypress(function(event) {

		//só permite numeros e substitui virgulas por pontos
			if(event.which == 44){   
				//substituir virgula por ponto
		    		event.preventDefault();
		    		 if($(this).val().indexOf('.') == -1){
						$(this).val($(this).val() + '.');
		    		 }
				}else if(event.which < 46
		    || event.which > 59) {
		        event.preventDefault();
		    } 

			//permite só um ponto
		    if(event.which == 46
		    && $(this).val().indexOf('.') != -1) {
		        event.preventDefault();
		    } 
		});
	
	$('#tabelaamostrasfo').dataTable(  {
	    initComplete: function () {
	        var api = this.api();

	        api.columns().indexes().flatten().each( function ( i ) {
	            var column = api.column( i );
	            var select = $('<select><option value=""></option></select>')
	                .appendTo( $(column.footer()).empty() )
	                .on( 'change', function () {
	                    var val = $.fn.dataTable.util.escapeRegex(
	                        $(this).val()
	                    );

	                    column
	                        .search( val ? '^'+val+'$' : '', true, false )
	                        .draw();
	                } );

	            column.data().unique().sort().each( function ( d, j ) {
	                select.append( '<option value="'+d+'">'+d+'</option>' )
	            } );
	        } );
	    },
			        "language": {
	        "sProcessing":   "A processar...",
	        "sLengthMenu":   "_MENU_ registos por página",
	        "sZeroRecords":  "Não foram encontrados resultados",
	        "sInfo":         "A mostrar de _START_ até _END_ de _TOTAL_ registos",
	        "sInfoEmpty":    "A mostrar de 0 até 0 de 0 registos",
	        "sInfoFiltered": "(a filtrar de _MAX_ registos no total)",
	        "sInfoPostFix":  "",
	        "sSearch":       "Pesquisar:",
	        "sUrl":          "",
	        "oPaginate": {
	        	"sFirst":    "Primeiro",
	        	"sPrevious": "Anterior",
	        	"sNext":     "Seguinte",
	        	"sLast":     "Último"
	        }
	    }
	} );	
	
	
});
	


function tratadataamostra(){
	var data = $("#dataamostrareg").val();
	var hora = $("#horaamostrareg").val();

	var formatodata = data+" "+hora;
	
	//var d= new Date(formatodata);
	var d=  Date.parse(formatodata);
	
	if(isNaN(d)){
		alert("não tem data");
	}else{
		//alert(d.toLocaleString());
//		$("#datahoraamostrareg").val(d.toLocaleString());
		$("#datahoraamostrareg").val(formatodata);
		//(d.getFullYear())+ '-' + (d.getMonth() + 1) + '-' + (d.getDate())
	}
}


function carregaramostras(){
	

	tratadataamostra();
		
		var data = $("#datahoraamostrareg").val();

		alertify.confirm("Confirma a introdução da amostra?", function (e) {
		    if (e) {
		        // clicou "ok"
				var spinner = new Spinner(opts).spin(document.getElementById('spinnergif'));
				
				 $.ajax({
				        url: 'carreganovasanalises',
				        type: 'POST',
				        cache: false,
				        data: {"data":data},
			            success: function(data, textStatus, jqXHR)
			            {
			            	$("#pptanalises").html(data);
			 				alertify.success("inserção efectuada com sucesso");
			 					
			 				spinner.stop();
			            },
			            error: function(jqXHR, textStatus, errorThrown) 
			            {
			 				if(textStatus=='error'){
			 				//	alert("Ocorreu um erro,por favor tente novamente");
			 					alertify.error('Não foi possível completar o pedido, por favor tente novamente');
			 				//location.href="errorpage";
			 				}
			 				spinner.stop();
			            }
				    });	
		    	
		    } else {
		    	alertify.error("Processo de inserção cancelado");
		    }
		});
	
		
	
}

function editaramostra(id, nome, valor, unidades, observ, data, idamostra){
	if(unidades===""){
		unidades=0;
	}	
	
	var spinner = new Spinner(opts).spin(document.getElementById('spinnergif'));
	 $.ajax({
	        url: 'carregaunidadesamostra',
	        type: 'POST',
	        cache: false,
	        data: {"idamostra":idamostra},
        success: function(data, textStatus, jqXHR)
        {
       			$("#editunidadesamostra").replaceWith(data);
       			$("#editunidadesamostra").val(unidades);
				spinner.stop();
        },
        error: function(jqXHR, textStatus, errorThrown) 
        {
				if(textStatus=='error'){
					alertify.error('Não foi possível completar o pedido, por favor tente novamente');
			
				}
				spinner.stop();
        }
	    });
	
	$("#editidamostrafo").val(id);
	$("#editnomeamostra").val(nome);
	$("#editvaloramostra").val(valor);
	$("#editobserv").val(observ);
	$("#editdataamostra").val(data);
	$("#editidamostra").val(idamostra);
	$("#registaramostra").hide();
	$("#editaramostra").show();	
	
}

function guardaramostra(){

	var id = $("#editidamostrafo").val();
	var valor = $("#editvaloramostra").val();
	var unidades = $("#editunidadesamostra").val();
	var observacoes = $("#editobserv").val();
	var data = $("#editdataamostra").val();
	var idamostra = $("#editidamostra").val();
	
	
	if($("#editunidadesamostra").val()==0){
		
		alertify.error('É necessário seleccionar as unidades do valor');
	}else{
	//guardar e qd guardar recarregar a tabela com a função que foi usada para recarregar qd introduz novo indice de amostras
	$("#editaramostra").hide();
	$("#registaramostra").show();
	var spinner = new Spinner(opts).spin(document.getElementById('spinnergif'));
	 $.ajax({
	        url: 'alteraanalise',
	        type: 'POST',
	        cache: false,
	        data: {"id":id, "data":data, "observacoes":observacoes, "valor":valor, "idamostra":idamostra, "unidades":unidades},
         success: function(data, textStatus, jqXHR)
         {

        	 	//$("#tabelaamostrasfo").html(data);
        	 	$("#pptanalises").html(data);
        	 	
				alertify.success("inserção efectuada com sucesso");
				spinner.stop();
         },
         error: function(jqXHR, textStatus, errorThrown) 
         {
				if(textStatus=='error'){
					alertify.error('Não foi possível completar o pedido, por favor tente novamente');
				//location.href="errorpage";
				}
				spinner.stop();
         }
	    });	
	}
}

function cancelaguardaramostra(){
	$("#registaramostra").show();
	$("#editaramostra").hide();			
}
