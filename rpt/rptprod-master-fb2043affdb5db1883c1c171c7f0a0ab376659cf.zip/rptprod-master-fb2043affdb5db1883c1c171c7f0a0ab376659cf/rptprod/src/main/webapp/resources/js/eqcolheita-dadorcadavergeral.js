$(document).ready(function() {
	
	
	 jQuery("#dcd1").add("#dct1").add("#dcu1").click(function() 
			  {
			  jQuery("#dcgeral").toggle("fast");
			  jQuery("#dcu1").toggle();
			  jQuery("#dcd1").toggle();
			  });
	 
	 jQuery("#dcd2").add("#dct2").add("#dcu2").click(function() 
			  {
			  jQuery("#dcrins").toggle("fast");
			  jQuery("#dcu2").toggle();
			  jQuery("#dcd2").toggle();
			  });
	 
	 jQuery("#dcd3").add("#dct3").add("#dcu3").click(function() 
			  {
			  jQuery("#dcpancreas").toggle("fast");
			  jQuery("#dcu3").toggle();
			  jQuery("#dcd3").toggle();
			  });
	 
	 jQuery("#dcd4").add("#dct4").add("#dcu4").click(function() 
			  {
			  jQuery("#dcfigado").toggle("fast");
			  jQuery("#dcu4").toggle();
			  jQuery("#dcd4").toggle();
			  });
	 
	 jQuery("#dcd5").add("#dct5").add("#dcu5").click(function() 
			  {
			  jQuery("#dccoracao").toggle("fast");
			  jQuery("#dcu5").toggle();
			  jQuery("#dcd5").toggle();
			  });
	
	 jQuery("#dcd6").add("#dct6").add("#dcu6").click(function() 
			  {
			  jQuery("#dcpulmoes").toggle("fast");
			  jQuery("#dcu6").toggle();
			  jQuery("#dcd6").toggle();
			  });

	 jQuery("#dcd7").add("#dct7").add("#dcu7").click(function() 
			  {
			  jQuery("#dccorneas").toggle("fast");
			  jQuery("#dcu7").toggle();
			  jQuery("#dcd7").toggle();
			  });


	 jQuery("#dcd8").add("#dct8").add("#dcu8").click(function() 
			  {
			  jQuery("#dcpele").toggle("fast");
			  jQuery("#dcu8").toggle();
			  jQuery("#dcd8").toggle();
			  });	
	
	 jQuery("#dcd9").add("#dct9").add("#dcu9").click(function() 
			  {
			  jQuery("#dctc").toggle("fast");
			  jQuery("#dcu9").toggle();
			  jQuery("#dcd9").toggle();
			  });
	 
	 jQuery("#dcd10").add("#dct10").add("#dcu10").click(function() 
			  {
			  jQuery("#dctme").toggle("fast");
			  jQuery("#dcu10").toggle();
			  jQuery("#dcd10").toggle();
			  });
	 
	 jQuery("#dcd11").add("#dct11").add("#dcu11").click(function() 
			  {
			  jQuery("#dcvasos").toggle("fast");
			  jQuery("#dcu11").toggle();
			  jQuery("#dcd11").toggle();
			  });
});