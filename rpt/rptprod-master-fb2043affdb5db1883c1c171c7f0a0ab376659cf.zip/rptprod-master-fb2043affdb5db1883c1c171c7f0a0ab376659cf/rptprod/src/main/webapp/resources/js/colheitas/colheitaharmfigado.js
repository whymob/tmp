$('.float').keypress(function(event) {
	
	var charCode = (event.which) ? event.which : event.keyCode;

	if(charCode == 44){   
		//substituir virgula por ponto
    		event.preventDefault();
    		 if($(this).val().indexOf('.') == -1){
				$(this).val($(this).val() + '.');
    		 }
		}else if(charCode==8){
		//apagar
		}else if(charCode < 46 
    || charCode > 59) {
	
        event.preventDefault();
    } 

	//permite só um ponto
    if(charCode == 46
    && $(this).val().indexOf('.') != -1) {
        event.preventDefault();
    } 
});

function registahorasfigado(tipo){
	
	var spinner = new Spinner(opts).spin(document.getElementById('spinnergif'));
	 $.ajax({
	        url: 'registahorasfigado',
	        type: 'POST',
	        cache: false,
	        data:  {"tipo" : tipo},
          success: function(data, textStatus, jqXHR)
          {
        	  var d = Date.parse(data).toString('dd/MM/yyyy HH:mm');
        	  
        	  if(tipo==1){
        		  $("#iniciofigado").html(d);    
        	  }else if(tipo==2){
        		  $("#fimfigado").html(d);	  
        	  }
				spinner.stop();
          },
          error: function(jqXHR, textStatus, errorThrown) 
          {

				alertify.error('Não foi possível completar o pedido, por favor tente novamente');
				spinner.stop();
          }
	    });
}

function gravaharmoniofigado(){
	
	var coddador = $("#dadorcod").text();
	var estadofigado = $("#estadofigado").val();
	
	$("#figadocod").val("");
	$("#lblcodfigado").text("");
	
	if(estadofigado!=3 && estadofigado!=0){
	$("#figadocod").val(coddador+"-FI");
	$("#lblcodfigado").text(coddador+"-FI");
	}
	
	var spinner = new Spinner(opts).spin(document.getElementById('spinnergif'));
	 $.ajax({
	        url: 'gravacolheitaharmoniofigado',
	        type: 'POST',
	        cache: false,
	        data: $("#formfigado").serialize(),
         success: function(data, textStatus, jqXHR)
         {

        	 alertify.success("Dados gravados com sucesso!");
				spinner.stop();
         },
         error: function(jqXHR, textStatus, errorThrown) 
         {
				if(textStatus=='error'){
				//	alert("Ocorreu um erro,por favor tente novamente");
					alertify.error('Não foi possível completar o pedido, por favor tente novamente');
				//location.href="errorpage";
				}
			spinner.stop();
         }
	    });	
}

function figadoalteraestado(estado){
	
	if(estado==1){
		var frase = "validado";
	}else if(estado==2){
		
		var frase = "condicional";
	}else if(estado==3){
		var frase = "não validado";
	}
		
		alertify.confirm("Confirma a alteração do estado do orgão para "+frase+"?", function (e) {
		    if (e) {
					var spinner = new Spinner(opts).spin(document.getElementById('spinnergif'));
					 $.ajax({
					        url: 'gravacolheitaestadofigado',
					        type: 'POST',
					        cache: false,
					        data: {"estado": estado},
				         success: function(data, textStatus, jqXHR)
				         {
				        	 if(data=='OK'){
						        	 if(estado==1){
							        		 $("#divestadofigado").html("<label style=\"color: green;\"><b>Orgão válido </b></label><img alt=\"Orgão validado\" src=\"resources/imagens/green-check.gif\" style=\"width: 20px; height: 20px; vertical-align: bottom;\">");
							        		 $("#estadofigado").val(1);
						        	 }else if(estado==2){
							        		 $("#divestadofigado").html("<label style=\"color: orange;\"><b>Orgão estado condicional </b></label><img alt=\"Orgão estado condicional\" src=\"resources/imagens/warning.png\" style=\"width: 20px; height: 20px; vertical-align: bottom;\">");
							        		 $("#estadofigado").val(2);
						        	 }
						        	 else if(estado==3){
							        		 $("#divestadofigado").html("<label style=\"color: red;\"><b>Orgão não válido </b></label><img alt=\"Orgão não válido\" src=\"resources/imagens/SA1.png\" style=\"width: 20px; height: 20px; vertical-align: bottom;\">");
							        		 $("#estadofigado").val(3);
						        	 }
						        	 
						        	 var coddador = $("#dadorcod").text();
						        		var estadofigado = $("#estadofigado").val();
						        		
						        		$("#figadocod").val("");
						        		$("#lblcodfigado").text("");
						        		
						        		if(estadofigado!=3 && estadofigado!=0){
						        		$("#figadocod").val(coddador+"-FI");
						        		$("#lblcodfigado").text(coddador+"-FI");
						        		}
						        		
						        		
						        		 $.ajax({
						        		        url: 'gravacolheitaharmoniofigado',
						        		        type: 'POST',
						        		        cache: false,
						        		        data: $("#formfigado").serialize(),
						        	         success: function(data, textStatus, jqXHR)
						        	         {

						        	        	 alertify.success("Estado do figado alterado com sucesso!");
						        					spinner.stop();
						        	         },
						        	         error: function(jqXHR, textStatus, errorThrown) 
						        	         {
						        					if(textStatus=='error'){
						        					//	alert("Ocorreu um erro,por favor tente novamente");
						        						alertify.error('Não foi possível completar o pedido, por favor tente novamente');
						        					//location.href="errorpage";
						        					}
						        				spinner.stop();
						        	         }
						        		    });
						        	 
						        	 
				        	 }
								spinner.stop();
				         },
				         error: function(jqXHR, textStatus, errorThrown) 
				         {
								if(textStatus=='error'){
								//	alert("Ocorreu um erro,por favor tente novamente");
									alertify.error('Não foi possível completar o pedido, por favor tente novamente');
								//location.href="errorpage";
								}
							spinner.stop();
				         }
					    });	
		    } else {
		    	alertify.error("Processo cancelado");
		    }
		});
	
}


//-------------------------Inicio Tabela perfusao figado-----------------------------------------------//
function adicionaperffigado(){
	
	var perfusao = $("#regperffigadoperfusao").val();
	var tipo = $("#regperffigadotipo").val();
	//var via = $("#regperfabdomvia").val();
	var volume = $("#regperffigadovolume").val();
	var inicio = $("#regperffigadoinicio").val();
	var fim = $("#regperffigadofim").val();
	var qualidade = $("#regperffigadoqualidade").val();
	var lote = $("#regperffigadolote").val();
	var teste = $("#regperffigadoteste").is(":checked");
	
	
	var spinner = new Spinner(opts).spin(document.getElementById('spinnergif'));
	 $.ajax({
	        url: 'adicionaperfharmoniofigado',
	        type: 'POST',
	        cache: false,
	        data: {"perfusao" : perfusao, "tipo" : tipo, "volume" : volume, "inicio" : inicio, "fim" : fim, "qualidade" : qualidade, "lote" : lote, "teste" : teste},
        success: function(data, textStatus, jqXHR)
        {
        	$("#tabperfusaofigado tr:last").after(data);
        	cancelagravaperffigado();
        	
       	 alertify.success("Dados gravados com sucesso!");
				spinner.stop();
        },
        error: function(jqXHR, textStatus, errorThrown) 
        {
				if(textStatus=='error'){
				//	alert("Ocorreu um erro,por favor tente novamente");
					alertify.error('Não foi possível completar o pedido, por favor verifique se todos os campos estão preenchidos corretamente.');
				//location.href="errorpage";
				}
			spinner.stop();
        }
	    });	
}

function cancelagravaperffigado(){
	$("#divregperffigado input").val("");
	$("#divregperffigado select").val(1);
	$("#regperffigadoteste").prop('checked', false);
	$("#diveditperffigado").fadeOut(function(){
		$("#divregperffigado").fadeIn();	
	});
}

function editperffigado(idperffigado, perfusao, tipo, qualidade, teste, event){
	
	$("#editidperffigado").val(idperffigado);
	$("#editperffigadoperfusao").val(perfusao);
	$("#editperffigadotipo").val(tipo);
	//$("#editperfabdomvia").val(via);
	$("#editerffigadovolume").val($(event).closest("tr").find('td:eq(2)').text());
	$("#editperffigadoinicio").val($(event).closest("tr").find('td:eq(3)').text());
	$("#editperffigadofim").val($(event).closest("tr").find('td:eq(4)').text());
	$("#editperffigadoqualidade").val(qualidade);
	$("#editperffigadolote").val($(event).closest("tr").find('td:eq(6)').text());
	$("#editperffigadoteste").prop('checked', teste);

	
	$("#divregperffigado").fadeOut(function(){
		$("#diveditperffigado").fadeIn();	
	});
	
}


function gravaperffigado(){
	
	var idperffigado = 	$("#editidperffigado").val();
	var perfusao = $("#editperffigadoperfusao").val();
	var tipo = $("#editperffigadotipo").val();
	//var via = $("#editperfabdomvia").val();
	var volume = $("#editerffigadovolume").val();
	var inicio = $("#editperffigadoinicio").val();
	var fim = $("#editperffigadofim").val();
	var qualidade = $("#editperffigadoqualidade").val();
	var lote = $("#editperffigadolote").val();
	var teste = $("#editperffigadoteste").is(":checked");

	
	var spinner = new Spinner(opts).spin(document.getElementById('spinnergif'));
	 $.ajax({
	        url: 'gravaperfharmoniofigado',
	        type: 'POST',
	        cache: false,
	        data: {"idperffigado" : idperffigado, "perfusao" : perfusao, "tipo" : tipo, "volume" : volume, "inicio" : inicio, "fim" : fim, "qualidade" : qualidade, "lote" : lote, "teste" : teste},
       success: function(data, textStatus, jqXHR)
       {
    	   
    	   
    	   //alterar linha
    	   $("#perffigado_"+idperffigado).replaceWith(data);
    	   
       //	$("#tabterapgeral tr:last").after(data);
    	   cancelagravaperffigado();
      	 alertify.success("Dados gravados com sucesso!");
				spinner.stop();
       },
       error: function(jqXHR, textStatus, errorThrown) 
       {
				if(textStatus=='error'){
				//	alert("Ocorreu um erro,por favor tente novamente");
					alertify.error('Não foi possível completar o pedido, por favor tente novamente');
				//location.href="errorpage";
				}
			spinner.stop();
       }
	    });	
}



function delperffigado(idperffigado, event){
	
	alertify.confirm("Confirma a eliminação  da perfusão "+$(event).closest("tr").find('td:eq(0)').text()+"?", function (e) {
	    if (e) {
			var spinner = new Spinner(opts).spin(document.getElementById('spinnergif'));
			$.ajax
			({
				url: 'delperffigado',
				type: 'POST',
				data:  {"idperffigado" : idperffigado},
				success: function(data, textStatus, jqXHR)
				{
					//  $("#tabcomorbilidades").html(data);
					 $("#perffigado_"+idperffigado).remove();
					 cancelagravaperffigado();
					  alertify.success('Perfusão eliminada com sucesso');
					  spinner.stop();
				},
				error: function(jqXHR, textStatus, errorThrown) 
				{
					if(textStatus=='error'){
						alertify.error('Não foi possível completar o pedido, por favor tente novamente');
					}
					  spinner.stop();
				} 
			});	
	    }
	else {
    	alertify.error("Processo de eliminação cancelado");
    }
});
	
}

//-------------------------Fim Tabela perfusao figado-----------------------------------------------//