$(document).ready(function() {
	
	
	 
	 jQuery("#d41").add("#t41").add("#u41").click(function() 
			  {
			  jQuery("#transf").toggle("fast");
			  jQuery("#u31").toggle();
			  jQuery("#d31").toggle();
			  });
	 
	 jQuery("#d42").add("#t42").add("#u42").click(function() 
			  {
			  jQuery("#terapeut").toggle("fast");
			  jQuery("#u42").toggle();
			  jQuery("#d42").toggle();
			  });
	 
	
});