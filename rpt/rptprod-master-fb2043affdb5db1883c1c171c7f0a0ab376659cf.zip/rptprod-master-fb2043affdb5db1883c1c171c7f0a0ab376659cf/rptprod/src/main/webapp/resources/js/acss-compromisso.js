/**
 * Script Página IPST
 */

$(document).ready(function() {
    $('#tabelacompromissogeral').dataTable(  {
        initComplete: function () {
            var api = this.api();
 
            api.columns().indexes().flatten().each( function ( i ) {
                var column = api.column( i );
                var select = $('<select style="max-width: 77px; margin:auto;"><option value=""></option></select>')
                    .appendTo( $(column.footer()).empty() )
                    .on( 'change', function () {
                        var val = $.fn.dataTable.util.escapeRegex(
                            $(this).val()
                        );
 
                        column
                            .search( val ? '^'+val+'$' : '', true, false )
                            .draw();
                    } );
 
                column.data().unique().sort().each( function ( d, j ) {
                    select.append( '<option value="'+d+'">'+d+'</option>' )
                } );
            } );
        },
		        "language": {
            "sProcessing":   "A processar...",
            "sLengthMenu":   "_MENU_ registos por página",
            "sZeroRecords":  "Não foram encontrados resultados",
            "sInfo":         "A mostrar de _START_ até _END_ de _TOTAL_ registos",
            "sInfoEmpty":    "A mostrar de 0 até 0 de 0 registos",
            "sInfoFiltered": "(a filtrar de _MAX_ registos no total)",
            "sInfoPostFix":  "",
            "sSearch":       "Pesquisar:",
            "sUrl":          "",
            "oPaginate": {
            	"sFirst":    "Primeiro",
            	"sPrevious": "Anterior",
            	"sNext":     "Seguinte",
            	"sLast":     "Último"
            }
        }
    
    
} );
   
  $("#tabelacompromissogeral_length").css({"borderTopWidth": "0", "borderRightWidth": "0" , "borderBottomWidth": "0", "borderLeftWidth": "0"});
  
  $('#tabelacompromissodetalhe').dataTable(  {
      initComplete: function () {
          var api = this.api();

          api.columns().indexes().flatten().each( function ( i ) {
              var column = api.column( i );
              var select = $('<select style="max-width: 77px; margin:auto;"><option value=""></option></select>')
                  .appendTo( $(column.footer()).empty() )
                  .on( 'change', function () {
                      var val = $.fn.dataTable.util.escapeRegex(
                          $(this).val()
                      );

                      column
                          .search( val ? '^'+val+'$' : '', true, false )
                          .draw();
                  } );

              column.data().unique().sort().each( function ( d, j ) {
                  select.append( '<option value="'+d+'">'+d+'</option>' )
              } );
          } );
      },
		        "language": {
          "sProcessing":   "A processar...",
          "sLengthMenu":   "_MENU_ registos por página",
          "sZeroRecords":  "Não foram encontrados resultados",
          "sInfo":         "A mostrar de _START_ até _END_ de _TOTAL_ registos",
          "sInfoEmpty":    "A mostrar de 0 até 0 de 0 registos",
          "sInfoFiltered": "(a filtrar de _MAX_ registos no total)",
          "sInfoPostFix":  "",
          "sSearch":       "Pesquisar:",
          "sUrl":          "",
          "oPaginate": {
          	"sFirst":    "Primeiro",
          	"sPrevious": "Anterior",
          	"sNext":     "Seguinte",
          	"sLast":     "Último"
          }
      },"bPaginate": false
  
  
} );
 
$("#tabelacompromissodetalhe_length").css({"borderTopWidth": "0", "borderRightWidth": "0" , "borderBottomWidth": "0", "borderLeftWidth": "0"});
} );

function cancelaobscomp()
{
	document.getElementById("alteranotas").style.display = 'none';
	document.getElementById("labeltodos").style.display = 'block';
	document.getElementById("cabecomp").style.display = 'block';
	document.getElementById("botcomp").style.display = 'block';
	
	$("#idacsscomp").val("");
	$("#obscomp").val("");
}

function abreedit(id, obs)
{
	document.getElementById("alteranotas").style.display = 'block';
	document.getElementById("labeltodos").style.display = 'none';
	document.getElementById("cabecomp").style.display = 'none';
	document.getElementById("botcomp").style.display = 'none';

	$("#idacsscomp").val(id);
	$("#obscomp").val(obs);
}

function salvaobscomp()
{
	var obs = $("#obscomp").val();
	var id = $("#idacsscomp").val();
	
	if(obs.length == 0)
	{
		alertify.error('Deve preencher as observações para guardar');
		return;
	}
		
	var spinner = new Spinner(opts).spin(document.getElementById('spinnergif'));
	
	 $.ajax({
	        url: 'guardaobscomp',
	        type: 'POST',
	        cache: false,
	        data: {"obs":obs, "id":id},
           success: function(data, textStatus, jqXHR)
           {
        	    $("#linhaatoscomp_"+id).replaceWith(data);
        	   
        	    document.getElementById("alteranotas").style.display = 'none';
        		document.getElementById("labeltodos").style.display = 'block';
        		document.getElementById("cabecomp").style.display = 'block';
        		document.getElementById("botcomp").style.display = 'block';
           	
           	    spinner.stop();
           },
           error: function(jqXHR, textStatus, errorThrown) 
           {
				if(textStatus=='error')
					alertify.error('Não foi possível completar o pedido, por favor tente novamente');
				spinner.stop();
           }
	    });	
}

function cancelarcompromisso()
{
	$("#datacomp").val("");
	$("#entidadeinputcomp").val(0);
	$("#numcomp").val("");
	
	var oTable = document.getElementById('tabelacompromissodetalhe');
	var rowLength = oTable.rows.length;

	for (i = 1; i < rowLength-1; i++)
	{
	   var oCells = oTable.rows.item(i).cells;
	   var cellVal = oCells.item(6).children[0];

	   $(cellVal).prop("checked", false);
	}
	
	$('#todos').prop("checked", false);
}

function filtraatos()
{
	var spinner = new Spinner(opts).spin(document.getElementById('spinnergif'));
	
	$.ajax({
        url: 'filtraatos',
        type: 'POST',
        cache: false,
        data: {"nomeentidade": $("#entidadeinputcomp").val()},
      success: function(data, textStatus, jqXHR)
      {
    	  $("#divcompromissodetalhe").html(data);
      	 
      	  spinner.stop();
      },
      error: function(jqXHR, textStatus, errorThrown) 
      {
			if(textStatus=='error')
				alertify.error('Não foi possível completar o pedido, por favor tente novamente');
			spinner.stop();
      }
	});
	
	$("#totalvalorcompromissos").val(0);
}

function marcatodos()
{
	if($('#todos').is(':checked'))
	{
		var oTable = document.getElementById('tabelacompromissodetalhe');
		var rowLength = oTable.rows.length;
		var total = 0;
		
		for (i = 1; i < rowLength-1; i++)
		{
		   var oCells = oTable.rows.item(i).cells;
		   var cellVal = oCells.item(6).children[0];
		   var valor = oTable.rows[this.i].cells[1].innerHTML;

		   total = total+parseFloat(valor);
		   
		   $(cellVal).prop("checked", true);
		}
		
		$("#totalvalorcompromissos").val(parseFloat(total.toFixed(2)));
	}
	else
	{
		var oTable = document.getElementById('tabelacompromissodetalhe');
		var rowLength = oTable.rows.length;

		for (i = 1; i < rowLength-1; i++)
		{
		   var oCells = oTable.rows.item(i).cells;
		   var cellVal = oCells.item(6).children[0];

		   $(cellVal).prop("checked", false);
		}
		
		$("#totalvalorcompromissos").val(0);
	}
}

function determinavalor(id, valor)
{
	$('#todos').prop("checked", false);
	
	var total = $("#totalvalorcompromissos").val();
	var totalfinal = 0;
	
	if(total.length == 0)
		total = 0;
	
	if($("#selcomp_"+id).is(':checked'))
	{
		totalfinal = parseFloat(total)+parseFloat(valor);
	}
	else
		totalfinal = parseFloat(total)-parseFloat(valor);
	
	$("#totalvalorcompromissos").val(parseFloat(totalfinal.toFixed(2)));
}

function criarcompromisso()
{
	var entidadeinputcomp = $("#entidadeinputcomp").val();
	var datacomp = $("#datacomp").val();
	var numcomp = $("#numcomp").val();
	var total = $("#totalvalorcompromissos").val();
	
	var oTable = document.getElementById('tabelacompromissodetalhe');
	var rowLength = oTable.rows.length;
	
	var aux = "";
	var total = 0;

	for (i = 1; i < rowLength-1; i++)
	{
	   var oCells = oTable.rows.item(i).cells;
	   var cellVal = oCells.item(6).children[0];
		   
	   var id = oTable.rows[this.i].cells[7].innerHTML;
	   var valor = oTable.rows[this.i].cells[1].innerHTML;

	   if($(cellVal).is(':checked'))
	   {
		   total = total+parseFloat(valor);
		   
		   if(aux.length == 0)
			   aux = id;
		   else
			   aux = aux+", "+id;
	   }
	   else
		   continue;
	}
	
	if(total == 0)
	{
		alertify.error('Não há atos para criar compromisso');
		return;
	}

	if(numcomp.length == 0 || datacomp.length == 0)
	{
		alertify.error('Deve preencher os campos todos');
		return;
	}
	
	alertify.confirm("Confirma criar compromisso?", function (e) 
	{
	    if (e) 
	    {
			var spinner = new Spinner(opts).spin(document.getElementById('spinnergif'));

			 $.ajax({
			        url: 'criacompromisso',
			        type: 'POST',
			        cache: false,
			        data: {"valor":total, "compromisso":numcomp, "data": datacomp, "entidade":entidadeinputcomp, "atos":aux},
		          success: function(data, textStatus, jqXHR)
		          {
		        	  $("#separadortabcompromisso").html(data);
		        	  
		        	  $.ajax({
		        	        url: 'filtraatosnovos',
		        	        type: 'POST',
		        	        cache: false,
		        	      success: function(data, textStatus, jqXHR)
		        	      {
		        	    	  $("#divcompromissodetalhe").html(data);
		        	      	 
		        	    	  alertify.success("Compromisso criado com sucesso");
		        	    	  
		        	      	  spinner.stop();
		        	      },
		        	      error: function(jqXHR, textStatus, errorThrown) 
		        	      {
		        				if(textStatus=='error')
		        					alertify.error('Não foi possível completar o pedido, por favor tente novamente');
		        				spinner.stop();
		        	      }
		        	 });
		        	  
		        	 $("#datacomp").val("");
		        	 $("#entidadeinputcomp").val(0);
		        	 $("#numcomp").val("");
		        	 $("#totalvalorcompromissos").val(0);
		          },
		          error: function(jqXHR, textStatus, errorThrown) 
		          {
						if(textStatus=='error')
							alertify.error('Não foi possível completar o pedido, por favor tente novamente');
						spinner.stop();
		          }
			 });
	    }
	});
}

/*function salvacompunico()
{
	var entidadeinputcompunico = $("#entidadeinputcompunico").val();
	var datacompunico = $("#datacompunico").val();
	var numcompunico = $("#numcompunico").val();
	var valorcompunico = $("#valorcompunico").val();
	
	if(numcompunico.length == 0 || valorcompunico.length == 0)
	{
		alertify.error('Deve preencher os campos todos');
		return;
	}
	
	alertify.confirm("Confirma criar compromisso?", function (e) 
	{
	    if (e) 
	    {
			var spinner = new Spinner(opts).spin(document.getElementById('spinnergif'));

			 $.ajax({
			        url: 'criacompromissounico',
			        type: 'POST',
			        cache: false,
			        data: {"valor":valorcompunico, "compromisso":numcompunico, "data": datacompunico, "identidade":entidadeinputcompunico},
		          success: function(data, textStatus, jqXHR)
		          {
		        	  $("#separadortabcompromisso").html(data);
		        	  
		        	  cancelacompunico();
		          },
		          error: function(jqXHR, textStatus, errorThrown) 
		          {
						if(textStatus=='error')
							alertify.error('Não foi possível completar o pedido, por favor tente novamente');
						spinner.stop();
		          }
			 });
	    }
	});
}*/

/*function abrecompromissounico()
{
	document.getElementById("divnovocompromisso").style.display = 'none';
	document.getElementById("separadortabcompromisso").style.display = 'none';
	document.getElementById("separadorcompromissounico").style.display = 'block';
}*/

/*function cancelacompunico()
{
	 $("#entidadeinputcompunico").val(0);
	 $("#datacompunico").val("");
	 $("#numcompunico").val("");
	 $("#valorcompunico").val("");
	
	document.getElementById("separadorcompromissounico").style.display = 'none';
	document.getElementById("divnovocompromisso").style.display = 'block';
	document.getElementById("separadortabcompromisso").style.display = 'block';
}*/