$(document).ready(function(){
	$('.float').keypress(function(event) {

		//só permite numeros e substitui virgulas por pontos
			if(event.which == 44){   
				//substituir virgula por ponto
		    		event.preventDefault();
		    		 if($(this).val().indexOf('.') == -1){
						$(this).val($(this).val() + '.');
		    		 }
				}else if(event.which < 46
		    || event.which > 59) {
		        event.preventDefault();
		    } 

			//permite só um ponto
		    if(event.which == 46
		    && $(this).val().indexOf('.') != -1) {
		        event.preventDefault();
		    } 
		});

	$('#tabelaamostrasfo').dataTable(  {
	    initComplete: function () {
	        var api = this.api();

	        api.columns().indexes().flatten().each( function ( i ) {
	            var column = api.column( i );
	            var select = $('<select><option value=""></option></select>')
	                .appendTo( $(column.footer()).empty() )
	                .on( 'change', function () {
	                    var val = $.fn.dataTable.util.escapeRegex(
	                        $(this).val()
	                    );

	                    column
	                        .search( val ? '^'+val+'$' : '', true, false )
	                        .draw();
	                } );

	            column.data().unique().sort().each( function ( d, j ) {
	                select.append( '<option value="'+d+'">'+d+'</option>' )
	            } );
	        } );
	    },
			        "language": {
	        "sProcessing":   "A processar...",
	        "sLengthMenu":   "_MENU_ registos por página",
	        "sZeroRecords":  "Não foram encontrados resultados",
	        "sInfo":         "A mostrar de _START_ até _END_ de _TOTAL_ registos",
	        "sInfoEmpty":    "A mostrar de 0 até 0 de 0 registos",
	        "sInfoFiltered": "(a filtrar de _MAX_ registos no total)",
	        "sInfoPostFix":  "",
	        "sSearch":       "Pesquisar:",
	        "sUrl":          "",
	        "oPaginate": {
	        	"sFirst":    "Primeiro",
	        	"sPrevious": "Anterior",
	        	"sNext":     "Seguinte",
	        	"sLast":     "Último"
	        }
	    }
	} );
	
});
	
	
	
	



function tratadataamostra(){
	var data = $("#dataamostrareg").val();
	var hora = $("#horaamostrareg").val();

	var formatodata = data+" "+hora;
	
	//var d= new Date(formatodata);
	var d=  Date.parse(formatodata);
	
	if(isNaN(d)){
		alert("não tem data");
	}else{
		//alert(d.toLocaleString());
//		$("#datahoraamostrareg").val(d.toLocaleString());
		$("#datahoraamostrareg").val(formatodata);
		//(d.getFullYear())+ '-' + (d.getMonth() + 1) + '-' + (d.getDate())
	}
}

function gravafo(){
	
	var spinner = new Spinner(opts).spin(document.getElementById('spinnergif'));
	 $.ajax({
	        url: 'gravadivfo',
	        type: 'POST',
	        cache: false,
	        data: $("#formfo").serialize(),
           success: function(data, textStatus, jqXHR)
           {
        	   $("#statusfo").attr("src","resources/imagens/green-check.gif");
				spinner.stop();
           },
           error: function(jqXHR, textStatus, errorThrown) 
           {
				if(textStatus=='error'){
				//	alert("Ocorreu um erro,por favor tente novamente");
					alertify.error('Não foi possível completar o pedido, por favor tente novamente');
				//location.href="errorpage";
				}
			spinner.stop();
           }
	    });
	
}

function existe(textInput){
	
	
var flag = false;
	
	$.each($("#tabelaamostrasfo tbody tr").find("td:eq(1)"), function() {
		
		
		 if ($(this).text() == textInput) {
	           flag = true;
	        } 
		         
    });
return flag;
	
}


function carregaramostras(){
	
	//formatar e carregar data completa para caixa data escondida
	tratadataamostra();
	
	var amostra = $("#amostraintroduzir").val();
	
	if(amostra == "0"){
		//alert("É necessário seleccionar uma amostra a introduzir");
		alertify.error("É necessário seleccionar um índice de amostras a registar");
	}else{	
	//alert("Verifica valores e carrega amostra: " + amostra);
		
		var data = $("#datahoraamostrareg").val();
		var nome = $("#amostraintroduzir option:selected").text();
		
		if(existe(nome)){
			alertify.error("Já foi introduzido esse indice de amostra");
		}else{
		// confirmar introdução
		alertify.confirm("Confirma a introdução da amostra "+nome, function (e) {
		    if (e) {
		        // clicou "ok"
				var spinner = new Spinner(opts).spin(document.getElementById('spinnergif'));
				
				 $.ajax({
				        url: 'addamostratabela',
				        type: 'POST',
				        cache: false,
				        data: {"amostra" : amostra, "data":data, "nome": nome},
			            success: function(data, textStatus, jqXHR)
			            {
			            	//$("#tabelaamostrasfo").html(data);
			            	$("#funcorgao").html(data);
			            	$("#statusfo").attr("src","resources/imagens/green-check.gif");
			            	/*$.post("carregacomboamostras", function(resposta) {
			        			$("#comboamostras").html(resposta);
			        		});
			        	 	$("#maxamostra").text("0");
			        	 	$("#minamostra").text("0.00");
			        	 	$("#mediaamostra").text("0");*/
			        	 	$("#statusfo").attr("src","resources/imagens/green-check.gif");
			 				alertify.success("inserção efectuada com sucesso");
			 				
			 				//controlo da combo hemodiluição para recarregar se forem adicionadas amostras
			 				if($("#ctrlcombohemodiluicao").val()=="1"){
			 					$.post("loadcombohemotransf",  function(resposta) {
			 						$("#hemoamostras").replaceWith(resposta);
			 						//$("#hemoamostras").html(resposta);
//			 						$("#listahemo").replaceWith(resposta);
			 						spinner.stop();
			 						//$("#ctrlcombohemodiluicao").val("0");
			 					});
			 				}
			 					
			 				spinner.stop();
			            },
			            error: function(jqXHR, textStatus, errorThrown) 
			            {
			 				if(textStatus=='error'){
			 				//	alert("Ocorreu um erro,por favor tente novamente");
			 					alertify.error('Não foi possível completar o pedido, por favor tente novamente');
			 				//location.href="errorpage";
			 				}
			 				spinner.stop();
			            }
				    });	
		    	
		    } else {
		    	alertify.error("Processo de inserção cancelado");
		    }
		});
	
		}
	}
}



function calculaamostras(){
	
	if($("#comboamostrasvalor").val()==0){
	//1º campo não pesquisar
	}else{
		
	var amostra = $("#comboamostrasvalor").val();
	var spinner = new Spinner(opts).spin(document.getElementById('spinnergif'));
	 $.ajax({
	        url: 'calcminimoamostra',
	        type: 'POST',
	        cache: false,
	        data: {"amostra" : amostra},
         success: function(data, textStatus, jqXHR)
         {
         	//$("#tabelaamostrasfo").html(data);
         	//$.post("carregacomboamostras", function(resposta) {
     		//	$("#comboamostras").html(resposta);
     		//});
         	$("#minamostra").text(data);
				spinner.stop();
         	
         	//calcula maximo
         	
         	
         },
         error: function(jqXHR, textStatus, errorThrown) 
         {
				if(textStatus=='error'){
				//	alert("Ocorreu um erro,por favor tente novamente");
					alertify.error('Não foi possível completar o pedido, por favor tente novamente');
				//location.href="errorpage";
				}
				spinner.stop();
         }
	    });	
	
   	 $.ajax({
	        url: 'calcmaxamostra',
	        type: 'POST',
	        cache: false,
	        data: {"amostra" : amostra},
    success: function(data, textStatus, jqXHR)
    {
    	//$("#tabelaamostrasfo").html(data);
    	//$.post("carregacomboamostras", function(resposta) {
		//	$("#comboamostras").html(resposta);
		//});
    	$("#maxamostra").text(data);
				spinner.stop();
    },
    error: function(jqXHR, textStatus, errorThrown) 
    {
				if(textStatus=='error'){
				//	alert("Ocorreu um erro,por favor tente novamente");
					alertify.error('Não foi possível completar o pedido, por favor tente novamente');
				//location.href="errorpage";
				}
				spinner.stop();
    }
	    });	
   	 
   	 $.ajax({
	        url: 'calcmediaamostra',
	        type: 'POST',
	        cache: false,
	        data: {"amostra" : amostra},
    success: function(data, textStatus, jqXHR)
    {
    	//$("#tabelaamostrasfo").html(data);
    	//$.post("carregacomboamostras", function(resposta) {
		//	$("#comboamostras").html(resposta);
		//});
    	var valor = parseFloat(data).toFixed(1);
    	//var valor = parseInt(data);
    	//$("#mediaamostra").text(data);
    	$("#mediaamostra").text(valor);
				spinner.stop();
    },
    error: function(jqXHR, textStatus, errorThrown) 
    {
				if(textStatus=='error'){
				//	alert("Ocorreu um erro,por favor tente novamente");
					alertify.error('Não foi possível completar o pedido, por favor tente novamente');
				//location.href="errorpage";
				}
				spinner.stop();
    }
	    });	
	
	}
}

function editaramostra(id, nome, tipo, valor, unidades, observ, data, idtipo, idamostra){
	if(unidades===""){
		unidades=0;
	}	
	
	var spinner = new Spinner(opts).spin(document.getElementById('spinnergif'));
	 $.ajax({
	        url: 'carregaunidadesamostra',
	        type: 'POST',
	        cache: false,
	        data: {"idamostra":idamostra},
        success: function(data, textStatus, jqXHR)
        {
       			$("#editunidadesamostra").replaceWith(data);
       			$("#editunidadesamostra").val(unidades);
				spinner.stop();
        },
        error: function(jqXHR, textStatus, errorThrown) 
        {
				if(textStatus=='error'){
					alertify.error('Não foi possível completar o pedido, por favor tente novamente');
				//location.href="errorpage";
				}
				spinner.stop();
        }
	    });
	
	$("#editidamostrafo").val(id);
	$("#editnomeamostra").val(nome);
	$("#edittipoamostra").val(tipo);
	$("#editvaloramostra").val(valor);
	//$("#editunidadesamostra").val(unidades);
	$("#editobserv").val(observ);
	$("#editdataamostra").val(data);
	$("#editidtipoamostra").val(idtipo);
	$("#editidamostra").val(idamostra);
	
	$("#registaramostra").hide();
	$("#editaramostra").show();	
	
}

function guardaramostra(){

	if($("#formeditafo").validate({
		rules:{
			editvaloramostra:{float: true
			},
		},
		errorLabelContainer: '#erroseditafo',
		wrapper: "li"
		}).form()){
	
	var id = $("#editidamostrafo").val();
	var valor = $("#editvaloramostra").val();
	var unidades = $("#editunidadesamostra").val();
	var observacoes = $("#editobserv").val();
	var data = $("#editdataamostra").val();
	var idtipo = $("#editidtipoamostra").val();
	var idamostra = $("#editidamostra").val();
	
	if($("#editunidadesamostra").val()==0){
		
		alertify.error('É necessário seleccionar as unidades do valor');
	}else{
	
	//guardar e qd guardar recarregar a tabela com a função que foi usada para recarregar qd introduz novo indice de amostras
	$("#editaramostra").hide();
	$("#registaramostra").show();
	var spinner = new Spinner(opts).spin(document.getElementById('spinnergif'));
	 $.ajax({
	        url: 'editardadosamostra',
	        type: 'POST',
	        cache: false,
	        data: {"id":id, "data":data, "observacoes":observacoes, "valor":valor, "idamostra":idamostra, "idtipo":idtipo, "unidades":unidades},
         success: function(data, textStatus, jqXHR)
         {
//colocar resposta que é a linha atualizada na linha correspondente
        	 //	$("#tabelaamostrasfo").html(data);
        	 	$("#funcorgao").html(data);
        	 	//atualiza combo
        	 	$.post("carregacomboamostras", function(resposta) {
        			$("#comboamostras").html(resposta);
        		});
        	 	
        	 	$("#maxamostra").text("0");
        	 	$("#minamostra").text("0");
        	 	$("#mediaamostra").text("0");
				alertify.success("inserção efectuada com sucesso");
				spinner.stop();
         },
         error: function(jqXHR, textStatus, errorThrown) 
         {
				if(textStatus=='error'){
					alertify.error('Não foi possível completar o pedido, por favor tente novamente');
				}
				spinner.stop();
         }
	    });	
	}

	}else{
		alertify.error('Existem campos que não foram validados, por favor confirme os dados');
	}
}

function cancelaguardaramostra(){
	$("#registaramostra").show();
	$("#editaramostra").hide();			
}

