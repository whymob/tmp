function carregaunidgasvent(){
	

	var id_gasvent = $("#tipogasvent").val();
	
	var spinner = new Spinner(opts).spin(document.getElementById('spinnergif'));
	
	 $.ajax({
	        url: 'carregaunidadesgasvent',
	        type: 'POST',
	        cache: false,
	        data: {"id_gasvent" : id_gasvent},
           success: function(data, textStatus, jqXHR)
           {
      	$("#unidgasvent").replaceWith(data);
				spinner.stop();
           },
           error: function(jqXHR, textStatus, errorThrown) 
           {
				if(textStatus=='error'){
					alertify.error('Não foi possível carregar as unidades da terapeutica');
				}
				spinner.stop();
           }
	    });	
}

function gravastatusharmgasvent(){
	 var spinner = new Spinner(opts).spin(document.getElementById('spinnergif'));
		$.ajax({
			        url: 'gravastatusharmgasvent',
			        type: 'POST',
			        cache: false,
		   success: function(data, textStatus, jqXHR)
		   {
			   		$("#statusgasvent").attr("src","resources/imagens/green-check.gif");
			   		alertify.success('Dados gravados com sucesso');
				//	hidesaveviro();
					spinner.stop();
		   },
		   error: function(jqXHR, textStatus, errorThrown) 
		   {
					alertify.error('Não foi possível completar o pedido, por favor tente novamente');
					spinner.stop();
		   	}
		});
	
}

function carregaunidgasventedit(){
	var id_gasvent = $("#edittipogasvent").val();
	
	var spinner = new Spinner(opts).spin(document.getElementById('spinnergif'));
	
	 $.ajax({
	        url: 'carregaunidadesgasventedit',
	        type: 'POST',
	        cache: false,
	        data: {"id_gasvent" : id_gasvent},
           success: function(data, textStatus, jqXHR)
           {
      	$("#editunidgasvent").replaceWith(data);
				spinner.stop();
           },
           error: function(jqXHR, textStatus, errorThrown) 
           {
				if(textStatus=='error'){
					alertify.error('Não foi possível carregar as unidades da terapeutica');
				}
				spinner.stop();
           }
	    });	
	
	
}

function tratadataamostragasvent(){
	var data = $("#datagasvent").val();
	var hora = $("#horagasvent").val();

	var formatodata = data+" "+hora;
	var d=  Date.parse(formatodata);
	//var d= new Date(formatodata);

	if(isNaN(d)){
		alert("não tem data");
	}else{
		//alert(d.toLocaleString());
//		$("#datahoraamostrareg").val(d.toLocaleString());
		$("#datahoragasventreg").val(formatodata);
		//(d.getFullYear())+ '-' + (d.getMonth() + 1) + '-' + (d.getDate())
	}
}

function registargasvent(){
	//carregar data completa para caixa escondida
	tratadataamostragasvent();
	
	if($("#formreggasvent").validate({
		rules:{
			horagasvent:{
				hora24: true,
				required : true
			},
			valorgasreg:{
				float : true,
				required: true
				},
			peepreg:{
				digits: true,
				maxlength: 2
			},
			fio2reg:{
				digits: true,
				maxlength: 3
			},
		},
		ignore: ".ignore",
		messages: {
			  /* name do campo não o id*/
				  horagasvent :{
					  required: "<font color=\"red\">O campo Hora é de preenchimento obrigatório</font>"
					},
				  valorgasreg: {
					  required: "<font color=\"red\">O campo Valor é de preenchimento obrigatório</font>"
						    },
				  peepreg: {
				    	digits: "<font color=\"red\">O campo PEEP só permite digitos</font>",
				    	maxlength: "<font color=\"red\">O campo PEEP só permite um máximo de 2 digitos</font>"
				    },
				    fio2reg: {
				    	digits: "<font color=\"red\">O campo FIO2 só permite digitos</font>",
				    	maxlength: "<font color=\"red\">O campo FIO2 apenas permite um máximo de 3 digitos</font>"
				    }
				  },
		errorLabelContainer: '#errosreggasvent',
		wrapper: "li"
		}).form()){
	
	var tipogasvent = $("#tipogasvent").val();
	
	var valor = $("#valorgasreg").val();
//	var unidgasvent = $("#unidgasvent").val();
	
	if(tipogasvent == "0"){
		//alert("É necessário seleccionar uma amostra a introduzir");
		alertify.error("É necessário seleccionar um tipo de gasimetria válido");
	}else if(valor < 1){
		alertify.error("É necessário introduzir um valor para a gasimetria válido");
	}else{	
	
		var data = $("#datahoragasventreg").val();
		
		var valor = $("#valorgasreg").val();
		
		if($("#fio2reg").val()==''){
			var fio2 = 0;
		}else{
			var fio2 = $("#fio2reg").val();
		}
		
		var obs = $("#observgasreg").val(); 
		
		if($("#peepreg").val()==''){
			var peep = 0;
		}else{
			var peep = $("#peepreg").val();
		}

		
		var spinner = new Spinner(opts).spin(document.getElementById('spinnergif'));
		
		 $.ajax({
		        url: 'registagasvent',
		        type: 'POST',
		        cache: false,
		        data: {"tipogasvent": tipogasvent, "data":data, "valor":valor, "fio2":fio2, "observ":obs, "peep":peep},
	         success: function(data, textStatus, jqXHR)
	         {

	        	    $("#tabgasvent").html(data);
	        	    $("#tipogasvent").val(0);
	        	    $("#unidgasvent").val(0);
	        	    $("#valorgasreg").val("");
	        	    $("#fio2reg").val("");
	        	    $("#peepreg").val("");
	        	    $("#observgasreg").val(""); 
	        	    $("#statusgasvent").attr("src","resources/imagens/green-check.gif");
					alertify.success("inserção efectuada com sucesso");
					spinner.stop();
	         },
	         error: function(jqXHR, textStatus, errorThrown) 
	         {
					if(textStatus=='error'){
						alertify.error('Não foi possível completar o pedido, por favor tente novamente');
					//location.href="errorpage";
					}
					spinner.stop();
	         }
		    });
	}
	
	}else{
		alertify.error('Existem campos que não foram validados, por favor confirme os dados');
	}
}

function cancelaguardargasvent(){
	
	$("#reggasvent").show();
	$("#editargasvent").hide();	

}

function editargasvent(idgasvent, fio2, valor, observ, data, idtipo, idunidades, hora, datacompleta, peep){
	
	
	$("#editidgasvent").val(idgasvent);
	$("#editdatagasvenoculto").val(datacompleta);
	$("#edithoragasvent").val(hora);
	$("#edittipogasvent").val(idtipo);
	$("#editvalorgasvent").val(valor);	
	$("#editunidgasvent").val(idunidades);
	$("#editfio2").val(fio2);
	$("#editobservgasvent").val(observ);
	$("#editdatagasvent").val(data);
	$("#peepedit").val(peep);

	
	$("#reggasvent").hide();
	$("#editargasvent").show();	

	
}

function guardargasvent(){
	
	if($("#formeditgasvent").validate({
		rules:{
			edithoragasvent:{
				hora24: true
			},
			editvalorgasvent:{
				float : true,
				required: true
				},
			peepedit:{
				digits: true,
				maxlength: 2
			},
			editfio2:{
				digits: true,
				maxlength: 3
			},
		},
		ignore: ".ignore",
		messages: {
			  /* name do campo não o id*/
			editvalorgasvent: {
					  required: "<font color=\"red\">O campo Valor é de preenchimento obrigatório</font>",
						    },
			peepedit: {
				    	digits: "<font color=\"red\">O campo PEEP só permite digitos</font>",
				    	maxlength: "<font color=\"red\">O campo PEEP só permite um máximo de 2 digitos</font>"
				    },
			editfio2: {
				    	digits: "<font color=\"red\">O campo FIO2 só permite digitos</font>",
				    	maxlength: "<font color=\"red\">O campo FIO2 apenas permite um máximo de 3 digitos</font>"
				    }
				  },
		errorLabelContainer: '#erroseditgasvent',
		wrapper: "li"
		}).form()){
	
	var idgasvent = $("#editidgasvent").val();
	var idtipo = $("#edittipogasvent").val();
	var valor = $("#editvalorgasvent").val();	
//	var idunidades = $("#editunidgasvent").val();
	var fio2 = $("#editfio2").val();
	var observ = $("#editobservgasvent").val();	
	
	var data = $("#editdatagasvent").val();
	var hora = $("#edithoragasvent").val();
	
	var peep = $("#peepedit").val();

	var formatodata = data+" "+hora;
	var d=  Date.parse(formatodata);
	//var d= new Date(formatodata);

	if(isNaN(d)){
		alert("não tem data");
	}else{
		$("#editdatagasvenoculto").val(formatodata);
	}
	var datacompleta = $("#editdatagasvenoculto").val();	

	var spinner = new Spinner(opts).spin(document.getElementById('spinnergif'));
	 $.ajax({
	        url: 'editargasvent',
	        type: 'POST',
	        cache: false,
	        data: {"idgasvent":idgasvent, "idtipo":idtipo, "valor":valor, "fio2":fio2, "observ":observ, "data":datacompleta, "peep":peep},
        success: function(data, textStatus, jqXHR)
        {

       	 //	$("#tabgasvent").html(data);
        	$("#gas_"+idgasvent).replaceWith(data);
       		$("#reggasvent").show();
       		$("#editargasvent").hide();	
				alertify.success("Alteração efectuada com sucesso");
				spinner.stop();
        },
        error: function(jqXHR, textStatus, errorThrown) 
        {
				if(textStatus=='error'){
					alertify.error('Não foi possível completar o pedido, por favor tente novamente');
				//location.href="errorpage";
				}
				spinner.stop();
        }
	    });		
	}else{
		alertify.error('Existem campos que não foram validados, por favor confirme os dados');
	}
}

function eliminargasvent(idgasvent, e){
	

	e.stopPropagation();
	
	alertify.confirm("Confirma a eliminação  da gasimentria/ventilação?", function (e) {
	    if (e) {
	        // user clicked "ok"
	    	
	    	var spinner = new Spinner(opts).spin(document.getElementById('spinnergif'));
	   	 $.ajax({
	   	        url: 'eliminagasvent',
	   	        type: 'POST',
	   	        cache: false,
	   	        data: {"idgasvent": idgasvent},
	       success: function(data, textStatus, jqXHR)
	       {
	       		$("#gas_"+idgasvent).remove();
	       		cancelaguardargasvent();
				alertify.success("Registo removido com sucesso");
	   			spinner.stop();
	       },
	       error: function(jqXHR, textStatus, errorThrown) 
	       {
	   				if(textStatus=='error'){
	   					alertify.error('Não foi possível completar o pedido, por favor tente novamente');
	   				}
	   				spinner.stop();
	       }
	   	    });
	    	
	    } else {
	    	alertify.error("Processo de eliminação cancelado");
	    }
	});	
}

