/**
 * Script Página IPST
 */

$(document).ready(function() {
    $('#tabelaaprovacao').dataTable(  {
        initComplete: function () {
            var api = this.api();
 
            api.columns().indexes().flatten().each( function ( i ) {
                var column = api.column( i );
                var select = $('<select style="max-width: 68px; margin:auto;"><option value=""></option></select>')
                    .appendTo( $(column.footer()).empty() )
                    .on( 'change', function () {
                        var val = $.fn.dataTable.util.escapeRegex(
                            $(this).val()
                        );
 
                        column
                            .search( val ? '^'+val+'$' : '', true, false )
                            .draw();
                    } );
 
                column.data().unique().sort().each( function ( d, j ) {
                    select.append( '<option value="'+d+'">'+d+'</option>' )
                } );
            } );
        },
		        "language": {
            "sProcessing":   "A processar...",
            "sLengthMenu":   "_MENU_ registos por página",
            "sZeroRecords":  "Não foram encontrados resultados",
            "sInfo":         "A mostrar de _START_ até _END_ de _TOTAL_ registos",
            "sInfoEmpty":    "A mostrar de 0 até 0 de 0 registos",
            "sInfoFiltered": "(a filtrar de _MAX_ registos no total)",
            "sInfoPostFix":  "",
            "sSearch":       "Pesquisar:",
            "sUrl":          "",
            "oPaginate": {
            	"sFirst":    "Primeiro",
            	"sPrevious": "Anterior",
            	"sNext":     "Seguinte",
            	"sLast":     "Último"
            }
        }
    
    
} );
   
  $("#tabelapagamentos_length").css({"borderTopWidth": "0", "borderRightWidth": "0" , "borderBottomWidth": "0", "borderLeftWidth": "0"});
} );

var opts = {
		  lines: 11, // The number of lines to draw
		  length: 30, // The length of each line
		  width: 13, // The line thickness
		  radius: 25, // The radius of the inner circle
		  corners: 1, // Corner roundness (0..1)
		  rotate: 0, // The rotation offset
		  direction: 1, // 1: clockwise, -1: counterclockwise
		  color: 'grey', // #rgb or #rrggbb or array of colors
		  speed: 1.5, // Rounds per second
		  trail: 60, // Afterglow percentage
		  shadow: true, // Whether to render a shadow
		  hwaccel: true, // Whether to use hardware acceleration
		  className: 'spinner', // The CSS class to assign to the spinner
		  zIndex: 2e9, // The z-index (defaults to 2000000000)
		  top: '50%', // Top position relative to parent
		  left: '50%' // Left position relative to parent
		};


function abredadosutilizador()
{
	var spinner = new Spinner(opts).spin(document.getElementById('spinnergif'));
	$.post("editautilizador2", {}, function(resposta) {
			$("#separadordadosutilizador").html(resposta);
			spinner.stop();
		});
	
	document.getElementById("separadordadosutilizador").style.display = 'block';
	document.getElementById("separadorpagamentos").style.display = 'none';
    document.getElementById("pagamento").className = "";
	document.getElementById("incentivos").className = "";
	document.getElementById("objetivos").className = "";
	document.getElementById("separadorpagamentos").style.display = 'none';
	document.getElementById("separadorincentivos").style.display = 'none';
	document.getElementById("detalhepagamentos").style.display = 'none';
	document.getElementById("separadorobjetivos").style.display = 'none';
	
	start();
	document.getElementById("pagamento").className = "";
	
//	document.getElementById("cabecalhoavaliacao").style.display = 'none';
//	document.getElementById("separadorreports").style.display = 'none';
//	document.getElementById("separadorreferenciar").style.display = 'none';
//	document.getElementById("detalheavaliacao").style.display = 'none';	
//	
//	
//	document.getElementById("avaliacao").className = "";
//	document.getElementById("referenciar").className = "";
//	document.getElementById("reports").className = "";
}


function start()
{
//	document.getElementById("processos").className = "";
//	document.getElementById("followup").className = "";
	document.getElementById("objetivos").className = "";
	document.getElementById("incentivos").className = "";
	document.getElementById("pagamento").className = "selected";
	//document.getElementById("aprovacao").className = "selected";
}

function abredetalheupagamento(id)
{
	document.getElementById("detalhepagamentos").style.display = 'block';
}

function changeclassSelected(element)
{
	var tab = element.id;
	
	if(tab == 'objetivos')
	{
		var spinner = new Spinner(opts).spin(document.getElementById('spinnergif'));
		$.ajax({
		        url: 'carregaseparadorobjetivos',
		        type: 'POST',
		        cache: false,
	           success: function(data, textStatus, jqXHR)
	           {
	        	    $("#separadorobjetivos").html(data);
	        	   
	        	    spinner.stop();
	        	   
	        	    document.getElementById("pagamento").className = "";
	        		document.getElementById("incentivos").className = "";
	        		document.getElementById("objetivos").className = "selected";
	        		document.getElementById("separadordadosutilizador").style.display = 'none';
	        		document.getElementById("separadorpagamentos").style.display = 'none';
	        		document.getElementById("separadorincentivos").style.display = 'none';
	        		document.getElementById("detalhepagamentos").style.display = 'none';
	        		document.getElementById("separadorobjetivos").style.display = 'block';
	           },
	           error: function(jqXHR, textStatus, errorThrown) 
	           {
					if(textStatus=='error')
						alertify.error('Não foi possível completar o pedido, por favor tente novamente');
				
					spinner.stop();
	           }
		});
	}
	else
//	if(tab == 'followup')
//	{
//		document.getElementById("processos").className = "";
//		document.getElementById("followup").className = "selected";
//		document.getElementById("ofertas").className = "";
//		document.getElementById("pagamento").className = "";
//		document.getElementById("reporte").className = "";
//		
//		document.getElementById("separadorpagamentos").style.display = 'none';
//		document.getElementById("separadordadosutilizador").style.display = 'none';
//	}
//	else
//	if(tab == 'ofertas')
//	{
//		document.getElementById("processos").className = "";
//		document.getElementById("followup").className = "";
//		document.getElementById("ofertas").className = "selected";
//		document.getElementById("pagamento").className = "";
//		document.getElementById("reporte").className = "";
//		
//		document.getElementById("separadorpagamentos").style.display = 'none';
//		document.getElementById("separadordadosutilizador").style.display = 'none';
//	}
//	else
	if(tab == 'pagamento')
	{
//		document.getElementById("processos").className = "";
//		document.getElementById("followup").className = "";
//		document.getElementById("ofertas").className = "";
		document.getElementById("pagamento").className = "selected";
		document.getElementById("incentivos").className = "";
		document.getElementById("objetivos").className = "";
		
		document.getElementById("separadordadosutilizador").style.display = 'none';
		
		document.getElementById("separadorpagamentos").style.display = 'block';
		document.getElementById("separadorincentivos").style.display = 'none';
		document.getElementById("separadorobjetivos").style.display = 'none';
	}
	else
	if(tab == 'incentivos')
	{
		var spinner = new Spinner(opts).spin(document.getElementById('spinnergif'));
		$.ajax({
		        url: 'carregaseparadorincentivos',
		        type: 'POST',
		        cache: false,
	           success: function(data, textStatus, jqXHR)
	           {
	        	    $("#separadorincentivos").html(data);
	        	   
	        	    spinner.stop();
	        	   
	        	    document.getElementById("pagamento").className = "";
		       		document.getElementById("objetivos").className = "";
		       		document.getElementById("incentivos").className = "selected";
		       		document.getElementById("separadordadosutilizador").style.display = 'none';
		       		document.getElementById("separadorpagamentos").style.display = 'none';
		       		document.getElementById("detalhepagamentos").style.display = 'none';
		       		document.getElementById("separadorobjetivos").style.display = 'none';
		       		document.getElementById("separadorincentivos").style.display = 'block';
	           },
	           error: function(jqXHR, textStatus, errorThrown) 
	           {
					if(textStatus=='error')
						alertify.error('Não foi possível completar o pedido, por favor tente novamente');
				
					spinner.stop();
	           }
		});
	}
}

function validaipst(idcolheita)
{
	alertify.confirm("Confirma a validação?", function (e) 
	{
	    if (e) 
	    {
			var spinner = new Spinner(opts).spin(document.getElementById('spinnergif'));
			
			 $.ajax({
			        url: 'validacolheitaipst',
			        type: 'POST',
			        cache: false,
			        data: {"idcolheita":idcolheita},
		            success: function(data, textStatus, jqXHR)
		            {
		            	alertify.success("Validação concluída");
		            	$("#linhacolheitaipst_"+idcolheita).replaceWith(data);
		            	
		 				spinner.stop();
		            },
		            error: function(jqXHR, textStatus, errorThrown) 
		            {
		 				if(textStatus=='error')
		 					alertify.error('Não foi possível completar o pedido, por favor tente novamente');
		 				spinner.stop();
		            }
			    });	
	    } 
	    else 
	    {
	    	$("#colheitaipst_"+idcolheita).prop('checked', false);
	    	
	    	alertify.error("Validação cancelada");
	    }
	});
}

function filtraraprovar()
{
	if($("#poraprovar").is(":checked"))
	{
		var spinner = new Spinner(opts).spin(document.getElementById('spinnergif'));
		
		 $.ajax({
		        url: 'buscaporaporvar',
		        type: 'POST',
		        cache: false,
	           success: function(data, textStatus, jqXHR)
	           {
	           		$("#separadorconfirmacaogeralipst").html(data);
	           		
	           		document.getElementById("detalhepagamentos").style.display = 'none';
	           	
	           		spinner.stop();
	           },
	           error: function(jqXHR, textStatus, errorThrown) 
	           {
					if(textStatus=='error')
						alertify.error('Não foi possível completar o pedido, por favor tente novamente');
					spinner.stop();
	           }
		    });
	}
	else
	{
		var spinner = new Spinner(opts).spin(document.getElementById('spinnergif'));
		
		 $.ajax({
		        url: 'buscaaprovados',
		        type: 'POST',
		        cache: false,
	           success: function(data, textStatus, jqXHR)
	           {
	           		$("#separadorconfirmacaogeralipst").html(data);
	           	
	           		spinner.stop();
	           },
	           error: function(jqXHR, textStatus, errorThrown) 
	           {
					if(textStatus=='error')
						alertify.error('Não foi possível completar o pedido, por favor tente novamente');
					spinner.stop();
	           }
		    });
	}
}

function filtracolheitaipst()
{
	var ano = $("#anopesquisa").val();
	var mes = $("#mespesquisa").val();
	
	var spinner = new Spinner(opts).spin(document.getElementById('spinnergif'));
	
	 $.ajax({
	        url: 'buscacolheitafiltradaipst',
	        type: 'POST',
	        cache: false,
	        data: {"ano":ano, "mes":mes},
           success: function(data, textStatus, jqXHR)
           {
           		$("#separadorconfirmacaogeralipst").html(data);
           		
           		document.getElementById("detalhepagamentos").style.display = 'none';
           	
           		spinner.stop();
           },
           error: function(jqXHR, textStatus, errorThrown) 
           {
				if(textStatus=='error')
					alertify.error('Não foi possível completar o pedido, por favor tente novamente');
				spinner.stop();
           }
	    });	
}


function abredetalheconfirmacaoipst(idgcctcolheita)
{
	var spinner = new Spinner(opts).spin(document.getElementById('spinnergif'));
	
	 $.ajax({
	        url: 'abredetalheipst',
	        type: 'POST',
	        cache: false,
	        data: {"idgcctcolheita":idgcctcolheita},
           success: function(data, textStatus, jqXHR)
           {
        	   $("#detalhepagamentos").html(data);
        	   
	    		document.getElementById("detalhepagamentos").style.display = 'block';
	    		
				spinner.stop();
           },
           error: function(jqXHR, textStatus, errorThrown) 
           {
				if(textStatus=='error'){
					alertify.error('Não foi possível completar o pedido, por favor tente novamente');
				}
			spinner.stop();
           }
	    });
}