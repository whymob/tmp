$(document).ready(function() {
	
	
	 
	 jQuery("#d21").add("#t21").add("#u21").click(function() 
			  {
			  jQuery("#gruposanguineo").toggle("fast");
			  jQuery("#u21").toggle();
			  jQuery("#d21").toggle();
			  });
	 
	 jQuery("#d22").add("#t22").add("#u22").click(function() 
			  {
			  jQuery("#funcoesorgao").toggle("fast");
			  jQuery("#u22").toggle();
			  jQuery("#d22").toggle();
			  });
	 
	 jQuery("#d23").add("#t23").add("#u23").click(function() 
			  {
			  jQuery("#microbiologia").toggle("fast");
			  jQuery("#u23").toggle();
			  jQuery("#d23").toggle();
			  });
	 
	 jQuery("#d24").add("#t24").add("#u24").click(function() 
			  {
			  jQuery("#virologia").toggle("fast");
			  jQuery("#u24").toggle();
			  jQuery("#d24").toggle();
			  });
	
	 jQuery("#d25").add("#t25").add("#u25").click(function() 
			  {
			  jQuery("#tipagemhla").toggle("fast");
			  jQuery("#u25").toggle();
			  jQuery("#d25").toggle();
			  });
	 jQuery("#d26").add("#t26").add("#u26").click(function() 
			  {
			  jQuery("#gasvent").toggle("fast");
			  jQuery("#u26").toggle();
			  jQuery("#d26").toggle();
			  });	
	
});