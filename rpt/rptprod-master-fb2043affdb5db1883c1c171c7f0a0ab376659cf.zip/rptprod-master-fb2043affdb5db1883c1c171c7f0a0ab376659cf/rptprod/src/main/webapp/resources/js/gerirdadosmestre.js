/**
 * 
 */

var opts = {
		  lines: 11, // The number of lines to draw
		  length: 30, // The length of each line
		  width: 13, // The line thickness
		  radius: 25, // The radius of the inner circle
		  corners: 1, // Corner roundness (0..1)
		  rotate: 0, // The rotation offset
		  direction: 1, // 1: clockwise, -1: counterclockwise
		  color: 'grey', // #rgb or #rrggbb or array of colors
		  speed: 1.5, // Rounds per second
		  trail: 60, // Afterglow percentage
		  shadow: true, // Whether to render a shadow
		  hwaccel: true, // Whether to use hardware acceleration
		  className: 'spinner', // The CSS class to assign to the spinner
		  zIndex: 2e9, // The z-index (defaults to 2000000000)
		  top: '50%', // Top position relative to parent
		  left: '50%' // Left position relative to parent
		};

$(document).ready(function() {
$('#tabelaudadosmestre').dataTable(  {
    initComplete: function () {
        var api = this.api();

        api.columns().indexes().flatten().each( function ( i ) {
            var column = api.column( i );
            var select = $('<select><option value=""></option></select>')
                .appendTo( $(column.footer()).empty() )
                .on( 'change', function () {
                    var val = $.fn.dataTable.util.escapeRegex(
                        $(this).val()
                    );

                    column
                        .search( val ? '^'+val+'$' : '', true, false )
                        .draw();
                } );

            column.data().unique().sort().each( function ( d, j ) {
                select.append( '<option value="'+d+'">'+d+'</option>' )
            } );
        } );
    },
		        "language": {
        "sProcessing":   "A processar...",
        "sLengthMenu":   "_MENU_ registos por página",
        "sZeroRecords":  "Não foram encontrados resultados",
        "sInfo":         "A mostrar de _START_ até _END_ de _TOTAL_ registos",
        "sInfoEmpty":    "A mostrar de 0 até 0 de 0 registos",
        "sInfoFiltered": "(a filtrar de _MAX_ registos no total)",
        "sInfoPostFix":  "",
        "sSearch":       "Pesquisar:",
        "sUrl":          "",
        "oPaginate": {
        	"sFirst":    "Primeiro",
        	"sPrevious": "Anterior",
        	"sNext":     "Seguinte",
        	"sLast":     "Último"
        }
    }
} );
} );

function abredetalhedadosmestre(num)
{
	var spinner = new Spinner(opts).spin(document.getElementById('spinnergif'));
	
	$.post("carregadadosmestre", {'id' : num}, function(resposta) {
			$("#separadordetalhedadosmestre").hide();
			$("#separadordetalhedadosmestre").html(resposta);
			$("#separadordetalhedadosmestre").fadeIn(600);
			spinner.stop();
	});	
	
	//$("#separadordetalhedadosmestre").scrollTop(500);
	//$.scrollTo('#separadordetalhedadosmestre',800);
	document.getElementById("separadordetalhedadosmestre").style.display = 'block';
	document.getElementById("idtabela").value = num;
}

function alteradados(idvalor, desc)
{
	document.getElementById("novovalor").value = desc;
	document.getElementById("idvalor").value = idvalor;
}

function alteradados2(idvalor, desc, combo)
{
	alteradados(idvalor, desc);
	$("#relacao").val(combo);
}

function alteradados3(idvalor, desc, combo, unid)
{
	alteradados2(idvalor, desc, combo);
	$("#unidades").val(unid);
}

function alteradadosamostrasfo(idvalor, desc){
	
	var spinner = new Spinner(opts).spin(document.getElementById('spinnergif'));
  	 $.ajax({
  	        url: 'loadunidadesamostras',
  	        type: 'POST',
  	        cache: false,
  	        data: {"id" : idvalor},
      success: function(data, textStatus, jqXHR)
      {
    	  $("#unidadesamostras").html(data);
    	  spinner.stop();
   	
      },
      error: function(jqXHR, textStatus, errorThrown) 
      {
  				if(textStatus=='error'){
  					alertify.error('Não foi possível completar o pedido, por favor tente novamente');
  				}
   				spinner.stop();
      }
  	    });
  	 
 	alteradados(idvalor, desc);
	$("#unidadesamostras").show();
}



function limpar()
{
	document.getElementById("novovalor").value = "";
	document.getElementById("idvalor").value = "";
}

function limpar2()
{
limpar();
$("#relacao").val(0);
}

function limpar3()
{
limpar();
$("#relacao").val(0);
$("#unidades").val(0);
}

function limparamostrasfo(){
	
	$("#unidadesamostras").hide();
	limpar();
	
}

function guardarvalor()
{
	var id = document.getElementById("idvalor").value;
	var desc = document.getElementById("novovalor").value;

	if(id.length < 1 && desc.length < 1)
	{
		alertify.error('Necessário selecionar o registo ou preencher a descrição');
	}
	
	if(id.length <1 && desc.length >= 1)
	{	
		var posting = $.post("criavalordadosmestre", {"id" : document.getElementById("idtabela").value, "desc" : desc});
		posting.done(function(data) {
			if(data==="true")
			{
				document.getElementById("idvalor").value = "";
				document.getElementById("novovalor").value = "";
				
				var spinner = new Spinner(opts).spin(document.getElementById('spinnergif'));

				$.post("carregadadosmestre", {'id' : document.getElementById("idtabela").value}, function(resposta) {
						$("#separadordetalhedadosmestre").html(resposta);
						spinner.stop();
				});
				
				alertify.success('Dados registados com sucesso');
			}
			else
			{ 
				alertify.error('Já existem valores');
			}
		});
	}
	else if(id >=1 && desc.length >= 1)
	{
		var posting = $.post("guardavalordadosmestre", {"id" : id, "desc" : desc, "idtabela" : document.getElementById("idtabela").value});
		posting.done(function(data) {
			if(data==="true")
			{
				document.getElementById("idvalor").value = "";
				document.getElementById("novovalor").value = "";
				
				var spinner = new Spinner(opts).spin(document.getElementById('spinnergif'));

				$.post("carregadadosmestre", {'id' : document.getElementById("idtabela").value}, function(resposta) {
						$("#separadordetalhedadosmestre").html(resposta);
						spinner.stop();
				});
				
				alertify.success('Dados alterados com sucesso');
			}
			else
			{ 
				alertify.error('Erro. Tente novamente');
			}
		});
	}
}

function guardarvalor2()
{
	
	var id = document.getElementById("idvalor").value;
	var desc = document.getElementById("novovalor").value;
	var combo = $("#relacao").val();

	if(id.length < 1 && desc.length < 1)
	{
		alertify.error('Necessário selecionar um registo ou preencher a descrição');
	}
	else
	if(combo==0){
		alertify.error('Necessário selecionar um valor da lista');
		
	}
	else
	if(id.length <1 && desc.length >= 1 && combo !=0)
	{	
		var posting = $.post("criavalordadosmestre2", {"id" : document.getElementById("idtabela").value, "desc" : desc, "combo" : combo});
		posting.done(function(data) {
			if(data==="true")
			{
				document.getElementById("idvalor").value = "";
				document.getElementById("novovalor").value = "";
				$("#relacao").val(0);
				
				var spinner = new Spinner(opts).spin(document.getElementById('spinnergif'));

				$.post("carregadadosmestre", {'id' : document.getElementById("idtabela").value}, function(resposta) {
						$("#separadordetalhedadosmestre").html(resposta);
						spinner.stop();
				});
				
				alertify.success('Dados registados com sucesso');
			}
			else
			{ 
				alertify.error('Já existem valores');
			}
		});
	}
	else if(id >=1 && desc.length >= 1)
	{
		var posting = $.post("guardavalordadosmestre2", {"id" : id, "desc" : desc, "idtabela" : document.getElementById("idtabela").value, "combo" : combo});
		posting.done(function(data) {
			if(data==="true")
			{
				document.getElementById("idvalor").value = "";
				document.getElementById("novovalor").value = "";
				$("#relacao").val(0);
				
				var spinner = new Spinner(opts).spin(document.getElementById('spinnergif'));

				$.post("carregadadosmestre", {'id' : document.getElementById("idtabela").value}, function(resposta) {
						$("#separadordetalhedadosmestre").html(resposta);
						spinner.stop();
				});
				
				alertify.success('Dados alterados com sucesso');
			}
			else
			{ 
				alertify.error('Erro. Tente novamente');
			}
		});
	}
}

function guardarvalor3()
{
	var id = document.getElementById("idvalor").value;
	var desc = document.getElementById("novovalor").value;
	var combo = $("#relacao").val();
	var unid = $("#unidades").val();

	if(id.length < 1 && desc.length < 1)
	{
		alertify.error('Necessário preencher todos os campos');
	}
	else
	if(combo==0 || unid==0){
		alertify.error('Necessário selecionar uma fórmula e unidades');
		
	}
	else
	if(id.length <1 && desc.length >= 1 && combo !=0 && unid !=0)
	{	
		var posting = $.post("criavalordadosmestre3", {"id" : document.getElementById("idtabela").value, "desc" : desc, "combo" : combo, "unid": unid});
		posting.done(function(data) {
			if(data==="true")
			{
				limpar3();
//				document.getElementById("idvalor").value = "";
//				document.getElementById("novovalor").value = "";
//				$("#relacao").val(0);
//				$("#unidades").val(0);
				
				var spinner = new Spinner(opts).spin(document.getElementById('spinnergif'));

				$.post("carregadadosmestre", {'id' : document.getElementById("idtabela").value}, function(resposta) {
						$("#separadordetalhedadosmestre").html(resposta);
						spinner.stop();
				});
				
				alertify.success('Dados registados com sucesso');
			}
			else
			{ 
				alertify.error('Já existem valores');
			}
		});
	}
	else if(id >=1 && desc.length >= 1)
	{
		var posting = $.post("guardavalordadosmestre3", {"id" : id, "desc" : desc, "idtabela" : document.getElementById("idtabela").value, "combo" : combo, "unid": unid});
		posting.done(function(data) {
			if(data==="true")
			{
				limpar3();
				
				var spinner = new Spinner(opts).spin(document.getElementById('spinnergif'));

				$.post("carregadadosmestre", {'id' : document.getElementById("idtabela").value}, function(resposta) {
						$("#separadordetalhedadosmestre").html(resposta);
						spinner.stop();
				});
				
				alertify.success('Dados alterados com sucesso');
			}
			else
			{ 
				alertify.error('Erro. Tente novamente');
			}
		});
	}
}

function guardarvalor4()
{
	var id = document.getElementById("idvalor").value;
	var desc = document.getElementById("novovalor").value;
	var combo = $("#relacao").val();

	if(id.length < 1 && desc.length < 1)
	{
		alertify.error('Necessário selecionar um registo ou preencher a descrição');
	}
	else
	if(id.length <1 && desc.length >= 1)
	{	
		var posting = $.post("criavalordadosmestre2", {"id" : document.getElementById("idtabela").value, "desc" : desc, "combo" : combo});
		posting.done(function(data) {
			if(data==="true")
			{
				document.getElementById("idvalor").value = "";
				document.getElementById("novovalor").value = "";
				$("#relacao").val(0);
				
				var spinner = new Spinner(opts).spin(document.getElementById('spinnergif'));

				$.post("carregadadosmestre", {'id' : document.getElementById("idtabela").value}, function(resposta) {
						$("#separadordetalhedadosmestre").html(resposta);
						spinner.stop();
				});
				
				alertify.success('Dados registados com sucesso');
			}
			else
			{ 
				alertify.error('Já existem valores');
			}
		});
	}
	else if(id >=1 && desc.length >= 1)
	{
		var posting = $.post("guardavalordadosmestre2", {"id" : id, "desc" : desc, "idtabela" : document.getElementById("idtabela").value, "combo" : combo});
		posting.done(function(data) {
			if(data==="true")
			{
				document.getElementById("idvalor").value = "";
				document.getElementById("novovalor").value = "";
				$("#relacao").val(0);
				
				var spinner = new Spinner(opts).spin(document.getElementById('spinnergif'));

				$.post("carregadadosmestre", {'id' : document.getElementById("idtabela").value}, function(resposta) {
						$("#separadordetalhedadosmestre").html(resposta);
						spinner.stop();
				});
				
				alertify.success('Dados alterados com sucesso');
			}
			else
			{ 
				alertify.error('Erro. Tente novamente');
			}
		});
	}
}


function guardarvaloridint()
{
	var id = document.getElementById("idvalor").value;
	var desc = document.getElementById("novovalor").value;

	if(id.length < 1 && desc.length < 1)
	{
		alertify.error('Necessário selecionar o registo ou preencher a descrição');
	}
	
	if(id.length <1 && desc.length >= 1)
	{	
		var posting = $.post("criavalordadosmestre", {"id" : document.getElementById("idtabela").value, "desc" : desc});
		posting.done(function(data) {
			if(data==="true")
			{
				document.getElementById("idvalor").value = "";
				document.getElementById("novovalor").value = "";
				
				var spinner = new Spinner(opts).spin(document.getElementById('spinnergif'));

				$.post("carregadadosmestre", {'id' : document.getElementById("idtabela").value}, function(resposta) {
						$("#separadordetalhedadosmestre").html(resposta);
						spinner.stop();
				});
				
				alertify.success('Dados registados com sucesso');
			}
			else
			{ 
				alertify.error('Já existem valores');
			}
		});
	}
	else if(id >=1 && desc.length >= 1)
	{
		var posting = $.post("guardavalordadosmestretipodiag", {"id" : id, "desc" : desc, "idtabela" : document.getElementById("idtabela").value});
		posting.done(function(data) {
			if(data==="true")
			{
				document.getElementById("idvalor").value = "";
				document.getElementById("novovalor").value = "";
				
				var spinner = new Spinner(opts).spin(document.getElementById('spinnergif'));

				$.post("carregadadosmestre", {'id' : document.getElementById("idtabela").value}, function(resposta) {
						$("#separadordetalhedadosmestre").html(resposta);
						spinner.stop();
				});
				
				alertify.success('Dados alterados com sucesso');
			}
			else
			{ 
				alertify.error('Erro. Tente novamente');
			}
		});
	}
}

function removedadosmestre(id, idtabela)
{
	var x;
	
	
	alertify.confirm("Deseja mesmo apagar o valor?", function (e) {
	    if (e) {
	    	
	    	var spinner = new Spinner(opts).spin(document.getElementById('spinnergif'));
		   	 $.ajax({
		   	        url: 'removedadosmestre',
		   	        type: 'POST',
		   	        cache: false,
		   	        data: {"id" : id, "idtabela" : idtabela},
		       success: function(data, textStatus, jqXHR)
		       {
		    		if(data==="true")
		    		{
		    			//var spinner = new Spinner(opts).spin(document.getElementById('spinnergif'));

		    			$.post("carregadadosmestre", {'id' : idtabela}, function(resposta) {
		    					$("#separadordetalhedadosmestre").html(resposta);
		    					spinner.stop();
		    			});
		    			
		    			alertify.success('Dados apagados com sucesso');
		    	
		    		}
		    		else
		    		{ 
		    			alertify.error('Erro. Tente novamente');
		    			spinner.stop();
		    		}
		       },
		       error: function(jqXHR, textStatus, errorThrown) 
		       {
		   				if(textStatus=='error'){
		   					alertify.error('Não foi possível completar o pedido, certifique-se que o registro a eliminar não está a ser usado no sistema');
		   					spinner.stop();
		   				}
		       }
		   	    });
	    	
	    } else {
	    	alertify.error("Processo de remoção cancelado");
	    }
	});
}


function removedadosmestreidint(id, idtabela)
{
	var x;
	
	
	alertify.confirm("Deseja mesmo apagar o valor?", function (e) {
	    if (e) {
	    	
	    	var spinner = new Spinner(opts).spin(document.getElementById('spinnergif'));
		   	 $.ajax({
		   	        url: 'removedadosmestretipodiag',
		   	        type: 'POST',
		   	        cache: false,
		   	        data: {"id" : id, "idtabela" : idtabela},
		       success: function(data, textStatus, jqXHR)
		       {
		    		if(data==="true")
		    		{
		    			//var spinner = new Spinner(opts).spin(document.getElementById('spinnergif'));

		    			$.post("carregadadosmestre", {'id' : idtabela}, function(resposta) {
		    					$("#separadordetalhedadosmestre").html(resposta);
		    					spinner.stop();
		    			});
		    			
		    			alertify.success('Dados apagados com sucesso');
		    	
		    		}
		    		else
		    		{ 
		    			alertify.error('Erro. Tente novamente');
		    			spinner.stop();
		    		}
		       },
		       error: function(jqXHR, textStatus, errorThrown) 
		       {
		   				if(textStatus=='error'){
		   					alertify.error('Não foi possível completar o pedido, certifique-se que o registro a eliminar não está a ser usado no sistema');
		   					spinner.stop();
		   				}
		       }
		   	    });
	    	
	    } else {
	    	alertify.error("Processo de remoção cancelado");
	    }
	});
}

function existeunidade(textInput){
	
	
	var flag = false;
		
		$.each($("#tabmestrefounidades tbody tr").find("td:eq(0)"), function() {
			
			 if ($(this).text() == textInput) {
		           flag = true;
		        } 
			         
	    });
	return flag;
		
	}

function adicionarunnidadesamostra(){
	
	var idamostra = $("#idvalor").val();
	var combo = $("#relacao").val();
	
	if(existeunidade($("#relacao option:selected").text())){
		alertify.error("Já foram introduzidas essas unidades para esta amostra");
	}else if($("#relacao").val()==0){
		
	}else{
	
	var spinner = new Spinner(opts).spin(document.getElementById('spinnergif'));
  	 $.ajax({
  	        url: 'addunidadesamostra',
  	        type: 'POST',
  	        cache: false,
  	        data: {"idamostra" : idamostra, "unidades":combo},
      success: function(data, textStatus, jqXHR)
      {
   	   

    	  $("#unidadesamostras").html(data);
   	  spinner.stop();
      },
      error: function(jqXHR, textStatus, errorThrown) 
      {

  					alertify.error('Não foi possível completar o pedido, por favor tente novamente');
  					spinner.stop();
  				
      }
  	    });
	
	
	}
}


function removeunidadesamostra(id_unidamostra){
	
	alertify.confirm("Confirma a remoção das unidades da amostra?", function (e) {
	    if (e) {
	    	
	    	var spinner = new Spinner(opts).spin(document.getElementById('spinnergif'));
		   	 $.ajax({
		   	        url: 'removeunidadesamostra',
		   	        type: 'POST',
		   	        cache: false,
		   	        data: {"id" : id_unidamostra},
		       success: function(data, textStatus, jqXHR)
		       {
		    	   
		    	   $("#ua_"+id_unidamostra).remove();
		    	  spinner.stop();
		       },
		       error: function(jqXHR, textStatus, errorThrown) 
		       {
		   				if(textStatus=='error'){
		   					alertify.error('Não foi possível completar o pedido, certifique-se que o registro a eliminar não está a ser usado no sistema');
		   				}
		   				spinner.stop();
		       }
		   	    });
	    	
	    } else {
	    	alertify.error("Processo de remoção cancelado");
	    }
	});
	
}