/**
 * Script Div ECG da aba exames
 */

var opts = {
		  lines: 11, // The number of lines to draw
		  length: 30, // The length of each line
		  width: 13, // The line thickness
		  radius: 25, // The radius of the inner circle
		  corners: 1, // Corner roundness (0..1)
		  rotate: 0, // The rotation offset
		  direction: 1, // 1: clockwise, -1: counterclockwise
		  color: 'grey', // #rgb or #rrggbb or array of colors
		  speed: 1.5, // Rounds per second
		  trail: 60, // Afterglow percentage
		  shadow: true, // Whether to render a shadow
		  hwaccel: true, // Whether to use hardware acceleration
		  className: 'spinner', // The CSS class to assign to the spinner
		  zIndex: 2e9, // The z-index (defaults to 2000000000)
		  top: '50%', // Top position relative to parent
		  left: '50%' // Left position relative to parent
		};




$(document).ready(function () {
    var charReg = /^\s*[a-zA-Z0-9,.\s]+\s*$/;
    $(".warning").hide();
    $('#nome').keyup(function () {
        var inputVal = $(this).val();
        if (!charReg.test(inputVal)) {
            $(this).parent().find(".warning").show();
        } else {
            $(this).parent().find(".warning").hide();
        }

    });
    
    //tamanho do ficheiro para upload
    $("#ficheiro3").change(function (){
    		     var iSize = ($("#ficheiro3")[0].files[0].size / 1024);
    		     if (iSize / 1024 > 1)
    		     {
    		        if (((iSize / 1024) / 1024) > 1)
    		        {
    		            iSize = (Math.round(((iSize / 1024) / 1024) * 100) / 100);
    		            $("#lbltamanho3").html( iSize + "Gb");
    		        }
    		        else
    		        {
    		            iSize = (Math.round((iSize / 1024) * 100) / 100)
    		            if(iSize<=10){
    		            	$("#lbltamanho3").html( iSize + "Mb");
    		            }else{
    		            	$("#lbltamanho3").html( iSize + "Mb");
    		        		alertify.error('O ficheiro escolhido excede o limite de 10Mb, por favor escolha um ficheiro dentro do limite imposto');	
    		            }
    		        }
    		     }
    		     else
    		     {
    		        iSize = (Math.round(iSize * 100) / 100)
    		        $("#lbltamanho3").html( iSize  + "kb");
    		     }   
    });
    
});

function salvarecgbotao()
{
	var sinoidal = $("#sinoidal").is(":checked");
	var bloqueioAV = $("#bloqueioAV").is(":checked");
	var arrAtrial = $("#arrAtrial").is(":checked");
	var arrVentri = $("#arrVentri").is(":checked");
	var qrs = $("#qrs").val();
	var notaseletrocardiograma = $("#notaseletrocardiograma").val();
	var qtc = $("#qtc").is(":checked");
	var qtc2 = $("#qtc2").is(":checked");
	var qtc3 = $("#qtc3").is(":checked");
	var stt = $("#stt").val();
	var ms = $("#ms").val();
	var hipertofia = $("#hipertofia").val();
	var qtcc;

	if(qtc == true)
		qtcc = 1;
	else if(qtc2 == true)
		qtcc = 2;
	else
		qtcc = 3;
		
	if(document.getElementById("horaExame").value.length == 0)
	{
		alertify.error('Deve escolher a hora do ecg');
	}
	else
	{
		var spinner = new Spinner(opts).spin(document.getElementById('spinnergif'));
		
		var data = document.getElementById("dataExame").value;
		var hora = document.getElementById("horaExame").value;
		var formatodata = data+" "+hora;
		var d=  new Date(Date.parse(formatodata)).toString('dd/MM/yyyy, HH:mm:ss');
	//	var d=  Date.parse(formatodata).toString('dd/MM/yyyy, HH:mm:ss');
		$("#datahoraecg").val(d);
		var datahoraecg = $("#datahoraecg").val();
		
		$.ajax
		({
			url: 'salvarecg',
			type: 'POST',
			data:  {"datahoraecg" : datahoraecg, "sinoidal" : sinoidal, "bloqueioAV" : bloqueioAV, "arrAtrial" : arrAtrial, "arrVentri" : arrVentri, "qrs" : qrs, 
				"notaseletrocardiograma" : notaseletrocardiograma, "qtc" : qtcc, "stt" : stt, "ms" : ms, "hipertofia" : hipertofia},
			success: function(data, textStatus, jqXHR)
			{
				$("#statusecg").attr("src","resources/imagens/green-check.gif");
				alertify.success('Dados gravados com sucesso');
				spinner.stop();
			},
			error: function(jqXHR, textStatus, errorThrown) 
			{
				if(textStatus=='error'){
					alertify.error('Não foi possível completar o pedido, por favor tente novamente');
				}
				spinner.stop();
			}           
		});
	}	
}


function alterafileecg()
{	
	//atualizar input nome ficheiro para possibilitar escolher nome
	var n = $('#ficheiro3').val().replace(/C:\\fakepath\\/i, '');
	var nome = n.replace(/[^a-z0-9.\s]/gi, '').replace(/[_\s]/g, ' ');
	$('#nome').val(nome);
}

function uploadecg(event)
{	
	$('#id_ecg').val($('#ecgobj').val());
	
		
	if($('#nome').val()=="")
	{
		alertify.error('É necessário seleccionar um ficheiro');	
	}
	else
	{
	
	function getDoc(frame) 
	{
	     var doc = null;

	     try 
	     {
	         if (frame.contentWindow) 
	         {
	             doc = frame.contentWindow.document;
	         }
	     }
	     catch(err) 
	     {
	     }
	 
	     if (doc) 
	     {
	         return doc;
	     }
	 
	     try 
	     { 
	         doc = frame.contentDocument ? frame.contentDocument : frame.document;
	     }
	     catch(err) 
	     {
	         doc = frame.document;
	     }
	     return doc;
	 }
	$("#enviarficheiroecg").submit(function(e)
	{
	    var formObj = $(this);
	    var formURL = formObj.attr("action");
	   
	    if(window.FormData !== undefined)  // para browsers HTML5
	    {
	        var formData = new FormData(this);
	        $.ajax({
	            url: formURL,
	            type: 'POST',
	            data:  formData,
	            mimeType:"multipart/form-data",
	            contentType: false,
	            cache: false,
	            processData:false,
	            success: function(data, textStatus, jqXHR)
	            { 
	 				alertify.success(data);
	 				
	 				var idecg = $('#ecgobj').val();
	 				$.post("carreganomedocecg", {'idecg' : idecg}, function(resposta) {
	 					$("#caminhodocecg").html(resposta);
	 				});
	 				
	 				$.post("carregaficheiroecg", {'idecg' : idecg}, function(resposta) {
	 					$("#imagemeletrocardiograma").html(resposta);
	 				});
	            },
	            error: function(jqXHR, textStatus, errorThrown) 
	            {
	 				if(textStatus=='error')
	 				{
	 					alertify.error('Não foi possível completar o pedido, por favor tente novamente');
	 				}
	            }           
	       });
	        e.preventDefault();
	      //  e.unbind();
	        e.stopImmediatePropagation();
	   }
	   else
	    {
	        //gerar um id aleatório
	        var  iframeId = 'unique' + (new Date().getTime());
	 
	        //criar um iframe vazio
	        var iframe = $('<iframe src="javascript:false;" name="'+iframeId+'" />');
	 
	        //esconder o iframe
	        iframe.hide();
	 
	        //definir o alvo do form para o iframe
	        formObj.attr('target',iframeId);
	 
	        //Adicionar o iframe ao body
	        iframe.appendTo('body');
	        iframe.load(function(e)
	        {
	            var doc = getDoc(iframe[0]);
	            var docRoot = doc.body ? doc.body : doc.documentElement;
	            var data = docRoot.innerHTML;
	        });
	 
	    }     
	});
	$("#enviarficheiroecg").submit();
	}
}