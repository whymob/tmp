/**
 * 
 */

var opts = {
		  lines: 11, // The number of lines to draw
		  length: 30, // The length of each line
		  width: 13, // The line thickness
		  radius: 25, // The radius of the inner circle
		  corners: 1, // Corner roundness (0..1)
		  rotate: 0, // The rotation offset
		  direction: 1, // 1: clockwise, -1: counterclockwise
		  color: 'grey', // #rgb or #rrggbb or array of colors
		  speed: 1.5, // Rounds per second
		  trail: 60, // Afterglow percentage
		  shadow: true, // Whether to render a shadow
		  hwaccel: true, // Whether to use hardware acceleration
		  className: 'spinner', // The CSS class to assign to the spinner
		  zIndex: 2e9, // The z-index (defaults to 2000000000)
		  top: '50%', // Top position relative to parent
		  left: '50%' // Left position relative to parent
		};

function editalesoes()
{
	var lesoesfigado = $("#lesoesfigado").is(":checked");
	
	if(lesoesfigado == false)
		document.getElementById("dadosfigado").style.display = 'none';
	else
		document.getElementById("dadosfigado").style.display = 'block';
}

function salvarfigadobotao()
{
	var lesoes = $("#lesoesfigado").is(":checked");
	var notasfigado = $("#notasecofigado").val();
	var dimensao = $("#dimensao").val();
	var cm = $("#cm").val();
	var parenchyma = $("#parenchyma").val();
	var bordo = $("#bordo").val();
	var viasBiliares = $("#viasBiliares").val();
	var veiaPorta = $("#veiaPorta").val();
	var visicula = $("#visicula").val();

	if(document.getElementById("horaExamefigado").value.length == 0)
	{
		alertify.error('Deve escolher a hora do exame');
	}
	else
	{
		var spinner = new Spinner(opts).spin(document.getElementById('spinnergif'));
		
		var data = document.getElementById("dataExamefigado").value;
		var hora = document.getElementById("horaExamefigado").value;
		var formatodata = data+" "+hora;
	//	var d=  Date.parse(formatodata).toString('dd/MM/yyyy, HH:mm:ss');
		var d=  new Date(Date.parse(formatodata)).toString('dd/MM/yyyy, HH:mm:ss');
		$("#datahorafigado").val(d);
		var datahorafigado = $("#datahorafigado").val();
		
		$.ajax
		({
			url: 'salvarfigado',
			type: 'POST',
			data:  {"datahorafigado" : datahorafigado, "lesoes" : lesoes, "notasfigado" : notasfigado,"dimensao" : dimensao, "cm" : cm, "parenchyma" : parenchyma, 
				"bordo" : bordo, "viasBiliares" : viasBiliares, "veiaPorta" : veiaPorta, "visicula" : visicula},
			success: function(data, textStatus, jqXHR)
			{
				$("#statusecofigado").attr("src","resources/imagens/green-check.gif");
				alertify.success('Dados gravados com sucesso');
				spinner.stop();
			},
			error: function(jqXHR, textStatus, errorThrown) 
			{
				if(textStatus=='error'){
					alertify.error('Não foi possível completar o pedido, por favor tente novamente');
				}
				spinner.stop();
			}           
		});
	}	
}

function carregarlesao()
{	
	var tipolesao = $("#tipolesao").val();
	var numero = $("#numero").val();
	var segmento = $("#segmento").val();
	var notas = $("#notasfigado").val();
	
	if(tipolesao == 0 || numero <= 0 || segmento <= 0)
	{
		alertify.error("Dados inválidos");
	}
	else
		{
			alertify.confirm("Confirma a introdução da lesão? ", function (c) 
			{
			    if (c) 
			    {
					var spinner = new Spinner(opts).spin(document.getElementById('spinnergif'));
					
					 $.ajax({
					        url: 'addlesaotabelafigado',
					        type: 'POST',
					        cache: false,
					        data: {"tipolesao" : tipolesao, 'numero': numero, 'segmento': segmento, "notas": notas},
				            success: function(data, textStatus, jqXHR)
				            {
				            	$("#tabelalesoesfigado").html(data);
				 				alertify.success("Inserção efectuada com sucesso");
				 				spinner.stop();
				 				
				 				$("#tipolesao").val(0);
				 				$("#numero").val("");
				 				$("#segmento").val("");
				 				$("#notasfigado").val("");
				            },
				            error: function(jqXHR, textStatus, errorThrown) 
				            {
				 				if(textStatus=='error')
				 				{
				 					alertify.error('Não foi possível completar o pedido, por favor tente novamente');
				 				}
				 				spinner.stop();
				            }
					    });	
			    	
			    } else {
			    	//alertify.error("Processo de inserção cancelado");
			    }
			});
		}
}

function cancelaredicao()
{
	$("#dadosedicaofigado").hide();
	$("#dadosinsercaofigado").show();
}

function mudaparaedicao(id, tipo, numero, segmento, notas)
{
	$("#nomelesaofigado").val(tipo);
	$("#numeroedicao").val(numero);
	$("#segmentoedicao").val(segmento);
	$("#notasedicaofigado").val(notas);	
	$("#idlesaofigado").val(id);
	
	$("#dadosedicaofigado").show();
	$("#dadosinsercaofigado").hide();
}

function guardaredicao()
{
	var idlesao = $("#idlesaofigado").val();
	var tipolesao = $("#nomelesaofigado").val();
	var numero = $("#numeroedicao").val(); 
	var segmento = $("#segmentoedicao").val(); 
	var notas = $("#notasedicaofigado").val(); 

	var spinner = new Spinner(opts).spin(document.getElementById('spinnergif'));
	
	 $.ajax({
		 url: 'editarlesaofigado',
	     type: 'POST',
	     cache: false,
	     data: {"idlesao": idlesao, "tipolesao" : tipolesao, "numero": numero, "segmento": segmento, "notas": notas},
         success: function(data, textStatus, jqXHR)
         {
        	$("#tabelalesoesfigado").html(data);
			alertify.success("Alteração efectuada com sucesso");
			
			$("#dadosedicaofigado").hide();
			$("#dadosinsercaofigado").show();
			
			spinner.stop();
         },
         error: function(jqXHR, textStatus, errorThrown) 
         {
        	 if(textStatus=='error')
        	 {
				alertify.error('Não foi possível completar o pedido, por favor tente novamente');
			}
        	 spinner.stop();
         }
	    });	
}

function removeleaso(idlesao)
{
	alertify.confirm("Confirma a eliminação da lesão? ", function (c) 
	{
		if (c) 
		{
			var spinner = new Spinner(opts).spin(document.getElementById('spinnergif'));
			
			$.ajax({
				url: 'removerlesaofigado',
				type: 'POST',
			    cache: false,
			    data: {"idlesao": idlesao},
			    success: function(data, textStatus, jqXHR)
			    {
			    	$("#tabelalesoesfigado").html(data);
					alertify.success("Lesao removida com sucesso");
					
					$("#dadosedicaofigado").hide();
					$("#dadosinsercaofigado").show();
					
					spinner.stop();
			    },
			    error: function(jqXHR, textStatus, errorThrown) 
			    {
				    if(textStatus=='error')
				    {
				    	alertify.error('Não foi possível completar o pedido, por favor tente novamente');
					}
				    spinner.stop();
			    }
			});	
		}
		else 
		{
			//alertify.error("Processo de eliminação cancelado");
		}
	});
}