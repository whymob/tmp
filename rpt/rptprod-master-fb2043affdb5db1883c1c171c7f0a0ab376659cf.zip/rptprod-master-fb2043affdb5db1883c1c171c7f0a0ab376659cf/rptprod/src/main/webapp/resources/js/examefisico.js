$(document).ready(function() {

	for(i=1; i<45; i++){
		var valor = $("#q"+i).val();
		
		if(valor == 1){
		    $("#"+i).find('img').toggle();	
		}
	}
	
	
	
});

function trocaimagem(ident,q){
	
    var id = document.getElementById(ident);
    $(id).find('img').toggle();
	//alert("alterar variável: "+ident);
	//alert("quadrante: "+q);
	var quad = "q"+q;
	var valor = $("#"+quad).val();
	if(valor==0){
	$("#"+quad).val(1);
	}else{
	$("#"+quad).val(0);	
	}
}

function salvarexamefisicobotao()
{

	if($("#examefisicogravar").validate({
		rules:{
			pertoracico:{digits: true
			},
			perabdominal:{
				digits: true
				},
			peso: {
			    digits: true    
			    },
			altura: {
			    digits: true
		    },
		},
		  messages: {
			  pertoracico:{
				  digits: "<font color=\"red\">O campo Per. Torácico só permite digitos</font>" 
			  },
			  perabdominal:{
				  digits: "<font color=\"red\">O campo Per. Abdominal só permite digitos</font>" 
			  },
			  peso:{
				  digits: "<font color=\"red\">O campo Peso só permite digitos</font>",
				    },
			  altura: {
				  digits: "<font color=\"red\">O campo Altura só permite digitos</font>",
				},
			  },
		errorLabelContainer: '#errosexamefisico',
		wrapper: "li"
		}).form()){
			
	var spinner = new Spinner(opts).spin(document.getElementById('spinnergif'));

	$.ajax
	({
		url: 'salvarexamefisicobotao',
		type: 'POST',
		data:  $("#examefisicogravar").serialize(),
		success: function(data, textStatus, jqXHR)
		{
			$("#statusexamefisico").attr("src","resources/imagens/green-check.gif");
			alertify.success('Dados gravados com sucesso');
			spinner.stop();
		},
		error: function(jqXHR, textStatus, errorThrown) 
		{
			if(textStatus=='error'){
				alertify.error('Não foi possível completar o pedido, por favor tente novamente');
			}
			spinner.stop();
		}           
	});	

	}else{
		alertify.error('Existem campos que não foram validados, por favor confirme os dados');
	}
}