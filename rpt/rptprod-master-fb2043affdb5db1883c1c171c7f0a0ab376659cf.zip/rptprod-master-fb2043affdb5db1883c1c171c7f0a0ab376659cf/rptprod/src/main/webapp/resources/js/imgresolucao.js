function changeDivImage()    
{   
//change the image path to a string   
var imgPath = new String();        
imgPath = document.getElementById("div1").style.backgroundImage;  

//get screen res of customer
var custHeight=screen.height;
var custWidth=screen.width;

//if their screen width is less than or equal to 640 then use the 640 pic url
if (custWidth <= 640)
    {
    document.getElementById("div1").style.backgroundImage = "url(resources/imagens/surgeons640x480.jpg)";
    }

else if (custWidth <= 800)
    {
    document.getElementById("div1").style.backgroundImage = "url(resources/imagens/surgeons800x600.jpg)";
    }

else if (custWidth <= 1024)
    {
    document.getElementById("div1").style.backgroundImage = "url(resources/imagens/surgeons1024x768.jpg)";
    }

else if (custWidth <= 1280)
    {
    document.getElementById("div1").style.backgroundImage = "url(resources/imagens/surgeons1280x960.jpg)";
    }

else if (custWidth <= 1366)
    {
    document.getElementById("div1").style.backgroundImage = "url(resources/imagens/surgeons1366.jpg)";
    }
else if (custWidth <= 1600)
    {
    document.getElementById("div1").style.backgroundImage = "url(resources/imagens/surgeons1600.jpg)";
    }
else {
    document.getElementById("div1").style.backgroundImage = "url(resources/imagens/surgeons.jpg)";
     }

}