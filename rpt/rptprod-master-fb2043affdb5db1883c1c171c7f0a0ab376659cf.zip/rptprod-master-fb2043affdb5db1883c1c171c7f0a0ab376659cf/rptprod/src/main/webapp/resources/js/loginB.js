/**
 *  Script loginB.jsp
 */

	var opts = {
			  lines: 11, // The number of lines to draw
			  length: 30, // The length of each line
			  width: 13, // The line thickness
			  radius: 25, // The radius of the inner circle
			  corners: 1, // Corner roundness (0..1)
			  rotate: 0, // The rotation offset
			  direction: 1, // 1: clockwise, -1: counterclockwise
			  color: 'grey', // #rgb or #rrggbb or array of colors
			  speed: 1.5, // Rounds per second
			  trail: 60, // Afterglow percentage
			  shadow: true, // Whether to render a shadow
			  hwaccel: true, // Whether to use hardware acceleration
			  className: 'spinner', // The CSS class to assign to the spinner
			  zIndex: 2e9, // The z-index (defaults to 2000000000)
			  top: '50%', // Top position relative to parent
			  left: '50%' // Left position relative to parent
			};


window.onload = function(){
	document.getElementById("pin").addEventListener("keydown", function(e) {
	   // if (!e) { var e = window.event; }
	    //e.preventDefault(); // sometimes useful

	    // Enter is pressed
	    if (e.keyCode == 13)
	    	entrar();
	});5
	
}

function entrar(){
	
	if($("#entrarB").validate({
		rules:{
			codigoOM:{
				digits: true,
			},
			pin:{
				digits: true,
			},
		},
		messages: {
			codigoOM: {
				    	digits: "<font color=\"red\">O campo Código OM é numérico</font>",
				    },
			pin: {
				    	digits: "<font color=\"red\">O campo PIN é numérico</font>",
				    }
				  },
		errorLabelContainer: '#errosloginb',
		wrapper: "li"
		}).form()){
		
	 if((document.getElementById("codigoOM").value.length<1)|| (document.getElementById("pin").value.length<1)){
		 alertify.error('Preencha todos os campos');
	    	//alert("Preencha todos os campos");
	}
	 else{
			var spinner = new Spinner(opts).spin(document.getElementById('spinnergif'));

	 $.ajax({
	        url: 'verificaLoginB',
	        type: 'POST',
	        cache: false,
	        data: $("#entrarB").serialize(),
         success: function(data, textStatus, jqXHR)
         {
        	
   		  if(data=="true"){
  			  $("#entrarB").submit();
  			//  spinner.stop();
  		  }
  		  else{
  			  alertify.error('Código OM ou PIN não reconhecidos, por favor, tente de novo');
  			//alert("Login ou password não reconhecidos, tente de novo");
  			spinner.stop();
  		  }
         },
         error: function(jqXHR, textStatus, errorThrown) 
         {
				if(textStatus=='error'){
				//	alert("Ocorreu um erro,por favor tente novamente");
					alertify.error('Não foi possível completar o pedido, por favor tente novamente');
				//location.href="errorpage";
				}
			spinner.stop();
         }
	    });
	
	 }
	 
	}else{
		alertify.error('Existem campos que não foram validados, por favor confirme os dados');
	}
}