$('#tabelaunidadetransp').dataTable(  {
    initComplete: function () {
        var api = this.api();

        api.columns().indexes().flatten().each( function ( i ) {
            var column = api.column( i );
            var select = $('<select style="max-width: 100px; margin:auto;"><option value=""></option></select>')
                .appendTo( $(column.footer()).empty() )
                .on( 'change', function () {
                    var val = $.fn.dataTable.util.escapeRegex(
                        $(this).val()
                    );

                    column
                        .search( val ? '^'+val+'$' : '', true, false )
                        .draw();
                } );

            column.data().unique().sort().each( function ( d, j ) {
                select.append( '<option value="'+d+'">'+d+'</option>' )
            } );
        } );
    },
		        "language": {
        "sProcessing":   "A processar...",
        "sLengthMenu":   "_MENU_ registos por página",
        "sZeroRecords":  "Não foram encontrados resultados",
        "sInfo":         "A mostrar de _START_ até _END_ de _TOTAL_ registos",
        "sInfoEmpty":    "A mostrar de 0 até 0 de 0 registos",
        "sInfoFiltered": "(a filtrar de _MAX_ registos no total)",
        "sInfoPostFix":  "",
        "sSearch":       "Pesquisar:",
        "sUrl":          "",
        "oPaginate": {
        	"sFirst":    "Primeiro",
        	"sPrevious": "Anterior",
        	"sNext":     "Seguinte",
        	"sLast":     "Último"
        }
    },"order": [[ 1, "asc" ]]
} );

function escolhehospital(idhospital, idassighosp, idassigorgao, event){
	
	valor = false;
	if(event.checked == true){
		valor = true
		
	}
		
		if(idassighosp==''){
			//insere novo hospital para o orgão do dador
			var spinner = new Spinner(opts).spin(document.getElementById('spinnergif'));
			 $.ajax({
			        url: 'inserehospitalorgao',
			        type: 'POST',
			        cache: false,
			        data: {"idassigorgao":idassigorgao, "idhospital":idhospital, "valor":valor},
		      success: function(data, textStatus, jqXHR)
		      {
		    	  		alertify.success('Alteração efectuada com sucesso');
		    	  		$(event).attr("onclick", "escolhehospital("+idhospital+", '"+data+"', "+idassigorgao+", this)");
		    	  		$(event).closest('td').next().html("Em análise");
		    	  		
		    	  		
		    	  		if($("#circulo_"+idassigorgao).attr("fill")=='#FAFAFA' || $("#circulo_"+idassigorgao).attr("fill")=='red'){	
		    	  		$("#circulo_"+idassigorgao).attr("fill", "orange").removeAttr("stroke").removeAttr("stroke-width");
		    	  		}
		    	  	//	verificaorgaosmultiplos();
		    	  		
		    	  		//carregar tabela de histórico
		   			 $.ajax({
		   			        url: 'recarregahistorico',
		   			        type: 'POST',
		   			        cache: false,
		   		      success: function(data, textStatus, jqXHR)
		   		      {
		   		    	$("#historicoassig").html(data);
		   		    	  		
		   						spinner.stop();
		   		      },
		   		      error: function(jqXHR, textStatus, errorThrown) 
		   		      {
		   						if(textStatus=='error'){
		   							alertify.error('Não foi possível completar o pedido, por favor tente novamente');
		   						}
		   		   				spinner.stop();
		   		      }
		   			    });
					//	spinner.stop();
		      },
		      error: function(jqXHR, textStatus, errorThrown) 
		      {
						if(textStatus=='error'){
							alertify.error('Não foi possível completar o pedido, por favor tente novamente');
						}
		   				spinner.stop();
		      }
			    });
			
		}else{
			//atualizacao
			var spinner = new Spinner(opts).spin(document.getElementById('spinnergif'));
			 $.ajax({
			        url: 'atualizahospitalorgao',
			        type: 'POST',
			        cache: false,
			        data: {"idassighosp":idassighosp, "idassigorgao":idassigorgao, "idhospital":idhospital, "valor":valor},
		      success: function(data, textStatus, jqXHR)
		      {
		    	  if(valor){
		    		  	$(event).closest('td').next().html("Em análise");
		    	  		$("#circulo_"+idassigorgao).attr("fill", "orange").removeAttr("stroke").removeAttr("stroke-width");
		    	  }else{
		    	  $(event).closest('td').next().html("Removido");
		    	  }

	    	  		var chk = 0;
	    	  		
	    	  		$("#tabelaunidadetransp tr").each(function(){
	    				if($(this).find('td:eq(1)').find('input').is(":checked"))
	    				{
	    						
	    					chk++;
	    					
	    				}			
	    			});
	    	  		
	    	  		if(chk == 0){ //nenhum hospital seleccionado para esse orgão
	    	  			
			   			 $.ajax({
			   			        url: 'atualizastatusorgaosemhospital',
			   			        type: 'POST',
			   			        cache: false,
			   			     data: {"idassigorgao": idassigorgao},
			   		      success: function(data, textStatus, jqXHR)
			   		      {
			   		    	$("#circulo_"+idassigorgao).attr("fill", "#FAFAFA").attr("stroke", "black").attr("stroke-width", "1");
			   		    		
			   						spinner.stop();
			   		      },
			   		      error: function(jqXHR, textStatus, errorThrown) 
			   		      {
			   						if(textStatus=='error'){
			   							alertify.error('Não foi possível completar o pedido, por favor tente novamente');
			   						}
			   		   				spinner.stop();
			   		      }
			   			    });
	    	  			
	    	  		}
	    	  		
		    			alertify.success('Alteração efectuada com sucesso');
		    			
		    			
			   			 $.ajax({
			   			        url: 'recarregahistorico',
			   			        type: 'POST',
			   			        cache: false,
			   		      success: function(data, textStatus, jqXHR)
			   		      {
			   		    	$("#historicoassig").html(data);
			   		    //	verificaorgaosmultiplos();  		
			   						spinner.stop();
			   		      },
			   		      error: function(jqXHR, textStatus, errorThrown) 
			   		      {
			   						if(textStatus=='error'){
			   							alertify.error('Não foi possível completar o pedido, por favor tente novamente');
			   						}
			   		   				spinner.stop();
			   		      }
			   			    });
					//	spinner.stop();
		      },
		      error: function(jqXHR, textStatus, errorThrown) 
		      {
						if(textStatus=='error'){
							alertify.error('Não foi possível completar o pedido, por favor tente novamente');
						}
		   				spinner.stop();
		      }
			    });
		}	
	
	
}