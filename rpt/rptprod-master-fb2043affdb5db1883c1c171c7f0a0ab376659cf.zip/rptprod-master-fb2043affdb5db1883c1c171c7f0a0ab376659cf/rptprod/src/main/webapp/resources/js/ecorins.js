/**
 * 
 */

var opts = {
		  lines: 11, // The number of lines to draw
		  length: 30, // The length of each line
		  width: 13, // The line thickness
		  radius: 25, // The radius of the inner circle
		  corners: 1, // Corner roundness (0..1)
		  rotate: 0, // The rotation offset
		  direction: 1, // 1: clockwise, -1: counterclockwise
		  color: 'grey', // #rgb or #rrggbb or array of colors
		  speed: 1.5, // Rounds per second
		  trail: 60, // Afterglow percentage
		  shadow: true, // Whether to render a shadow
		  hwaccel: true, // Whether to use hardware acceleration
		  className: 'spinner', // The CSS class to assign to the spinner
		  zIndex: 2e9, // The z-index (defaults to 2000000000)
		  top: '50%', // Top position relative to parent
		  left: '50%' // Left position relative to parent
		};

function editalesoesrins()
{
	var lesoesrins = $("#lesoesrins").is(":checked");
	
	if(lesoesrins == false)
		document.getElementById("dadosrins").style.display = 'none';
	else
		document.getElementById("dadosrins").style.display = 'block';
}

function salvarrinsbotao()
{
	var lesoes = $("#lesoesrins").is(":checked");
	var notasrins = $("#notasecorins").val();
	var calculos = $("#calculosrins").is(":checked");
	var obstrucoes = $("#obstrucoesrins").is(":checked");
	var comp = $("#comp").val();
	var larg = $("#larg").val();
	var esp = $("#esp").val();
	var morfo = $("#morfologia").val();
	
	var calculos2 = $("#calculosrins2").is(":checked");
	var obstrucoes2 = $("#obstrucoesrins2").is(":checked");
	var comp2 = $("#comp2").val();
	var larg2 = $("#larg2").val();
	var esp2 = $("#esp2").val();
	var morfo2 = $("#morfologia2").val();

	if(document.getElementById("horaExamerins").value.length == 0)
	{
		alertify.error('Deve escolher a hora do exame');
	}
	else
	{
		var spinner = new Spinner(opts).spin(document.getElementById('spinnergif'));
		
		var data = document.getElementById("dataExamerins").value;
		var hora = document.getElementById("horaExamerins").value;
		var formatodata = data+" "+hora;
	//	var d=  Date.parse(formatodata).toString('dd/MM/yyyy, HH:mm:ss');
		var d=  new Date(Date.parse(formatodata)).toString('dd/MM/yyyy, HH:mm:ss');
		$("#datahorarins").val(d);
		var datahorarins = $("#datahorarins").val();
		
		$.ajax
		({
			url: 'salvarrins',
			type: 'POST',
			data:  {"datahorarins" : datahorarins, "lesoes" : lesoes, "notasrins" : notasrins, "calculos" : calculos, "obstrucoes" : obstrucoes,
					"comp" : comp, "larg" : larg, "esp" : esp, "morfo" :morfo, "calculos2" : calculos2, "obstrucoes2" : obstrucoes2,
					"comp2" : comp2, "larg2" : larg2, "esp2" : esp2, "morfo2" :morfo2},
			success: function(data, textStatus, jqXHR)
			{
				$("#statusecorins").attr("src","resources/imagens/green-check.gif");
				alertify.success('Dados gravados com sucesso');
				spinner.stop();
			},
			error: function(jqXHR, textStatus, errorThrown) 
			{
				if(textStatus=='error'){
					alertify.error('Não foi possível completar o pedido, por favor tente novamente');
				}
				spinner.stop();
			}           
		});
	}	
}

function carregarlesaorins()
{	
	var tipolesao = $("#tipolesaorins").val();
	var localizacao = $("#localizacaorins").val();
	var notas = $("#notasrins").val();
	
	if(tipolesao == 0 || localizacao == 0)
	{
		alertify.error("Dados inválidos");
	}
	else
		{
			alertify.confirm("Confirma a introdução da lesão? ", function (a) 
			{
			    if (a) 
			    {
					var spinner = new Spinner(opts).spin(document.getElementById('spinnergif'));

					 $.ajax({
					        url: 'addlesaotabelarins',
					        type: 'POST',
					        cache: false,
					        data: {"tipolesao" : tipolesao, "localizacao": localizacao, "notas": notas},
				            success: function(data, textStatus, jqXHR)
				            {
				            	$("#tabelalesoesrins").html(data);
				 				alertify.success("Inserção efectuada com sucesso");
				 				spinner.stop();

				 				$("#tipolesaorins").val(0);
				 				$("#localizacaorins").val(0);
				 				$("#notasrins").val("");
				            },
				            error: function(jqXHR, textStatus, errorThrown) 
				            {
				 				if(textStatus=='error')
				 				{
				 					alertify.error('Não foi possível completar o pedido, por favor tente novamente');
				 				}
				 				spinner.stop();
				            }
					    });	
			    	
			    } else {
			    	alertify.error("Processo de inserção cancelado");
			    }
			});
		}
		
}

function cancelaredicaorins()
{
	$("#dadosedicaorins").hide();
	$("#dadosinsercaorins").show();
}

function mudaparaedicaorins(id, tipolesao, localizacaolesao, notas)
{
	$("#tipolesaorinsedicao").val(tipolesao);
	$("#localizacaorinsedicao").val(localizacaolesao);
		
	$("#idlesaorins").val(id);
	$("#notasedicaorins").val(notas);
	
	$("#dadosedicaorins").show();
	$("#dadosinsercaorins").hide();
}

function guardaredicaorins()
{
	var idlesao = $("#idlesaorins").val();
	var tipolesao = $("#tipolesaorinsedicao").val();
	var localizacao = $("#localizacaorinsedicao").val();
	var notas = $("#notasedicaorins").val();

	var spinner = new Spinner(opts).spin(document.getElementById('spinnergif'));
	
	 $.ajax({
		 url: 'editarlesaorins',
	     type: 'POST',
	     cache: false,
	     data: {"idlesao": idlesao, "tipolesao" : tipolesao, "localizacao": localizacao, "notas": notas},
         success: function(data, textStatus, jqXHR)
         {
        	$("#tabelalesoesrins").html(data);
			alertify.success("Alteração efectuada com sucesso");
			
			$("#dadosedicaorins").hide();
			$("#dadosinsercaorins").show();
			
			spinner.stop();
         },
         error: function(jqXHR, textStatus, errorThrown) 
         {
        	 if(textStatus=='error')
        	 {
				alertify.error('Não foi possível completar o pedido, por favor tente novamente');
			}
        	 spinner.stop();
         }
	    });	
}

function removeleasorins(idlesao)
{
	alertify.confirm("Confirma a eliminação da lesão? ", function (c) 
	{
		if (c) 
		{
			var spinner = new Spinner(opts).spin(document.getElementById('spinnergif'));
			
			$.ajax({
				url: 'removerlesaorins',
				type: 'POST',
			    cache: false,
			    data: {"idlesao": idlesao},
			    success: function(data, textStatus, jqXHR)
			    {
			    	$("#tabelalesoesrins").html(data);
					alertify.success("Lesao removida com sucesso");
					
					$("#dadosedicaorins").hide();
					$("#dadosinsercaorins").show();
					
					spinner.stop();
			    },
			    error: function(jqXHR, textStatus, errorThrown) 
			    {
				    if(textStatus=='error')
				    {
				    	alertify.error('Não foi possível completar o pedido, por favor tente novamente');
					}
				    spinner.stop();
			    }
			});	
		}
		else 
		{
			alertify.error("Processo de eliminação cancelado");
		}
	});
}