$(document).ready(function() {
	
	
	 
	 jQuery("#d31").add("#t31").add("#u31").click(function() 
			  {
			  jQuery("#ecg").toggle("fast");
			  jQuery("#u31").toggle();
			  jQuery("#d31").toggle();
			  });
	 
	 jQuery("#d32").add("#t32").add("#u32").click(function() 
			  {
			  jQuery("#coronografia").toggle("fast");
			  jQuery("#u32").toggle();
			  jQuery("#d32").toggle();
			  });
	 
	 jQuery("#d33").add("#t33").add("#u33").click(function() 
			  {
			  jQuery("#rx").toggle("fast");
			  jQuery("#u33").toggle();
			  jQuery("#d33").toggle();
			  });
	 
	 jQuery("#d34").add("#t34").add("#u34").click(function() 
			  {
			  jQuery("#ecocardio").toggle("fast");
			  jQuery("#u34").toggle();
			  jQuery("#d34").toggle();
			  });
	
	 jQuery("#d35").add("#t35").add("#u35").click(function() 
			  {
			  jQuery("#ecofigado").toggle("fast");
			  jQuery("#u35").toggle();
			  jQuery("#d35").toggle();
			  });
	 
	 jQuery("#d36").add("#t36").add("#u36").click(function() 
			  {
			  jQuery("#ecorins").toggle("fast");
			  jQuery("#u36").toggle();
			  jQuery("#d36").toggle();
			  });	
	 
	 jQuery("#d37").add("#t37").add("#u37").click(function() 
			  {
			  jQuery("#ecopancreas").toggle("fast");
			  jQuery("#u37").toggle();
			  jQuery("#d37").toggle();
			  });	
	 
	 jQuery("#d38").add("#t38").add("#u38").click(function() 
			  {
			  jQuery("#broncofibro").toggle("fast");
			  jQuery("#u38").toggle();
			  jQuery("#d38").toggle();
			  });	
	 
	 jQuery("#d39").add("#t39").add("#u39").click(function() 
			  {
			  jQuery("#bioprenal").toggle("fast");
			  jQuery("#u39").toggle();
			  jQuery("#d39").toggle();
			  });	
	 
	 jQuery("#d40").add("#t40").add("#u40").click(function() 
			  {
			  jQuery("#biophepatica").toggle("fast");
			  jQuery("#u40").toggle();
			  jQuery("#d40").toggle();
			  });
	 jQuery("#d60").add("#t60").add("#u60").click(function() 
			  {
			  jQuery("#explante").toggle("fast");
			  jQuery("#u60").toggle();
			  jQuery("#d60").toggle();
			  });
	 
	 jQuery("#d61").add("#t61").add("#u61").click(function() 
			  {
			  jQuery("#transplante").toggle("fast");
			  jQuery("#u61").toggle();
			  jQuery("#d61").toggle();
			  });
	
});