$('.float').keypress(function(event) {
	
	var charCode = (event.which) ? event.which : event.keyCode;

	if(charCode == 44){   
		//substituir virgula por ponto
    		event.preventDefault();
    		 if($(this).val().indexOf('.') == -1){
				$(this).val($(this).val() + '.');
    		 }
		}else if(charCode==8){
		//apagar
		}else if(charCode < 46 
    || charCode > 59) {
	
        event.preventDefault();
    } 

	//permite só um ponto
    if(charCode == 46
    && $(this).val().indexOf('.') != -1) {
        event.preventDefault();
    } 
});

function registahorasgeral(tipo){
	
	if(tipo==3){
		alertify.confirm("<b>Confirma que a colheita de orgãos foi finalizada?</b> <p> Nota: <font color=\"red\"> Esta ação só deve ser confirmada quando guardadas todas as colheitas de orgãos do cadáver!</font>", function (e) {
		    if (e) {
		    	var spinner = new Spinner(opts).spin(document.getElementById('spinnergif'));
		   	 $.ajax({
		   	        url: 'registahorasgeral',
		   	        type: 'POST',
		   	        cache: false,
		   	        data:  {"tipo" : tipo},
		             success: function(data, textStatus, jqXHR)
		             {
		           	  var d = Date.parse(data).toString('dd/MM/yyyy HH:mm');
		           	  
		           	  if(tipo==1){
		           		  $("#iniciogeral").html(d);    
		           	  }else if(tipo==2){
		           		  $("#clampagemgeral").html(d);
		           	  }else if(tipo==3){
		           		  $("#fimgeral").html(d);	  
		           	  }
		           	 
		           	  alertify.success("Colheita registada com sucesso!");
		   				spinner.stop();
		             },
		             error: function(jqXHR, textStatus, errorThrown) 
		             {
		   				if(textStatus=='error'){
		   				//	alert("Ocorreu um erro,por favor tente novamente");
		   					alertify.error('Não foi possível completar o pedido, por favor tente novamente');
		   				//location.href="errorpage";
		   				}
		   			spinner.stop();
		             }
		   	    });
		    } else {
		    	alertify.error("Finalização de colheita cancelada.");
		    }
		});
		
		
	}else{
		
		var spinner = new Spinner(opts).spin(document.getElementById('spinnergif'));
	   	 $.ajax({
	   	        url: 'registahorasgeral',
	   	        type: 'POST',
	   	        cache: false,
	   	        data:  {"tipo" : tipo},
	             success: function(data, textStatus, jqXHR)
	             {
	           	  var d = Date.parse(data).toString('dd/MM/yyyy HH:mm');
	           	  
	           	  if(tipo==1){
	           		  $("#iniciogeral").html(d);    
	           	  }else if(tipo==2){
	           		  $("#clampagemgeral").html(d);
	           	  }else if(tipo==3){
	           		  $("#fimgeral").html(d);	  
	           	  }
	           	 
	           	  alertify.success("Colheita registada com sucesso!");
	   				spinner.stop();
	             },
	             error: function(jqXHR, textStatus, errorThrown) 
	             {
	   				if(textStatus=='error'){
	   				//	alert("Ocorreu um erro,por favor tente novamente");
	   					alertify.error('Não foi possível completar o pedido, por favor tente novamente');
	   				//location.href="errorpage";
	   				}
	   			spinner.stop();
	             }
	   	    });
	}

	
	
}


function gravaharmoniogeral(){
	
	var spinner = new Spinner(opts).spin(document.getElementById('spinnergif'));
	 $.ajax({
	        url: 'gravacolheitaharmoniogeral',
	        type: 'POST',
	        cache: false,
	        data: $("#formgeral").serialize(),
         success: function(data, textStatus, jqXHR)
         {

        	 alertify.success("Dados gravados com sucesso!");
				spinner.stop();
         },
         error: function(jqXHR, textStatus, errorThrown) 
         {
				if(textStatus=='error'){
				//	alert("Ocorreu um erro,por favor tente novamente");
					alertify.error('Não foi possível completar o pedido, por favor tente novamente');
				//location.href="errorpage";
				}
			spinner.stop();
         }
	    });	
}

//-------------------------Inicio Tabela terapeuticas-----------------------------------------------//

function adicionaterapeuticageral(){
	
	var terapeutica = $("#regterapeutica").val();
	var observacaoterap = $("#regobsterapeutica").val();
	
	var spinner = new Spinner(opts).spin(document.getElementById('spinnergif'));
	 $.ajax({
	        url: 'adicionaterapeuticaharmoniogeral',
	        type: 'POST',
	        cache: false,
	        data: {"terapeutica" : terapeutica, "observacaoterap" : observacaoterap},
        success: function(data, textStatus, jqXHR)
        {
        	$("#tabterapgeral tr:last").after(data);
        	cancelagravaterapgeral();
       	 alertify.success("Dados gravados com sucesso!");
				spinner.stop();
        },
        error: function(jqXHR, textStatus, errorThrown) 
        {
				if(textStatus=='error'){
				//	alert("Ocorreu um erro,por favor tente novamente");
					alertify.error('Não foi possível completar o pedido, por favor tente novamente');
				//location.href="errorpage";
				}
			spinner.stop();
        }
	    });	
}

function editterap(idcolheitaterapeutica, terapeutica, event){
	$("#editterapeutica").val(terapeutica);
	$("#editobsterapeutica").val($(event).closest("tr").find('td:eq(1)').text());
	$("#editidterapeutica").val(idcolheitaterapeutica);
	$("#divregterapgeral").fadeOut(function(){
		$("#diveditterapgeral").fadeIn();	
	});
	
}

function cancelagravaterapgeral(){
	$("#regterapeutica").val(1);
	$("#regobsterapeutica").val("");
	$("#editidterapeutica").val("");
	$("#diveditterapgeral").fadeOut(function(){
		$("#divregterapgeral").fadeIn();	
	});
}

function gravaterapeuticageral(){
	var terapeutica = 		$("#editterapeutica").val();
	var observacaoterap = 	$("#editobsterapeutica").val();
	var idcolheitaterap = 	$("#editidterapeutica").val();
	
	var spinner = new Spinner(opts).spin(document.getElementById('spinnergif'));
	 $.ajax({
	        url: 'gravaterapeuticaharmoniogeral',
	        type: 'POST',
	        cache: false,
	        data: {"terapeutica" : terapeutica, "observacaoterap" : observacaoterap, "idcolheitaterap" : idcolheitaterap},
       success: function(data, textStatus, jqXHR)
       {
    	   
    	   
    	   //alterar linha
    	   $("#ter_"+idcolheitaterap).replaceWith(data);
    	   
       //	$("#tabterapgeral tr:last").after(data);
       	cancelagravaterapgeral();
      	 alertify.success("Dados gravados com sucesso!");
				spinner.stop();
       },
       error: function(jqXHR, textStatus, errorThrown) 
       {
				if(textStatus=='error'){
				//	alert("Ocorreu um erro,por favor tente novamente");
					alertify.error('Não foi possível completar o pedido, por favor tente novamente');
				//location.href="errorpage";
				}
			spinner.stop();
       }
	    });	
}

function delterap(idcolheitaterap, event){
	
	alertify.confirm("Confirma a eliminação  da terapêutica "+$(event).closest("tr").find('td:eq(0)').text()+"?", function (e) {
	    if (e) {
			var spinner = new Spinner(opts).spin(document.getElementById('spinnergif'));
			$.ajax
			({
				url: 'delterapeutica',
				type: 'POST',
				data:  {"idcolheitaterap" : idcolheitaterap},
				success: function(data, textStatus, jqXHR)
				{
					//  $("#tabcomorbilidades").html(data);
					 $("#ter_"+idcolheitaterap).remove();
					 cancelagravaterapgeral();
					  alertify.success('Terapêutica eliminada com sucesso');
					  spinner.stop();
				},
				error: function(jqXHR, textStatus, errorThrown) 
				{
					if(textStatus=='error'){
						alertify.error('Não foi possível completar o pedido, por favor tente novamente');
					}
					  spinner.stop();
				} 
			});	
	    }
	else {
    	alertify.error("Processo de eliminação cancelado");
    }
});
	
}

//-------------------------Fim Tabela terapeuticas-----------------------------------------------//

//-------------------------Inicio Tabela perfusao abdominal-----------------------------------------------//
function adicionaperfabdom(){
	
	var perfusao = $("#regperfabdomperfusao").val();
	var tipo = $("#regperfabdomtipo").val();
	var via = $("#regperfabdomvia").val();
	var volume = $("#regperfabdomvolume").val();
	var inicio = Date.parse($("#regperfabdominicio").val()).toString('HH:mm');
	var fim = Date.parse($("#regperfabdomfim").val()).toString('HH:mm');
	var qualidade = $("#regperfabdomqualidade").val();
	var lote = $("#regperfabdomlote").val();
	var teste = $("#regperfabdomteste").is(":checked");
	
	//volume = volume.replace(/,/g, '.');
	var spinner = new Spinner(opts).spin(document.getElementById('spinnergif'));
	 $.ajax({
	        url: 'adicionaperfabdomharmoniogeral',
	        type: 'POST',
	        cache: false,
	        data: {"perfusao" : perfusao, "tipo" : tipo, "via" : via, "volume" : volume, "inicio" : inicio, "fim" : fim, "qualidade" : qualidade, "lote" : lote, "teste" : teste},
        success: function(data, textStatus, jqXHR)
        {
        	$("#tabperfusaoabdomgeral tr:last").after(data);
        	cancelagravaperfabdom();
        	
       	 alertify.success("Dados gravados com sucesso!");
				spinner.stop();
        },
        error: function(jqXHR, textStatus, errorThrown) 
        {
				if(textStatus=='error'){
				//	alert("Ocorreu um erro,por favor tente novamente");
					alertify.error('Não foi possível completar o pedido, por favor verifique se todos os campos estão preenchidos corretamente.');
				//location.href="errorpage";
				}
			spinner.stop();
        }
	    });	
}

function cancelagravaperfabdom(){
	$("#divregperfabdom input").val("");
	$("#divregperfabdom select").val(1);
	$("#regperfabdomteste").prop('checked', false);
	$("#diveditperfabdom").fadeOut(function(){
		$("#divregperfabdom").fadeIn();	
	});
}

function editperfabdom(idperfabdominal, perfusao, tipo, via, qualidade, teste, event){
	
	$("#editidperfabdom").val(idperfabdominal);
	$("#editperfabdomperfusao").val(perfusao);
	$("#editperfabdomtipo").val(tipo);
	$("#editperfabdomvia").val(via);
	$("#editerfabdomvolume").val($(event).closest("tr").find('td:eq(3)').text());
	$("#editperfabdominicio").val($(event).closest("tr").find('td:eq(4)').text());
	$("#editperfabdomfim").val($(event).closest("tr").find('td:eq(5)').text());
	$("#editperfabdomqualidade").val(qualidade);
	$("#editperfabdomlote").val($(event).closest("tr").find('td:eq(7)').text());
	$("#editperfabdomteste").prop('checked', teste);

	
	$("#divregperfabdom").fadeOut(function(){
		$("#diveditperfabdom").fadeIn();	
	});
	
}


function gravaperfabdom(){
	
	var idperfabdom = 	$("#editidperfabdom").val();
	var perfusao = $("#editperfabdomperfusao").val();
	var tipo = $("#editperfabdomtipo").val();
	var via = $("#editperfabdomvia").val();
	var volume = $("#editerfabdomvolume").val();
	var inicio = $("#editperfabdominicio").val();
	var fim = $("#editperfabdomfim").val();
	var qualidade = $("#editperfabdomqualidade").val();
	var lote = $("#editperfabdomlote").val();
	var teste = $("#editperfabdomteste").is(":checked");

	
	var spinner = new Spinner(opts).spin(document.getElementById('spinnergif'));
	 $.ajax({
	        url: 'gravaperfabdomharmoniogeral',
	        type: 'POST',
	        cache: false,
	        data: {"idperfabdom" : idperfabdom, "perfusao" : perfusao, "tipo" : tipo, "via" : via, "volume" : volume, "inicio" : inicio, "fim" : fim, "qualidade" : qualidade, "lote" : lote, "teste" : teste},
       success: function(data, textStatus, jqXHR)
       {
    	   
    	   
    	   //alterar linha
    	   $("#perf_"+idperfabdom).replaceWith(data);
    	   
       //	$("#tabterapgeral tr:last").after(data);
    	   cancelagravaperfabdom();
      	 alertify.success("Dados gravados com sucesso!");
				spinner.stop();
       },
       error: function(jqXHR, textStatus, errorThrown) 
       {
				if(textStatus=='error'){
				//	alert("Ocorreu um erro,por favor tente novamente");
					alertify.error('Não foi possível completar o pedido, por favor tente novamente');
				//location.href="errorpage";
				}
			spinner.stop();
       }
	    });	
}



function delperfabdom(idperfabdom, event){
	
	alertify.confirm("Confirma a eliminação  da perfusão "+$(event).closest("tr").find('td:eq(0)').text()+"?", function (e) {
	    if (e) {
			var spinner = new Spinner(opts).spin(document.getElementById('spinnergif'));
			$.ajax
			({
				url: 'delperfabdomharmoniogeral',
				type: 'POST',
				data:  {"idperfabdom" : idperfabdom},
				success: function(data, textStatus, jqXHR)
				{
					//  $("#tabcomorbilidades").html(data);
					 $("#perf_"+idperfabdom).remove();
					 cancelagravaperfabdom();
					  alertify.success('Perfusão eliminada com sucesso');
					  spinner.stop();
				},
				error: function(jqXHR, textStatus, errorThrown) 
				{
					if(textStatus=='error'){
						alertify.error('Não foi possível completar o pedido, por favor tente novamente');
					}
					  spinner.stop();
				} 
			});	
	    }
	else {
    	alertify.error("Processo de eliminação cancelado");
    }
});
	
}

//-------------------------Fim Tabela perfusao abdominal-----------------------------------------------//

//-------------------------Inicio Tabela perfusao toracica-----------------------------------------------//
function adicionaperftorax(){
	
	var perfusao = $("#regperftoraxperfusao").val();
	var tipo = $("#regperftoraxtipo").val();
	var via = $("#regperftoraxvia").val();
	var volume = $("#regperftoraxvolume").val();
	var inicio = $("#regperftoraxinicio").val();
	var fim = $("#regperftoraxfim").val();
	var qualidade = $("#regperftoraxqualidade").val();
	var lote = $("#regperftoraxlote").val();
	var teste = $("#regperftoraxteste").is(":checked");
	
	
	var spinner = new Spinner(opts).spin(document.getElementById('spinnergif'));
	 $.ajax({
	        url: 'adicionaperftoraxharmoniogeral',
	        type: 'POST',
	        cache: false,
	        data: {"perfusao" : perfusao, "tipo" : tipo, "via" : via, "volume" : volume, "inicio" : inicio, "fim" : fim, "qualidade" : qualidade, "lote" : lote, "teste" : teste},
        success: function(data, textStatus, jqXHR)
        {
        	$("#tabperfusaotoraxgeral tr:last").after(data);
        	cancelagravaperftorax();
        	
       	 alertify.success("Dados gravados com sucesso!");
				spinner.stop();
        },
        error: function(jqXHR, textStatus, errorThrown) 
        {
				if(textStatus=='error'){
				//	alert("Ocorreu um erro,por favor tente novamente");
					alertify.error('Não foi possível completar o pedido, por favor verifique se todos os campos estão preenchidos corretamente.');
				//location.href="errorpage";
				}
			spinner.stop();
        }
	    });	
}

function cancelagravaperftorax(){
	$("#divregperftorax input").val("");
	$("#divregperftorax select").val(1);
	$("#regperftoraxteste").prop('checked', false);
	$("#diveditperftorax").fadeOut(function(){
		$("#divregperftorax").fadeIn();	
	});
}

function editperftorax(idperftorax, perfusao, tipo, via, qualidade, teste, event){
	
	$("#editidperftorax").val(idperftorax);
	$("#editperftoraxperfusao").val(perfusao);
	$("#editperftoraxtipo").val(tipo);
	$("#editperftoraxvia").val(via);
	$("#editerftoraxvolume").val($(event).closest("tr").find('td:eq(3)').text());
	$("#editperftoraxinicio").val($(event).closest("tr").find('td:eq(4)').text());
	$("#editperftoraxfim").val($(event).closest("tr").find('td:eq(5)').text());
	$("#editperftoraxqualidade").val(qualidade);
	$("#editperftoraxlote").val($(event).closest("tr").find('td:eq(7)').text());
	$("#editperftoraxteste").prop('checked', teste);

	
	$("#divregperftorax").fadeOut(function(){
		$("#diveditperftorax").fadeIn();	
	});
	
}


function gravaperftorax(){
	
	var idperftorax = 	$("#editidperftorax").val();
	var perfusao = $("#editperftoraxperfusao").val();
	var tipo = $("#editperftoraxtipo").val();
	var via = $("#editperftoraxvia").val();
	var volume = $("#editerftoraxvolume").val();
	var inicio = $("#editperftoraxinicio").val();
	var fim = $("#editperftoraxfim").val();
	var qualidade = $("#editperftoraxqualidade").val();
	var lote = $("#editperftoraxlote").val();
	var teste = $("#editperftoraxteste").is(":checked");

	
	var spinner = new Spinner(opts).spin(document.getElementById('spinnergif'));
	 $.ajax({
	        url: 'gravaperftoraxharmoniogeral',
	        type: 'POST',
	        cache: false,
	        data: {"idperftorax" : idperftorax, "perfusao" : perfusao, "tipo" : tipo, "via" : via, "volume" : volume, "inicio" : inicio, "fim" : fim, "qualidade" : qualidade, "lote" : lote, "teste" : teste},
       success: function(data, textStatus, jqXHR)
       {
    	   
    	   
    	   //alterar linha
    	   $("#perftorax_"+idperftorax).replaceWith(data);
    	   
       //	$("#tabterapgeral tr:last").after(data);
    	   cancelagravaperftorax();
      	 alertify.success("Dados gravados com sucesso!");
				spinner.stop();
       },
       error: function(jqXHR, textStatus, errorThrown) 
       {
				if(textStatus=='error'){
				//	alert("Ocorreu um erro,por favor tente novamente");
					alertify.error('Não foi possível completar o pedido, por favor tente novamente');
				//location.href="errorpage";
				}
			spinner.stop();
       }
	    });	
}



function delperftorax(idperftorax, event){
	
	alertify.confirm("Confirma a eliminação  da perfusão "+$(event).closest("tr").find('td:eq(0)').text()+"?", function (e) {
	    if (e) {
			var spinner = new Spinner(opts).spin(document.getElementById('spinnergif'));
			$.ajax
			({
				url: 'delperftoraxharmoniogeral',
				type: 'POST',
				data:  {"idperftorax" : idperftorax},
				success: function(data, textStatus, jqXHR)
				{
					//  $("#tabcomorbilidades").html(data);
					 $("#perftorax_"+idperftorax).remove();
					 cancelagravaperftorax();
					  alertify.success('Perfusão eliminada com sucesso');
					  spinner.stop();
				},
				error: function(jqXHR, textStatus, errorThrown) 
				{
					if(textStatus=='error'){
						alertify.error('Não foi possível completar o pedido, por favor tente novamente');
					}
					  spinner.stop();
				} 
			});	
	    }
	else {
    	alertify.error("Processo de eliminação cancelado");
    }
});
	
}

//-------------------------Fim Tabela perfusao toracica-----------------------------------------------//

