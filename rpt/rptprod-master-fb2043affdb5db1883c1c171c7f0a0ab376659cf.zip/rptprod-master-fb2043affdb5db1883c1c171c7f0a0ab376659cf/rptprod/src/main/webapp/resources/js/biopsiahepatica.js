$(document).ready(function () {
    var charReg = /^\s*[a-zA-Z0-9,.\s]+\s*$/;
    $(".warning2").hide();
    $('#nomehepatica').keyup(function () {
        var inputVal = $(this).val();
        if (!charReg.test(inputVal)) {
            $(this).parent().find(".warning2").show();
        } else {
            $(this).parent().find(".warning2").hide();
        }

    });
    
    
    
    //tamanho do ficheiro para upload
    $("#ficheirohepatica").change(function (){
    		     var iSize = ($("#ficheirohepatica")[0].files[0].size / 1024);
    		     if (iSize / 1024 > 1)
    		     {
    		        if (((iSize / 1024) / 1024) > 1)
    		        {
    		            iSize = (Math.round(((iSize / 1024) / 1024) * 100) / 100);
    		            $("#lbltamanhohepatica").html( iSize + "Gb");
    		        }
    		        else
    		        {
    		            iSize = (Math.round((iSize / 1024) * 100) / 100)
    		            if(iSize<=10){
    		            	$("#lbltamanhohepatica").html( iSize + "Mb");
    		            }else{
    		            	$("#lbltamanhohepatica").html( iSize + "Mb");
    		        		alertify.error('O ficheiro escolhido excede o limite de 10Mb, por favor escolha um ficheiro dentro do limite imposto');	
    		            }
    		        }
    		     }
    		     else
    		     {
    		        iSize = (Math.round(iSize * 100) / 100)
    		        $("#lbltamanhohepatica").html( iSize  + "kb");
    		     }   
    });
    
    
    
    
});


function gravarbiopsiahepatica(){
	
	var d=  new Date(Date.parse($("#databiopsiahepatica").val())).toString('dd/MM/yyyy, HH:mm:ss');
	$("#databiohepatica").val(d);
	
	var spinner = new Spinner(opts).spin(document.getElementById('spinnergif'));
	
	 $.ajax({
	        url: 'gravarbiopsiahepatica',
	        type: 'POST',
	        cache: false,
	        data: $("#formbiohepatica").serialize(),
          success: function(data, textStatus, jqXHR)
          {
        	  $("#statusbiohepatica").attr("src","resources/imagens/green-check.gif");
        	  alertify.success('Biópsia Hepática guardada com sucesso.');
				spinner.stop();
          },
          error: function(jqXHR, textStatus, errorThrown) 
          {
				if(textStatus=='error'){
					alertify.error('Não foi possível gravar a biopsia, por favor tente de novo mais tarde');
				}
				spinner.stop();
          }
	    });	
}

function uploadhepatica(){
	
	if($('#nomehepatica').val()==""){
			alertify.error('É necessário seleccionar um ficheiro');	
	}else{
	
	
	function getDoc(frame) {
	     var doc = null;
	 
	     // IE8 verificação do acesso em cascata
	     try {
	         if (frame.contentWindow) {
	             doc = frame.contentWindow.document;
	         }
	     } catch(err) {
	     }
	 
	     if (doc) { // conteudo obtido com sucesso
	         return doc;
	     }
	 
	     try { 
	         doc = frame.contentDocument ? frame.contentDocument : frame.document;
	     } catch(err) {
	         // ultima tentativa
	         doc = frame.document;
	     }
	     return doc;
	 }
	$("#enviarficheirohepatica").submit(function(e)
	{
	 
	    var formObj = $(this);
	    var formURL = formObj.attr("action");
	 
	    if(window.FormData !== undefined)  // para browsers HTML5
	    {
	    	var spinner = new Spinner(opts).spin(document.getElementById('spinnergif'));
	        var formData = new FormData(this);
	        $.ajax({
	            url: formURL,
	            type: 'POST',
	            data:  formData,
	            mimeType:"multipart/form-data",
	            contentType: false,
	            cache: false,
	            processData:false,
	            success: function(data, textStatus, jqXHR)
	            {
	 				alertify.success(data);
	 				var id_biohepatica = $('#id_hepatica').val();
	 				$.post("carreganomedocbiohepatica", {'id_biohepatica' : id_biohepatica}, function(resposta) {
	 					$("#caminhodocbiohepatica").html(resposta);
	 					spinner.stop();
	 				});
	            },
	            error: function(jqXHR, textStatus, errorThrown) 
	            {
	 				if(textStatus=='error'){
	 				//	alert("Ocorreu um erro,por favor tente novamente");
	 					alertify.error('Não foi possível completar o pedido, por favor tente novamente');
	 				//location.href="errorpage";
	 				}
	 				spinner.stop();
	            }           
	       });
	        e.preventDefault();
	        //e.unbind(); // não usar, antes o stopImmediatePropagation()
	        e.stopImmediatePropagation();
	   }
	   else  //para browsers antigos
	    {
	        //gerar um id aleatório
	        var  iframeId = 'unique' + (new Date().getTime());
	 
	        //criar um iframe vazio
	        var iframe = $('<iframe src="javascript:false;" name="'+iframeId+'" />');
	 
	        //esconder o iframe
	        iframe.hide();
	 
	        //definir o alvo do form para o iframe
	        formObj.attr('target',iframeId);
	 
	        //Adicionar o iframe ao body
	        iframe.appendTo('body');
	        iframe.load(function(e)
	        {
	            var doc = getDoc(iframe[0]);
	            var docRoot = doc.body ? doc.body : doc.documentElement;
	            var data = docRoot.innerHTML;
	            //dados do servidor server.
	 
	        });
	 
	    }     
	});
	$("#enviarficheirohepatica").submit();
	}
	
}

function alterafilehepatica(){
	
	//atualizar input nome ficheiro para possibilitar escolher nome
	var n = $('#ficheirohepatica').val().replace(/C:\\fakepath\\/i, '');
	var nome = n.replace(/[^a-z0-9.\s]/gi, '').replace(/[_\s]/g, ' ');
	$('#nomehepatica').val(nome);
}