/**
 * 
 */

$('.notnullint').blur(function(event) {
	if($(this).val()==''){
		$(this).val("0");
	}
});

$('.numdigitos2').keypress(function(event) {
	if($(this).val().length>=2){
		event.preventDefault();
	}
});

function salvarhcgeral()
{


	if($("#hcgeralgravar").validate({
		rules:{
			hipertensaoanos:{digits: true
			},
			diabetesanos:{
				digits: true
				},
		},
		  messages: {
			  hipertensaoanos:{
				  digits: "<font color=\"red\">O campo Anos de Hipertensão só permite digitos</font>" 
			  },
			  diabetesanos:{
				  digits: "<font color=\"red\">O campo Anos de diabetes só permite digitos</font>" 
			  },
			  },
		errorLabelContainer: '#erroshcgeral',
		wrapper: "li"
		}).form()){	
	
	
	
	var spinner = new Spinner(opts).spin(document.getElementById('spinnergif'));
	if($("#hipertensaoanos").val()==''){
		
		$("#hipertensaoanos").val('0');
	}
	if($("#diabetesanos").val()==''){
		
		$("#diabetesanos").val('0');
	}
	
	$.ajax
	({
		url: 'salvargeral',
		type: 'POST',
		data:  $("#hcgeralgravar").serialize(),
		success: function(data, textStatus, jqXHR)
		{
			$("#statusgeral").attr("src","resources/imagens/green-check.gif");
			alertify.success('Dados gravados com sucesso');
			spinner.stop();
		},
		error: function(jqXHR, textStatus, errorThrown) 
		{
			if(textStatus=='error'){
				alertify.error('Não foi possível completar o pedido, por favor tente novamente');
			}
				spinner.stop();
		}           
	});	
	

	}else{
		alertify.error('Existem campos que não foram validados, por favor confirme os dados');
	}
}


