
$('#tabmestrehospitalunidtransp').dataTable(  {
    initComplete: function () {
        var api = this.api();

        api.columns().indexes().flatten().each( function ( i ) {
            var column = api.column( i );
            var select = $('<select><option value=""></option></select>')
                .appendTo( $(column.footer()).empty() )
                .on( 'change', function () {
                    var val = $.fn.dataTable.util.escapeRegex(
                        $(this).val()
                    );

                    column
                        .search( val ? '^'+val+'$' : '', true, false )
                        .draw();
                } );

            column.data().unique().sort().each( function ( d, j ) {
                select.append( '<option value="'+d+'">'+d+'</option>' )
            } );
        } );
    },
		        "language": {
        "sProcessing":   "A processar...",
        "sLengthMenu":   "_MENU_ registos por página",
        "sZeroRecords":  "Não foram encontrados resultados",
        "sInfo":         "A mostrar de _START_ até _END_ de _TOTAL_ registos",
        "sInfoEmpty":    "A mostrar de 0 até 0 de 0 registos",
        "sInfoFiltered": "(a filtrar de _MAX_ registos no total)",
        "sInfoPostFix":  "",
        "sSearch":       "Pesquisar:",
        "sUrl":          "",
        "oPaginate": {
        	"sFirst":    "Primeiro",
        	"sPrevious": "Anterior",
        	"sNext":     "Seguinte",
        	"sLast":     "Último"
        }
    },"order": [[ 1, "asc" ]]
} );


function alteradadoshospunidades(id_hosp){
	
	var spinner = new Spinner(opts).spin(document.getElementById('spinnergif'));
  	 $.ajax({
  	        url: 'mostraunidtransphospital',
  	        type: 'POST',
  	        data: {"id_hosp" : id_hosp},
      success: function(data, textStatus, jqXHR)
      {
    	  			$("#divunidtransphospital").hide();
   					$("#divunidtransphospital").html(data);
   					$("#divunidtransphospital").show(400);
   					spinner.stop();
      },
      error: function(jqXHR, textStatus, errorThrown) 
      {
  				if(textStatus=='error'){
  					alertify.error('Não foi possível completar o pedido, por favor tente novamente.');
  					spinner.stop();
  				}
      }
  	    });

}

function removerunidtransphospital(id_unidtransp, event){
	
	var id_hospital = $("#id_hospital").val();  
	var nomeunid = event.parentNode.parentNode.cells[0].innerHTML;
	
	alertify.confirm("Confirma a remoção da Unidade de Transplante \""+nomeunid+"\" do Hospital \""+$("#nomehosp").text()+"\"?", function (e) {
	if (e) {
				var spinner = new Spinner(opts).spin(document.getElementById('spinnergif'));
			 	 $.ajax({
			 	        url: 'removeunidtransphospital',
			 	        type: 'POST',
			 	        data: {"id_unidtransp" : id_unidtransp, "id_hospital": id_hospital},
			     success: function(data, textStatus, jqXHR)
			     {
			  					$("#divunidtransphospital").html(data);
			  					spinner.stop();
			  					alertify.success("Remoção efetuada com sucesso!");
			     },
			     error: function(jqXHR, textStatus, errorThrown) 
			     {
			 				if(textStatus=='error'){
			 					alertify.error('Não foi possível completar o pedido, por favor tente novamente.');
			 					spinner.stop();
			 				}
			     }
			 	 });
 	 } else {
	    	alertify.error("Processo de remoção cancelado");
	    }
	});
}

function adicionarunidtransp(){
	
	var unidade = $("#unidtransp").val();	
	var id_hospital = $("#id_hospital").val();
	var nomeunidade = $("#unidtransp option:selected").text();

	if(unidade == 0){
		
		alertify.error('É necessário seleccionar uma unidade de transplante a adicionar ao Hospital!');
	}else{
		
		alertify.confirm("Confirma a inserção da Unidade de Transplante \""+nomeunidade+"\" ao Hospital?", function (e) {
			if (e) {
						var spinner = new Spinner(opts).spin(document.getElementById('spinnergif'));
					 	 $.ajax({
					 	        url: 'adicionaunidtransphospital',
					 	        type: 'POST',
					 	        data: {"id_unidtransp" : unidade, "id_hospital": id_hospital},
					     success: function(data, textStatus, jqXHR)
					     {
					  					$("#divunidtransphospital").html(data);
					  					spinner.stop();
					  					alertify.success("Inserção  efetuada com sucesso!");
					     },
					     error: function(jqXHR, textStatus, errorThrown) 
					     {
					 				if(textStatus=='error'){
					 					alertify.error('Não foi possível completar o pedido, por favor tente novamente.');
					 					spinner.stop();
					 				}
					     }
					 	    });
		 	 } else {
			    	alertify.error("Processo de inserção cancelado");
			    }
			});
		
		
		
	}
	
}