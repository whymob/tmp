$('.float').keypress(function(event) {
	
	var charCode = (event.which) ? event.which : event.keyCode;

	if(charCode == 44){   
		//substituir virgula por ponto
    		event.preventDefault();
    		 if($(this).val().indexOf('.') == -1){
				$(this).val($(this).val() + '.');
    		 }
		}else if(charCode==8){
		//apagar
		}else if(charCode < 46 
    || charCode > 59) {
	
        event.preventDefault();
    } 

	//permite só um ponto
    if(charCode == 46
    && $(this).val().indexOf('.') != -1) {
        event.preventDefault();
    } 
});


function registahoraspancreas(tipo){
	
	var spinner = new Spinner(opts).spin(document.getElementById('spinnergif'));
	 $.ajax({
	        url: 'registahoraspancreas',
	        type: 'POST',
	        cache: false,
	        data:  {"tipo" : tipo},
          success: function(data, textStatus, jqXHR)
          {
        	  var d = Date.parse(data).toString('dd/MM/yyyy HH:mm');
        	  
        	  if(tipo==1){
        		  $("#iniciopancreas").html(d);    
        	  }else if(tipo==2){
        		  $("#fimpancreas").html(d);	  
        	  }
				spinner.stop();
          },
          error: function(jqXHR, textStatus, errorThrown) 
          {
				if(textStatus=='error'){
				//	alert("Ocorreu um erro,por favor tente novamente");
					alertify.error('Não foi possível completar o pedido, por favor tente novamente');
				//location.href="errorpage";
				}
			spinner.stop();
          }
	    });
}


function gravaharmoniopancreas(){
	
	
	var coddador = $("#dadorcod").text();
	var estadopancreas = $("#estadopancreas").val();
	
	$("#pancreascod").val("");
	$("#lblcodpancreas").text("");
	
	
	if(estadopancreas!=3 && estadopancreas!=0){
	$("#pancreascod").val(coddador+"-PA");
	$("#lblcodpancreas").text(coddador+"-PA");
	}
	
	var spinner = new Spinner(opts).spin(document.getElementById('spinnergif'));
	 $.ajax({
	        url: 'gravacolheitaharmoniopancreas',
	        type: 'POST',
	        cache: false,
	        data: $("#formpancreas").serialize(),
         success: function(data, textStatus, jqXHR)
         {
        	alertify.success("Dados gravados com sucesso!");
			spinner.stop();
         },
         error: function(jqXHR, textStatus, errorThrown) 
         {
				if(textStatus=='error'){
				//	alert("Ocorreu um erro,por favor tente novamente");
					alertify.error('Não foi possível completar o pedido, por favor tente novamente');
				//location.href="errorpage";
				}
			spinner.stop();
         }
	    });	
}



function pancreasalteraestado(estado){
	
	if(estado==1){
		var frase = "validado";
	}else if(estado==2){
		
		var frase = "condicional";
	}else if(estado==3){
		var frase = "não validado";
	}
		
		alertify.confirm("Confirma a alteração do estado do orgão para "+frase+"?", function (e) {
		    if (e) {
					var spinner = new Spinner(opts).spin(document.getElementById('spinnergif'));
					 $.ajax({
					        url: 'gravacolheitaestadopancreas',
					        type: 'POST',
					        cache: false,
					        data: {"estado": estado},
				         success: function(data, textStatus, jqXHR)
				         {
				        	 if(data=='OK'){
						        	 if(estado==1){
							        		 $("#divestadopancreas").html("<label style=\"color: green;\"><b>Orgão válido </b></label><img alt=\"Orgão validado\" src=\"resources/imagens/green-check.gif\" style=\"width: 20px; height: 20px; vertical-align: bottom;\">");
							        		 $("#estadopancreas").val(1);
						        	 }else if(estado==2){
							        		 $("#divestadopancreas").html("<label style=\"color: orange;\"><b>Orgão estado condicional </b></label><img alt=\"Orgão estado condicional\" src=\"resources/imagens/warning.png\" style=\"width: 20px; height: 20px; vertical-align: bottom;\">");
							        		 $("#estadopancreas").val(2);
						        	 }
						        	 else if(estado==3){
							        		 $("#divestadopancreas").html("<label style=\"color: red;\"><b>Orgão não válido </b></label><img alt=\"Orgão não válido\" src=\"resources/imagens/SA1.png\" style=\"width: 20px; height: 20px; vertical-align: bottom;\">");
							        		 $("#estadopancreas").val(3);
						        	 }
						        	 var coddador = $("#dadorcod").text();
						        		var estadopancreas = $("#estadopancreas").val();
						        		
						        		$("#pancreascod").val("");
						        		$("#lblcodpancreas").text("");
						        		
						        		
						        		if(estadopancreas!=3 && estadopancreas!=0){
						        		$("#pancreascod").val(coddador+"-PA");
						        		$("#lblcodpancreas").text(coddador+"-PA");
						        		}

						        		 $.ajax({
						        		        url: 'gravacolheitaharmoniopancreas',
						        		        type: 'POST',
						        		        cache: false,
						        		        data: $("#formpancreas").serialize(),
						        	         success: function(data, textStatus, jqXHR)
						        	         {
						        	        	alertify.success("Estado do pâncreas alterado com sucesso!");
						        				spinner.stop();
						        	         },
						        	         error: function(jqXHR, textStatus, errorThrown) 
						        	         {
						        					if(textStatus=='error'){
						        					//	alert("Ocorreu um erro,por favor tente novamente");
						        						alertify.error('Não foi possível completar o pedido, por favor tente novamente');
						        					//location.href="errorpage";
						        					}
						        				spinner.stop();
						        	         }
						        		    });
						        	
				        	 }
								spinner.stop();
				         },
				         error: function(jqXHR, textStatus, errorThrown) 
				         {
								if(textStatus=='error'){
								//	alert("Ocorreu um erro,por favor tente novamente");
									alertify.error('Não foi possível completar o pedido, por favor tente novamente');
								//location.href="errorpage";
								}
							spinner.stop();
				         }
					    });	
		    } else {
		    	alertify.error("Processo cancelado");
		    }
		});
	
}


//-------------------------Inicio Tabela perfusao pancreas-----------------------------------------------//
function adicionaperfpancreas(){
	
	var perfusao = $("#regperfpancreasperfusao").val();
	var tipo = $("#regperfpancreastipo").val();
	//var via = $("#regperfabdomvia").val();
	var volume = $("#regperfpancreasvolume").val();
	var inicio = $("#regperfpancreasinicio").val();
	var fim = $("#regperfpancreasfim").val();
	var qualidade = $("#regperfpancreasqualidade").val();
	var lote = $("#regperfpancreaslote").val();
	var teste = $("#regperfpancreasteste").is(":checked");
	
	
	var spinner = new Spinner(opts).spin(document.getElementById('spinnergif'));
	 $.ajax({
	        url: 'adicionaperfharmoniopancreas',
	        type: 'POST',
	        cache: false,
	        data: {"perfusao" : perfusao, "tipo" : tipo, "volume" : volume, "inicio" : inicio, "fim" : fim, "qualidade" : qualidade, "lote" : lote, "teste" : teste},
        success: function(data, textStatus, jqXHR)
        {
        	$("#tabperfusaopancreas tr:last").after(data);
        	cancelagravaperfpancreas();
        	
       	 alertify.success("Dados gravados com sucesso!");
				spinner.stop();
        },
        error: function(jqXHR, textStatus, errorThrown) 
        {
				if(textStatus=='error'){
				//	alert("Ocorreu um erro,por favor tente novamente");
					alertify.error('Não foi possível completar o pedido, por favor verifique se todos os campos estão preenchidos corretamente.');
				//location.href="errorpage";
				}
			spinner.stop();
        }
	    });	
}

function cancelagravaperfpancreas(){
	$("#divregperfpancreas input").val("");
	$("#divregperfpancreas select").val(1);
	$("#regperfpancreasteste").prop('checked', false);
	$("#diveditperfpancreas").fadeOut(function(){
		$("#divregperfpancreas").fadeIn();	
	});
}

function editperfpancreas(idperfpancreas, perfusao, tipo, qualidade, teste, event){
	
	$("#editidperfpancreas").val(idperfpancreas);
	$("#editperfpancreasperfusao").val(perfusao);
	$("#editperfpancreastipo").val(tipo);
	//$("#editperfabdomvia").val(via);
	$("#editerfpancreasvolume").val($(event).closest("tr").find('td:eq(2)').text());
	$("#editperfpancreasinicio").val($(event).closest("tr").find('td:eq(3)').text());
	$("#editperfpancreasfim").val($(event).closest("tr").find('td:eq(4)').text());
	$("#editperfpancreasqualidade").val(qualidade);
	$("#editperfpancreaslote").val($(event).closest("tr").find('td:eq(6)').text());
	$("#editperfpancreasteste").prop('checked', teste);

	
	$("#divregperfpancreas").fadeOut(function(){
		$("#diveditperfpancreas").fadeIn();	
	});
	
}


function gravaperfpancreas(){
	
	var idperfpancreas = 	$("#editidperfpancreas").val();
	var perfusao = $("#editperfpancreasperfusao").val();
	var tipo = $("#editperfpancreastipo").val();
	//var via = $("#editperfabdomvia").val();
	var volume = $("#editerfpancreasvolume").val();
	var inicio = $("#editperfpancreasinicio").val();
	var fim = $("#editperfpancreasfim").val();
	var qualidade = $("#editperfpancreasqualidade").val();
	var lote = $("#editperfpancreaslote").val();
	var teste = $("#editperfpancreasteste").is(":checked");

	
	var spinner = new Spinner(opts).spin(document.getElementById('spinnergif'));
	 $.ajax({
	        url: 'gravaperfharmoniopancreas',
	        type: 'POST',
	        cache: false,
	        data: {"idperfpancreas" : idperfpancreas, "perfusao" : perfusao, "tipo" : tipo, "volume" : volume, "inicio" : inicio, "fim" : fim, "qualidade" : qualidade, "lote" : lote, "teste" : teste},
       success: function(data, textStatus, jqXHR)
       {
    	   
    	   
    	   //alterar linha
    	   $("#perfpancreas_"+idperfpancreas).replaceWith(data);
    	   
       //	$("#tabterapgeral tr:last").after(data);
    	   cancelagravaperfpancreas();
      	 alertify.success("Dados gravados com sucesso!");
				spinner.stop();
       },
       error: function(jqXHR, textStatus, errorThrown) 
       {
				if(textStatus=='error'){
				//	alert("Ocorreu um erro,por favor tente novamente");
					alertify.error('Não foi possível completar o pedido, por favor tente novamente');
				//location.href="errorpage";
				}
			spinner.stop();
       }
	    });	
}



function delperfpancreas(idperfpancreas, event){
	
	alertify.confirm("Confirma a eliminação  da perfusão "+$(event).closest("tr").find('td:eq(0)').text()+"?", function (e) {
	    if (e) {
			var spinner = new Spinner(opts).spin(document.getElementById('spinnergif'));
			$.ajax
			({
				url: 'delperfpancreas',
				type: 'POST',
				data:  {"idperfpancreas" : idperfpancreas},
				success: function(data, textStatus, jqXHR)
				{
					//  $("#tabcomorbilidades").html(data);
					 $("#perfpancreas_"+idperfpancreas).remove();
					 cancelagravaperfpancreas();
					  alertify.success('Perfusão eliminada com sucesso');
					  spinner.stop();
				},
				error: function(jqXHR, textStatus, errorThrown) 
				{
					if(textStatus=='error'){
						alertify.error('Não foi possível completar o pedido, por favor tente novamente');
					}
					  spinner.stop();
				} 
			});	
	    }
	else {
    	alertify.error("Processo de eliminação cancelado");
    }
});
	
}

//-------------------------Fim Tabela perfusao pancreas-----------------------------------------------//



//-------------------------Inicio Tabela produtos-----------------------------------------------//

function adicionaprodpancreas(){
	
	var produto = $("#regprodpancreas").val();
	var observacaoprod = $("#regobsprodpancreas").val();
	
	var spinner = new Spinner(opts).spin(document.getElementById('spinnergif'));
	 $.ajax({
	        url: 'adicionaprodpancreasharmoniopancreas',
	        type: 'POST',
	        cache: false,
	        data: {"produto" : produto, "observacaoprod" : observacaoprod},
        success: function(data, textStatus, jqXHR)
        {
        	$("#tabproddescontduoden tr:last").after(data);
        	cancelagravaprodpancreas();
       	 alertify.success("Dados gravados com sucesso!");
				spinner.stop();
        },
        error: function(jqXHR, textStatus, errorThrown) 
        {
				if(textStatus=='error'){
				//	alert("Ocorreu um erro,por favor tente novamente");
					alertify.error('Não foi possível completar o pedido, por favor tente novamente');
				//location.href="errorpage";
				}
			spinner.stop();
        }
	    });	
}

function editprodpancreasd(idcolheitaprodpancreas, produto, event){
	$("#editprodpancreas").val(produto);
	$("#editobsprodpancreas").val($(event).closest("tr").find('td:eq(1)').text());
	$("#editidprodpancreas").val(idcolheitaprodpancreas);
	$("#divregprodpancreas").fadeOut(function(){
		$("#diveditprodpancreas").fadeIn();	
	});
	
}

function cancelagravaprodpancreas(){
	$("#regprodpancreas").val(1);
	$("#regobsprodpancreas").val("");
	$("#editidprodpancreas").val("");
	$("#diveditprodpancreas").fadeOut(function(){
		$("#divregprodpancreas").fadeIn();	
	});
}

function gravaprodpancreas(){
	var produto = 		$("#editprodpancreas").val();
	var observacaoproduto = 	$("#editobsprodpancreas").val();
	var idcolheitaprodpancreas = 	$("#editidprodpancreas").val();
	
	var spinner = new Spinner(opts).spin(document.getElementById('spinnergif'));
	 $.ajax({
	        url: 'gravaprodutoharmoniopancreas',
	        type: 'POST',
	        cache: false,
	        data: {"produto" : produto, "observacaoproduto" : observacaoproduto, "idcolheitaprodpancreas" : idcolheitaprodpancreas},
       success: function(data, textStatus, jqXHR)
       {
    	   
    	   
    	   //alterar linha
    	   $("#prodpancreas_"+idcolheitaprodpancreas).replaceWith(data);
    	   
       //	$("#tabterapgeral tr:last").after(data);
       	cancelagravaprodpancreas();
      	 alertify.success("Dados gravados com sucesso!");
				spinner.stop();
       },
       error: function(jqXHR, textStatus, errorThrown) 
       {
				if(textStatus=='error'){
				//	alert("Ocorreu um erro,por favor tente novamente");
					alertify.error('Não foi possível completar o pedido, por favor tente novamente');
				//location.href="errorpage";
				}
			spinner.stop();
       }
	    });	
}

function delprodpancreas(idcolheitaprodpancreas, event){
	
	alertify.confirm("Confirma a eliminação  do produto "+$(event).closest("tr").find('td:eq(0)').text()+"?", function (e) {
	    if (e) {
			var spinner = new Spinner(opts).spin(document.getElementById('spinnergif'));
			$.ajax
			({
				url: 'delprodpancreas',
				type: 'POST',
				data:  {"idcolheitaprodpancreas" : idcolheitaprodpancreas},
				success: function(data, textStatus, jqXHR)
				{
					//  $("#tabcomorbilidades").html(data);
					 $("#prodpancreas_"+idcolheitaprodpancreas).remove();
					 cancelagravaprodpancreas();
					  alertify.success('Produto eliminado com sucesso');
					  spinner.stop();
				},
				error: function(jqXHR, textStatus, errorThrown) 
				{
					if(textStatus=='error'){
						alertify.error('Não foi possível completar o pedido, por favor tente novamente');
					}
					  spinner.stop();
				} 
			});	
	    }
	else {
    	alertify.error("Processo de eliminação cancelado");
    }
});
	
}

//-------------------------Fim Tabela produtos-----------------------------------------------//