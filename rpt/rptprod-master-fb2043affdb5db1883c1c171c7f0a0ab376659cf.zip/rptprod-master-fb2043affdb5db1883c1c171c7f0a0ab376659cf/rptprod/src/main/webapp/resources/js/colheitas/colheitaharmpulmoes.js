function registahoraspulmoes(tipo){
	
	var spinner = new Spinner(opts).spin(document.getElementById('spinnergif'));
	 $.ajax({
	        url: 'registahoraspulmoes',
	        type: 'POST',
	        cache: false,
	        data:  {"tipo" : tipo},
          success: function(data, textStatus, jqXHR)
          {
        	  var d = Date.parse(data).toString('dd/MM/yyyy HH:mm');
        	  
        	  if(tipo==1){
        		  $("#iniciopulmoes").html(d);    
        	  }else if(tipo==2){
        		  $("#fimpulmoes").html(d);	  
        	  }
				spinner.stop();
          },
          error: function(jqXHR, textStatus, errorThrown) 
          {

				alertify.error('Não foi possível completar o pedido, por favor tente novamente');
				spinner.stop();
          }
	    });
}

function gravaharmoniopulmoes(){
	
	var coddador = $("#dadorcod").text();
	var estadopulmaoesq = $("#estadopulmaoesq").val();
	var estadopulmaodir = $("#estadopulmaodir").val();
	
	//Inicializar vazio
	$("#pulmesqcod").val("");
	$("#lblcodpulmesq").text("");
	$("#pulmdircod").val("");
	$("#lblcodpulmdir").text("");
	
	
	if(estadopulmaoesq!=3 && estadopulmaoesq!=0){
	$("#pulmesqcod").val(coddador+"-PE");
	$("#lblcodpulmesq").text(coddador+"-PE");
	}
	
	if(estadopulmaodir!=3 && estadopulmaodir!=0){
	$("#pulmdircod").val(coddador+"-PD");
	$("#lblcodpulmdir").text(coddador+"-PD");
	}
	
	var spinner = new Spinner(opts).spin(document.getElementById('spinnergif'));
	 $.ajax({
	        url: 'gravacolheitaharmoniopulmoes',
	        type: 'POST',
	        cache: false,
	        data: $("#formpulmoes").serialize(),
         success: function(data, textStatus, jqXHR)
         {

        	 alertify.success("Dados gravados com sucesso!");
				spinner.stop();
         },
         error: function(jqXHR, textStatus, errorThrown) 
         {
				if(textStatus=='error'){
				//	alert("Ocorreu um erro,por favor tente novamente");
					alertify.error('Não foi possível completar o pedido, por favor tente novamente');
				//location.href="errorpage";
				}
			spinner.stop();
         }
	    });	
}

function pulmaoalteraestado(lado, estado){
	
	if(estado==1){
		var frase = "validado";
	}else if(estado==2){
		
		var frase = "condicional";
	}else if(estado==3){
		var frase = "não validado";
	}
		
		alertify.confirm("Confirma a alteração do estado do orgão para "+frase+"?", function (e) {
		    if (e) {
					var spinner = new Spinner(opts).spin(document.getElementById('spinnergif'));
					 $.ajax({
					        url: 'gravacolheitaestadopulmoes',
					        type: 'POST',
					        cache: false,
					        data: {"lado" : lado, "estado": estado},
				         success: function(data, textStatus, jqXHR)
				         {
				        	 if(data=='OK'){
						        	 if(estado==1){
							        	 if(lado==1){
							        		 $("#divestadopulmaoesq").html("<label style=\"color: green;\"><b>Orgão válido </b></label><img alt=\"Orgão validado\" src=\"resources/imagens/green-check.gif\" style=\"width: 20px; height: 20px; vertical-align: bottom;\">");
							        		 $("#estadopulmaoesq").val(1);
							        	 }else{
							        		 $("#divestadopulmaodir").html("<label style=\"color: green;\"><b>Orgão válido </b></label><img alt=\"Orgão validado\" src=\"resources/imagens/green-check.gif\" style=\"width: 20px; height: 20px; vertical-align: bottom;\">");	 
							        		 $("#estadopulmaodir").val(1);
							        	 }
						        	 }else if(estado==2){
						        		 if(lado==1){
							        		 $("#divestadopulmaoesq").html("<label style=\"color: orange;\"><b>Orgão estado condicional </b></label><img alt=\"Orgão estado condicional\" src=\"resources/imagens/warning.png\" style=\"width: 20px; height: 20px; vertical-align: bottom;\">");
							        		 $("#estadopulmaoesq").val(2);
							        	 }else{
							        		 $("#divestadopulmaodir").html("<label style=\"color: orange;\"><b>Orgão estado condicional </b></label><img alt=\"Orgão estado condicional\" src=\"resources/imagens/warning.png\" style=\"width: 20px; height: 20px; vertical-align: bottom;\">");
							        		 $("#estadopulmaodir").val(2);
							        	 } 
						        	 }
						        	 else if(estado==3){
						        		 if(lado==1){
							        		 $("#divestadopulmaoesq").html("<label style=\"color: red;\"><b>Orgão não válido </b></label><img alt=\"Orgão não válido\" src=\"resources/imagens/SA1.png\" style=\"width: 20px; height: 20px; vertical-align: bottom;\">");
							        		 $("#estadopulmaoesq").val(3);
							        	 }else{
							        		 $("#divestadopulmaodir").html("<label style=\"color: red;\"><b>Orgão não válido </b></label><img alt=\"Orgão não válido\" src=\"resources/imagens/SA1.png\" style=\"width: 20px; height: 20px; vertical-align: bottom;\">");	
							        		 $("#estadopulmaodir").val(3);
							        	 } 
						        	 }
						        	 var coddador = $("#dadorcod").text();
						        		var estadopulmaoesq = $("#estadopulmaoesq").val();
						        		var estadopulmaodir = $("#estadopulmaodir").val();
						        		
						        		//Inicializar vazio
						        		$("#pulmesqcod").val("");
						        		$("#lblcodpulmesq").text("");
						        		$("#pulmdircod").val("");
						        		$("#lblcodpulmdir").text("");
						        		
						        		
						        		if(estadopulmaoesq!=3 && estadopulmaoesq!=0){
						        		$("#pulmesqcod").val(coddador+"-PE");
						        		$("#lblcodpulmesq").text(coddador+"-PE");
						        		}
						        		
						        		if(estadopulmaodir!=3 && estadopulmaodir!=0){
						        		$("#pulmdircod").val(coddador+"-PD");
						        		$("#lblcodpulmdir").text(coddador+"-PD");
						        		}
						        		
						        		 $.ajax({
						        		        url: 'gravacolheitaharmoniopulmoes',
						        		        type: 'POST',
						        		        cache: false,
						        		        data: $("#formpulmoes").serialize(),
						        	         success: function(data, textStatus, jqXHR)
						        	         {

						        	        	 alertify.success("Estado do pulmao alterado com sucesso!");
						        					spinner.stop();
						        	         },
						        	         error: function(jqXHR, textStatus, errorThrown) 
						        	         {
						        					if(textStatus=='error'){
						        					//	alert("Ocorreu um erro,por favor tente novamente");
						        						alertify.error('Não foi possível completar o pedido, por favor tente novamente');
						        					//location.href="errorpage";
						        					}
						        				spinner.stop();
						        	         }
						        		    });	
						        	
				        	 }
								spinner.stop();
				         },
				         error: function(jqXHR, textStatus, errorThrown) 
				         {
								if(textStatus=='error'){
								//	alert("Ocorreu um erro,por favor tente novamente");
									alertify.error('Não foi possível completar o pedido, por favor tente novamente');
								//location.href="errorpage";
								}
							spinner.stop();
				         }
					    });	
		    } else {
		    	alertify.error("Processo cancelado");
		    }
		});
	
}


//-------------------------Inicio Tabela tratamento-----------------------------------------------//

function adicionatratpulmoes(){
	
	var tratamento = $("#regtratpulmoes").val();
	var observacaotrat = $("#regobstratpulmoes").val();
	
	var spinner = new Spinner(opts).spin(document.getElementById('spinnergif'));
	 $.ajax({
	        url: 'adicionatratharmoniopulmoes',
	        type: 'POST',
	        cache: false,
	        data: {"tratamento" : tratamento, "observacaotrat" : observacaotrat},
        success: function(data, textStatus, jqXHR)
        {
        	$("#tabtratpulmoes tr:last").after(data);
        	cancelagravatratpulmoes();
       	 alertify.success("Dados gravados com sucesso!");
				spinner.stop();
        },
        error: function(jqXHR, textStatus, errorThrown) 
        {
				if(textStatus=='error'){
				//	alert("Ocorreu um erro,por favor tente novamente");
					alertify.error('Não foi possível completar o pedido, por favor tente novamente');
				//location.href="errorpage";
				}
			spinner.stop();
        }
	    });	
}

function edittratamentopulmoes(idcolheitatratpulmoes, tratamento, event){
	$("#edittratpulmoes").val(tratamento);
	$("#editobstratpulmoes").val($(event).closest("tr").find('td:eq(1)').text());
	$("#editidtratpulmoes").val(idcolheitatratpulmoes);
	$("#divregtratpulmoes").fadeOut(function(){
		$("#divedittratpulmoes").fadeIn();	
	});
	
}

function cancelagravatratpulmoes(){
	$("#regtratpulmoes").val(1);
	$("#regobstratpulmoes").val("");
	$("#editidtratpulmoes").val("");
	$("#divedittratpulmoes").fadeOut(function(){
		$("#divregtratpulmoes").fadeIn();	
	});
}

function gravatratpulmoes(){
	var tratamento = 		$("#edittratpulmoes").val();
	var observacaotrat = 	$("#editobstratpulmoes").val();
	var idcolheitatrat = 	$("#editidtratpulmoes").val();
	
	var spinner = new Spinner(opts).spin(document.getElementById('spinnergif'));
	 $.ajax({
	        url: 'gravatratamentoharmoniopulmoes',
	        type: 'POST',
	        cache: false,
	        data: {"tratamento" : tratamento, "observacaotrat" : observacaotrat, "idcolheitatrat" : idcolheitatrat},
       success: function(data, textStatus, jqXHR)
       {
    	   
    	   
    	   //alterar linha
    	   $("#tratpulmoes_"+idcolheitatrat).replaceWith(data);
    	   
       //	$("#tabterapgeral tr:last").after(data);
    	   cancelagravatratpulmoes();
      	 alertify.success("Dados gravados com sucesso!");
				spinner.stop();
       },
       error: function(jqXHR, textStatus, errorThrown) 
       {
				if(textStatus=='error'){
				//	alert("Ocorreu um erro,por favor tente novamente");
					alertify.error('Não foi possível completar o pedido, por favor tente novamente');
				//location.href="errorpage";
				}
			spinner.stop();
       }
	    });	
}

function deltratpulmoes(idcolheitatrat, event){
	
	alertify.confirm("Confirma a eliminação  do tratamento "+$(event).closest("tr").find('td:eq(0)').text()+"?", function (e) {
	    if (e) {
			var spinner = new Spinner(opts).spin(document.getElementById('spinnergif'));
			$.ajax
			({
				url: 'deltratpulmoes',
				type: 'POST',
				data:  {"idcolheitatrat" : idcolheitatrat},
				success: function(data, textStatus, jqXHR)
				{
					//  $("#tabcomorbilidades").html(data);
					 $("#tratpulmoes_"+idcolheitatrat).remove();
					 cancelagravatratpulmoes();
					  alertify.success('Tratamento eliminado com sucesso');
					  spinner.stop();
				},
				error: function(jqXHR, textStatus, errorThrown) 
				{
					if(textStatus=='error'){
						alertify.error('Não foi possível completar o pedido, por favor tente novamente');
					}
					  spinner.stop();
				} 
			});	
	    }
	else {
    	alertify.error("Processo de eliminação cancelado");
    }
});
	
}

//-------------------------Fim Tabela tratamento-----------------------------------------------//