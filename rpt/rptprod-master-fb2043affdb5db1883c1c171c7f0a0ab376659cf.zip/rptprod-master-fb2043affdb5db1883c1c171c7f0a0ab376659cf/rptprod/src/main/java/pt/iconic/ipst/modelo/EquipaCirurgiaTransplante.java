package pt.iconic.ipst.modelo;

import java.util.Calendar;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name = "EQUIPA_CIRURGIA_TRANSPLANTE")
public class EquipaCirurgiaTransplante {

	private Long idequipacirurgiatransplante;
//	private FaseCirurgia fase;
//	private Dador dador;
	private Calendar horaprevista;
	private String nomecirurgiao;
	private Utilizador utilizador;
	private int ordem;
	private String nummecanografico;
	private int contato;
	private String transporte;
	private Long inicio;
	private boolean principal;
	private AssignacaoOrgaos assigorgao;
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="ID_EQUIPA_CIRURGIA")
	public Long getIdequipacirurgiatransplante() {
		return idequipacirurgiatransplante;
	}
	public void setIdequipacirurgiatransplante(Long idequipacirurgiatransplante) {
		this.idequipacirurgiatransplante = idequipacirurgiatransplante;
	}
	
//    @ManyToOne(fetch = FetchType.EAGER)
//    @JoinColumn(name = "ID_FASE")
//	public FaseCirurgia getFase() {
//		return fase;
//	}
//	public void setFase(FaseCirurgia fase) {
//		this.fase = fase;
//	}
//	
//    @ManyToOne(fetch = FetchType.EAGER)
//    @JoinColumn(name = "ID_DADOR")
//	public Dador getDador() {
//		return dador;
//	}
//	public void setDador(Dador dador) {
//		this.dador = dador;
//	}
	
	@Column(name="HORA_PREVISTA")
	public Calendar getHoraprevista() {
		return horaprevista;
	}
	public void setHoraprevista(Calendar horaprevista) {
		this.horaprevista = horaprevista;
	}
	
	@Column(name="NOME_CIRURGIAO")
	public String getNomecirurgiao() {
		return nomecirurgiao;
	}
	public void setNomecirurgiao(String nomecirurgiao) {
		this.nomecirurgiao = nomecirurgiao;
	}
	
    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "ID_UTILIZADOR")
	public Utilizador getUtilizador() {
		return utilizador;
	}
	public void setUtilizador(Utilizador utilizador) {
		this.utilizador = utilizador;
	}
	
	@Column(name="ORDEM")
	public int getOrdem() {
		return ordem;
	}
	public void setOrdem(int ordem) {
		this.ordem = ordem;
	}
	
	@Column(name="NUM_MECANOGRAF")
	public String getNummecanografico() {
		return nummecanografico;
	}
	public void setNummecanografico(String nummecanografico) {
		this.nummecanografico = nummecanografico;
	}
	
	@Column(name="CONTATO")
	public int getContato() {
		return contato;
	}
	public void setContato(int contato) {
		this.contato = contato;
	}
	
	@Column(name="TRANSPORTE")
	public String getTransporte() {
		return transporte;
	}
	public void setTransporte(String transporte) {
		this.transporte = transporte;
	}
	
	@Column(name="INICIO")
	public Long getInicio() {
		return inicio;
	}
	public void setInicio(Long inicio) {
		this.inicio = inicio;
	}
	
	@Column(name="PRINCIPAL")
	public boolean isPrincipal() {
		return principal;
	}
	public void setPrincipal(boolean principal) {
		this.principal = principal;
	}
	
    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "ID_ASSIG_ORGAO")
	public AssignacaoOrgaos getAssigorgao() {
		return assigorgao;
	}
	public void setAssigorgao(AssignacaoOrgaos assigorgao) {
		this.assigorgao = assigorgao;
	}
	
}
