package pt.iconic.ipst.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.springframework.stereotype.Repository;

import pt.iconic.ipst.modelo.TipoMicroorganismo;

@Repository
public class TipoMicroorganismoDAO {

	@PersistenceContext
	private EntityManager manager;
	
	
/*	public void adiciona(TipoMicroorganismo tipomicroorganismo){
		manager.persist(tipomicroorganismo);	
	}
	
	public void atualiza(TipoMicroorganismo tipomicroorganismo){
		manager.merge(tipomicroorganismo);
	}*/
	
	
	@SuppressWarnings("unchecked")
	public List<TipoMicroorganismo> ListaTipoMicroorganismo(){
		return manager.createQuery("select d from TipoMicroorganismo d").getResultList();
	}
	
/*	public TipoMicroorganismo buscaPorId(Long id){
		return manager.find(TipoMicroorganismo.class, id);
	}
	
	
	public void remove(TipoMicroorganismo tipomicroorganismo){
		TipoMicroorganismo tipomicroorganismoARemover = buscaPorId(tipomicroorganismo.getId_tipomicroorganismo());
		manager.remove(tipomicroorganismoARemover);
	}*/
	
	
	
}
