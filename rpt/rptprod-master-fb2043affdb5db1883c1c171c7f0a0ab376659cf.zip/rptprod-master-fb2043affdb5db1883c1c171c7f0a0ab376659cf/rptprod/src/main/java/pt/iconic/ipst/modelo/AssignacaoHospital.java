package pt.iconic.ipst.modelo;

import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;


@Entity
@Table(name = "ASSIGNACAO_HOSPITAL")
public class AssignacaoHospital {

	
	private Long id_assignacaohospital;
	private Hospital hospital;
	private AssignacaoOrgaos assignacaoorgao;
	private boolean escolher;
	private StatusAssignacaoHospital estadoassighosp;
	private List<HistoricoAssignacao> historico;
	//private Recetores recetor;
	
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="ID_ASSIGNACAO_HOSPITAL")
	public Long getId_assignacaohospital() {
		return id_assignacaohospital;
	}
	public void setId_assignacaohospital(Long id_assignacaohospital) {
		this.id_assignacaohospital = id_assignacaohospital;
	}
	
    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "ID_HOSPITAL")
	public Hospital getHospital() {
		return hospital;
	}
	public void setHospital(Hospital hospital) {
		this.hospital = hospital;
	}
	
    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "ID_ASSIGNACAO_ORGAO")
	public AssignacaoOrgaos getAssignacaoorgao() {
		return assignacaoorgao;
	}
	public void setAssignacaoorgao(AssignacaoOrgaos assignacaoorgao) {
		this.assignacaoorgao = assignacaoorgao;
	}
	
	@Column(name="SELECCIONADO")
    public boolean isEscolher() {
		return escolher;
	}
	public void setEscolher(boolean escolher) {
		this.escolher = escolher;
	}
	@ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "ID_ESTADO")
	public StatusAssignacaoHospital getEstadoassighosp() {
		return estadoassighosp;
	}
	public void setEstadoassighosp(StatusAssignacaoHospital estadoassighosp) {
		this.estadoassighosp = estadoassighosp;
	}
	
	@OneToMany(fetch = FetchType.LAZY, mappedBy = "assighosp")
	public List<HistoricoAssignacao> getHistorico() {
		return historico;
	}
	public void setHistorico(List<HistoricoAssignacao> historico) {
		this.historico = historico;
	}

}
