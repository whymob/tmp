package pt.iconic.ipst.modelo;

import java.util.Calendar;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;


@Entity
@Table(name = "COLHEITA_CORACAO")
public class ColheitaCoracao {

	private Long idcolheitacoracao;
	private Calendar iniciocoracao;
	private Calendar fimcoracao;
	private int morfologia;
	private int popcoronormal;
	private String notascoracao;
	private int tipoperf;
	private int pressao;
	private int assistolia;
	private float volume;
	private Calendar horaassistolia;
	private String tempo;
	private String notasperf;
	private int estadocoracao;
	private AnaliseDador analiseDador;
	private String codcoracao;
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="ID_COLHEITA_CORACAO")
	public Long getIdcolheitacoracao() {
		return idcolheitacoracao;
	}
	public void setIdcolheitacoracao(Long idcolheitacoracao) {
		this.idcolheitacoracao = idcolheitacoracao;
	}
	
	@Column(name="INICIO")
	public Calendar getIniciocoracao() {
		return iniciocoracao;
	}
	public void setIniciocoracao(Calendar iniciocoracao) {
		this.iniciocoracao = iniciocoracao;
	}
	
	@Column(name="FIM")
	public Calendar getFimcoracao() {
		return fimcoracao;
	}
	public void setFimcoracao(Calendar fimcoracao) {
		this.fimcoracao = fimcoracao;
	}
	
	@Column(name="MORFOLOGIA")
	public int getMorfologia() {
		return morfologia;
	}
	public void setMorfologia(int morfologia) {
		this.morfologia = morfologia;
	}
	
	@Column(name="POPCORONORMAL")
	public int getPopcoronormal() {
		return popcoronormal;
	}
	public void setPopcoronormal(int popcoronormal) {
		this.popcoronormal = popcoronormal;
	}
	
	@Column(name="NOTAS_CORACAO")
	public String getNotascoracao() {
		return notascoracao;
	}
	public void setNotascoracao(String notascoracao) {
		this.notascoracao = notascoracao;
	}
	
	@Column(name="TIPO_PERFUSAO")
	public int getTipoperf() {
		return tipoperf;
	}
	public void setTipoperf(int tipoperf) {
		this.tipoperf = tipoperf;
	}
	
	@Column(name="PRESSAO")
	public int getPressao() {
		return pressao;
	}
	public void setPressao(int pressao) {
		this.pressao = pressao;
	}
	
	@Column(name="ASSISTOLIA")
	public int getAssistolia() {
		return assistolia;
	}
	public void setAssistolia(int assistolia) {
		this.assistolia = assistolia;
	}
	
	@Column(name="VOLUME")
	public float getVolume() {
		return volume;
	}
	public void setVolume(float volume) {
		this.volume = volume;
	}
	
	@Column(name="HORA_ASSISTOLIA")
	public Calendar getHoraassistolia() {
		return horaassistolia;
	}
	public void setHoraassistolia(Calendar horaassistolia) {
		this.horaassistolia = horaassistolia;
	}
	
	@Column(name="TEMPO")
	public String getTempo() {
		return tempo;
	}
	public void setTempo(String tempo) {
		this.tempo = tempo;
	}
	
	@Column(name="NOTAS_PERFUSAO")
	public String getNotasperf() {
		return notasperf;
	}
	public void setNotasperf(String notasperf) {
		this.notasperf = notasperf;
	}
	
	@Column(name="ESTADO_CORACAO")
	public int getEstadocoracao() {
		return estadocoracao;
	}
	public void setEstadocoracao(int estadocoracao) {
		this.estadocoracao = estadocoracao;
	}
	
	@OneToOne(fetch=FetchType.EAGER)
	@JoinColumn(name="ID_ANALISEDADOR")
	public AnaliseDador getAnaliseDador() {
		return analiseDador;
	}
	public void setAnaliseDador(AnaliseDador analiseDador) {
		this.analiseDador = analiseDador;
	}
	
	@Column(name="COD_CORACAO")
	public String getCodcoracao() {
		return codcoracao;
	}
	public void setCodcoracao(String codcoracao) {
		this.codcoracao = codcoracao;
	}
	
	
	
}
