package pt.iconic.ipst.modelo;

import java.util.Calendar;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name = "IMUNOLOGIA")
public class Imunologia {    //TIPAGEM HLA

	private Long Id_Imunologia;
	private AnaliseDador analiseDador;
	private double aum;
	private double adois;
	private double bum;
	private double bdois;
	private double cum;
	private double cdois;
	private double drum;
	private double drdois;
	private double dqum;
	private double dqdois;
	private boolean statusharmimuno;
	private Calendar datagravacao;
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="ID_IMUNOLOGIA")
	public Long getId_Imunologia() {
		return Id_Imunologia;
	}
	public void setId_Imunologia(Long id_Imunologia) {
		Id_Imunologia = id_Imunologia;
	}
	
	@OneToOne
	@JoinColumn(name="ID_ANALISEDADOR")
	public AnaliseDador getAnaliseDador() {
		return analiseDador;
	}
	public void setAnaliseDador(AnaliseDador analiseDador) {
		this.analiseDador = analiseDador;
	}
	
	@Column(name="AUM")
	public double getAum() {
		return aum;
	}
	public void setAum(double aum) {
		this.aum = aum;
	}
	
	@Column(name="ADOIS")
	public double getAdois() {
		return adois;
	}
	public void setAdois(double adois) {
		this.adois = adois;
	}
	
	@Column(name="BUM")
	public double getBum() {
		return bum;
	}
	public void setBum(double bum) {
		this.bum = bum;
	}
	
	@Column(name="BDOIS")
	public double getBdois() {
		return bdois;
	}
	public void setBdois(double bdois) {
		this.bdois = bdois;
	}
	
	@Column(name="DRUM")
	public double getDrum() {
		return drum;
	}
	public void setDrum(double drum) {
		this.drum = drum;
	}
	
	@Column(name="DRDOIS")
	public double getDrdois() {
		return drdois;
	}
	public void setDrdois(double drdois) {
		this.drdois = drdois;
	}
	
	@Column(name="DQUM")
	public double getDqum() {
		return dqum;
	}
	public void setDqum(double dqum) {
		this.dqum = dqum;
	}
	
	@Column(name="DQDOIS")
	public double getDqdois() {
		return dqdois;
	}
	public void setDqdois(double dqdois) {
		this.dqdois = dqdois;
	}
	
	@Column(name="CUM")
	public double getCum() {
		return cum;
	}
	public void setCum(double cum) {
		this.cum = cum;
	}
	
	@Column(name="CDOIS")
	public double getCdois() {
		return cdois;
	}
	public void setCdois(double cdois) {
		this.cdois = cdois;
	}
	
	@Column(name="STATUSHARMONIO")	
	public boolean isStatusharmimuno() {
		return statusharmimuno;
	}
	public void setStatusharmimuno(boolean statusharmimuno) {
		this.statusharmimuno = statusharmimuno;
	}
	
	@Column(name="DATAGRAVACAO")
	public Calendar getDatagravacao() {
		return datagravacao;
	}


	public void setDatagravacao(Calendar datagravacao) {
		this.datagravacao = datagravacao;
	}
}