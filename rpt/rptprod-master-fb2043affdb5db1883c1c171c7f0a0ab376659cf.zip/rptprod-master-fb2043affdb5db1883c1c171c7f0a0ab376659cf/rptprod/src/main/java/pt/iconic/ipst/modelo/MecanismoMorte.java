package pt.iconic.ipst.modelo;

import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name = "MECANISMOMORTE")
public class MecanismoMorte{

	
	private Long Id_MecanismoMorte;
	private String DescMecanismoMorte;
	private List<BDAvaliacaoInicial> BDAvaliacaoInicial;
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="ID_MECANISMOMORTE")
	public Long getId_MecanismoMorte() {
		return Id_MecanismoMorte;
	}
	public void setId_MecanismoMorte(Long id_MecanismoMorte) {
		Id_MecanismoMorte = id_MecanismoMorte;
	}
	
	@Column(name="DESCMECANISMOMORTE")
	public String getDescMecanismoMorte() {
		return DescMecanismoMorte;
	}
	public void setDescMecanismoMorte(String descMecanismoMorte) {
		DescMecanismoMorte = descMecanismoMorte;
	}
	
	@OneToMany(fetch = FetchType.LAZY, mappedBy = "mecanismoMorte")
	public List<BDAvaliacaoInicial> getBDAvaliacaoInicial() {
		return BDAvaliacaoInicial;
	}
	public void setBDAvaliacaoInicial(List<BDAvaliacaoInicial> bDAvaliacaoInicial) {
		BDAvaliacaoInicial = bDAvaliacaoInicial;
	}	
}