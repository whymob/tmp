package pt.iconic.ipst.controller;

import java.util.UUID;

import javax.mail.MessagingException;
import javax.mail.internet.MimeMessage;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import pt.iconic.ipst.dao.DadorDAO;
import pt.iconic.ipst.dao.EquipaExplantesDAO;
import pt.iconic.ipst.dao.EquipaTransplantesDAO;
import pt.iconic.ipst.dao.EspecialidadesDAO;
import pt.iconic.ipst.dao.EstadoDadorDAO;
import pt.iconic.ipst.dao.GCCTColheitaDAO;
import pt.iconic.ipst.dao.GlasgowCommaDAO;
import pt.iconic.ipst.dao.HospitalDAO;
import pt.iconic.ipst.dao.PermissaoAuxDAO;
import pt.iconic.ipst.dao.PermissaoDAO;
import pt.iconic.ipst.dao.PosicaoDAO;
import pt.iconic.ipst.dao.RecetoresDAO;
import pt.iconic.ipst.dao.UtilizadorBDAO;
import pt.iconic.ipst.dao.UtilizadorDAO;
import pt.iconic.ipst.modelo.Hospital;
import pt.iconic.ipst.modelo.PermissaoLocalizacao;
import pt.iconic.ipst.modelo.Posicao;
import pt.iconic.ipst.modelo.Utilizador;
import pt.iconic.ipst.modelo.UtilizadorB;

@Controller
public class LoginController 
{
	private UtilizadorDAO daouser;
	private UtilizadorBDAO daouserB;
	private DadorDAO daoDador;
	private PosicaoDAO daopos;
	private PermissaoDAO daoperm;
	private HospitalDAO daohosp;
	private PermissaoAuxDAO daopermaux;
	private GlasgowCommaDAO daoglasg;
	private EspecialidadesDAO daoespec;
	private EstadoDadorDAO daoest;
	private RecetoresDAO daorecetores;
	private EquipaTransplantesDAO daoeqtransplantes;
	private EquipaExplantesDAO daoeqexplantes;
	private GCCTColheitaDAO daogcctcolheita;
	
    @Autowired
    private JavaMailSender mailSender;
		
	@Autowired
	public LoginController(UtilizadorDAO daouser, UtilizadorBDAO daouserB,DadorDAO daoDador, PosicaoDAO daopos, PermissaoDAO daoperm, HospitalDAO daohosp, 
			PermissaoAuxDAO daopermaux, GlasgowCommaDAO daoglasg, EspecialidadesDAO daoespec, EstadoDadorDAO daoest, 
			RecetoresDAO daorecetores, EquipaTransplantesDAO daoeqtransplantes, EquipaExplantesDAO daoeqexplantes, GCCTColheitaDAO daogcctcolheita) {
	this.daouser = daouser;
	this.daouserB = daouserB;
	this.daoDador = daoDador;
	this.daopos = daopos;
	this.daoperm = daoperm;
	this.daohosp = daohosp;
	this.daopermaux = daopermaux;
	this.daoglasg = daoglasg;
	this.daoespec = daoespec;
	this.daoest = daoest;
	//this.daoOrgao = daoOrgao;
	this.daorecetores = daorecetores;
	this.daoeqtransplantes = daoeqtransplantes;
	this.daoeqexplantes = daoeqexplantes;
	this.daogcctcolheita = daogcctcolheita;
	}
	
	@RequestMapping(value="efetuaLogin")
	@ResponseBody
	public String login(Utilizador utilizador, HttpSession session,  Model model, RedirectAttributes ra) {
	if(daouser.existeUtilizador(utilizador)) {
		session.setAttribute("tipoutilizador", "a");
		session.setAttribute("utilizadorLogado", utilizador);
		session.setAttribute("Utilizador", daouser.buscaNomeUser(utilizador));
		Long iduser = daouser.buscaIdUser(utilizador);
		session.setAttribute("iduser", iduser);
/*		NotificationsController notificacoes = new NotificationsController();
		notificacoes.envianotificacao();*/
	    return "true";	
	}
	else
	
	   return "false";	
	}
	
	//mudar posi��o pelo cabe�alho
	@RequestMapping(value="mudarposicao")
	public String mudarposicao(Utilizador utilizador, Model model, HttpSession session){
		Long iduser = (Long) session.getAttribute("iduser");
		model.addAttribute("posicoes", daopos.buscaPosicoesUtilizador(iduser));
		model.addAttribute("localizacoes", daoperm.ListaLocalizacoesPosicao(daopos.buscaPosicoesUtilizador(iduser).get(0).getId_Posicao(), iduser));
		return "admin/loads/combomudaposicao";
	}
	
	@RequestMapping(value="carregaposicoeslogin")
	public String carregaposicoes(Utilizador utilizador, Model model){
		Long iduser = daouser.buscaIdUser(utilizador);
		model.addAttribute("posicoes", daopos.buscaPosicoesUtilizador(iduser));
		model.addAttribute("localizacoes", daoperm.ListaLocalizacoesPosicao(daopos.buscaPosicoesUtilizador(iduser).get(0).getId_Posicao(), iduser));
		return "comboposicaologin";
	}
	
	@RequestMapping(value="carregalocalizacoes")
	public String carregalocalizacoes(Hospital hospital, Model model, Long id,  HttpSession session){
		Long iduser = (Long) session.getAttribute("iduser");
		model.addAttribute("localizacoes", daoperm.ListaLocalizacoesPosicao(id, iduser));
	return "combolocalizacaologin";
	}
	
	@RequestMapping("guardaposicao")
	@ResponseBody
	public String guardaposicao(Posicao posicao, Hospital hospital, Model model, HttpSession session)
	{
		session.setAttribute("idposicao", posicao.getId_Posicao());
		session.setAttribute("posicao", daopos.buscaPorId(posicao.getId_Posicao()).getPosicao());
		session.setAttribute("idlocalizacao", hospital.getId_Hospital());
		session.setAttribute("localizacao", daohosp.buscaPorId(hospital.getId_Hospital()).getNomeHospital());
		
		
		//verificar permiss�o leitura ou escrita:
		PermissaoLocalizacao permissao = daoperm.buscaidpermissao(hospital.getId_Hospital(), (Long) session.getAttribute("iduser"), posicao.getId_Posicao());
		boolean le = daoperm.buscaPorId(permissao.getId_PermissaoLocalizacao()).isLeituraescrita();
		session.setAttribute("leituraescrita", le);
		session.setAttribute("leituraescritaeqcirurgica", le);
		
		return "true";
	}
	
	@RequestMapping(value="verificaLoginB", method = RequestMethod.POST)
	@ResponseBody
	public String verificaloginB( UtilizadorB utilizadorb) {
		
	if(daouserB.existeUtilizador(utilizadorb)) {
		return "true";
	}
		else
		return "false";
	}
	
	
	
	@RequestMapping(value="efetuaLoginB")
	public String loginB(UtilizadorB utilizadorb, HttpSession session, RedirectAttributes ra, Model model) {
		
	if(daouserB.existeUtilizador(utilizadorb)) {
		session.setAttribute("tipoutilizador", "b");
	    session.setAttribute("utilizadorLogado", utilizadorb);
	    Long iduser = daouserB.buscaIdUserB(utilizadorb);
	    session.setAttribute("iduser", iduser);
	   
	    model.addAttribute("hospitaisuserb", daohosp.ListaHospitais());
		model.addAttribute("glasgowcommauserb", daoglasg.ListaGlasgowComma());
		session.setAttribute("Utilizador", daouserB.buscaNomeUserB(utilizadorb));
		model.addAttribute("numvidassalvas", daouserB.CalculaVidasSalvasReferenciadorB(iduser));
		model.addAttribute("historicosalvos", daouserB.CarregadadoresreferenciadosorgaostransplantadosB(iduser));
	   return "admin/referenciacao";

	}
		else
	   return "loginB";	

	}
	
	@RequestMapping("abreprincipal")
	public String abreprincipal(HttpSession session) {
		return "redirect:principal";	
	}
	
	@RequestMapping("abrepagina")
	public String abrepagina(HttpSession session) {
		int idpos = Integer.parseInt(session.getAttribute("idposicao").toString());
		
		if(idpos == 6 || idpos == 9)	
			return "redirect:pesquisadador";	
		else
			if(idpos == 1)
				return "redirect:utilizadores";
			else
				if(idpos == 2)
					return "redirect:abriripst";
				else
					if(idpos == 3)
						return "redirect:abriracss";
					else
						if(idpos == 4)
							return "redirect:abrirgcct";
						else
/*							if(idpos == 5)
								return "redirect:abrircoordcolhtransp";
							else*/
								if(idpos == 7)
									return "redirect:abrireqcirurgica";
									else
										if(idpos == 10)
											return "redirect:abrirpp";
										else
											return "redirect:login";
									/*else
										return "redirect:principal";*/
	}
	
	
	@RequestMapping("abrireqcirurgica")
	public String abrireqcirurgica(Model model , HttpSession session) 
	{
		model.addAttribute("localizacao", session.getAttribute("localizacao"));
		model.addAttribute("Utilizador", session.getAttribute("Utilizador"));
		model.addAttribute("posicao",session.getAttribute("posicao"));
		model.addAttribute("explantes", daoeqexplantes.carregaexplanteshospital((Long)session.getAttribute("idlocalizacao"))); 
		
		session.setAttribute("transplante", false);
		session.setAttribute("gcct", false);
		return "/eqexplante/eqexplante";
	}	
	
	@RequestMapping("abretransplantes")
	public String abrireqtransplante(Model model , HttpSession session) 
	{
		model.addAttribute("localizacao", session.getAttribute("localizacao"));
		model.addAttribute("Utilizador", session.getAttribute("Utilizador"));
		model.addAttribute("posicao",session.getAttribute("posicao"));
		model.addAttribute("transplantes", daoeqtransplantes.carregatransplanteshospital((Long)session.getAttribute("idlocalizacao"))); 
		
		session.setAttribute("transplante", true);
		session.setAttribute("gcct", false);
		return "/eqtransplante/divseparadortransplantes";
	}	
	
	
	
	@RequestMapping("abreexplantes")
	public String abreexplantes(Model model , HttpSession session) 
	{
		model.addAttribute("explantes", daoeqexplantes.carregaexplanteshospital((Long)session.getAttribute("idlocalizacao"))); 
		session.setAttribute("transplante", false);
		session.setAttribute("gcct", false);
		return "/eqexplante/divseparadorexplantes";
	}
	
	
	@RequestMapping("abrirpp")
	public String abrirpp(Model model , HttpSession session) 
	{
		Long id_hosp = daohosp.buscaIdHospital((String) session.getAttribute("localizacao"));
		model.addAttribute("recetores", daorecetores.buscarecetoreshospital(id_hosp));
		session.setAttribute("verestados", 0);	
		return "/pptransplante/pretransplante";
	}
	
	@RequestMapping(value = "abrirgcct")
	public String gcct() 
	{
		return "redirect:gcct";
	}
	
	@RequestMapping(value = "gcct")
	public String abrirgcct(Model model, HttpSession session) 
	{
		model.addAttribute("localizacao", session.getAttribute("localizacao"));
		model.addAttribute("Utilizador", session.getAttribute("Utilizador"));
		model.addAttribute("posicao",session.getAttribute("posicao"));
		model.addAttribute("atribuicoes", daoDador.listaatribuicoes((Long) session.getAttribute("idlocalizacao")));
		session.setAttribute("gcct", true);
		return "/gcct/gcct";
	}
	
	@RequestMapping("abriracss")
	public String abriracss(Model model, HttpSession session) 
	{
		//model.addAttribute("localizacao", session.getAttribute("localizacao"));
		model.addAttribute("Utilizador", session.getAttribute("Utilizador"));
		model.addAttribute("posicao",session.getAttribute("posicao"));
		model.addAttribute("ano", daogcctcolheita.buscaAnosgcctcolheitaanalise());
		
		model.addAttribute("colheitas", daogcctcolheita.buscagcctcolheitaACSS());
		return "/acss/acss";
	}
	
/*	@RequestMapping("abrircoordcolhtransp")
	public String abrircoordcolhtransp(Model model , HttpSession session) 
	{
		
		model.addAttribute("Utilizador", session.getAttribute("Utilizador"));
		model.addAttribute("posicao",session.getAttribute("posicao"));
		
		if((Long)session.getAttribute("idposicao")==1){
			model.addAttribute("dadores",daoDador.ListaDador());
		}
		else{	
			model.addAttribute("dadores",daoDador.ListaDadorPermissao((Long)session.getAttribute("idposicao"), (Long)session.getAttribute("iduser"), (Long)session.getAttribute("idlocalizacao")));	
		}

		model.addAttribute("localizacao", session.getAttribute("localizacao"));
		model.addAttribute("localizacoes", daohosp.ListaHospitais());
		model.addAttribute("estado", daoest.ListaEstadoDador());
		model.addAttribute("dador", daoDador.ListaDador());
		model.addAttribute("orgaos", daoOrgao.ListaOrgaos());
		
		return "/admin/coordcolheitatransplantes";
	}*/
	
	@RequestMapping("abriripst")
	public String abriripst(Model model , HttpSession session) 
	{
		model.addAttribute("colheitas", daogcctcolheita.buscagcctcolheitaIPST());
		model.addAttribute("ano", daogcctcolheita.buscaAnosgcctcolheitaanalise());
		
		return "/ipst/ipst";
	}
	
	@RequestMapping("pesquisautilizadores")
	public String pesquisautilizadores(Model model , HttpSession session) 
	{
		model.addAttribute("Utilizador", session.getAttribute("Utilizador"));
		model.addAttribute("utilizadores",daouser.ListaUtilizadorActividadeRecente());
		model.addAttribute("utilizadoresB",daouserB.Lista());
		model.addAttribute("posicao",session.getAttribute("posicao"));
		model.addAttribute("idposicao", session.getAttribute("idposicao"));
		
		return "/admin/utilizadores";
	}
	
	@RequestMapping("principal")
	public String index() {
	return "/admin/principal";
	}
	
	@RequestMapping("principalB")
	public String indexB() {
	return "principalB";
	}
	
	@RequestMapping("logout")
	public String logout(HttpSession session){
		session.invalidate();
		return "redirect:/";
	}
	
	@RequestMapping("recuperarPass")
	public String recuperapass() {
		return "recuperarPasswordEmail";
	}
	
	@RequestMapping(value="recuperarpassenviaemail")
	@ResponseBody
	public String enviaemailrecuperapass(String useremail){
		// verifica se email existe na BD , cria codigo para esse utilizador na tabela desse user 
		//e envia esse codigo no corpo do email, na recupera��o qd abre o link verifica qual o utilizador a alterar a pass por esse codigo
		
		if((!daouser.existeUtilizadoremail(useremail)) && (!daouser.existeUtilizadorLogin(useremail))){
			return "false";
		}
		else if(daouser.existeUtilizadorLogin(useremail)){
			//login
			
			//verifica se c�digo j� existe associado e gera um que n�o exista
			String codigo = geraUUID();
			
			//actualizar utilizador com o codigo
			Utilizador user = daouser.buscaPorLogin(useremail);
			user.setCodigo(codigo);
			daouser.atualiza(user);
			
			//email
			
			String recipientAddress = user.getEmail();
			String subject = "IPST - RPT - Recupera��o de password";

		//	String message = "Foi efectuado um pedido de recupera��o de password para este email, para recuperar o acesso � sua conta siga o seguinte endere�o, http://213.136.79.187:8085/ipst/novaPass?codigo="+codigo+"";

																																																								// http://213.58.181.218:8080/rptprod http://213.136.79.187:8085/ipst/
			String message = "Exmo(a). Senhor(a),<br><br> Foi efectuado um pedido de recupera��o de password no Registo Portugu�s de Transplanta��o (RPT) para este contacto. Para concluir o processo aceda ao link <a href=\"http://213.58.181.218:8080/rptprod/novaPass?codigo="+codigo
					+"\">(link de acesso)</a> e siga as instru��es necess�rias. <br><br><br> "
					+ "Em nome da Coordena��o Nacional da Transplanta��o (CNT) do Instituto Portugu�s do Sangue "
					+ "e da Transplanta��o (IPST, IP) agradecemos a sua colabora��o. <br><br> "
					+ "Qualquer  problema  t�cnico  ou  dificuldade  no  acesso  ao  RPT,  dever� ser  reportado  para  o  endere�o: rpt@IPST.min-saude.pt <br><br><br> "
					+ "Com os melhores cumprimentos, <br><br> "
					+ "A Coordena��o Nacional da Transplanta��o";
					
			
			
			try {
		    	// criar o objecto email
				MimeMessage mimeMessage = mailSender.createMimeMessage();
			     MimeMessageHelper helper;
				helper = new MimeMessageHelper(mimeMessage, true, "UTF-8");

		     mimeMessage.setContent(message, "text/html");
		     helper.setTo(recipientAddress);
		     helper.setSubject(subject);
	         mailSender.send(mimeMessage);
	        
			} catch (MessagingException e) {
				e.printStackTrace();
			}
					
//			// criar o objecto email
//			SimpleMailMessage email1 = new SimpleMailMessage();
//			email1.setTo(recipientAddress);
//			email1.setSubject(subject);
//			email1.setText(message);
//        
//			// enviar o e-mail
//			mailSender.send(email1);
			
//			System.out.println("existe utilizador com o login: "+useremail);		
			
			return "true";
		}
		else if(daouser.existeUtilizadoremail(useremail)){
			
			//verifica se c�digo j� existe associado e gera um que n�o exista
			String codigo = geraUUID();
			
			//actualizar utilizador com o codigo
			Utilizador user = daouser.buscaPorEmail(useremail);
			user.setCodigo(codigo);
			daouser.atualiza(user);
			
			//email
			String recipientAddress = useremail;
			String subject = "IPST - RPT - Recupera��o de password";

		//	String message = "Foi efectuado um pedido de recupera��o de password para este email, para recuperar o acesso � sua conta siga o seguinte endere�o, http://whydevtest.whymob.pt:8085/ipst/novaPass?codigo="+codigo+"";
			String message = "Exmo(a). Senhor(a),<br><br> Foi efectuado um pedido de recupera��o de password no Registo Portugu�s de Transplanta��o (RPT) para este contacto. Para concluir o seu registo aceda ao link <a href=\"http://213.58.181.218:8080/rptprod/novaPass?codigo="+codigo
					+"\">(link de acesso)</a> e siga as instru��es necess�rias. <br><br><br> "
					+ "Em nome da Coordena��o Nacional da Transplanta��o (CNT) do Instituto Portugu�s do Sangue "
					+ "e da Transplanta��o (IPST, IP) agradecemos a sua colabora��o. <br><br> "
					+ "Qualquer  problema  t�cnico  ou  dificuldade  no  acesso  ao  RPT,  dever� ser  reportado  para  o  endere�o: rpt@IPST.min-saude.pt <br><br><br> "
					+ "Com os melhores cumprimentos, <br><br> "
					+ "A Coordena��o Nacional da Transplanta��o";
			
			
			try {
		    	// criar o objecto email
				MimeMessage mimeMessage = mailSender.createMimeMessage();
			     MimeMessageHelper helper;
				helper = new MimeMessageHelper(mimeMessage, true, "UTF-8");

		     mimeMessage.setContent(message, "text/html");
		     helper.setTo(recipientAddress);
		     helper.setSubject(subject);
			

	        mailSender.send(mimeMessage);
			} catch (MessagingException e) {
				e.printStackTrace();
			}
			
			
			
			
			// criar o objecto email
//			SimpleMailMessage email1 = new SimpleMailMessage();
//			email1.setTo(recipientAddress);
//			email1.setSubject(subject);
//			email1.setText(message);
//        
//			// enviar o e-mail
//			mailSender.send(email1);
				
			return "true";
		}
		else
			return "false";
		}
	
	//gera codigo UUID - Identificador universal �nico
	public String geraUUID(){
		String codigo = "";
		
		do {
			codigo = UUID.randomUUID().toString();
			
		} while (existecodigo(codigo));
		//String codigo = UUID.randomUUID().toString();
		
//		System.out.println("codigo �: " +codigo);
		
		return codigo;
	}
	
	//verifica se j� existe algum utilizador com codigo uuid de recupera��o
	public boolean existecodigo(String codigo){
		if(!daouser.existeUtilizadorcodigoUUID(codigo)){
			return false;
			
		}
		else{	
		return true;
		}
	}
	
	
	@RequestMapping(value="recuperarpassenviaemailB")
	@ResponseBody
	public String enviaemailrecuperapassB(int codigoOM){
		if(!daouserB.existeUtilizadorLogin(codigoOM)){
			return "false";
		}
		else if(daouserB.existeUtilizadorLogin(codigoOM)){
			//login
			
			//verifica se c�digo j� existe associado e gera um que n�o exista
			String codigo = geraUUIDB();
			
			//actualizar utilizador com o codigo
			UtilizadorB userb = daouserB.buscaPorLogin(codigoOM);
			userb.setCodigoUUID(codigo);
			daouserB.atualiza(userb);
			
			//email
			
			String recipientAddress = userb.getEmail();
			String subject = "IPST - Recupera��o de password";

		//	String message = "Foi efectuado um pedido de recupera��o de password para este email, para recuperar o acesso � sua conta siga o seguinte endere�o, http://whydevtest.whymob.pt:8085/ipst/novaPassB?codigo="+codigo+"";
			String message = "Exmo(a). Senhor(a),<br><br> Foi efectuado um pedido de recupera��o de password no Registo Portugu�s de Transplanta��o (RPT) para este contacto. Para concluir o processo aceda ao link <a href=\"http://213.58.181.218:8080/rptprod/novaPassB?codigo="+codigo
					+"\">(link de acesso)</a> e siga as instru��es necess�rias. <br><br><br> "
					+ "Em nome da Coordena��o Nacional da Transplanta��o (CNT) do Instituto Portugu�s do Sangue "
					+ "e da Transplanta��o (IPST, IP) agradecemos a sua colabora��o. <br><br> "
					+ "Qualquer  problema  t�cnico  ou  dificuldade  no  acesso  ao  RPT,  dever� ser  reportado  para  o  endere�o: rpt@IPST.min-saude.pt <br><br><br> "
					+ "Com os melhores cumprimentos, <br><br> "
					+ "A Coordena��o Nacional da Transplanta��o";
			
			
			
			try {
		    	// criar o objecto email
				MimeMessage mimeMessage = mailSender.createMimeMessage();
			     MimeMessageHelper helper;
				helper = new MimeMessageHelper(mimeMessage, true, "UTF-8");

		     mimeMessage.setContent(message, "text/html");
		     helper.setTo(recipientAddress);
		     helper.setSubject(subject);
			

	        mailSender.send(mimeMessage);
			} catch (MessagingException e) {
				e.printStackTrace();
			}
			
			
//			// criar o objecto email
//			SimpleMailMessage email1 = new SimpleMailMessage();
//			email1.setTo(recipientAddress);
//			email1.setSubject(subject);
//			email1.setText(message);
//        
//			// enviar o e-mail
//			mailSender.send(email1);
			
//			System.out.println("existe utilizadorB com o login: "+codigoOM);		
			
			return "true";
		}
		else
			return "false";
	}
	
	
	//gera codigo UUID user B - Identificador universal �nico
	public String geraUUIDB(){
		String codigo = "";
		
		do {
			codigo = UUID.randomUUID().toString();
			
		} while (existecodigoB(codigo));
		
		return codigo;
	}
	
	//verifica se j� existe algum utilizador com codigo uuid de recupera��o
	public boolean existecodigoB(String codigo){
		if(!daouserB.existeUtilizadorcodigoUUIDB(codigo)){
			return false;
			
		}
		else{	
		return true;
		}
	}
	
	
	
	@RequestMapping("recuperarPass2")
	public String recuperapassB() {
		return "recuperarPasswordEmailB";
	}
	
	@RequestMapping(value="novaPass")
	public String novapass(String codigo, Model model, RedirectAttributes ra) {

		
		
		if(daouser.existeUtilizadorcodigoUUID(codigo)){
			
		model.addAttribute("utilizador",daouser.buscaPorCodigo(codigo));
		return "recuperarNovaPassword";
		}
		else
			return "login";
	}
	
	@RequestMapping(value = "gravapassA")
	@ResponseBody
	public String gravarnovapass(Utilizador utilizador){
		BCryptPasswordEncoder passwordEncoder = new BCryptPasswordEncoder();
		String hashedPassword = passwordEncoder.encode(utilizador.getSenha());
		utilizador.setSenha(hashedPassword);
		
		Utilizador utilizador2 = daouser.buscaPorLogin(utilizador.getLogin());
		utilizador2.setSenha(utilizador.getSenha());
		utilizador2.setCodigo(null);
		daouser.atualiza(utilizador2);
		return "true";
	}
	
	
	@RequestMapping(value="novaPassB")
	public String novapassB(String codigo, Model model) {

		
		
		if(daouserB.existeUtilizadorcodigoUUIDB(codigo)){
			
			model.addAttribute("utilizadorB",daouserB.buscaPorCodigo(codigo));
			return "recuperarNovaPasswordB";
			}
			else
				return "login";
	}
	
	@RequestMapping(value = "gravapassB")
	@ResponseBody
	public String gravarnovapassB(UtilizadorB utilizadorb){
		UtilizadorB utilizador2 = daouserB.buscaPorLogin(utilizadorb.getCodigoOM());
		utilizador2.setPin(utilizadorb.getPin());
		utilizador2.setCodigoUUID(null);
		daouserB.atualiza(utilizador2);
		return "true";
	}
	
	@RequestMapping("loginTipoB")
	public String logintipoB(UtilizadorB utilizadorB, Model model) {
		model.addAttribute(utilizadorB);
		return "loginB";
	}
	@RequestMapping("registoUserB")
	public String registotipoB() {
		return "registoB";
	}
	
	@RequestMapping("registouserA")
	public String registotipoA(Utilizador utilizador, Model model, HttpSession session) {
		
		//Verifica se existe permiss�o e se n�o passou o prazo para registo
		if(daopermaux.existePermissaoauxregisto(utilizador.getEmail())){
			utilizador.setTelemovel((String) session.getAttribute("contato"));
			model.addAttribute(utilizador);
			model.addAttribute("especialidades", daoespec.ListaEspecialidade());
			session.removeAttribute("contato");
			return "registoUserA";
		}
		else
			model.addAttribute("expirou","Utilizador j� registado, inexistente, ou tempo m�ximo para registo expirado! <br> Por favor contacte o administrador e pe�a um novo pedido de registo e PIN caso ainda n�o tenha um login.");
			return "login";
		
	}
	
	
	@Transactional
	@RequestMapping("registarUserA")
	@ResponseBody
	public String registarUserA(Utilizador utilizador, HttpSession session) {
		
		if(daouser.existeUtilizadorLogin(utilizador.getLogin()))
		{
			
			return "1";
		}
		
	    //verificar se o pin corresponde na permissao aux
		else if(!daopermaux.verificapin(utilizador.getEmail(), utilizador.getPin())){
		return "2";
		}
	    else{
	    	
	    //adicionar utilizador
	    daouser.adiciona(utilizador);
	    
	    //transferir permiss�es desse email para a tabela permissoes_localizacao
	    //tranfere permissoes da tabela auxiliar para permissoes
	    // e apagar registos correspondentes na permiss�o aux
	    daopermaux.transferePermissaoAuxPermissao(utilizador);
	  
	    
	    session.setAttribute("utilizadorLogado", utilizador);
		session.setAttribute("Utilizador", daouser.buscaNomeUser(utilizador));
		Long iduser = daouser.buscaIdUser(utilizador);
		session.setAttribute("iduser", iduser);
		return "true";
	    }
	}
	

	@RequestMapping(value = "registarUserB")
	@ResponseBody
	public String registarUserB(UtilizadorB utilizador, HttpSession session) {
	    
	    if(!daouserB.existeUtilizador(utilizador)){	
	    	daouserB.adiciona(utilizador);
	    	session.setAttribute("utilizadorLogado", utilizador);	
			session.setAttribute("Utilizador", utilizador.getNome());	    	
			return "true";
	    }
	    else{
	    	return "false";
	    }
	}
	
/*	@RequestMapping("atualizatabdadores")
	public String Atualizatabdadores(Model model , HttpSession session){ // Est� no AvaliacaoController linha 2748 atualizatabdadores


		model.addAttribute("Utilizador", session.getAttribute("Utilizador"));
		model.addAttribute("posicao",session.getAttribute("posicao"));
		model.addAttribute("leituraescrita",session.getAttribute("leituraescrita"));
		
		
		//trocar lista de dadores pelos dadores dos hospitais a que o utilizador tem acesso
    	if((Long)session.getAttribute("idposicao")==1){
    		model.addAttribute("dadores",daoDador.ListaDador());
    	}
    	else{
    		model.addAttribute("dadores",daoDador.ListaDadorPermissao((Long)session.getAttribute("idposicao"), (Long)session.getAttribute("iduser"), (Long)session.getAttribute("idlocalizacao")));	
    	}
    
		return "/admin/divdadosdadores";
	}*/	
	
	@RequestMapping("pesquisadador")
	public String AbreDador(Model model , HttpSession session){

		model.addAttribute("Utilizador", session.getAttribute("Utilizador"));
		model.addAttribute("posicao",session.getAttribute("posicao"));
		model.addAttribute("leituraescrita",session.getAttribute("leituraescrita"));
		
		
		//trocar lista de dadores pelos dadores dos hospitais a que o utilizador tem acesso
    	if((Long)session.getAttribute("idposicao")==1){
    		model.addAttribute("dadores",daoDador.ListaDador());
    	}
    	else{
    		model.addAttribute("dadores",daoDador.ListaDadorPermissao((Long)session.getAttribute("idposicao"), (Long)session.getAttribute("iduser"), (Long)session.getAttribute("idlocalizacao")));	
    	}
    
		model.addAttribute("localizacao", session.getAttribute("localizacao"));
		model.addAttribute("localizacoes", daohosp.ListaHospitais());
		model.addAttribute("estado", daoest.ListaEstadoDador());
		return "/admin/pesquisadador2";
	}
	
	@RequestMapping("divseparadorreferenciar")
	public String refere(Model model, HttpSession session) {
	model.addAttribute("hospitais", daohosp.ListaHospitais());
	model.addAttribute("glasgowcomma", daoglasg.ListaGlasgowComma());
	model.addAttribute("numvidassalvas", daouser.CalculaVidasSalvasReferenciador((Long) session.getAttribute("iduser")));
	model.addAttribute("historicosalvos", daouser.Carregadadoresreferenciadosorgaostransplantados((Long) session.getAttribute("iduser")));
	return "admin/divseparadorreferenciar";
	}
	
}
