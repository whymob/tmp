package pt.iconic.ipst.modelo;

import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name = "ESTADO_ANALISE_RECETOR")
public class EstadoAnaliseRecetor {
	private int idestadoanalise;
	private String estado;
	private List<AnaliseRecetorTransplante> analiserecetortransp;
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="ID_ESTADO_ANALISE")
	public int getIdestadoanalise() {
		return idestadoanalise;
	}
	public void setIdestadoanalise(int idestadoanalise) {
		this.idestadoanalise = idestadoanalise;
	}
	
	@Column(name="ESTADO")
	public String getEstado() {
		return estado;
	}
	public void setEstado(String estado) {
		this.estado = estado;
	}
	
	@OneToMany(fetch = FetchType.EAGER, mappedBy = "estadoanaliserecetor")
	public List<AnaliseRecetorTransplante> getAnaliserecetortransp() {
		return analiserecetortransp;
	}
	public void setAnaliserecetortransp(
			List<AnaliseRecetorTransplante> analiserecetortransp) {
		this.analiserecetortransp = analiserecetortransp;
	}
	
}
