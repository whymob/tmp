package pt.iconic.ipst.dao;

import java.math.BigInteger;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import pt.iconic.ipst.modelo.AnaliseDador;

@Repository
@Transactional
public class AnaliseDadorDAO {

	
	@PersistenceContext
	private EntityManager manager;
	
	
	public void adiciona(AnaliseDador analisedador){
		manager.persist(analisedador);	
	}
	
	public void atualiza(AnaliseDador analisedador){
		manager.merge(analisedador);
	}
	

/*	@SuppressWarnings("unchecked")
	public List<AnaliseDador> ListaAnaliseDador(){
		return manager.createQuery("select d from AnaliseDador d").getResultList();
	}*/
	
	public AnaliseDador buscaPorId(Long id){
		return manager.find(AnaliseDador.class, id);
	}
	
	
/*	public void remove(AnaliseDador analisedador){
		AnaliseDador analisedadorARemover = buscaPorId(analisedador.getId_AnaliseDador());
		manager.remove(analisedadorARemover);
	}*/
	
	@SuppressWarnings("unchecked")
	public AnaliseDador buscaAnaliseDoDador(Long id){
		
		Query query = manager.createQuery("select a from AnaliseDador a JOIN a.dador dador WHERE dador.id_Dador =:iddador");
		query.setParameter("iddador", id);
		
		List<AnaliseDador> results = query.getResultList();
		AnaliseDador analisedador = null;
		if(!results.isEmpty()){
			analisedador = (AnaliseDador) results.get(0);
		}
		return analisedador;
	}
	
	public Long buscaIdDador(Long idanalise){

		Query query = manager.createNativeQuery("select ANALISEDADOR.ID_DADOR from ANALISEDADOR where ANALISEDADOR.ID_ANALISEDADOR =:idanalise");
		query.setParameter("idanalise", idanalise);
		
		BigInteger id = (BigInteger) query.getSingleResult();	

		return id.longValue();
	}
}
