package pt.iconic.ipst.modelo;

import java.util.Calendar;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import org.springframework.format.annotation.DateTimeFormat;

@Entity
@Table(name = "FATURAACSS")
public class FaturaACSS 
{
	private Long idfatura;
	private Calendar data;
	private Calendar datapagamento;
	private Compromisso compromisso;
	private boolean paga;
	private boolean prob;
	private String notas;
	private String fatura;
	private String caminhodocfatura;
	private String nomedocfatura;
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="ID_FATURA")
	public Long getIdfatura() {
		return idfatura;
	}
	public void setIdfatura(Long idfatura) {
		this.idfatura = idfatura;
	}

	@DateTimeFormat(pattern="dd/MM/yyyy")
	@Temporal(TemporalType.DATE)
	@Column(name="DATA")
	public Calendar getData() {
		return data;
	}
	public void setData(Calendar data) {
		this.data = data;
	}
	
	@DateTimeFormat(pattern="dd/MM/yyyy")
	@Temporal(TemporalType.DATE)
	@Column(name="DATAPAGAMENTO")
	public Calendar getDatapagamento() {
		return datapagamento;
	}
	public void setDatapagamento(Calendar datapagamento) {
		this.datapagamento = datapagamento;
	}
	
	@OneToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "ID_COMPROMISSO")
	public Compromisso getCompromisso() {
		return compromisso;
	}
	public void setCompromisso(Compromisso compromisso) {
		this.compromisso = compromisso;
	}
	
	@Column(name="PAGA")
	public boolean isPaga() {
		return paga;
	}
	public void setPaga(boolean paga) {
		this.paga = paga;
	}
	
	@Column(name="PROB")
	public boolean isProb() {
		return prob;
	}
	public void setProb(boolean prob) {
		this.prob = prob;
	}
	
	@Column(name="notas")
	public String getNotas() {
		return notas;
	}
	public void setNotas(String notas) {
		this.notas = notas;
	}
	
	@Column(name="FATURA")
	public String getFatura() {
		return fatura;
	}
	public void setFatura(String fatura) {
		this.fatura = fatura;
	}
	
	@Column(name="CAMINHO_DOC_FATURA")
	public String getCaminhodocfatura() {
		return caminhodocfatura;
	}
	public void setCaminhodocfatura(String caminhodocfatura) {
		this.caminhodocfatura = caminhodocfatura;
	}
	
	@Column(name="NOME_DOC_FATURA")
	public String getNomedocfatura() {
		return nomedocfatura;
	}
	public void setNomedocfatura(String nomedocfatura) {
		this.nomedocfatura = nomedocfatura;
	}
}
