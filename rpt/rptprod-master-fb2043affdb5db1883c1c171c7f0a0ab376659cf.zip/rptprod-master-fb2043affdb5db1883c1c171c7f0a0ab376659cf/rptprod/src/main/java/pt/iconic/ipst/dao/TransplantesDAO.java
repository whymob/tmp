package pt.iconic.ipst.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import pt.iconic.ipst.modelo.Transplantes;

@Repository
public class TransplantesDAO 
{
	@PersistenceContext
	private EntityManager manager;
	
	@Transactional
	public void adiciona(Transplantes transp){
		manager.persist(transp);	
	}
	
	@Transactional
	public void atualiza(Transplantes transp){
		manager.merge(transp);
	}
	
	@SuppressWarnings("unchecked")
	public List<Transplantes> ListaTransplantes(){
		return manager.createQuery("select d from Transplantes d").getResultList();
	}
	
	public Transplantes buscaPorId(Long id){
		return manager.find(Transplantes.class, id);
	}
	
	@SuppressWarnings("unchecked")
	public List<Transplantes> ListaTransplantesHospital(Long idhospital){
		Query query = manager.createQuery("select d from Transplantes d join d.hospital h where h.id_Hospital = :idhospital");
		
		query.setParameter("idhospital", idhospital);
		
		List<Transplantes> out = query.getResultList();
		return out;
	}
/*	public void remove(Transplantes transp){
		Transplantes transprem = buscaPorId(transp.getId_transplante());
		manager.remove(transprem);
	}*/

	@SuppressWarnings("unchecked")
	public boolean buscaseexiste(Long id_recetor) {
		Query query = manager.createNativeQuery("select * from TRANSPLANTADOS tr "
				+ "where tr.ID_RECETOR = :id_recetor");
		query.setParameter("id_recetor", id_recetor);
		
		List<Transplantes> results = query.getResultList();
		if(!results.isEmpty()){
		   return true;
	
		}else{
		return false;
		}	
	}

	@SuppressWarnings("unchecked")
	public boolean verificajafoitransplantado(Long id_recetor, Long id_assigorg) {
		Query query = manager.createNativeQuery("select * from TRANSPLANTADOS tr "
				+ "where tr.ID_RECETOR = :id_recetor and tr.ID_ASSIG_ORGAO = :id_assigorg");
		query.setParameter("id_recetor", id_recetor);
		query.setParameter("id_assigorg", id_assigorg);
		
		List<Transplantes> results = query.getResultList();
		if(!results.isEmpty()){
			return true;
		}else{
			return false;
		}	
	}
}