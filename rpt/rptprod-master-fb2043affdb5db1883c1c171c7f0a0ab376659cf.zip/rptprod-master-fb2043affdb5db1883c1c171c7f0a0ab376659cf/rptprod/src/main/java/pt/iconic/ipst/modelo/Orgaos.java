/*package pt.iconic.ipst.modelo;

import javax.persistence.Column;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;



public class Orgaos {
	private Long Id_Orgao;
	private String CodigoOrgao;
	private String orgao;
	private UnidadeTransplante unidtransp;
//	private List<GravidadeOrgao> gravorgao;
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="ID_ORGAO")
	public Long getId_Orgao() {
		return Id_Orgao;
	}
	public void setId_Orgao(Long id_Orgao) {
		Id_Orgao = id_Orgao;
	}
	
	@Column(name="ORGAO")
	public String getOrgao() {
		return orgao;
	}
	public void setOrgao(String orgao2) {
		orgao = orgao2;
	}
	
	@Column(name="CODIGOORGAO")
	public String getCodigoOrgao() {
		return CodigoOrgao;
	}
	public void setCodigoOrgao(String codigoOrgao) {
		CodigoOrgao = codigoOrgao;
	}
	
//	@OneToMany(fetch = FetchType.LAZY, mappedBy = "orgaos")
//	public List<Recetores> getRecetores() {
//		return recetores;
//	}
//	public void setRecetores(List<Recetores> recetores) {
//		this.recetores = recetores;
//	}
	
	@OneToOne(fetch = FetchType.LAZY)
	@JoinColumn(name="ID_UNIDADETRANSP")
	public UnidadeTransplante getUnidtransp() {
		return unidtransp;
	}
	public void setUnidtransp(UnidadeTransplante unidtransp) {
		this.unidtransp = unidtransp;
	}
	
	@OneToMany(fetch = FetchType.LAZY, mappedBy = "orgao")
	public List<GravidadeOrgao> getGravorgao() {
		return gravorgao;
	}
	public void setGravorgao(List<GravidadeOrgao> gravorgao) {
		this.gravorgao = gravorgao;
	}
}*/