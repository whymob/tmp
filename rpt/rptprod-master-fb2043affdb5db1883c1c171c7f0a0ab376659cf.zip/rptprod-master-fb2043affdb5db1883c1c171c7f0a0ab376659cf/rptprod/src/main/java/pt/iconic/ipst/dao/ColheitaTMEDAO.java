package pt.iconic.ipst.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import pt.iconic.ipst.modelo.ColheitaTME;


@Repository
@Transactional
public class ColheitaTMEDAO {

	
	@PersistenceContext
	private EntityManager manager;
	
	public void adiciona(ColheitaTME colheita){
		manager.persist(colheita);	
	}
	

	public void atualiza(ColheitaTME colheita){
		manager.merge(colheita);
	}
	

/*	@SuppressWarnings("unchecked")
	public List<ColheitaTME> ListaColheitaTME(){
		return manager.createQuery("select a from ColheitaTME a").getResultList();
	}
	
	public ColheitaTME buscaPorId(Long id){
		return manager.find(ColheitaTME.class, id);
	}
	
	
	public void remove(ColheitaTME colheita){
		ColheitaTME colheitaARemover = buscaPorId(colheita.getIdcolheitatme());
		manager.remove(colheitaARemover);
		
	}*/
	
	@SuppressWarnings("unchecked")
	public ColheitaTME buscacolheitaTMEanalise(Long idanalise){
		
		Query query = manager.createQuery("select b from ColheitaTME b JOIN b.analiseDador a WHERE a.id_AnaliseDador =:idanalise");
		query.setParameter("idanalise", idanalise);
		
		List<ColheitaTME> results = query.getResultList();
		ColheitaTME colheita = null;
		if(!results.isEmpty()){
			colheita = (ColheitaTME) results.get(0);
		}
		return colheita;
		
	}
}
