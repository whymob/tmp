 package pt.iconic.ipst.dao;




import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import pt.iconic.ipst.modelo.EquipaCirurgia;

@Repository
@Transactional
public class EquipaCirurgiaDAO {

	
	
	@PersistenceContext
	private EntityManager manager;
	
	
	public void adiciona(EquipaCirurgia ec){
		manager.persist(ec);	
	}
	
	public void atualiza(EquipaCirurgia ec){
		manager.merge(ec);
	}
	

/*	@SuppressWarnings("unchecked")
	public List<EquipaCirurgia> ListaEquipaCirurgia(){
		return manager.createQuery("select a from EquipaCirurgia a").getResultList();
	}*/
	
	public EquipaCirurgia buscaPorId(Long id){
		return manager.find(EquipaCirurgia.class, id);
	}
	
	
	public void remove(EquipaCirurgia ec){
		EquipaCirurgia ecARemover = buscaPorId(ec.getIdequipacirurgia());
		manager.remove(ecARemover);
	}

	@SuppressWarnings("unchecked")
	public List<Object> buscaequipacirurgiadador(Long id_Dador) {
		
		Query query = manager.createNativeQuery("select coalesce(ao.ID_ORGAOOFERTA, eq.INICIO), eq.HORA_PREVISTA, eq.NOME_CIRURGIAO, eq.ORDEM, eq.NUM_MECANOGRAF, eq.CONTATO, eq.TRANSPORTE,"
				+ " case when eq.INICIO <>99 then  org.NOME_ORGAO End as orgao, eq.ID_UTILIZADOR, eq.ID_EQUIPA_CIRURGIA, case when eq.PRINCIPAL='True' then 'Sim' else 'N�o' End as principal, eq.PRINCIPAL "
				+ "from EQUIPA_CIRURGIA eq "
				+ "LEFT JOIN ASSIGNACAO_ORGAOS ao on (ao.ID_ASSIGNACAO_ORGAOS = eq.ID_ASSIG_ORGAO) "
				+ "LEFT JOIN ORGAOS_OFERTA org on (org.ID_ORGAO_OFERTA = ao.ID_ORGAOOFERTA) "
				+ "where eq.ID_DADOR = :iddador "
				+ "Order by eq.HORA_PREVISTA");
		
		query.setParameter("iddador", id_Dador);

		List<Object> results = query.getResultList();
//		
//        int count = 0;  
//        for (Iterator i = results.iterator(); i.hasNext();) {  
//            Object[] values = (Object[]) i.next();  
//            System.out.println(++count + ": " + values[0] + ", " + values[1] + ", " + values[2] + ", " + values[3] + ", " + values[4] + ", " + values[5] + ", " + values[6] + ", " + values[7] + ", " + values[8] + ", " + values[9] +"<br />");  
//        } 
		
		return results;
	}
	
}
