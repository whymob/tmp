package pt.iconic.ipst.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import pt.iconic.ipst.modelo.EcoToraxico;

@Repository
@Transactional
public class EcotoraxicoDAO 
{
	@PersistenceContext
	private EntityManager manager;
	
	public void adiciona(EcoToraxico tora){
		manager.persist(tora);	
	}
	
	public void atualiza(EcoToraxico tora){
		manager.merge(tora);
	}

	public EcoToraxico buscaPorId(Long id){
		return manager.find(EcoToraxico.class, id);
	}
	
/*	public void remove(EcoToraxico tora){
		EcoToraxico toraxico = buscaPorId(tora.getId_EcoToraico());
		manager.remove(toraxico);
	}*/
	

	@SuppressWarnings("rawtypes")
	public EcoToraxico ListaEcoToraxico(Long id)
	{
		Query query = manager.createQuery("select e from EcoToraxico e JOIN e.analiseDador analisedador WHERE analisedador.id_AnaliseDador =:idanalise");
		query.setParameter("idanalise", id);

		List results = query.getResultList();
		EcoToraxico eletro = null;
		
		if(!results.isEmpty())
		{
			eletro = (EcoToraxico) results.get(0);
		}
		
		return eletro;
	}
}