package pt.iconic.ipst.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import pt.iconic.ipst.modelo.PPCardiaco;

@Repository
public class PPCardiacoDAO 
{
	@PersistenceContext
	private EntityManager manager;
	
	public void adiciona(PPCardiaco card){
		manager.persist(card);	
	}
	
	@Transactional
	public void atualiza(PPCardiaco card){
		manager.merge(card);
	}
	
/*	@SuppressWarnings("unchecked")
	public List<PPCardiaco> ListaPPCardiaco(){
		return manager.createQuery("select p from PPCardiaco p").getResultList();
	}*/
	
/*	public PPCardiaco buscaPorId(Long id){
		return manager.find(PPCardiaco.class, id);
	}
	
	public void remove(PPCardiaco card){
		PPCardiaco cardrem = buscaPorId(card.getId_ppcardiaco());
		manager.remove(cardrem);
	}*/
	
	@SuppressWarnings("rawtypes")
	public PPCardiaco ListaPPCardiacoAnalise(Long id)
	{
		Query query = manager.createQuery("select e from PPCardiaco e JOIN e.analiserecetor analiserecetor WHERE analiserecetor.id_analiserecetor =:idanalise");
		query.setParameter("idanalise", id);

		List results = query.getResultList();
		PPCardiaco rad = null;
		
		if(!results.isEmpty())
		{
			rad = (PPCardiaco) results.get(0);
		}
		
		return rad;
	}
}