package pt.iconic.ipst.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import pt.iconic.ipst.modelo.PPPulmonar;

@Repository
public class PPPulmonarDAO 
{
	@PersistenceContext
	private EntityManager manager;
	
	public void adiciona(PPPulmonar pulm){
		manager.persist(pulm);	
	}
	
	@Transactional
	public void atualiza(PPPulmonar pulm){
		manager.merge(pulm);
	}
	
/*	@SuppressWarnings("unchecked")
	public List<PPPulmonar> ListaPPPulmonar(){
		return manager.createQuery("select p from PPPulmonar p").getResultList();
	}*/
	
/*	public PPPulmonar buscaPorId(Long id){
		return manager.find(PPPulmonar.class, id);
	}
	
	public void remove(PPPulmonar pulm){
		PPPulmonar pulmrem = buscaPorId(pulm.getId_pppulmonar());
		manager.remove(pulmrem);
	}*/
	
	@SuppressWarnings("rawtypes")
	public PPPulmonar ListaPPPulmonarAnalise(Long id)
	{
		Query query = manager.createQuery("select e from PPPulmonar e JOIN e.analiserecetor analiserecetor WHERE analiserecetor.id_analiserecetor =:idanalise");
		query.setParameter("idanalise", id);

		List results = query.getResultList();
		PPPulmonar rad = null;
		
		if(!results.isEmpty())
		{
			rad = (PPPulmonar) results.get(0);
		}
		
		return rad;
	}
}
