package pt.iconic.ipst.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import pt.iconic.ipst.modelo.Entidade;

@Repository
@Transactional
public class EntidadeDAO 
{
	@PersistenceContext
	private EntityManager manager;	
	
/*	public void adiciona(Entidade ent){
		manager.persist(ent);	
	}
	
	public void atualiza(Entidade ent){
		manager.merge(ent);
	}*/

	@SuppressWarnings("unchecked")
	public List<Entidade> ListaEntidade(){
		return manager.createQuery("select a from Entidade a").getResultList();
	}
	
	public Entidade buscaPorId(Long id){
		return manager.find(Entidade.class, id);
	}
	
/*	public void remove(Entidade ent){
		Entidade assARemover = buscaPorId(ent.getId_Entidade());
		manager.remove(assARemover);
	}*/

	@SuppressWarnings({ "unchecked" })
	public List<String> ListaEntidadeCompromissos() {
/*		Query query = manager.createNativeQuery("select distinct(ACSSDETALHECOLHEITA.ENTIDADE), ACSSDETALHECOLHEITA.ID_ACSSDETALHECOLHEITA "
				+ "from ACSSDETALHECOLHEITA where ACSSDETALHECOLHEITA.ID_COMPROMISSO is null", ACSSDetalheColheita.class);*/
		
		Query query = manager.createNativeQuery("select distinct(a.ENTIDADE) "
				+ "from ACSSDETALHECOLHEITA a where a.ID_COMPROMISSO is null");
		
		List<String> results = query.getResultList();
		
        
/*        
        int count = 0;  
        for (Iterator i = results.iterator(); i.hasNext();) {  
            String values = (String) i.next();  
            System.out.println(++count + ": " + values+ "<br />");  

        } */
		

		return results;
	}

	@SuppressWarnings("rawtypes")
	public Entidade buscaPorNome(String entidade) {
	
		Query query = manager.createNativeQuery("select e.* from ENTIDADE e "
				+ "inner join HOSPITAL h on (h.ID_ENTIDADE = e.ID_ENTIDADE) "
				+ "where h.NOMEHOSPITAL LIKE :entidade", Entidade.class);
		
		query.setParameter("entidade", entidade);
		
		List results = query.getResultList();
		Entidade entidade2 = null;
		if(!results.isEmpty()){
		    // ignores multiple results
			entidade2 = (Entidade) results.get(0);
		}
		return entidade2;
		
	
	}
}
