package pt.iconic.ipst.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import pt.iconic.ipst.modelo.TransplantePosOperatorioTerapeuticas;

@Repository
@Transactional
public class TransplantePosOperatorioTerapeuticasDAO {

	@PersistenceContext
	private EntityManager manager;
	
	
	public void adiciona(TransplantePosOperatorioTerapeuticas transplante){
		manager.persist(transplante);	
	}
	

	public void atualiza(TransplantePosOperatorioTerapeuticas transplante){
		manager.merge(transplante);
	}
	

/*	@SuppressWarnings("unchecked")
	public List<TransplantePosOperatorioTerapeuticas> ListaTranspPosOperatorioTerapeuticas(){
		return manager.createQuery("select a from TransplantePosOperatorioTerapeuticas a").getResultList();
	}*/
	
	public TransplantePosOperatorioTerapeuticas buscaPorId(Long id){
		return manager.find(TransplantePosOperatorioTerapeuticas.class, id);
	}
	
	
	public void remove(TransplantePosOperatorioTerapeuticas transplante){
		TransplantePosOperatorioTerapeuticas transplanteARemover = buscaPorId(transplante.getIdterapposop());
		manager.remove(transplanteARemover);
		
	}
	
	@SuppressWarnings("unchecked")
	public List<TransplantePosOperatorioTerapeuticas> listaTranspPosOperatorioterapassig(Long idassigorg){
		
		Query query = manager.createQuery("select b from TransplantePosOperatorioTerapeuticas b JOIN b.assigorgao a WHERE a.id_assignacao =:idassigorg");
		query.setParameter("idassigorg", idassigorg);
		
		List<TransplantePosOperatorioTerapeuticas> results = query.getResultList();
		return results;
		
	}
}
