package pt.iconic.ipst.modelo;

import java.util.Calendar;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name = "BRONCOESCOPIA")
public class Broncoescopia 
{
	private Long Id_Broncoescopia;
	private Calendar DataBroncoescopia;
	private String Notas;
	private boolean Lesoes;
	private int Traqueia;
	private int Brdireito;
	private int Bresquerdo;
	private int Brsuplementar;
	private boolean Amostralab;
	private int aspiracao;
	private int orificiosbrdireito;
	private int orificiosbresquerdo;
	private int orificiosbrsuplementar;
	private int secrecaobresquerdo;
	private int secrecaobrdireito;
	private int secrecaobrsuplementar;
	private AnaliseDador analiseDador;
	private boolean statusharmbronco;
	private Calendar datagravacao;
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="ID_BRONCOESCOPIA")
	public Long getId_Broncoescopia() {
		return Id_Broncoescopia;
	}
	public void setId_Broncoescopia(Long id_Broncoescopia) {
		Id_Broncoescopia = id_Broncoescopia;
	}
	
	@Column(name="DATABRONCOESCOPIA")
	public Calendar getDataBroncoescopia() {
		return DataBroncoescopia;
	}
	public void setDataBroncoescopia(Calendar dataBroncoescopia) {
		DataBroncoescopia = dataBroncoescopia;
	}
	
	@Column(name="NOTAS")
	public String getNotas() {
		return Notas;
	}
	public void setNotas(String notas) {
		Notas = notas;
	}
	
	@Column(name="LESOES")
	public boolean isLesoes() {
		return Lesoes;
	}
	public void setLesoes(boolean lesoes) {
		Lesoes = lesoes;
	}
	
	@Column(name="TRAQUEIA")
	public int getTraqueia() {
		return Traqueia;
	}
	public void setTraqueia(int traqueia) {
		Traqueia = traqueia;
	}
	
	@Column(name="BRDIREITO")
	public int getBrdireito() {
		return Brdireito;
	}
	public void setBrdireito(int brdireito) {
		Brdireito = brdireito;
	}
	
	@Column(name="BRESQUERDO")
	public int getBresquerdo() {
		return Bresquerdo;
	}
	public void setBresquerdo(int bresquerdo) {
		Bresquerdo = bresquerdo;
	}
	
	@Column(name="BRSUPLEMENTAR")
	public int getBrsuplementar() {
		return Brsuplementar;
	}
	public void setBrsuplementar(int brsuplementar) {
		Brsuplementar = brsuplementar;
	}

	@OneToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="ID_ANALISEDADOR")
	public AnaliseDador getAnaliseDador() {
		return analiseDador;
	}
	public void setAnaliseDador(AnaliseDador analiseDador) {
		this.analiseDador = analiseDador;
	}
	
	@Column(name="AMOSTRALAB")
	public boolean isAmostralab() {
		return Amostralab;
	}
	public void setAmostralab(boolean amostralab) {
		Amostralab = amostralab;
	}
	
	@Column(name="ASPIRACAO")
	public int getAspiracao() {
		return aspiracao;
	}
	public void setAspiracao(int aspiracao) {
		this.aspiracao = aspiracao;
	}
	
	@Column(name="ORIFICIOBRDIREITO")
	public int getOrificiosbrdireito() {
		return orificiosbrdireito;
	}
	public void setOrificiosbrdireito(int orificiosbrdireito) {
		this.orificiosbrdireito = orificiosbrdireito;
	}
	
	@Column(name="ORIFICIOBRESQUERDO")
	public int getOrificiosbresquerdo() {
		return orificiosbresquerdo;
	}
	public void setOrificiosbresquerdo(int orificiosbresquerdo) {
		this.orificiosbresquerdo = orificiosbresquerdo;
	}
	
	@Column(name="ORIFICIOBRSUPLEMENTAR")
	public int getOrificiosbrsuplementar() {
		return orificiosbrsuplementar;
	}
	public void setOrificiosbrsuplementar(int orificiosbrsuplementar) {
		this.orificiosbrsuplementar = orificiosbrsuplementar;
	}
	
	@Column(name="SECRECAOBRESQUERDO")
	public int getSecrecaobresquerdo() {
		return secrecaobresquerdo;
	}
	public void setSecrecaobresquerdo(int secrecaobresquerdo) {
		this.secrecaobresquerdo = secrecaobresquerdo;
	}
	
	@Column(name="SECRECAOBRDIREITO")
	public int getSecrecaobrdireito() {
		return secrecaobrdireito;
	}
	public void setSecrecaobrdireito(int secrecaobrdireito) {
		this.secrecaobrdireito = secrecaobrdireito;
	}
	
	@Column(name="SECRECAOBRSUPLEMENTAR")
	public int getSecrecaobrsuplementar() {
		return secrecaobrsuplementar;
	}
	public void setSecrecaobrsuplementar(int secrecaobrsuplementar) {
		this.secrecaobrsuplementar = secrecaobrsuplementar;
	}
	
	@Column(name="STATUSHARMONIO")
	public boolean isStatusharmbronco() {
		return statusharmbronco;
	}
	public void setStatusharmbronco(boolean statusharmbronco) {
		this.statusharmbronco = statusharmbronco;
	}
	
	@Column(name="DATAGRAVACAO")
	public Calendar getDatagravacao() {
		return datagravacao;
	}

	public void setDatagravacao(Calendar datagravacao) {
		this.datagravacao = datagravacao;
	}
}