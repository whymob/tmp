package pt.iconic.ipst.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import pt.iconic.ipst.modelo.PPHepatico;

@Repository
public class PPHepaticoDAO
{
	@PersistenceContext
	private EntityManager manager;
	
	public void adiciona(PPHepatico hep){
		manager.persist(hep);	
	}
	
	@Transactional
	public void atualiza(PPHepatico hep){
		manager.merge(hep);
	}
	
/*	@SuppressWarnings("unchecked")
	public List<PPHepatico> ListaPPHepatico(){
		return manager.createQuery("select p from PPHepatico p").getResultList();
	}*/
	
/*	public PPHepatico buscaPorId(Long id){
		return manager.find(PPHepatico.class, id);
	}
	
	public void remove(PPHepatico hep){
		PPHepatico heprem = buscaPorId(hep.getId_pphepatico());
		manager.remove(heprem);
	}*/
	
	@SuppressWarnings("rawtypes")
	public PPHepatico ListaPPHepaticoAnalise(Long id)
	{
		Query query = manager.createQuery("select e from PPHepatico e JOIN e.analiserecetor analiserecetor WHERE analiserecetor.id_analiserecetor =:idanalise");
		query.setParameter("idanalise", id);

		List results = query.getResultList();
		PPHepatico rad = null;
		
		if(!results.isEmpty())
		{
			rad = (PPHepatico) results.get(0);
		}
		
		return rad;
	}
}
