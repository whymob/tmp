package pt.iconic.ipst.modelo;

import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name = "CAUSAMORTE")
public class CausaMorte {

	
	private Long Id_CausaMorte;
	private String DescricaoCausaMorte;
	private List<BDAvaliacaoInicial> BDAvaliacaoInicial;
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "ID_CAUSAMORTE")
	public Long getId_CausaMorte() {
		return Id_CausaMorte;
	}
	public void setId_CausaMorte(Long id_CausaMorte) {
		Id_CausaMorte = id_CausaMorte;
	}
	
	@Column(name = "DESCRICAOCAUSAMORTE")
	public String getDescricaoCausaMorte() {
		return DescricaoCausaMorte;
	}
	public void setDescricaoCausaMorte(String descricaoCausaMorte) {
		DescricaoCausaMorte = descricaoCausaMorte;
	}
	
	@OneToMany(fetch = FetchType.LAZY, mappedBy = "causaMorte")
	public List<BDAvaliacaoInicial> getBDAvaliacaoInicial() {
		return BDAvaliacaoInicial;
	}
	public void setBDAvaliacaoInicial(List<BDAvaliacaoInicial> bDAvaliacaoInicial) {
		BDAvaliacaoInicial = bDAvaliacaoInicial;
	}	
	
	
	
	
}
