package pt.iconic.ipst.modelo;

import java.util.Calendar;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;


@Entity
@Table(name = "BIOPSIA_HEPATICA")
public class BiopsiaHepatica {

	
	private Long idbiopsiahepatica;
	private Calendar data;
	private String biopsia;
	private boolean esteatose;
	private int esteatosevesicular;
	private int esteatoselobular;
	private int esteatosegravidade;
	private boolean fibrose;
	private boolean inflamacao;
	private String notas;
	private AnaliseDador analiseDador;
	private boolean statusharmecohepatica;
	private String caminhodochepatica;
	private String nomedochepatica;
	private Calendar datagravacao;
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="ID_BIOPSIAHEPATICA")
	public Long getIdbiopsiahepatica() {
		return idbiopsiahepatica;
	}
	public void setIdbiopsiahepatica(Long idbiopsiahepatica) {
		this.idbiopsiahepatica = idbiopsiahepatica;
	}
	
	@Column(name="DATA")
	public Calendar getData() {
		return data;
	}
	public void setData(Calendar data) {
		this.data = data;
	}
	
	@Column(name="BIOPSIA")
	public String getBiopsia() {
		return biopsia;
	}
	public void setBiopsia(String biopsia) {
		this.biopsia = biopsia;
	}
	
	@Column(name="ESTEATOSE")
	public boolean isEsteatose() {
		return esteatose;
	}
	public void setEsteatose(boolean esteatose) {
		this.esteatose = esteatose;
	}
	
	@Column(name="ESTEATOSE_VESICULAR")
	public int getEsteatosevesicular() {
		return esteatosevesicular;
	}
	public void setEsteatosevesicular(int esteatosevesicular) {
		this.esteatosevesicular = esteatosevesicular;
	}
	
	@Column(name="ESTEATOSE_LOBULAR")
	public int getEsteatoselobular() {
		return esteatoselobular;
	}
	public void setEsteatoselobular(int esteatoselobular) {
		this.esteatoselobular = esteatoselobular;
	}
	
	@Column(name="ESTEATOSE_GRAVIDADE")
	public int getEsteatosegravidade() {
		return esteatosegravidade;
	}
	public void setEsteatosegravidade(int esteatosegravidade) {
		this.esteatosegravidade = esteatosegravidade;
	}
	
	@Column(name="FIBROSE")
	public boolean isFibrose() {
		return fibrose;
	}
	public void setFibrose(boolean fibrose) {
		this.fibrose = fibrose;
	}
	
	@Column(name="INFLAMACAO")
	public boolean isInflamacao() {
		return inflamacao;
	}
	public void setInflamacao(boolean inflamacao) {
		this.inflamacao = inflamacao;
	}
	
	@Column(name="NOTAS")
	public String getNotas() {
		return notas;
	}
	public void setNotas(String notas) {
		this.notas = notas;
	}
	
	@OneToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="ID_ANALISEDADOR")
	public AnaliseDador getAnaliseDador() {
		return analiseDador;
	}
	public void setAnaliseDador(AnaliseDador analiseDador) {
		this.analiseDador = analiseDador;
	}
	
	@Column(name="STATUSHARMONIO")
	public boolean isStatusharmecohepatica() {
		return statusharmecohepatica;
	}
	public void setStatusharmecohepatica(boolean statusharmecohepatica) {
		this.statusharmecohepatica = statusharmecohepatica;
	}

	@Column(name="CAMINHO_DOC_HEPATICA")
	public String getCaminhodochepatica() {
		return caminhodochepatica;
	}
	public void setCaminhodochepatica(String caminhodochepatica) {
		this.caminhodochepatica = caminhodochepatica;
	}
	
	@Column(name="NOME_DOC_HEPATICA")
	public String getNomedochepatica() {
		return nomedochepatica;
	}
	public void setNomedochepatica(String nomedochepatica) {
		this.nomedochepatica = nomedochepatica;
	}
	
	@Column(name="DATAGRAVACAO")
	public Calendar getDatagravacao() {
		return datagravacao;
	}

	public void setDatagravacao(Calendar datagravacao) {
		this.datagravacao = datagravacao;
	}

}
