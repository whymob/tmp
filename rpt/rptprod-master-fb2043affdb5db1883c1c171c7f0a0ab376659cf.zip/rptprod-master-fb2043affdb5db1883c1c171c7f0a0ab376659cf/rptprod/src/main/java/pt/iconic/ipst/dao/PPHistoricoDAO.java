package pt.iconic.ipst.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;

@Repository
public class PPHistoricoDAO {

	
	@PersistenceContext
	private EntityManager manager;
	
	@SuppressWarnings({ "rawtypes", "unchecked" })
	public List<Object> buscahistoricocandidato(int sns) {
		
		Query query = manager.createNativeQuery("select art.ID_ANALISE_RECETOR_TRANSP, ao.ID_ASSIGNACAO_ORGAOS "
				+ ",org.NOME_ORGAO  "
				+ ",(select case when exists (select tf.ID_ASSIGNACAO_ORGAOS from TRANSPLANTE_FIGADO tf where tf.ID_ASSIGNACAO_ORGAOS = ao.ID_ASSIGNACAO_ORGAOS and tf.ESTADO<>0) then (select tf.FIM from TRANSPLANTE_FIGADO tf where tf.ID_ASSIGNACAO_ORGAOS = ao.ID_ASSIGNACAO_ORGAOS and tf.ESTADO<>0 ) "
				+ "when exists (select tp.ID_ASSIGNACAO_ORGAOS from TRANSPLANTE_PANCREAS tp where tp.ID_ASSIGNACAO_ORGAOS = ao.ID_ASSIGNACAO_ORGAOS and tp.ESTADO<>0) then (select tp.FIM from TRANSPLANTE_PANCREAS tp where tp.ID_ASSIGNACAO_ORGAOS = ao.ID_ASSIGNACAO_ORGAOS and tp.ESTADO<>0 ) "
				+ "when exists (select tc.ID_ASSIGNACAO_ORGAOS from TRANSPLANTE_CORACAO tc where tc.ID_ASSIGNACAO_ORGAOS = ao.ID_ASSIGNACAO_ORGAOS and tc.ESTADO<>0) then (select tc.FIM from TRANSPLANTE_CORACAO tc where tc.ID_ASSIGNACAO_ORGAOS = ao.ID_ASSIGNACAO_ORGAOS and tc.ESTADO<>0) "
				+ "when exists (select tpu.ID_ASSIGNACAO_ORGAOS from TRANSPLANTE_PULMOES tpu where tpu.ID_ASSIGNACAO_ORGAOS = ao.ID_ASSIGNACAO_ORGAOS and tpu.ESTADO<>0) then (select tpu.FIM from TRANSPLANTE_PULMOES tpu where tpu.ID_ASSIGNACAO_ORGAOS = ao.ID_ASSIGNACAO_ORGAOS and tpu.ESTADO<>0) "
				+ "when exists (select tr.ID_ASSIGNACAO_ORGAOS from TRANSPLANTE_RINS tr where tr.ID_ASSIGNACAO_ORGAOS = ao.ID_ASSIGNACAO_ORGAOS and tr.ESTADO<>0) then (select tr.FIM from TRANSPLANTE_RINS tr where tr.ID_ASSIGNACAO_ORGAOS = ao.ID_ASSIGNACAO_ORGAOS and tr.ESTADO<>0) "
				+ "end) as DATA "
				+ ", h.NOMEHOSPITAL+'-'+ ut.NOME , r.CODIGORECETOR "
				+ "from ANALISE_RECETOR_TRANSPLANTE art "
				+ "inner join ASSIGNACAO_ORGAOS ao on (ao.ID_ASSIGNACAO_ORGAOS = art.ID_ASSIGORG) "
				+ "inner join RECETOR r on (art.ID_RECETOR = r.ID_RECETOR) "
				+ "inner join ORGAOS_OFERTA org on (org.ID_ORGAO_OFERTA = r.ID_ORGAO) "
				+ "inner join UNIDADETRANSPLANTE ut on (ut.ID_UNIDADETRANSP = org.ID_UNIDADE_TRANSP) "
				+ "inner join HOSPITAL h on (h.ID_HOSPITAL = r.ID_HOSPITAL) "
				+ "inner join ANALISERECETOR ar on (ar.ID_RECETOR = r.ID_RECETOR) "
				+ "inner join ESTADORECETOR er on (er.ID_ANALISERECETOR = ar.ID_ANALISERECETOR) "
				+ "where r.SNS = :sns and art.ID_ESTADO_ANALISE_RECETOR = 3 "
				+ "and er.ESTADO = 5 and (select case when exists (select tc.FIM from TRANSPLANTE_CORACAO tc where tc.ID_ASSIGNACAO_ORGAOS = ao.ID_ASSIGNACAO_ORGAOS and tc.ESTADO<>0) then 'Cora��o' "
				+ "when exists (select tp.ID_ASSIGNACAO_ORGAOS from TRANSPLANTE_PANCREAS tp where tp.ID_ASSIGNACAO_ORGAOS = ao.ID_ASSIGNACAO_ORGAOS and tp.ESTADO<>0) then 'P�ncreas' "
				+ "when exists (select tf.ID_ASSIGNACAO_ORGAOS from TRANSPLANTE_FIGADO tf where tf.ID_ASSIGNACAO_ORGAOS = ao.ID_ASSIGNACAO_ORGAOS and tf.ESTADO<>0) then 'Figado' "
				+ "when exists (select tpu.ID_ASSIGNACAO_ORGAOS from TRANSPLANTE_PULMOES tpu where tpu.ID_ASSIGNACAO_ORGAOS = ao.ID_ASSIGNACAO_ORGAOS and tpu.ESTADO<>0) then 'Pulmoes' "
				+ "when exists (select tr.ID_ASSIGNACAO_ORGAOS from TRANSPLANTE_RINS tr where tr.ID_ASSIGNACAO_ORGAOS = ao.ID_ASSIGNACAO_ORGAOS and tr.ESTADO<>0) then 'Rins' "
				+ "end)is not null");
		
		query.setParameter("sns", sns);
		
		List results = query.getResultList();

		return results;
	}
}
