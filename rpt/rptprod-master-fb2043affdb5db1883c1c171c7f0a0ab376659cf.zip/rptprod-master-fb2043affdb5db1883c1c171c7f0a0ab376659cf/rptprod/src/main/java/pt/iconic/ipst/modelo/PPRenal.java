package pt.iconic.ipst.modelo;

import java.util.Calendar;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name = "PPRENAL")
public class PPRenal 
{
	private Long id_pprenal;
	private AnaliseRecetor analiserecetor;
//	private double pesorenal;
//	private int alturarenal;
//	private Etnia etniarenal;
	private int transfusoesrenal;
	private int gestacoesrenal;
	private float imcrenal;
	private int pertoraxicorenal;
	private Calendar ulimatransfusaorenal;
//	private boolean hbrenal;
//	private boolean hcrenal;
//	private boolean rhrenal;
//	private int aborenal;
	private int diagnosticorenal;
	private String observacoesrenal;
	private boolean retransplantadorenal; //iniciou tratamento ou n�o
	private int etiologiarenal;
	private int cdialiserenal;
	//centro de dialise peritoneal
	private int ltratamentorenal;
	private Calendar iniciotratamentorenal;
	private String caminhodocpptrenal;
	private String nomedocpptrenal;
//	private boolean biopsiarenal;
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="ID_PPRENAL")
	public Long getId_pprenal() {
		return id_pprenal;
	}
	public void setId_pprenal(Long id_pprenal) {
		this.id_pprenal = id_pprenal;
	}
	
	@OneToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="ID_ANALISERECETOR")
	public AnaliseRecetor getAnaliserecetor() {
		return analiserecetor;
	}
	public void setAnaliserecetor(AnaliseRecetor analiserecetor) {
		this.analiserecetor = analiserecetor;
	}
	
//	@Column(name="PESO")
//	public double getPesorenal() {
//		return pesorenal;
//	}
//	public void setPesorenal(double pesorenal) {
//		this.pesorenal = pesorenal;
//	}
//	
//	@Column(name="ALTURA")
//	public int getAlturarenal() {
//		return alturarenal;
//	}
//	public void setAlturarenal(int alturarenal) {
//		this.alturarenal = alturarenal;
//	}
//	
//	@OneToOne(fetch = FetchType.EAGER)
//    @JoinColumn(name = "ID_ETNIA")
//	public Etnia getEtniarenal() {
//		return etniarenal;
//	}
//	public void setEtniarenal(Etnia etniarenal) {
//		this.etniarenal = etniarenal;
//	}
	
	@Column(name="TRANSFUSOES")
	public int getTransfusoesrenal() {
		return transfusoesrenal;
	}
	public void setTransfusoesrenal(int transfusoesrenal) {
		this.transfusoesrenal = transfusoesrenal;
	}
	
	@Column(name="GESTACOES")
	public int getGestacoesrenal() {
		return gestacoesrenal;
	}
	public void setGestacoesrenal(int gestacoesrenal) {
		this.gestacoesrenal = gestacoesrenal;
	}
	
	@Column(name="IMC")
	public float getImcrenal() {
		return imcrenal;
	}
	public void setImcrenal(float imcrenal) {
		this.imcrenal = imcrenal;
	}
	
	@Column(name="PERTORAXICO")
	public int getPertoraxicorenal() {
		return pertoraxicorenal;
	}
	public void setPertoraxicorenal(int pertoraxicorenal) {
		this.pertoraxicorenal = pertoraxicorenal;
	}
	
	@Column(name="ULTIMATRANSFUSAO")
	public Calendar getUlimatransfusaorenal() {
		return ulimatransfusaorenal;
	}
	public void setUlimatransfusaorenal(Calendar ulimatransfusaorenal) {
		this.ulimatransfusaorenal = ulimatransfusaorenal;
	}
	
//	@Column(name="HB")
//	public boolean isHbrenal() {
//		return hbrenal;
//	}
//	public void setHbrenal(boolean hbrenal) {
//		this.hbrenal = hbrenal;
//	}
//	
//	@Column(name="HC")
//	public boolean isHcrenal() {
//		return hcrenal;
//	}
//	public void setHcrenal(boolean hcrenal) {
//		this.hcrenal = hcrenal;
//	}
	
//	@Column(name="RH")
//	public boolean isRhrenal() {
//		return rhrenal;
//	}
//	public void setRhrenal(boolean rhrenal) {
//		this.rhrenal = rhrenal;
//	}
//	
//	@Column(name="ABO")
//	public int getAborenal() {
//		return aborenal;
//	}
//	public void setAborenal(int aborenal) {
//		this.aborenal = aborenal;
//	}
	
	@Column(name="DIAGNOSTICO")
	public int getDiagnosticorenal() {
		return diagnosticorenal;
	}
	public void setDiagnosticorenal(int diagnosticorenal) {
		this.diagnosticorenal = diagnosticorenal;
	}
	
	@Column(name="OBSERVACOES")
	public String getObservacoesrenal() {
		return observacoesrenal;
	}
	public void setObservacoesrenal(String observacoesrenal) {
		this.observacoesrenal = observacoesrenal;
	}
	
	@Column(name="RETRANSPLANTADO")
	public boolean isRetransplantadorenal() {
		return retransplantadorenal;
	}
	public void setRetransplantadorenal(boolean retransplantadorenal) {
		this.retransplantadorenal = retransplantadorenal;
	}
	
	@Column(name="ETIOLOGIA")
	public int getEtiologiarenal() {
		return etiologiarenal;
	}
	public void setEtiologiarenal(int etiologiarenal) {
		this.etiologiarenal = etiologiarenal;
	}
	
	@Column(name="DIALISE")
	public int getCdialiserenal() {
		return cdialiserenal;
	}
	public void setCdialiserenal(int cdialiserenal) {
		this.cdialiserenal = cdialiserenal;
	}
	
	@Column(name="TRATAMENTO")
	public int getLtratamentorenal() {
		return ltratamentorenal;
	}
	public void setLtratamentorenal(int ltratamentorenal) {
		this.ltratamentorenal = ltratamentorenal;
	}
	
	@Column(name="INICIOTRATAMENTO")
	public Calendar getIniciotratamentorenal() {
		return iniciotratamentorenal;
	}
	public void setIniciotratamentorenal(Calendar iniciotratamentorenal) {
		this.iniciotratamentorenal = iniciotratamentorenal;
	}
	
	@Column(name="CAMINHO_DOC_PPTRENAL")
	public String getCaminhodocpptrenal() {
		return caminhodocpptrenal;
	}
	public void setCaminhodocpptrenal(String caminhodocpptrenal) {
		this.caminhodocpptrenal = caminhodocpptrenal;
	}
	
	@Column(name="NOME_DOC_PPTRENAL")
	public String getNomedocpptrenal() {
		return nomedocpptrenal;
	}
	public void setNomedocpptrenal(String nomedocpptrenal) {
		this.nomedocpptrenal = nomedocpptrenal;
	}
	
//	@Column(name="BIOPSIA")
//	public boolean isBiopsiarenal() {
//		return biopsiarenal;
//	}
//	public void setBiopsiarenal(boolean biopsiarenal) {
//		this.biopsiarenal = biopsiarenal;
//	}
}