package pt.iconic.ipst.modelo;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name="UNIDADES_AMOSTRASFO")
public class UnidadesAmostrasFO {

	private Long id_unidades_amostras;
	private AmostrasFO amostraFO;
	private UnidadesGeral unidadesGeral;
//	private List<AmostrasFuncoesOrgao> Amostra;
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="ID_UNIDADES_AMOSTRAS")
	public Long getId_unidades_amostras() {
		return id_unidades_amostras;
	}
	public void setId_unidades_amostras(Long id_unidades_amostras) {
		this.id_unidades_amostras = id_unidades_amostras;
	}
	
	@ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "ID_AMOSTRAFO")
	public AmostrasFO getAmostraFO() {
		return amostraFO;
	}
	public void setAmostraFO(AmostrasFO amostraFO) {
		this.amostraFO = amostraFO;
	}
	
	@ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "ID_UNIDADES")
	public UnidadesGeral getUnidadesGeral() {
		return unidadesGeral;
	}
	public void setUnidadesGeral(UnidadesGeral unidadesGeral) {
		this.unidadesGeral = unidadesGeral;
	}
	


	

	


	
	
}
