package pt.iconic.ipst.modelo;

import java.util.Calendar;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import org.springframework.format.annotation.DateTimeFormat;

@Entity
@Table(name = "COLHEITA_TME")
public class ColheitaTME {

	private Long idcolheitatme;
	private Calendar iniciotme;
	private Calendar fimtme;
	private int fllado;
	private String flcodigo;
	private boolean flnaoretirado;
	private int tglado;
	private String tgcodigo;
	private boolean tgnaoretirado;
	private int tstlado;
	private String tstcodigo;
	private boolean tstnaoretirado;
	private int flado;
	private String fcodigo;
	private boolean fnaoretirado;
	private int ttalado;
	private String ttacodigo;
	private boolean ttanaoretirado;
	private int ttplado;
	private String ttpcodigo;
	private boolean ttpnaoretirado;
	private int tplado;
	private String tpcodigo;
	private boolean tpnaoretirado;
	private int tmlado;
	private String tmcodigo;
	private boolean tmnaoretirado;
	private int taeclado;
	private String taeccodigo;
	private boolean taecnaoretirado;
	private int trlado;
	private String trcodigo;
	private boolean trnaoretirado;
	private int tqlado;
	private String tqcodigo;
	private boolean tqnaoretirado;
	private int tactllado;
	private String tactlcodigo;
	private boolean tactlnaoretirado;
	private int taclado;
	private String taccodigo;
	private boolean tacnaoretirado;
	private int aeclado;
	private String aeccodigo;
	private boolean aecnaoretirado;
	private int plado;
	private String pcodigo;
	private boolean pnaoretirado;
	private int ulado;
	private String ucodigo;
	private boolean unaoretirado;
	private int vllado;
	private String vlcodigo;
	private boolean vlnaoretirado;
	private int hplado;
	private String hpcodigo;
	private boolean hpnaoretirado;
	private int cilado;
	private String cicodigo;
	private boolean cinaoretirado;
	private int cxlado;
	private String cxcodigo;
	private boolean cxnaoretirado;
	private int otlado;
	private String otcodigo;
	private boolean otnaoretirado;
	private boolean controlo;
	private int desigcontrolo;
	private int fabricante;
	private String lote;
	private Calendar validade;
	private int zaragatoas;
	private int embalagens;
	private String notas;
	private AnaliseDador analiseDador;
	private String codtme;
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="ID_COLHEITA_TME")
	public Long getIdcolheitatme() {
		return idcolheitatme;
	}
	public void setIdcolheitatme(Long idcolheitatme) {
		this.idcolheitatme = idcolheitatme;
	}
	
	@Column(name="INICIO")
	public Calendar getIniciotme() {
		return iniciotme;
	}
	public void setIniciotme(Calendar iniciotme) {
		this.iniciotme = iniciotme;
	}
	
	@Column(name="FIM")
	public Calendar getFimtme() {
		return fimtme;
	}
	public void setFimtme(Calendar fimtme) {
		this.fimtme = fimtme;
	}
	
	@Column(name="FL_LADO")
	public int getFllado() {
		return fllado;
	}
	public void setFllado(int fllado) {
		this.fllado = fllado;
	}
	
	@Column(name="FL_COD")
	public String getFlcodigo() {
		return flcodigo;
	}
	public void setFlcodigo(String flcodigo) {
		this.flcodigo = flcodigo;
	}
	
	@Column(name="FL_NRETIRADO")
	public boolean isFlnaoretirado() {
		return flnaoretirado;
	}
	public void setFlnaoretirado(boolean flnaoretirado) {
		this.flnaoretirado = flnaoretirado;
	}
	
	@Column(name="TG_LADO")
	public int getTglado() {
		return tglado;
	}
	public void setTglado(int tglado) {
		this.tglado = tglado;
	}
	
	@Column(name="TG_COD")
	public String getTgcodigo() {
		return tgcodigo;
	}
	
	public void setTgcodigo(String tgcodigo) {
		this.tgcodigo = tgcodigo;
	}
	
	@Column(name="TG_NRETIRADO")
	public boolean isTgnaoretirado() {
		return tgnaoretirado;
	}
	public void setTgnaoretirado(boolean tgnaoretirado) {
		this.tgnaoretirado = tgnaoretirado;
	}
	
	@Column(name="TST_LADO")
	public int getTstlado() {
		return tstlado;
	}
	public void setTstlado(int tstlado) {
		this.tstlado = tstlado;
	}
	
	@Column(name="TST_COD")
	public String getTstcodigo() {
		return tstcodigo;
	}
	public void setTstcodigo(String tstcodigo) {
		this.tstcodigo = tstcodigo;
	}
	
	@Column(name="TST_NRETIRADO")
	public boolean isTstnaoretirado() {
		return tstnaoretirado;
	}
	public void setTstnaoretirado(boolean tstnaoretirado) {
		this.tstnaoretirado = tstnaoretirado;
	}
	
	@Column(name="F_LADO")
	public int getFlado() {
		return flado;
	}
	public void setFlado(int flado) {
		this.flado = flado;
	}
	
	@Column(name="F_COD")
	public String getFcodigo() {
		return fcodigo;
	}
	public void setFcodigo(String fcodigo) {
		this.fcodigo = fcodigo;
	}
	
	@Column(name="F_NRETIRADO")
	public boolean isFnaoretirado() {
		return fnaoretirado;
	}
	public void setFnaoretirado(boolean fnaoretirado) {
		this.fnaoretirado = fnaoretirado;
	}
	
	@Column(name="TTA_LADO")
	public int getTtalado() {
		return ttalado;
	}
	public void setTtalado(int ttalado) {
		this.ttalado = ttalado;
	}
	
	@Column(name="TTA_COD")
	public String getTtacodigo() {
		return ttacodigo;
	}
	public void setTtacodigo(String ttacodigo) {
		this.ttacodigo = ttacodigo;
	}
	
	@Column(name="TTA_NRETIRADO")
	public boolean isTtanaoretirado() {
		return ttanaoretirado;
	}
	public void setTtanaoretirado(boolean ttanaoretirado) {
		this.ttanaoretirado = ttanaoretirado;
	}
	
	@Column(name="TTP_LADO")
	public int getTtplado() {
		return ttplado;
	}
	public void setTtplado(int ttplado) {
		this.ttplado = ttplado;
	}
	
	@Column(name="TTP_COD")
	public String getTtpcodigo() {
		return ttpcodigo;
	}
	public void setTtpcodigo(String ttpcodigo) {
		this.ttpcodigo = ttpcodigo;
	}
	
	@Column(name="TTP_NRETIRADO")
	public boolean isTtpnaoretirado() {
		return ttpnaoretirado;
	}
	public void setTtpnaoretirado(boolean ttpnaoretirado) {
		this.ttpnaoretirado = ttpnaoretirado;
	}
	
	@Column(name="TP_LADO")
	public int getTplado() {
		return tplado;
	}
	public void setTplado(int tplado) {
		this.tplado = tplado;
	}
	
	@Column(name="TP_COD")
	public String getTpcodigo() {
		return tpcodigo;
	}
	public void setTpcodigo(String tpcodigo) {
		this.tpcodigo = tpcodigo;
	}
	
	@Column(name="TP_NRETIRADO")
	public boolean isTpnaoretirado() {
		return tpnaoretirado;
	}
	public void setTpnaoretirado(boolean tpnaoretirado) {
		this.tpnaoretirado = tpnaoretirado;
	}
	
	@Column(name="TM_LADO")
	public int getTmlado() {
		return tmlado;
	}
	public void setTmlado(int tmlado) {
		this.tmlado = tmlado;
	}
	
	@Column(name="TM_COD")
	public String getTmcodigo() {
		return tmcodigo;
	}
	public void setTmcodigo(String tmcodigo) {
		this.tmcodigo = tmcodigo;
	}
	
	@Column(name="TM_NRETIRADO")
	public boolean isTmnaoretirado() {
		return tmnaoretirado;
	}
	public void setTmnaoretirado(boolean tmnaoretirado) {
		this.tmnaoretirado = tmnaoretirado;
	}
	
	@Column(name="TAEC_LADO")
	public int getTaeclado() {
		return taeclado;
	}
	public void setTaeclado(int taeclado) {
		this.taeclado = taeclado;
	}
	
	@Column(name="TAEC_COD")
	public String getTaeccodigo() {
		return taeccodigo;
	}
	public void setTaeccodigo(String taeccodigo) {
		this.taeccodigo = taeccodigo;
	}
	
	@Column(name="TAEC_NRETIRADO")
	public boolean isTaecnaoretirado() {
		return taecnaoretirado;
	}
	public void setTaecnaoretirado(boolean taecnaoretirado) {
		this.taecnaoretirado = taecnaoretirado;
	}
	
	@Column(name="TR_LADO")
	public int getTrlado() {
		return trlado;
	}
	public void setTrlado(int trlado) {
		this.trlado = trlado;
	}
	
	@Column(name="TR_COD")
	public String getTrcodigo() {
		return trcodigo;
	}
	public void setTrcodigo(String trcodigo) {
		this.trcodigo = trcodigo;
	}
	
	@Column(name="TR_NRETIRADO")
	public boolean isTrnaoretirado() {
		return trnaoretirado;
	}
	public void setTrnaoretirado(boolean trnaoretirado) {
		this.trnaoretirado = trnaoretirado;
	}
	
	@Column(name="TQ_LADO")
	public int getTqlado() {
		return tqlado;
	}
	public void setTqlado(int tqlado) {
		this.tqlado = tqlado;
	}
	
	@Column(name="TQ_COD")
	public String getTqcodigo() {
		return tqcodigo;
	}
	public void setTqcodigo(String tqcodigo) {
		this.tqcodigo = tqcodigo;
	}
	
	@Column(name="TQ_NRETIRADO")
	public boolean isTqnaoretirado() {
		return tqnaoretirado;
	}
	public void setTqnaoretirado(boolean tqnaoretirado) {
		this.tqnaoretirado = tqnaoretirado;
	}
	
	@Column(name="TACTL_LADO")
	public int getTactllado() {
		return tactllado;
	}
	public void setTactllado(int tactllado) {
		this.tactllado = tactllado;
	}
	
	@Column(name="TACTL_COD")
	public String getTactlcodigo() {
		return tactlcodigo;
	}
	public void setTactlcodigo(String tactlcodigo) {
		this.tactlcodigo = tactlcodigo;
	}
	
	@Column(name="TACTL_NRETIRADO")
	public boolean isTactlnaoretirado() {
		return tactlnaoretirado;
	}
	public void setTactlnaoretirado(boolean tactlnaoretirado) {
		this.tactlnaoretirado = tactlnaoretirado;
	}
	
	@Column(name="TAC_LADO")
	public int getTaclado() {
		return taclado;
	}
	public void setTaclado(int taclado) {
		this.taclado = taclado;
	}
	
	@Column(name="TAC_COD")
	public String getTaccodigo() {
		return taccodigo;
	}
	public void setTaccodigo(String taccodigo) {
		this.taccodigo = taccodigo;
	}
	
	@Column(name="TAC_NRETIRADO")
	public boolean isTacnaoretirado() {
		return tacnaoretirado;
	}
	public void setTacnaoretirado(boolean tacnaoretirado) {
		this.tacnaoretirado = tacnaoretirado;
	}
	
	@Column(name="AEC_LADO")
	public int getAeclado() {
		return aeclado;
	}
	public void setAeclado(int aeclado) {
		this.aeclado = aeclado;
	}
	
	@Column(name="AEC_COD")
	public String getAeccodigo() {
		return aeccodigo;
	}
	public void setAeccodigo(String aeccodigo) {
		this.aeccodigo = aeccodigo;
	}
	
	@Column(name="AEC_NRETIRADO")
	public boolean isAecnaoretirado() {
		return aecnaoretirado;
	}
	public void setAecnaoretirado(boolean aecnaoretirado) {
		this.aecnaoretirado = aecnaoretirado;
	}
	
	@Column(name="P_LADO")
	public int getPlado() {
		return plado;
	}
	public void setPlado(int plado) {
		this.plado = plado;
	}
	
	@Column(name="P_COD")
	public String getPcodigo() {
		return pcodigo;
	}
	public void setPcodigo(String pcodigo) {
		this.pcodigo = pcodigo;
	}
	
	@Column(name="P_NRETIRADO")
	public boolean isPnaoretirado() {
		return pnaoretirado;
	}
	public void setPnaoretirado(boolean pnaoretirado) {
		this.pnaoretirado = pnaoretirado;
	}
	
	@Column(name="U_LADO")
	public int getUlado() {
		return ulado;
	}
	public void setUlado(int ulado) {
		this.ulado = ulado;
	}
	
	@Column(name="U_COD")
	public String getUcodigo() {
		return ucodigo;
	}
	public void setUcodigo(String ucodigo) {
		this.ucodigo = ucodigo;
	}
	
	@Column(name="U_NRETIRADO")
	public boolean isUnaoretirado() {
		return unaoretirado;
	}
	public void setUnaoretirado(boolean unaoretirado) {
		this.unaoretirado = unaoretirado;
	}
	
	@Column(name="VL_LADO")
	public int getVllado() {
		return vllado;
	}
	public void setVllado(int vllado) {
		this.vllado = vllado;
	}
	
	@Column(name="VL_COD")
	public String getVlcodigo() {
		return vlcodigo;
	}
	public void setVlcodigo(String vlcodigo) {
		this.vlcodigo = vlcodigo;
	}
	
	@Column(name="VL_NRETIRADO")
	public boolean isVlnaoretirado() {
		return vlnaoretirado;
	}
	public void setVlnaoretirado(boolean vlnaoretirado) {
		this.vlnaoretirado = vlnaoretirado;
	}
	
	@Column(name="HP_LADO")
	public int getHplado() {
		return hplado;
	}
	public void setHplado(int hplado) {
		this.hplado = hplado;
	}
	
	@Column(name="HP_COD")
	public String getHpcodigo() {
		return hpcodigo;
	}
	public void setHpcodigo(String hpcodigo) {
		this.hpcodigo = hpcodigo;
	}
	
	@Column(name="HP_NRETIRADO")
	public boolean isHpnaoretirado() {
		return hpnaoretirado;
	}
	public void setHpnaoretirado(boolean hpnaoretirado) {
		this.hpnaoretirado = hpnaoretirado;
	}
	
	@Column(name="CI_LADO")
	public int getCilado() {
		return cilado;
	}
	public void setCilado(int cilado) {
		this.cilado = cilado;
	}
	
	@Column(name="CI_COD")
	public String getCicodigo() {
		return cicodigo;
	}
	public void setCicodigo(String cicodigo) {
		this.cicodigo = cicodigo;
	}
	
	@Column(name="CI_NRETIRADO")
	public boolean isCinaoretirado() {
		return cinaoretirado;
	}
	public void setCinaoretirado(boolean cinaoretirado) {
		this.cinaoretirado = cinaoretirado;
	}
	
	@Column(name="CX_LADO")
	public int getCxlado() {
		return cxlado;
	}
	public void setCxlado(int cxlado) {
		this.cxlado = cxlado;
	}
	
	@Column(name="CX_COD")
	public String getCxcodigo() {
		return cxcodigo;
	}
	public void setCxcodigo(String cxcodigo) {
		this.cxcodigo = cxcodigo;
	}
	
	@Column(name="CX_NRETIRADO")
	public boolean isCxnaoretirado() {
		return cxnaoretirado;
	}
	public void setCxnaoretirado(boolean cxnaoretirado) {
		this.cxnaoretirado = cxnaoretirado;
	}
	
	@Column(name="OT_LADO")
	public int getOtlado() {
		return otlado;
	}
	public void setOtlado(int otlado) {
		this.otlado = otlado;
	}
	
	@Column(name="OT_COD")
	public String getOtcodigo() {
		return otcodigo;
	}
	public void setOtcodigo(String otcodigo) {
		this.otcodigo = otcodigo;
	}
	
	@Column(name="OT_NRETIRADO")
	public boolean isOtnaoretirado() {
		return otnaoretirado;
	}
	public void setOtnaoretirado(boolean otnaoretirado) {
		this.otnaoretirado = otnaoretirado;
	}
	
	@Column(name="CONTROLO")
	public boolean isControlo() {
		return controlo;
	}
	public void setControlo(boolean controlo) {
		this.controlo = controlo;
	}
	
	@Column(name="DESIG_CONTROLO")
	public int getDesigcontrolo() {
		return desigcontrolo;
	}
	public void setDesigcontrolo(int desigcontrolo) {
		this.desigcontrolo = desigcontrolo;
	}
	
	@Column(name="FABRICANTE")
	public int getFabricante() {
		return fabricante;
	}
	public void setFabricante(int fabricante) {
		this.fabricante = fabricante;
	}
	
	@Column(name="LOTE")
	public String getLote() {
		return lote;
	}
	public void setLote(String lote) {
		this.lote = lote;
	}
	
	@Column(name="VALIDADE")
	@DateTimeFormat(pattern="dd/MM/yyyy")
	public Calendar getValidade() {
		return validade;
	}
	public void setValidade(Calendar validade) {
		this.validade = validade;
	}
	
	@Column(name="ZARAGATOAS")
	public int getZaragatoas() {
		return zaragatoas;
	}
	public void setZaragatoas(int zaragatoas) {
		this.zaragatoas = zaragatoas;
	}
	
	@Column(name="EMBALAGENS")
	public int getEmbalagens() {
		return embalagens;
	}
	public void setEmbalagens(int embalagens) {
		this.embalagens = embalagens;
	}
	
	@Column(name="NOTAS")
	public String getNotas() {
		return notas;
	}
	public void setNotas(String notas) {
		this.notas = notas;
	}
	
	@OneToOne(fetch=FetchType.EAGER)
	@JoinColumn(name="ID_ANALISEDADOR")
	public AnaliseDador getAnaliseDador() {
		return analiseDador;
	}
	public void setAnaliseDador(AnaliseDador analiseDador) {
		this.analiseDador = analiseDador;
	}
	
	@Column(name="COD_TME")
	public String getCodtme() {
		return codtme;
	}
	public void setCodtme(String codtme) {
		this.codtme = codtme;
	}
	
}
