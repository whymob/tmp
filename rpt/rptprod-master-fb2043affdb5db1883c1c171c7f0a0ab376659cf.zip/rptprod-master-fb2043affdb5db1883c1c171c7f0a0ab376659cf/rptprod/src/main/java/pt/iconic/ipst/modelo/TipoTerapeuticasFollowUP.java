package pt.iconic.ipst.modelo;

import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name="TIPOTERAPEUTICASFOLLOWUP")
public class TipoTerapeuticasFollowUP {

	
	private Long Id_TipoTerapeuticasFollowUp;
	private String descricao;
	private List<TerapeuticasFollowUP> Terapeuticas;
	private UnidadesGeral unidades;
	
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="ID_TIPOTERAPEUTICASFOLLOWUP")
	public Long getId_TipoTerapeuticasFollowUp() {
		return Id_TipoTerapeuticasFollowUp;
	}
	public void setId_TipoTerapeuticasFollowUp(
			Long id_TipoTerapeuticasFollowUp) {
		Id_TipoTerapeuticasFollowUp = id_TipoTerapeuticasFollowUp;
	}
	
	@Column(name="DESCRICAO")
	public String getDescricao() {
		return descricao;
	}
	public void setDescricao(String descricao) {
		this.descricao = descricao;
	}
	
    @OneToMany(fetch = FetchType.LAZY, mappedBy = "tipoTerapeuticas")
	public List<TerapeuticasFollowUP> getTerapeuticas() {
		return Terapeuticas;
	}
	public void setTerapeuticas(List<TerapeuticasFollowUP> terapeuticas) {
		Terapeuticas = terapeuticas;
	}
	
    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "ID_UNIDADES")
	public UnidadesGeral getUnidades() {
		return unidades;
	}
	public void setUnidades(UnidadesGeral unidades) {
		this.unidades = unidades;
	}
	
	
	
}
