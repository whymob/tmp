package pt.iconic.ipst.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import pt.iconic.ipst.modelo.TransplanteCoracaoComplicacoes;

@Repository
@Transactional
public class TransplanteCoracaoComplicacoesDAO {

	
	@PersistenceContext
	private EntityManager manager;
	
	
	public void adiciona(TransplanteCoracaoComplicacoes transplante){
		manager.persist(transplante);	
	}
	

	public void atualiza(TransplanteCoracaoComplicacoes transplante){
		manager.merge(transplante);
	}
	
/*
	@SuppressWarnings("unchecked")
	public List<TransplanteCoracaoComplicacoes> ListaTransplanteCoracaoComplicacoes(){
		return manager.createQuery("select a from TransplanteCoracaoComplicacoes a").getResultList();
	}*/
	
	public TransplanteCoracaoComplicacoes buscaPorId(Long id){
		return manager.find(TransplanteCoracaoComplicacoes.class, id);
	}
	
	
	public void remove(TransplanteCoracaoComplicacoes transplante){
		TransplanteCoracaoComplicacoes transplanteARemover = buscaPorId(transplante.getIdtranspcoracaocompl());
		manager.remove(transplanteARemover);
		
	}
	
	@SuppressWarnings("unchecked")
	public List<TransplanteCoracaoComplicacoes> listatransplanteCoracaocomplassig(Long idassigorg){
		
		Query query = manager.createQuery("select b from TransplanteCoracaoComplicacoes b JOIN b.assigorgao a WHERE a.id_assignacao =:idassigorg");
		query.setParameter("idassigorg", idassigorg);
		
		List<TransplanteCoracaoComplicacoes> results = query.getResultList();
		return results;
		
	}
}
