package pt.iconic.ipst.modelo;

import java.util.Calendar;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;


@Entity
@Table(name = "COLHEITA_PELE")
public class ColheitaPele {

	private Long idcolheitapele;
	private Calendar iniciopele;
	private Calendar fimpele;
	private String areadorsopele;
	private int pecasdorsopele;
	private String areatorsopele;
	private int pecastorsopele;
	private String areapernpostpele;
	private int pecaspernpostpele;
	private String areapernantpele;
	private int pecaspernantpele;
	private String areatoraxpele;
	private int pecastoraxpele;
	private String areaabdompele;
	private int pecasabdompele;
	private String areaoutpele;
	private int pecasoutpele;
	private String notaspele;
	private AnaliseDador analiseDador;
	private String codpele;
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="ID_COLHEITA_PELE")
	public Long getIdcolheitapele() {
		return idcolheitapele;
	}
	public void setIdcolheitapele(Long idcolheitapele) {
		this.idcolheitapele = idcolheitapele;
	}
	
	@Column(name="INICIO")
	public Calendar getIniciopele() {
		return iniciopele;
	}
	public void setIniciopele(Calendar iniciopele) {
		this.iniciopele = iniciopele;
	}
	
	@Column(name="FIM")
	public Calendar getFimpele() {
		return fimpele;
	}
	public void setFimpele(Calendar fimpele) {
		this.fimpele = fimpele;
	}
	
	@Column(name="AREA_DORSO")
	public String getAreadorsopele() {
		return areadorsopele;
	}
	public void setAreadorsopele(String areadorsopele) {
		this.areadorsopele = areadorsopele;
	}
	
	@Column(name="PECAS_DORSO")
	public int getPecasdorsopele() {
		return pecasdorsopele;
	}
	public void setPecasdorsopele(int pecasdorsopele) {
		this.pecasdorsopele = pecasdorsopele;
	}
	
	@Column(name="AREA_TORSO")
	public String getAreatorsopele() {
		return areatorsopele;
	}
	public void setAreatorsopele(String areatorsopele) {
		this.areatorsopele = areatorsopele;
	}
	
	@Column(name="PECAS_TORSO")
	public int getPecastorsopele() {
		return pecastorsopele;
	}
	public void setPecastorsopele(int pecastorsopele) {
		this.pecastorsopele = pecastorsopele;
	}
	
	@Column(name="AREA_PERNAS_POST")
	public String getAreapernpostpele() {
		return areapernpostpele;
	}
	public void setAreapernpostpele(String areapernpostpele) {
		this.areapernpostpele = areapernpostpele;
	}
	
	@Column(name="PECAS_PERNAS_POST")
	public int getPecaspernpostpele() {
		return pecaspernpostpele;
	}
	public void setPecaspernpostpele(int pecaspernpostpele) {
		this.pecaspernpostpele = pecaspernpostpele;
	}
	
	@Column(name="AREA_PERNAS_ANT")
	public String getAreapernantpele() {
		return areapernantpele;
	}
	public void setAreapernantpele(String areapernantpele) {
		this.areapernantpele = areapernantpele;
	}
	
	@Column(name="PECAS_PERNAS_ANT")
	public int getPecaspernantpele() {
		return pecaspernantpele;
	}
	public void setPecaspernantpele(int pecaspernantpele) {
		this.pecaspernantpele = pecaspernantpele;
	}
	
	@Column(name="AREA_TORAX")
	public String getAreatoraxpele() {
		return areatoraxpele;
	}
	public void setAreatoraxpele(String areatoraxpele) {
		this.areatoraxpele = areatoraxpele;
	}
	
	@Column(name="PECAS_TORAX")
	public int getPecastoraxpele() {
		return pecastoraxpele;
	}
	public void setPecastoraxpele(int pecastoraxpele) {
		this.pecastoraxpele = pecastoraxpele;
	}
	
	@Column(name="AREA_ABDOMINAL")
	public String getAreaabdompele() {
		return areaabdompele;
	}
	public void setAreaabdompele(String areaabdompele) {
		this.areaabdompele = areaabdompele;
	}
	
	@Column(name="PECAS_ABDOMINAL")
	public int getPecasabdompele() {
		return pecasabdompele;
	}
	public void setPecasabdompele(int pecasabdompele) {
		this.pecasabdompele = pecasabdompele;
	}
	
	@Column(name="AREA_OUTROS")
	public String getAreaoutpele() {
		return areaoutpele;
	}
	public void setAreaoutpele(String areaoutpele) {
		this.areaoutpele = areaoutpele;
	}
	
	@Column(name="PECAS_OUTROS")
	public int getPecasoutpele() {
		return pecasoutpele;
	}
	public void setPecasoutpele(int pecasoutpele) {
		this.pecasoutpele = pecasoutpele;
	}
	
	@Column(name="NOTAS")
	public String getNotaspele() {
		return notaspele;
	}
	public void setNotaspele(String notaspele) {
		this.notaspele = notaspele;
	}
	@OneToOne(fetch=FetchType.EAGER)
	@JoinColumn(name="ID_ANALISEDADOR")
	public AnaliseDador getAnaliseDador() {
		return analiseDador;
	}
	public void setAnaliseDador(AnaliseDador analiseDador) {
		this.analiseDador = analiseDador;
	}
	
	@Column(name="COD_PELE")
	public String getCodpele() {
		return codpele;
	}
	public void setCodpele(String codpele) {
		this.codpele = codpele;
	}
	
	
}
