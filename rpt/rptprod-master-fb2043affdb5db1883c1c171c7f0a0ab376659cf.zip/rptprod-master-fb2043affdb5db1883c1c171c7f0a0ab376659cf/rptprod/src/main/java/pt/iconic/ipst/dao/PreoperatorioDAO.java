package pt.iconic.ipst.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import pt.iconic.ipst.modelo.Preoperatorio;


@Repository
@Transactional
public class PreoperatorioDAO {

	@PersistenceContext
	private EntityManager manager;
	
	public void adiciona(Preoperatorio po){
		manager.persist(po);	
	}
	
	public void atualiza(Preoperatorio po){
		manager.merge(po);
	}
	

/*	@SuppressWarnings("unchecked")
	public List<Preoperatorio> ListaPreoperatorio(){
		return manager.createQuery("select p from Preoperatorio p").getResultList();
	}*/
	
/*	public Preoperatorio buscaPorId(Long id){
		return manager.find(Preoperatorio.class, id);
	}*/
	
	
/*	public void remove(Preoperatorio po){
		Preoperatorio poARemover = buscaPorId(po.getId_preoperat());
		manager.remove(poARemover);
	}*/
	
	
//	@SuppressWarnings("unchecked")
//	public Preoperatorio buscaPreoperatorioanalise(Long idanalise){
//		
//		Query query = manager.createQuery("select p from Preoperatorio p JOIN p.analiseRecetor a WHERE a.id_analiserecetor =:idanalise");
//		query.setParameter("idanalise", idanalise);
//		
//		List<Preoperatorio> results = query.getResultList();
//		Preoperatorio colheita = null;
//		if(!results.isEmpty()){
//			colheita = (Preoperatorio) results.get(0);
//		}
//		return colheita;
//	}
	
	@SuppressWarnings("unchecked")
	public Preoperatorio buscaPreoperatorioDadorOrgao(Long idassigorg){
		
		Query query = manager.createQuery("select p from Preoperatorio p JOIN p.assigorgao a WHERE a.id_assignacao =:idassigorg");
		query.setParameter("idassigorg", idassigorg);
		
		List<Preoperatorio> results = query.getResultList();
		Preoperatorio p = null;
		if(!results.isEmpty()){
			p = (Preoperatorio) results.get(0);
		}
		return p;
	}
}
