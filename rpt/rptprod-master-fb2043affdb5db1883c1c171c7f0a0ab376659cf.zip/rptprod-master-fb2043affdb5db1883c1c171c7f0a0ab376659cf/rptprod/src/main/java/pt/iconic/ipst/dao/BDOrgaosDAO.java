package pt.iconic.ipst.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import pt.iconic.ipst.modelo.BDOrgaos;


@Repository
public class BDOrgaosDAO {

	
	@PersistenceContext
	private EntityManager manager;
	
	
	public void adiciona(BDOrgaos bdorgaos){
		manager.persist(bdorgaos);	
	}
	
	@Transactional
	public void atualiza(BDOrgaos bdorgaos){
		manager.merge(bdorgaos);
	}
	

/*	@SuppressWarnings("unchecked")
	public List<BDOrgaos> ListaBDOrgaos(){
		return manager.createQuery("select d from BDOrgaos d").getResultList();
	}*/
	
/*	public BDOrgaos buscaPorId(Long id){
		return manager.find(BDOrgaos.class, id);
	}
	
	
	public void remove(BDOrgaos bdorgaos){
		BDOrgaos bdorgaosARemover = buscaPorId(bdorgaos.getId_bdorgaos());
		manager.remove(bdorgaosARemover);
		
	}*/

	@SuppressWarnings("unchecked")
	public BDOrgaos buscabdorgaosdaavaliacao(Long idanalise) {
		
		Query query = manager.createQuery("select b from BDOrgaos b JOIN b.analiseDador a WHERE a.id_AnaliseDador =:idanalise");
		query.setParameter("idanalise", idanalise);
		
		List<BDOrgaos> results = query.getResultList();
		BDOrgaos orgaos = null;
		if(!results.isEmpty()){
			orgaos = (BDOrgaos) results.get(0);
		}
		
		return orgaos;
	}
	

	
	
}
