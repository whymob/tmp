package pt.iconic.ipst.modelo;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name = "MICRORGMBANALISE")
public class Microrgmbanalisemb {

	
	private Long id_microrgmbanalisemb;
	private MBAnalises mbAnalises;
	private Microorganismos microrganismo;
	private List<SensMicroorganalise> sensibilidades;
	private boolean valor;
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="ID_MICRORGMBANALISE")
	public Long getId_microrgmbanalisemb() {
		return id_microrgmbanalisemb;
	}
	public void setId_microrgmbanalisemb(Long id_microrgmbanalisemb) {
		this.id_microrgmbanalisemb = id_microrgmbanalisemb;
	}

	
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "ID_MBANALISES")
	public MBAnalises getMbAnalises() {
		return mbAnalises;
	}
	public void setMbAnalises(MBAnalises mbAnalises) {
		this.mbAnalises = mbAnalises;
	}
	
	@OneToOne(fetch=FetchType.EAGER)
    @JoinColumn(name = "ID_MICRORGANISMO")
    public Microorganismos getMicrorganismo() {
		return microrganismo;
	}
	public void setMicrorganismo(Microorganismos microrganismo) {
		this.microrganismo = microrganismo;
	}
	
	@OneToMany(fetch = FetchType.LAZY, mappedBy = "microrganismoanalise", cascade=CascadeType.REMOVE)
	public List<SensMicroorganalise> getSensibilidades() {
		return sensibilidades;
	}
	
	public void setSensibilidades(List<SensMicroorganalise> sensibilidades) {
		this.sensibilidades = sensibilidades;
	}
	
	@Column(name="VALOR")
	public boolean isValor() {
		return valor;
	}
	
	public void setValor(boolean valor) {
		this.valor = valor;
	}
}
