package pt.iconic.ipst.modelo;


import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;


@Entity
@Table(name = "UNIDADETRANSP_HOSPITAL")
public class Unidade_Hospital {

	private Long id_unidade_hospital;
	private UnidadeTransplante unidtransp;
	private Hospital hosp;
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="ID_UNIDADE_HOSPITAL")
	public Long getId_unidade_hospital() {
		return id_unidade_hospital;
	}
	public void setId_unidade_hospital(Long id_unidade_hospital) {
		this.id_unidade_hospital = id_unidade_hospital;
	}
	
    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "ID_UNIDADETRANSP")
	public UnidadeTransplante getUnidtransp() {
		return unidtransp;
	}
	public void setUnidtransp(UnidadeTransplante unidtransp) {
		this.unidtransp = unidtransp;
	}
	
    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "ID_HOSPITAL")
	public Hospital getHosp() {
		return hosp;
	}
	public void setHosp(Hospital hosp) {
		this.hosp = hosp;
	}
	
	
	
}
