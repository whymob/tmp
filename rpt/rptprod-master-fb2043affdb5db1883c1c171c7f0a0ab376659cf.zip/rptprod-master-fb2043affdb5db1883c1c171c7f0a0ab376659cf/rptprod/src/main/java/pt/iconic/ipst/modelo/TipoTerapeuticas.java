package pt.iconic.ipst.modelo;

import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name="TIPOTERAPEUTICAS")
public class TipoTerapeuticas {

	
	private Long Id_TipoTerapeuticas;
	private String descricao;
	private List<Terapeuticas> Terapeuticas;
	private UnidadesGeral unidades;
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="ID_TIPOTERAPEUTICAS")
	public Long getId_TipoTerapeuticas() {
		return Id_TipoTerapeuticas;
	}
	public void setId_TipoTerapeuticas(Long id_TipoTerapeuticas) {
		Id_TipoTerapeuticas = id_TipoTerapeuticas;
	}
	
	@Column(name="DESCRICAO")
	public String getDescricao() {
		return descricao;
	}
	public void setDescricao(String descricao) {
		this.descricao = descricao;
	}
	
    @OneToMany(fetch = FetchType.LAZY, mappedBy = "tipoTerapeuticas")
	public List<Terapeuticas> getTerapeuticas() {
		return Terapeuticas;
	}
	public void setTerapeuticas(List<Terapeuticas> terapeuticas) {
		Terapeuticas = terapeuticas;
	}
	
    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "ID_UNIDADES")
	public UnidadesGeral getUnidades() {
		return unidades;
	}
	public void setUnidades(UnidadesGeral unidades) {
		this.unidades = unidades;
	}
	

}
