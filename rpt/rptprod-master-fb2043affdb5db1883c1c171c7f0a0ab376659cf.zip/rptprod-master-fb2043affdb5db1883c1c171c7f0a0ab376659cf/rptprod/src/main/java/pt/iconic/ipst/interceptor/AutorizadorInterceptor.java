package pt.iconic.ipst.interceptor;



import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.web.servlet.handler.HandlerInterceptorAdapter;

public class AutorizadorInterceptor extends HandlerInterceptorAdapter{
	
	public boolean preHandle(HttpServletRequest request,
			HttpServletResponse response,Object controller) throws Exception{
		
		String uri = request.getRequestURI();
		
		if(uri.endsWith("/404") ||
		uri.endsWith("/") ||
		uri.endsWith("loginTipoB") ||
		uri.endsWith("index") ||
		uri.endsWith("efetuaLogin") ||
		uri.endsWith("efetuaLoginB") ||
		uri.endsWith("errorpage") ||
		uri.endsWith("recuperarPass") ||
		uri.endsWith("login") ||
		uri.endsWith("loginB") ||
		uri.contains("resources") ||
		uri.contains("novaPass") ||
		uri.contains("novaPassB") ||
		uri.contains("recuperarNovaPassword") ||
		uri.contains("recuperarNovaPasswordB") ||
		uri.contains("recuperarPass2") ||
		uri.contains("recuperarPassEmail") ||
		uri.contains("gravapassA") ||
		uri.contains("gravapassB") ||
		uri.contains("recuperarpassenviaemail") ||
		uri.contains("recuperarpassenviaemailB") ||
		uri.contains("registouserA") ||	
		uri.contains("registarUserA") ||
		uri.contains("registoUserB") ||	
		uri.contains("registarUserB") ||
		uri.contains("verificaLoginB") ||
		uri.contains("recuperarPasswordEmail")){
		return true;
		}
		
		if(request.getSession().getAttribute("utilizadorLogado") != null) {
			return true;
		}

		response.sendRedirect("login");
		return false;
	
	}

}
