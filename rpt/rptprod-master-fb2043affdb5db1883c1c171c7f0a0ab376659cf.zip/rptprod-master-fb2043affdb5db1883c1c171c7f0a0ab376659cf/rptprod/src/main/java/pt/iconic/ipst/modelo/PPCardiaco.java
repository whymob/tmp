package pt.iconic.ipst.modelo;

import java.util.Calendar;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name = "PPCARDIACO")
public class PPCardiaco 
{
	private Long id_ppcardiaco;
	private AnaliseRecetor analiserecetor;
//	private double pesocardiaco;
//	private int alturacardiaco;
//	private Etnia etniacardiaco;
	private int transfusoescardiaco;
	private int gestacoescardiaco;
	private float imccardiaco;
	private int pertoraxicocardiaco;
	private Calendar ulimatransfusaocardiaco;
//	private boolean hbcardiaco;
//	private boolean hccardiaco;
//	private boolean rhcardiaco;
//	private int abocardiaco;
	private int diagnosticocardiaco;
	private String observacoescardiaco;
	//private boolean retransplantadocardiaco;
	private int tamaxcardiaco;
	private int tamincardiaco;
	private int creatininacardiaco;
	private float bilirrubinacardiaco;
	private Calendar tadatamedicaocardiaco;
	private Calendar creatininadatamedicaocardiaco;
	private Calendar bilirrubinadatamedicaocardiaco;
	private int classefunc;
	private boolean disfrenal;
	private boolean disfhepat;
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="ID_PPCARDIACO")
	public Long getId_ppcardiaco() {
		return id_ppcardiaco;
	}
	public void setId_ppcardiaco(Long id_ppcardiaco) {
		this.id_ppcardiaco = id_ppcardiaco;
	}
	
	@OneToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="ID_ANALISERECETOR")
	public AnaliseRecetor getAnaliserecetor() {
		return analiserecetor;
	}
	public void setAnaliserecetor(AnaliseRecetor analiserecetor) {
		this.analiserecetor = analiserecetor;
	}
	
//	@Column(name="PESO")
//	public double getPesocardiaco() {
//		return pesocardiaco;
//	}
//	public void setPesocardiaco(double pesocardiaco) {
//		this.pesocardiaco = pesocardiaco;
//	}
//	
//	@Column(name="ALTURA")
//	public int getAlturacardiaco() {
//		return alturacardiaco;
//	}
//	public void setAlturacardiaco(int alturacardiaco) {
//		this.alturacardiaco = alturacardiaco;
//	}
//	
//	@OneToOne(fetch = FetchType.EAGER)
//    @JoinColumn(name = "ID_ETNIA")
//	public Etnia getEtniacardiaco() {
//		return etniacardiaco;
//	}
//	public void setEtniacardiaco(Etnia etniacardiaco) {
//		this.etniacardiaco = etniacardiaco;
//	}
	
	@Column(name="TRANSFUSOES")
	public int getTransfusoescardiaco() {
		return transfusoescardiaco;
	}
	public void setTransfusoescardiaco(int transfusoescardiaco) {
		this.transfusoescardiaco = transfusoescardiaco;
	}
	
	@Column(name="GESTACOES")
	public int getGestacoescardiaco() {
		return gestacoescardiaco;
	}
	public void setGestacoescardiaco(int gestacoescardiaco) {
		this.gestacoescardiaco = gestacoescardiaco;
	}
	
	@Column(name="IMC")
	public float getImccardiaco() {
		return imccardiaco;
	}
	public void setImccardiaco(float imccardiaco) {
		this.imccardiaco = imccardiaco;
	}
	
	@Column(name="PERTORAXICO")
	public int getPertoraxicocardiaco() {
		return pertoraxicocardiaco;
	}
	public void setPertoraxicocardiaco(int pertoraxicocardiaco) {
		this.pertoraxicocardiaco = pertoraxicocardiaco;
	}
	
	@Column(name="ULTIMATRANSFUSAO")
	public Calendar getUlimatransfusaocardiaco() {
		return ulimatransfusaocardiaco;
	}
	public void setUlimatransfusaocardiaco(Calendar ulimatransfusaocardiaco) {
		this.ulimatransfusaocardiaco = ulimatransfusaocardiaco;
	}
	
//	@Column(name="HB")
//	public boolean isHbcardiaco() {
//		return hbcardiaco;
//	}
//	public void setHbcardiaco(boolean hbcardiaco) {
//		this.hbcardiaco = hbcardiaco;
//	}
//	
//	@Column(name="HC")
//	public boolean isHccardiaco() {
//		return hccardiaco;
//	}
//	public void setHccardiaco(boolean hccardiaco) {
//		this.hccardiaco = hccardiaco;
//	}
	
//	@Column(name="RH")
//	public boolean isRhcardiaco() {
//		return rhcardiaco;
//	}
//	public void setRhcardiaco(boolean rhcardiaco) {
//		this.rhcardiaco = rhcardiaco;
//	}
//	
//	@Column(name="ABO")
//	public int getAbocardiaco() {
//		return abocardiaco;
//	}
//	public void setAbocardiaco(int abocardiaco) {
//		this.abocardiaco = abocardiaco;
//	}
	
	@Column(name="DIAGNOSTICO")
	public int getDiagnosticocardiaco() {
		return diagnosticocardiaco;
	}
	public void setDiagnosticocardiaco(int diagnosticocardiaco) {
		this.diagnosticocardiaco = diagnosticocardiaco;
	}
	
	@Column(name="OBSERVACOES")
	public String getObservacoescardiaco() {
		return observacoescardiaco;
	}
	public void setObservacoescardiaco(String observacoescardiaco) {
		this.observacoescardiaco = observacoescardiaco;
	}
	
//	@Column(name="RETRANSPLANTADO")
//	public boolean isRetransplantadocardiaco() {
//		return retransplantadocardiaco;
//	}
//	public void setRetransplantadocardiaco(boolean retransplantadocardiaco) {
//		this.retransplantadocardiaco = retransplantadocardiaco;
//	}
	
	@Column(name="TAMAX")
	public int getTamaxcardiaco() {
		return tamaxcardiaco;
	}
	public void setTamaxcardiaco(int tamaxcardiaco) {
		this.tamaxcardiaco = tamaxcardiaco;
	}
	
	@Column(name="TAMIN")
	public int getTamincardiaco() {
		return tamincardiaco;
	}
	public void setTamincardiaco(int tamincardiaco) {
		this.tamincardiaco = tamincardiaco;
	}
	
	@Column(name="CREATININA")
	public int getCreatininacardiaco() {
		return creatininacardiaco;
	}
	public void setCreatininacardiaco(int creatininacardiaco) {
		this.creatininacardiaco = creatininacardiaco;
	}
	
	@Column(name="BILIRRUBINA")
	public float getBilirrubinacardiaco() {
		return bilirrubinacardiaco;
	}
	public void setBilirrubinacardiaco(float bilirrubinacardiaco) {
		this.bilirrubinacardiaco = bilirrubinacardiaco;
	}
	
	@Column(name="TADATA")
	public Calendar getTadatamedicaocardiaco() {
		return tadatamedicaocardiaco;
	}
	public void setTadatamedicaocardiaco(Calendar tadatamedicaocardiaco) {
		this.tadatamedicaocardiaco = tadatamedicaocardiaco;
	}
	
	@Column(name="CREATININADATA")
	public Calendar getCreatininadatamedicaocardiaco() {
		return creatininadatamedicaocardiaco;
	}
	public void setCreatininadatamedicaocardiaco(
			Calendar creatininadatamedicaocardiaco) {
		this.creatininadatamedicaocardiaco = creatininadatamedicaocardiaco;
	}
	
	@Column(name="BILIRRUBINADATA")
	public Calendar getBilirrubinadatamedicaocardiaco() {
		return bilirrubinadatamedicaocardiaco;
	}
	public void setBilirrubinadatamedicaocardiaco(
			Calendar bilirrubinadatamedicaocardiaco) {
		this.bilirrubinadatamedicaocardiaco = bilirrubinadatamedicaocardiaco;
	}
	
	@Column(name="CLASSE_FUNCIONAL")
	public int getClassefunc() {
		return classefunc;
	}
	public void setClassefunc(int classefunc) {
		this.classefunc = classefunc;
	}
	
	@Column(name="DISFUNCAO_RENAL")
	public boolean isDisfrenal() {
		return disfrenal;
	}
	public void setDisfrenal(boolean disfrenal) {
		this.disfrenal = disfrenal;
	}
	
	@Column(name="DISFUNCAO_HEPATICA")
	public boolean isDisfhepat() {
		return disfhepat;
	}
	public void setDisfhepat(boolean disfhepat) {
		this.disfhepat = disfhepat;
	}
}
