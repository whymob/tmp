/*package pt.iconic.ipst.dao;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.springframework.stereotype.Repository;

@Repository
public class OrgaoDAO {
	
	@PersistenceContext
	private EntityManager manager;
	
	public void adiciona(Orgaos orgao){
		manager.persist(orgao);	
	}
	
	public void atualiza(Orgaos orgao){
		manager.merge(orgao);
	}
	
	@SuppressWarnings("unchecked")
	public List<Orgaos> ListaOrgaos(){
		return manager.createQuery("select o from Orgaos o").getResultList();
	}
	
	public Orgaos buscaPorId(Long id){
		return manager.find(Orgaos.class, id);
	}
	
	public void remove(Orgaos orgao){
		Orgaos orgaoARemover = buscaPorId(orgao.getId_Orgao());
		manager.remove(orgaoARemover);
	}
	
	@SuppressWarnings("unchecked")
	public List<Orgaos> buscaOrgaosporUnidade(Long iduni)
	{
		Query query = manager.createQuery("select o from Orgaos o JOIN o.unidtransp u WHERE u.id_unidadetransplante =:iduni");
		query.setParameter("iduni", iduni);
		
		List<Orgaos> results = query.getResultList();
		
		return results;
	}
}*/