package pt.iconic.ipst.modelo;

import java.util.Calendar;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name = "ELETROCARDIOGRAMA")
public class Eletrocardiograma 
{
	private Long Id_Eletrocardiograma;
	private Calendar DataExame;
	private boolean Sinoidal;
	private boolean BloqueioAV;
	private boolean ArrAtrial;
	private boolean ArrVentri;
	private int Qtc;
	private int ms;
	private int Qrs;
	private int Stt;
	private int Hipertofia;
	private String Notas;
	private String caminho;
	private String nomedoc;
	private AnaliseDador analiseDador;
	private boolean statusharmecg;
	private Calendar datagravacao;
	
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="ID_ELETROCARDIOGRAMA")
	public Long getId_Eletrocardiograma() {
		return Id_Eletrocardiograma;
	}
	public void setId_Eletrocardiograma(Long id_Eletrocardiograma) {
		Id_Eletrocardiograma = id_Eletrocardiograma;
	}
	
	@Column(name="DATAEAME")
	public Calendar getDataExame() {
		return DataExame;
	}
	public void setDataExame(Calendar dataExame) {
		DataExame = dataExame;
	}

	@Column(name="SINOIDAL")
	public boolean isSinoidal() {
		return Sinoidal;
	}
	public void setSinoidal(boolean sinoidal) {
		Sinoidal = sinoidal;
	}
	
	@Column(name="BLOQUEIOAV")
	public boolean isBloqueioAV() {
		return BloqueioAV;
	}
	public void setBloqueioAV(boolean bloqueioAV) {
		BloqueioAV = bloqueioAV;
	}
	
	@Column(name="ARRATRIAL")
	public boolean isArrAtrial() {
		return ArrAtrial;
	}
	public void setArrAtrial(boolean arrAtrial) {
		ArrAtrial = arrAtrial;
	}
	
	@Column(name="ARRVENTRI")
	public boolean isArrVentri() {
		return ArrVentri;
	}
	public void setArrVentri(boolean arrVentri) {
		ArrVentri = arrVentri;
	}
	
	@Column(name="MS")
	public int getMs() {
		return ms;
	}
	public void setMs(int ms) {
		this.ms = ms;
	}
	
	@Column(name="QRS")
	public int getQrs() {
		return Qrs;
	}
	public void setQrs(int qrs) {
		Qrs = qrs;
	}
	
	@Column(name="STT")
	public int getStt() {
		return Stt;
	}
	public void setStt(int stt) {
		Stt = stt;
	}
	
	@Column(name="HIPERTOFIA")
	public int getHipertofia() {
		return Hipertofia;
	}
	public void setHipertofia(int hipertofia) {
		Hipertofia = hipertofia;
	}
	
	@Column(name="NOTAS")
	public String getNotas() {
		return Notas;
	}
	public void setNotas(String notas) {
		Notas = notas;
	}
	
	@OneToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="ID_ANALISEDADOR")
	public AnaliseDador getAnaliseDador() {
		return analiseDador;
	}
	public void setAnaliseDador(AnaliseDador analiseDador) {
		this.analiseDador = analiseDador;
	}
	
	@Column(name="CAMINHODOC")
	public String getCaminho() {
		return caminho;
	}
	public void setCaminho(String caminho) {
		this.caminho = caminho;
	}
	
	@Column(name="NOMEDOC")
	public String getNomedoc() {
		return nomedoc;
	}
	public void setNomedoc(String nomedoc) {
		this.nomedoc = nomedoc;
	}
	
	@Column(name="QTC")
	public int getQtc() {
		return Qtc;
	}
	public void setQtc(int qtc) {
		Qtc = qtc;
	}
	
	@Column(name="STATUSHARMONIO")
	public boolean isStatusharmecg() {
		return statusharmecg;
	}
	public void setStatusharmecg(boolean statusharmecg) {
		this.statusharmecg = statusharmecg;
	}
	
	@Column(name="DATAGRAVACAO")
	public Calendar getDatagravacao() {
		return datagravacao;
	}


	public void setDatagravacao(Calendar datagravacao) {
		this.datagravacao = datagravacao;
	}
}