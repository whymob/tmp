package pt.iconic.ipst.modelo;

/*
@Entity
@Table(name = "ACTIVIDADE")
public class Actividade {

	
	private Long Id_Actividade;
	private String DescricaoActividade;
	private List<UtilizadorActividade> utilizadores;
	
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="ID_ACTIVIDADE")
	public Long getId_Actividade() {
		return Id_Actividade;
	}
	public void setId_Actividade(Long id_Actividade) {
		Id_Actividade = id_Actividade;
	}
	
	@Column(name="DESCRICAOACTIVIDADE", length = 30)	
	public String getDescricaoActividade() {
		return DescricaoActividade;
	}
	public void setDescricaoActividade(String descricaoActividade) {
		DescricaoActividade = descricaoActividade;
	}
	
    @OneToMany(fetch = FetchType.LAZY, mappedBy = "actividade")
	public List<UtilizadorActividade> getUtilizadores() {
		return utilizadores;
	}
	public void setUtilizadores(List<UtilizadorActividade> utilizadores) {
		this.utilizadores = utilizadores;
	}
	
	
	
	
}
*/
