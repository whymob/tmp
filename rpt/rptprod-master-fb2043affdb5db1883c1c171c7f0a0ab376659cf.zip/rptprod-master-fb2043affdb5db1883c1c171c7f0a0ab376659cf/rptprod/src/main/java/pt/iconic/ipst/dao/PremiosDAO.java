package pt.iconic.ipst.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import pt.iconic.ipst.modelo.Premios;


@Repository
public class PremiosDAO {

	@PersistenceContext
	private EntityManager manager;
	
	@Transactional
	public void adiciona(Premios p){
		manager.persist(p);	
	}
	
	@Transactional
	public void atualiza(Premios p){
		manager.merge(p);
	}

	@SuppressWarnings("unchecked")
	public List<Premios> ListaPremios(){
		return manager.createQuery("select d from Premios d").getResultList();
	}
	
	public Premios buscaPorId(Long id){
		return manager.find(Premios.class, id);
	}
	
/*	public void remove(Premios p){
		Premios prem = buscaPorId(p.getId_premio());
		manager.remove(prem);
	}*/
}
