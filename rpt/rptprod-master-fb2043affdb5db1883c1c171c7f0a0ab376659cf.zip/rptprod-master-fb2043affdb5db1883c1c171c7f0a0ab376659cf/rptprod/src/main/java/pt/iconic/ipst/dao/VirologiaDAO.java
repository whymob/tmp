package pt.iconic.ipst.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import pt.iconic.ipst.modelo.Virologia;

@Repository
public class VirologiaDAO {

	@PersistenceContext
	private EntityManager manager;
	
/*	
	public void adiciona(Virologia virologia){
		manager.persist(virologia);	
	}*/
	
	@Transactional
	public void atualiza(Virologia virologia){
		manager.merge(virologia);
	}
	

/*	@SuppressWarnings("unchecked")
	public List<Virologia> ListaVirologia(){
		return manager.createQuery("select a from Virologia a").getResultList();
	}*/
	
	public Virologia buscaPorId(Long id){
		return manager.find(Virologia.class, id);
	}
	
	
/*	public void remove(Virologia virologia){
		Virologia virologiaARemover = buscaPorId(virologia.getId_virologia());
		manager.remove(virologiaARemover);
		
	}*/
	
	@SuppressWarnings("unchecked")
	public List<Virologia> buscaVirologiaAnalisePretrans(Long idanalise){
		//ESte era quando tinhas as duas an�lises, pr� e p�s transfus�o
//		Query query = manager.createQuery("select b from Virologia b JOIN b.analiseDador a JOIN b.tipoVirologia tipo WHERE a.id_AnaliseDador =:idanalise AND b.prepostransfusao = true ORDER BY tipo.id_tipovirologia");
		Query query = manager.createQuery("select b from Virologia b JOIN b.analiseDador a JOIN b.tipoVirologia tipo WHERE a.id_AnaliseDador =:idanalise ORDER BY tipo.id_tipovirologia");
		query.setParameter("idanalise", idanalise);
		
		List<Virologia> results = query.getResultList();
		
		return results;
	}
	
/*	@SuppressWarnings("unchecked")
	public List<Virologia> buscaVirologiaAnalisePostrans(Long idanalise){
		
		Query query = manager.createQuery("select b from Virologia b JOIN b.analiseDador a JOIN b.tipoVirologia tipo WHERE a.id_AnaliseDador =:idanalise AND b.prepostransfusao = false ORDER BY tipo.id_tipovirologia");
		query.setParameter("idanalise", idanalise);
		
		List<Virologia> results = query.getResultList();
		
		return results;
	}*/
	

	public void carregaamostrasvirologiaanalisepretransf(Long idanalise){
		
	    Query query = manager.createNativeQuery("Insert into Virologia(CSTOBS, CSTRADIO, CSTVALOR, HOSPOBS, HOSPRADIO, HOSPVALOR, PREPOSTRANSFUSAO, "
	    		+ "ID_ANALISEDADOR, ID_TIPOVIROLOGIA) "
	    		+ "select NULL, 1, 0, NULL, 1, 0, 'True', :idanalise , ID_TIPOVIROLOGIA from TIPOVIROLOGIA");
	        query.setParameter("idanalise", idanalise);
	        query.executeUpdate();
	}

//	public void carregaamostrasvirologiaanalisepostransf(Long idanalise) {
//		
//	    Query query = manager.createNativeQuery("Insert into Virologia(CSTOBS, CSTRADIO, CSTVALOR, HOSPOBS, HOSPRADIO, HOSPVALOR, PREPOSTRANSFUSAO, "
//	    		+ "ID_ANALISEDADOR, ID_TIPOVIROLOGIA) "
//	    		+ "select NULL, 1, 0, NULL, 1, 0, 'False', :idanalise , ID_TIPOVIROLOGIA from TIPOVIROLOGIA");
//	        query.setParameter("idanalise", idanalise);
//	        query.executeUpdate();
//	}

	//verifica se a an�lise possui todos os tipo mestre de virologia
	public boolean verificatiposmestreadiciona(Long idanalise) {
	
	    Query query = manager.createNativeQuery("select count(ID_TIPOVIROLOGIA) from TIPOVIROLOGIA where ID_TIPOVIROLOGIA not in (select ID_TIPOVIROLOGIA "
	    		+ "from VIROLOGIA where ID_ANALISEDADOR = :idanalise) ");
	        query.setParameter("idanalise", idanalise);
	        int valor = (int) query.getSingleResult();
		
	        if(valor==0){
	        	return false;
	        }
	        else{
		return true;
	        }
	}

	
	//adicionar tipos de virologia n�o existentes ainda nas virologias prepostransf analise
	@Transactional
	public void adicionavirologiaexistentes(Long idanalise) {
		
		//Este adicionava todas, as pr�-transfus�o e p�s transfus�o como se houvesse duas an�lises
//	    Query query = manager.createNativeQuery("Insert into Virologia(CSTOBS, CSTRADIO, CSTVALOR, HOSPOBS, HOSPRADIO, HOSPVALOR, PREPOSTRANSFUSAO, "
//	    		+ "ID_ANALISEDADOR, ID_TIPOVIROLOGIA) "
//	    		+ "(select NULL, 1, 0, NULL, 1, 0, 'False', :idanalise , ID_TIPOVIROLOGIA "
//	    		+ "from TIPOVIROLOGIA where ID_TIPOVIROLOGIA not in (select ID_TIPOVIROLOGIA "
//	    		+ "from VIROLOGIA where ID_ANALISEDADOR = :idanalise) Union "
//	    		+ "select NULL, 1, 0, NULL, 1, 0, 'True', :idanalise , ID_TIPOVIROLOGIA "
//	    		+ "from TIPOVIROLOGIA where ID_TIPOVIROLOGIA not in (select ID_TIPOVIROLOGIA from VIROLOGIA where ID_ANALISEDADOR = :idanalise))");
		
	    Query query = manager.createNativeQuery("Insert into Virologia(CSTOBS, CSTRADIO, CSTVALOR, HOSPOBS, HOSPRADIO, HOSPVALOR, PREPOSTRANSFUSAO, "
	    		+ "ID_ANALISEDADOR, ID_TIPOVIROLOGIA) "
	    		+ "(select NULL, 1, 0, NULL, 1, 0, 'True', :idanalise , ID_TIPOVIROLOGIA "
	    		+ "from TIPOVIROLOGIA where ID_TIPOVIROLOGIA not in (select ID_TIPOVIROLOGIA "
	    		+ "from VIROLOGIA where ID_ANALISEDADOR = :idanalise))");
	        query.setParameter("idanalise", idanalise);
	        query.executeUpdate();
		
	}

	@Transactional
	public void guardadadosviro(String dados, Long id_analise) {
		
		//criar lista com dados que vieram do cliente
		String str = dados;
    	String delims = "[,]";
    	String[] lista = str.split(delims);
    	boolean tipo = true;
    	
    	
    	
    	for(int i=0; i<lista.length;i++)
    	{
    		String valor = 	lista[i];
    		String delimitador = "[:]";
    		String[] posicao = valor.split(delimitador);



            
    		Virologia viro = buscaPorId(Long.parseLong(posicao[0]));
    		viro.setCstobs(posicao[1]);
    		viro.setCstradio(Integer.parseInt(posicao[2]));
    		viro.setCstvalor(Float.parseFloat(posicao[3]));
    		viro.setHospobs(posicao[4]);
    		viro.setHospradio(Integer.parseInt(posicao[5]));
    		viro.setHospvalor(Float.parseFloat(posicao[6]));
    		viro.setPrepostransfusao(Boolean.parseBoolean(posicao[7]));
    		atualiza(viro);	
    		tipo =Boolean.parseBoolean(posicao[7]);
            
    	}
		//actualiza as transfus�es para pre ou p�s
//    	Query query = manager.createNativeQuery("Update VIROLOGIA set PREPOSTRANSFUSAO=:tipo where ID_ANALISEDADOR= :id_analise");
//    	query.setParameter("tipo", tipo);
//    	query.setParameter("id_analise", id_analise);
//    	query.executeUpdate();
    	actualizatipotransfviro(tipo, id_analise);
    	
	}
	
	@Transactional
	public void actualizatipotransfviro(boolean tipo, Long id_analise){
		
    	Query query = manager.createNativeQuery("Update VIROLOGIA set PREPOSTRANSFUSAO=:tipo where ID_ANALISEDADOR= :id_analise");
    	query.setParameter("tipo", tipo);
    	query.setParameter("id_analise", id_analise);
    	query.executeUpdate();
		
	}

/*	@SuppressWarnings("unchecked")
	public boolean verificastatusharmonioviro(Long id_analise) {
		Query query = manager.createQuery("select b from Virologia b JOIN b.analiseDador a JOIN b.tipoVirologia tipo WHERE a.id_AnaliseDador =:idanalise AND (b.hospvalor >0 OR b.cstvalor>0) ORDER BY tipo.id_tipovirologia");
		query.setParameter("idanalise", id_analise);
		
		List<Virologia> results = query.getResultList();
		if(results.isEmpty()){
		//	System.out.println("n�o existem valores nas virologias");
			return false;
		}else{
		//	System.out.println("Existem valores nas virologias");
		return true;
		}
	}*/
	
	
	//virologias do dador positivas na selec��o de candidato
	@SuppressWarnings("unchecked")
	public List<Virologia> buscaVirologiaSelecaoCandidato(Long idanalise){
		
		Query query = manager.createQuery("select b from Virologia b JOIN b.analiseDador a JOIN b.tipoVirologia tipo WHERE a.id_AnaliseDador =:idanalise AND b.cstradio = 2 ORDER BY tipo.id_tipovirologia");
		query.setParameter("idanalise", idanalise);
		
		List<Virologia> results = query.getResultList();
		
		return results;
	}
	
}
