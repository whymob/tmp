package pt.iconic.ipst.modelo;

import java.util.Calendar;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import org.springframework.format.annotation.DateTimeFormat;

@Entity
@Table(name = "TRANSPLANTE_POS_OP_ANALISES")
public class TransplantePosOperatorioAnalises {

	private Long idtranspposopanalise;
	private Calendar data;
	private AmostrasFO analise;
	private float valor;
	private UnidadesGeral unidades;
	private String obs;
	private AssignacaoOrgaos assigorgao;
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="ID_TRANSP_POS_OP_ANALISE")
	public Long getIdtranspposopanalise() {
		return idtranspposopanalise;
	}
	public void setIdtranspposopanalise(Long idtranspposopanalise) {
		this.idtranspposopanalise = idtranspposopanalise;
	}
	
	@DateTimeFormat(pattern = "dd/MM/yyyy")
	@Column(name="DATA")
	public Calendar getData() {
		return data;
	}
	public void setData(Calendar data) {
		this.data = data;
	}
	
    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "ID_AMOSTRAFO")
	public AmostrasFO getAnalise() {
		return analise;
	}
	public void setAnalise(AmostrasFO analise) {
		this.analise = analise;
	}
	
	@Column(name="VALOR")
	public float getValor() {
		return valor;
	}
	public void setValor(float valor) {
		this.valor = valor;
	}
	
    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "ID_UNIDADES")
	public UnidadesGeral getUnidades() {
		return unidades;
	}
	public void setUnidades(UnidadesGeral unidades) {
		this.unidades = unidades;
	}
	
	@Column(name="OBSERVACOES")
	public String getObs() {
		return obs;
	}
	public void setObs(String obs) {
		this.obs = obs;
	}
	
    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "ID_ASSIGNACAO")
	public AssignacaoOrgaos getAssigorgao() {
		return assigorgao;
	}
	public void setAssigorgao(AssignacaoOrgaos assigorgao) {
		this.assigorgao = assigorgao;
	}
	
	
}
