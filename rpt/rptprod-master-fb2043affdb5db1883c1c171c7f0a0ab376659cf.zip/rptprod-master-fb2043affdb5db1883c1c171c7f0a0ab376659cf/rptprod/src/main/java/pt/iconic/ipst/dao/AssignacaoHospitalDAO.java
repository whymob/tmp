package pt.iconic.ipst.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import pt.iconic.ipst.modelo.AssignacaoHospital;

@Repository
@Transactional
public class AssignacaoHospitalDAO {

	
	@PersistenceContext
	private EntityManager manager;
	
	
	public void adiciona(AssignacaoHospital assignacao){
		manager.persist(assignacao);	
	}
	
	public void atualiza(AssignacaoHospital assignacao){
		manager.merge(assignacao);
	}
	

/*	@SuppressWarnings("unchecked")
	public List<AssignacaoHospital> ListaAssignacaoHospital(){
		return manager.createQuery("select a from AssignacaoHospital a").getResultList();
	}*/
	
	public AssignacaoHospital buscaPorId(Long id){
		return manager.find(AssignacaoHospital.class, id);
	}
	
	
/*	public void remove(AssignacaoHospital assignacao){
		AssignacaoHospital assARemover = buscaPorId(assignacao.getId_assignacaohospital());
		manager.remove(assARemover);
	}*/
	
	@SuppressWarnings( "unchecked")
	public List<Object[]> listaHospitaisAssignOrgao(Long idassignacaoorg, Long unidadetransp){
		
		
	//	System.out.println("idassignacaoorg"+idassignacaoorg+" ,unidadetransp: "+unidadetransp);
		
		List<Object[]> out = null;
		//Antes de ter status de org�o:
/*		String sql = "select ah.ID_ASSIGNACAO_HOSPITAL, ah.ID_ASSIGNACAO_ORGAO, ah.ID_HOSPITAL, h.NOMEHOSPITAL, case ah.SELECCIONADO when 1 then 'true' else 'false' end as SELECCIONADO,"
				+ " est.ESTADO"
				+ " from ASSIGNACAO_HOSPITAL ah inner join HOSPITAL h on (h.ID_HOSPITAL = ah.ID_HOSPITAL)"
				+ " inner join ESTADO_ASSIGNACAO_HOSPITAL est on (est.ID_ESTADO = ah.ID_ESTADO) "
				+ " where ah.ID_ASSIGNACAO_ORGAO = :idassignacaoorg "
				+ "union "
				+ "select null, :idassignacaoorg , h.ID_HOSPITAL, h.NOMEHOSPITAL ,'false', ''"
				+ " from HOSPITAL h inner join UNIDADETRANSP_HOSPITAL uh on (uh.ID_HOSPITAL = h.ID_HOSPITAL) "
				+ "where uh.ID_UNIDADETRANSP=:unidadetransp and h.ID_HOSPITAL not in"
				+ " ( select ah.ID_HOSPITAL from ASSIGNACAO_HOSPITAL ah"
				+ " inner join HOSPITAL h on (h.ID_HOSPITAL = ah.ID_HOSPITAL)"
				+ " where ah.ID_ASSIGNACAO_ORGAO = :idassignacaoorg)";*/
		
		/*String sql = "select ah.ID_ASSIGNACAO_HOSPITAL, ah.ID_ASSIGNACAO_ORGAO, ah.ID_HOSPITAL, h.NOMEHOSPITAL, "
				+ "case ah.SELECCIONADO when 1 then 'true' else 'false' end as SELECCIONADO, "
				+ "est.ESTADO, st.STATUS, "
				+ "(Select  TOP 1 r.NOMERECETOR from RECETOR r "
				+ "inner join HOSPITAL ho on (h.ID_HOSPITAL = r.ID_HOSPITAL) "
				+ "inner join UNIDADETRANSPLANTE ut on (ut.ID_UNIDADETRANSP = r.ID_UNIDADETRANSP) "
				+ "inner join ASSIGNACAO_HOSPITAL ahosp on (h.ID_HOSPITAL = ahosp.ID_HOSPITAL) "
				+ "inner join ASSIGNACAO_ORGAOS ao on (ao.ID_ASSIGNACAO_ORGAOS = ah.ID_ASSIGNACAO_ORGAO) "
				+ "where ho.ID_HOSPITAL = h.ID_HOSPITAL AND ut.ID_UNIDADETRANSP = :unidadetransp AND r.ESTADO=2 AND ahosp.ID_ASSIGNACAO_ORGAO = ah.ID_ASSIGNACAO_ORGAO) "
				+ "from ASSIGNACAO_HOSPITAL ah "
				+ "inner join HOSPITAL h on (h.ID_HOSPITAL = ah.ID_HOSPITAL) "
				+ "inner join ESTADO_ASSIGNACAO_HOSPITAL est on (est.ID_ESTADO = ah.ID_ESTADO) "
				+ "inner join ASSIGNACAO_ORGAOS ao on (ao.ID_ASSIGNACAO_ORGAOS = ah.ID_ASSIGNACAO_ORGAO) "
				+ "inner join STATUS_ASSIGNACAO_ORGAOS st on (st.ID_STATUS = ao.ID_STATUS) "
				+ "where ah.ID_ASSIGNACAO_ORGAO = :idassignacaoorg "
				+ "union "
				+ "select null, :idassignacaoorg , h.ID_HOSPITAL, h.NOMEHOSPITAL ,'false', '', '', '' "
				+ "from HOSPITAL h inner join UNIDADETRANSP_HOSPITAL uh on (uh.ID_HOSPITAL = h.ID_HOSPITAL) "
				+ "left join ASSIGNACAO_HOSPITAL ah on (h.ID_HOSPITAL = ah.ID_HOSPITAL) "
				+ "left join ASSIGNACAO_ORGAOS ao on (ao.ID_ASSIGNACAO_ORGAOS = ah.ID_ASSIGNACAO_ORGAO) "
				+ "where uh.ID_UNIDADETRANSP=:unidadetransp and h.ID_HOSPITAL not in "
				+ "(select ah.ID_HOSPITAL from ASSIGNACAO_HOSPITAL ah "
				+ "inner join HOSPITAL h on (h.ID_HOSPITAL = ah.ID_HOSPITAL) "
				+ "where ah.ID_ASSIGNACAO_ORGAO = :idassignacaoorg)";*/
		
		String sql = "select ah.ID_ASSIGNACAO_HOSPITAL, ah.ID_ASSIGNACAO_ORGAO, ah.ID_HOSPITAL, h.NOMEHOSPITAL, "
				+ "case ah.SELECCIONADO when 1 then 'true' else 'false' end as SELECCIONADO, "
				+ "est.ESTADO, st.STATUS, "
				+ "(select r.NOMERECETOR from ANALISE_RECETOR_TRANSPLANTE art "
				+ "inner join RECETOR r on (r.ID_RECETOR = art.ID_RECETOR) "
				+ "where art.ID_ASSIGORG =:idassignacaoorg and art.ID_ESTADO_ANALISE_RECETOR = 3) "
				+ "from ASSIGNACAO_HOSPITAL ah "
				+ "inner join HOSPITAL h on (h.ID_HOSPITAL = ah.ID_HOSPITAL) "
				+ "inner join ESTADO_ASSIGNACAO_HOSPITAL est on (est.ID_ESTADO = ah.ID_ESTADO) "
				+ "inner join ASSIGNACAO_ORGAOS ao on (ao.ID_ASSIGNACAO_ORGAOS = ah.ID_ASSIGNACAO_ORGAO) "
				+ "inner join STATUS_ASSIGNACAO_ORGAOS st on (st.ID_STATUS = ao.ID_STATUS) "
				+ "where ah.ID_ASSIGNACAO_ORGAO = :idassignacaoorg "
				+ "union "
				+ "select null, :idassignacaoorg , h.ID_HOSPITAL, h.NOMEHOSPITAL ,'false', '', '', '' "
				+ "from HOSPITAL h inner join UNIDADETRANSP_HOSPITAL uh on (uh.ID_HOSPITAL = h.ID_HOSPITAL) "
				+ "left join ASSIGNACAO_HOSPITAL ah on (h.ID_HOSPITAL = ah.ID_HOSPITAL) "
				+ "left join ASSIGNACAO_ORGAOS ao on (ao.ID_ASSIGNACAO_ORGAOS = ah.ID_ASSIGNACAO_ORGAO) "
				+ "where uh.ID_UNIDADETRANSP=:unidadetransp and h.ID_HOSPITAL not in "
				+ "(select ah.ID_HOSPITAL from ASSIGNACAO_HOSPITAL ah "
				+ "inner join HOSPITAL h on (h.ID_HOSPITAL = ah.ID_HOSPITAL) "
				+ "where ah.ID_ASSIGNACAO_ORGAO = :idassignacaoorg)";
		
		

		Query query = manager.createNativeQuery(sql);
		query.setParameter("idassignacaoorg", idassignacaoorg);
		query.setParameter("unidadetransp", unidadetransp);
		
		out = query.getResultList();
//		int count = 0;  
//		for (Iterator i = out.iterator(); i.hasNext();) {  
//		    Object[] values = (Object[]) i.next();  
//		    System.out.println(++count + ": " + values[0] + ", " + values[1] + " ," + values[2] +"," + values[3] + " ," + values[4] + " ," + values[5] + "<br />");  
//
//		}

		
		return out;
	}
	
	public void alteraestadoassighospitalorgao(Long idassignacaoorg, int estado){
		
		Query query = manager.createNativeQuery("UPDATE A "
				+ "SET A.ID_ESTADO = :estado "
				+ "FROM ASSIGNACAO_HOSPITAL A "
				+ "INNER JOIN ASSIGNACAO_ORGAOS ao ON ao.ID_ASSIGNACAO_ORGAOS = A.ID_ASSIGNACAO_ORGAO "
				+ "WHERE ao.ID_ASSIGNACAO_ORGAOS = :idassignacaoorg AND A.SELECCIONADO='True'");	
		query.setParameter("idassignacaoorg", idassignacaoorg);
		query.setParameter("estado", estado);
		query.executeUpdate();
	//	System.out.println(updateCount+" linhas actualizadas");
	}

	public void atualizacaoaceitacaoorgao(Long id_assigorg, Long id_Hospital, int estado) {
		
		Query query = manager.createNativeQuery("UPDATE A "
				+ "SET A.ID_ESTADO = :estado "
				+ "FROM ASSIGNACAO_HOSPITAL A "
				+ "INNER JOIN ASSIGNACAO_ORGAOS ao ON ao.ID_ASSIGNACAO_ORGAOS = A.ID_ASSIGNACAO_ORGAO "
				+ "WHERE ao.ID_ASSIGNACAO_ORGAOS = :idassignacaoorg AND A.ID_HOSPITAL= :id_Hospital");	
		query.setParameter("estado", estado);
		query.setParameter("idassignacaoorg", id_assigorg);
		query.setParameter("id_Hospital", id_Hospital);
		query.executeUpdate();
	}
	
	
	@SuppressWarnings("unchecked")
	public AssignacaoHospital buscaassighosporgaohospital(Long id_assigorg, Long id_Hospital){
		
		Query query = manager.createQuery("select a from AssignacaoHospital a "
				+ "join a.hospital hosp join a.assignacaoorgao assigorg "
				+ "where assigorg.id_assignacao = :idassignacaoorg and hosp.id_Hospital= :id_Hospital");	
		query.setParameter("idassignacaoorg", id_assigorg);
		query.setParameter("id_Hospital", id_Hospital);
		
		List<AssignacaoHospital> results = query.getResultList();
		AssignacaoHospital assighosp = null;
		
		if(!results.isEmpty()){
			assighosp = (AssignacaoHospital) results.get(0);
		}
		return assighosp;
		
	}

	public void rejeitaosoutroshospitais(Long id_assigorg, Long id_Hospital) {
		Query query = manager.createNativeQuery("UPDATE A "
				+ "SET A.ID_ESTADO = :estado "
				+ "FROM ASSIGNACAO_HOSPITAL A "
				+ "INNER JOIN ASSIGNACAO_ORGAOS ao ON ao.ID_ASSIGNACAO_ORGAOS = A.ID_ASSIGNACAO_ORGAO "
				+ "WHERE ao.ID_ASSIGNACAO_ORGAOS = :idassignacaoorg AND A.ID_HOSPITAL<> :id_Hospital");	
		query.setParameter("estado", 7);
		query.setParameter("idassignacaoorg", id_assigorg);
		query.setParameter("id_Hospital", id_Hospital);
		query.executeUpdate();
		
	}
	
}
