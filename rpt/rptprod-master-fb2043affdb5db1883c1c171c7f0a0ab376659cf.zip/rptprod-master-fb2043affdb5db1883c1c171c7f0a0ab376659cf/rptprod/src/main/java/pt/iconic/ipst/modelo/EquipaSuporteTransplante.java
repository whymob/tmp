package pt.iconic.ipst.modelo;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name = "EQUIPA_SUPORTE_TRANSPLANTE")
public class EquipaSuporteTransplante {

	private Long idequipasuporte;
//	private Dador dador;
	private String nome;
	private int ordem;
	private String funcao;
	private String contatos;
	private Utilizador utilizador;
	private AssignacaoOrgaos assigorgao;
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="ID_EQUIPA_SUPORTE")
	public Long getIdequipasuporte() {
		return idequipasuporte;
	}
	public void setIdequipasuporte(Long idequipasuporte) {
		this.idequipasuporte = idequipasuporte;
	}
	
//    @ManyToOne(fetch = FetchType.EAGER)
//    @JoinColumn(name = "ID_DADOR")
//	public Dador getDador() {
//		return dador;
//	}
//	public void setDador(Dador dador) {
//		this.dador = dador;
//	}
	
	@Column(name="NOME")
	public String getNome() {
		return nome;
	}
	public void setNome(String nome) {
		this.nome = nome;
	}
	
	@Column(name="ORDEM")
	public int getOrdem() {
		return ordem;
	}
	public void setOrdem(int ordem) {
		this.ordem = ordem;
	}
	
	@Column(name="FUNCAO")
	public String getFuncao() {
		return funcao;
	}
	public void setFuncao(String funcao) {
		this.funcao = funcao;
	}
	
	@Column(name="CONTATO")
	public String getContatos() {
		return contatos;
	}
	public void setContatos(String contatos) {
		this.contatos = contatos;
	}
	
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "ID_UTILIZADOR")
	public Utilizador getUtilizador() {
		return utilizador;
	}
	public void setUtilizador(Utilizador utilizador) {
		this.utilizador = utilizador;
	}
	
	
    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "ID_ASSIG_ORGAO")
	public AssignacaoOrgaos getAssigorgao() {
		return assigorgao;
	}
	public void setAssigorgao(AssignacaoOrgaos assigorgao) {
		this.assigorgao = assigorgao;
	}
}
