package pt.iconic.ipst.modelo;

import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name="TIPODADOR")
public class TipoDador {

	private Long Id_TipoDador;
	private String Tipo;
	private List<Dador> Dadores;	
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="ID_TIPODADOR")
	public Long getId_TipoDador() {
		return Id_TipoDador;
	}
	public void setId_TipoDador(Long id_TipoDador) {
		Id_TipoDador = id_TipoDador;
	}
	
	@Column(name="TIPO")
	public String getTipo() {
		return Tipo;
	}
	public void setTipo(String tipo) {
		Tipo = tipo;
	}
	
	@OneToMany(fetch = FetchType.LAZY, mappedBy = "tipoDador")
	public List<Dador> getDadores() {
		return Dadores;
	}
	public void setDadores(List<Dador> dadores) {
		Dadores = dadores;
	}
	
}
