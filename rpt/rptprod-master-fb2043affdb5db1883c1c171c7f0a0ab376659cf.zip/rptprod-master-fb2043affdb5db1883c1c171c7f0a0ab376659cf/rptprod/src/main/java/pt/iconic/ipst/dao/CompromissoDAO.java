package pt.iconic.ipst.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import pt.iconic.ipst.modelo.Compromisso;

@Repository
@Transactional
public class CompromissoDAO 
{
	@PersistenceContext
	private EntityManager manager;
	
	public void adiciona(Compromisso comp){
		manager.persist(comp);	
	}

/*	public void atualiza(Compromisso comp){
		manager.merge(comp);
	}*/
	
	@SuppressWarnings("unchecked")
	public List<Compromisso> ListaComprimisso(){
		return manager.createQuery("select a from Compromisso a").getResultList();
	}
	
	public Compromisso buscaPorId(Long id){
		return manager.find(Compromisso.class, id);
	}
	
/*	public void remove(Compromisso comp){
		Compromisso compARemover = buscaPorId(comp.getIdcompromisso());
		manager.remove(compARemover);	
	}*/
}
