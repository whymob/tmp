package pt.iconic.ipst.modelo;

import java.util.Calendar;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;


@Entity
@Table(name = "TRANSPLANTE_FIGADO")
public class TransplanteFigado {

	private Long idtransplantefigado;
	private Calendar inicioanestesia;
	private Calendar iniciocirurgia;
	private Calendar clampAH;
	private Calendar clampVP;
	private Calendar clampVCIH;
	private Calendar clampVCSH;
	private Calendar excisaofigado;
	private Calendar retirargelo;
	private Calendar anastVCSHinicio;
	private Calendar anastVCSHfim;
	private Calendar anastVCIHinicio;
	private Calendar anastVCIHfim;
	private Calendar anastVPinicio;
	private Calendar anastVPfim;
	private Calendar desclampVCSH;
	private Calendar desclampVCIH;
	private Calendar desclampVP;
	private Calendar anastAHinicio;
	private Calendar anastAHfim;
	private Calendar desclampAH;
	private Calendar anastVBinicio;
	private Calendar anastVBfim;
	private Calendar fim;
	private String isqfria;
	private String isqquente;
	private String isqtotal;
	private String clampdescArHep;
	private String clampdescVeiaP;
	private String clampdescVCIH;
	private String clampdescVCSH;
	private String anastArHep;
	private String anastVeiaP;
	private String anastVCIH;
	private String anastVCSH;
	private String anastViaB;
	private int transpfigado;
	private int hepatectomia;
	private int ascite;
	private float volume;
	private int bypass;
	private int anastarterial;
	private int orgtotal;
	private int impltopica;
	private int inplauxiliar;
	private int reconstbiliar;
	private int reclampart;
	private int reclampven;
	private String relatoperat;
	private int complicacoes;
	private int estado;
	private AssignacaoOrgaos assigorgao;
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="ID_TRANSP_FIGADO")
	public Long getIdtransplantefigado() {
		return idtransplantefigado;
	}
	public void setIdtransplantefigado(Long idtransplantefigado) {
		this.idtransplantefigado = idtransplantefigado;
	}
	
	@Column(name="INICIO_ANESTESIA")
	public Calendar getInicioanestesia() {
		return inicioanestesia;
	}
	public void setInicioanestesia(Calendar inicioanestesia) {
		this.inicioanestesia = inicioanestesia;
	}
	
	@Column(name="INICIO_CIRURGIA")
	public Calendar getIniciocirurgia() {
		return iniciocirurgia;
	}
	public void setIniciocirurgia(Calendar iniciocirurgia) {
		this.iniciocirurgia = iniciocirurgia;
	}
	
	@Column(name="CLAMP_AH")
	public Calendar getClampAH() {
		return clampAH;
	}
	public void setClampAH(Calendar clampAH) {
		this.clampAH = clampAH;
	}
	
	@Column(name="CLAMP_VP")
	public Calendar getClampVP() {
		return clampVP;
	}
	public void setClampVP(Calendar clampVP) {
		this.clampVP = clampVP;
	}
	
	@Column(name="CLAMP_VCIH")
	public Calendar getClampVCIH() {
		return clampVCIH;
	}
	public void setClampVCIH(Calendar clampVCIH) {
		this.clampVCIH = clampVCIH;
	}
	
	@Column(name="CLAMP_VCSH")
	public Calendar getClampVCSH() {
		return clampVCSH;
	}
	public void setClampVCSH(Calendar clampVCSH) {
		this.clampVCSH = clampVCSH;
	}
	
	@Column(name="EXCISAO_FIGADO")
	public Calendar getExcisaofigado() {
		return excisaofigado;
	}
	public void setExcisaofigado(Calendar excisaofigado) {
		this.excisaofigado = excisaofigado;
	}
	
	@Column(name="RETIRAR_GELO")
	public Calendar getRetirargelo() {
		return retirargelo;
	}
	public void setRetirargelo(Calendar retirargelo) {
		this.retirargelo = retirargelo;
	}
	
	@Column(name="INICIO_ANAST_VCSH")
	public Calendar getAnastVCSHinicio() {
		return anastVCSHinicio;
	}
	public void setAnastVCSHinicio(Calendar anastVCSHinicio) {
		this.anastVCSHinicio = anastVCSHinicio;
	}
	
	@Column(name="FIM_ANAST_VCSH")
	public Calendar getAnastVCSHfim() {
		return anastVCSHfim;
	}
	public void setAnastVCSHfim(Calendar anastVCSHfim) {
		this.anastVCSHfim = anastVCSHfim;
	}
	
	@Column(name="INICIO_ANAST_VCIH")
	public Calendar getAnastVCIHinicio() {
		return anastVCIHinicio;
	}
	public void setAnastVCIHinicio(Calendar anastVCIHinicio) {
		this.anastVCIHinicio = anastVCIHinicio;
	}
	
	@Column(name="FIM_ANAST_VCIH")
	public Calendar getAnastVCIHfim() {
		return anastVCIHfim;
	}
	public void setAnastVCIHfim(Calendar anastVCIHfim) {
		this.anastVCIHfim = anastVCIHfim;
	}
	
	@Column(name="INICIO_ANAST_VP")
	public Calendar getAnastVPinicio() {
		return anastVPinicio;
	}
	public void setAnastVPinicio(Calendar anastVPinicio) {
		this.anastVPinicio = anastVPinicio;
	}
	
	@Column(name="FIM_ANAST_VP")
	public Calendar getAnastVPfim() {
		return anastVPfim;
	}
	public void setAnastVPfim(Calendar anastVPfim) {
		this.anastVPfim = anastVPfim;
	}
	
	@Column(name="DESCLAMP_VCSH")
	public Calendar getDesclampVCSH() {
		return desclampVCSH;
	}
	public void setDesclampVCSH(Calendar desclampVCSH) {
		this.desclampVCSH = desclampVCSH;
	}
	
	@Column(name="DESCLAMP_VCIH")
	public Calendar getDesclampVCIH() {
		return desclampVCIH;
	}
	public void setDesclampVCIH(Calendar desclampVCIH) {
		this.desclampVCIH = desclampVCIH;
	}
	
	@Column(name="DESCLAMP_VP")
	public Calendar getDesclampVP() {
		return desclampVP;
	}
	public void setDesclampVP(Calendar desclampVP) {
		this.desclampVP = desclampVP;
	}
	
	@Column(name="INICIO_ANAST_AH")
	public Calendar getAnastAHinicio() {
		return anastAHinicio;
	}
	public void setAnastAHinicio(Calendar anastAHinicio) {
		this.anastAHinicio = anastAHinicio;
	}
	
	@Column(name="FIM_ANAST_AH")
	public Calendar getAnastAHfim() {
		return anastAHfim;
	}
	public void setAnastAHfim(Calendar anastAHfim) {
		this.anastAHfim = anastAHfim;
	}
	
	@Column(name="DESCLAMP_AH")
	public Calendar getDesclampAH() {
		return desclampAH;
	}
	public void setDesclampAH(Calendar desclampAH) {
		this.desclampAH = desclampAH;
	}
	
	@Column(name="INICIO_ANAST_VB")
	public Calendar getAnastVBinicio() {
		return anastVBinicio;
	}
	public void setAnastVBinicio(Calendar anastVBinicio) {
		this.anastVBinicio = anastVBinicio;
	}
	
	@Column(name="FIM_ANAST_VB")
	public Calendar getAnastVBfim() {
		return anastVBfim;
	}
	public void setAnastVBfim(Calendar anastVBfim) {
		this.anastVBfim = anastVBfim;
	}
	
	@Column(name="FIM")
	public Calendar getFim() {
		return fim;
	}
	public void setFim(Calendar fim) {
		this.fim = fim;
	}
	
	@Column(name="ISQUEMIA_FRIA")
	public String getIsqfria() {
		return isqfria;
	}
	public void setIsqfria(String isqfria) {
		this.isqfria = isqfria;
	}
	
	@Column(name="ISQUEMIA_QUENTE")
	public String getIsqquente() {
		return isqquente;
	}
	public void setIsqquente(String isqquente) {
		this.isqquente = isqquente;
	}
	
	@Column(name="ISQUEMIA_TOTAL")
	public String getIsqtotal() {
		return isqtotal;
	}
	public void setIsqtotal(String isqtotal) {
		this.isqtotal = isqtotal;
	}
	
	@Column(name="CLAMP_DESCLAMP_AR_HEP")
	public String getClampdescArHep() {
		return clampdescArHep;
	}
	public void setClampdescArHep(String clampdescArHep) {
		this.clampdescArHep = clampdescArHep;
	}
	
	@Column(name="CLAMP_DESCLAMP_VEIA_P")
	public String getClampdescVeiaP() {
		return clampdescVeiaP;
	}
	public void setClampdescVeiaP(String clampdescVeiaP) {
		this.clampdescVeiaP = clampdescVeiaP;
	}
	
	@Column(name="CLAMP_DESCLAMP_VCIH")
	public String getClampdescVCIH() {
		return clampdescVCIH;
	}
	public void setClampdescVCIH(String clampdescVCIH) {
		this.clampdescVCIH = clampdescVCIH;
	}
	
	@Column(name="CLAMP_DESCLAMP_VCSH")
	public String getClampdescVCSH() {
		return clampdescVCSH;
	}
	public void setClampdescVCSH(String clampdescVCSH) {
		this.clampdescVCSH = clampdescVCSH;
	}
	
	@Column(name="ANAST_AR_HEP")
	public String getAnastArHep() {
		return anastArHep;
	}
	public void setAnastArHep(String anastArHep) {
		this.anastArHep = anastArHep;
	}
	
	@Column(name="ANAST_VEIA_P")
	public String getAnastVeiaP() {
		return anastVeiaP;
	}
	public void setAnastVeiaP(String anastVeiaP) {
		this.anastVeiaP = anastVeiaP;
	}
	
	@Column(name="ANAST_VCIH")
	public String getAnastVCIH() {
		return anastVCIH;
	}
	public void setAnastVCIH(String anastVCIH) {
		this.anastVCIH = anastVCIH;
	}
	
	@Column(name="ANAST_VCSH")
	public String getAnastVCSH() {
		return anastVCSH;
	}
	public void setAnastVCSH(String anastVCSH) {
		this.anastVCSH = anastVCSH;
	}
	
	@Column(name="ANAST_VIA_B")
	public String getAnastViaB() {
		return anastViaB;
	}
	public void setAnastViaB(String anastViaB) {
		this.anastViaB = anastViaB;
	}
	
	@Column(name="TRANSP_FIGADO")
	public int getTranspfigado() {
		return transpfigado;
	}
	public void setTranspfigado(int transpfigado) {
		this.transpfigado = transpfigado;
	}
	
	@Column(name="HEPATECTOMIA")
	public int getHepatectomia() {
		return hepatectomia;
	}
	public void setHepatectomia(int hepatectomia) {
		this.hepatectomia = hepatectomia;
	}
	
	@Column(name="ASCITE")
	public int getAscite() {
		return ascite;
	}
	public void setAscite(int ascite) {
		this.ascite = ascite;
	}
	
	@Column(name="VOLUME")
	public float getVolume() {
		return volume;
	}
	public void setVolume(float volume) {
		this.volume = volume;
	}
	
	@Column(name="BYPASS")
	public int getBypass() {
		return bypass;
	}
	public void setBypass(int bypass) {
		this.bypass = bypass;
	}
	
	@Column(name="ANAST_ARTERIAL")
	public int getAnastarterial() {
		return anastarterial;
	}
	public void setAnastarterial(int anastarterial) {
		this.anastarterial = anastarterial;
	}
	
	@Column(name="ORGAO_TOTAL")
	public int getOrgtotal() {
		return orgtotal;
	}
	public void setOrgtotal(int orgtotal) {
		this.orgtotal = orgtotal;
	}
	
	@Column(name="IMPLANT_TOPICA")
	public int getImpltopica() {
		return impltopica;
	}
	public void setImpltopica(int impltopica) {
		this.impltopica = impltopica;
	}
	
	@Column(name="IMPLANT_AUXILIAR")
	public int getInplauxiliar() {
		return inplauxiliar;
	}
	public void setInplauxiliar(int inplauxiliar) {
		this.inplauxiliar = inplauxiliar;
	}
	
	@Column(name="RECONSTR_BILIAR")
	public int getReconstbiliar() {
		return reconstbiliar;
	}
	public void setReconstbiliar(int reconstbiliar) {
		this.reconstbiliar = reconstbiliar;
	}
	
	@Column(name="RECLAMP_ARTERIAL")
	public int getReclampart() {
		return reclampart;
	}
	public void setReclampart(int reclampart) {
		this.reclampart = reclampart;
	}
	
	@Column(name="RECLAMP_VENOSA")
	public int getReclampven() {
		return reclampven;
	}
	public void setReclampven(int reclampven) {
		this.reclampven = reclampven;
	}
	
	@Column(name="RELATO_OPERATORIO")
	public String getRelatoperat() {
		return relatoperat;
	}
	public void setRelatoperat(String relatoperat) {
		this.relatoperat = relatoperat;
	}
	
	@Column(name="COMPLICACOES")
	public int getComplicacoes() {
		return complicacoes;
	}
	public void setComplicacoes(int complicacoes) {
		this.complicacoes = complicacoes;
	}
	
	@Column(name="ESTADO")
	public int getEstado() {
		return estado;
	}
	public void setEstado(int estado) {
		this.estado = estado;
	}
	
	@OneToOne(fetch=FetchType.EAGER)
	@JoinColumn(name="ID_ASSIGNACAO_ORGAOS")
	public AssignacaoOrgaos getAssigorgao() {
		return assigorgao;
	}
	public void setAssigorgao(AssignacaoOrgaos assigorgao) {
		this.assigorgao = assigorgao;
	}	
}
