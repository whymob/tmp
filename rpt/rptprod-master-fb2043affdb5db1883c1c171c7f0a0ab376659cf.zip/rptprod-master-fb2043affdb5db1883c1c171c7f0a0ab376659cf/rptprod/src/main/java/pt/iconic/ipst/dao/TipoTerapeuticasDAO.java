package pt.iconic.ipst.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import pt.iconic.ipst.modelo.TipoTerapeuticas;
import pt.iconic.ipst.modelo.UnidadesGeral;



@Repository
@Transactional
public class TipoTerapeuticasDAO 
{	
	@PersistenceContext
	private EntityManager manager;
	
	public void adiciona(TipoTerapeuticas tipoterapeuticas){
		manager.persist(tipoterapeuticas);	
	}
	
	public void atualiza(TipoTerapeuticas tipoterapeuticas){
		manager.merge(tipoterapeuticas);
	}

	@SuppressWarnings("unchecked")
	public List<TipoTerapeuticas> ListaTipoTerapeuticas(){
		return manager.createQuery("select t from TipoTerapeuticas t").getResultList();
	}
	
	public TipoTerapeuticas buscaPorId(Long id){
		return manager.find(TipoTerapeuticas.class, id);
	}
	
	public void remove(TipoTerapeuticas tipoterapeuticas){
		TipoTerapeuticas tipoterapeuticasdadorARemover = buscaPorId(tipoterapeuticas.getId_TipoTerapeuticas());
		manager.remove(tipoterapeuticasdadorARemover);
	}
	
	public boolean trataadicionar(String desc, Long combo)
	{
		Query query = manager.createQuery("SELECT t FROM TipoTerapeuticas t WHERE t.descricao =:desc");
		query.setParameter("desc", desc);
		
		if(query.getResultList().isEmpty())
		{
			
			UnidadesGeral unid = new UnidadesGeral();
			unid.setId_unidades(combo);
			
			TipoTerapeuticas terap = new TipoTerapeuticas();
			terap.setDescricao(desc);
			terap.setUnidades(unid);
			adiciona(terap);
			
			return true;
		}
		else
		{
			return false;
		}
	}
	
	public boolean trataalterar(Long id, String desc, Long combo)
	{
		
		UnidadesGeral unid = new UnidadesGeral();
		unid.setId_unidades(combo);
		
		TipoTerapeuticas terap = new TipoTerapeuticas();
		terap.setId_TipoTerapeuticas(id);
		terap.setDescricao(desc);
		terap.setUnidades(unid);
		atualiza(terap);
			
		return true;
	}
	
	public boolean remover(Long id)
	{
		TipoTerapeuticas terap = new TipoTerapeuticas();
		terap = buscaPorId(id);
		remove(terap);
			
		return true;
	}
}