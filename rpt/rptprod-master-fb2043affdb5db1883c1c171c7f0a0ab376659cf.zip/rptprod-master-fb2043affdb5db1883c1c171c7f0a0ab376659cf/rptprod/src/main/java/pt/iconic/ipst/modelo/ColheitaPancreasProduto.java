package pt.iconic.ipst.modelo;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name = "COLHEITA_PANCREAS_PRODUTO")
public class ColheitaPancreasProduto {

	private Long idcolheitapancreasproduto;
	private int produto;
	private String observacoesproduto;
	private AnaliseDador analiseDador;
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="ID_COLHEITA_PANCREAS_PRODUTO")
	public Long getIdcolheitapancreasproduto() {
		return idcolheitapancreasproduto;
	}
	public void setIdcolheitapancreasproduto(Long idcolheitapancreasproduto) {
		this.idcolheitapancreasproduto = idcolheitapancreasproduto;
	}
	
	@Column(name="PRODUTO")
	public int getProduto() {
		return produto;
	}
	public void setProduto(int produto) {
		this.produto = produto;
	}
	
	@Column(name="OBSERVACOES")
	public String getObservacoesproduto() {
		return observacoesproduto;
	}
	public void setObservacoesproduto(String observacoesproduto) {
		this.observacoesproduto = observacoesproduto;
	}
	
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "ID_ANALISE_DADOR")
	public AnaliseDador getAnaliseDador() {
		return analiseDador;
	}
	public void setAnaliseDador(AnaliseDador analiseDador) {
		this.analiseDador = analiseDador;
	}
	
	
	
}
