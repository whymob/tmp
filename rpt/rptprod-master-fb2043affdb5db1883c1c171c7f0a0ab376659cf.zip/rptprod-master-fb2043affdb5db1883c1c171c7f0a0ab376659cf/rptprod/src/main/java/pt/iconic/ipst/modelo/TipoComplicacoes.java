package pt.iconic.ipst.modelo;

import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name = "TIPOCOMPLICACOES")
public class TipoComplicacoes {

	private int idtipocomplicacao;
	private String descricao;
	private List<PPHepaticoComplicacoes> pphepaticocomplicacao;
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="ID_TIPOCOMPLICACAO")
	public int getIdtipocomplicacao() {
		return idtipocomplicacao;
	}
	public void setIdtipocomplicacao(int idtipocomplicacao) {
		this.idtipocomplicacao = idtipocomplicacao;
	}
	
	@Column(name="DESCRICAO")
	public String getDescricao() {
		return descricao;
	}
	public void setDescricao(String descricao) {
		this.descricao = descricao;
	}
	
	@OneToMany(fetch = FetchType.LAZY, mappedBy = "tipocomplicacoes")
	public List<PPHepaticoComplicacoes> getPphepaticocomplicacao() {
		return pphepaticocomplicacao;
	}
	public void setPphepaticocomplicacao(
			List<PPHepaticoComplicacoes> pphepaticocomplicacao) {
		this.pphepaticocomplicacao = pphepaticocomplicacao;
	}
	
	
}
