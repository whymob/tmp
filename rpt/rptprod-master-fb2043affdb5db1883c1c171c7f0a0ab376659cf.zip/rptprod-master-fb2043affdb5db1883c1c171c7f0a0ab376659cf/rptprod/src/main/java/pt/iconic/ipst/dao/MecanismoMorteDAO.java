package pt.iconic.ipst.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import pt.iconic.ipst.modelo.MecanismoMorte;

@Repository
@Transactional
public class MecanismoMorteDAO 
{
	@PersistenceContext
	private EntityManager manager;
	
	
	public void adiciona(MecanismoMorte mecanismomorte){
		manager.persist(mecanismomorte);	
	}
	
	public void atualiza(MecanismoMorte mecanismomorte){
		manager.merge(mecanismomorte);
	}
	
	@SuppressWarnings("unchecked")
	public List<MecanismoMorte> ListaMecanismoMorte(){
		return manager.createQuery("select m from MecanismoMorte m").getResultList();
	}
	
	public MecanismoMorte buscaPorId(Long id){
		return manager.find(MecanismoMorte.class, id);
	}
	
	
	public void remove(MecanismoMorte mecanismomorte){
		MecanismoMorte mecanismomorteARemover = buscaPorId(mecanismomorte.getId_MecanismoMorte());
		manager.remove(mecanismomorteARemover);
	}
	
	public boolean trataadicionar(String desc)
	{
		Query query = manager.createQuery("SELECT e FROM MecanismoMorte e WHERE e.descMecanismoMorte =:desc");
		query.setParameter("desc", desc);
		
		if(query.getResultList().isEmpty())
		{
			MecanismoMorte mecanismo = new MecanismoMorte();
			mecanismo.setDescMecanismoMorte(desc);
			adiciona(mecanismo);
			
			return true;
		}
		else
		{
			return false;
		}
	}
	
	public boolean trataalterar(Long id, String desc)
	{
		MecanismoMorte mecanismo = new MecanismoMorte();
		mecanismo.setId_MecanismoMorte(id);
		mecanismo.setDescMecanismoMorte(desc);
		atualiza(mecanismo);
			
		return true;
	}
	
	public boolean remover(Long id)
	{
		MecanismoMorte mecanismo = new MecanismoMorte();
		mecanismo = buscaPorId(id);
		remove(mecanismo);
			
		return true;
	}
}