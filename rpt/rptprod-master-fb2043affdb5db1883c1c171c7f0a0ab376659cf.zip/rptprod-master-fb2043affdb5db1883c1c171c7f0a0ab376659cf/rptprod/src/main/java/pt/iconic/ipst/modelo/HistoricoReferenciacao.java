package pt.iconic.ipst.modelo;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name = "HISTORICOREFERENCIACAO")
public class HistoricoReferenciacao 
{
	private Long id_referenciacao;
	private String descricao;
	private Date dataregisto;
	private Utilizador utilizador;
	private UtilizadorB utilizadorb;
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="ID_REFERENCIACAO")
	public Long getId_referenciacao() {
		return id_referenciacao;
	}
	public void setId_referenciacao(Long id_referenciacao) {
		this.id_referenciacao = id_referenciacao;
	}
	
	@Column(name="DESCRICAO")
	public String getDescricao() {
		return descricao;
	}
	public void setDescricao(String descricao) {
		this.descricao = descricao;
	}
	
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "ID_UTILIZADOR")
	public Utilizador getUtilizador() {
		return utilizador;
	}
	public void setUtilizador(Utilizador utilizador) {
		this.utilizador = utilizador;
	}
	
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "ID_UTILIZADORB")
	public UtilizadorB getUtilizadorb() {
		return utilizadorb;
	}
	public void setUtilizadorb(UtilizadorB utilizadorb) {
		this.utilizadorb = utilizadorb;
	}
	
	@Column(name="DATAREGISTO")
	public Date getDataregisto() {
		return dataregisto;
	}
	public void setDataregisto(Date dataregisto) {
		this.dataregisto = dataregisto;
		//this.dataregisto = new Date(dataregisto.getTime());
	}
}