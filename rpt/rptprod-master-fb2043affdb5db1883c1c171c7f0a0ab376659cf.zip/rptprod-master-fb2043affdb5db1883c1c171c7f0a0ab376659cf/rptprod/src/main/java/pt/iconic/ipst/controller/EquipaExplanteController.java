package pt.iconic.ipst.controller;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.TimeZone;

import javax.servlet.http.HttpSession;

import org.json.simple.JSONArray;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import pt.iconic.ipst.dao.AnaliseDadorDAO;
import pt.iconic.ipst.dao.AssignacaoHospitalDAO;
import pt.iconic.ipst.dao.AssignacaoOrgaosDAO;
import pt.iconic.ipst.dao.BDAvaliacaoInicialDAO;
import pt.iconic.ipst.dao.BDOrgaosDAO;
import pt.iconic.ipst.dao.CausaMorteDAO;
import pt.iconic.ipst.dao.ColheitaCoracaoDAO;
import pt.iconic.ipst.dao.ColheitaCorneasDAO;
import pt.iconic.ipst.dao.ColheitaFigadoDAO;
import pt.iconic.ipst.dao.ColheitaFigadoPerfusaoDAO;
import pt.iconic.ipst.dao.ColheitaGeralDAO;
import pt.iconic.ipst.dao.ColheitaGeralPerfOrgAbdomDAO;
import pt.iconic.ipst.dao.ColheitaGeralPerfOrgToraxDAO;
import pt.iconic.ipst.dao.ColheitaGeralTerapeuticasDAO;
import pt.iconic.ipst.dao.ColheitaPancreasDAO;
import pt.iconic.ipst.dao.ColheitaPancreasPerfusaoDAO;
import pt.iconic.ipst.dao.ColheitaPancreasProdutoDAO;
import pt.iconic.ipst.dao.ColheitaPeleDAO;
import pt.iconic.ipst.dao.ColheitaPulmoesDAO;
import pt.iconic.ipst.dao.ColheitaPulmoesTratamentoDAO;
import pt.iconic.ipst.dao.ColheitaRinsDAO;
import pt.iconic.ipst.dao.ColheitaRinsPerfusaoDAO;
import pt.iconic.ipst.dao.ColheitaRinsTerapeuticasDAO;
import pt.iconic.ipst.dao.ColheitaTCDAO;
import pt.iconic.ipst.dao.ColheitaTMEDAO;
import pt.iconic.ipst.dao.ColheitaVasosDAO;
import pt.iconic.ipst.dao.DadorDAO;
import pt.iconic.ipst.dao.DadorDetalhesDAO;
import pt.iconic.ipst.dao.EntidadeDAO;
import pt.iconic.ipst.dao.EquipaCirurgiaDAO;
import pt.iconic.ipst.dao.EquipaLocalDAO;
import pt.iconic.ipst.dao.EquipaSuporteDAO;
import pt.iconic.ipst.dao.EtniaDAO;
import pt.iconic.ipst.dao.GCCTColheitaDAO;
import pt.iconic.ipst.dao.GCCTColheitaDetalheDAO;
import pt.iconic.ipst.dao.GlasgowCommaDAO;
import pt.iconic.ipst.dao.HCDoencasPreExistentesDAO;
import pt.iconic.ipst.dao.HCExameFisicoDAO;
import pt.iconic.ipst.dao.HCGeralDAO;
import pt.iconic.ipst.dao.HCSituacoesRiscoDAO;
import pt.iconic.ipst.dao.HistoricoAssignacaoDAO;
import pt.iconic.ipst.dao.HospitalDAO;
import pt.iconic.ipst.dao.MecanismoMorteDAO;
import pt.iconic.ipst.dao.PosOperatorioExplanteDAO;
import pt.iconic.ipst.dao.PosOperatorioTabExplDAO;
import pt.iconic.ipst.dao.QuadrantesDAO;
import pt.iconic.ipst.dao.TransporteEquipaDAO;
import pt.iconic.ipst.dao.UtilizadorDAO;
import pt.iconic.ipst.modelo.AnaliseDador;
import pt.iconic.ipst.modelo.AssignacaoOrgaos;
import pt.iconic.ipst.modelo.BDAvaliacaoInicial;
import pt.iconic.ipst.modelo.BDOrgaos;
import pt.iconic.ipst.modelo.ColheitaCoracao;
import pt.iconic.ipst.modelo.ColheitaCorneas;
import pt.iconic.ipst.modelo.ColheitaFigado;
import pt.iconic.ipst.modelo.ColheitaFigadoPerfusao;
import pt.iconic.ipst.modelo.ColheitaGeral;
import pt.iconic.ipst.modelo.ColheitaGeralPerfOrgAbdom;
import pt.iconic.ipst.modelo.ColheitaGeralPerfOrgTorax;
import pt.iconic.ipst.modelo.ColheitaGeralTerapeuticas;
import pt.iconic.ipst.modelo.ColheitaPancreas;
import pt.iconic.ipst.modelo.ColheitaPancreasPerfusao;
import pt.iconic.ipst.modelo.ColheitaPancreasProduto;
import pt.iconic.ipst.modelo.ColheitaPele;
import pt.iconic.ipst.modelo.ColheitaPulmoes;
import pt.iconic.ipst.modelo.ColheitaPulmoesTratamento;
import pt.iconic.ipst.modelo.ColheitaRins;
import pt.iconic.ipst.modelo.ColheitaRinsPerfusao;
import pt.iconic.ipst.modelo.ColheitaRinsTerapeuticas;
import pt.iconic.ipst.modelo.ColheitaTC;
import pt.iconic.ipst.modelo.ColheitaTME;
import pt.iconic.ipst.modelo.ColheitaVasos;
import pt.iconic.ipst.modelo.Dador;
import pt.iconic.ipst.modelo.Entidade;
import pt.iconic.ipst.modelo.EquipaLocal;
import pt.iconic.ipst.modelo.GCCTColheita;
import pt.iconic.ipst.modelo.GCCTColheitaDetalhe;
import pt.iconic.ipst.modelo.Hospital;
import pt.iconic.ipst.modelo.PosOperatorioExplante;
import pt.iconic.ipst.modelo.PosOperatorioTabExpl;
import pt.iconic.ipst.modelo.Quadrantes;
import pt.iconic.ipst.modelo.StatusAssignacaoOrgaos;

@Controller
public class EquipaExplanteController {

	private DadorDAO daoDador;
	private BDOrgaosDAO daobdorg;
	private GlasgowCommaDAO daoglasg;
	private CausaMorteDAO daocausamorte;
	private MecanismoMorteDAO daomecmorte;
	private EtniaDAO daoetnia;
	private DadorDetalhesDAO daodaddet;
	private BDAvaliacaoInicialDAO daobdavalinicial;
	private AnaliseDadorDAO daoanalisedador;
	private HCExameFisicoDAO daoexamefisico;
	private QuadrantesDAO daoquadrantes;
	private HCGeralDAO daogeral;
	private HCDoencasPreExistentesDAO daodoencaspreex;
	private HCSituacoesRiscoDAO daositrisco;
	private HospitalDAO daohosp;
	private EquipaLocalDAO daoequipalocal;
	private EquipaCirurgiaDAO daoequipacirurgia;
	private UtilizadorDAO daouser;
	private EquipaSuporteDAO daoequipsuporte;
	private AssignacaoOrgaosDAO daoAssigOrg;
	private ColheitaGeralDAO daocolheitageral;
	private ColheitaGeralTerapeuticasDAO daocolheitasgeralterap;
	private ColheitaGeralPerfOrgAbdomDAO daocolheitasgeralperfabdom;
	private ColheitaGeralPerfOrgToraxDAO daocolheitasgeralperftorax;
	private ColheitaRinsDAO daocolheitarins;
	private ColheitaRinsPerfusaoDAO daocolheitaperfrins;
	private ColheitaRinsTerapeuticasDAO daocolheitarinsterap;
	private ColheitaPancreasDAO daocolheitapancreas;
	private ColheitaPancreasPerfusaoDAO daocolheitaperfpancreas;
	private ColheitaPancreasProdutoDAO daocolheitapancreasprod;
	private ColheitaFigadoDAO daocolheitafigado;
	private ColheitaFigadoPerfusaoDAO daocolheitaperffigado;
	private ColheitaCoracaoDAO daocolheitacoracao;
	private ColheitaPulmoesDAO daocolheitapulmoes;
	private ColheitaPulmoesTratamentoDAO daocolheitapulmoestrat;
	private ColheitaCorneasDAO daocolheitacorneas;
	private ColheitaPeleDAO daocolheitapele;
	private ColheitaTCDAO daocolheitatc;
	private ColheitaTMEDAO daocolheitatme;
	private ColheitaVasosDAO daocolheitavasos;
	private PosOperatorioExplanteDAO daoposoperatexplante;
	private PosOperatorioTabExplDAO daoposoptabexpl;
	private AssignacaoHospitalDAO daoAssighosp;
	private HistoricoAssignacaoDAO daohistorico;
	private GCCTColheitaDAO daogcctcolheita;
	private EntidadeDAO daoentidade;
	private GCCTColheitaDetalheDAO daogcctcolheitadetalhe;
	private TransporteEquipaDAO daotranspequipa;
	
	
	@Autowired
	public EquipaExplanteController(DadorDAO daoDador, BDOrgaosDAO daobdorg, GlasgowCommaDAO daoglasg, CausaMorteDAO daocausamorte, MecanismoMorteDAO daomecmorte, EtniaDAO daoetnia , DadorDetalhesDAO daodaddet,
			BDAvaliacaoInicialDAO daobdavalinicial, AnaliseDadorDAO daoanalisedador, HCExameFisicoDAO daoexamefisico , QuadrantesDAO daoquadrantes, HCGeralDAO daogeral,
			HCDoencasPreExistentesDAO daodoencaspreex, HCSituacoesRiscoDAO daositrisco, HospitalDAO daohosp, EquipaLocalDAO daoequipalocal, EquipaCirurgiaDAO daoequipacirurgia, UtilizadorDAO daouser, 
			EquipaSuporteDAO daoequipsuporte, AssignacaoOrgaosDAO daoAssigOrg, ColheitaGeralDAO daocolheitageral, ColheitaGeralTerapeuticasDAO daocolheitasgeralterap, ColheitaGeralPerfOrgAbdomDAO daocolheitasgeralperfabdom, 
			ColheitaGeralPerfOrgToraxDAO daocolheitasgeralperftorax, ColheitaRinsDAO daocolheitarins, ColheitaRinsPerfusaoDAO daocolheitaperfrins, ColheitaRinsTerapeuticasDAO daocolheitarinsterap,
			ColheitaPancreasDAO daocolheitapancreas, ColheitaPancreasPerfusaoDAO daocolheitaperfpancreas, ColheitaPancreasProdutoDAO daocolheitapancreasprod, ColheitaFigadoDAO daocolheitafigado, 
			ColheitaFigadoPerfusaoDAO daocolheitaperffigado, ColheitaCoracaoDAO daocolheitacoracao, ColheitaPulmoesDAO daocolheitapulmoes, ColheitaPulmoesTratamentoDAO daocolheitapulmoestrat, 
			ColheitaCorneasDAO daocolheitacorneas, ColheitaPeleDAO daocolheitapele, ColheitaTCDAO daocolheitatc, ColheitaTMEDAO daocolheitatme, ColheitaVasosDAO daocolheitavasos,
			PosOperatorioExplanteDAO daoposoperatexplante, PosOperatorioTabExplDAO daoposoptabexpl, AssignacaoHospitalDAO daoAssighosp, HistoricoAssignacaoDAO daohistorico,
			GCCTColheitaDetalheDAO daogcctcolheitadetalhe , GCCTColheitaDAO daogcctcolheita, EntidadeDAO daoentidade, TransporteEquipaDAO daotranspequipa) {
		this.daoDador=daoDador;
		this.daobdorg = daobdorg;
		this.daoglasg = daoglasg;
		this.daocausamorte = daocausamorte;
		this.daomecmorte = daomecmorte;
		this.daoetnia = daoetnia;
		this.daodaddet = daodaddet;
		this.daobdavalinicial = daobdavalinicial;
		this.daoanalisedador = daoanalisedador;
		this.daoexamefisico = daoexamefisico;
		this.daoquadrantes = daoquadrantes;
		this.daogeral = daogeral;
		this.daodoencaspreex = daodoencaspreex;
		this.daositrisco = daositrisco;
		this.daohosp = daohosp;
		this.daoequipalocal =daoequipalocal;
		this.daoequipacirurgia = daoequipacirurgia;
		this.daouser =daouser;
		this.daoequipsuporte = daoequipsuporte;
		this.daoAssigOrg = daoAssigOrg;
		this.daocolheitageral = daocolheitageral;
		this.daocolheitasgeralterap = daocolheitasgeralterap;
		this.daocolheitasgeralperfabdom = daocolheitasgeralperfabdom;
		this.daocolheitasgeralperftorax = daocolheitasgeralperftorax;
		this.daocolheitarins = daocolheitarins;
		this.daocolheitaperfrins = daocolheitaperfrins;
		this.daocolheitarinsterap = daocolheitarinsterap;
		this.daocolheitapancreas = daocolheitapancreas;
		this.daocolheitaperfpancreas = daocolheitaperfpancreas;
		this.daocolheitapancreasprod = daocolheitapancreasprod;
		this.daocolheitafigado = daocolheitafigado;
		this.daocolheitaperffigado = daocolheitaperffigado;
		this.daocolheitacoracao = daocolheitacoracao;
		this.daocolheitapulmoes = daocolheitapulmoes;
		this.daocolheitapulmoestrat = daocolheitapulmoestrat;
		this.daocolheitacorneas = daocolheitacorneas;
		this.daocolheitapele = daocolheitapele;
		this.daocolheitatc = daocolheitatc;
		this.daocolheitatme = daocolheitatme;
		this.daocolheitavasos = daocolheitavasos;
		this.daoposoperatexplante = daoposoperatexplante;
		this.daoposoptabexpl = daoposoptabexpl;
		this.daoAssighosp = daoAssighosp;
		this.daohistorico = daohistorico;
		this.daogcctcolheitadetalhe = daogcctcolheitadetalhe;
		this.daogcctcolheita = daogcctcolheita;
		this.daoentidade = daoentidade;
		this.daotranspequipa = daotranspequipa;
	}
	
	@RequestMapping(value="abreexplanteequipaexplante")
	public String abreexplanteequipaexplante(@RequestParam("iddador") Long iddador, @RequestParam("idanalise") Long idanalise, Model model, HttpSession session){
				
		Dador dador = daoDador.buscaPorId(iddador);
		
		AnaliseDador analise = daoanalisedador.buscaAnaliseDoDador(dador.getId_Dador());
		
		session.setAttribute("id_analise", analise.getId_AnaliseDador());
		
		//vari�vel para carregar dados de an�lise dador s� de leitura
		session.setAttribute("leituraescrita", false);

		
		
		//coloca em sessao o dador ofertas
		session.setAttribute("dadoroferta", dador);
		session.setAttribute("dadororgao", dador);
		model.addAttribute("Dador", dador);
		
		
		Long id_analise = (Long)session.getAttribute("id_analise");
		
		model.addAttribute("leituraescrita",false);
		
		model.addAttribute("dador", dador);
		model.addAttribute("glasgowcomma", daoglasg.ListaGlasgowComma());
		model.addAttribute("causademorte", daocausamorte.ListaCausaMorte());
		model.addAttribute("mecanismomorte", daomecmorte.ListaMecanismoMorte());
		BDOrgaos orgaos = daobdorg.buscabdorgaosdaavaliacao(id_analise);
		model.addAttribute("bdorgaos", orgaos);
		model.addAttribute("dadordetalhe", daodaddet.buscadetalhesdador(dador.getId_Dador()));
		model.addAttribute("bdavalinicial", daobdavalinicial.buscaavaliacaoinicial(id_analise));
		model.addAttribute("examefisico", daoexamefisico.buscaexamefisico(id_analise));
		Quadrantes quad = daoquadrantes.buscaquadrantesanalise(id_analise);
		model.addAttribute("quadrantes", quad);
		model.addAttribute("etnia", daoetnia.ListaEtnia());
		model.addAttribute("hcgeral", daogeral.buscageralanalise(id_analise));
		model.addAttribute("doencas", daodoencaspreex.buscaDoencasPreExistentesAvaliacao(id_analise));	
		model.addAttribute("sitrisco", daositrisco.buscaSituacoesRiscoAvaliacao(id_analise));
		
		return "eqexplante/divdetalheexplante";
	}
	
	
	@RequestMapping(value="carregaseparadorequipaeqexplante")
	public String carregaseparadorequipaeqexplante(Model model, HttpSession session){
		
//		Long id_analise = (Long)session.getAttribute("id_analise");
		Dador dador = (Dador)session.getAttribute("dadororgao");
		
		
		if(daoequipalocal.buscaequipalocal(dador.getId_Dador())==null){
		EquipaLocal el = new EquipaLocal();
		el.setDador(dador);
		daoequipalocal.adiciona(el);
		}
		
		model.addAttribute("local",daohosp.ListaHospitais());
		model.addAttribute("el",daoequipalocal.buscaequipalocal(dador.getId_Dador()));
		model.addAttribute("equipacirurgia",daoequipacirurgia.buscaequipacirurgiadador(dador.getId_Dador()));
		model.addAttribute("assignacao", daoAssigOrg.ListaAssignacaoOrgaosDador(dador.getId_Dador()));
		model.addAttribute("cirurgiao", daouser.buscacirurgioes());
		model.addAttribute("equipasuporte",daoequipsuporte.buscaequipacsuportedador(dador.getId_Dador()));
		model.addAttribute("transpequipa",daotranspequipa.buscatranspequipadador(dador.getId_Dador()));
		model.addAttribute("idhospitaluser", session.getAttribute("idlocalizacao"));
		
		//return "eqexplante/divseparadorequipaofertaleitura";
		return "eqexplante/divseparadorequipaexplante";
	}
	
	@RequestMapping(value="carregacolheitadadorcadaver")
	public String carregacolheitadadorcadaver(Model model, HttpSession session){
		
		Long id_analise = (Long)session.getAttribute("id_analise");
		
		//Colheita Geral-----------------------------------------------------------------
		//se n�o existe colheitageral cria
		ColheitaGeral c = daocolheitageral.buscacolheitageralanalise(id_analise);
		if(c==null){
			ColheitaGeral colheita = new ColheitaGeral();
			colheita.setAnaliseDador(daoanalisedador.buscaPorId(id_analise));
			daocolheitageral.adiciona(colheita);
			model.addAttribute("colheita", colheita);
		}else{
			model.addAttribute("colheita", c);
		}

		//Tabela terapeuticas do harmonio geral
		model.addAttribute("terapeuticasgeral", daocolheitasgeralterap.listacolheitageralterapeuticasanalise(id_analise));
		//Tabela perfus�o abdmonial do harmonio geral
		model.addAttribute("perfusao", daocolheitasgeralperfabdom.ListaColheitaGeralPerfOrgAbdomanalise(id_analise));
		//Tabela perfus�o toracica do harmonio geral
		model.addAttribute("perftoracica", daocolheitasgeralperftorax.ListaColheitaGeralPerfOrgToraxanalise(id_analise));
		
		
		//ColheitaRins-------------------------------------------------------------------
		//Se n�o existe colheita rins cria
		ColheitaRins cr = daocolheitarins.buscacolheitaRinsanalise(id_analise);
		if(cr==null){
			ColheitaRins colheitarins = new ColheitaRins();
			colheitarins.setAnaliseDador(daoanalisedador.buscaPorId(id_analise));
			daocolheitarins.adiciona(colheitarins);
			model.addAttribute("colheitarins", colheitarins);
		}else{
			model.addAttribute("colheitarins", cr);
		}
		//tabela perfus�o rins
		//Tabela perfus�o toracica do harmonio geral
		model.addAttribute("rimperfusao", daocolheitaperfrins.ListaColheitaRinsPerfusaoanalise(id_analise));
		
		//tabela terapeuticas rins
		model.addAttribute("terapeuticasrins", daocolheitarinsterap.listacolheitarinsterapeuticasanalise(id_analise));
		
		
		//ColheitaPancreas----------------------------------------------------
		//Se n�o existe colheita pancreas cria
		ColheitaPancreas cp = daocolheitapancreas.buscacolheitaPancreasanalise(id_analise);
		if(cp==null){
			ColheitaPancreas colheitapancreas = new ColheitaPancreas();
			colheitapancreas.setAnaliseDador(daoanalisedador.buscaPorId(id_analise));
			daocolheitapancreas.adiciona(colheitapancreas);
			model.addAttribute("colheitapancreas", colheitapancreas);
		}else{
			model.addAttribute("colheitapancreas", cp);
		}
		//tabela perfus�o pancreas
		//Tabela perfus�o do harmonio pancreas
		model.addAttribute("pancreasperfusao", daocolheitaperfpancreas.ListaColheitaPancreasPerfusaoanalise(id_analise));
		
		//tabela produtos pancreas
		model.addAttribute("produtopancreas", daocolheitapancreasprod.listacolheitapancreasprodutoanalise(id_analise));
		
		
		
		//ColheitaFigado----------------------------------------------------
				//Se n�o existe colheita figado cria
				ColheitaFigado cf = daocolheitafigado.buscacolheitaFigadoanalise(id_analise);
				if(cf==null){
					ColheitaFigado colheitafigado = new ColheitaFigado();
					colheitafigado.setAnaliseDador(daoanalisedador.buscaPorId(id_analise));
					daocolheitafigado.adiciona(colheitafigado);
					model.addAttribute("colheitafigado", colheitafigado);
				}else{
					model.addAttribute("colheitafigado", cf);
				}
				
		//tabela perfus�o figado
		//Tabela perfus�o do harmonio figado
		model.addAttribute("figadoperfusao", daocolheitaperffigado.ListaColheitaFigadoPerfusaoanalise(id_analise));
				
				
		//ColheitaCoracao---------------------------------------------------------------
		//Se n�o existe colheita coracao cria
		ColheitaCoracao cc = daocolheitacoracao.buscacolheitaCoracaoanalise(id_analise);
		if(cc==null){
			ColheitaCoracao colheitacoracao = new ColheitaCoracao();
			colheitacoracao.setAnaliseDador(daoanalisedador.buscaPorId(id_analise));
			daocolheitacoracao.adiciona(colheitacoracao);
			model.addAttribute("colheitacoracao", colheitacoracao);
		}else{
			model.addAttribute("colheitacoracao", cc);
		}
		
		//ColheitaPulmoes---------------------------------------------------------------
		//Se n�o existe colheita pulmoes cria
		ColheitaPulmoes cpul = daocolheitapulmoes.buscacolheitaPulmoesanalise(id_analise);
		if(cpul==null){
			ColheitaPulmoes colheitapulmoes = new ColheitaPulmoes();
			colheitapulmoes.setAnaliseDador(daoanalisedador.buscaPorId(id_analise));
			daocolheitapulmoes.adiciona(colheitapulmoes);
			model.addAttribute("colheitapulmoes", colheitapulmoes);
		}else{
			model.addAttribute("colheitapulmoes", cpul);
		}
		
		//tabela tratamento pulmoes
		model.addAttribute("tratpulmoes", daocolheitapulmoestrat.listacolheitapulmoestratamentoanalise(id_analise));
		
		//ColheitaCorneas---------------------------------------------------------------
				//Se n�o existe colheita corneas cria
				ColheitaCorneas ccorn = daocolheitacorneas.buscacolheitaCorneasanalise(id_analise);
				if(ccorn==null){
					ColheitaCorneas colheitacorneas = new ColheitaCorneas();
					colheitacorneas.setAnaliseDador(daoanalisedador.buscaPorId(id_analise));
					daocolheitacorneas.adiciona(colheitacorneas);
					model.addAttribute("colheitacorneas", colheitacorneas);
				}else{
					model.addAttribute("colheitacorneas", ccorn);
				}

				//ColheitaPele---------------------------------------------------------------
				//Se n�o existe colheita corneas cria
				ColheitaPele cpele = daocolheitapele.buscacolheitaPeleanalise(id_analise);
				if(cpele==null){
					ColheitaPele colheitapele = new ColheitaPele();
					colheitapele.setAnaliseDador(daoanalisedador.buscaPorId(id_analise));
					daocolheitapele.adiciona(colheitapele);
					model.addAttribute("colheitapele", colheitapele);
				}else{
					model.addAttribute("colheitapele", cpele);
				}
				
				//ColheitaTC---------------------------------------------------------------
				//Se n�o existe colheita tc cria
				ColheitaTC ctc = daocolheitatc.buscacolheitaTCanalise(id_analise);
				if(ctc==null){
					ColheitaTC colheitatc = new ColheitaTC();
					colheitatc.setAnaliseDador(daoanalisedador.buscaPorId(id_analise));
					daocolheitatc.adiciona(colheitatc);
					model.addAttribute("colheitatc", colheitatc);
				}else{
					model.addAttribute("colheitatc", ctc);
				}
				
				//ColheitaTME---------------------------------------------------------------
				//Se n�o existe colheita tme cria
				ColheitaTME ctme = daocolheitatme.buscacolheitaTMEanalise(id_analise);
				if(ctme==null){
					ColheitaTME colheitatme = new ColheitaTME();
					colheitatme.setAnaliseDador(daoanalisedador.buscaPorId(id_analise));
					daocolheitatme.adiciona(colheitatme);
					model.addAttribute("colheitatme", colheitatme);
				}else{
					model.addAttribute("colheitatme", ctme);
				}
				
				//ColheitaVasos---------------------------------------------------------------
				//Se n�o existe colheita vasos cria
				ColheitaVasos cvasos = daocolheitavasos.buscacolheitaVasosanalise(id_analise);
				if(cvasos==null){
					ColheitaVasos colheitavasos = new ColheitaVasos();
					colheitavasos.setAnaliseDador(daoanalisedador.buscaPorId(id_analise));
					daocolheitavasos.adiciona(colheitavasos);
					model.addAttribute("colheitavasos", colheitavasos);
				}else{
					model.addAttribute("colheitavasos", cvasos);
				}
				
				//carregar vari�vel da permiss�o de leitura escrita para modulo equipa cirurgica
				boolean transp = (boolean) session.getAttribute("transplante");
				
				if(transp){
					model.addAttribute("leituraescritaeqcirurgica", false);
					
				}else{
				boolean leitesceqcirurgica = (boolean) session.getAttribute("leituraescritaeqcirurgica");
				model.addAttribute("leituraescritaeqcirurgica", leitesceqcirurgica);
				}
				
				Dador d = (Dador) session.getAttribute("dadororgao");
				//listar assig orgaos desse dador
				model.addAttribute("orgaosdador", daoAssigOrg.ListaOrgaosAssignadosDador(d.getId_Dador()));
				
		
		return "eqexplante/divseparadorcolheitadadorcadaver";
	}
	
	
	//registos horas geral
	@SuppressWarnings("unchecked")
	@RequestMapping(value="registahorasgeral")
	@ResponseBody
	public String registahorasgeral(@RequestParam("tipo") int tipo, HttpSession session){

		Long id_analise = (Long)session.getAttribute("id_analise");
		
		Calendar cal = Calendar.getInstance();
		ColheitaGeral c = daocolheitageral.buscacolheitageralanalise(id_analise);
		
		
		if(tipo==1){
			
			c.setIniciogeral(cal);
		//	notificacao colheita iniciada:
			Dador d = daoDador.buscadadoranalise(id_analise);
			Hospital h = daohosp.buscaPorId(d.getHospital().getId_Hospital());
			List<Long> users = daouser.buscausershospitalcolheitainiciada(d.getHospital().getId_Hospital());
			NotificationsController notificacao = new NotificationsController();
			JSONArray perfis = new JSONArray();
			perfis.add("IPST");
/*			perfis.add("GCCT");*/			
			String msg = "Colheita "+d.getCodigoDador()+" iniciada no "+h.getNomeHospital()+".";
			notificacao.envianotificacao(users, 5, perfis, "", msg, d.getCodigoDador(), 2);	
				
		}else if(tipo==2){
			
			c.setClampagemgeral(cal);
			
		}else if(tipo==3){
			
			c.setFimgeral(cal);
			daoDador.mudaestadodadorcolheita(4, id_analise);
//		notificacao colheita terminada:
			Dador d = daoDador.buscadadoranalise(id_analise);
			Hospital h = daohosp.buscaPorId(d.getHospital().getId_Hospital());
			List<Long> users = daouser.buscausershospitalcolheitaterminada(d.getHospital().getId_Hospital(), d.getId_Dador());
			NotificationsController notificacao = new NotificationsController();
			JSONArray perfis = new JSONArray();
/*			perfis.add("GCCT");
			perfis.add("CHD");
			perfis.add("EC");
			perfis.add("ECT");*/	
			perfis.add("IPST");
			String msg = "Colheita "+d.getCodigoDador()+" no "+h.getNomeHospital()+" terminada.";
			notificacao.envianotificacao(users, 6, perfis, "", msg, d.getCodigoDador(), 2);	
		}
		
		daocolheitageral.atualiza(c);
		
		DateFormat dum = new SimpleDateFormat("dd/MM/yyyy HH:mm");
		String date = dum.format(cal.getTime());
		
		if(daocolheitageral.contaCodOrgao(id_analise) > 0)
		{
			if(!daogcctcolheita.existegcctcolheitaanalise(id_analise))
			{
				GCCTColheita gc = new GCCTColheita();
				
				Dador d = daoDador.buscaPorId(daoanalisedador.buscaIdDador(id_analise));
				Hospital h = daohosp.buscaPorId(daoDador.buscaIdHospital(d.getId_Dador()));
				Entidade e = daoentidade.buscaPorId(daohosp.buscaIdEntidade(h.getId_Hospital()));
				ColheitaGeral cg = daocolheitageral.buscacolheitageralanalise(id_analise);
				//MorteCerebral mc = daomortecerebral.buscaMorteCerebralAvaliacao(id_analise);
				BDAvaliacaoInicial av = daobdavalinicial.buscaavaliacaoinicial(id_analise);

				if(av.getEstado()== 1) {
					gc.setAto("Colheita-PCC");
					
				}
				else if(av.getEstado()== 2){
					gc.setAto("Colheita-CP");	
					
				
					gc.setTipo("Tecidos");
					
				}else{
					gc.setAto("Colheita-MC");
					
					if(daocolheitageral.contaCodOrgaoSolidos(id_analise) > 1){
						gc.setTipo("Multi");
					}else{
						gc.setTipo("Simples");
					}
					
				}
				

				gc.setDatacolheita(cg.getFimgeral());
				gc.setEstado(0);
				gc.setCodigodador(d.getCodigoDador());
				gc.setDador(d);
				gc.setHospital(h);
				gc.setEntidade(e);
				gc.setAnaliseDador(daoanalisedador.buscaPorId(id_analise));
				
				daogcctcolheita.adiciona(gc);
				
				if(daocolheitageral.contaCodOrgaoCoracao(id_analise) > 0)
				{
					GCCTColheitaDetalhe gcd = new GCCTColheitaDetalhe();
					
					gcd.setGcctcolheita(gc);
					gcd.setOrgao("Cora��o");
				
					daogcctcolheitadetalhe.adiciona(gcd);
				}
				
				if(daocolheitageral.contaCodOrgaoFigado(id_analise) > 0)
				{
					GCCTColheitaDetalhe gcd = new GCCTColheitaDetalhe();
				
					gcd.setGcctcolheita(gc);
					gcd.setOrgao("F�gado");
				
					daogcctcolheitadetalhe.adiciona(gcd);
				}
				
				if((daocolheitageral.contaCodOrgaoCorneaDir(id_analise) > 0)||(daocolheitageral.contaCodOrgaoCorneaEsq(id_analise) > 0))
				{
					GCCTColheitaDetalhe gcd = new GCCTColheitaDetalhe();
					
					gcd.setGcctcolheita(gc);
					gcd.setOrgao("C�rneas");
				
					daogcctcolheitadetalhe.adiciona(gcd);
				}
				
				
				if(daocolheitageral.contaCodOrgaoPancreas(id_analise) > 0)
				{
					GCCTColheitaDetalhe gcd = new GCCTColheitaDetalhe();
					
					gcd.setGcctcolheita(gc);
					gcd.setOrgao("P�ncreas");
				
					daogcctcolheitadetalhe.adiciona(gcd);
				}
				
				if(daocolheitageral.contaCodOrgaoPele(id_analise) > 0)
				{
					GCCTColheitaDetalhe gcd = new GCCTColheitaDetalhe();
					
					gcd.setGcctcolheita(gc);
					gcd.setOrgao("Pele");
				
					daogcctcolheitadetalhe.adiciona(gcd);
				}
				
				if((daocolheitageral.contaCodOrgaoPulmaoDir(id_analise) > 0)||(daocolheitageral.contaCodOrgaoPulmaoEsq(id_analise) > 0))
				{
					GCCTColheitaDetalhe gcd = new GCCTColheitaDetalhe();
					
					gcd.setGcctcolheita(gc);
					gcd.setOrgao("Pulm�es");
				
					daogcctcolheitadetalhe.adiciona(gcd);
				}
				
				
				if((daocolheitageral.contaCodOrgaoRimDir(id_analise) > 0) || (daocolheitageral.contaCodOrgaoRimEsq(id_analise) > 0))
				{
					GCCTColheitaDetalhe gcd = new GCCTColheitaDetalhe();
					
					gcd.setGcctcolheita(gc);
					gcd.setOrgao("Rins");
				
					daogcctcolheitadetalhe.adiciona(gcd);
				}
				
				
				if(daocolheitageral.contaCodOrgaoTC(id_analise) > 0)
				{
					GCCTColheitaDetalhe gcd = new GCCTColheitaDetalhe();
					
					gcd.setGcctcolheita(gc);
					gcd.setOrgao("TC");
				
					daogcctcolheitadetalhe.adiciona(gcd);
				}
				
				if(daocolheitageral.contaCodOrgaoTME(id_analise) > 0)
				{
					GCCTColheitaDetalhe gcd = new GCCTColheitaDetalhe();
					
					gcd.setGcctcolheita(gc);
					gcd.setOrgao("TME");
				
					daogcctcolheitadetalhe.adiciona(gcd);
				}
				
				if(daocolheitageral.contaCodOrgaoVasos(id_analise) > 0)
				{
					GCCTColheitaDetalhe gcd = new GCCTColheitaDetalhe();
					
					gcd.setGcctcolheita(gc);
					gcd.setOrgao("Vasos");
				
					daogcctcolheitadetalhe.adiciona(gcd);
				}
			}
		}
		
		return date;
	}
	
	//Grava��o harm�nio geral
	@RequestMapping(value="gravacolheitaharmoniogeral")
	@ResponseBody
	public String gravacolheitaharmoniogeral(ColheitaGeral colheita, HttpSession session){

		Long id_analise = (Long)session.getAttribute("id_analise");
		//colheita.setAnaliseDador(daoanalisedador.buscaPorId(id_analise));

		
		
		ColheitaGeral co = daocolheitageral.buscacolheitageralanalise(id_analise);
		colheita.setIniciogeral(co.getIniciogeral());
		colheita.setClampagemgeral(co.getClampagemgeral());
		colheita.setFimgeral(co.getFimgeral());
		
		daocolheitageral.atualiza(colheita);
		
		return "OK";
	}
	
	
	//-----------tabela terapeuticas geral harmonio colheita dados cad�ver----------------------//
	
	
	@RequestMapping(value="adicionaterapeuticaharmoniogeral")
	public String adicionaterapeuticaharmoniogeral(@RequestParam("terapeutica") int terapeutica, @RequestParam("observacaoterap") String observacaoterap, Model model, HttpSession session){

		Long id_analise = (Long)session.getAttribute("id_analise");
		//colheita.setAnaliseDador(daoanalisedador.buscaPorId(id_analise));
		ColheitaGeralTerapeuticas terap = new ColheitaGeralTerapeuticas();
		
		AnaliseDador analise = new AnaliseDador();
		analise.setId_AnaliseDador(id_analise);
		
		terap.setAnaliseDador(analise);
		terap.setTerapeutica(terapeutica);
		terap.setObservacoesterapeutica(observacaoterap);
		
		daocolheitasgeralterap.adiciona(terap);
		
		model.addAttribute("ter", terap);
		return "eqexplante/loads/carregalinhaterapgeral";
	}
	
	
	
	@RequestMapping(value="gravaterapeuticaharmoniogeral")
	public String gravaterapeuticaharmoniogeral(@RequestParam("terapeutica") int terapeutica, @RequestParam("observacaoterap") String observacaoterap, @RequestParam("idcolheitaterap") Long idcolheitaterap, Model model){

		//colheita.setAnaliseDador(daoanalisedador.buscaPorId(id_analise));
		ColheitaGeralTerapeuticas terap = daocolheitasgeralterap.buscaPorId(idcolheitaterap);
		terap.setTerapeutica(terapeutica);
		terap.setObservacoesterapeutica(observacaoterap);
		
		daocolheitasgeralterap.atualiza(terap);
		
		model.addAttribute("ter", terap);
		return "eqexplante/loads/carregalinhaterapgeral";
	}
	
	
	@RequestMapping(value="delterapeutica")
	@ResponseBody
	public void delterapeutica(@RequestParam("idcolheitaterap") Long idcolheitaterap, Model model){

		//colheita.setAnaliseDador(daoanalisedador.buscaPorId(id_analise));
		ColheitaGeralTerapeuticas terap = daocolheitasgeralterap.buscaPorId(idcolheitaterap);

		daocolheitasgeralterap.remove(terap);
	}
	//-----------fim tabela terapeuticas geral harmonio colheita dados cad�ver----------------------//	
	
	//-----------tabela perfus�o abdominal geral harmonio colheita dados cad�ver----------------------//
	
	@RequestMapping(value="adicionaperfabdomharmoniogeral")
	public String adicionaperfabdomharmoniogeral(@RequestParam("perfusao") int perfusao, @RequestParam("tipo") int tipo,  @RequestParam("via") int via, @RequestParam("volume") float volume,
			@RequestParam("inicio") String inicio, @RequestParam("fim") String fim, @RequestParam("qualidade") int qualidade, @RequestParam("lote") String lote, 
			@RequestParam("teste") boolean teste, Model model, HttpSession session) throws ParseException{

		Long id_analise = (Long)session.getAttribute("id_analise");
		//colheita.setAnaliseDador(daoanalisedador.buscaPorId(id_analise));
		ColheitaGeralPerfOrgAbdom perf = new ColheitaGeralPerfOrgAbdom();
		
		AnaliseDador analise = new AnaliseDador();
		analise.setId_AnaliseDador(id_analise);
		
		perf.setAnaliseDador(analise);
		perf.setPerfusao(perfusao);
		perf.setTipo(tipo);
		perf.setVia(via);
		perf.setVolume(volume);
		
		DateFormat df = new SimpleDateFormat("HH:mm");
		Date date = df.parse(inicio);
		Calendar in = Calendar.getInstance();
		in.setTime(date);
		perf.setInicio(in);
		
		Date date2 = df.parse(fim);
		Calendar f = Calendar.getInstance();
		f.setTime(date2);
		perf.setFim(f);
		
		perf.setQualidade(qualidade);
		perf.setLote(lote);
		perf.setTeste(teste);
				
		daocolheitasgeralperfabdom.adiciona(perf);
		
		model.addAttribute("perf", perf);
		return "eqexplante/loads/carregalinhaperfabdomgeral";
	}
	
	
	@RequestMapping(value="gravaperfabdomharmoniogeral")
	public String gravaperfabdomharmoniogeral(@RequestParam("idperfabdom") Long idperfabdom, @RequestParam("perfusao") int perfusao, @RequestParam("tipo") int tipo,  
			@RequestParam("via") int via, @RequestParam("volume") float volume,	@RequestParam("inicio") String inicio, @RequestParam("fim") String fim, 
			@RequestParam("qualidade") int qualidade, @RequestParam("lote") String lote, @RequestParam("teste") boolean teste, Model model) throws ParseException{
		
		//colheita.setAnaliseDador(daoanalisedador.buscaPorId(id_analise));
		ColheitaGeralPerfOrgAbdom perf = daocolheitasgeralperfabdom.buscaPorId(idperfabdom);
		perf.setPerfusao(perfusao);
		perf.setTipo(tipo);
		perf.setVia(via);
		perf.setVolume(volume);
		
		DateFormat df = new SimpleDateFormat("HH:mm");
		Date date = df.parse(inicio);
		Calendar in = Calendar.getInstance();
		in.setTime(date);
		perf.setInicio(in);
		
		Date date2 = df.parse(fim);
		Calendar f = Calendar.getInstance();
		f.setTime(date2);
		perf.setFim(f);
		perf.setQualidade(qualidade);
		perf.setLote(lote);
		perf.setTeste(teste);
		
		daocolheitasgeralperfabdom.atualiza(perf);
		
		model.addAttribute("perf", perf);
		return "eqexplante/loads/carregalinhaperfabdomgeral";
	}
	
	@RequestMapping(value="delperfabdomharmoniogeral")
	@ResponseBody
	public void delperfabdomharmoniogeral(@RequestParam("idperfabdom") Long idperfabdom, Model model){

		//colheita.setAnaliseDador(daoanalisedador.buscaPorId(id_analise));
		ColheitaGeralPerfOrgAbdom perf = daocolheitasgeralperfabdom.buscaPorId(idperfabdom);

		daocolheitasgeralperfabdom.remove(perf);
	}
	
	//-----------Fim tabela perfus�o abdominal geral harmonio colheita dados cad�ver----------------------//
	
	
	//-----------tabela perfus�o toraxica geral harmonio colheita dados cad�ver----------------------//
	
	@RequestMapping(value="adicionaperftoraxharmoniogeral")
	public String adicionaperftoraxharmoniogeral(@RequestParam("perfusao") int perfusao, @RequestParam("tipo") int tipo,  @RequestParam("via") int via, @RequestParam("volume") float volume,
			@RequestParam("inicio") String inicio, @RequestParam("fim") String fim, @RequestParam("qualidade") int qualidade, @RequestParam("lote") String lote, 
			@RequestParam("teste") boolean teste, Model model, HttpSession session) throws ParseException{

		Long id_analise = (Long)session.getAttribute("id_analise");
		//colheita.setAnaliseDador(daoanalisedador.buscaPorId(id_analise));
		ColheitaGeralPerfOrgTorax perf = new ColheitaGeralPerfOrgTorax();
		
		AnaliseDador analise = new AnaliseDador();
		analise.setId_AnaliseDador(id_analise);
		
		perf.setAnaliseDador(analise);
		perf.setPerfusao(perfusao);
		perf.setTipo(tipo);
		perf.setVia(via);
		perf.setVolume(volume);
		
		DateFormat df = new SimpleDateFormat("HH:mm");
		Date date = df.parse(inicio);
		Calendar in = Calendar.getInstance();
		in.setTime(date);
		perf.setInicio(in);
		
		Date date2 = df.parse(fim);
		Calendar f = Calendar.getInstance();
		f.setTime(date2);
		perf.setFim(f);
		
		perf.setQualidade(qualidade);
		perf.setLote(lote);
		perf.setTeste(teste);
				
		daocolheitasgeralperftorax.adiciona(perf);
		
		model.addAttribute("perf", perf);
		return "eqexplante/loads/carregalinhaperftoraxgeral";
	}
	
	
	@RequestMapping(value="gravaperftoraxharmoniogeral")
	public String gravaperftoraxharmoniogeral(@RequestParam("idperftorax") Long idperftorax, @RequestParam("perfusao") int perfusao, @RequestParam("tipo") int tipo,  
			@RequestParam("via") int via, @RequestParam("volume") float volume,	@RequestParam("inicio") String inicio, @RequestParam("fim") String fim, 
			@RequestParam("qualidade") int qualidade, @RequestParam("lote") String lote, @RequestParam("teste") boolean teste, Model model) throws ParseException{
		
		//colheita.setAnaliseDador(daoanalisedador.buscaPorId(id_analise));
		ColheitaGeralPerfOrgTorax perf = daocolheitasgeralperftorax.buscaPorId(idperftorax);
		perf.setPerfusao(perfusao);
		perf.setTipo(tipo);
		perf.setVia(via);
		perf.setVolume(volume);
		
		DateFormat df = new SimpleDateFormat("HH:mm");
		Date date = df.parse(inicio);
		Calendar in = Calendar.getInstance();
		in.setTime(date);
		perf.setInicio(in);
		
		Date date2 = df.parse(fim);
		Calendar f = Calendar.getInstance();
		f.setTime(date2);
		perf.setFim(f);
		perf.setQualidade(qualidade);
		perf.setLote(lote);
		perf.setTeste(teste);
		
		daocolheitasgeralperftorax.atualiza(perf);
		
		model.addAttribute("perf", perf);
		return "eqexplante/loads/carregalinhaperftoraxgeral";
	}
	
	@RequestMapping(value="delperftoraxharmoniogeral")
	@ResponseBody
	public void delperftoraxharmoniogeral(@RequestParam("idperftorax") Long idperftorax, Model model){

		//colheita.setAnaliseDador(daoanalisedador.buscaPorId(id_analise));
		ColheitaGeralPerfOrgTorax perf = daocolheitasgeralperftorax.buscaPorId(idperftorax);

		daocolheitasgeralperftorax.remove(perf);
	}
	
	//-----------tabela perfus�o toraxica geral harmonio colheita dados cad�ver----------------------//	
	
//-------------------HARMONIO COLHEITA RINS-----------------------------------------------------------------------------//
	
	//registos horas rins
	@RequestMapping(value="registahorasrins")
	@ResponseBody
	public String registahorasrins(@RequestParam("tipo") int tipo, HttpSession session){

		Long id_analise = (Long)session.getAttribute("id_analise");
		
		Calendar cal = Calendar.getInstance();
		ColheitaRins cr = daocolheitarins.buscacolheitaRinsanalise(id_analise);
		
		
		if(tipo==1){
			
			cr.setIniciorins(cal);
			
		}else if(tipo==2){
				
			cr.setFimrins(cal);
			
		}
		
		daocolheitarins.atualiza(cr);
		
		DateFormat dum = new SimpleDateFormat("dd/MM/yyyy HH:mm");
		String date = dum.format(cal.getTime());
		
		return date;
	}
	
	
	
	//-------------------------Grava��o harm�nio rins-----------------------------------------------------------//
	@RequestMapping(value="gravacolheitaharmoniorins")
	@ResponseBody
	public String gravacolheitaharmoniorins(ColheitaRins colheita, HttpSession session){

		Long id_analise = (Long)session.getAttribute("id_analise");
		//colheita.setAnaliseDador(daoanalisedador.buscaPorId(id_analise));

		ColheitaRins co = daocolheitarins.buscacolheitaRinsanalise(id_analise);
		colheita.setIniciorins(co.getIniciorins());
		colheita.setFimrins(co.getFimrins());
		colheita.setEstadorimdir(co.getEstadorimdir());
		colheita.setEstadorimesq(co.getEstadorimesq());
		
		daocolheitarins.atualiza(colheita);
		
		return "OK";
	}
	
	
	
	@SuppressWarnings("unchecked")
	@RequestMapping(value="gravacolheitaestadorim")
	@ResponseBody
	public String gravacolheitaestadorim(int lado, int estado, HttpSession session){

		Long id_analise = (Long)session.getAttribute("id_analise");
		//colheita.setAnaliseDador(daoanalisedador.buscaPorId(id_analise));

		ColheitaRins co = daocolheitarins.buscacolheitaRinsanalise(id_analise);
		
		if(lado==1){
		co.setEstadorimesq(estado);
		
		
		
		Dador d = (Dador)session.getAttribute("dadororgao");
		
		actualizacoesestadovalidacaoorgao(8, d.getId_Dador(), estado);
		daocolheitarins.atualiza(co);
		
		
		if(estado==1){
			//notificacao org�o colhido:
				Long idhosp = (Long)session.getAttribute("idlocalizacao");
				List<Long> users = daouser.buscausershospitalorgaocolhidoValidadoNaoValidado(idhosp, d.getId_Dador());
				NotificationsController notificacao = new NotificationsController();
				JSONArray perfis = new JSONArray();
				perfis.add("EC");
				perfis.add("IPST");	
				String msg = "Rim Esquerdo do processo "+ d.getCodigoDador()+" explantado e validado";
				notificacao.envianotificacao(users, 18, perfis, "", msg, d.getCodigoDador(), 2);
			}
			if(estado==3){
			//notificacao org�o n�o validado:
				Long idhosp = (Long)session.getAttribute("idlocalizacao");
				List<Long> users = daouser.buscausershospitalorgaocolhidoValidadoNaoValidado(idhosp, d.getId_Dador());
				NotificationsController notificacao = new NotificationsController();
				JSONArray perfis = new JSONArray();
				perfis.add("EC");
				perfis.add("IPST");	
				String msg = "Rim Esquerdo do processo "+ d.getCodigoDador()+" n�o foi validado";
				notificacao.envianotificacao(users, 19, perfis, "", msg, d.getCodigoDador(), 2);
			}
		}else{
		
		co.setEstadorimdir(estado);
		
		Dador d = (Dador)session.getAttribute("dadororgao");
		
		actualizacoesestadovalidacaoorgao(9, d.getId_Dador(), estado);
		daocolheitarins.atualiza(co);
		
		if(estado==1){
			//notificacao org�o colhido:
				Long idhosp = (Long)session.getAttribute("idlocalizacao");
				List<Long> users = daouser.buscausershospitalorgaocolhidoValidadoNaoValidado(idhosp, d.getId_Dador());
				NotificationsController notificacao = new NotificationsController();
				JSONArray perfis = new JSONArray();
				perfis.add("EC");
				perfis.add("IPST");	
				String msg = "Rim Direito do processo "+ d.getCodigoDador()+" explantado e validado";
				notificacao.envianotificacao(users, 18, perfis, "", msg, d.getCodigoDador(), 2);
			}
			if(estado==3){
			//notificacao org�o n�o validado:
				Long idhosp = (Long)session.getAttribute("idlocalizacao");
				List<Long> users = daouser.buscausershospitalorgaocolhidoValidadoNaoValidado(idhosp, d.getId_Dador());
				NotificationsController notificacao = new NotificationsController();
				JSONArray perfis = new JSONArray();
				perfis.add("EC");
				perfis.add("IPST");	
				String msg = "Rim Direito do processo "+ d.getCodigoDador()+" n�o foi validado";
				notificacao.envianotificacao(users, 19, perfis, "", msg, d.getCodigoDador(), 2);
			}
		}
		
		
		return "OK";
	}
	



//-------------------------------- Inicio Tabela perfus�o rins----------------------------------//


@RequestMapping(value="adicionaperfharmoniorins")
public String adicionaperfharmoniorins(@RequestParam("perfusao") int perfusao, @RequestParam("tipo") int tipo,  @RequestParam("volume") float volume,
		@RequestParam("inicio") String inicio, @RequestParam("fim") String fim, @RequestParam("qualidade") int qualidade, @RequestParam("lote") String lote, 
		@RequestParam("teste") boolean teste, Model model, HttpSession session) throws ParseException{

	Long id_analise = (Long)session.getAttribute("id_analise");
	//colheita.setAnaliseDador(daoanalisedador.buscaPorId(id_analise));
	ColheitaRinsPerfusao perf = new ColheitaRinsPerfusao();
	
	AnaliseDador analise = new AnaliseDador();
	analise.setId_AnaliseDador(id_analise);
	
	perf.setAnaliseDador(analise);
	perf.setPerfusao(perfusao);
	perf.setTipo(tipo);
//	perf.setVia(via);
	perf.setVolume(volume);
	
	DateFormat df = new SimpleDateFormat("HH:mm");
	Date date = df.parse(inicio);
	Calendar in = Calendar.getInstance();
	in.setTime(date);
	perf.setInicio(in);
	
	Date date2 = df.parse(fim);
	Calendar f = Calendar.getInstance();
	f.setTime(date2);
	perf.setFim(f);
	
	perf.setQualidade(qualidade);
	perf.setLote(lote);
	perf.setTeste(teste);
			
	daocolheitaperfrins.adiciona(perf);
	
	model.addAttribute("rimperf", perf);
	return "eqexplante/loads/carregalinhaperfusaorins";
}


@RequestMapping(value="gravaperfharmoniorins")
public String gravaperfharmoniorins(@RequestParam("idperfrins") Long idperfrins, @RequestParam("perfusao") int perfusao, @RequestParam("tipo") int tipo,  
		@RequestParam("volume") float volume,	@RequestParam("inicio") String inicio, @RequestParam("fim") String fim, 
		@RequestParam("qualidade") int qualidade, @RequestParam("lote") String lote, @RequestParam("teste") boolean teste, Model model) throws ParseException{
	
	//colheita.setAnaliseDador(daoanalisedador.buscaPorId(id_analise));
	ColheitaRinsPerfusao perf = daocolheitaperfrins.buscaPorId(idperfrins);
	perf.setPerfusao(perfusao);
	perf.setTipo(tipo);
	//perf.setVia(via);
	perf.setVolume(volume);
	
	DateFormat df = new SimpleDateFormat("HH:mm");
	Date date = df.parse(inicio);
	Calendar in = Calendar.getInstance();
	in.setTime(date);
	perf.setInicio(in);
	
	Date date2 = df.parse(fim);
	Calendar f = Calendar.getInstance();
	f.setTime(date2);
	perf.setFim(f);
	perf.setQualidade(qualidade);
	perf.setLote(lote);
	perf.setTeste(teste);
	
	daocolheitaperfrins.atualiza(perf);
	
	model.addAttribute("rimperf", perf);
	return "eqexplante/loads/carregalinhaperfusaorins";
}

@RequestMapping(value="delperfrins")
@ResponseBody
public void delperfrins(@RequestParam("idperfrins") Long idperfrins, Model model){

	//colheita.setAnaliseDador(daoanalisedador.buscaPorId(id_analise));
	ColheitaRinsPerfusao perf = daocolheitaperfrins.buscaPorId(idperfrins);

	daocolheitaperfrins.remove(perf);
}




//-------------------------------- Fim Tabela perfus�o rins----------------------------------//

//-----------tabela terapeuticas rins harmonio colheita dados cad�ver----------------------//


@RequestMapping(value="adicionaterapeuticaharmoniorins")
public String adicionaterapeuticaharmoniorins(@RequestParam("terapeutica") int terapeutica, @RequestParam("observacaoterap") String observacaoterap, Model model, HttpSession session){

	Long id_analise = (Long)session.getAttribute("id_analise");
	//colheita.setAnaliseDador(daoanalisedador.buscaPorId(id_analise));
	ColheitaRinsTerapeuticas terap = new ColheitaRinsTerapeuticas();
	
	AnaliseDador analise = new AnaliseDador();
	analise.setId_AnaliseDador(id_analise);
	
	terap.setAnaliseDador(analise);
	terap.setTerapeutica(terapeutica);
	terap.setObservacoesterapeutica(observacaoterap);
	
	daocolheitarinsterap.adiciona(terap);
	
	model.addAttribute("teraprins", terap);
	return "eqexplante/loads/carregalinhateraprins";
}



@RequestMapping(value="gravaterapeuticaharmoniorins")
public String gravaterapeuticaharmoniorins(@RequestParam("terapeutica") int terapeutica, @RequestParam("observacaoterap") String observacaoterap, @RequestParam("idcolheitaterap") Long idcolheitaterap, Model model){

	//colheita.setAnaliseDador(daoanalisedador.buscaPorId(id_analise));
	ColheitaRinsTerapeuticas terap = daocolheitarinsterap.buscaPorId(idcolheitaterap);
	terap.setTerapeutica(terapeutica);
	terap.setObservacoesterapeutica(observacaoterap);
	
	daocolheitarinsterap.atualiza(terap);
	
	model.addAttribute("teraprins", terap);
	return "eqexplante/loads/carregalinhateraprins";
}


@RequestMapping(value="delterapeuticarins")
@ResponseBody
public void delterapeuticarins(@RequestParam("idcolheitaterap") Long idcolheitaterap, Model model){

	//colheita.setAnaliseDador(daoanalisedador.buscaPorId(id_analise));
	ColheitaRinsTerapeuticas terap = daocolheitarinsterap.buscaPorId(idcolheitaterap);

	daocolheitarinsterap.remove(terap);
}
//-----------fim tabela terapeuticas geral harmonio colheita dados cad�ver----------------------//	


//------------------------------------------------HARMONIO COLHEITA DADOR CADAVER PANCREAS------------------------------------------------------//


//registos horas geral
@RequestMapping(value="registahoraspancreas")
@ResponseBody
public String registahoraspancreas(@RequestParam("tipo") int tipo, HttpSession session){

	Long id_analise = (Long)session.getAttribute("id_analise");
	
	Calendar cal = Calendar.getInstance();
	ColheitaPancreas cp = daocolheitapancreas.buscacolheitaPancreasanalise(id_analise);
	
	
	if(tipo==1){
		
		cp.setIniciopancreas(cal);
		
	}else if(tipo==2){
			
		cp.setFimpancreas(cal);
		
	}
	
	daocolheitapancreas.atualiza(cp);
	
	DateFormat dum = new SimpleDateFormat("dd/MM/yyyy HH:mm");
	String date = dum.format(cal.getTime());
	
	return date;
}



@RequestMapping(value="gravacolheitaharmoniopancreas")
@ResponseBody
public String gravacolheitaharmoniopancreas(ColheitaPancreas colheita, HttpSession session){

	Long id_analise = (Long)session.getAttribute("id_analise");
	//colheita.setAnaliseDador(daoanalisedador.buscaPorId(id_analise));

	ColheitaPancreas co = daocolheitapancreas.buscacolheitaPancreasanalise(id_analise);
	colheita.setIniciopancreas(co.getIniciopancreas());
	colheita.setFimpancreas(co.getFimpancreas());
	colheita.setEstadopancreas(co.getEstadopancreas());
	
	daocolheitapancreas.atualiza(colheita);
	
	return "OK";
}


@SuppressWarnings("unchecked")
@RequestMapping(value="gravacolheitaestadopancreas")
@ResponseBody
public String gravacolheitaestadopancreas(int estado, HttpSession session){

	Long id_analise = (Long)session.getAttribute("id_analise");
	//colheita.setAnaliseDador(daoanalisedador.buscaPorId(id_analise));

	ColheitaPancreas co = daocolheitapancreas.buscacolheitaPancreasanalise(id_analise);
	co.setEstadopancreas(estado);
	
	Dador d = (Dador)session.getAttribute("dadororgao");
	
	actualizacoesestadovalidacaoorgao(6, d.getId_Dador(), estado);
	
	
	daocolheitapancreas.atualiza(co);
	
	if(estado==1){
	//notificacao org�o colhido:
		Long idhosp = (Long)session.getAttribute("idlocalizacao");
		List<Long> users = daouser.buscausershospitalorgaocolhidoValidadoNaoValidado(idhosp, d.getId_Dador());
		NotificationsController notificacao = new NotificationsController();
		JSONArray perfis = new JSONArray();
		perfis.add("EC");
		perfis.add("IPST");	
		String msg = "P�ncreas do processo "+ d.getCodigoDador()+" explantado e validado";
		notificacao.envianotificacao(users, 18, perfis, "", msg, d.getCodigoDador(), 2);
	}
	if(estado==3){
	//notificacao org�o n�o validado:
		Long idhosp = (Long)session.getAttribute("idlocalizacao");
		List<Long> users = daouser.buscausershospitalorgaocolhidoValidadoNaoValidado(idhosp, d.getId_Dador());
		NotificationsController notificacao = new NotificationsController();
		JSONArray perfis = new JSONArray();
		perfis.add("EC");
		perfis.add("IPST");	
		String msg = "P�ncreas do processo "+ d.getCodigoDador()+" n�o foi validado";
		notificacao.envianotificacao(users, 19, perfis, "", msg, d.getCodigoDador(), 2);
	}
	
	return "OK";
}


//-------------------------------- Inicio Tabela perfus�o pancreas----------------------------------//


@RequestMapping(value="adicionaperfharmoniopancreas")
public String adicionaperfharmoniopancreas(@RequestParam("perfusao") int perfusao, @RequestParam("tipo") int tipo,  @RequestParam("volume") float volume,
		@RequestParam("inicio") String inicio, @RequestParam("fim") String fim, @RequestParam("qualidade") int qualidade, @RequestParam("lote") String lote, 
		@RequestParam("teste") boolean teste, Model model, HttpSession session) throws ParseException{

	Long id_analise = (Long)session.getAttribute("id_analise");
	//colheita.setAnaliseDador(daoanalisedador.buscaPorId(id_analise));
	ColheitaPancreasPerfusao perf = new ColheitaPancreasPerfusao();
	
	AnaliseDador analise = new AnaliseDador();
	analise.setId_AnaliseDador(id_analise);
	
	perf.setAnaliseDador(analise);
	perf.setPerfusao(perfusao);
	perf.setTipo(tipo);
//	perf.setVia(via);
	perf.setVolume(volume);
	
	DateFormat df = new SimpleDateFormat("HH:mm");
	Date date = df.parse(inicio);
	Calendar in = Calendar.getInstance();
	in.setTime(date);
	perf.setInicio(in);
	
	Date date2 = df.parse(fim);
	Calendar f = Calendar.getInstance();
	f.setTime(date2);
	perf.setFim(f);
	
	perf.setQualidade(qualidade);
	perf.setLote(lote);
	perf.setTeste(teste);
			
	daocolheitaperfpancreas.adiciona(perf);
	
	model.addAttribute("pancreasperf", perf);
	return "eqexplante/loads/carregalinhaperfusaopancreas";
}


@RequestMapping(value="gravaperfharmoniopancreas")
public String gravaperfharmoniopancreas(@RequestParam("idperfpancreas") Long idperfpancreas, @RequestParam("perfusao") int perfusao, @RequestParam("tipo") int tipo,  
		@RequestParam("volume") float volume,	@RequestParam("inicio") String inicio, @RequestParam("fim") String fim, 
		@RequestParam("qualidade") int qualidade, @RequestParam("lote") String lote, @RequestParam("teste") boolean teste, Model model) throws ParseException{
	
	//colheita.setAnaliseDador(daoanalisedador.buscaPorId(id_analise));
	ColheitaPancreasPerfusao perf = daocolheitaperfpancreas.buscaPorId(idperfpancreas);
	perf.setPerfusao(perfusao);
	perf.setTipo(tipo);
	//perf.setVia(via);
	perf.setVolume(volume);
	
	DateFormat df = new SimpleDateFormat("HH:mm");
	Date date = df.parse(inicio);
	Calendar in = Calendar.getInstance();
	in.setTime(date);
	perf.setInicio(in);
	
	Date date2 = df.parse(fim);
	Calendar f = Calendar.getInstance();
	f.setTime(date2);
	perf.setFim(f);
	perf.setQualidade(qualidade);
	perf.setLote(lote);
	perf.setTeste(teste);
	
	daocolheitaperfpancreas.atualiza(perf);
	
	model.addAttribute("pancreasperf", perf);
	return "eqexplante/loads/carregalinhaperfusaopancreas";
}

@RequestMapping(value="delperfpancreas")
@ResponseBody
public void delperfpancreas(@RequestParam("idperfpancreas") Long idperfpancreas, Model model){

	//colheita.setAnaliseDador(daoanalisedador.buscaPorId(id_analise));
	ColheitaPancreasPerfusao perf = daocolheitaperfpancreas.buscaPorId(idperfpancreas);

	daocolheitaperfpancreas.remove(perf);
}




//-------------------------------- Fim Tabela perfus�o pancreas----------------------------------//

//-----------tabela produtos pancreas harmonio colheita dados cad�ver----------------------//


@RequestMapping(value="adicionaprodpancreasharmoniopancreas")
public String adicionaprodpancreasharmoniopancreas(@RequestParam("produto") int produto, @RequestParam("observacaoprod") String observacaoprod, Model model, HttpSession session){

	Long id_analise = (Long)session.getAttribute("id_analise");
	//colheita.setAnaliseDador(daoanalisedador.buscaPorId(id_analise));
	ColheitaPancreasProduto prod = new ColheitaPancreasProduto();
	
	AnaliseDador analise = new AnaliseDador();
	analise.setId_AnaliseDador(id_analise);
	
	prod.setAnaliseDador(analise);
	prod.setProduto(produto);
	prod.setObservacoesproduto(observacaoprod);
	
	daocolheitapancreasprod.adiciona(prod);
	
	model.addAttribute("prodpancreas", prod);
	return "eqexplante/loads/carregalinhaprodpancreas";
}



@RequestMapping(value="gravaprodutoharmoniopancreas")
public String gravaprodutoharmoniopancreas(@RequestParam("produto") int produto, @RequestParam("observacaoproduto") String observacaoproduto, @RequestParam("idcolheitaprodpancreas") Long idcolheitaprodpancreas, Model model){

	//colheita.setAnaliseDador(daoanalisedador.buscaPorId(id_analise));
	ColheitaPancreasProduto prod = daocolheitapancreasprod.buscaPorId(idcolheitaprodpancreas);
	prod.setProduto(produto);
	prod.setObservacoesproduto(observacaoproduto);
	
	daocolheitapancreasprod.atualiza(prod);
	
	model.addAttribute("prodpancreas", prod);
	return "eqexplante/loads/carregalinhaprodpancreas";
}


@RequestMapping(value="delprodpancreas")
@ResponseBody
public void delprodpancreas(@RequestParam("idcolheitaprodpancreas") Long idcolheitaprodpancreas, Model model){

	//colheita.setAnaliseDador(daoanalisedador.buscaPorId(id_analise));
	ColheitaPancreasProduto prod = daocolheitapancreasprod.buscaPorId(idcolheitaprodpancreas);

	daocolheitapancreasprod.remove(prod);
}
//-----------fim tabela produtos pancreas harmonio colheita dados cad�ver----------------------//	



//------------------------------------------------HARMONIO COLHEITA DADOR CADAVER FIGADO------------------------------------------------------//

//registos horas figado
@RequestMapping(value="registahorasfigado")
@ResponseBody
public String registahorasfigado(@RequestParam("tipo") int tipo, HttpSession session){

	Long id_analise = (Long)session.getAttribute("id_analise");
	
	Calendar calfig = Calendar.getInstance();
	ColheitaFigado cf = daocolheitafigado.buscacolheitaFigadoanalise(id_analise);
	
	
	if(tipo==1){
		
		cf.setIniciofigado(calfig);;
		
	}else if(tipo==2){
			
		cf.setFimfigado(calfig);
		
	}
	
	daocolheitafigado.atualiza(cf);
	
	DateFormat dum = new SimpleDateFormat("dd/MM/yyyy HH:mm");
	String date = dum.format(calfig.getTime());
	
	return date;
}



@RequestMapping(value="gravacolheitaharmoniofigado")
@ResponseBody
public String gravacolheitaharmoniofigado(ColheitaFigado colheita, HttpSession session){

	Long id_analise = (Long)session.getAttribute("id_analise");
	//colheita.setAnaliseDador(daoanalisedador.buscaPorId(id_analise));

	ColheitaFigado cf = daocolheitafigado.buscacolheitaFigadoanalise(id_analise);
	colheita.setIniciofigado(cf.getIniciofigado());
	colheita.setFimfigado(cf.getFimfigado());
	colheita.setEstadofigado(cf.getEstadofigado());
	
	daocolheitafigado.atualiza(colheita);
	
	return "OK";
}



@SuppressWarnings("unchecked")
@RequestMapping(value="gravacolheitaestadofigado")
@ResponseBody
public String gravacolheitaestadofigado(int estado, HttpSession session){

	Long id_analise = (Long)session.getAttribute("id_analise");
	//colheita.setAnaliseDador(daoanalisedador.buscaPorId(id_analise));

	ColheitaFigado cf = daocolheitafigado.buscacolheitaFigadoanalise(id_analise);
	cf.setEstadofigado(estado);
	
	Dador d = (Dador)session.getAttribute("dadororgao");
	
	actualizacoesestadovalidacaoorgao(2, d.getId_Dador(), estado);
	
	
	daocolheitafigado.atualiza(cf);
	
	if(estado==1){
	//notificacao org�o colhido:
		Long idhosp = (Long)session.getAttribute("idlocalizacao");
		List<Long> users = daouser.buscausershospitalorgaocolhidoValidadoNaoValidado(idhosp, d.getId_Dador());
		NotificationsController notificacao = new NotificationsController();
		JSONArray perfis = new JSONArray();
		perfis.add("EC");
		perfis.add("IPST");	
		String msg = "F�gado do processo "+ d.getCodigoDador()+" explantado e validado";
		notificacao.envianotificacao(users, 18, perfis, "", msg, d.getCodigoDador(), 2);
	}
	if(estado==3){
	//notificacao org�o n�o validado:
		Long idhosp = (Long)session.getAttribute("idlocalizacao");
		List<Long> users = daouser.buscausershospitalorgaocolhidoValidadoNaoValidado(idhosp, d.getId_Dador());
		NotificationsController notificacao = new NotificationsController();
		JSONArray perfis = new JSONArray();
		perfis.add("EC");
		perfis.add("IPST");	
		String msg = "F�gado do processo "+ d.getCodigoDador()+" n�o foi validado";
		notificacao.envianotificacao(users, 19, perfis, "", msg, d.getCodigoDador(), 2);
	}
	
	
	return "OK";
}

//-------------------------------- Inicio Tabela perfus�o figado----------------------------------//


@RequestMapping(value="adicionaperfharmoniofigado")
public String adicionaperfharmoniofigado(@RequestParam("perfusao") int perfusao, @RequestParam("tipo") int tipo,  @RequestParam("volume") float volume,
		@RequestParam("inicio") String inicio, @RequestParam("fim") String fim, @RequestParam("qualidade") int qualidade, @RequestParam("lote") String lote, 
		@RequestParam("teste") boolean teste, Model model, HttpSession session) throws ParseException{

	Long id_analise = (Long)session.getAttribute("id_analise");
	//colheita.setAnaliseDador(daoanalisedador.buscaPorId(id_analise));
	ColheitaFigadoPerfusao perf = new ColheitaFigadoPerfusao();
	
	AnaliseDador analise = new AnaliseDador();
	analise.setId_AnaliseDador(id_analise);
	
	perf.setAnaliseDador(analise);
	perf.setPerfusao(perfusao);
	perf.setTipo(tipo);
//	perf.setVia(via);
	perf.setVolume(volume);
	
	DateFormat df = new SimpleDateFormat("HH:mm");
	Date date = df.parse(inicio);
	Calendar in = Calendar.getInstance();
	in.setTime(date);
	perf.setInicio(in);
	
	Date date2 = df.parse(fim);
	Calendar f = Calendar.getInstance();
	f.setTime(date2);
	perf.setFim(f);
	
	perf.setQualidade(qualidade);
	perf.setLote(lote);
	perf.setTeste(teste);
			
	daocolheitaperffigado.adiciona(perf);
	
	model.addAttribute("figadoperf", perf);
	return "eqexplante/loads/carregalinhaperfusaofigado";
}


@RequestMapping(value="gravaperfharmoniofigado")
public String gravaperfharmoniofigado(@RequestParam("idperffigado") Long idperffigado, @RequestParam("perfusao") int perfusao, @RequestParam("tipo") int tipo,  
		@RequestParam("volume") float volume,	@RequestParam("inicio") String inicio, @RequestParam("fim") String fim, 
		@RequestParam("qualidade") int qualidade, @RequestParam("lote") String lote, @RequestParam("teste") boolean teste, Model model) throws ParseException{
	
	//colheita.setAnaliseDador(daoanalisedador.buscaPorId(id_analise));
	ColheitaFigadoPerfusao perf = daocolheitaperffigado.buscaPorId(idperffigado);
	perf.setPerfusao(perfusao);
	perf.setTipo(tipo);
	//perf.setVia(via);
	perf.setVolume(volume);
	
	DateFormat df = new SimpleDateFormat("HH:mm");
	Date date = df.parse(inicio);
	Calendar in = Calendar.getInstance();
	in.setTime(date);
	perf.setInicio(in);
	
	Date date2 = df.parse(fim);
	Calendar f = Calendar.getInstance();
	f.setTime(date2);
	perf.setFim(f);
	perf.setQualidade(qualidade);
	perf.setLote(lote);
	perf.setTeste(teste);
	
	daocolheitaperffigado.atualiza(perf);
	
	model.addAttribute("figadoperf", perf);
	return "eqexplante/loads/carregalinhaperfusaofigado";
}

@RequestMapping(value="delperffigado")
@ResponseBody
public void delperffigado(@RequestParam("idperffigado") Long idperffigado, Model model){

	//colheita.setAnaliseDador(daoanalisedador.buscaPorId(id_analise));
	ColheitaFigadoPerfusao perf = daocolheitaperffigado.buscaPorId(idperffigado);

	daocolheitaperffigado.remove(perf);
}
//-------------------------------- Fim Tabela perfus�o figado----------------------------------//

//------------------------------------------------FIM HARMONIO COLHEITA DADOR CADAVER FIGADO------------------------------------------------------//

//------------------------------------------------HARMONIO COLHEITA DADOR CADAVER CORACAO------------------------------------------------------//

//registos horas coracao
@RequestMapping(value="registahorascoracao")
@ResponseBody
public String registahorascoracao(@RequestParam("tipo") int tipo, HttpSession session){

	Long id_analise = (Long)session.getAttribute("id_analise");
	
	Calendar calfig = Calendar.getInstance();
	ColheitaCoracao cc = daocolheitacoracao.buscacolheitaCoracaoanalise(id_analise);
	
	
	if(tipo==1){
		
		cc.setIniciocoracao(calfig);;
		
	}else if(tipo==2){
			
		cc.setFimcoracao(calfig);
		
	}
	
	daocolheitacoracao.atualiza(cc);
	
	DateFormat dum = new SimpleDateFormat("dd/MM/yyyy HH:mm");
	String date = dum.format(calfig.getTime());
	
	return date;
}



@RequestMapping(value="gravacolheitaharmoniocoracao")
@ResponseBody
public String gravacolheitaharmoniocoracao(ColheitaCoracao colheita, HttpSession session){

	Long id_analise = (Long)session.getAttribute("id_analise");

	ColheitaCoracao cf = daocolheitacoracao.buscacolheitaCoracaoanalise(id_analise);
	colheita.setIniciocoracao(cf.getIniciocoracao());
	colheita.setFimcoracao(cf.getFimcoracao());
	colheita.setEstadocoracao(cf.getEstadocoracao());
	colheita.setHoraassistolia(cf.getHoraassistolia());
	colheita.setTempo(cf.getTempo());
	
	daocolheitacoracao.atualiza(colheita);
	
	return "OK";
}



@SuppressWarnings("unchecked")
@RequestMapping(value="gravacolheitaestadocoracao")
@ResponseBody
public String gravacolheitaestadocoracao(int estado, HttpSession session){

	Long id_analise = (Long)session.getAttribute("id_analise");
	//colheita.setAnaliseDador(daoanalisedador.buscaPorId(id_analise));

	ColheitaCoracao cf = daocolheitacoracao.buscacolheitaCoracaoanalise(id_analise);
	cf.setEstadocoracao(estado);
	
	Dador d = (Dador)session.getAttribute("dadororgao");
	
	actualizacoesestadovalidacaoorgao(1, d.getId_Dador(), estado);
	
	daocolheitacoracao.atualiza(cf);
	
	if(estado==1){
	//notificacao org�o colhido:
		Long idhosp = (Long)session.getAttribute("idlocalizacao");
		List<Long> users = daouser.buscausershospitalorgaocolhidoValidadoNaoValidado(idhosp, d.getId_Dador());
		NotificationsController notificacao = new NotificationsController();
		JSONArray perfis = new JSONArray();
		perfis.add("EC");
		perfis.add("IPST");	
		String msg = "Cora��o do processo "+ d.getCodigoDador()+" explantado e validado";
		notificacao.envianotificacao(users, 18, perfis, "", msg, d.getCodigoDador(), 2);
	}
	if(estado==3){
	//notificacao org�o n�o validado:
		Long idhosp = (Long)session.getAttribute("idlocalizacao");
		List<Long> users = daouser.buscausershospitalorgaocolhidoValidadoNaoValidado(idhosp, d.getId_Dador());
		NotificationsController notificacao = new NotificationsController();
		JSONArray perfis = new JSONArray();
		perfis.add("EC");
		perfis.add("IPST");	
		String msg = "Cora��o do processo "+ d.getCodigoDador()+" n�o foi validado";
		notificacao.envianotificacao(users, 19, perfis, "", msg, d.getCodigoDador(), 2);
	}
	
	return "OK";
}


@RequestMapping(value="registatempoassistoliacoracao", produces="application/json")
@ResponseBody
public String registatempoassistoliacoracao(HttpSession session){

	Long id_analise = (Long)session.getAttribute("id_analise");
	
	//TimeZone tz = TimeZone.getTimeZone("GMT");
	
	
	Calendar calassist = Calendar.getInstance();
	ColheitaCoracao cc = daocolheitacoracao.buscacolheitaCoracaoanalise(id_analise);
			
	cc.setHoraassistolia(calassist);
	
	DateFormat dum = new SimpleDateFormat("dd/MM/yyyy HH:mm");
	String date = dum.format(calassist.getTime());
	
	ColheitaGeral cg = daocolheitageral.buscacolheitageralanalise(id_analise);
	cg.getClampagemgeral();
	
	Date date1 = cg.getClampagemgeral().getTime();
	Date date2 = calassist.getTime();
	long difference = date2.getTime() - date1.getTime(); //em milisegundos
	
    TimeZone tz = TimeZone.getTimeZone("UTC");
    
    SimpleDateFormat df = new SimpleDateFormat("HH:mm:ss");
    df.setTimeZone(tz);
    String time = df.format(new Date(difference));
    

    cc.setTempo(time);
    
    daocolheitacoracao.atualiza(cc);
    
    return "[\""+date+"\",\""+time+"\"]";
}

//------------------------------------------------FIM HARMONIO COLHEITA DADOR CADAVER CORACAO------------------------------------------------------//

//------------------------------------------------INICIO HARMONIO COLHEITA DADOR CADAVER PULMOES------------------------------------------------------//

@RequestMapping(value="registahoraspulmoes")
@ResponseBody
public String registahoraspulmoes(@RequestParam("tipo") int tipo, HttpSession session){

	Long id_analise = (Long)session.getAttribute("id_analise");
	
	Calendar cal = Calendar.getInstance();
	ColheitaPulmoes cr = daocolheitapulmoes.buscacolheitaPulmoesanalise(id_analise);
	
	
	if(tipo==1){
		
		cr.setIniciopulmoes(cal);
		
	}else if(tipo==2){
			
		cr.setFimpulmoes(cal);
		
	}
	
	daocolheitapulmoes.atualiza(cr);
	
	DateFormat dum = new SimpleDateFormat("dd/MM/yyyy HH:mm");
	String date = dum.format(cal.getTime());
	
	return date;
}



//-------------------------Grava��o harm�nio pulmoes-----------------------------------------------------------//
@RequestMapping(value="gravacolheitaharmoniopulmoes")
@ResponseBody
public String gravacolheitaharmoniopulmoes(ColheitaPulmoes colheita, HttpSession session){

	Long id_analise = (Long)session.getAttribute("id_analise");
	//colheita.setAnaliseDador(daoanalisedador.buscaPorId(id_analise));

	ColheitaPulmoes co = daocolheitapulmoes.buscacolheitaPulmoesanalise(id_analise);
	colheita.setIniciopulmoes(co.getIniciopulmoes());
	colheita.setFimpulmoes(co.getFimpulmoes());
	colheita.setEstadopulmaodir(co.getEstadopulmaodir());
	colheita.setEstadopulmaoesq(co.getEstadopulmaoesq());
	
	daocolheitapulmoes.atualiza(colheita);
	
	return "OK";
}



@SuppressWarnings("unchecked")
@RequestMapping(value="gravacolheitaestadopulmoes")
@ResponseBody
public String gravacolheitaestadopulmoes(int lado, int estado, HttpSession session){

	Long id_analise = (Long)session.getAttribute("id_analise");
	//colheita.setAnaliseDador(daoanalisedador.buscaPorId(id_analise));

	ColheitaPulmoes co = daocolheitapulmoes.buscacolheitaPulmoesanalise(id_analise);
	
	if(lado==1){
	co.setEstadopulmaoesq(estado);
	
	Dador d = (Dador)session.getAttribute("dadororgao");
	
	actualizacoesestadovalidacaoorgao(4, d.getId_Dador(), estado);
	daocolheitapulmoes.atualiza(co);
	
	if(estado==1){
	//notificacao org�o colhido:
		Long idhosp = (Long)session.getAttribute("idlocalizacao");
		List<Long> users = daouser.buscausershospitalorgaocolhidoValidadoNaoValidado(idhosp, d.getId_Dador());
		NotificationsController notificacao = new NotificationsController();
		JSONArray perfis = new JSONArray();
		perfis.add("EC");
		perfis.add("IPST");	
		String msg = "Pulm�o Esquerdo do processo "+ d.getCodigoDador()+" explantado e validado";
		notificacao.envianotificacao(users, 18, perfis, "", msg, d.getCodigoDador(), 2);
	}
	if(estado==3){
	//notificacao org�o n�o validado:
		Long idhosp = (Long)session.getAttribute("idlocalizacao");
		List<Long> users = daouser.buscausershospitalorgaocolhidoValidadoNaoValidado(idhosp, d.getId_Dador());
		NotificationsController notificacao = new NotificationsController();
		JSONArray perfis = new JSONArray();
		perfis.add("EC");
		perfis.add("IPST");	
		String msg = "Pulm�o Esquerdo do processo "+ d.getCodigoDador()+" n�o foi validado";
		notificacao.envianotificacao(users, 19, perfis, "", msg, d.getCodigoDador(), 2);
	}
	
	}else{
	
	co.setEstadopulmaodir(estado);
	Dador d = (Dador)session.getAttribute("dadororgao");
	
	actualizacoesestadovalidacaoorgao(5, d.getId_Dador(), estado);
	daocolheitapulmoes.atualiza(co);
	
	if(estado==1){
	//notificacao org�o colhido:
		Long idhosp = (Long)session.getAttribute("idlocalizacao");
		List<Long> users = daouser.buscausershospitalorgaocolhidoValidadoNaoValidado(idhosp, d.getId_Dador());
		NotificationsController notificacao = new NotificationsController();
		JSONArray perfis = new JSONArray();
		perfis.add("EC");
		perfis.add("IPST");	
		String msg = "Pulm�o Direito do processo "+ d.getCodigoDador()+" explantado e validado";
		notificacao.envianotificacao(users, 18, perfis, "", msg, d.getCodigoDador(), 2);
	}
	if(estado==3){
	//notificacao org�o n�o validado:
		Long idhosp = (Long)session.getAttribute("idlocalizacao");
		List<Long> users = daouser.buscausershospitalorgaocolhidoValidadoNaoValidado(idhosp, d.getId_Dador());
		NotificationsController notificacao = new NotificationsController();
		JSONArray perfis = new JSONArray();
		perfis.add("EC");
		perfis.add("IPST");	
		String msg = "Pulm�o Direito do processo "+ d.getCodigoDador()+" n�o foi validado";
		notificacao.envianotificacao(users, 19, perfis, "", msg, d.getCodigoDador(), 2);
	}
	}
	
	
	return "OK";
}

//-----------tabela tratamento harmonio colheita pulm�es----------------------//


@RequestMapping(value="adicionatratharmoniopulmoes")
public String adicionatratharmoniopulmoes(@RequestParam("tratamento") int tratamento, @RequestParam("observacaotrat") String observacaotrat, Model model, HttpSession session){

	Long id_analise = (Long)session.getAttribute("id_analise");
	//colheita.setAnaliseDador(daoanalisedador.buscaPorId(id_analise));
	ColheitaPulmoesTratamento trat = new ColheitaPulmoesTratamento();
	
	AnaliseDador analise = new AnaliseDador();
	analise.setId_AnaliseDador(id_analise);
	
	trat.setAnaliseDador(analise);
	trat.setTratamento(tratamento);
	trat.setObservacoestratamento(observacaotrat);
	
	daocolheitapulmoestrat.adiciona(trat);
	
	model.addAttribute("tp", trat);
	return "eqexplante/loads/carregalinhatratpulmoes";
}



@RequestMapping(value="gravatratamentoharmoniopulmoes")
public String gravatratamentoharmoniopulmoes(@RequestParam("tratamento") int tratamento, @RequestParam("observacaotrat") String observacaotrat, @RequestParam("idcolheitatrat") Long idcolheitatrat, Model model){

	//colheita.setAnaliseDador(daoanalisedador.buscaPorId(id_analise));
	ColheitaPulmoesTratamento trat = daocolheitapulmoestrat.buscaPorId(idcolheitatrat);
	trat.setTratamento(tratamento);
	trat.setObservacoestratamento(observacaotrat);
	
	daocolheitapulmoestrat.atualiza(trat);
	
	model.addAttribute("tp", trat);
	return "eqexplante/loads/carregalinhatratpulmoes";
}


@RequestMapping(value="deltratpulmoes")
@ResponseBody
public void deltratamentopulmoes(@RequestParam("idcolheitatrat") Long idcolheitatrat, Model model){

	//colheita.setAnaliseDador(daoanalisedador.buscaPorId(id_analise));
	ColheitaPulmoesTratamento trat = daocolheitapulmoestrat.buscaPorId(idcolheitatrat);

	daocolheitapulmoestrat.remove(trat);
}
//-----------fim tabela tratamento harmonio colheita pulm�es----------------------//	

//------------------------------------------------FIM HARMONIO COLHEITA DADOR CADAVER PULMOES------------------------------------------------------//


//------------------------------------------------INICIO HARMONIO COLHEITA DADOR CADAVER CORNEAS------------------------------------------------------//

@RequestMapping(value="registahorascorneas")
@ResponseBody
public String registahorascorneas(@RequestParam("tipo") int tipo, HttpSession session){

	Long id_analise = (Long)session.getAttribute("id_analise");
	
	Calendar cal = Calendar.getInstance();
	ColheitaCorneas cc = daocolheitacorneas.buscacolheitaCorneasanalise(id_analise);
	
	
	if(tipo==1){
		
		cc.setIniciocorneas(cal);
		
	}else if(tipo==2){
			
		cc.setFimcorneas(cal);
		
	}
	
	daocolheitacorneas.atualiza(cc);
	
	DateFormat dum = new SimpleDateFormat("dd/MM/yyyy HH:mm");
	String date = dum.format(cal.getTime());
	
	return date;
}



//-------------------------Grava��o harm�nio corneas-----------------------------------------------------------//
@RequestMapping(value="gravacolheitaharmoniocorneas")
@ResponseBody
public String gravacolheitaharmoniocorneas(ColheitaCorneas colheita, HttpSession session){

	Long id_analise = (Long)session.getAttribute("id_analise");
	//colheita.setAnaliseDador(daoanalisedador.buscaPorId(id_analise));

	ColheitaCorneas co = daocolheitacorneas.buscacolheitaCorneasanalise(id_analise);
	colheita.setIniciocorneas(co.getIniciocorneas());
	colheita.setFimcorneas(co.getFimcorneas());
	
	daocolheitacorneas.atualiza(colheita);
	
	return "OK";
}

//---------------Fim grava��o harmonio corneas---------------------------------//

//------------------------------------------------FIM HARMONIO COLHEITA DADOR CADAVER CORNEAS------------------------------------------------------//

//------------------------------------------------INICIO HARMONIO COLHEITA DADOR CADAVER PELE------------------------------------------------------//

@RequestMapping(value="registahoraspele")
@ResponseBody
public String registahoraspele(@RequestParam("tipo") int tipo, HttpSession session){

	Long id_analise = (Long)session.getAttribute("id_analise");
	
	Calendar cal = Calendar.getInstance();
	ColheitaPele cc = daocolheitapele.buscacolheitaPeleanalise(id_analise);
	
	
	if(tipo==1){
		
		cc.setIniciopele(cal);
		
	}else if(tipo==2){
			
		cc.setFimpele(cal);
		
	}
	
	daocolheitapele.atualiza(cc);
	
	DateFormat dum = new SimpleDateFormat("dd/MM/yyyy HH:mm");
	String date = dum.format(cal.getTime());
	
	return date;
}



//-------------------------Grava��o harm�nio pele-----------------------------------------------------------//
@RequestMapping(value="gravacolheitaharmoniopele")
@ResponseBody
public String gravacolheitaharmoniopele(ColheitaPele colheita, HttpSession session){

	Long id_analise = (Long)session.getAttribute("id_analise");
	//colheita.setAnaliseDador(daoanalisedador.buscaPorId(id_analise));

	ColheitaPele cp = daocolheitapele.buscacolheitaPeleanalise(id_analise);
	colheita.setIniciopele(cp.getIniciopele());
	colheita.setFimpele(cp.getFimpele());
	
	daocolheitapele.atualiza(colheita);
	
	return "OK";
}

//---------------Fim grava��o harmonio pele---------------------------------//

//------------------------------------------------FIM HARMONIO COLHEITA DADOR CADAVER PELE------------------------------------------------------//


//------------------------------------------------INICIO HARMONIO COLHEITA DADOR CADAVER TC------------------------------------------------------//

@RequestMapping(value="registahorastc")
@ResponseBody
public String registahorastc(@RequestParam("tipo") int tipo, HttpSession session){

	Long id_analise = (Long)session.getAttribute("id_analise");
	
	Calendar cal = Calendar.getInstance();
	ColheitaTC cc = daocolheitatc.buscacolheitaTCanalise(id_analise);
	
	
	if(tipo==1){
		
		cc.setIniciotc(cal);
		
	}else if(tipo==2){
			
		cc.setFimtc(cal);
		
	}
	
	daocolheitatc.atualiza(cc);
	
	DateFormat dum = new SimpleDateFormat("dd/MM/yyyy HH:mm");
	String date = dum.format(cal.getTime());
	
	return date;
}



//-------------------------Grava��o harm�nio tc-----------------------------------------------------------//
@RequestMapping(value="gravacolheitaharmoniotc")
@ResponseBody
public String gravacolheitaharmoniotc(ColheitaTC colheita, HttpSession session){

	Long id_analise = (Long)session.getAttribute("id_analise");
	//colheita.setAnaliseDador(daoanalisedador.buscaPorId(id_analise));

	ColheitaTC cp = daocolheitatc.buscacolheitaTCanalise(id_analise);
	colheita.setIniciotc(cp.getIniciotc());
	colheita.setFimtc(cp.getFimtc());
	
	daocolheitatc.atualiza(colheita);
	
	return "OK";
}

//---------------Fim grava��o harmonio tc---------------------------------//

//------------------------------------------------FIM HARMONIO COLHEITA DADOR CADAVER TC------------------------------------------------------//


//------------------------------------------------INICIO HARMONIO COLHEITA DADOR CADAVER TME------------------------------------------------------//

@RequestMapping(value="registahorastme")
@ResponseBody
public String registahorastme(@RequestParam("tipo") int tipo, HttpSession session){

	Long id_analise = (Long)session.getAttribute("id_analise");
	
	Calendar cal = Calendar.getInstance();
	ColheitaTME cc = daocolheitatme.buscacolheitaTMEanalise(id_analise);
	
	
	if(tipo==1){
		
		cc.setIniciotme(cal);
		
	}else if(tipo==2){
			
		cc.setFimtme(cal);
		
	}
	
	daocolheitatme.atualiza(cc);
	
	DateFormat dum = new SimpleDateFormat("dd/MM/yyyy HH:mm");
	String date = dum.format(cal.getTime());
	
	return date;
}



//-------------------------Grava��o harm�nio tme-----------------------------------------------------------//
@RequestMapping(value="gravacolheitaharmoniotme")
@ResponseBody
public String gravacolheitaharmoniotme(ColheitaTME colheita, @RequestParam(value="validade2") @DateTimeFormat(pattern="dd/MM/yyyy") Date validade2, HttpSession session){

	Long id_analise = (Long)session.getAttribute("id_analise");
	//colheita.setAnaliseDador(daoanalisedador.buscaPorId(id_analise));
	
	Calendar cal = Calendar.getInstance();
	cal.setTime(validade2);
	
	ColheitaTME cp = daocolheitatme.buscacolheitaTMEanalise(id_analise);
	colheita.setIniciotme(cp.getIniciotme());
	colheita.setFimtme(cp.getFimtme());
	colheita.setValidade(cal);
	
	daocolheitatme.atualiza(colheita);
	
	return "OK";
}

//---------------Fim grava��o harmonio tme---------------------------------//

//------------------------------------------------FIM HARMONIO COLHEITA DADOR CADAVER TME------------------------------------------------------//

//------------------------------------------------INICIO HARMONIO COLHEITA DADOR CADAVER VASOS------------------------------------------------------//

@RequestMapping(value="registahorasvasos")
@ResponseBody
public String registahorasvasos(@RequestParam("tipo") int tipo, HttpSession session){

	Long id_analise = (Long)session.getAttribute("id_analise");
	
	Calendar cal = Calendar.getInstance();
	ColheitaVasos cc = daocolheitavasos.buscacolheitaVasosanalise(id_analise);
	
	
	if(tipo==1){
		
		cc.setIniciovasos(cal);
		
	}else if(tipo==2){
			
		cc.setFimvasos(cal);
		
	}
	
	daocolheitavasos.atualiza(cc);
	
	DateFormat dum = new SimpleDateFormat("dd/MM/yyyy HH:mm");
	String date = dum.format(cal.getTime());
	
	return date;
}



//-------------------------Grava��o harm�nio vasos-----------------------------------------------------------//
@RequestMapping(value="gravacolheitaharmoniovasos")
@ResponseBody
public String gravacolheitaharmoniovasos(ColheitaVasos colheita, HttpSession session){

	Long id_analise = (Long)session.getAttribute("id_analise");
	//colheita.setAnaliseDador(daoanalisedador.buscaPorId(id_analise));

	ColheitaVasos cp = daocolheitavasos.buscacolheitaVasosanalise(id_analise);
	colheita.setIniciovasos(cp.getIniciovasos());
	colheita.setFimvasos(cp.getFimvasos());
	
	daocolheitavasos.atualiza(colheita);
	
	return "OK";
}

//---------------Fim grava��o harmonio vasos---------------------------------//

//------------------------------------------------FIM HARMONIO COLHEITA DADOR CADAVER VASOS------------------------------------------------------//

//----------------------------INICIO SEPARADOR EXPLANTE POS OPERATORIO------------------------------------------//
@RequestMapping(value="carregaseparadorposoperatorioexplante")
public String carregaseparadorposoperatorioexplante(Model model, HttpSession session){
	
	Long id_analise = (Long)session.getAttribute("id_analise");
	
	
	//Se n�o existe pos operatorio cria
	PosOperatorioExplante po = daoposoperatexplante.buscaPosOperatorioExplante(id_analise);
	if(po==null){
		PosOperatorioExplante posop = new PosOperatorioExplante();
		posop.setAnaliseDador(daoanalisedador.buscaPorId(id_analise));
		daoposoperatexplante.adiciona(posop);
		model.addAttribute("posoperexplante", posop);
	}else{
		model.addAttribute("posoperexplante", po);
	}

	//tabela tipo
			model.addAttribute("tipoposop", daoposoptabexpl.listaPosOperatorioTabExplanalise(id_analise));
	
	return "eqexplante/divseparadorposoperatorio";
}

//-----------tabela tipo pos operatorio explante----------------------//


@RequestMapping(value="adicionatipoposopexplante")
public String adicionatipoposopexplante(@RequestParam("tipo") int tipo, @RequestParam("notas") String notas, Model model, HttpSession session){

	Long id_analise = (Long)session.getAttribute("id_analise");
	//colheita.setAnaliseDador(daoanalisedador.buscaPorId(id_analise));
	PosOperatorioTabExpl pot = new PosOperatorioTabExpl();
	
	AnaliseDador analise = new AnaliseDador();
	analise.setId_AnaliseDador(id_analise);
	
	pot.setAnaliseDador(analise);
	pot.setTipo(tipo);
	pot.setNotas(notas);
	
	daoposoptabexpl.adiciona(pot);
	
	model.addAttribute("tipoposop", pot);
	return "eqexplante/loads/carregalinhaposoptabexpl";
}



@RequestMapping(value="gravatipoposopexplante")
public String gravatipoposopexplante(@RequestParam("tipo") int tipo, @RequestParam("notas") String notas, @RequestParam("idtipoposop") Long idtipoposop, Model model){

	//colheita.setAnaliseDador(daoanalisedador.buscaPorId(id_analise));
	PosOperatorioTabExpl pot = daoposoptabexpl.buscaPorId(idtipoposop);
	pot.setTipo(tipo);
	pot.setNotas(notas);
	
	daoposoptabexpl.atualiza(pot);
	
	model.addAttribute("tipoposop", pot);
	return "eqexplante/loads/carregalinhaposoptabexpl";
}


@RequestMapping(value="deltipoposopexplante")
@ResponseBody
public void deltipoposopexplante(@RequestParam("idtipoposop") Long idtipoposop, Model model){

	//colheita.setAnaliseDador(daoanalisedador.buscaPorId(id_analise));
	PosOperatorioTabExpl pot = daoposoptabexpl.buscaPorId(idtipoposop);

	daoposoptabexpl.remove(pot);
}
//-----------fim tabela tipo pos operatorio explante----------------------//

@RequestMapping(value="gravaseparadorposoperatorio")
@ResponseBody
public String gravaseparadorposoperatorio(PosOperatorioExplante posop, HttpSession session){
	
	daoposoperatexplante.atualiza(posop);
	
	return "OK";
}

//----------------------------FIM SEPARADOR EXPLANTE POS OPERATORIO------------------------------------------//



//---------ATUALIZA��O ESTADOS GCCT ASSIG HOSPITAL E HISTORICO QUANDO ORGAO � DADO COMO INVALIDO NO EXPLANTE---------------//


public void actualizacoesestadovalidacaoorgao(int idorgao_oferta, Long iddador, int estado){

	
	if(estado==1){
		StatusAssignacaoOrgaos statusassig = new StatusAssignacaoOrgaos();
		statusassig.setIdstatus(6);
		
		AssignacaoOrgaos assigorg = daoAssigOrg.buscaassignacaoorgaodador(iddador, idorgao_oferta);
		if(assigorg!= null){
			assigorg.setStatusassignacao(statusassig);
			daoAssigOrg.atualiza(assigorg);
			atualizaassighospehistoricoassig(iddador, assigorg.getId_assignacao(), 1, estado);
		}
		
		
	}
	if(estado==2){
		StatusAssignacaoOrgaos statusassig = new StatusAssignacaoOrgaos();
		statusassig.setIdstatus(7);
		
		AssignacaoOrgaos assigorg = daoAssigOrg.buscaassignacaoorgaodador(iddador, idorgao_oferta);
		if(assigorg!= null){
			assigorg.setStatusassignacao(statusassig);
			daoAssigOrg.atualiza(assigorg);
			atualizaassighospehistoricoassig(iddador, assigorg.getId_assignacao(), 1, estado);
		}
		
		
	}
	if(estado==3){
		// id pancreas - 6
		StatusAssignacaoOrgaos statusassig = new StatusAssignacaoOrgaos();
		statusassig.setIdstatus(5);
		
		AssignacaoOrgaos assigorg = daoAssigOrg.buscaassignacaoorgaodador(iddador, idorgao_oferta);
		if(assigorg!= null){
		//	System.out.println("alterar para inv�lido");
			assigorg.setStatusassignacao(statusassig);
			daoAssigOrg.atualiza(assigorg);
			
			atualizaassighospehistoricoassig(iddador, assigorg.getId_assignacao(), 6, estado);
		}
	}
	
	
}


public void atualizaassighospehistoricoassig(long iddador, long idassigorg, int estado, int estadovalidacao){
	
	//altera estado da assigna��o do hospital
	daoAssighosp.alteraestadoassighospitalorgao(idassigorg, estado);
	
	//coloca hist�rico do cancelamento de d�diva
	daohistorico.InsereRegistosEstadoOrgaoHistoricoAssignacao(iddador, estado, idassigorg, estadovalidacao);
}
//---------FIM ATUALIZA��O ESTADOS GCCT ASSIG HOSPITAL E HISTORICO QUANDO ORGAO � DADO COMO INVALIDO NO EXPLANTE---------------//

}