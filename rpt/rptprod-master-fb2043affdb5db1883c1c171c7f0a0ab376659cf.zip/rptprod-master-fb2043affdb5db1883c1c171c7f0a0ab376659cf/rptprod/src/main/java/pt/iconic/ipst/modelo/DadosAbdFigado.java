package pt.iconic.ipst.modelo;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name = "DADOSABDFIGADO")
public class DadosAbdFigado 
{
	private Long Id_DadosAbdFigado;
	private String Tipo;
	private int Numero;
	private int Segmento;
	private String Observacoes;
	private AnaliseDador analiseDador;
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="ID_DADOSABDFIGADO")
	public Long getId_DadosAbdFigado() {
		return Id_DadosAbdFigado;
	}
	public void setId_DadosAbdFigado(Long id_DadosAbdFigado) {
		Id_DadosAbdFigado = id_DadosAbdFigado;
	}
	
	@Column(name="TIPO")
	public String getTipo() {
		return Tipo;
	}
	public void setTipo(String tipo) {
		Tipo = tipo;
	}
	
	@Column(name="NUMERO")
	public int getNumero() {
		return Numero;
	}
	public void setNumero(int numero) {
		Numero = numero;
	}
	
	@Column(name="SEGMENTO")
	public int getSegmento() {
		return Segmento;
	}
	public void setSegmento(int segmento) {
		Segmento = segmento;
	}

	@Column(name="OBSERVACOES")
	public String getObservacoes() {
		return Observacoes;
	}
	public void setObservacoes(String observacoes) {
		Observacoes = observacoes;
	}
	
	@ManyToOne
	@JoinColumn(name="ID_ANALISEDADOR")
	public AnaliseDador getAnaliseDador() {
		return analiseDador;
	}
	public void setAnaliseDador(AnaliseDador analiseDador) {
		this.analiseDador = analiseDador;
	}
}