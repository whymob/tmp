package pt.iconic.ipst.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import pt.iconic.ipst.modelo.GCCT;

@Repository
@Transactional
public class GCCTDAO {

	
	@PersistenceContext
	private EntityManager manager;	
	
	public void adiciona(GCCT gcct){
		manager.persist(gcct);	
	}
	
	public void atualiza(GCCT gcct){
		manager.merge(gcct);
	}

	@SuppressWarnings("unchecked")
	public List<GCCT> ListaGCCT(){
		return manager.createQuery("select s from GCCT s").getResultList();
	}
	
	public GCCT buscaPorId(Long id){
		return manager.find(GCCT.class, id);
	}
		
	public void remove(GCCT gcct){
		GCCT gcctremove = buscaPorId(gcct.getId_GCCT());
		manager.remove(gcctremove);
	}
	
	public boolean trataadicionar(String desc)
	{
		Query query = manager.createQuery("SELECT e FROM GCCT e WHERE e.nomeGCCT =:desc");
		query.setParameter("desc", desc);
		
		if(query.getResultList().isEmpty())
		{
			GCCT gcct = new GCCT();
			gcct.setNomeGCCT(desc);;
			adiciona(gcct);
			
			return true;
		}
		else
		{
			return false;
		}
	}
	
	public boolean trataalterar(Long id, String desc)
	{
		Query query = manager.createQuery("SELECT e FROM GCCT e WHERE e.nomeGCCT =:desc");
		query.setParameter("desc", desc);
		
		if(query.getResultList().isEmpty())
		{
			GCCT gcct = new GCCT();
			gcct.setNomeGCCT(desc);
			gcct.setId_GCCT(id);
			atualiza(gcct);
				
			return true;
		}
		else
		{
			return false;
		}
	}
	
	public boolean remover(Long id) 
	{
		GCCT gcct = new GCCT();
		gcct = buscaPorId(id);

		remove(gcct);
		return true;
	}
}
