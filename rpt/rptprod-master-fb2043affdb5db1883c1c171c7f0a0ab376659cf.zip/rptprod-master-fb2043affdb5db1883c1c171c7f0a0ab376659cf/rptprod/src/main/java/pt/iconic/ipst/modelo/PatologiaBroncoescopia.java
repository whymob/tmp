package pt.iconic.ipst.modelo;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name = "PATOLOGIABRONCOESCOPIA")
public class PatologiaBroncoescopia 
{
	private Long Id_PatologiaBroncoescopia;
	private String Patologia;
	private boolean T;
	private boolean BD;
	private boolean BE;
	private boolean BS;
	private AnaliseDador analiseDador;
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="ID_PATOLOGIABRONCOESCOPIA")
	public Long getId_PatologiaBroncoescopia() {
		return Id_PatologiaBroncoescopia;
	}
	public void setId_PatologiaBroncoescopia(Long id_PatologiaBroncoescopia) {
		Id_PatologiaBroncoescopia = id_PatologiaBroncoescopia;
	}
	
	@Column(name="PATOLOGIA")
	public String getPatologia() {
		return Patologia;
	}
	public void setPatologia(String patologia) {
		Patologia = patologia;
	}
	
	@Column(name="T")
	public boolean isT() {
		return T;
	}
	public void setT(boolean t) {
		T = t;
	}
	
	@Column(name="BD")
	public boolean isBD() {
		return BD;
	}
	public void setBD(boolean bD) {
		BD = bD;
	}
	
	@Column(name="BE")
	public boolean isBE() {
		return BE;
	}
	public void setBE(boolean bE) {
		BE = bE;
	}
	
	@ManyToOne
	@JoinColumn(name="ID_ANALISEDADOR")
	public AnaliseDador getAnaliseDador() {
		return analiseDador;
	}
	public void setAnaliseDador(AnaliseDador analiseDador) {
		this.analiseDador = analiseDador;
	}
	
	@Column(name="BS")
	public boolean isBS() {
		return BS;
	}
	public void setBS(boolean bS) {
		BS = bS;
	}
	
	
}