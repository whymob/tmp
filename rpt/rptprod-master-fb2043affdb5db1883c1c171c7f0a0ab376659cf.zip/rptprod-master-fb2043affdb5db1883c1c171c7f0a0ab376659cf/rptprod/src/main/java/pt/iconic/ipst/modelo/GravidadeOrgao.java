package pt.iconic.ipst.modelo;

import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name = "GRAVIDADEORGAO")
public class GravidadeOrgao 
{
	private Long id_gravidadeorgao;
	private String gravidade;
	//private Orgaos orgao;
	private OrgaosOferta orgao;
	private List<GravidadeRecetor> gravrec;
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="ID_GRAVIDADEORGAO")
	public Long getId_gravidadeorgao() {
		return id_gravidadeorgao;
	}
	public void setId_gravidadeorgao(Long id_gravidadeorgao) {
		this.id_gravidadeorgao = id_gravidadeorgao;
	}
	
	@Column(name="GRAVIDADE")
	public String getGravidade() {
		return gravidade;
	}
	public void setGravidade(String gravidade) {
		this.gravidade = gravidade;
	}
	
/*	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name="ID_ORGAO")
	public Orgaos getOrgao() {
		return orgao;
	}
	public void setOrgao(Orgaos orgao) {
		this.orgao = orgao;
	}*/
	
	@OneToMany(fetch = FetchType.LAZY, mappedBy = "gravorg")
	public List<GravidadeRecetor> getGravrec() {
		return gravrec;
	}
	public void setGravrec(List<GravidadeRecetor> gravrec) {
		this.gravrec = gravrec;
	}
	
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name="ID_ORGAO")
	public OrgaosOferta getOrgao() {
		return orgao;
	}
	public void setOrgao(OrgaosOferta orgao) {
		this.orgao = orgao;
	}
}