package pt.iconic.ipst.modelo;

import java.util.List;

import javax.persistence.Cacheable;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import org.hibernate.annotations.Cache;
import org.hibernate.annotations.CacheConcurrencyStrategy;
import org.hibernate.validator.constraints.Email;

@Entity
@Cacheable(true)
@Cache(usage=CacheConcurrencyStrategy.NONSTRICT_READ_WRITE)
@Table(name = "UTILIZADOR")
public class Utilizador {

	private Long ID_Utilizador;
	private String login;
	private String senha;
	private String utilizador;
	private String email;
	private String telemovel;
	private String telefone;
	private String extensao;
	private int pin;
	private int tipoUtilizador;
	private String codigo;
	private Especialidade especialidade;
	private List<PermissaoLocalizacao> permissoes;
	private List<Dador> dador;
	private List<HistoricoReferenciacao> hist;
	private List<EquipaSuporte> equipasuporte;
	private List<EquipaCirurgia> equipacirurgia;
	private List<EquipaCirurgiaTransplante> equipacirurgiatransplante;
	private List<EquipaSuporteTransplante> equipasuportetransplante;
	private List<EstadoRecetor> estadorecetor; // marca��es pr� transplante
	private List<FollowUp> followup; // marca��es followup
	private List<Recetores> recetores;
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="ID_UTILIZADOR")
	public Long getID_Utilizador() {
		return ID_Utilizador;
	}

	public void setID_Utilizador(Long iD_Utilizador) {
		ID_Utilizador = iD_Utilizador;
	}

	@NotNull @Size(min=5)
	@Column(name="LOGIN", unique=true)
	public String getLogin() {
		return login;
	}

	public void setLogin(String login) {
		this.login = login;
	}

	@NotNull @Size(min=5, message="A senha deve conter no minimo 5 caracteres")
	@Column(name="SENHA")
	public String getSenha() {
		return senha;
	}

	public void setSenha(String senha) {
		this.senha = senha;
	}

	@NotNull
	@Column(name="UTILIZADOR")
    public String getUtilizador() {
		return utilizador;
	}

	public void setUtilizador(String utilizador) {
		this.utilizador = utilizador;
	}


	@NotNull
	@Email(message="Preencha corretamente o Email")
	@Size(min=2, message="Preencha corretamente o Email")
	@Column(name="EMAIL", unique=true)
	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}
	@Column(name="TELEMOVEL")
	public String getTelemovel() {
		return telemovel;
	}

	public void setTelemovel(String telemovel) {
		this.telemovel = telemovel;
	}

	@Column(name="TELEFONE")
	public String getTelefone() {
		return telefone;
	}

	public void setTelefone(String telefone) {
		this.telefone = telefone;
	}

	@Column(name="EXTENSAO")
	public String getExtensao() {
		return extensao;
	}

	public void setExtensao(String extensao) {
		this.extensao = extensao;
	}

	@Column(name="PIN")
	public int getPin() {
		return pin;
	}

	public void setPin(int pin) {
		this.pin = pin;
	}

	@Column(name="TIPOUTILIZADOR")
    public int getTipoUtilizador() {
		return tipoUtilizador;
	}

	public void setTipoUtilizador(int tipoUtilizador) {
		this.tipoUtilizador = tipoUtilizador;
	}

	@Column(name="CODIGO")
	public String getCodigo() {
		return codigo;
	}

	public void setCodigo(String codigo) {
		this.codigo = codigo;
	}

    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "ID_ESPECIALIDADE")
    public Especialidade getEspecialidade() {
		return especialidade;
	}

	public void setEspecialidade(Especialidade especialidade) {
		this.especialidade = especialidade;
	}

	@Cache(usage=CacheConcurrencyStrategy.NONSTRICT_READ_WRITE)
	@OneToMany(fetch = FetchType.LAZY, mappedBy = "utilizador")
	public List<PermissaoLocalizacao> getPermissoes() {
		return permissoes;
	}

	public void setPermissoes(List<PermissaoLocalizacao> permissoes) {
		this.permissoes = permissoes;
	}

	@OneToMany(fetch = FetchType.LAZY, mappedBy = "utilizador")
	public List<Dador> getDador() {
		return dador;
	}

	public void setDador(List<Dador> dador) {
		this.dador = dador;
	}

	@OneToMany(fetch = FetchType.LAZY, mappedBy = "utilizador")
	public List<HistoricoReferenciacao> getHist() {
		return hist;
	}

	public void setHist(List<HistoricoReferenciacao> hist) {
		this.hist = hist;
	}

	@OneToMany(fetch = FetchType.LAZY, mappedBy = "utilizador")
	public List<EquipaSuporte> getEquipasuporte() {
		return equipasuporte;
	}

	public void setEquipasuporte(List<EquipaSuporte> equipasuporte) {
		this.equipasuporte = equipasuporte;
	}

	@OneToMany(fetch = FetchType.LAZY, mappedBy = "utilizador")
	public List<EquipaCirurgia> getEquipacirurgia() {
		return equipacirurgia;
	}

	public void setEquipacirurgia(List<EquipaCirurgia> equipacirurgia) {
		this.equipacirurgia = equipacirurgia;
	}

	@OneToMany(fetch = FetchType.LAZY, mappedBy = "utilizador")
	public List<EquipaCirurgiaTransplante> getEquipacirurgiatransplante() {
		return equipacirurgiatransplante;
	}

	public void setEquipacirurgiatransplante(
			List<EquipaCirurgiaTransplante> equipacirurgiatransplante) {
		this.equipacirurgiatransplante = equipacirurgiatransplante;
	}

	@OneToMany(fetch = FetchType.LAZY, mappedBy = "utilizador")
	public List<EquipaSuporteTransplante> getEquipasuportetransplante() {
		return equipasuportetransplante;
	}

	public void setEquipasuportetransplante(List<EquipaSuporteTransplante> equipasuportetransplante) {
		this.equipasuportetransplante = equipasuportetransplante;
	}

	@OneToMany(fetch = FetchType.LAZY, mappedBy = "user")
	public List<EstadoRecetor> getEstadorecetor() {
		return estadorecetor;
	}

	public void setEstadorecetor(List<EstadoRecetor> estadorecetor) {
		this.estadorecetor = estadorecetor;
	}

	@OneToMany(fetch = FetchType.LAZY, mappedBy = "user")
	public List<FollowUp> getFollowup() {
		return followup;
	}

	public void setFollowup(List<FollowUp> followup) {
		this.followup = followup;
	}

	@OneToMany(fetch = FetchType.LAZY, mappedBy = "utilizador")
	public List<Recetores> getRecetores() {
		return recetores;
	}

	public void setRecetores(List<Recetores> recetores) {
		this.recetores = recetores;
	}	
	
}
