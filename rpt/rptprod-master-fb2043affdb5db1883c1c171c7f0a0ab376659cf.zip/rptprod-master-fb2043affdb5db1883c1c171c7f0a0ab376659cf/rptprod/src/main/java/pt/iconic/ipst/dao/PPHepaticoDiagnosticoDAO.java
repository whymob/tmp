package pt.iconic.ipst.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import pt.iconic.ipst.modelo.PPHepaticoDiagnostico;;

@Repository
public class PPHepaticoDiagnosticoDAO {

	@PersistenceContext
	private EntityManager manager;
	
	@Transactional
	public void adiciona(PPHepaticoDiagnostico hep){
		manager.persist(hep);	
	}
	
	@Transactional
	public void atualiza(PPHepaticoDiagnostico hep){
		manager.merge(hep);
	}
	
/*	@SuppressWarnings("unchecked")
	public List<PPHepaticoDiagnostico> ListaPPHepaticoDiagnostico(){
		return manager.createQuery("select p from PPHepaticoDiagnostico p").getResultList();
	}*/
	
	public PPHepaticoDiagnostico buscaPorId(Long id){
		return manager.find(PPHepaticoDiagnostico.class, id);
	}
	
	@Transactional
	public void remove(PPHepaticoDiagnostico hep){
		PPHepaticoDiagnostico heprem = buscaPorId(hep.getId_pphepaticodiagnostico());
		manager.remove(heprem);
	}
	
	@SuppressWarnings({ "rawtypes", "unchecked" })
	public List<PPHepaticoDiagnostico> ListaPPHepaticoDiagnosticoAnalise(Long id)
	{
		Query query = manager.createQuery("select e from PPHepaticoDiagnostico e JOIN e.analiserecetor analiserecetor WHERE analiserecetor.id_analiserecetor =:idanalise");
		query.setParameter("idanalise", id);

		List results = query.getResultList();
		
		return results;
	}
}
