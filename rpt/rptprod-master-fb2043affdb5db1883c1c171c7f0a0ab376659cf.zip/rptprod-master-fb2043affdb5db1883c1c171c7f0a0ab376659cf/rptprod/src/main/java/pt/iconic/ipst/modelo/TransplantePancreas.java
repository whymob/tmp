package pt.iconic.ipst.modelo;

import java.util.Calendar;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name = "TRANSPLANTE_PANCREAS")
public class TransplantePancreas {

	private Long idtransplantepancreas;
	private Calendar inicio;
	private Calendar clampvenosa;
	private Calendar retirargelo;
	private Calendar desclampvenosa;
	private Calendar clamparterial;
	private Calendar desclamparterial;
	private Calendar fim;
	private String isqfria;
	private String isqquente;
	private String isqtotal;
	private String clampdescVenosa;
	private String clampdescArterial;
	private int transppancreas;
	private int implantacao;
	private int anastarterial;
	private int orgtotal;
	private int reclampart;
	private int reclampven;	
	private int modalidade;
	private int drenven;
	private int drenexoc;
	private String relatoperat;
	private int complicacoes;
	private int estado;
	private AssignacaoOrgaos assigorgao;
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="ID_TRANSP_PANCREAS")
	public Long getIdtransplantepancreas() {
		return idtransplantepancreas;
	}
	public void setIdtransplantepancreas(Long idtransplantepancreas) {
		this.idtransplantepancreas = idtransplantepancreas;
	}
	
	@Column(name="INICIO")
	public Calendar getInicio() {
		return inicio;
	}
	public void setInicio(Calendar inicio) {
		this.inicio = inicio;
	}
	
	@Column(name="CLAMP_VENOSA")
	public Calendar getClampvenosa() {
		return clampvenosa;
	}
	public void setClampvenosa(Calendar clampvenosa) {
		this.clampvenosa = clampvenosa;
	}
	
	@Column(name="RETIRAR_GELO")
	public Calendar getRetirargelo() {
		return retirargelo;
	}
	public void setRetirargelo(Calendar retirargelo) {
		this.retirargelo = retirargelo;
	}
	
	@Column(name="DESCLAMP_VENOSA")
	public Calendar getDesclampvenosa() {
		return desclampvenosa;
	}
	public void setDesclampvenosa(Calendar desclampvenosa) {
		this.desclampvenosa = desclampvenosa;
	}
	
	@Column(name="CLAMP_ARTERIAL")
	public Calendar getClamparterial() {
		return clamparterial;
	}
	public void setClamparterial(Calendar clamparterial) {
		this.clamparterial = clamparterial;
	}
	
	@Column(name="DESCLAMP_ARTERIAL")
	public Calendar getDesclamparterial() {
		return desclamparterial;
	}
	public void setDesclamparterial(Calendar desclamparterial) {
		this.desclamparterial = desclamparterial;
	}
	
	@Column(name="FIM")
	public Calendar getFim() {
		return fim;
	}
	public void setFim(Calendar fim) {
		this.fim = fim;
	}
	
	@Column(name="ISQUEMIA_FRIA")
	public String getIsqfria() {
		return isqfria;
	}
	public void setIsqfria(String isqfria) {
		this.isqfria = isqfria;
	}
	
	@Column(name="ISQUEMIA_QUENTE")
	public String getIsqquente() {
		return isqquente;
	}
	public void setIsqquente(String isqquente) {
		this.isqquente = isqquente;
	}
	
	@Column(name="ISQUEMIA_TOTAL")
	public String getIsqtotal() {
		return isqtotal;
	}
	public void setIsqtotal(String isqtotal) {
		this.isqtotal = isqtotal;
	}
	
	@Column(name="CLAMP_DESCLAMP_VENOSA")
	public String getClampdescVenosa() {
		return clampdescVenosa;
	}
	public void setClampdescVenosa(String clampdescVenosa) {
		this.clampdescVenosa = clampdescVenosa;
	}
	
	@Column(name="CLAMP_DESCLAMP_ARTERIAL")
	public String getClampdescArterial() {
		return clampdescArterial;
	}
	public void setClampdescArterial(String clampdescArterial) {
		this.clampdescArterial = clampdescArterial;
	}
	
	@Column(name="TRANSP_PANCREAS")
	public int getTransppancreas() {
		return transppancreas;
	}
	public void setTransppancreas(int transppancreas) {
		this.transppancreas = transppancreas;
	}
	
	@Column(name="IMPLANTACAO")
	public int getImplantacao() {
		return implantacao;
	}
	public void setImplantacao(int implantacao) {
		this.implantacao = implantacao;
	}
	
	@Column(name="ANASTOMOSE_ARTERIAL")
	public int getAnastarterial() {
		return anastarterial;
	}
	public void setAnastarterial(int anastarterial) {
		this.anastarterial = anastarterial;
	}
	
	@Column(name="ORGAO_TOTAL")
	public int getOrgtotal() {
		return orgtotal;
	}
	public void setOrgtotal(int orgtotal) {
		this.orgtotal = orgtotal;
	}
	
	@Column(name="RECLAMP_ARTERIAL")
	public int getReclampart() {
		return reclampart;
	}
	public void setReclampart(int reclampart) {
		this.reclampart = reclampart;
	}
	
	@Column(name="RECLAMP_VENOSA")
	public int getReclampven() {
		return reclampven;
	}
	public void setReclampven(int reclampven) {
		this.reclampven = reclampven;
	}
	
	@Column(name="MODALIDADE")
	public int getModalidade() {
		return modalidade;
	}
	public void setModalidade(int modalidade) {
		this.modalidade = modalidade;
	}
	
	@Column(name="DRENAGEM_VENOSA")
	public int getDrenven() {
		return drenven;
	}
	public void setDrenven(int drenven) {
		this.drenven = drenven;
	}
	
	@Column(name="DRENAGEM_EXOCRINA")
	public int getDrenexoc() {
		return drenexoc;
	}
	public void setDrenexoc(int drenexoc) {
		this.drenexoc = drenexoc;
	}
	
	@Column(name="RELATO_OPERATORIO")
	public String getRelatoperat() {
		return relatoperat;
	}
	public void setRelatoperat(String relatoperat) {
		this.relatoperat = relatoperat;
	}
	
	@Column(name="COMPLICACOES")
	public int getComplicacoes() {
		return complicacoes;
	}
	public void setComplicacoes(int complicacoes) {
		this.complicacoes = complicacoes;
	}
	
	@Column(name="ESTADO")
	public int getEstado() {
		return estado;
	}
	public void setEstado(int estado) {
		this.estado = estado;
	}
	
	@OneToOne(fetch=FetchType.EAGER)
	@JoinColumn(name="ID_ASSIGNACAO_ORGAOS")
	public AssignacaoOrgaos getAssigorgao() {
		return assigorgao;
	}
	public void setAssigorgao(AssignacaoOrgaos assigorgao) {
		this.assigorgao = assigorgao;
	}
	
	
	
}
