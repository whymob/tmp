package pt.iconic.ipst.modelo;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name = "TRANSPLANTE_FIGADO_TRANSFUSAO")
public class TransplanteFigadoTransfusao {

	
	private Long idfigadotransf;
	private int transfusao;
	private int qtd;
	private String observacoestransf;
	private AssignacaoOrgaos assigorgao;
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="ID_FIGADO_TRANSFUSAO")
	public Long getIdfigadotransf() {
		return idfigadotransf;
	}
	public void setIdfigadotransf(Long idfigadotransf) {
		this.idfigadotransf = idfigadotransf;
	}
	
	@Column(name="TRANSFUSAO")
	public int getTransfusao() {
		return transfusao;
	}
	public void setTransfusao(int transfusao) {
		this.transfusao = transfusao;
	}
	
	@Column(name="QTD")
	public int getQtd() {
		return qtd;
	}
	public void setQtd(int qtd) {
		this.qtd = qtd;
	}
	
	@Column(name="OBSERVACOES")
	public String getObservacoestransf() {
		return observacoestransf;
	}
	public void setObservacoestransf(String observacoestransf) {
		this.observacoestransf = observacoestransf;
	}
	@ManyToOne(fetch=FetchType.EAGER)
	@JoinColumn(name="ID_ASSIGNACAO_ORGAOS")
	public AssignacaoOrgaos getAssigorgao() {
		return assigorgao;
	}
	public void setAssigorgao(AssignacaoOrgaos assigorgao) {
		this.assigorgao = assigorgao;
	}
}
