package pt.iconic.ipst.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

@Repository
@Transactional
public class EquipaExplantesDAO {

	
	
	@PersistenceContext
	private EntityManager manager;
	
	@SuppressWarnings( "unchecked")
	public List<Object> carregaexplanteshospital(Long idhospital){
		
		List<Object> out = null;

		Query query = manager.createNativeQuery("select d.CODIGODADOR , e.ESTADO, h.NOMEHOSPITAL, el.SALA, el.DATA, d.ID_DADOR , an.ID_ANALISEDADOR "
				+ "from DADOR d "
				+ "inner join ANALISEDADOR an on (an.ID_DADOR = d.ID_DADOR) "
				+ "inner join ESTADODADOR e on (e.ID_ESTADODADOR = d.ID_ESTADODADOR) "
				+ "left join EQUIPA_LOCAL el on (el.ID_DADOR = d.ID_DADOR) "
				+ "left join HOSPITAL h on (h.ID_HOSPITAL = el.ID_HOSPITAL) "
				+ "where d.ID_HOSPITAL=:idhospital and (e.ID_ESTADODADOR = 2 OR e.ID_ESTADODADOR = 3)");
		query.setParameter("idhospital", idhospital);

		
		out = query.getResultList();

		
		return out;
	}
}
