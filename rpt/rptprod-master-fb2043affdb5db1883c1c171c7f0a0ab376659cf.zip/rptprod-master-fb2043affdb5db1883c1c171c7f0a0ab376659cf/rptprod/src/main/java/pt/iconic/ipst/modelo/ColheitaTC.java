package pt.iconic.ipst.modelo;

import java.util.Calendar;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name = "COLHEITA_TC")
public class ColheitaTC {

	private Long idcolheitatc;
	private Calendar iniciotc;
	private Calendar fimtc;
	private String notastc;
	private int aortaretirada;
	private int pulmonarretirada;
	private AnaliseDador analiseDador;
	private String codtc;
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="ID_COLHEITA_TC")
	public Long getIdcolheitatc() {
		return idcolheitatc;
	}
	public void setIdcolheitatc(Long idcolheitatc) {
		this.idcolheitatc = idcolheitatc;
	}
	
	@Column(name="INICIO")
	public Calendar getIniciotc() {
		return iniciotc;
	}
	public void setIniciotc(Calendar iniciotc) {
		this.iniciotc = iniciotc;
	}
	
	@Column(name="FIM")
	public Calendar getFimtc() {
		return fimtc;
	}
	public void setFimtc(Calendar fimtc) {
		this.fimtc = fimtc;
	}
	
	@Column(name="NOTAS")
	public String getNotastc() {
		return notastc;
	}
	public void setNotastc(String notastc) {
		this.notastc = notastc;
	}
	
	@Column(name="AORTA_RETIRADA")
	public int getAortaretirada() {
		return aortaretirada;
	}
	public void setAortaretirada(int aortaretirada) {
		this.aortaretirada = aortaretirada;
	}
	
	@Column(name="PULMONAR_RETIRADA")
	public int getPulmonarretirada() {
		return pulmonarretirada;
	}
	public void setPulmonarretirada(int pulmonarretirada) {
		this.pulmonarretirada = pulmonarretirada;
	}
	
	@OneToOne(fetch=FetchType.EAGER)
	@JoinColumn(name="ID_ANALISEDADOR")
	public AnaliseDador getAnaliseDador() {
		return analiseDador;
	}
	public void setAnaliseDador(AnaliseDador analiseDador) {
		this.analiseDador = analiseDador;
	}
	
	@Column(name="COD_TC")
	public String getCodtc() {
		return codtc;
	}
	public void setCodtc(String codtc) {
		this.codtc = codtc;
	}
	
	
	
}
