package pt.iconic.ipst.modelo;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "VALORESCOLHEITAS")
public class ValoresColheitas 
{
	private Long idvalorcolheita;
	private int ano;
	private int ato;
	private int tipo;
	private float valor;
	private float suplementar;
	private String observacoes;
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="ID_VALORCOLHEITA")
	public Long getIdvalorcolheita() {
		return idvalorcolheita;
	}
	public void setIdvalorcolheita(Long idvalorcolheita) {
		this.idvalorcolheita = idvalorcolheita;
	}
	
	@Column(name="ANO")
	public int getAno() {
		return ano;
	}
	public void setAno(int ano) {
		this.ano = ano;
	}
	
	@Column(name="ATO")
	public int getAto() {
		return ato;
	}
	public void setAto(int ato) {
		this.ato = ato;
	}
	
	@Column(name="TIPO")
	public int getTipo() {
		return tipo;
	}
	public void setTipo(int tipo) {
		this.tipo = tipo;
	}
	
	@Column(name="VALOR")
	public float getValor() {
		return valor;
	}
	public void setValor(float valor) {
		this.valor = valor;
	}
	
	@Column(name="SUPLEMENTAR")
	public float getSuplementar() {
		return suplementar;
	}
	public void setSuplementar(float suplementar) {
		this.suplementar = suplementar;
	}
	
	@Column(name="OBSERVACOES")
	public String getObservacoes() {
		return observacoes;
	}
	public void setObservacoes(String observacoes) {
		this.observacoes = observacoes;
	}
	
	
}
