package pt.iconic.ipst.dao;

import java.util.Calendar;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import pt.iconic.ipst.modelo.Objetivos;

@Repository
@Transactional
public class ObjetivosDAO 
{
	@PersistenceContext
	private EntityManager manager;
	
	public void adiciona(Objetivos orgao){
		manager.persist(orgao);	
	}
	
	public void atualiza(Objetivos orgao){
		manager.merge(orgao);
	}
	
	@SuppressWarnings("unchecked")
	public List<Objetivos> ListaObjetivos(){
		return manager.createQuery("select o from Objetivos o").getResultList();
	}
	
	public Objetivos buscaPorId(Long id){
		return manager.find(Objetivos.class, id);
	}
	
/*	public void remove(Objetivos orgao){
		Objetivos orgaoARemover = buscaPorId(orgao.getId_objetivo());
		manager.remove(orgaoARemover);
	}*/
	
	public int buscaultimoano()
	{
		Query query = manager.createNativeQuery("select MAX(OBJETIVOS.ANO) from OBJETIVOS");

		Calendar cal = Calendar.getInstance();
		
		int recente = cal.get(Calendar.YEAR);
		
		if(!(query.getResultList().get(0)==null)){
			recente = (int) query.getResultList().get(0);
		}
		
		return recente;
	}
	
	@SuppressWarnings("unchecked")
	public List<Objetivos> buscacomobjetivos()
	{
		Query query = manager.createQuery("select o from Objetivos o where o.objetivo > 0");

		List<Objetivos> results = query.getResultList();

		return results;
	}
	
	@Transactional
	public boolean criavaloresnovos()
	{
		Calendar cal = Calendar.getInstance();
		int anoatual = cal.get(Calendar.YEAR);
		
		Query query = manager.createNativeQuery("select MAX(OBJETIVOS.ANO) from OBJETIVOS");
		int recente = (int) query.getResultList().get(0);

		if((recente-anoatual) >= 1)
			return false;
		else
		{
			Query query2 = manager.createNativeQuery("insert into OBJETIVOS (ANO, DATAPAGAMENTO, OBJETIVO, PAGAMENTO, REALIZADO, ID_ENTIDADE, ID_HOSPITAL, ID_ORGAO_OFERTA, OBJETIVOREF)(Select v.ANO+1 as ANO, "
					+ "NULL, v.OBJETIVO, 'False', 0, v.ID_ENTIDADE, V.ID_HOSPITAL, V.ID_ORGAO_OFERTA, V.OBJETIVOREF  from OBJETIVOS v where v.ANO= (Select MAX(ANO) from OBJETIVOS va));");
			query2.executeUpdate();
			
			return true;
		}
	}
}
