package pt.iconic.ipst.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import pt.iconic.ipst.modelo.TipoDiagnostico;

@Repository
@Transactional
public class TipoDiagnosticoDAO {

	
	@PersistenceContext
	private EntityManager manager;
	
	
	public void adiciona(TipoDiagnostico tipodiag){
		manager.persist(tipodiag);	
	}
	
	public void atualiza(TipoDiagnostico tipodiag){
		manager.merge(tipodiag);
	}
	

	@SuppressWarnings("unchecked")
	public List<TipoDiagnostico> ListaTipoDiagnostico(){
		return manager.createQuery("select c from TipoDiagnostico c").getResultList();
	}
	
	public TipoDiagnostico buscaPorId(int id){
		return manager.find(TipoDiagnostico.class, id);
	}
	
	
	public void remove(TipoDiagnostico tipodiag){
		TipoDiagnostico tipodiagARemover = buscaPorId(tipodiag.getIdtipodiagnostico());
		manager.remove(tipodiagARemover);
	}
	
	public boolean trataadicionar(String desc)
	{
		Query query = manager.createQuery("SELECT t FROM TipoDiagnostico t WHERE t.descricao =:desc");
		query.setParameter("desc", desc);
		
		if(query.getResultList().isEmpty())
		{
			TipoDiagnostico tipodiag = new TipoDiagnostico();
			tipodiag.setDescricao(desc);
			adiciona(tipodiag);
			
			return true;
		}
		else
		{
			return false;
		}
	}
	
	public boolean trataalterar(int id, String desc)
	{
		TipoDiagnostico tipodiag = new TipoDiagnostico();
		tipodiag.setIdtipodiagnostico(id);
		tipodiag.setDescricao(desc);
		atualiza(tipodiag);
			
		return true;
	}
	
	public boolean remover(int id)
	{
		TipoDiagnostico tipodiag = buscaPorId(id);
		
		remove(tipodiag);
		return true;
	}
}
