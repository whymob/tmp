package pt.iconic.ipst.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import pt.iconic.ipst.modelo.Radiografia;

@Repository
@Transactional
public class RadiografiaDAO
{
	@PersistenceContext
	private EntityManager manager;
	
	public void adiciona(Radiografia rx){
		manager.persist(rx);	
	}

	public void atualiza(Radiografia rx){
		manager.merge(rx);
	}

	public Radiografia buscaPorId(Long id){
		return manager.find(Radiografia.class, id);
	}
	
/*	public void remove(Radiografia rx){
		Radiografia rad = buscaPorId(rx.getId_Radiografia());
		manager.remove(rad);
	}*/


	@SuppressWarnings("rawtypes")
	public Radiografia ListaRadiografia(Long id)
	{
		Query query = manager.createQuery("select e from Radiografia e JOIN e.analiseDador analisedador WHERE analisedador.id_AnaliseDador =:idanalise");
		query.setParameter("idanalise", id);

		List results = query.getResultList();
		Radiografia rad = null;
		
		if(!results.isEmpty())
		{
			rad = (Radiografia) results.get(0);
		}
		
		return rad;
	}
}
