package pt.iconic.ipst.modelo;

import java.util.Calendar;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
import javax.persistence.PrePersist;
import javax.persistence.Table;


@Entity
@Table(name = "HCEXAMEFISICO")
public class HCExameFisico {


	private Long id_exameFisico;
	private AnaliseDador analisedador;
	private boolean ictericia;
	private boolean lesoesgenitais;
	private boolean noduloslinfaticos;
	private boolean tatpiercings;
	private boolean pontosbrancosboca;
	private boolean puncoes;
	private boolean hepatomegalia;
	private boolean lesoesperianais;
	private boolean lesoescutaneas;
	private boolean lesoesnecroticas;
	private boolean traumainfecao;
	private boolean evidocularesanormais;
	private String especificarexame;
	private int pertoracico;
	private int peso;
	private int perabdominal;
	private int altura;
	private boolean aparencia;
	private Etnia etnia;
	private Quadrantes quadrantes;
	private String especificar_quadrantes;
	private boolean statusharmonio;
	private Calendar datagravacao;
	
	@PrePersist
	void preInsercao() {
		HCExameFisico.this.setIctericia(false);
		HCExameFisico.this.setLesoesgenitais(false);
		HCExameFisico.this.setNoduloslinfaticos(false);
		HCExameFisico.this.setTatpiercings(false);
		HCExameFisico.this.setPontosbrancosboca(false);
		HCExameFisico.this.setPuncoes(false);
		HCExameFisico.this.setHepatomegalia(false);
		HCExameFisico.this.setLesoesperianais(false);
		HCExameFisico.this.setLesoescutaneas(false);
		HCExameFisico.this.setLesoesnecroticas(false);
		HCExameFisico.this.setTraumainfecao(false);
		HCExameFisico.this.setEvidocularesanormais(false);
	}
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="ID_EXAMEFISICO")
	public Long getId_exameFisico() {
		return id_exameFisico;
	}
	public void setId_exameFisico(Long id_exameFisico) {
		this.id_exameFisico = id_exameFisico;
	}
	
	@OneToOne
	@JoinColumn(name="ID_ANALISEDADOR")
	public AnaliseDador getAnalisedador() {
		return analisedador;
	}
	public void setAnalisedador(AnaliseDador analisedador) {
		this.analisedador = analisedador;
	}
	
	@Column(name="ICTERICIA")
	public boolean isIctericia() {
		return ictericia;
	}
	public void setIctericia(boolean ictericia) {
		this.ictericia = ictericia;
	}
	
	@Column(name="LESOESGENITAIS")
	public boolean isLesoesgenitais() {
		return lesoesgenitais;
	}
	public void setLesoesgenitais(boolean lesoesgenitais) {
		this.lesoesgenitais = lesoesgenitais;
	}
	
	@Column(name="NODULOSLINFATICOS")
	public boolean isNoduloslinfaticos() {
		return noduloslinfaticos;
	}
	public void setNoduloslinfaticos(boolean noduloslinfaticos) {
		this.noduloslinfaticos = noduloslinfaticos;
	}
	
	@Column(name="TATUAGENSPIERCINGS")
	public boolean isTatpiercings() {
		return tatpiercings;
	}
	public void setTatpiercings(boolean tatpiercings) {
		this.tatpiercings = tatpiercings;
	}
	
	@Column(name="PONTOSBRANCOSBOCA")
	public boolean isPontosbrancosboca() {
		return pontosbrancosboca;
	}
	public void setPontosbrancosboca(boolean pontosbrancosboca) {
		this.pontosbrancosboca = pontosbrancosboca;
	}
	
	@Column(name="PUNCOES")
	public boolean isPuncoes() {
		return puncoes;
	}
	public void setPuncoes(boolean puncoes) {
		this.puncoes = puncoes;
	}
	
	@Column(name="HEPATOMEGALIA")
	public boolean isHepatomegalia() {
		return hepatomegalia;
	}
	public void setHepatomegalia(boolean hepatomegalia) {
		this.hepatomegalia = hepatomegalia;
	}
	
	@Column(name="LESOESPERIANAIS")
	public boolean isLesoesperianais() {
		return lesoesperianais;
	}
	public void setLesoesperianais(boolean lesoesperianais) {
		this.lesoesperianais = lesoesperianais;
	}
	
	@Column(name="LESOESCUTANEAS")
	public boolean isLesoescutaneas() {
		return lesoescutaneas;
	}
	public void setLesoescutaneas(boolean lesoescutaneas) {
		this.lesoescutaneas = lesoescutaneas;
	}
	
	@Column(name="LESOESNECROTICAS")
	public boolean isLesoesnecroticas() {
		return lesoesnecroticas;
	}
	public void setLesoesnecroticas(boolean lesoesnecroticas) {
		this.lesoesnecroticas = lesoesnecroticas;
	}
	
	@Column(name="TRAUMAINFECAO")	
	public boolean isTraumainfecao() {
		return traumainfecao;
	}
	public void setTraumainfecao(boolean traumainfecao) {
		this.traumainfecao = traumainfecao;
	}
	
	@Column(name="EVIDOCULARESANORMAIS")
	public boolean isEvidocularesanormais() {
		return evidocularesanormais;
	}
	public void setEvidocularesanormais(boolean evidocularesanormais) {
		this.evidocularesanormais = evidocularesanormais;
	}
	
	@Column(name="ESPECIFICAREXAME")
	public String getEspecificarexame() {
		return especificarexame;
	}
	public void setEspecificarexame(String especificarexame) {
		this.especificarexame = especificarexame;
	}
	
	@Column(name="PER_TORACICO")
	public int getPertoracico() {
		return pertoracico;
	}
	public void setPertoracico(int pertoracico) {
		this.pertoracico = pertoracico;
	}
	
	@Column(name="PESO")
	public int getPeso() {
		return peso;
	}
	public void setPeso(int peso) {
		this.peso = peso;
	}
	
	@Column(name="PER_ABDOMINAL")
	public int getPerabdominal() {
		return perabdominal;
	}
	public void setPerabdominal(int perabdominal) {
		this.perabdominal = perabdominal;
	}
	
	@Column(name="ALTURA")
	public int getAltura() {
		return altura;
	}
	public void setAltura(int altura) {
		this.altura = altura;
	}
	
	@Column(name="APARENCIA")
	public boolean isAparencia() {
		return aparencia;
	}
	public void setAparencia(boolean aparencia) {
		this.aparencia = aparencia;
	}
	
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="ID_ETNIA")
	public Etnia getEtnia() {
		return etnia;
	}
	public void setEtnia(Etnia etnia) {
		this.etnia = etnia;
	}
	
	@OneToOne(fetch=FetchType.LAZY, cascade= CascadeType.ALL)
	@JoinColumn(name="ID_QUADRANTES")
	public Quadrantes getQuadrantes() {
		return quadrantes;
	}
	public void setQuadrantes(Quadrantes quadrantes) {
		this.quadrantes = quadrantes;
	}
	
	@Column(name="ESPECIFICAR_QUADRANTES")
	public String getEspecificar_quadrantes() {
		return especificar_quadrantes;
	}
	public void setEspecificar_quadrantes(String especificar_quadrantes) {
		this.especificar_quadrantes = especificar_quadrantes;
	}

	@Column(name="STATUSHARMONIO")	
	public boolean isStatusharmonio() {
		return statusharmonio;
	}

	public void setStatusharmonio(boolean statusharmonio) {
		this.statusharmonio = statusharmonio;
	}

	@Column(name="DATAGRAVACAO")
	public Calendar getDatagravacao() {
		return datagravacao;
	}


	public void setDatagravacao(Calendar datagravacao) {
		this.datagravacao = datagravacao;
	}
}
