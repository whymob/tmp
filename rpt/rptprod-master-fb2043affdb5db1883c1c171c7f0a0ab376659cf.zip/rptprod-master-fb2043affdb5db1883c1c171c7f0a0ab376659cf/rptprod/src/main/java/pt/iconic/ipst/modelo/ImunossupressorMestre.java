package pt.iconic.ipst.modelo;

import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name = "IMUNOPRESSORMESTRE")
public class ImunossupressorMestre 
{
	private Long id_imuno;
	private String nome;
	private List<Imunossupressores> imunosupressor;
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="ID_IMUNO")
	public Long getId_imuno() {
		return id_imuno;
	}
	public void setId_imuno(Long id_imuno) {
		this.id_imuno = id_imuno;
	}
	
	@Column(name="NOME")
	public String getNome() {
		return nome;
	}
	public void setNome(String nome) {
		this.nome = nome;
	}
	
	@OneToMany(fetch = FetchType.LAZY, mappedBy = "imuno")
	public List<Imunossupressores> getImunosupressor() {
		return imunosupressor;
	}
	public void setImunosupressor(List<Imunossupressores> imunosupressor) {
		this.imunosupressor = imunosupressor;
	}	
}