package pt.iconic.ipst.modelo;

/*import javax.persistence.TemporalType;

import org.springframework.format.annotation.DateTimeFormat;

@Entity
@Table(name = "UTILIZADORACTIVIDADE")
public class UtilizadorActividade {

	private Long Id_Utilizador_Actividade;
	private Calendar DataActividade;
	private Utilizador utilizador;
	private Actividade actividade;
	
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="ID_UTILIZADORACTIVIDADE")
	public Long getId_Utilizador_Actividade() {
		return Id_Utilizador_Actividade;
	}
	public void setId_Utilizador_Actividade(Long id_Utilizador_Actividade) {
		Id_Utilizador_Actividade = id_Utilizador_Actividade;
	}
	
	@DateTimeFormat(pattern="dd/MM/yyyy")
	@Temporal(TemporalType.DATE)
	@Column(name="DATAACTIVIDADE")
	public Calendar getDataActividade() {
		return DataActividade;
	}
	public void setDataActividade(Calendar dataActividade) {
		DataActividade = dataActividade;
	}
	
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "ID_UTILIZADOR")
	public Utilizador getUtilizador() {
		return utilizador;
	}
    
	public void setUtilizador(Utilizador utilizador) {
		this.utilizador = utilizador;
	}
	
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "ID_ACTIVIDADE")
	public Actividade getActividade() {
		return actividade;
	}
	public void setActividade(Actividade actividade) {
		this.actividade = actividade;
	}
	
}
*/
