package pt.iconic.ipst.modelo;

import javax.persistence.Column;
import javax.persistence.Entity;
//import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
//import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;

@Entity
@Table(name = "SENSIBILIDADE")
public class Sensibilidade 
{
	private Long Id_Sensibilidade;
	private String SensDescricao;
//	private SensMicroorganalise sensmicroanalise;
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="ID_SENSIBILIDADE")
	public Long getId_Sensibilidade() {
		return Id_Sensibilidade;
	}
	
	public void setId_Sensibilidade(Long id_Sensibilidade) {
		Id_Sensibilidade = id_Sensibilidade;
	}

	@NotNull
	@Column(name="SENSDESCRICAO")
	public String getSensDescricao() {
		return SensDescricao;
	}
	
	public void setSensDescricao(String sensDescricao) {
		SensDescricao = sensDescricao;
	}

//	@OneToOne(fetch = FetchType.LAZY, mappedBy = "sensibilidade")
//	public SensMicroorganalise getSensmicroanalise() {
//		return sensmicroanalise;
//	}
//
//	public void setSensmicroanalise(SensMicroorganalise sensmicroanalise) {
//		this.sensmicroanalise = sensmicroanalise;
//	}	
}