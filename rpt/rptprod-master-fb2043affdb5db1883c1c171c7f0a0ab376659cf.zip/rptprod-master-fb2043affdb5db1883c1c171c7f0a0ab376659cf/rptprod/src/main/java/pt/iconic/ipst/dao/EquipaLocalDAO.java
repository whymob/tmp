package pt.iconic.ipst.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import pt.iconic.ipst.modelo.EquipaLocal;

@Repository
@Transactional
public class EquipaLocalDAO {

	
	@PersistenceContext
	private EntityManager manager;
	
	
	public void adiciona(EquipaLocal el){
		manager.persist(el);	
	}
	
	public void atualiza(EquipaLocal el){
		manager.merge(el);
	}
	

/*	@SuppressWarnings("unchecked")
	public List<EquipaLocal> ListaEquipaLocal(){
		return manager.createQuery("select a from EquipaLocal a").getResultList();
	}*/
	
/*	public EquipaLocal buscaPorId(Long id){
		return manager.find(EquipaLocal.class, id);
	}
	
	
	public void remove(EquipaLocal el){
		EquipaLocal elARemover = buscaPorId(el.getIdequipalocal());
		manager.remove(elARemover);
	}*/
	
	@SuppressWarnings("unchecked")
	public EquipaLocal buscaequipalocal(Long iddador){
		
		Query query = manager.createQuery("select el from EquipaLocal el JOIN el.dador dador WHERE dador.id_Dador =:iddador");
		query.setParameter("iddador", iddador);
		
		
		List<EquipaLocal> results = query.getResultList();
		EquipaLocal el = null;
		if(!results.isEmpty()){
			el = (EquipaLocal) results.get(0);
		}

		return el;
		
	}
}
