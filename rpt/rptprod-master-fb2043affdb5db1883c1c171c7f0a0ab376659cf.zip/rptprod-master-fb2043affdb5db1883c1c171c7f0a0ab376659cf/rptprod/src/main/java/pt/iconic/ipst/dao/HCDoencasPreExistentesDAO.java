package pt.iconic.ipst.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import pt.iconic.ipst.modelo.HCDoencasPreExistentes;



@Repository
public class HCDoencasPreExistentesDAO {

	
	@PersistenceContext
	private EntityManager manager;
	
	
	public void adiciona(HCDoencasPreExistentes doencas){
		manager.persist(doencas);	
	}
	
	@Transactional
	public void atualiza(HCDoencasPreExistentes doencas){
		manager.merge(doencas);
	}
	

/*	@SuppressWarnings("unchecked")
	public List<HCDoencasPreExistentes> ListaDoencasPreExistentes(){
		return manager.createQuery("select h from HCDoencasPreExistentes h").getResultList();
	}
	
	public HCDoencasPreExistentes buscaPorId(Long id){
		return manager.find(HCDoencasPreExistentes.class, id);
	}
	
	
	public void remove(HCDoencasPreExistentes doencas){
		HCDoencasPreExistentes doencasARemover = buscaPorId(doencas.getId_HCDoencasPreExistentes());
		manager.remove(doencasARemover);
		
	}*/

	@SuppressWarnings("unchecked")
	public HCDoencasPreExistentes buscaDoencasPreExistentesAvaliacao(Long idanalise) {
		
		Query query = manager.createQuery("select b from HCDoencasPreExistentes b JOIN b.analiseDador a WHERE a.id_AnaliseDador =:idanalise");
		query.setParameter("idanalise", idanalise);
		
		List<HCDoencasPreExistentes> results = query.getResultList();
		HCDoencasPreExistentes doencas = null;
		if(!results.isEmpty()){
			doencas = (HCDoencasPreExistentes) results.get(0);
		}
			
		return doencas;
	}
}
