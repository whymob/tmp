package pt.iconic.ipst.modelo;

import javax.persistence.Cacheable;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import org.hibernate.annotations.Cache;
import org.hibernate.annotations.CacheConcurrencyStrategy;


@Entity
@Table(name = "PERMISSAO_LOCALIZACAO")
@Cacheable(true)
@Cache(usage=CacheConcurrencyStrategy.NONSTRICT_READ_WRITE)
public class PermissaoLocalizacao {

	private Long Id_PermissaoLocalizacao;
	//private UtilizadorPosicao utilizadorposicao;
	private Posicao posicao;
	private Utilizador utilizador;
	private Hospital hospital;
	private boolean leituraescrita;
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="ID_PERMISSAOLOCALIZACAO")
	public Long getId_PermissaoLocalizacao() {
		return Id_PermissaoLocalizacao;
	}
	public void setId_PermissaoLocalizacao(Long id_PermissaoLocalizacao) {
		Id_PermissaoLocalizacao = id_PermissaoLocalizacao;
	}
	
	@ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "ID_POSICAO")
	public Posicao getPosicao() {
		return posicao;
	}
	public void setPosicao(Posicao posicao) {
		this.posicao = posicao;
	}
	
	@ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "ID_UTILIZADOR")
	public Utilizador getUtilizador() {
		return utilizador;
	}
	public void setUtilizador(Utilizador utilizador) {
		this.utilizador = utilizador;
	}
	
	@ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "ID_HOSPITAL")
	public Hospital getHospital() {
		return hospital;
	}
	public void setHospital(Hospital hospital) {
		this.hospital = hospital;
	}
	
	@Column(name="LEITURAESCRITA")
	public boolean isLeituraescrita() {
		return leituraescrita;
	}
	public void setLeituraescrita(boolean leituraescrita) {
		this.leituraescrita = leituraescrita;
	}
	
	
	
	
}
