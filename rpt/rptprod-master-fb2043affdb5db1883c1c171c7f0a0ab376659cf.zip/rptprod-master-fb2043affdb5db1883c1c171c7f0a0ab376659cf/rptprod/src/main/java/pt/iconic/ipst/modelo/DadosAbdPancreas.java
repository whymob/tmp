package pt.iconic.ipst.modelo;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name = "DADOSABDPANCREAS")
public class DadosAbdPancreas 
{
	private Long Id_DadosAbdPancreas;
	private String Tipo;
	private String Localizacao;
	private String Notas;
	private AnaliseDador analiseDador;
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="ID_DADOSABDPANCREAS")
	public Long getId_DadosAbdPancreas() {
		return Id_DadosAbdPancreas;
	}
	public void setId_DadosAbdPancreas(Long id_DadosAbdPancreas) {
		Id_DadosAbdPancreas = id_DadosAbdPancreas;
	}
	
	@Column(name="TIPO")
	public String getTipo() {
		return Tipo;
	}
	public void setTipo(String tipo) {
		Tipo = tipo;
	}
	
	@Column(name="LOCALIZACAO")
	public String getLocalizacao() {
		return Localizacao;
	}
	public void setLocalizacao(String localizacao) {
		Localizacao = localizacao;
	}
	
	@Column(name="NOTAS")
	public String getNotas() {
		return Notas;
	}
	public void setNotas(String notas) {
		Notas = notas;
	}
	
	@ManyToOne
	@JoinColumn(name="ID_ANALISEDADOR")
	public AnaliseDador getAnaliseDador() {
		return analiseDador;
	}
	public void setAnaliseDador(AnaliseDador analiseDador) {
		this.analiseDador = analiseDador;
	}
}