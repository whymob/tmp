package pt.iconic.ipst.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import pt.iconic.ipst.modelo.TransplantePancreasPerfusao;


@Repository
@Transactional
public class TransplantePancreasPerfusaoDAO {

	
	@PersistenceContext
	private EntityManager manager;
	
	
	public void adiciona(TransplantePancreasPerfusao transplante){
		manager.persist(transplante);	
	}
	

	public void atualiza(TransplantePancreasPerfusao transplante){
		manager.merge(transplante);
	}
	

/*	@SuppressWarnings("unchecked")
	public List<TransplantePancreasPerfusao> ListaTransplantePancreasPerfusao(){
		return manager.createQuery("select a from TransplantePancreasPerfusao a").getResultList();
	}*/
	
	public TransplantePancreasPerfusao buscaPorId(Long id){
		return manager.find(TransplantePancreasPerfusao.class, id);
	}
	
	
	public void remove(TransplantePancreasPerfusao transplante){
		TransplantePancreasPerfusao transplanteARemover = buscaPorId(transplante.getIdperfusaopancreas());
		manager.remove(transplanteARemover);
		
	}
	
	@SuppressWarnings("unchecked")
	public List<TransplantePancreasPerfusao> ListaTransplantePancreasPerfusaoassig(Long idassigorg){
		
		Query query = manager.createQuery("select p from TransplantePancreasPerfusao p JOIN p.assigorgao a WHERE a.id_assignacao =:idassigorg");
		query.setParameter("idassigorg", idassigorg);
		
		List<TransplantePancreasPerfusao> results = query.getResultList();

		return results;
		
	}
}
