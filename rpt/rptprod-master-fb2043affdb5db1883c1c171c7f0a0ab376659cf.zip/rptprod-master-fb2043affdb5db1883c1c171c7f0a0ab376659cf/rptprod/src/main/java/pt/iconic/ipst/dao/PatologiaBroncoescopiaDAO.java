package pt.iconic.ipst.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import pt.iconic.ipst.modelo.AnaliseDador;
import pt.iconic.ipst.modelo.PatologiaBroncoescopia;

@Repository
@Transactional
public class PatologiaBroncoescopiaDAO 
{
	@PersistenceContext
	private EntityManager manager;
	
/*	public void adiciona(PatologiaBroncoescopia patologiabronco){
		manager.persist(patologiabronco);	
	}*/
	
	@Transactional
	public void atualiza(PatologiaBroncoescopia patologiabronco){
		manager.merge(patologiabronco);
	}

/*	@SuppressWarnings("unchecked")
	public List<PatologiaBroncoescopia> PatologiaBroncoescopia(){
		return manager.createQuery("select d from PatologiaBroncoescopia d").getResultList();
	}*/
	
	public PatologiaBroncoescopia buscaPorId(Long id){
		return manager.find(PatologiaBroncoescopia.class, id);
	}
	
	public void remove(PatologiaBroncoescopia patologiabronco){
		PatologiaBroncoescopia lesoes = buscaPorId(patologiabronco.getId_PatologiaBroncoescopia());
		manager.remove(lesoes);
	}
	
	//adiciona a lesao � tabela
	@Transactional
	public boolean adicionalesao(String patologia, boolean t, boolean bd, boolean be, boolean bs,Long id_analise)
	{
		AnaliseDador analise = manager.find(AnaliseDador.class, id_analise);
		
		PatologiaBroncoescopia lesoes = new PatologiaBroncoescopia();
		lesoes.setBD(bd);
		lesoes.setBE(be);
		lesoes.setT(t);
		lesoes.setBS(bs);
		lesoes.setPatologia(patologia);
		lesoes.setAnaliseDador(analise);

		manager.persist(lesoes);
					
		return true;
	}
	
	//carrega as lesoes quando insere a ultima lesao para que as da ultima apare�am em cima
	@SuppressWarnings("unchecked")
	public List<PatologiaBroncoescopia> buscalesoesDescendente(Long idanalise)
	{		
		Query query = manager.createQuery("select a from PatologiaBroncoescopia a JOIN a.analiseDador an WHERE an.id_AnaliseDador =:idanalise");
		query.setParameter("idanalise", idanalise);

		List<PatologiaBroncoescopia> results = query.getResultList();

		return results;
	}
}
