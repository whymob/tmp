package pt.iconic.ipst.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import pt.iconic.ipst.modelo.Especialidade;



@Repository
@Transactional
public class EspecialidadesDAO {

	
	@PersistenceContext
	private EntityManager manager;
	
	
	public void adiciona(Especialidade especialidade){
		manager.persist(especialidade);	
	}
	
	public void atualiza(Especialidade especialidade){
		manager.merge(especialidade);
	}
	

	@SuppressWarnings("unchecked")
	public List<Especialidade> ListaEspecialidade(){
		return manager.createQuery("select e from Especialidade e").getResultList();
	}
	
	public Especialidade buscaPorId(Long id){
		return manager.find(Especialidade.class, id);
	}
	
	
	public void remove(Especialidade especialidade){
		Especialidade especialidadeARemover = buscaPorId(especialidade.getId_Especialidade());
		manager.remove(especialidadeARemover);
	}
	
/*	@SuppressWarnings("rawtypes")
	public Especialidade buscaespecialidadeutilizador(Long id){
//		System.out.println("Id utilizador:  "+id);
		Query query = manager.createQuery("select e from Especialidade e JOIN e.utilizadores u  WHERE u.ID_Utilizador =:id");
		//Query query = manager.createQuery("select e from Especialidade e JOIN e.utilizadores usersespec WHERE usersespec.utilizador.ID_Utilizador =:id");
		query.setParameter("id", id) ;
		
		List results = query.getResultList();
		Especialidade especialidade = null;
		if(!results.isEmpty()){
		    // ignores multiple results
			especialidade = (Especialidade) results.get(0);
		}
		
		//Especialidade esp = (Especialidade) query.getSingleResult();
		//System.out.println("Query id da especialidade:  "+esp.getId_Especialidade());
		return especialidade;
	}*/
	
	public boolean trataadicionar(String desc)
	{
		Query query = manager.createQuery("SELECT e FROM Especialidade e WHERE e.especialidade =:desc");
		query.setParameter("desc", desc);
		
		if(query.getResultList().isEmpty())
		{
			Especialidade esp = new Especialidade();
			esp.setEspecialidade(desc);;
			adiciona(esp);
			
			return true;
		}
		else
		{
			return false;
		}
	}
	
	public boolean trataalterar(Long id, String desc)
	{
		Query query = manager.createQuery("SELECT e FROM Especialidade e WHERE e.especialidade =:desc");
		query.setParameter("desc", desc);
		
		if(query.getResultList().isEmpty())
		{
			Especialidade esp = new Especialidade();
			esp.setEspecialidade(desc);;
			esp.setId_Especialidade(id);;
			atualiza(esp);
				
			return true;
		}
		else
		{
			return false;
		}
	}
	
	public boolean remover(Long id) 
	{
		Especialidade esp = new Especialidade();
		esp = buscaPorId(id);

		remove(esp);
		return true;
	}
	
}
