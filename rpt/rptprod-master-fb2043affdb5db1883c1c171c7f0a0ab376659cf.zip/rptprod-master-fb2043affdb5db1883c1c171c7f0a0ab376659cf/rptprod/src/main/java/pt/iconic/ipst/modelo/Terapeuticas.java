package pt.iconic.ipst.modelo;

import java.util.Calendar;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name="TERAPEUTICAS")
public class Terapeuticas {

	
	private Long id_terapeutica;
	private AnaliseDador analiseDador;
	private TipoTerapeuticas tipoTerapeuticas;
	private float doseterapeutica;
//	private int QtdUnidades;
//	private UnidadesTerapeuticas unidadesTerapeuticas;
	private Calendar datahoraterapeutica;
//	private String TP;
	private String obsterapeutica;
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="ID_TERAPEUTICAS")
	public Long getId_terapeutica() {
		return id_terapeutica;
	}
	public void setId_terapeutica(Long id_terapeutica) {
		this.id_terapeutica = id_terapeutica;
	}
	
    @ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name="ID_ANALISEDADOR")
	public AnaliseDador getAnaliseDador() {
		return analiseDador;
	}
	public void setAnaliseDador(AnaliseDador analiseDador) {
		this.analiseDador = analiseDador;
	}
	
    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "ID_TIPOTERAPEUTICAS")
	public TipoTerapeuticas getTipoTerapeuticas() {
		return tipoTerapeuticas;
	}
	public void setTipoTerapeuticas(TipoTerapeuticas tipoTerapeuticas) {
		this.tipoTerapeuticas = tipoTerapeuticas;
	}
	
	@Column(name="DOSETERAPEUTICA")
	public float getDoseterapeutica() {
		return doseterapeutica;
	}
	public void setDoseterapeutica(float doseterapeutica) {
		this.doseterapeutica = doseterapeutica;
	}
	
//	@Column(name="QTDUNIDADES")
//	public int getQtdUnidades() {
//		return QtdUnidades;
//	}
//	public void setQtdUnidades(int qtdUnidades) {
//		QtdUnidades = qtdUnidades;
//	}
	
//    @ManyToOne(fetch = FetchType.EAGER)
//    @JoinColumn(name = "ID_UNIDADESTERAPEUTICAS")
//	public UnidadesTerapeuticas getUnidadesTerapeuticas() {
//		return unidadesTerapeuticas;
//	}
//	public void setUnidadesTerapeuticas(UnidadesTerapeuticas unidadesTerapeuticas) {
//		this.unidadesTerapeuticas = unidadesTerapeuticas;
//	}
	
	@Column(name="DATAHORATERAPEUTICAS")
	public Calendar getDatahoraterapeutica() {
		return datahoraterapeutica;
	}
	public void setDatahoraterapeutica(Calendar datahoraterapeutica) {
		this.datahoraterapeutica = datahoraterapeutica;
	}
	
//	@Column(name="TP")
//	public String getTP() {
//		return TP;
//	}
//	public void setTP(String tP) {
//		TP = tP;
//	}
	
	@Column(name="OBSTERAPEUTICAS")
	public String getObsterapeutica() {
		return obsterapeutica;
	}
	public void setObsterapeutica(String obsterapeutica) {
		this.obsterapeutica = obsterapeutica;
	}
	
}
