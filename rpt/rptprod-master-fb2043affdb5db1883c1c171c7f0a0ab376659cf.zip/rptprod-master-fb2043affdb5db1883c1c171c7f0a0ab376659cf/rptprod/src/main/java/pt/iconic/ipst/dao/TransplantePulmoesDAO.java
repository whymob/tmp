package pt.iconic.ipst.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import pt.iconic.ipst.modelo.TransplantePulmoes;

@Repository
@Transactional
public class TransplantePulmoesDAO {

	@PersistenceContext
	private EntityManager manager;
	
	public void adiciona(TransplantePulmoes transplante){
		manager.persist(transplante);	
	}
	
	public void atualiza(TransplantePulmoes transplante){
		manager.merge(transplante);
	}
	
/*	@SuppressWarnings("unchecked")
	public List<TransplantePulmoes> ListaTransplantePulmoes(){
		return manager.createQuery("select a from TransplantePulmoes a").getResultList();
	}*/
	
	public TransplantePulmoes buscaPorId(Long id){
		return manager.find(TransplantePulmoes.class, id);
	}
	
/*	public void remove(TransplantePulmoes transplante){
		TransplantePulmoes transplanteARemover = buscaPorId(transplante.getIdtransplantepulmoes());
		manager.remove(transplanteARemover);
	}*/
	
	@SuppressWarnings("unchecked")
	public TransplantePulmoes buscaTransplantePulmoesAssigorgao(Long idassigorg){
		
		Query query = manager.createQuery("select p from TransplantePulmoes p JOIN p.assigorgao a WHERE a.id_assignacao =:idassigorg");
		query.setParameter("idassigorg", idassigorg);
		
		List<TransplantePulmoes> results = query.getResultList();
		TransplantePulmoes transplante = null;
		if(!results.isEmpty()){
			transplante = (TransplantePulmoes) results.get(0);
		}
		return transplante;
	}
}
