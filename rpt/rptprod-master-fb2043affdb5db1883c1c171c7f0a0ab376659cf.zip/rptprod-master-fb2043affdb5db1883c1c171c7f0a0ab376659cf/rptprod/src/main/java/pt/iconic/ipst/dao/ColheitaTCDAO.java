package pt.iconic.ipst.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import pt.iconic.ipst.modelo.ColheitaTC;

@Repository
@Transactional
public class ColheitaTCDAO {

	@PersistenceContext
	private EntityManager manager;
	
	public void adiciona(ColheitaTC colheita){
		manager.persist(colheita);	
	}
	

	public void atualiza(ColheitaTC colheita){
		manager.merge(colheita);
	}
	

/*	@SuppressWarnings("unchecked")
	public List<ColheitaTC> ListaColheitaTC(){
		return manager.createQuery("select a from ColheitaTC a").getResultList();
	}*/
	
/*	public ColheitaTC buscaPorId(Long id){
		return manager.find(ColheitaTC.class, id);
	}
	
	
	public void remove(ColheitaTC colheita){
		ColheitaTC colheitaARemover = buscaPorId(colheita.getIdcolheitatc());
		manager.remove(colheitaARemover);
		
	}*/
	
	@SuppressWarnings("unchecked")
	public ColheitaTC buscacolheitaTCanalise(Long idanalise){
		
		Query query = manager.createQuery("select b from ColheitaTC b JOIN b.analiseDador a WHERE a.id_AnaliseDador =:idanalise");
		query.setParameter("idanalise", idanalise);
		
		List<ColheitaTC> results = query.getResultList();
		ColheitaTC colheita = null;
		if(!results.isEmpty()){
			colheita = (ColheitaTC) results.get(0);
		}
		return colheita;
		
	}
}
