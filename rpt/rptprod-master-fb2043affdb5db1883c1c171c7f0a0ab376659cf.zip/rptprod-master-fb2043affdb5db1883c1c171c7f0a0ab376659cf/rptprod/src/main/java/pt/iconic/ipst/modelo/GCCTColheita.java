package pt.iconic.ipst.modelo;

import java.util.Calendar;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name = "GCCTCOLHEITA")
public class GCCTColheita 
{
	private Long idgcctcolheita;
	private Entidade entidade;
	private Hospital hospital;
	private Dador dador;
	private AnaliseDador analiseDador;
	private Calendar datacolheita;
	private String ato;
	private String tipo;
	private String codigodador;
	private int estado;
	private List<GCCTColheitaDetalhe> gcctcolheitadetalhe;
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="ID_GCCTCOLHEITA")
	public Long getIdgcctcolheita() {
		return idgcctcolheita;
	}
	public void setIdgcctcolheita(Long idgcctcolheita) {
		this.idgcctcolheita = idgcctcolheita;
	}
	
	@ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "ID_ENTIDADE")
	public Entidade getEntidade() {
		return entidade;
	}
	public void setEntidade(Entidade entidade) {
		this.entidade = entidade;
	}
	
	@ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "ID_HOSPITAL")
	public Hospital getHospital() {
		return hospital;
	}
	public void setHospital(Hospital hospital) {
		this.hospital = hospital;
	}
	
	@ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "ID_DADOR")
	public Dador getDador() {
		return dador;
	}
	public void setDador(Dador dador) {
		this.dador = dador;
	}
	
	@Column(name="DATA")
	public Calendar getDatacolheita() {
		return datacolheita;
	}
	public void setDatacolheita(Calendar datacolheita) {
		this.datacolheita = datacolheita;
	}
	
	@Column(name="ATO")
	public String getAto() {
		return ato;
	}
	public void setAto(String ato) {
		this.ato = ato;
	}
	
	@Column(name="TIPO")
	public String getTipo() {
		return tipo;
	}
	public void setTipo(String tipo) {
		this.tipo = tipo;
	}
	
	@Column(name="CODIGODADOR")
	public String getCodigodador() {
		return codigodador;
	}
	public void setCodigodador(String codigodador) {
		this.codigodador = codigodador;
	}
	
	@Column(name="ESTADO")
	public int getEstado() {
		return estado;
	}
	public void setEstado(int estado) {
		this.estado = estado;
	}
	
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="ID_ANALISEDADOR")
	public AnaliseDador getAnaliseDador() {
		return analiseDador;
	}
	public void setAnaliseDador(AnaliseDador analisedador) {
		this.analiseDador = analisedador;
	}
	
	@OneToMany(fetch = FetchType.LAZY, mappedBy = "gcctcolheita")
	public List<GCCTColheitaDetalhe> getGcctcolheitadetalhe() {
		return gcctcolheitadetalhe;
	}
	public void setGcctcolheitadetalhe(List<GCCTColheitaDetalhe> gcctcolheitadetalhe) {
		this.gcctcolheitadetalhe = gcctcolheitadetalhe;
	}
}