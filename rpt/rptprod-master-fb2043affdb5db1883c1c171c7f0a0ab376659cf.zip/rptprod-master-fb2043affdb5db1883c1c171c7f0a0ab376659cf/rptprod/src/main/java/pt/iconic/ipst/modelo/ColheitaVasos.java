package pt.iconic.ipst.modelo;

import java.util.Calendar;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name = "COLHEITA_VASOS")
public class ColheitaVasos {

	private Long idcolheitavasos;
	private Calendar iniciovasos;
	private Calendar fimvasos;
	private String notasvasos;
	private int bifurcretirada;
	private int segmildirretirada;
	private int segmilesqretirada;
	private int aortatoracretirada;
	private int aortaabdomretirada;
	private int outrosretirada;
	private AnaliseDador analiseDador;
	private String codvasos;
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="ID_COLHEITA_VASOS")
	public Long getIdcolheitavasos() {
		return idcolheitavasos;
	}
	public void setIdcolheitavasos(Long idcolheitavasos) {
		this.idcolheitavasos = idcolheitavasos;
	}
	
	@Column(name="INICIO")
	public Calendar getIniciovasos() {
		return iniciovasos;
	}
	public void setIniciovasos(Calendar iniciovasos) {
		this.iniciovasos = iniciovasos;
	}
	
	@Column(name="FIM")
	public Calendar getFimvasos() {
		return fimvasos;
	}
	public void setFimvasos(Calendar fimvasos) {
		this.fimvasos = fimvasos;
	}
	
	@Column(name="NOTAS")
	public String getNotasvasos() {
		return notasvasos;
	}
	public void setNotasvasos(String notasvasos) {
		this.notasvasos = notasvasos;
	}
	
	@Column(name="BIFURC_RETIRADA")
	public int getBifurcretirada() {
		return bifurcretirada;
	}
	public void setBifurcretirada(int bifurcretirada) {
		this.bifurcretirada = bifurcretirada;
	}
	
	@Column(name="SEGM_IL_DIR_RETIRADO")
	public int getSegmildirretirada() {
		return segmildirretirada;
	}
	public void setSegmildirretirada(int segmildirretirada) {
		this.segmildirretirada = segmildirretirada;
	}
	
	@Column(name="SEGM_IL_ESQ_RETIRADO")
	public int getSegmilesqretirada() {
		return segmilesqretirada;
	}
	public void setSegmilesqretirada(int segmilesqretirada) {
		this.segmilesqretirada = segmilesqretirada;
	}
	
	@Column(name="AORTA_TORAC_RETIRADA")
	public int getAortatoracretirada() {
		return aortatoracretirada;
	}
	public void setAortatoracretirada(int aortatoracretirada) {
		this.aortatoracretirada = aortatoracretirada;
	}
	
	@Column(name="AORTA_ABDOM_RETIRADA")
	public int getAortaabdomretirada() {
		return aortaabdomretirada;
	}
	public void setAortaabdomretirada(int aortaabdomretirada) {
		this.aortaabdomretirada = aortaabdomretirada;
	}
	
	@Column(name="OUTROS_RETIRADA")
	public int getOutrosretirada() {
		return outrosretirada;
	}
	public void setOutrosretirada(int outrosretirada) {
		this.outrosretirada = outrosretirada;
	}
	
	@OneToOne(fetch=FetchType.EAGER)
	@JoinColumn(name="ID_ANALISEDADOR")
	public AnaliseDador getAnaliseDador() {
		return analiseDador;
	}
	public void setAnaliseDador(AnaliseDador analiseDador) {
		this.analiseDador = analiseDador;
	}
	
	@Column(name="COD_VASOS")
	public String getCodvasos() {
		return codvasos;
	}
	public void setCodvasos(String codvasos) {
		this.codvasos = codvasos;
	}
	
}
