package pt.iconic.ipst.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import pt.iconic.ipst.modelo.ColheitaPancreasProduto;

@Repository
@Transactional
public class ColheitaPancreasProdutoDAO {

	@PersistenceContext
	private EntityManager manager;
	
	
	public void adiciona(ColheitaPancreasProduto colheita){
		manager.persist(colheita);	
	}
	

	public void atualiza(ColheitaPancreasProduto colheita){
		manager.merge(colheita);
	}
	
/*
	@SuppressWarnings("unchecked")
	public List<ColheitaPancreasProduto> ListaColheitaPancreasProduto(){
		return manager.createQuery("select a from ColheitaPancreasProduto a").getResultList();
	}*/
	
	public ColheitaPancreasProduto buscaPorId(Long id){
		return manager.find(ColheitaPancreasProduto.class, id);
	}
	
	
	public void remove(ColheitaPancreasProduto colheita){
		ColheitaPancreasProduto colheitaARemover = buscaPorId(colheita.getIdcolheitapancreasproduto());
		manager.remove(colheitaARemover);
		
	}
	
	@SuppressWarnings("unchecked")
	public List<ColheitaPancreasProduto> listacolheitapancreasprodutoanalise(Long idanalise){
		
		Query query = manager.createQuery("select b from ColheitaPancreasProduto b JOIN b.analiseDador a WHERE a.id_AnaliseDador =:idanalise");
		query.setParameter("idanalise", idanalise);
		
		List<ColheitaPancreasProduto> results = query.getResultList();
		return results;
		
	}
}
