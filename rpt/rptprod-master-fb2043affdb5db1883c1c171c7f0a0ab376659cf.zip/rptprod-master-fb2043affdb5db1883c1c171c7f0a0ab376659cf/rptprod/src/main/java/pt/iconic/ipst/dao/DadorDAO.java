package pt.iconic.ipst.dao;

import java.math.BigInteger;
import java.util.Calendar;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import pt.iconic.ipst.modelo.AnaliseDador;
import pt.iconic.ipst.modelo.Dador;


@Repository
@Transactional
public class DadorDAO {
	
	@PersistenceContext
	private EntityManager manager;
	
	
	public void adiciona(Dador dador){
		manager.persist(dador);	
	}
	
	public void atualiza(Dador dador){
		manager.merge(dador);
	}
	

	@SuppressWarnings("unchecked")
	public List<Dador> ListaDador(){
		return manager.createQuery("select d from Dador d").getResultList();
	}
	
	public Dador buscaPorId(Long id){
		return manager.find(Dador.class, id);
	}
	
	
/*	public void remove(Dador dador){
		Dador dadorARemover = buscaPorId(dador.getId_Dador());
		manager.remove(dadorARemover);
	}*/

/*	public boolean existeUtilizador(Dador dador) 
	{
			Query query = manager.createQuery("SELECT d FROM Dador d WHERE d.nomeDador =:nomeDador");
			query.setParameter("nomeDador", dador.getNomeDador()) ;
			if(query.getResultList().isEmpty()){
				return false;
			}else{
				return true;
			}
	}*/

	@SuppressWarnings("unchecked")
	public List<Dador> ListaDadorPermissao(Long idposicao, Long idutilizador, Long idhospital) {
		List<Dador> out = null;
		
		Query query = manager.createQuery("select d from Dador d join d.hospital hospital join hospital.permissoes permissao JOIN d.estadoDador estado WHERE hospital.id_Hospital =:idhospital AND permissao.posicao.id_Posicao =:idposicao AND permissao.utilizador.ID_Utilizador = :idutilizador AND (estado.estado =:estado2 Or estado.estado =:estado3 Or estado.estado =:estado4)");
		
		//String sql = "select distinct POSICAO.* from POSICAO inner join PERMISSAO_LOCALIZACAO on (PERMISSAO_LOCALIZACAO.ID_POSICAO = POSICAO.ID_POSICAO) "
		//		+ "inner join UTILIZADOR on (PERMISSAO_LOCALIZACAO.ID_UTILIZADOR = UTILIZADOR.ID_UTILIZADOR) "
		//		+ "where UTILIZADOR.ID_UTILIZADOR = :idutilizador";
		//Query query = manager.createNativeQuery(sql, Hospital.class);
		query.setParameter("idposicao", idposicao);
		query.setParameter("idhospital", idhospital);
		query.setParameter("idutilizador", idutilizador);	
		query.setParameter("estado2", "Poss�vel Dador");
		query.setParameter("estado3", "Validado");
		query.setParameter("estado4", "Em avalia��o");
		
		out = query.getResultList();

		return out;
	}
	
	@SuppressWarnings("unchecked")
	public List<Dador> ListaDadorPermissaoFiltrado(Long idposicao, Long idutilizador, int tipo, Calendar dataum, Calendar datadois, Long idhospital) {
		List<Dador> out = null;
		
	//	System.out.println("tipo: "+tipo);
		//ESTADO VALIDADO E EM AVALIA��O   --> Apenas ativos
		if(tipo == 1)
		{
			
			//Query query = manager.createQuery("select d from Dador d join d.hospital hospital join hospital.permissoes permissao JOIN d.estadoDador estado WHERE hospital.id_Hospital =:idhospital AND permissao.posicao.id_Posicao =:idposicao AND permissao.utilizador.ID_Utilizador = :idutilizador AND (estado.estado =:estado4 Or estado.estado =:estado3) AND (d.dataregisto BETWEEN :date AND :date2)");
			Query query = manager.createNativeQuery("select d.* from Dador d inner join HOSPITAL h on (h.ID_HOSPITAL = d.ID_HOSPITAL) "
					+ "inner join PERMISSAO_LOCALIZACAO permissao on (permissao.ID_HOSPITAL = h.ID_HOSPITAL) "
					+ "inner join ESTADODADOR estado on (estado.ID_ESTADODADOR = d.ID_ESTADODADOR) "
					+ "WHERE h.ID_HOSPITAL =:idhospital AND permissao.ID_POSICAO =:idposicao AND permissao.ID_Utilizador = :idutilizador AND (estado.estado =:estado4 Or estado.estado =:estado3) AND (cast(d.dataregisto  as date) BETWEEN :date AND :date2)", Dador.class);
			query.setParameter("idposicao", idposicao);
			query.setParameter("idhospital", idhospital);
			query.setParameter("idutilizador", idutilizador);	
			query.setParameter("estado3", "Validado");
			query.setParameter("estado4", "Em avalia��o");
			query.setParameter("date", dataum);
			query.setParameter("date2", datadois);
			
			out = query.getResultList();
		}
		//ESTADO EM AVALIA��O --> Possivel dador
		else if(tipo == 2)
		{
		//	Query query = manager.createQuery("select d from Dador d join d.hospital hospital join hospital.permissoes permissao JOIN d.estadoDador estado WHERE hospital.id_Hospital =:idhospital AND permissao.posicao.id_Posicao =:idposicao AND permissao.utilizador.ID_Utilizador = :idutilizador AND (estado.estado =:estado4) AND (d.dataregisto BETWEEN :date AND :date2)");
			Query query = manager.createNativeQuery("select d.* from Dador d inner join HOSPITAL h on (h.ID_HOSPITAL = d.ID_HOSPITAL) "
					+ "inner join PERMISSAO_LOCALIZACAO permissao on (permissao.ID_HOSPITAL = h.ID_HOSPITAL) "
					+ "inner join ESTADODADOR estado on (estado.ID_ESTADODADOR = d.ID_ESTADODADOR) "
					+ "WHERE h.ID_HOSPITAL =:idhospital AND permissao.ID_POSICAO =:idposicao AND permissao.ID_Utilizador = :idutilizador AND (estado.estado =:estado4) AND (cast(d.dataregisto  as date) BETWEEN :date AND :date2)", Dador.class);
			
			
			
			query.setParameter("idposicao", idposicao);
			query.setParameter("idhospital", idhospital);
			query.setParameter("idutilizador", idutilizador);	
			query.setParameter("estado4", "Poss�vel dador");
			query.setParameter("date", dataum);
			query.setParameter("date2", datadois);
			
			out = query.getResultList();
		}
		//ESTADO VALIDADO --> Em avalia��o
		else if(tipo == 3)
		{
		//	Query query = manager.createQuery("select d from Dador d join d.hospital hospital join hospital.permissoes permissao JOIN d.estadoDador estado WHERE hospital.id_Hospital =:idhospital AND permissao.posicao.id_Posicao =:idposicao AND permissao.utilizador.ID_Utilizador = :idutilizador AND (estado.estado =:estado4) AND (d.dataregisto BETWEEN :date AND :date2)");
			Query query = manager.createNativeQuery("select d.* from Dador d inner join HOSPITAL h on (h.ID_HOSPITAL = d.ID_HOSPITAL) "
					+ "inner join PERMISSAO_LOCALIZACAO permissao on (permissao.ID_HOSPITAL = h.ID_HOSPITAL) "
					+ "inner join ESTADODADOR estado on (estado.ID_ESTADODADOR = d.ID_ESTADODADOR) "
					+ "WHERE h.ID_HOSPITAL =:idhospital AND permissao.ID_POSICAO =:idposicao AND permissao.ID_Utilizador = :idutilizador AND (estado.estado =:estado4) AND (cast(d.dataregisto  as date) BETWEEN :date AND :date2)", Dador.class);
			query.setParameter("idposicao", idposicao);
			query.setParameter("idhospital", idhospital);
			query.setParameter("idutilizador", idutilizador);	
			query.setParameter("estado4", "Em avalia��o");
			query.setParameter("date", dataum);
			query.setParameter("date2", datadois);
			
			out = query.getResultList();
		}
		//ESTADO COLHEITA --> Validado
		else if(tipo == 4)
		{
	//		Query query = manager.createQuery("select d from Dador d join d.hospital hospital join hospital.permissoes permissao JOIN d.estadoDador estado WHERE hospital.id_Hospital =:idhospital AND permissao.posicao.id_Posicao =:idposicao AND permissao.utilizador.ID_Utilizador = :idutilizador AND (estado.estado =:estado4) AND (d.dataregisto BETWEEN :date AND :date2)");
			Query query = manager.createNativeQuery("select d.* from Dador d inner join HOSPITAL h on (h.ID_HOSPITAL = d.ID_HOSPITAL) "
					+ "inner join PERMISSAO_LOCALIZACAO permissao on (permissao.ID_HOSPITAL = h.ID_HOSPITAL) "
					+ "inner join ESTADODADOR estado on (estado.ID_ESTADODADOR = d.ID_ESTADODADOR) "
					+ "WHERE h.ID_HOSPITAL =:idhospital AND permissao.ID_POSICAO =:idposicao AND permissao.ID_Utilizador = :idutilizador AND (estado.estado =:estado4) AND (cast(d.dataregisto  as date) BETWEEN :date AND :date2)", Dador.class);	
			query.setParameter("idposicao", idposicao);
			query.setParameter("idhospital", idhospital);
			query.setParameter("idutilizador", idutilizador);	
			query.setParameter("estado4", "Validado");
			query.setParameter("date", dataum);
			query.setParameter("date2", datadois);
			
			out = query.getResultList();
		}
		//ESTADO INV�LIDO --> N�o validado
		else if(tipo == 5)
		{
		//	Query query = manager.createQuery("select d from Dador d join d.hospital hospital join hospital.permissoes permissao JOIN d.estadoDador estado WHERE hospital.id_Hospital =:idhospital AND permissao.posicao.id_Posicao =:idposicao AND permissao.utilizador.ID_Utilizador = :idutilizador AND (estado.estado =:estado4) AND (d.dataregisto BETWEEN :date AND :date2)");
			Query query = manager.createNativeQuery("select d.* from Dador d inner join HOSPITAL h on (h.ID_HOSPITAL = d.ID_HOSPITAL) "
					+ "inner join PERMISSAO_LOCALIZACAO permissao on (permissao.ID_HOSPITAL = h.ID_HOSPITAL) "
					+ "inner join ESTADODADOR estado on (estado.ID_ESTADODADOR = d.ID_ESTADODADOR) "
					+ "WHERE h.ID_HOSPITAL =:idhospital AND permissao.ID_POSICAO =:idposicao AND permissao.ID_Utilizador = :idutilizador AND (estado.estado =:estado4) AND (cast(d.dataregisto  as date) BETWEEN :date AND :date2)", Dador.class);
			
			query.setParameter("idposicao", idposicao);
			query.setParameter("idhospital", idhospital);
			query.setParameter("idutilizador", idutilizador);	
			query.setParameter("estado4", "Inv�lido");
			query.setParameter("date", dataum);
			query.setParameter("date2", datadois);
			
			out = query.getResultList();
		}
		//ESTADO COLHEITA
		else if(tipo == 6)
		{
		//	Query query = manager.createQuery("select d from Dador d join d.hospital hospital join hospital.permissoes permissao JOIN d.estadoDador estado WHERE hospital.id_Hospital =:idhospital AND permissao.posicao.id_Posicao =:idposicao AND permissao.utilizador.ID_Utilizador = :idutilizador AND (estado.estado =:estado4) AND (d.dataregisto BETWEEN :date AND :date2)");
			Query query = manager.createNativeQuery("select d.* from Dador d inner join HOSPITAL h on (h.ID_HOSPITAL = d.ID_HOSPITAL) "
					+ "inner join PERMISSAO_LOCALIZACAO permissao on (permissao.ID_HOSPITAL = h.ID_HOSPITAL) "
					+ "inner join ESTADODADOR estado on (estado.ID_ESTADODADOR = d.ID_ESTADODADOR) "
					+ "WHERE h.ID_HOSPITAL =:idhospital AND permissao.ID_POSICAO =:idposicao AND permissao.ID_Utilizador = :idutilizador AND (estado.estado =:estado4) AND (cast(d.dataregisto  as date) BETWEEN :date AND :date2)", Dador.class);
			query.setParameter("idposicao", idposicao);
			query.setParameter("idhospital", idhospital);
			query.setParameter("idutilizador", idutilizador);	
			query.setParameter("estado4", "Colheita efetuada");
			query.setParameter("date", dataum);
			query.setParameter("date2", datadois);
					
			out = query.getResultList();
		}
		
		return out;
	}
	
	@SuppressWarnings("unchecked")
	public boolean verificaexisteavaliacao(Long id){		
		
		Query query = manager.createQuery("select a from AnaliseDador a JOIN a.dador dador WHERE dador.id_Dador =:iddador");
		query.setParameter("iddador", id);

		List<AnaliseDador> results = query.getResultList();
		if(!results.isEmpty()){
		   return true;
	
		}else{
		return false;
		}
	}
	
	@SuppressWarnings("unchecked")
	public Dador buscadadoranalise(Long id_analise){
		Query query = manager.createQuery("select b from Dador b JOIN b.analiseDador a WHERE a.id_AnaliseDador =:idanalise");
		query.setParameter("idanalise", id_analise);
		
		List<Dador> results = query.getResultList();
		Dador dador = null;
		if(!results.isEmpty()){
			dador = (Dador) results.get(0);
		}
		
		return dador;
	}


	public String buscaultimocodigodador2(int ano) {
				
				String query = "select  MAX(right(DADOR.CODIGODADOR,6)) from DADOR where right(left(DADOR.CODIGODADOR,6),4) = :ano";
			
				Query query2 = manager.createNativeQuery(query);
				query2.setParameter("ano", ano);
				
				return (String) query2.getSingleResult();	
			}
	
	//muda estado dador RENNDA avalia��o inicial
	public int mudaestadodador(int estado, Long id_analise) {
		
		Long id = buscadadoranalise(id_analise).getId_Dador();
		Query query;
		if(estado == 5){
			query = manager.createNativeQuery("Update DADOR SET ID_ESTADODADOR=:estado, MOTIVOESTADO='Consta no RENNDA' " +
		            " Where ID_DADOR=:id_dador");	
		}
		else{
	    query = manager.createNativeQuery("Update DADOR SET ID_ESTADODADOR=:estado" +
	            " Where ID_DADOR=:id_dador");
		}
	        query.setParameter("estado", estado);
	        query.setParameter("id_dador", id);
	        return query.executeUpdate();
	}
	
	//muda estado dador RENNDA avalia��o inicial
	public int mudaestadodadorcolheita(int estado, Long id_analise) {
		
		Long id = buscadadoranalise(id_analise).getId_Dador();
		Query query;

	    query = manager.createNativeQuery("Update DADOR SET ID_ESTADODADOR=:estado" +
	            " Where ID_DADOR=:id_dador");
	        query.setParameter("estado", estado);
	        query.setParameter("id_dador", id);
	        return query.executeUpdate();
	}
	

	@SuppressWarnings("unchecked")
	public List<Object> listaatribuicoes(Long id_hospital) {
		
		List<Object> out = null;
		
/*		Query query = manager.createNativeQuery("select ANALISEDADOR.ID_ANALISEDADOR , dador.ID_DADOR, dador.CODIGODADOR, ESTADODADOR.ESTADO, "
				+ "(select STUFF( Case When BDORGAOS.CORACAO = 'True' Then '-CO' Else '' End"
				+ " + Case When BDORGAOS.FIGADO = 'True' Then '-FI' Else '' End"
				+ "	 +  Case When BDORGAOS.RIMESQUERDO = 'True' Then '-RIE' Else '' End"
				+ "	 +  Case When BDORGAOS.RIMDIREITO = 'True' Then '-RID' Else '' End"
				+ "	+ Case When BDORGAOS.PANCREAS = 'True' Then '-PA' Else '' End"
				+ "	+  Case When BDORGAOS.PULMAODIR = 'True' Then '-PUD' Else '' End"
				+ "	+  Case When BDORGAOS.PULMAOESQ = 'True' Then '-PUE' Else '' End,1,1,'') "
				+ "from BDORGAOS where BDORGAOS.ID_ANALISEDADOR =ANALISEDADOR.ID_ANALISEDADOR) AS ORGAOS "
				+ ", (select count(ao.ID_ASSIGNACAO_ORGAOS) from ASSIGNACAO_ORGAOS ao "
				+ "inner join DADOR dd on (dd.ID_DADOR = ao.ID_DADOR) "
				+ "where dd.ID_HOSPITAL = :id_hospital and dd.ID_DADOR = dador.ID_DADOR and ao.ID_ORGAOOFERTA<10) as 'Total Org�os', "
				+ "el.SALA as 'SALA' ,"
				+ "(Case when (select count(ec.ID_EQUIPA_CIRURGIA) from EQUIPA_CIRURGIA ec where ec.ID_DADOR = dador.ID_DADOR AND ec.INICIO<>99)>0 then 'OK' else NULL end) as 'EQUIPA'"
				+ ",(select TOP 1 eh.ESTADO from HISTORICO_ASSIGNACAO ha "
				+ "inner join ESTADO_ASSIGNACAO_HOSPITAL eh on (eh.ID_ESTADO = ha.ID_ESTADO_ASSIG) "
				+ "where ha.ID_DADOR = dador.ID_DADOR AND ha.DATAHISTORICO = (Select MAX(ha.DATAHISTORICO) from HISTORICO_ASSIGNACAO ha where ha.ID_DADOR = dador.ID_DADOR)) as 'STATUS' "
				+ ", (select count(distinct(oo.NOME_ORGAO)) from ASSIGNACAO_ORGAOS ao "
				+ "inner join ORGAOS_OFERTA oo on (oo.ID_ORGAO_OFERTA = ao.ID_ORGAOOFERTA) "
				+ "inner join ASSIGNACAO_HOSPITAL ah on (ah.ID_ASSIGNACAO_ORGAO = ao.ID_ASSIGNACAO_ORGAOS) "
				+ "inner join DADOR dd on (dd.ID_DADOR = ao.ID_DADOR) "
				+ "where dd.ID_HOSPITAL = :id_hospital and dd.ID_DADOR = dador.ID_DADOR) as 'Oferecidos' , "
				+ "(Select count(ao.ID_ASSIGNACAO_ORGAOS) "
				+ "from  ASSIGNACAO_HOSPITAL ah "
				+ "inner join ASSIGNACAO_ORGAOS ao on (ao.ID_ASSIGNACAO_ORGAOS = ah.ID_ASSIGNACAO_ORGAO) "
				+ "where ah.ID_ESTADO = 3 and ao.ID_DADOR = dador.ID_DADOR) as 'Aceites', "
				+ "(Select count(distinct(ao.ID_ASSIGNACAO_ORGAOS)) "
				+ "from  ASSIGNACAO_HOSPITAL ah "
				+ "inner join ASSIGNACAO_ORGAOS ao on (ao.ID_ASSIGNACAO_ORGAOS = ah.ID_ASSIGNACAO_ORGAO) "
				+ "where (ah.ID_ESTADO = 2 and ao.ID_DADOR = dador.ID_DADOR) OR (ah.ID_ESTADO = 6 and ao.ID_DADOR = dador.ID_DADOR)) as 'N�o Aceites', "
				+ "(select (Case When (BDORGAOS.RIMESQUERDO = 'True' and BDORGAOS.RIMDIREITO = 'True') Then 1 Else 0 End) from  BDORGAOS where BDORGAOS.ID_ANALISEDADOR =ANALISEDADOR.ID_ANALISEDADOR) as 'Rins', "
				+ "(select (Case When (BDORGAOS.PULMAODIR = 'True' and BDORGAOS.PULMAOESQ = 'True') Then 1 Else 0 End) from  BDORGAOS where BDORGAOS.ID_ANALISEDADOR =ANALISEDADOR.ID_ANALISEDADOR) as 'Pulm�es' "
				+ "from DADOR dador "
				+ "left join EQUIPA_LOCAL el on (el.ID_DADOR = dador.ID_DADOR) "
				+ "inner join ESTADODADOR on (DADOR.ID_ESTADODADOR = ESTADODADOR.ID_ESTADODADOR) "
				+ "inner join ANALISEDADOR on (ANALISEDADOR.ID_DADOR = DADOR.ID_DADOR) "
				+ "inner join BDORGAOS on (BDORGAOS.ID_ANALISEDADOR = ANALISEDADOR.ID_ANALISEDADOR) "
			//	+ "inner join BDAVALIACAOINICIAL av on (av.ID_ANALISEDADOR = ANALISEDADOR.ID_ANALISEDADOR) "
				+ "where DADOR.ID_HOSPITAL=:id_hospital AND (ESTADODADOR.ID_ESTADODADOR =2 OR ESTADODADOR.ID_ESTADODADOR =3 OR ESTADODADOR.ID_ESTADODADOR =4)"
			//	+ " AND av.STATUSRENNDA <> 2 "
				);*/
		
		
		Query query = manager.createNativeQuery("select ANALISEDADOR.ID_ANALISEDADOR , dador.ID_DADOR, dador.CODIGODADOR, ESTADODADOR.ESTADO, "
				+ "(select STUFF( Case When BDORGAOS.CORACAO = 'True' Then '-CO' Else '' End "
				+ " + Case When BDORGAOS.FIGADO = 'True' Then '-FI' Else '' End "
				+ "+  Case When BDORGAOS.RIMESQUERDO = 'True' Then '-RIE' Else '' End	"
				+ " +  Case When BDORGAOS.RIMDIREITO = 'True' Then '-RID' Else '' End "
				+ "	+ Case When BDORGAOS.PANCREAS = 'True' Then '-PA' Else '' End "
				+ " 	+  Case When BDORGAOS.PULMAODIR = 'True' Then '-PUD' Else '' End "
				+ " 	+  Case When BDORGAOS.PULMAOESQ = 'True' Then '-PUE' Else '' End,1,1,'') "
				+ " from BDORGAOS where BDORGAOS.ID_ANALISEDADOR =ANALISEDADOR.ID_ANALISEDADOR) AS ORGAOS "
				+ " , (select count(ao.ID_ASSIGNACAO_ORGAOS) from ASSIGNACAO_ORGAOS ao "
				+ " inner join DADOR dd on (dd.ID_DADOR = ao.ID_DADOR) "
				+ " where dd.ID_HOSPITAL in (select h.ID_HOSPITAL from HOSPITAL h inner join GCCT g on (h.ID_GCCT = g.ID_GCCT) where g.ID_GCCT = (select hosp.ID_GCCT from HOSPITAL hosp where hosp.ID_HOSPITAL = :id_hospital)) "
				+ "and dd.ID_DADOR = dador.ID_DADOR and ao.ID_ORGAOOFERTA<10) as 'Total Org�os',  "
				+ "el.SALA as 'SALA' , "
				+ " (Case when (select count(ec.ID_EQUIPA_CIRURGIA) from EQUIPA_CIRURGIA ec where ec.ID_DADOR = dador.ID_DADOR AND ec.INICIO<>99)>0 then 'OK' else NULL end) as 'EQUIPA' "
				+ " ,(select TOP 1 eh.ESTADO from HISTORICO_ASSIGNACAO ha "
				+ " inner join ESTADO_ASSIGNACAO_HOSPITAL eh on (eh.ID_ESTADO = ha.ID_ESTADO_ASSIG) "
				+ "where ha.ID_DADOR = dador.ID_DADOR AND ha.DATAHISTORICO = (Select MAX(ha.DATAHISTORICO) from HISTORICO_ASSIGNACAO ha where ha.ID_DADOR = dador.ID_DADOR)) as 'STATUS' "
				+ ", (select count(distinct(oo.NOME_ORGAO)) from ASSIGNACAO_ORGAOS ao "
				+ "inner join ORGAOS_OFERTA oo on (oo.ID_ORGAO_OFERTA = ao.ID_ORGAOOFERTA) "
				+ "inner join ASSIGNACAO_HOSPITAL ah on (ah.ID_ASSIGNACAO_ORGAO = ao.ID_ASSIGNACAO_ORGAOS) "
				+ "inner join DADOR dd on (dd.ID_DADOR = ao.ID_DADOR) "
				+ "where dd.ID_HOSPITAL in (select h.ID_HOSPITAL from HOSPITAL h inner join GCCT g on (h.ID_GCCT = g.ID_GCCT) where g.ID_GCCT = (select hosp.ID_GCCT from HOSPITAL hosp where hosp.ID_HOSPITAL = :id_hospital)) "
				+ "and dd.ID_DADOR = dador.ID_DADOR) as 'Oferecidos' , "
				+ "(Select count(ao.ID_ASSIGNACAO_ORGAOS) "
				+ "from  ASSIGNACAO_HOSPITAL ah "
				+ "inner join ASSIGNACAO_ORGAOS ao on (ao.ID_ASSIGNACAO_ORGAOS = ah.ID_ASSIGNACAO_ORGAO) "
				+ "where ah.ID_ESTADO = 3 and ao.ID_DADOR = dador.ID_DADOR) as 'Aceites', "
				+ "(Select count(distinct(ao.ID_ASSIGNACAO_ORGAOS)) "
				+ "from  ASSIGNACAO_HOSPITAL ah "
				+ "inner join ASSIGNACAO_ORGAOS ao on (ao.ID_ASSIGNACAO_ORGAOS = ah.ID_ASSIGNACAO_ORGAO) "
				+ "where (ah.ID_ESTADO = 2 and ao.ID_DADOR = dador.ID_DADOR) OR (ah.ID_ESTADO = 6 and ao.ID_DADOR = dador.ID_DADOR)) as 'N�o Aceites', "
				+ "(select (Case When (BDORGAOS.RIMESQUERDO = 'True' and BDORGAOS.RIMDIREITO = 'True') Then 1 Else 0 End) from  BDORGAOS where BDORGAOS.ID_ANALISEDADOR =ANALISEDADOR.ID_ANALISEDADOR) as 'Rins', "
				+ "(select (Case When (BDORGAOS.PULMAODIR = 'True' and BDORGAOS.PULMAOESQ = 'True') Then 1 Else 0 End) from  BDORGAOS where BDORGAOS.ID_ANALISEDADOR =ANALISEDADOR.ID_ANALISEDADOR) as 'Pulm�es' "
				+ "from DADOR dador "
				+ "left join EQUIPA_LOCAL el on (el.ID_DADOR = dador.ID_DADOR) "
				+ "inner join ESTADODADOR on (DADOR.ID_ESTADODADOR = ESTADODADOR.ID_ESTADODADOR) "
				+ "inner join ANALISEDADOR on (ANALISEDADOR.ID_DADOR = DADOR.ID_DADOR) "
				+ "inner join BDORGAOS on (BDORGAOS.ID_ANALISEDADOR = ANALISEDADOR.ID_ANALISEDADOR) "
				+ "where DADOR.ID_HOSPITAL in (select h.ID_HOSPITAL from HOSPITAL h inner join GCCT g on (h.ID_GCCT = g.ID_GCCT) where g.ID_GCCT = (select hosp.ID_GCCT from HOSPITAL hosp where hosp.ID_HOSPITAL = :id_hospital)) "
				+ "AND (ESTADODADOR.ID_ESTADODADOR =2 OR ESTADODADOR.ID_ESTADODADOR =3 OR ESTADODADOR.ID_ESTADODADOR =4)");		
		
		
		query.setParameter("id_hospital", id_hospital);

		
		out = query.getResultList();
		
//		int count = 0;  
//		for (Iterator i = out.iterator(); i.hasNext();) {  
//		    Object[] values = (Object[]) i.next();  
//		    System.out.println(++count + ": " + values[0] + ", " + values[1] + " ," + values[2] +"," + values[3] +"," + values[4] +" ," + values[5] + "," + values[6] + "," + values[7] + "<br />");  
//
//		}

		return out;
	}
	
	
	@SuppressWarnings("unchecked")
	public boolean verificaexisteassignacao(Long id){		
		
		Query query = manager.createQuery("select a from AssignacaoOrgaos a JOIN a.dadoroferta dador WHERE dador.id_Dador =:iddador");
		query.setParameter("iddador", id);

		List<AnaliseDador> results = query.getResultList();
		if(!results.isEmpty()){
		   return true;
	
		}else{
		return false;
		}
	}

	@SuppressWarnings("unchecked")
	public List<Object> listaofertasgcct(Long id_hospital) {
		
		List<Object> out = null;
		
		Query query = manager.createNativeQuery("select distinct d.ID_DADOR, d.CODIGODADOR , est.ESTADO, orgof.NOME_ORGAO, an.ID_ANALISEDADOR, orgof.ID_ORGAO_OFERTA, sao.STATUS "
				+ "from DADOR d inner join ANALISEDADOR an on (an.ID_DADOR = d.ID_DADOR) "
				+ "inner join ESTADODADOR est on (est.ID_ESTADODADOR = d.ID_ESTADODADOR) "
				+ "inner join ASSIGNACAO_ORGAOS ao on (ao.ID_DADOR = d.ID_DADOR) "
				+ "left join STATUS_ASSIGNACAO_ORGAOS sao on (sao.ID_STATUS = ao.ID_STATUS) "
				+ "inner join ORGAOS_OFERTA orgof on (orgof.ID_ORGAO_OFERTA = ao.ID_ORGAOOFERTA) "
				+ "inner join ASSIGNACAO_HOSPITAL ah on (ah.ID_ASSIGNACAO_ORGAO = ao.ID_ASSIGNACAO_ORGAOS) "
				+ "where ah.ID_HOSPITAL=:id_hospital");
		
		//rede do GCCT:
		/*Query query = manager.createNativeQuery("select distinct d.ID_DADOR, d.CODIGODADOR , est.ESTADO, orgof.NOME_ORGAO, an.ID_ANALISEDADOR, orgof.ID_ORGAO_OFERTA, sao.STATUS , ah.ID_HOSPITAL "
				+ "from DADOR d inner join ANALISEDADOR an on (an.ID_DADOR = d.ID_DADOR) "
				+ "inner join ESTADODADOR est on (est.ID_ESTADODADOR = d.ID_ESTADODADOR) "
				+ "inner join ASSIGNACAO_ORGAOS ao on (ao.ID_DADOR = d.ID_DADOR) "
				+ "left join STATUS_ASSIGNACAO_ORGAOS sao on (sao.ID_STATUS = ao.ID_STATUS) "
				+ "inner join ORGAOS_OFERTA orgof on (orgof.ID_ORGAO_OFERTA = ao.ID_ORGAOOFERTA) "
				+ "inner join ASSIGNACAO_HOSPITAL ah on (ah.ID_ASSIGNACAO_ORGAO = ao.ID_ASSIGNACAO_ORGAOS) "
				+ "where ah.ID_HOSPITAL in (select h.ID_HOSPITAL from HOSPITAL h inner join GCCT g on (h.ID_GCCT = g.ID_GCCT) where g.ID_GCCT = (select hosp.ID_GCCT from HOSPITAL hosp where hosp.ID_HOSPITAL = :id_hospital))");*/
		query.setParameter("id_hospital", id_hospital);
		
		out = query.getResultList();
		
		return out;
	}
	
	public Long buscaIdHospital(Long iddador){

		Query query = manager.createNativeQuery("select DADOR.ID_HOSPITAL from DADOR where DADOR.ID_DADOR =:iddador");
		query.setParameter("iddador", iddador);
		
		BigInteger id = (BigInteger) query.getSingleResult();	

		return id.longValue();
	}
}
