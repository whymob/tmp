package pt.iconic.ipst.modelo;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;


@Entity
@Table(name = "COLHEITA_RINS_TERAPEUTICAS")
public class ColheitaRinsTerapeuticas {

	private Long idcolheitaterapeuticarins;
	private int terapeutica;
	private String observacoesterapeutica;
	private AnaliseDador analiseDador;
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="ID_COLHEITA_TERAPEUTICA_RINS")
	public Long getIdcolheitaterapeuticarins() {
		return idcolheitaterapeuticarins;
	}
	public void setIdcolheitaterapeuticarins(Long idcolheitaterapeuticarins) {
		this.idcolheitaterapeuticarins = idcolheitaterapeuticarins;
	}
	
	@Column(name="TERAPEUTICA")
	public int getTerapeutica() {
		return terapeutica;
	}
	public void setTerapeutica(int terapeutica) {
		this.terapeutica = terapeutica;
	}
	
	@Column(name="OBSERVACOES_TERAPEUTICA")
	public String getObservacoesterapeutica() {
		return observacoesterapeutica;
	}
	public void setObservacoesterapeutica(String observacoesterapeutica) {
		this.observacoesterapeutica = observacoesterapeutica;
	}
	
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "ID_ANALISE_DADOR")
	public AnaliseDador getAnaliseDador() {
		return analiseDador;
	}
	public void setAnaliseDador(AnaliseDador analiseDador) {
		this.analiseDador = analiseDador;
	}
	
}
