package pt.iconic.ipst.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import pt.iconic.ipst.modelo.MedicamentosPreTransp;

@Repository
@Transactional
public class MedicamentosPreTranspDAO {

	@PersistenceContext
	private EntityManager manager;
	
	public void adiciona(MedicamentosPreTransp med){
		manager.persist(med);	
	}
	
	public void atualiza(MedicamentosPreTransp med){
		manager.merge(med);
	}

/*	@SuppressWarnings("unchecked")
	public List<MedicamentosPreTransp> ListaMedicamentosPreTransp(){
		return manager.createQuery("select d from MedicamentosPreTransp d").getResultList();
	}*/
	
	public MedicamentosPreTransp buscaPorId(Long id){
		return manager.find(MedicamentosPreTransp.class, id);
	}
	
	public void remove(MedicamentosPreTransp med){
		MedicamentosPreTransp medrem = buscaPorId(med.getIdmedicamento());
		manager.remove(medrem);
	}

	@SuppressWarnings("unchecked")
	public List<MedicamentosPreTransp> buscamedicamentosmarcacao(Long id_estadorecetor) {
	
		Query query = manager.createQuery("select a from MedicamentosPreTransp a JOIN a.marcacao marc WHERE marc.id_estadorecetor =:id_estadorecetor", MedicamentosPreTransp.class);
		query.setParameter("id_estadorecetor", id_estadorecetor);
		
		List<MedicamentosPreTransp> results = query.getResultList();

		return results;
	}
}
