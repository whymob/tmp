package pt.iconic.ipst.dao;

import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;
import pt.iconic.ipst.modelo.CausaMorte;

@Repository
@Transactional
public class CausaMorteDAO {

	
	@PersistenceContext
	private EntityManager manager;
	
	
	public void adiciona(CausaMorte causamorte){
		manager.persist(causamorte);	
	}
	
	public void atualiza(CausaMorte causamorte){
		manager.merge(causamorte);
	}
	

	@SuppressWarnings("unchecked")
	public List<CausaMorte> ListaCausaMorte(){
		return manager.createQuery("select c from CausaMorte c").getResultList();
	}
	
	public CausaMorte buscaPorId(Long id){
		return manager.find(CausaMorte.class, id);
	}
	
	
	public void remove(CausaMorte causamorte){
		CausaMorte causamorteARemover = buscaPorId(causamorte.getId_CausaMorte());
		manager.remove(causamorteARemover);
	}
	
	public boolean trataadicionar(String desc)
	{
		Query query = manager.createQuery("SELECT c FROM CausaMorte c WHERE c.descricaoCausaMorte =:desc");
		query.setParameter("desc", desc);
		
		if(query.getResultList().isEmpty())
		{
			CausaMorte causa = new CausaMorte();
			causa.setDescricaoCausaMorte(desc);
			adiciona(causa);
			
			return true;
		}
		else
		{
			return false;
		}
	}
	
	public boolean trataalterar(Long id, String desc)
	{
		CausaMorte causa = new CausaMorte();
		causa.setId_CausaMorte(id);
		causa.setDescricaoCausaMorte(desc);
		atualiza(causa);
			
		return true;
	}
	
	public boolean remover(Long id)
	{
		CausaMorte causa = new CausaMorte();
		causa = buscaPorId(id);
		remove(causa);
			
		return true;
	}
}
