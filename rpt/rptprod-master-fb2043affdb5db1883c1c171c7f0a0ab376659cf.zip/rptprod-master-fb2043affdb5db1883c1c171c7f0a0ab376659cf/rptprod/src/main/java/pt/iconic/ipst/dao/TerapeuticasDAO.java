package pt.iconic.ipst.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import pt.iconic.ipst.modelo.Terapeuticas;

@Repository
public class TerapeuticasDAO {

	@PersistenceContext
	private EntityManager manager;
	
	@Transactional
	public void adiciona(Terapeuticas terapeuticas){
		manager.persist(terapeuticas);	
	}
	
	@Transactional
	public void atualiza(Terapeuticas terapeuticas){
		manager.merge(terapeuticas);
	}
	

/*	@SuppressWarnings("unchecked")
	public List<Terapeuticas> ListaTerapeuticas(){
		return manager.createQuery("select c from Terapeuticas c").getResultList();
	}*/
	
	public Terapeuticas buscaPorId(Long id){
		return manager.find(Terapeuticas.class, id);
	}
	
	
	public void remove(Terapeuticas terapeuticas){
		Terapeuticas terapeuticasARemover = buscaPorId(terapeuticas.getId_terapeutica());
		manager.remove(terapeuticasARemover);
	}
	
	@SuppressWarnings("unchecked")
	public List<Terapeuticas> buscaterapeuticasanalise(Long idanalise){
		Query query = manager.createQuery("select a from Terapeuticas a JOIN a.analiseDador an  WHERE an.id_AnaliseDador =:idanalise");
		query.setParameter("idanalise", idanalise);
		
		List<Terapeuticas> results = query.getResultList();
		
		
		return results;
	
	}
	
}
