package pt.iconic.ipst.modelo;

import java.util.Calendar;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "PERMISSAO_AUX")
public class PermissaoAux {

	private Long Id_PermissaoAux;
	private String email;
	private String telemovel;
	private boolean leituraescrita;
	private int pin;
	private Calendar data;
	private Long id_hospital;
	private Long id_posicao;
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="ID_PERMISSAOAUX")
	public Long getId_PermissaoAux() {
		return Id_PermissaoAux;
	}
	public void setId_PermissaoAux(Long id_PermissaoAux) {
		Id_PermissaoAux = id_PermissaoAux;
	}
	
	@Column(name="EMAIL")
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	
	@Column(name="LEITURAESCRITA")
	public boolean isLeituraescrita() {
		return leituraescrita;
	}
	public void setLeituraescrita(boolean leituraescrita) {
		this.leituraescrita = leituraescrita;
	}
	
	@Column(name="PIN")
	public int getPin() {
		return pin;
	}
	public void setPin(int pin) {
		this.pin = pin;
	}
	
	@Column(name="DATA")
	public Calendar getData() {
		return data;
	}
	public void setData(Calendar data) {
		this.data = data;
	}
	
	@Column(name="ID_HOSPITAL")	
	public Long getId_hospital() {
		return id_hospital;
	}
	public void setId_hospital(Long id_hospital) {
		this.id_hospital = id_hospital;
	}
	
	@Column(name="ID_POSICAO")	
	public Long getId_posicao() {
		return id_posicao;
	}
	public void setId_posicao(Long id_posicao) {
		this.id_posicao = id_posicao;
	}
	
	@Column(name="TELEMOVEL")
	public String getTelemovel() {
		return telemovel;
	}
	public void setTelemovel(String telemovel) {
		this.telemovel = telemovel;
	}
	
	
}
