package pt.iconic.ipst.modelo;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name="TRANSFUSOES")
public class Transfusoes {

	private Long id_transfusao;
	private AnaliseDador analiseDador;
	private NomeTransfusoes nomeTransfusoes;
//	private int intervalotransf;
	private int volunidade;
//	private int numunidades;

	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="ID_TRANSFUSOES")
	public Long getId_transfusao() {
		return id_transfusao;
	}
	
	public void setId_transfusao(Long id_transfusao) {
		this.id_transfusao = id_transfusao;
	}
	
    @ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name="ID_ANALISEDADOR")
	public AnaliseDador getAnaliseDador() {
		return analiseDador;
	}
	public void setAnaliseDador(AnaliseDador analiseDador) {
		this.analiseDador = analiseDador;
	}
	
    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "ID_NOMETRANSFUSAO")
	public NomeTransfusoes getNomeTransfusoes() {
		return nomeTransfusoes;
	}
	
	public void setNomeTransfusoes(NomeTransfusoes nomeTransfusoes) {
		this.nomeTransfusoes = nomeTransfusoes;
	}
	
//	@Column(name="INTERVALOTRANSFUSAO")
//	public int getIntervalotransf() {
//		return intervalotransf;
//	}
//	public void setIntervalotransf(int intervalotransf) {
//		this.intervalotransf = intervalotransf;
//	}
	
	
	@Column(name="VOLUNIDADE")
	public int getVolunidade() {
		return volunidade;
	}
	public void setVolunidade(int volunidade) {
		this.volunidade = volunidade;
	}
	
//	@Column(name="NUMUNIDADES")
//	public int getNumunidades() {
//		return numunidades;
//	}
//	public void setNumunidades(int numunidades) {
//		this.numunidades = numunidades;
//	}
	

	
}
