package pt.iconic.ipst.modelo;


import java.util.Calendar;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;


@Entity
@Table(name = "ANALISEDADOR")
public class AnaliseDador {

	private Long Id_AnaliseDador;
	private Dador dador;
	private boolean statusharmviro;
	private Calendar datagravacaoviro;
	private boolean statusharmgasvent;
	private Calendar datagravacaogasvent;
	private Calendar datagravacaoterapeuticas;
	private Calendar datagravacaotransfusoes;
	private List<AmostrasFuncoesOrgao> amostraFO;
	private List<MBAnalises> mbanalises;
	private MorteCerebral MorteCerebral;
	private List<Terapeuticas> Terapeuticas;
	private List<Transfusoes> Transfusoes;	
	private BDAvaliacaoInicial  bdAvaliacaoInicial;
	private BDFichaDador bdFichaDador;
	private BDOrgaos bdOrgaos;
	private List<GasVent> gasVent;
	private HCExameFisico hcExameFisico;
	private HCSituacoesRisco hcSituacoesRisco;
	private HCGeral hcGeral;
	private HCDoencasPreExistentes hcDoencasPreExistentes;
	private GrupoSanguineo grupoSanguineo;
	private Microbiologia microbiologia;
	private Imunologia imunologia;
	private FuncoesOrgao funcoesOrgao;
	private List<Virologia> virologia;
	private BiopsiaRenal biopsiarenal;
	private List<BiopsiarenalItens> biorenalitens;
	private BiopsiaHepatica biopsiahepatica;
	private ColheitaGeral colheitageral;
	private List<ColheitaGeralTerapeuticas> colheitageralterapeuricas;
	private List<ColheitaGeralPerfOrgAbdom> colheitageralperforgabdominal;
	private List<ColheitaGeralPerfOrgTorax> colheitageralperforgtoraxico;
	private ColheitaRins colheitarins;
	private List<ColheitaRinsPerfusao> colheitarinsperfusao;
	private List<ColheitaRinsTerapeuticas> colheitarinsterapeuticas;
	private ColheitaPancreas colheitapancreas;
	private List<ColheitaPancreasPerfusao> colheitapancreasperfusao;
	private List<ColheitaPancreasProduto> colheitapancreasprodutos;
	private ColheitaFigado colheitafigado;
	private List<ColheitaFigadoPerfusao> colheitafigadoperfusao;
	private ColheitaCoracao colheitacoracao;
	private ColheitaPulmoes colheitapulmoes;
	private List<ColheitaPulmoesTratamento> colheitapulmoestratamento;
	private ColheitaCorneas colheitacorneas;
	private ColheitaPele colheitapele;
	private ColheitaTC colheitatc;
	private ColheitaTME colheitatme;
	private ColheitaVasos colheitavasos;
	private List<PosOperatorioTabExpl> posoptabexplante;
	private PosOperatorioExplante posoperatexplante;
	private List<GCCTColheita> gcctcolheita;
	
	//private BaseDador BaseDador;
	//private HistorialClinico HistorialClinico;
	//private Analises Analises;
	//private Exames Exames;
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="ID_ANALISEDADOR")
	public Long getId_AnaliseDador() {
		return Id_AnaliseDador;
	}
	public void setId_AnaliseDador(Long id_AnaliseDador) {
		Id_AnaliseDador = id_AnaliseDador;
	}
	
    @OneToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "ID_DADOR")
	public Dador getDador() {
		return dador;
	}
	public void setDador(Dador dador) {
		this.dador = dador;
	}
	
	@OneToMany(fetch = FetchType.LAZY, mappedBy = "analiseDador")
	public List<AmostrasFuncoesOrgao> getAmostraFO() {
		return amostraFO;
	}
	public void setAmostraFO(List<AmostrasFuncoesOrgao> amostraFO) {
		this.amostraFO = amostraFO;
	}

	@OneToMany(fetch = FetchType.LAZY, mappedBy = "analiseDador")
	public List<MBAnalises> getMbanalises() {
		return mbanalises;
	}
	public void setMbanalises(List<MBAnalises> mbanalises) {
		this.mbanalises = mbanalises;
	}
	@OneToMany(fetch = FetchType.LAZY, mappedBy = "analiseDador")
	public List<Virologia> getVirologia() {
		return virologia;
	}
	public void setVirologia(List<Virologia> virologia) {
		this.virologia = virologia;
	}
	
	@OneToOne(fetch = FetchType.LAZY, mappedBy = "analiseDador")
	public FuncoesOrgao getFuncoesOrgao() {
		return funcoesOrgao;
	}
	public void setFuncoesOrgao(FuncoesOrgao funcoesOrgao) {
		this.funcoesOrgao = funcoesOrgao;
	}
	
	@OneToOne(fetch = FetchType.LAZY, mappedBy = "analiseDador")
	public Imunologia getImunologia() {
		return imunologia;
	}
	public void setImunologia(Imunologia imunologia) {
		this.imunologia = imunologia;
	}
	
	@OneToOne(fetch = FetchType.LAZY, mappedBy = "analiseDador")
	public Microbiologia getMicrobiologia() {
		return microbiologia;
	}
	public void setMicrobiologia(Microbiologia microbiologia) {
		this.microbiologia = microbiologia;
	}
	
	@OneToOne(fetch = FetchType.LAZY, mappedBy = "analiseDador")
	public GrupoSanguineo getGrupoSanguineo() {
		return grupoSanguineo;
	}
	public void setGrupoSanguineo(GrupoSanguineo grupoSanguineo) {
		this.grupoSanguineo = grupoSanguineo;
	}
	
	@OneToOne(fetch = FetchType.LAZY, mappedBy = "analiseDador")
	public HCDoencasPreExistentes getHcDoencasPreExistentes() {
		return hcDoencasPreExistentes;
	}
	public void setHcDoencasPreExistentes(HCDoencasPreExistentes hcDoencasPreExistentes) {
		this.hcDoencasPreExistentes = hcDoencasPreExistentes;
	}
	
	@OneToOne(fetch = FetchType.LAZY, mappedBy = "analiseDador")
	public HCGeral getHcGeral() {
		return hcGeral;
	}
	public void setHcGeral(HCGeral hcGeral) {
		this.hcGeral = hcGeral;
	}
	
	
	@OneToOne(fetch = FetchType.LAZY, mappedBy = "analiseDador")
	public HCSituacoesRisco getHcSituacoesRisco() {
		return hcSituacoesRisco;
	}
	public void setHcSituacoesRisco(HCSituacoesRisco hcSituacoesRisco) {
		this.hcSituacoesRisco = hcSituacoesRisco;
	}
	
	
	@OneToOne(fetch = FetchType.LAZY, mappedBy = "analisedador")
	public HCExameFisico getHcExameFisico() {
		return hcExameFisico;
	}
	public void setHcExameFisico(HCExameFisico hcExameFisico) {
		this.hcExameFisico = hcExameFisico;
	}
	
	
	@OneToMany(fetch = FetchType.LAZY, mappedBy = "analiseDador")
	public List<GasVent> getGasVent() {
		return gasVent;
	}
	public void setGasVent(List<GasVent> gasVent) {
		this.gasVent = gasVent;
	}
	
	
	@OneToOne(fetch = FetchType.LAZY, mappedBy = "analiseDador")	
	public BDOrgaos getBdOrgaos() {
		return bdOrgaos;
	}
	public void setBdOrgaos(BDOrgaos bdOrgaos) {
		this.bdOrgaos = bdOrgaos;
	}
	
	
	@OneToOne(fetch = FetchType.LAZY, mappedBy = "analiseDador")
	public BDAvaliacaoInicial getBdAvaliacaoInicial() {
		return bdAvaliacaoInicial;
	}
	public void setBdAvaliacaoInicial(BDAvaliacaoInicial bdAvaliacaoInicial) {
		this.bdAvaliacaoInicial = bdAvaliacaoInicial;
	}
	
	@OneToOne(fetch = FetchType.LAZY, mappedBy = "analiseDador")
	public BDFichaDador getBdFichaDador() {
		return bdFichaDador;
	}
	public void setBdFichaDador(BDFichaDador bdFichaDador) {
		this.bdFichaDador = bdFichaDador;
	}
	
/*	@OneToOne(fetch = FetchType.LAZY, mappedBy = "analiseDador")
	public BaseDador getBaseDador() {
		return BaseDador;
	}
	public void setBaseDador(BaseDador baseDador) {
		BaseDador = baseDador;
	}
	
	@OneToOne(fetch = FetchType.LAZY, mappedBy = "analiseDador")
	public HistorialClinico getHistorialClinico() {
		return HistorialClinico;
	}
	public void setHistorialClinico(HistorialClinico historialClinico) {
		HistorialClinico = historialClinico;
	}*/
	


	@OneToOne(fetch = FetchType.LAZY, mappedBy = "analiseDador")	
	public MorteCerebral getMorteCerebral() {
		return MorteCerebral;
	}
	public void setMorteCerebral(MorteCerebral morteCerebral) {
		MorteCerebral = morteCerebral;
	}
	
/*	@OneToOne(fetch = FetchType.LAZY, mappedBy = "analiseDador")
	public Analises getAnalises() {
		return Analises;
	}
	public void setAnalises(Analises analises) {
		Analises = analises;
	}
	
	@OneToOne(fetch = FetchType.LAZY, mappedBy = "analiseDador")
	public Exames getExames() {
		return Exames;
	}
	public void setExames(Exames exames) {
		Exames = exames;
	}*/
	
	@OneToMany(fetch = FetchType.LAZY, mappedBy = "analiseDador")
	public List<Terapeuticas> getTerapeuticas() {
		return Terapeuticas;
	}
	public void setTerapeuticas(List<Terapeuticas> terapeuticas) {
		Terapeuticas = terapeuticas;
	}
	
	@OneToMany(fetch = FetchType.LAZY, mappedBy = "analiseDador")
	public List<Transfusoes> getTransfusoes() {
		return Transfusoes;
	}
	public void setTransfusoes(List<Transfusoes> transfusoes) {
		Transfusoes = transfusoes;
	}
	
	@OneToOne(fetch = FetchType.LAZY, mappedBy = "analiseDador")
	public BiopsiaRenal getBiopsiarenal() {
		return biopsiarenal;
	}
	public void setBiopsiarenal(BiopsiaRenal biopsiarenal) {
		this.biopsiarenal = biopsiarenal;
	}
	
	@OneToMany(fetch = FetchType.LAZY, mappedBy = "analiseDador")
	public List<BiopsiarenalItens> getBiorenalitens() {
		return biorenalitens;
	}
	public void setBiorenalitens(List<BiopsiarenalItens> biorenalitens) {
		this.biorenalitens = biorenalitens;
	}
	
	@OneToOne(fetch = FetchType.LAZY, mappedBy = "analiseDador")
	public BiopsiaHepatica getBiopsiahepatica() {
		return biopsiahepatica;
	}
	public void setBiopsiahepatica(BiopsiaHepatica biopsiahepatica) {
		this.biopsiahepatica = biopsiahepatica;
	}
	
	@OneToOne(fetch = FetchType.LAZY, mappedBy = "analiseDador")
	public ColheitaGeral getColheitageral() {
		return colheitageral;
	}
	public void setColheitageral(ColheitaGeral colheitageral) {
		this.colheitageral = colheitageral;
	}
	
	@OneToMany(fetch = FetchType.LAZY, mappedBy = "analiseDador")
	public List<ColheitaGeralTerapeuticas> getColheitageralterapeuricas() {
		return colheitageralterapeuricas;
	}
	public void setColheitageralterapeuricas(
			List<ColheitaGeralTerapeuticas> colheitageralterapeuricas) {
		this.colheitageralterapeuricas = colheitageralterapeuricas;
	}
	
	@OneToMany(fetch = FetchType.LAZY, mappedBy = "analiseDador")
	public List<ColheitaGeralPerfOrgAbdom> getColheitageralperforgabdominal() {
		return colheitageralperforgabdominal;
	}
	public void setColheitageralperforgabdominal(
			List<ColheitaGeralPerfOrgAbdom> colheitageralperforgabdominal) {
		this.colheitageralperforgabdominal = colheitageralperforgabdominal;
	}
	
	@OneToMany(fetch = FetchType.LAZY, mappedBy = "analiseDador")
	public List<ColheitaGeralPerfOrgTorax> getColheitageralperforgtoraxico() {
		return colheitageralperforgtoraxico;
	}
	public void setColheitageralperforgtoraxico(
			List<ColheitaGeralPerfOrgTorax> colheitageralperforgtoraxico) {
		this.colheitageralperforgtoraxico = colheitageralperforgtoraxico;
	}
	
	@OneToOne(fetch = FetchType.LAZY, mappedBy = "analiseDador")
	public ColheitaRins getColheitarins() {
		return colheitarins;
	}
	public void setColheitarins(ColheitaRins colheitarins) {
		this.colheitarins = colheitarins;
	}
	
	@OneToMany(fetch = FetchType.LAZY, mappedBy = "analiseDador")
	public List<ColheitaRinsPerfusao> getColheitarinsperfusao() {
		return colheitarinsperfusao;
	}
	public void setColheitarinsperfusao(List<ColheitaRinsPerfusao> colheitarinsperfusao) {
		this.colheitarinsperfusao = colheitarinsperfusao;
	}
	
	@OneToMany(fetch = FetchType.LAZY, mappedBy = "analiseDador")
	public List<ColheitaRinsTerapeuticas> getColheitarinsterapeuticas() {
		return colheitarinsterapeuticas;
	}
	public void setColheitarinsterapeuticas(List<ColheitaRinsTerapeuticas> colheitarinsterapeuticas) {
		this.colheitarinsterapeuticas = colheitarinsterapeuticas;
	}
	
	@OneToOne(fetch = FetchType.LAZY, mappedBy = "analiseDador")
	public ColheitaPancreas getColheitapancreas() {
		return colheitapancreas;
	}
	public void setColheitapancreas(ColheitaPancreas colheitapancreas) {
		this.colheitapancreas = colheitapancreas;
	}
	
	@OneToMany(fetch = FetchType.LAZY, mappedBy = "analiseDador")
	public List<ColheitaPancreasPerfusao> getColheitapancreasperfusao() {
		return colheitapancreasperfusao;
	}
	public void setColheitapancreasperfusao(List<ColheitaPancreasPerfusao> colheitapancreasperfusao) {
		this.colheitapancreasperfusao = colheitapancreasperfusao;
	}
	
	@OneToMany(fetch = FetchType.LAZY, mappedBy = "analiseDador")
	public List<ColheitaPancreasProduto> getColheitapancreasprodutos() {
		return colheitapancreasprodutos;
	}
	public void setColheitapancreasprodutos(List<ColheitaPancreasProduto> colheitapancreasprodutos) {
		this.colheitapancreasprodutos = colheitapancreasprodutos;
	}
	
	@OneToOne(fetch = FetchType.LAZY, mappedBy = "analiseDador")
	public ColheitaFigado getColheitafigado() {
		return colheitafigado;
	}
	public void setColheitafigado(ColheitaFigado colheitafigado) {
		this.colheitafigado = colheitafigado;
	}
	
	@OneToMany(fetch = FetchType.LAZY, mappedBy = "analiseDador")
	public List<ColheitaFigadoPerfusao> getColheitafigadoperfusao() {
		return colheitafigadoperfusao;
	}
	public void setColheitafigadoperfusao(List<ColheitaFigadoPerfusao> colheitafigadoperfusao) {
		this.colheitafigadoperfusao = colheitafigadoperfusao;
	}
	
	@OneToOne(fetch = FetchType.LAZY, mappedBy = "analiseDador")
	public ColheitaCoracao getColheitacoracao() {
		return colheitacoracao;
	}
	public void setColheitacoracao(ColheitaCoracao colheitacoracao) {
		this.colheitacoracao = colheitacoracao;
	}
	
	@OneToOne(fetch = FetchType.LAZY, mappedBy = "analiseDador")
	public ColheitaPulmoes getColheitapulmoes() {
		return colheitapulmoes;
	}
	public void setColheitapulmoes(ColheitaPulmoes colheitapulmoes) {
		this.colheitapulmoes = colheitapulmoes;
	}
	
	@OneToMany(fetch = FetchType.LAZY, mappedBy = "analiseDador")
	public List<ColheitaPulmoesTratamento> getColheitapulmoestratamento() {
		return colheitapulmoestratamento;
	}
	public void setColheitapulmoestratamento(
			List<ColheitaPulmoesTratamento> colheitapulmoestratamento) {
		this.colheitapulmoestratamento = colheitapulmoestratamento;
	}
	
	@OneToOne(fetch = FetchType.LAZY, mappedBy = "analiseDador")
	public ColheitaCorneas getColheitacorneas() {
		return colheitacorneas;
	}
	public void setColheitacorneas(ColheitaCorneas colheitacorneas) {
		this.colheitacorneas = colheitacorneas;
	}
	
	@OneToOne(fetch = FetchType.LAZY, mappedBy = "analiseDador")
	public ColheitaPele getColheitapele() {
		return colheitapele;
	}
	public void setColheitapele(ColheitaPele colheitapele) {
		this.colheitapele = colheitapele;
	}
	
	@OneToOne(fetch = FetchType.LAZY, mappedBy = "analiseDador")
	public ColheitaTC getColheitatc() {
		return colheitatc;
	}
	public void setColheitatc(ColheitaTC colheitatc) {
		this.colheitatc = colheitatc;
	}
	
	@OneToOne(fetch = FetchType.LAZY, mappedBy = "analiseDador")
	public ColheitaTME getColheitatme() {
		return colheitatme;
	}
	public void setColheitatme(ColheitaTME colheitatme) {
		this.colheitatme = colheitatme;
	}
	
	@OneToOne(fetch = FetchType.LAZY, mappedBy = "analiseDador")
	public ColheitaVasos getColheitavasos() {
		return colheitavasos;
	}
	public void setColheitavasos(ColheitaVasos colheitavasos) {
		this.colheitavasos = colheitavasos;
	}
	
	@OneToMany(fetch = FetchType.LAZY, mappedBy = "analiseDador")
	public List<PosOperatorioTabExpl> getPosoptabexplante() {
		return posoptabexplante;
	}
	public void setPosoptabexplante(List<PosOperatorioTabExpl> posoptabexplante) {
		this.posoptabexplante = posoptabexplante;
	}
	
	@OneToOne(fetch = FetchType.LAZY, mappedBy = "analiseDador")
	public PosOperatorioExplante getPosoperatexplante() {
		return posoperatexplante;
	}
	public void setPosoperatexplante(PosOperatorioExplante posoperatexplante) {
		this.posoperatexplante = posoperatexplante;
	}
	
	@OneToMany(fetch = FetchType.LAZY, mappedBy = "analiseDador")
	public List<GCCTColheita> getGcctcolheita() {
		return gcctcolheita;
	}
	public void setGcctcolheita(List<GCCTColheita> gcctcolheita) {
		this.gcctcolheita = gcctcolheita;
	}
	
	@Column(name="STATUSHARMONIOVIRO")
	public boolean isStatusharmviro() {
		return statusharmviro;
	}
	
	public void setStatusharmviro(boolean statusharmviro) {
		this.statusharmviro = statusharmviro;
	}
	
	@Column(name="STATUSHARMONIOGASVENT")
	public boolean isStatusharmgasvent() {
		return statusharmgasvent;
	}
	public void setStatusharmgasvent(boolean statusharmgasvent) {
		this.statusharmgasvent = statusharmgasvent;
	}
	
	@Column(name="DATAGRAVACAOVIRO")
	public Calendar getDatagravacaoviro() {
		return datagravacaoviro;
	}

	public void setDatagravacaoviro(Calendar datagravacaoviro) {
		this.datagravacaoviro = datagravacaoviro;
	}
	
	@Column(name="DATAGRAVACAOGASVENT")
	public Calendar getDatagravacaogasvent() {
		return datagravacaogasvent;
	}
	public void setDatagravacaogasvent(Calendar datagravacaogasvent) {
		this.datagravacaogasvent = datagravacaogasvent;
	}
	
	@Column(name="DATAGRAVACAOTERAPEUTICAS")
	public Calendar getDatagravacaoterapeuticas() {
		return datagravacaoterapeuticas;
	}
	public void setDatagravacaoterapeuticas(Calendar datagravacaoterapeuticas) {
		this.datagravacaoterapeuticas = datagravacaoterapeuticas;
	}
	
	@Column(name="DATAGRAVACAOTRANSFUSOES")
	public Calendar getDatagravacaotransfusoes() {
		return datagravacaotransfusoes;
	}
	public void setDatagravacaotransfusoes(Calendar datagravacaotransfusoes) {
		this.datagravacaotransfusoes = datagravacaotransfusoes;
	}
	
}
