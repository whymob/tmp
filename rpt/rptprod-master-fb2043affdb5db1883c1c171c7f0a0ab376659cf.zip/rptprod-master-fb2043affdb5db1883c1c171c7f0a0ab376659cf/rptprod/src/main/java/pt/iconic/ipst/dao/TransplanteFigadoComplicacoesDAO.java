package pt.iconic.ipst.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import pt.iconic.ipst.modelo.TransplanteFigadoComplicacoes;

@Repository
@Transactional
public class TransplanteFigadoComplicacoesDAO {

	@PersistenceContext
	private EntityManager manager;
	
	
	public void adiciona(TransplanteFigadoComplicacoes transplante){
		manager.persist(transplante);	
	}
	

	public void atualiza(TransplanteFigadoComplicacoes transplante){
		manager.merge(transplante);
	}
	

/*	@SuppressWarnings("unchecked")
	public List<TransplanteFigadoComplicacoes> ListaTransplanteFigadoComplicacoes(){
		return manager.createQuery("select a from TransplanteFigadoComplicacoes a").getResultList();
	}*/
	
	public TransplanteFigadoComplicacoes buscaPorId(Long id){
		return manager.find(TransplanteFigadoComplicacoes.class, id);
	}
	
	
	public void remove(TransplanteFigadoComplicacoes transplante){
		TransplanteFigadoComplicacoes transplanteARemover = buscaPorId(transplante.getIdtranspfigadocompl());
		manager.remove(transplanteARemover);
		
	}
	
	@SuppressWarnings("unchecked")
	public List<TransplanteFigadoComplicacoes> listatransplantefigadocomplassig(Long idassigorg){
		
		Query query = manager.createQuery("select b from TransplanteFigadoComplicacoes b JOIN b.assigorgao a WHERE a.id_assignacao =:idassigorg");
		query.setParameter("idassigorg", idassigorg);
		
		List<TransplanteFigadoComplicacoes> results = query.getResultList();
		return results;
		
	}
}
