package pt.iconic.ipst.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import pt.iconic.ipst.modelo.ColheitaGeralPerfOrgAbdom;

@Repository
@Transactional
public class ColheitaGeralPerfOrgAbdomDAO {

	
	@PersistenceContext
	private EntityManager manager;
	
	
	public void adiciona(ColheitaGeralPerfOrgAbdom colheita){
		manager.persist(colheita);	
	}
	

	public void atualiza(ColheitaGeralPerfOrgAbdom colheita){
		manager.merge(colheita);
	}
	

/*	@SuppressWarnings("unchecked")
	public List<ColheitaGeralPerfOrgAbdom> ListaColheitaGeralPerfOrgAbdom(){
		return manager.createQuery("select a from ColheitaGeralPerfOrgAbdom a").getResultList();
	}*/
	
	public ColheitaGeralPerfOrgAbdom buscaPorId(Long id){
		return manager.find(ColheitaGeralPerfOrgAbdom.class, id);
	}
	
	
	public void remove(ColheitaGeralPerfOrgAbdom colheita){
		ColheitaGeralPerfOrgAbdom colheitaARemover = buscaPorId(colheita.getIdperfabdominal());
		manager.remove(colheitaARemover);
		
	}
	
	@SuppressWarnings("unchecked")
	public List<ColheitaGeralPerfOrgAbdom> ListaColheitaGeralPerfOrgAbdomanalise(Long idanalise){
		
		Query query = manager.createQuery("select b from ColheitaGeralPerfOrgAbdom b JOIN b.analiseDador a WHERE a.id_AnaliseDador =:idanalise");
		query.setParameter("idanalise", idanalise);
		
		List<ColheitaGeralPerfOrgAbdom> results = query.getResultList();

		return results;
		
	}
}
