package pt.iconic.ipst.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import pt.iconic.ipst.modelo.TransplantePosOperatorio;

@Repository
@Transactional
public class TransplantePosOperatorioDAO {

	@PersistenceContext
	private EntityManager manager;
	
	public void adiciona(TransplantePosOperatorio transplante){
		manager.persist(transplante);	
	}
	
	public void atualiza(TransplantePosOperatorio transplante){
		manager.merge(transplante);
	}
	
/*	@SuppressWarnings("unchecked")
	public List<TransplantePosOperatorio> ListaTransplantePosOperatorio(){
		return manager.createQuery("select a from TransplantePosOperatorio a").getResultList();
	}*/
	
/*	public TransplantePosOperatorio buscaPorId(Long id){
		return manager.find(TransplantePosOperatorio.class, id);
	}*/
	
/*	public void remove(TransplantePosOperatorio transplante){
		TransplantePosOperatorio transplanteARemover = buscaPorId(transplante.getIdtransplanteposop());
		manager.remove(transplanteARemover);
	}*/
	
	@SuppressWarnings("unchecked")
	public TransplantePosOperatorio buscaTransplantePosOperatorioAssigorgao(Long idassigorg){
		
		Query query = manager.createQuery("select p from TransplantePosOperatorio p JOIN p.assigorgao a WHERE a.id_assignacao =:idassigorg");
		query.setParameter("idassigorg", idassigorg);
		
		List<TransplantePosOperatorio> results = query.getResultList();
		TransplantePosOperatorio transplante = null;
		if(!results.isEmpty()){
			transplante = (TransplantePosOperatorio) results.get(0);
		}
		return transplante;
	}
}
