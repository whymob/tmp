package pt.iconic.ipst.modelo;

import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;

@Entity
@Table(name = "HOSPITAL")
public class Hospital {

	private Long Id_Hospital;
//	private List<Utilizador> Utilizadores;
	private String NomeHospital;
	private GCCT gcct;
	private List<Dador> Dador;
	private List<PermissaoLocalizacao> permissoes;
	private List<Recetores> recetor;
	private List<Unidade_Hospital> unidtransp;
	private List<AssignacaoHospital> assignacao;
	private List<EquipaLocal> equipalocal;
	private List<EquipaLocalTransplante> equipalocaltransplante;
	private Entidade entidade;
	private List<GCCTColheita> gcctcolheita;
	private List<Objetivos> objetivos;
	private List<Premios> premios;
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="ID_HOSPITAL")
	public Long getId_Hospital() {
		return Id_Hospital;
	}
	public void setId_Hospital(Long id_Hospital) {
		Id_Hospital = id_Hospital;
	}
	
	@NotNull
	@Column(name="NOMEHOSPITAL")
	public String getNomeHospital() {
		return NomeHospital;
	}
	public void setNomeHospital(String nomeHospital) {
		NomeHospital = nomeHospital;
	}
	
	@OneToMany(fetch = FetchType.LAZY, mappedBy = "hosp")
    public List<Unidade_Hospital> getUnidtransp() {
		return unidtransp;
	}
	public void setUnidtransp(List<Unidade_Hospital> unidtransp) {
		this.unidtransp = unidtransp;
	}
	@ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "ID_GCCT")
	public GCCT getGcct() {
		return gcct;
	}
	public void setGcct(GCCT gcct) {
		this.gcct = gcct;
	}
	
	@OneToMany(fetch = FetchType.LAZY, mappedBy = "hospital")
	public List<Dador> getDador() {
		return Dador;
	}
	public void setDador(List<Dador> dador) {
		Dador = dador;
	}
	
	@OneToMany(fetch = FetchType.LAZY, mappedBy = "hospital")
	public List<PermissaoLocalizacao> getPermissoes() {
		return permissoes;
	}
	public void setPermissoes(List<PermissaoLocalizacao> permissoes) {
		this.permissoes = permissoes;
	}
	
	@OneToMany(fetch = FetchType.LAZY, mappedBy = "hospital")
	public List<Recetores> getRecetor() {
		return recetor;
	}
	public void setRecetor(List<Recetores> recetor) {
		this.recetor = recetor;
	}
	
	@OneToMany(fetch = FetchType.LAZY, mappedBy = "hospital")
	public List<AssignacaoHospital> getAssignacao() {
		return assignacao;
	}
	public void setAssignacao(List<AssignacaoHospital> assignacao) {
		this.assignacao = assignacao;
	}
	
	@OneToMany(fetch = FetchType.LAZY, mappedBy = "hospital")
	public List<EquipaLocal> getEquipalocal() {
		return equipalocal;
	}
	public void setEquipalocal(List<EquipaLocal> equipalocal) {
		this.equipalocal = equipalocal;
	}
	
	@OneToMany(fetch = FetchType.LAZY, mappedBy = "hospital")
	public List<EquipaLocalTransplante> getEquipalocaltransplante() {
		return equipalocaltransplante;
	}
	public void setEquipalocaltransplante(List<EquipaLocalTransplante> equipalocaltransplante) {
		this.equipalocaltransplante = equipalocaltransplante;
	}
	
	
	@ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "ID_ENTIDADE")
	public Entidade getEntidade() {
		return entidade;
	}
	public void setEntidade(Entidade entidade) {
		this.entidade = entidade;
	}
	
	@OneToMany(fetch = FetchType.LAZY, mappedBy = "hospital")
	public List<GCCTColheita> getGcctcolheita() {
		return gcctcolheita;
	}
	public void setGcctcolheita(List<GCCTColheita> gcctcolheita) {
		this.gcctcolheita = gcctcolheita;
	}
	
	@OneToMany(fetch = FetchType.LAZY, mappedBy = "hospital")
	public List<Objetivos> getObjetivos() {
		return objetivos;
	}
	public void setObjetivos(List<Objetivos> objetivos) {
		this.objetivos = objetivos;
	}
	
	@OneToMany(fetch = FetchType.LAZY, mappedBy = "hospital")
	public List<Premios> getPremios() {
		return premios;
	}
	public void setPremios(List<Premios> premios) {
		this.premios = premios;
	}
	
}
