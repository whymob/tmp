package pt.iconic.ipst.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import pt.iconic.ipst.modelo.ColheitaRinsPerfusao;


@Repository
@Transactional
public class ColheitaRinsPerfusaoDAO {

	
	@PersistenceContext
	private EntityManager manager;
	
	
	public void adiciona(ColheitaRinsPerfusao colheita){
		manager.persist(colheita);	
	}
	

	public void atualiza(ColheitaRinsPerfusao colheita){
		manager.merge(colheita);
	}
	

/*	@SuppressWarnings("unchecked")
	public List<ColheitaRinsPerfusao> ListaColheitaRinsPerfusao(){
		return manager.createQuery("select a from ColheitaRinsPerfusao a").getResultList();
	}*/
	
	public ColheitaRinsPerfusao buscaPorId(Long id){
		return manager.find(ColheitaRinsPerfusao.class, id);
	}
	
	
	public void remove(ColheitaRinsPerfusao colheita){
		ColheitaRinsPerfusao colheitaARemover = buscaPorId(colheita.getIdperfrins());
		manager.remove(colheitaARemover);
		
	}
	
	@SuppressWarnings("unchecked")
	public List<ColheitaRinsPerfusao> ListaColheitaRinsPerfusaoanalise(Long idanalise){
		
		Query query = manager.createQuery("select b from ColheitaRinsPerfusao b JOIN b.analiseDador a WHERE a.id_AnaliseDador =:idanalise");
		query.setParameter("idanalise", idanalise);
		
		List<ColheitaRinsPerfusao> results = query.getResultList();

		return results;
		
	}
}
