package pt.iconic.ipst.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import pt.iconic.ipst.modelo.EquipaSuporteTransplante;;

@Repository
@Transactional
public class EquipaSuporteTransplanteDAO {

	@PersistenceContext
	private EntityManager manager;
	
	
	public void adiciona(EquipaSuporteTransplante es){
		manager.persist(es);	
	}
	
	public void atualiza(EquipaSuporteTransplante es){
		manager.merge(es);
	}
	

/*	@SuppressWarnings("unchecked")
	public List<EquipaSuporteTransplante> ListaEquipaSuporteTransplante(){
		return manager.createQuery("select a from EquipaSuporteTransplante a").getResultList();
	}*/
	
	public EquipaSuporteTransplante buscaPorId(Long id){
		return manager.find(EquipaSuporteTransplante.class, id);
	}
	
	
	public void remove(EquipaSuporteTransplante es){
		EquipaSuporteTransplante esARemover = buscaPorId(es.getIdequipasuporte());
		manager.remove(esARemover);
	}

	@SuppressWarnings("unchecked")
	public List<EquipaSuporteTransplante> buscaequipacsuportetransplanteassigorgao(Long id_assigorg) {
		
	//	Query query = manager.createQuery("select es from EquipaSuporteTransplante es JOIN es.dador d where d.id_Dador =:iddador");
		Query query = manager.createQuery("select es from EquipaSuporteTransplante es JOIN es.assigorgao ass where ass.id_assignacao =:id_assigorg");
		query.setParameter("id_assigorg", id_assigorg);

		List<EquipaSuporteTransplante> results = query.getResultList();
		
		return results;
	}
	
	
}
