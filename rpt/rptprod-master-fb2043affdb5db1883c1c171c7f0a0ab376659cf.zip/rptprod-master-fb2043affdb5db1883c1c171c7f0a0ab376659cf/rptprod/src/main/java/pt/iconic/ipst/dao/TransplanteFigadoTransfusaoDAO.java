package pt.iconic.ipst.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import pt.iconic.ipst.modelo.TransplanteFigadoTransfusao;

@Repository
@Transactional
public class TransplanteFigadoTransfusaoDAO {

	@PersistenceContext
	private EntityManager manager;
	
	
	public void adiciona(TransplanteFigadoTransfusao transplante){
		manager.persist(transplante);	
	}
	

	public void atualiza(TransplanteFigadoTransfusao transplante){
		manager.merge(transplante);
	}
	

/*	@SuppressWarnings("unchecked")
	public List<TransplanteFigadoTransfusao> ListaTransplanteFigadoTransfusao(){
		return manager.createQuery("select a from TransplanteFigadoTransfusao a").getResultList();
	}*/
	
	public TransplanteFigadoTransfusao buscaPorId(Long id){
		return manager.find(TransplanteFigadoTransfusao.class, id);
	}
	
	
	public void remove(TransplanteFigadoTransfusao transplante){
		TransplanteFigadoTransfusao transplanteARemover = buscaPorId(transplante.getIdfigadotransf());
		manager.remove(transplanteARemover);
		
	}
	
	@SuppressWarnings("unchecked")
	public List<TransplanteFigadoTransfusao> ListaTransplanteFigadoTransfusaoassig(Long idassigorg){
		
		Query query = manager.createQuery("select p from TransplanteFigadoTransfusao p JOIN p.assigorgao a WHERE a.id_assignacao =:idassigorg");
		query.setParameter("idassigorg", idassigorg);
		
		List<TransplanteFigadoTransfusao> results = query.getResultList();

		return results;
		
	}
}
