package pt.iconic.ipst.modelo;

import java.util.Calendar;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import org.springframework.format.annotation.DateTimeFormat;

@Entity
@Table(name = "OBJETIVOS")
public class Objetivos 
{
	private Long id_objetivo;
	private int ano;
	private int objetivo;
	private int objetivoref;
	private int realizado;
	private boolean pagamento;
	private Calendar datapagamento;
	private Entidade entidade;
	private Hospital hospital;
	private OrgaosOferta orgaosoferta;
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="ID_OBJETIVO")
	public Long getId_objetivo() {
		return id_objetivo;
	}
	public void setId_objetivo(Long id_objetivo) {
		this.id_objetivo = id_objetivo;
	}
	
	@Column(name="ANO")
	public int getAno() {
		return ano;
	}
	public void setAno(int ano) {
		this.ano = ano;
	}
	
	@Column(name="OBJETIVO")
	public int getObjetivo() {
		return objetivo;
	}
	public void setObjetivo(int objetivo) {
		this.objetivo = objetivo;
	}
	
	@Column(name="OBJETIVOREF")
	public int getObjetivoref() {
		return objetivoref;
	}
	public void setObjetivoref(int objetivoref) {
		this.objetivoref = objetivoref;
	}
	
	@Column(name="REALIZADO")
	public int getRealizado() {
		return realizado;
	}
	public void setRealizado(int realizado) {
		this.realizado = realizado;
	}
	
	@Column(name="PAGAMENTO")
	public boolean isPagamento() {
		return pagamento;
	}
	public void setPagamento(boolean pagamento) {
		this.pagamento = pagamento;
	}
	
	@DateTimeFormat(pattern="dd/MM/yyyy")
	@Column(name="DATAPAGAMENTO")
	public Calendar getDatapagamento() {
		return datapagamento;
	}
	public void setDatapagamento(Calendar datapagamento) {
		this.datapagamento = datapagamento;
	}
	
	@ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "ID_ENTIDADE")
	public Entidade getEntidade() {
		return entidade;
	}
	public void setEntidade(Entidade entidade) {
		this.entidade = entidade;
	}
	
	@ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "ID_HOSPITAL")
	public Hospital getHospital() {
		return hospital;
	}
	public void setHospital(Hospital hospital) {
		this.hospital = hospital;
	}
	
	@ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "ID_ORGAO_OFERTA")
	public OrgaosOferta getOrgaosoferta() {
		return orgaosoferta;
	}
	public void setOrgaosoferta(OrgaosOferta orgaosoferta) {
		this.orgaosoferta = orgaosoferta;
	}
}
