package pt.iconic.ipst.modelo;

import java.util.Calendar;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name = "TRANSPLANTADOS")
public class Transplantes 
{
	private Long id_transplante;
	private String codigotransplantado;
	private String nometransplantado;
	private Calendar datatransplante;
/*	private OrgaosOferta orgaosoferta;
	private Orgaos orgaos;*/
	private Hospital hospital;
	private int estadotransplantado;
	private int sns;
	private UnidadeTransplante unidadetransp;
	private TransplantadoDetalhes transplantadodetalhe;
	private List<PPAnalisesFollowUp>  ppanalisesfollowup;
	private List<TerapeuticasFollowUP> Terapeuticasfollowup;
	private Recetores recetor;
	private AssignacaoOrgaos assigorgao;
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="ID_TRANSPLANTE")
	public Long getId_transplante() {
		return id_transplante;
	}
	public void setId_transplante(Long id_transplante) {
		this.id_transplante = id_transplante;
	}
	
	@Column(name="CODIGO")
	public String getCodigotransplantado() {
		return codigotransplantado;
	}
	public void setCodigotransplantado(String codigotransplantado) {
		this.codigotransplantado = codigotransplantado;
	}
	
	@Column(name="NOME")
	public String getNometransplantado() {
		return nometransplantado;
	}
	public void setNometransplantado(String nometransplantado) {
		this.nometransplantado = nometransplantado;
	}
	
	@Column(name="DATA")
	public Calendar getDatatransplante() {
		return datatransplante;
	}
	public void setDatatransplante(Calendar datatransplante) {
		this.datatransplante = datatransplante;
	}
	
/*	@ManyToOne(fetch=FetchType.EAGER)
	@JoinColumn(name="ID_ORGAO_OFERTA")
	public OrgaosOferta getOrgaosoferta() {
		return orgaosoferta;
	}
	public void setOrgaosoferta(OrgaosOferta orgaosoferta) {
		this.orgaosoferta = orgaosoferta;
	}*/
	
	@ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "ID_HOSPITAL")
	public Hospital getHospital() {
		return hospital;
	}
	public void setHospital(Hospital hospital) {
		this.hospital = hospital;
	}
	
	@Column(name="ESTADO")
	public int getEstadotransplantado() {
		return estadotransplantado;
	}
	public void setEstadotransplantado(int estadotransplantado) {
		this.estadotransplantado = estadotransplantado;
	}
	
	@OneToOne(fetch = FetchType.LAZY, mappedBy = "tranplantado")
	public TransplantadoDetalhes getTransplantadodetalhe() {
		return transplantadodetalhe;
	}
	public void setTransplantadodetalhe(TransplantadoDetalhes transplantadodetalhe) {
		this.transplantadodetalhe = transplantadodetalhe;
	}
	
	@Column(name="SNS")
	public int getSns() {
		return sns;
	}
	public void setSns(int sns) {
		this.sns = sns;
	}
	
	@ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "ID_UNIDADETRANSP")
	public UnidadeTransplante getUnidadetransp() {
		return unidadetransp;
	}
	public void setUnidadetransp(UnidadeTransplante unidadetransp) {
		this.unidadetransp = unidadetransp;
	}
	
	@OneToMany(fetch = FetchType.LAZY, mappedBy = "transplantado")
	public List<PPAnalisesFollowUp> getPpanalisesfollowup() {
		return ppanalisesfollowup;
	}
	public void setPpanalisesfollowup(List<PPAnalisesFollowUp> ppanalisesfollowup) {
		this.ppanalisesfollowup = ppanalisesfollowup;
	}
	
	@OneToMany(fetch = FetchType.LAZY, mappedBy = "transplantado")
	public List<TerapeuticasFollowUP> getTerapeuticasfollowup() {
		return Terapeuticasfollowup;
	}
	public void setTerapeuticasfollowup(List<TerapeuticasFollowUP> terapeuticasfollowup) {
		Terapeuticasfollowup = terapeuticasfollowup;
	}
	
	@ManyToOne(fetch=FetchType.EAGER)
	@JoinColumn(name="ID_RECETOR")
	public Recetores getRecetor() {
		return recetor;
	}
	public void setRecetor(Recetores recetor) {
		this.recetor = recetor;
	}
	
	@OneToOne(fetch=FetchType.EAGER)
	@JoinColumn(name="ID_ASSIG_ORGAO")
	public AssignacaoOrgaos getAssigorgao() {
		return assigorgao;
	}
	public void setAssigorgao(AssignacaoOrgaos assigorgao) {
		this.assigorgao = assigorgao;
	}
	
/*	@ManyToOne(fetch=FetchType.EAGER)
	@JoinColumn(name="ID_ORGAO")
	public Orgaos getOrgaos() {
		return orgaos;
	}
	public void setOrgaos(Orgaos orgaos) {
		this.orgaos = orgaos;
	}*/
}