package pt.iconic.ipst.modelo;

import java.util.Calendar;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name = "MORTECEREBRAL")
public class MorteCerebral 
{
	private Long Id_MorteCerebral;
	private AnaliseDador analiseDador;
//	private DiagnosticoMC DiagnosticoMC;
//	private CausasExternasMC CausasExternas;
	private boolean pcr;
	private int reanimacoes;
	private Calendar duracaoparagem;
	private Calendar duracaoultimareanimacao;
	private String p1_medico1;
	private int p1_om1;
	private Calendar p1_data;
	private String p1_medico2;
	private int p1_om2;
	private String p2_medico1;
	private int p2_om1;
	private Calendar p2_data;
	private boolean p2_conf;
	private String p2_medico2;
	private int p2_om2;
	private String caminhodocmc;
	private String nomedocmc;
	private boolean statusharmonio;
	private Calendar datagravacao;
	
//	private List<DocumentoMC> DocumentoMC;
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="ID_MORTECEREBRAL")
	public Long getId_MorteCerebral() {
		return Id_MorteCerebral;
	}
	public void setId_MorteCerebral(Long id_MorteCerebral) {
		Id_MorteCerebral = id_MorteCerebral;
	}
	
	
	@OneToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="ID_ANALISEDADOR")
	public AnaliseDador getAnaliseDador() {
		return analiseDador;
	}
	public void setAnaliseDador(AnaliseDador analiseDador) {
		this.analiseDador = analiseDador;
	}
	
//	@OneToOne
//	@JoinColumn(name="ID_DIAGNOSTICOMC")
//	public DiagnosticoMC getDiagnosticoMC() {
//		return DiagnosticoMC;
//	}
//	public void setDiagnosticoMC(DiagnosticoMC diagnosticoMC) {
//		DiagnosticoMC = diagnosticoMC;
//	}
	
//	@OneToOne
//	@JoinColumn(name="ID_CAUSASEXTERNASMC")
//	public CausasExternasMC getCausasExternas() {
//		return CausasExternas;
//	}
//	public void setCausasExternas(CausasExternasMC causasExternas) {
//		CausasExternas = causasExternas;
//	}
	
	@Column(name="PCR")
	public boolean isPcr() {
		return pcr;
	}
	public void setPcr(boolean pcr) {
		this.pcr = pcr;
	}
	
	@Column(name="REANIMACOES")
	public int getReanimacoes() {
		return reanimacoes;
	}
	public void setReanimacoes(int reanimacoes) {
		this.reanimacoes = reanimacoes;
	}
	
	@Column(name="DURACAOPARAGEM")
	public Calendar getDuracaoparagem() {
		return duracaoparagem;
	}
	public void setDuracaoparagem(Calendar duracaoparagem) {
		this.duracaoparagem = duracaoparagem;
	}
	
	@Column(name="DURACAOULTIMAREANIMACAO")
	public Calendar getDuracaoultimareanimacao() {
		return duracaoultimareanimacao;
	}
	public void setDuracaoultimareanimacao(Calendar duracaoultimareanimacao) {
		this.duracaoultimareanimacao = duracaoultimareanimacao;
	}
	
	@Column(name="P1_MEDICO1")
	public String getP1_medico1() {
		return p1_medico1;
	}
	public void setP1_medico1(String p1_medico1) {
		this.p1_medico1 = p1_medico1;
	}
	
	@Column(name="P1_OM1")
	public int getP1_om1() {
		return p1_om1;
	}
	public void setP1_om1(int p1_om1) {
		this.p1_om1 = p1_om1;
	}
	
	@Column(name="P1_DATA")
	public Calendar getP1_data() {
		return p1_data;
	}
	public void setP1_data(Calendar p1_data) {
		this.p1_data = p1_data;
	}
	
	@Column(name="P1_MEDICO2")
	public String getP1_medico2() {
		return p1_medico2;
	}
	public void setP1_medico2(String p1_medico2) {
		this.p1_medico2 = p1_medico2;
	}
	
	@Column(name="P1_OM2")
	public int getP1_om2() {
		return p1_om2;
	}
	public void setP1_om2(int p1_om2) {
		this.p1_om2 = p1_om2;
	}
	
	@Column(name="P2_MEDICO1")
	public String getP2_medico1() {
		return p2_medico1;
	}
	public void setP2_medico1(String p2_medico1) {
		this.p2_medico1 = p2_medico1;
	}
	
	@Column(name="P2_OM1")
	public int getP2_om1() {
		return p2_om1;
	}
	public void setP2_om1(int p2_om1) {
		this.p2_om1 = p2_om1;
	}
	
	@Column(name="P2_DATA")
	public Calendar getP2_data() {
		return p2_data;
	}
	public void setP2_data(Calendar p2_data) {
		this.p2_data = p2_data;
	}
	
	@Column(name="P2_CONF")
	public boolean isP2_conf() {
		return p2_conf;
	}
	public void setP2_conf(boolean p2_conf) {
		this.p2_conf = p2_conf;
	}
	
	@Column(name="P2_MEDICO2")
	public String getP2_medico2() {
		return p2_medico2;
	}
	public void setP2_medico2(String p2_medico2) {
		this.p2_medico2 = p2_medico2;
	}
	
	@Column(name="P2_OM2")
	public int getP2_om2() {
		return p2_om2;
	}
	public void setP2_om2(int p2_om2) {
		this.p2_om2 = p2_om2;
	}

	@Column(name="CAMINHO_DOC_MC")
	public String getCaminhodocmc() {
		return caminhodocmc;
	}
	public void setCaminhodocmc(String caminhodocmc) {
		this.caminhodocmc = caminhodocmc;
	}
	
	@Column(name="NOME_DOC_MC")
	public String getNomedocmc() {
		return nomedocmc;
	}
	public void setNomedocmc(String nomedocmc) {
		this.nomedocmc = nomedocmc;
	}
	
	@Column(name="STATUSHARMONIO")
	public boolean isStatusharmonio() {
		return statusharmonio;
	}

	public void setStatusharmonio(boolean statusharmonio) {
		this.statusharmonio = statusharmonio;
	}
	

	@Column(name="DATAGRAVACAO")
	public Calendar getDatagravacao() {
		return datagravacao;
	}

	public void setDatagravacao(Calendar datagravacao) {
		this.datagravacao = datagravacao;
	}
}
