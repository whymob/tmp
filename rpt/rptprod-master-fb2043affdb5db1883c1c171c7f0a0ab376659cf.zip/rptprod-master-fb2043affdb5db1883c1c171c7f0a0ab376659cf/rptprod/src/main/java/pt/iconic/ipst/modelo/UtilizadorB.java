package pt.iconic.ipst.modelo;

import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;








import org.hibernate.validator.constraints.Range;


@Entity
@Table(name = "UTILIZADORB")
public class UtilizadorB {

	
	private Long Id_UtilizadorB;
	private int codigoOM;
	private int pin;
	private String nome;
	private String email;
	private String localTrabalho;
	private String codigoUUID;
	private List<Dador> dador;
	private List<HistoricoReferenciacao> hist;
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="ID_UTILIZADORB")
	public Long getId_UtilizadorB() {
		return Id_UtilizadorB;
	}
	public void setId_UtilizadorB(Long id_UtilizadorB) {
		Id_UtilizadorB = id_UtilizadorB;
	}
	
	@NotNull
	@Column(name="CODIGOOM", unique=true)
	@Range(min = 1, message="Preencha corretamente o codigoOM")
	public int getCodigoOM() {
		return codigoOM;
	}
	public void setCodigoOM(int codigoOM) {
		this.codigoOM = codigoOM;
	}


	//@Range(min=1, message="Preencha corretamente o PIN")
	@NotNull
	@Column(name="PIN")
	public int getPin() {
		return pin;
	}
	public void setPin(int pin) {
		this.pin = pin;
	}
	
	@NotNull
	@Column(name="NOME")
	public String getNome() {
		return nome;
	}
	public void setNome(String nome) {
		this.nome = nome;
	}
	
	@NotNull
	@Column(name="EMAIL", unique=true)
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	
	@NotNull
	@Column(name="LOCALTRABALHO")
	public String getLocalTrabalho() {
		return localTrabalho;
	}
	public void setLocalTrabalho(String localTrabalho) {
		this.localTrabalho = localTrabalho;
	}
	
	@Column(name="CODIGOUUID")
	public String getCodigoUUID() {
		return codigoUUID;
	}
	public void setCodigoUUID(String codigoUUID) {
		this.codigoUUID = codigoUUID;
	}

	@OneToMany(fetch = FetchType.LAZY, mappedBy = "utilizadorb")
	public List<Dador> getDador() {
		return dador;
	}
	public void setDador(List<Dador> dador) {
		this.dador = dador;
	}
	
	@OneToMany(fetch = FetchType.LAZY, mappedBy = "utilizadorb")
	public List<HistoricoReferenciacao> getHist() {
		return hist;
	}
	public void setHist(List<HistoricoReferenciacao> hist) {
		this.hist = hist;
	}	
	
	
}
