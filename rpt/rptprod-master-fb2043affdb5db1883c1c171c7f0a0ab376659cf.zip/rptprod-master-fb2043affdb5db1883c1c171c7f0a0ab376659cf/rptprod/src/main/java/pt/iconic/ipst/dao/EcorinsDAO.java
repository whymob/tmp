package pt.iconic.ipst.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import pt.iconic.ipst.modelo.EcoAbdRins;

@Repository
@Transactional
public class EcorinsDAO
{
	@PersistenceContext
	private EntityManager manager;
	
	public void adiciona(EcoAbdRins eco){
		manager.persist(eco);	
	}

	public void atualiza(EcoAbdRins eco){
		manager.merge(eco);
	}

/*	public EcoAbdRins buscaPorId(Long id){
		return manager.find(EcoAbdRins.class, id);
	}
	
	public void remove(EcoAbdRins eco){
		EcoAbdRins ecor = buscaPorId(eco.getId_Ecoabdrins());
		manager.remove(ecor);
	}*/
	

	@SuppressWarnings("rawtypes")
	public EcoAbdRins ListaEcoAbdFigado(Long id)
	{
		Query query = manager.createQuery("select e from EcoAbdRins e JOIN e.analiseDador analisedador WHERE analisedador.id_AnaliseDador =:idanalise");
		query.setParameter("idanalise", id);

		List results = query.getResultList();
		EcoAbdRins ecor = null;
		
		if(!results.isEmpty())
		{
			ecor = (EcoAbdRins) results.get(0);
		}
		
		return ecor;
	}
}