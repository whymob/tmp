package pt.iconic.ipst.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import pt.iconic.ipst.modelo.TransplantePancreas;

@Repository
@Transactional
public class TransplantePancreasDAO {

	
	@PersistenceContext
	private EntityManager manager;
	
	public void adiciona(TransplantePancreas transplante){
		manager.persist(transplante);	
	}
	
	public void atualiza(TransplantePancreas transplante){
		manager.merge(transplante);
	}
	
/*	@SuppressWarnings("unchecked")
	public List<TransplantePancreas> ListaTransplantePancreas(){
		return manager.createQuery("select a from TransplantePancreas a").getResultList();
	}*/
	
	public TransplantePancreas buscaPorId(Long id){
		return manager.find(TransplantePancreas.class, id);
	}
	
/*	public void remove(TransplantePancreas transplante){
		TransplantePancreas transplanteARemover = buscaPorId(transplante.getIdtransplantepancreas());
		manager.remove(transplanteARemover);
	}*/
	
	@SuppressWarnings("unchecked")
	public TransplantePancreas buscaTransplantePancreasAssigorgao(Long idassigorg){
		
		Query query = manager.createQuery("select p from TransplantePancreas p JOIN p.assigorgao a WHERE a.id_assignacao =:idassigorg");
		query.setParameter("idassigorg", idassigorg);
		
		List<TransplantePancreas> results = query.getResultList();
		TransplantePancreas transplante = null;
		if(!results.isEmpty()){
			transplante = (TransplantePancreas) results.get(0);
		}
		return transplante;
	}
}
