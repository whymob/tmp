package pt.iconic.ipst.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import pt.iconic.ipst.modelo.Sensibilidade;

@Repository
@Transactional
public class SensibilidadeDAO 
{
	@PersistenceContext
	private EntityManager manager;	
	
	public void adiciona(Sensibilidade sensibilidade){
		manager.persist(sensibilidade);	
	}
	
	public void atualiza(Sensibilidade sensibilidade){
		manager.merge(sensibilidade);
	}

	@SuppressWarnings("unchecked")
	public List<Sensibilidade> ListaSensibilidade(){
		return manager.createQuery("select s from Sensibilidade s").getResultList();
	}
	
	public Sensibilidade buscaPorId(Long id){
		return manager.find(Sensibilidade.class, id);
	}
		
	public void remove(Sensibilidade sensibilidade){
		Sensibilidade causamorteARemover = buscaPorId(sensibilidade.getId_Sensibilidade());
		manager.remove(causamorteARemover);
	}
	
	public boolean trataadicionar(String desc)
	{
		Query query = manager.createQuery("SELECT e from Sensibilidade e WHERE e.sensDescricao =:desc");
		query.setParameter("desc", desc);
		
		if(query.getResultList().isEmpty())
		{
			Sensibilidade sensi = new Sensibilidade();
			sensi.setSensDescricao(desc);
			adiciona(sensi);
			
			return true;
		}
		else
		{
			return false;
		}
	}
	
	public boolean trataalterar(Long id, String desc)
	{
		Query query = manager.createQuery("SELECT e from Sensibilidade e WHERE e.sensDescricao =:desc");
		query.setParameter("desc", desc);
		
		if(query.getResultList().isEmpty())
		{
			Sensibilidade sensi = new Sensibilidade();
			sensi.setSensDescricao(desc);
			sensi.setId_Sensibilidade(id);
			atualiza(sensi);
				
			return true;
		}
		else
		{
			return false;
		}		
	}
	
	public boolean remover(Long id) 
	{
		Sensibilidade sensi = new Sensibilidade();
		sensi = buscaPorId(id);

		remove(sensi);
		return true;
	}
}