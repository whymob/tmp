package pt.iconic.ipst.modelo;

import java.util.Calendar;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name = "HCSITUACOESRISCO")
public class HCSituacoesRisco {

	
	private Long Id_HCSituacoesRisco;
	private AnaliseDador analiseDador;
	private boolean corticoides;
	private boolean hemodialise;
	private boolean transfusoes;
	private boolean transplantes;
	private boolean hemofilia;
	private boolean tatuagenspiercings;
	private boolean irradiacaoquimioterapia;
	private boolean alcooldrogasmetaispesados;
	private boolean toxicofilia;
	private boolean drogasiv;
	private boolean infecoesbacterianas;
	private boolean vacinacaovirus;
	private boolean instituicaoprisional;
	private boolean viagens;
	private boolean comportamentosexual;
	private boolean terapeuticahormonal;
	private boolean transplanteduramater;
	private boolean intervencaoneurocirurgica;
	private boolean transfusoessangue1980;
	private boolean creutzfeldtjacob;
	private boolean outrossitrisco;	
	private String observacoessitrisco;
	private boolean statusharmsitrisco;
	private Calendar datagravacao;
	
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="ID_HCSITUACOESRISCO")
	public Long getId_HCSituacoesRisco() {
		return Id_HCSituacoesRisco;
	}
	public void setId_HCSituacoesRisco(Long id_HCSituacoesRisco) {
		Id_HCSituacoesRisco = id_HCSituacoesRisco;
	}
	
	@OneToOne
	@JoinColumn(name="ID_ANALISEDADOR")
	public AnaliseDador getAnaliseDador() {
		return analiseDador;
	}
	public void setAnaliseDador(AnaliseDador analiseDador) {
		this.analiseDador = analiseDador;
	}
	
	@Column(name="CORTICOIDES")
	public boolean isCorticoides() {
		return corticoides;
	}
	public void setCorticoides(boolean corticoides) {
		this.corticoides = corticoides;
	}
	
	@Column(name="HEMODIALISE")
	public boolean isHemodialise() {
		return hemodialise;
	}
	public void setHemodialise(boolean hemodialise) {
		this.hemodialise = hemodialise;
	}
	
	@Column(name="TRANSFUSOES")
	public boolean isTransfusoes() {
		return transfusoes;
	}
	public void setTransfusoes(boolean transfusoes) {
		this.transfusoes = transfusoes;
	}
	
	@Column(name="TRANSPLANTES")
	public boolean isTransplantes() {
		return transplantes;
	}
	public void setTransplantes(boolean transplantes) {
		this.transplantes = transplantes;
	}
	
	@Column(name="HEMOFILIA")
	public boolean isHemofilia() {
		return hemofilia;
	}
	public void setHemofilia(boolean hemofilia) {
		this.hemofilia = hemofilia;
	}
	
	@Column(name="TATUAGENSPIERCINGS")
	public boolean isTatuagenspiercings() {
		return tatuagenspiercings;
	}
	public void setTatuagenspiercings(boolean tatuagenspiercings) {
		this.tatuagenspiercings = tatuagenspiercings;
	}
	
	@Column(name="IRRADIACAOQUIMIOTERAPIA")
	public boolean isIrradiacaoquimioterapia() {
		return irradiacaoquimioterapia;
	}
	public void setIrradiacaoquimioterapia(boolean irradiacaoquimioterapia) {
		this.irradiacaoquimioterapia = irradiacaoquimioterapia;
	}
	
	@Column(name="ALCOOLDROGASMETAISPESADOS")
	public boolean isAlcooldrogasmetaispesados() {
		return alcooldrogasmetaispesados;
	}
	public void setAlcooldrogasmetaispesados(boolean alcooldrogasmetaispesados) {
		this.alcooldrogasmetaispesados = alcooldrogasmetaispesados;
	}
	
	@Column(name="TOXICOFILIA")
	public boolean isToxicofilia() {
		return toxicofilia;
	}
	public void setToxicofilia(boolean toxicofilia) {
		this.toxicofilia = toxicofilia;
	}
	
	@Column(name="DROGASIV")
	public boolean isDrogasiv() {
		return drogasiv;
	}
	public void setDrogasiv(boolean drogasiv) {
		this.drogasiv = drogasiv;
	}
	
	@Column(name="INFECOESBACTERIANAS")
	public boolean isInfecoesbacterianas() {
		return infecoesbacterianas;
	}
	public void setInfecoesbacterianas(boolean infecoesbacterianas) {
		this.infecoesbacterianas = infecoesbacterianas;
	}
	
	@Column(name="VACINACAOVIRUS")
	public boolean isVacinacaovirus() {
		return vacinacaovirus;
	}
	public void setVacinacaovirus(boolean vacinacaovirus) {
		this.vacinacaovirus = vacinacaovirus;
	}
	
	@Column(name="INSTITUICAOPRISIONAL")
	public boolean isInstituicaoprisional() {
		return instituicaoprisional;
	}
	public void setInstituicaoprisional(boolean instituicaoprisional) {
		this.instituicaoprisional = instituicaoprisional;
	}
	
	@Column(name="VIAGENS")
	public boolean isViagens() {
		return viagens;
	}
	public void setViagens(boolean viagens) {
		this.viagens = viagens;
	}
	
	@Column(name="COMPORTAMENTOSEXUAL")
	public boolean isComportamentosexual() {
		return comportamentosexual;
	}
	public void setComportamentosexual(boolean comportamentosexual) {
		this.comportamentosexual = comportamentosexual;
	}
	
	@Column(name="TERAPEUTICAHORMONAL")
	public boolean isTerapeuticahormonal() {
		return terapeuticahormonal;
	}
	public void setTerapeuticahormonal(boolean terapeuticahormonal) {
		this.terapeuticahormonal = terapeuticahormonal;
	}
	
	@Column(name="TRANSPLANTEDURAMATER")
	public boolean isTransplanteduramater() {
		return transplanteduramater;
	}
	public void setTransplanteduramater(boolean transplanteduramater) {
		this.transplanteduramater = transplanteduramater;
	}
	
	@Column(name="INTERVENCAONEUROCIRURGICA")
	public boolean isIntervencaoneurocirurgica() {
		return intervencaoneurocirurgica;
	}
	public void setIntervencaoneurocirurgica(boolean intervencaoneurocirurgica) {
		this.intervencaoneurocirurgica = intervencaoneurocirurgica;
	}
	
	@Column(name="TRANSFUSOESSANGUE1980")
	public boolean isTransfusoessangue1980() {
		return transfusoessangue1980;
	}
	public void setTransfusoessangue1980(boolean transfusoessangue1980) {
		this.transfusoessangue1980 = transfusoessangue1980;
	}
	
	@Column(name="CREUTZFELDTJACOB")
	public boolean isCreutzfeldtjacob() {
		return creutzfeldtjacob;
	}
	public void setCreutzfeldtjacob(boolean creutzfeldtjacob) {
		this.creutzfeldtjacob = creutzfeldtjacob;
	}
	
	@Column(name="OUTROS")
	public boolean isOutrossitrisco() {
		return outrossitrisco;
	}
	public void setOutrossitrisco(boolean outrossitrisco) {
		this.outrossitrisco = outrossitrisco;
	}


	
	@Column(name="OBSERVACOESSITRISCO")
	public String getObservacoessitrisco() {
		return observacoessitrisco;
	}
	public void setObservacoessitrisco(String observacoessitrisco) {
		this.observacoessitrisco = observacoessitrisco;
	}
	
	@Column(name="STATUSHARMONIO")
	public boolean isStatusharmsitrisco() {
		return statusharmsitrisco;
	}
	public void setStatusharmsitrisco(boolean statusharmsitrisco) {
		this.statusharmsitrisco = statusharmsitrisco;
	} 
	
	@Column(name="DATAGRAVACAO")
	public Calendar getDatagravacao() {
		return datagravacao;
	}


	public void setDatagravacao(Calendar datagravacao) {
		this.datagravacao = datagravacao;
	}
	
}
