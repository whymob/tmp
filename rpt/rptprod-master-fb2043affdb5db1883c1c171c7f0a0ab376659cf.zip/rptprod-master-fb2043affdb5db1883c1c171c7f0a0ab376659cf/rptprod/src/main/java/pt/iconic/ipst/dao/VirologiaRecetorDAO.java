package pt.iconic.ipst.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;


import javax.persistence.Query;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import pt.iconic.ipst.modelo.VirologiaRecetor;

@Repository
public class VirologiaRecetorDAO {
	
	@PersistenceContext
	private EntityManager manager;
	
	
/*	public void adiciona(VirologiaRecetor virologia){
		manager.persist(virologia);	
	}*/
	
	@Transactional
	public void atualiza(VirologiaRecetor virologia){
		manager.merge(virologia);
	}
	

/*	@SuppressWarnings("unchecked")
	public List<VirologiaRecetor> ListaVirologia(){
		return manager.createQuery("select a from VirologiaRecetor a").getResultList();
	}*/
	
	public VirologiaRecetor buscaPorId(Long id){
		return manager.find(VirologiaRecetor.class, id);
	}
	
	
/*	public void remove(VirologiaRecetor virologia){
		VirologiaRecetor virologiaARemover = buscaPorId(virologia.getId_virologia());
		manager.remove(virologiaARemover);
		
	}*/
	
	@SuppressWarnings("unchecked")
	public List<VirologiaRecetor> buscaVirologiaRecetorPretransplante(Long idanalise){
		//ESte era quando tinhas as duas an�lises, pr� e p�s transfus�o
//		Query query = manager.createQuery("select b from Virologia b JOIN b.analiseDador a JOIN b.tipoVirologia tipo WHERE a.id_AnaliseDador =:idanalise AND b.prepostransfusao = true ORDER BY tipo.id_tipovirologia");
		Query query = manager.createQuery("select b from VirologiaRecetor b JOIN b.analiserecetor a JOIN b.tipoVirologia tipo WHERE a.id_analiserecetor =:idanalise ORDER BY tipo.id_tipovirologia");
		query.setParameter("idanalise", idanalise);
		
		List<VirologiaRecetor> results = query.getResultList();
		
		return results;
	}
	
	public void carregaamostrasvirologiarecetorpretransf(Long idanalise){
		
	    Query query = manager.createNativeQuery("Insert into VIROLOGIARECETOR(CSTOBS, CSTRADIO, CSTVALOR, PREPOSTRANSFUSAO, "
	    		+ "ID_ANALISERECETOR, ID_TIPOVIROLOGIA) "
	    		+ "select NULL, 1, 0, 'True', :idanalise , ID_TIPOVIROLOGIA from TIPOVIROLOGIA");
	        query.setParameter("idanalise", idanalise);
	        query.executeUpdate();
	}



	//verifica se a an�lise possui todos os tipo mestre de virologia
	public boolean verificatiposmestreadiciona(Long idanalise) {
	
	    Query query = manager.createNativeQuery("select count(ID_TIPOVIROLOGIA) from TIPOVIROLOGIA where ID_TIPOVIROLOGIA not in (select ID_TIPOVIROLOGIA "
	    		+ "from VIROLOGIARECETOR where ID_ANALISERECETOR = :idanalise) ");
	        query.setParameter("idanalise", idanalise);
	        int valor = (int) query.getSingleResult();
		
	        if(valor==0){
	        	return false;
	        }
	        else{
		return true;
	        }
	}

	
	//adicionar tipos de virologia n�o existentes ainda nas virologias prepostransf analise
	@Transactional
	public void adicionavirologiaexistentes(Long idanalise) {
		
	    Query query = manager.createNativeQuery("Insert into VIROLOGIARECETOR(CSTOBS, CSTRADIO, CSTVALOR, PREPOSTRANSFUSAO, "
	    		+ "ID_ANALISERECETOR, ID_TIPOVIROLOGIA) "
	    		+ "(select NULL, 1, 0, 'True', :idanalise , ID_TIPOVIROLOGIA "
	    		+ "from TIPOVIROLOGIA where ID_TIPOVIROLOGIA not in (select ID_TIPOVIROLOGIA "
	    		+ "from VIROLOGIARECETOR where ID_ANALISERECETOR = :idanalise))");
	        query.setParameter("idanalise", idanalise);
	        query.executeUpdate();
		
	}

	@Transactional
	public void guardadadosviro(String dados, Long id_analise) {
		
		//criar lista com dados que vieram do cliente
		String str = dados;
    	String delims = "[,]";
    	String[] lista = str.split(delims);
    	
    	
    	
    	for(int i=0; i<lista.length;i++)
    	{
    		String valor = 	lista[i];
    		String delimitador = "[:]";
    		String[] posicao = valor.split(delimitador);



            
    		VirologiaRecetor viro = buscaPorId(Long.parseLong(posicao[0]));
    		viro.setCstobs(posicao[1]);
    		viro.setCstradio(Integer.parseInt(posicao[2]));
    		viro.setCstvalor(Float.parseFloat(posicao[3]));
    		viro.setPrepostransfusao(Boolean.parseBoolean(posicao[4]));
    		atualiza(viro);	
  
            
    	}
    	
	}
	/*	
	@Transactional
	public void actualizatipotransfviro(boolean tipo, Long id_analise){
		
    	Query query = manager.createNativeQuery("Update VIROLOGIA set PREPOSTRANSFUSAO=:tipo where ID_ANALISEDADOR= :id_analise");
    	query.setParameter("tipo", tipo);
    	query.setParameter("id_analise", id_analise);
    	query.executeUpdate();
		
	}

	@SuppressWarnings("unchecked")
	public boolean verificastatusharmonioviro(Long id_analise) {
		Query query = manager.createQuery("select b from Virologia b JOIN b.analiseDador a JOIN b.tipoVirologia tipo WHERE a.id_AnaliseDador =:idanalise AND (b.hospvalor >0 OR b.cstvalor>0) ORDER BY tipo.id_tipovirologia");
		query.setParameter("idanalise", id_analise);
		
		List<Virologia> results = query.getResultList();
		if(results.isEmpty()){
		//	System.out.println("n�o existem valores nas virologias");
			return false;
		}else{
		//	System.out.println("Existem valores nas virologias");
		return true;
		}
	}*/

}
