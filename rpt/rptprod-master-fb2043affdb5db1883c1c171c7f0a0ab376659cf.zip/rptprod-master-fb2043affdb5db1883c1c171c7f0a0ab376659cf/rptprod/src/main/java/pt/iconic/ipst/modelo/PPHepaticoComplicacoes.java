package pt.iconic.ipst.modelo;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;


@Entity
@Table(name = "PPHEPATICOCOMPLICACOES")
public class PPHepaticoComplicacoes {

	private Long id_pphepaticocomplicacao;
	private AnaliseRecetor analiserecetor;
	private TipoComplicacoes tipocomplicacoes;
	private boolean esc;
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="ID_PPHEPATICO_COMPLICACAO")
	public Long getId_pphepaticocomplicacao() {
		return id_pphepaticocomplicacao;
	}
	public void setId_pphepaticocomplicacao(Long id_pphepaticocomplicacao) {
		this.id_pphepaticocomplicacao = id_pphepaticocomplicacao;
	}
	
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="ID_ANALISERECETOR")
	public AnaliseRecetor getAnaliserecetor() {
		return analiserecetor;
	}
	public void setAnaliserecetor(AnaliseRecetor analiserecetor) {
		this.analiserecetor = analiserecetor;
	}
	
	@ManyToOne(fetch=FetchType.EAGER)
	@JoinColumn(name="ID_TIPOCOMPLICACAO")
	public TipoComplicacoes getTipocomplicacoes() {
		return tipocomplicacoes;
	}
	public void setTipocomplicacoes(TipoComplicacoes tipocomplicacoes) {
		this.tipocomplicacoes = tipocomplicacoes;
	}
	
	@Column(name="ESC")
	public boolean isEsc() {
		return esc;
	}
	public void setEsc(boolean esc) {
		this.esc = esc;
	}
	
	
	
}
