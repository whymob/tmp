package pt.iconic.ipst.modelo;

import java.util.Calendar;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name = "EQUIPA_LOCAL")
public class EquipaLocal {

	private Long idequipalocal;
	private Dador dador;
	private Hospital hospital;
	private String sala;
	private Calendar data;
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="ID_EQUIPA_LOCAL")
	public Long getIdequipalocal() {
		return idequipalocal;
	}
	public void setIdequipalocal(Long idequipalocal) {
		this.idequipalocal = idequipalocal;
	}
	
    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "ID_DADOR")
	public Dador getDador() {
		return dador;
	}
	public void setDador(Dador dador) {
		this.dador = dador;
	}
	
    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "ID_HOSPITAL")
	public Hospital getHospital() {
		return hospital;
	}
	public void setHospital(Hospital hospital) {
		this.hospital = hospital;
	}
	
	@Column(name="SALA")
	public String getSala() {
		return sala;
	}
	public void setSala(String sala) {
		this.sala = sala;
	}
	
	@Column(name="DATA")
	public Calendar getData() {
		return data;
	}
	public void setData(Calendar data) {
		this.data = data;
	}
	
	
	
}
