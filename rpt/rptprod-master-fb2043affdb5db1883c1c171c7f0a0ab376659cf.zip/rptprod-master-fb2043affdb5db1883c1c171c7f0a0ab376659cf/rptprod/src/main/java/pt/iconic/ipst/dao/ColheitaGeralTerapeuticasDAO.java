package pt.iconic.ipst.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import pt.iconic.ipst.modelo.ColheitaGeralTerapeuticas;


@Repository
@Transactional
public class ColheitaGeralTerapeuticasDAO {

	
	@PersistenceContext
	private EntityManager manager;
	
	
	public void adiciona(ColheitaGeralTerapeuticas colheita){
		manager.persist(colheita);	
	}
	

	public void atualiza(ColheitaGeralTerapeuticas colheita){
		manager.merge(colheita);
	}
	

/*	@SuppressWarnings("unchecked")
	public List<ColheitaGeralTerapeuticas> ListaColheitaGeralTerapeuticas(){
		return manager.createQuery("select a from ColheitaGeral a").getResultList();
	}*/
	
	public ColheitaGeralTerapeuticas buscaPorId(Long id){
		return manager.find(ColheitaGeralTerapeuticas.class, id);
	}
	
	
	public void remove(ColheitaGeralTerapeuticas colheita){
		ColheitaGeralTerapeuticas colheitaARemover = buscaPorId(colheita.getIdcolheitaterapeutica());
		manager.remove(colheitaARemover);
		
	}
	
	@SuppressWarnings("unchecked")
	public List<ColheitaGeralTerapeuticas> listacolheitageralterapeuticasanalise(Long idanalise){
		
		Query query = manager.createQuery("select b from ColheitaGeralTerapeuticas b JOIN b.analiseDador a WHERE a.id_AnaliseDador =:idanalise");
		query.setParameter("idanalise", idanalise);
		
		List<ColheitaGeralTerapeuticas> results = query.getResultList();
		return results;
		
	}
}
