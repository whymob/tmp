package pt.iconic.ipst.modelo;

import java.util.Calendar;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name = "ECOTORAXICO")
public class EcoToraxico 
{
	private Long Id_EcoToraico;
	private Calendar DataToraxico;
	private boolean Exame;
	private boolean Vasopressores;
	private int Vizualizacao;
	private int LVEDD;
	private int LVPWD;
	private int LA;
	private int LVESD;
	private int LVPWS;
	private int IVSS;
	private int IVSD;
	private int LVEFT;
	private int LVEFS;
	private int RVEDD;
	private int RVESD;
	private int RVTAPASE;
	private int RA;
	private int AortaDiametro;
	private int AortaAscedente;
	private String AortaObservacoes;
	private int MAP;
	private int CVP;
	private int BPM;
	private boolean EfusaoPericardial;
	private String Notas;
	private String LVFS;
	private String LVFD;
	private String LVWMD;
	private String RVF;
	private String RVM;
	private String RVD;
	private String AorticaEstadoUm;
	private String AorticaEstadoDois;
	private String MitralEstadoUm;
	private String MitralEstadoDois;
	private String TricuspidalEstadoUm;
	private String TricuspidalEstadoDois;
	private String PulmonarEstadoUm;
	private String PulmonarEstadoDois;
	private String caminho;
	private String nomedoc;
	private int morfologiatoraxico;
	private int severidadeve;
	private AnaliseDador analiseDador;
	private boolean statusharmecocardio;
	private Calendar datagravacao;
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="ID_ECOTORAXICO")
	public Long getId_EcoToraico() {
		return Id_EcoToraico;
	}
	public void setId_EcoToraico(Long id_EcoToraico) {
		Id_EcoToraico = id_EcoToraico;
	}
	
	@Column(name="DATAEXAMETORAXICO")
	public Calendar getDataToraxico() {
		return DataToraxico;
	}
	public void setDataToraxico(Calendar dataToraxico) {
		DataToraxico = dataToraxico;
	}
	
	@Column(name="EXAME")
	public boolean isExame() {
		return Exame;
	}
	public void setExame(boolean exame) {
		Exame = exame;
	}
	
	@Column(name="VASOPRESSOR")
	public boolean isVasopressores() {
		return Vasopressores;
	}
	public void setVasopressores(boolean vasopressores) {
		Vasopressores = vasopressores;
	}

	@Column(name="LVED")
	public int getLVEDD() {
		return LVEDD;
	}
	public void setLVEDD(int lVEDD) {
		LVEDD = lVEDD;
	}
	
	@Column(name="LVPWD")
	public int getLVPWD() {
		return LVPWD;
	}
	public void setLVPWD(int lVPWD) {
		LVPWD = lVPWD;
	}
	
	@Column(name="LA")
	public int getLA() {
		return LA;
	}
	public void setLA(int lA) {
		LA = lA;
	}
	
	@Column(name="LVESD")
	public int getLVESD() {
		return LVESD;
	}
	public void setLVESD(int lVESD) {
		LVESD = lVESD;
	}
	
	@Column(name="LVPWS")
	public int getLVPWS() {
		return LVPWS;
	}
	public void setLVPWS(int lVPWS) {
		LVPWS = lVPWS;
	}
	
	@Column(name="IVSS")
	public int getIVSS() {
		return IVSS;
	}
	public void setIVSS(int iVSS) {
		IVSS = iVSS;
	}
	
	@Column(name="IVSD")
	public int getIVSD() {
		return IVSD;
	}
	public void setIVSD(int iVSD) {
		IVSD = iVSD;
	}
	
	@Column(name="LVEFT")
	public int getLVEFT() {
		return LVEFT;
	}
	public void setLVEFT(int lVEFT) {
		LVEFT = lVEFT;
	}
	
	@Column(name="LVEFS")
	public int getLVEFS() {
		return LVEFS;
	}
	public void setLVEFS(int lVEFS) {
		LVEFS = lVEFS;
	}
	
	@Column(name="RVEDD")
	public int getRVEDD() {
		return RVEDD;
	}
	public void setRVEDD(int rVEDD) {
		RVEDD = rVEDD;
	}
	
	@Column(name="RVESD")
	public int getRVESD() {
		return RVESD;
	}
	public void setRVESD(int rVESD) {
		RVESD = rVESD;
	}
	
	@Column(name="RVTAPASE")
	public int getRVTAPASE() {
		return RVTAPASE;
	}
	public void setRVTAPASE(int rVTAPASE) {
		RVTAPASE = rVTAPASE;
	}
	
	@Column(name="RA")
	public int getRA() {
		return RA;
	}
	public void setRA(int rA) {
		RA = rA;
	}
	
	@Column(name="AORTADIAMETRO")
	public int getAortaDiametro() {
		return AortaDiametro;
	}
	public void setAortaDiametro(int aortaDiametro) {
		AortaDiametro = aortaDiametro;
	}
	
	@Column(name="AORTAOBSERVACOES")
	public String getAortaObservacoes() {
		return AortaObservacoes;
	}
	public void setAortaObservacoes(String aortaObservacoes) {
		AortaObservacoes = aortaObservacoes;
	}
	
	@Column(name="MAP")
	public int getMAP() {
		return MAP;
	}
	public void setMAP(int mAP) {
		MAP = mAP;
	}
	
	@Column(name="CVP")
	public int getCVP() {
		return CVP;
	}
	public void setCVP(int cVP) {
		CVP = cVP;
	}
	
	@Column(name="BPM")
	public int getBPM() {
		return BPM;
	}
	public void setBPM(int bPM) {
		BPM = bPM;
	}
	
	@Column(name="EFUSAOPERICARDIAL")
	public boolean isEfusaoPericardial() {
		return EfusaoPericardial;
	}
	public void setEfusaoPericardial(boolean efusaoPericardial) {
		EfusaoPericardial = efusaoPericardial;
	}
	
	@Column(name="NOTAS")
	public String getNotas() {
		return Notas;
	}
	public void setNotas(String notas) {
		Notas = notas;
	}
	
	@Column(name="LVFS")
	public String getLVFS() {
		return LVFS;
	}
	public void setLVFS(String lVFS) {
		LVFS = lVFS;
	}
	
	@Column(name="LVFD")
	public String getLVFD() {
		return LVFD;
	}
	public void setLVFD(String lVFD) {
		LVFD = lVFD;
	}
	
	@Column(name="LVWMD")
	public String getLVWMD() {
		return LVWMD;
	}
	public void setLVWMD(String lVWMD) {
		LVWMD = lVWMD;
	}
	
	@Column(name="RVF")
	public String getRVF() {
		return RVF;
	}
	public void setRVF(String rVF) {
		RVF = rVF;
	}
	
	@Column(name="RVM")
	public String getRVM() {
		return RVM;
	}
	public void setRVM(String rVM) {
		RVM = rVM;
	}
	
	@Column(name="RVD")
	public String getRVD() {
		return RVD;
	}
	public void setRVD(String rVD) {
		RVD = rVD;
	}
	
	@Column(name="AORTICAESTADOUM")
	public String getAorticaEstadoUm() {
		return AorticaEstadoUm;
	}
	public void setAorticaEstadoUm(String aorticaEstadoUm) {
		AorticaEstadoUm = aorticaEstadoUm;
	}
	
	@Column(name="AORTICAESTADODOIS")
	public String getAorticaEstadoDois() {
		return AorticaEstadoDois;
	}
	public void setAorticaEstadoDois(String aorticaEstadoDois) {
		AorticaEstadoDois = aorticaEstadoDois;
	}
	
	@Column(name="MITRALESTADOUM")
	public String getMitralEstadoUm() {
		return MitralEstadoUm;
	}
	public void setMitralEstadoUm(String mitralEstadoUm) {
		MitralEstadoUm = mitralEstadoUm;
	}
	
	@Column(name="MITRALESTADODOIS")
	public String getMitralEstadoDois() {
		return MitralEstadoDois;
	}
	public void setMitralEstadoDois(String mitralEstadoDois) {
		MitralEstadoDois = mitralEstadoDois;
	}
	
	@Column(name="TRICUSPIDALESTADOUM")
	public String getTricuspidalEstadoUm() {
		return TricuspidalEstadoUm;
	}
	public void setTricuspidalEstadoUm(String tricuspidalEstadoUm) {
		TricuspidalEstadoUm = tricuspidalEstadoUm;
	}
	
	@Column(name="TRICUSPIDALESTADODOIS")
	public String getTricuspidalEstadoDois() {
		return TricuspidalEstadoDois;
	}
	public void setTricuspidalEstadoDois(String tricuspidalEstadoDois) {
		TricuspidalEstadoDois = tricuspidalEstadoDois;
	}
	
	@Column(name="PULMONARESTADOUM")
	public String getPulmonarEstadoUm() {
		return PulmonarEstadoUm;
	}
	public void setPulmonarEstadoUm(String pulmonarEstadoUm) {
		PulmonarEstadoUm = pulmonarEstadoUm;
	}
	
	@Column(name="PULMONARESTADODOIS")
	public String getPulmonarEstadoDois() {
		return PulmonarEstadoDois;
	}
	public void setPulmonarEstadoDois(String pulmonarEstadoDois) {
		PulmonarEstadoDois = pulmonarEstadoDois;
	}

	@OneToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="ID_ANALISEDADOR")
	public AnaliseDador getAnaliseDador() {
		return analiseDador;
	}
	public void setAnaliseDador(AnaliseDador analiseDador) {
		this.analiseDador = analiseDador;
	}

	@Column(name="AORTADESCENDENTE")
	public int getAortaAscedente() {
		return AortaAscedente;
	}
	public void setAortaAscedente(int aortaAscedente) {
		AortaAscedente = aortaAscedente;
	}
	
	@Column(name="CAMINHODOC")
	public String getCaminho() {
		return caminho;
	}
	public void setCaminho(String caminho) {
		this.caminho = caminho;
	}
	
	@Column(name="VIZUALIZACAO")
	public int getVizualizacao() {
		return Vizualizacao;
	}
	public void setVizualizacao(int vizualizacao) {
		Vizualizacao = vizualizacao;
	}

	@Column(name="NOMEDOC")
	public String getNomedoc() {
		return nomedoc;
	}
	public void setNomedoc(String nomedoc) {
		this.nomedoc = nomedoc;
	}
	@Column(name="morfologiatoraxico")
	public int getMorfologiatoraxico() {
		return morfologiatoraxico;
	}
	public void setMorfologiatoraxico(int morfologiatoraxico) {
		this.morfologiatoraxico = morfologiatoraxico;
	}
	
	@Column(name="SEVERIDADEVE")
	public int getSeveridadeve() {
		return severidadeve;
	}
	public void setSeveridadeve(int severidadeve) {
		this.severidadeve = severidadeve;
	}
	
	@Column(name="STATUSHARMONIO")
	public boolean isStatusharmecocardio() {
		return statusharmecocardio;
	}
	public void setStatusharmecocardio(boolean statusharmecocardio) {
		this.statusharmecocardio = statusharmecocardio;
	}
	
	@Column(name="DATAGRAVACAO")
	public Calendar getDatagravacao() {
		return datagravacao;
	}


	public void setDatagravacao(Calendar datagravacao) {
		this.datagravacao = datagravacao;
	}
}