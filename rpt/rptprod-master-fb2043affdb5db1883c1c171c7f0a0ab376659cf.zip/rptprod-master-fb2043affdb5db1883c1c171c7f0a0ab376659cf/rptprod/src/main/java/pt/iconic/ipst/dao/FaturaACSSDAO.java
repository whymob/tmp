package pt.iconic.ipst.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import pt.iconic.ipst.modelo.Compromisso;
import pt.iconic.ipst.modelo.FaturaACSS;

@Repository
@Transactional
public class FaturaACSSDAO 
{
	@PersistenceContext
	private EntityManager manager;
	
	public void adiciona(FaturaACSS comp){
		manager.persist(comp);	
	}

	public void atualiza(FaturaACSS comp){
		manager.merge(comp);
	}
	
/*	@SuppressWarnings("unchecked")
	public List<FaturaACSS> ListaFaturaACSS(){
		return manager.createQuery("select a from FaturaACSS a").getResultList();
	}*/
	
	public FaturaACSS buscaPorId(Long id){
		return manager.find(FaturaACSS.class, id);
	}
	
/*	public void remove(FaturaACSS comp){
		FaturaACSS compARemover = buscaPorId(comp.getIdfatura());
		manager.remove(compARemover);	
	}*/
	
	@SuppressWarnings("unchecked")
	public List<Object> buscaFaturaCompromisso()
	{
		Query query = manager.createNativeQuery("select ENTIDADE.NOME, COMPROMISSO.DATA as data1, COMPROMISSO.VALOR, COMPROMISSO.COMPROMISSO, FATURAACSS.FATURA as fat, case when (len(CONVERT(VARCHAR(10),FATURAACSS.DATA,110)) = 0) then '' else FATURAACSS.DATA end as data2, case when (len(CONVERT(VARCHAR(10),FATURAACSS.DATAPAGAMENTO,110)) = 0) then '' else FATURAACSS.DATAPAGAMENTO end as data3, case when (FATURAACSS.PAGA IS null) then 2 else FATURAACSS.PAGA end as paga, case when (FATURAACSS.PROB IS null) then 2 else FATURAACSS.PROB end as prob, case when (FATURAACSS.notas IS null) then '' else FATURAACSS.notas end as notas, COMPROMISSO.ID_COMPROMISSO, case when (FATURAACSS.ID_FATURA IS null) then 0 else FATURAACSS.ID_FATURA end as id from COMPROMISSO left join FATURAACSS on (COMPROMISSO.ID_COMPROMISSO = FATURAACSS.ID_COMPROMISSO) join ENTIDADE on (COMPROMISSO.ID_ENTIDADE = ENTIDADE.ID_ENTIDADE)");
		
		List<Object> results = query.getResultList();

		return results;
	}
	
	@SuppressWarnings("unchecked")
	public List<Object> buscaFaturaCompromissoSem()
	{
		Query query = manager.createNativeQuery("select ENTIDADE.NOME, COMPROMISSO.DATA as data1, COMPROMISSO.VALOR, COMPROMISSO.COMPROMISSO, FATURAACSS.FATURA as fat, FATURAACSS.DATA as data2, FATURAACSS.DATAPAGAMENTO as data3, case when (FATURAACSS.PAGA IS null) then 2 else FATURAACSS.PAGA end as paga, case when (FATURAACSS.PROB IS null) then 2 else FATURAACSS.PROB end as prob, case when (FATURAACSS.notas IS null) then '' else FATURAACSS.notas end as notas, COMPROMISSO.ID_COMPROMISSO,  case when (FATURAACSS.ID_FATURA IS null) then 0 else FATURAACSS.ID_FATURA end as id  from COMPROMISSO  left join FATURAACSS on (COMPROMISSO.ID_COMPROMISSO = FATURAACSS.ID_COMPROMISSO)  join ENTIDADE on (COMPROMISSO.ID_ENTIDADE = ENTIDADE.ID_ENTIDADE) where FATURAACSS.ID_FATURA is null");
		
		List<Object> results = query.getResultList();

		return results;
	}

	@SuppressWarnings("unchecked")
	public Compromisso buscaCompromissoFactura(Long idfatura) {
		Query query = manager.createQuery("select c from Compromisso c JOIN c.fatura f WHERE f.idfatura =:idfatura");
		query.setParameter("idfatura", idfatura);
		
		List<Compromisso> results = query.getResultList();
		Compromisso comp = null;
		if(!results.isEmpty()){
			comp = (Compromisso) results.get(0);
		}
		return comp;
	}
}
