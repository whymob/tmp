package pt.iconic.ipst.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import pt.iconic.ipst.modelo.TipoTerapeuticasFollowUP;
import pt.iconic.ipst.modelo.UnidadesGeral;


@Repository
@Transactional
public class TipoTerapeuticasFollowUpDAO {

	@PersistenceContext
	private EntityManager manager;
	
	public void adiciona(TipoTerapeuticasFollowUP tipoterapeuticas){
		manager.persist(tipoterapeuticas);	
	}
	
	public void atualiza(TipoTerapeuticasFollowUP tipoterapeuticas){
		manager.merge(tipoterapeuticas);
	}

	@SuppressWarnings("unchecked")
	public List<TipoTerapeuticasFollowUP> ListaTipoTerapeuticas(){
		return manager.createQuery("select t from TipoTerapeuticasFollowUP t").getResultList();
	}
	
	public TipoTerapeuticasFollowUP buscaPorId(Long id){
		return manager.find(TipoTerapeuticasFollowUP.class, id);
	}
	
	public void remove(TipoTerapeuticasFollowUP tipoterapeuticas){
		TipoTerapeuticasFollowUP tipoterapeuticasdadorARemover = buscaPorId(tipoterapeuticas.getId_TipoTerapeuticasFollowUp());
		manager.remove(tipoterapeuticasdadorARemover);
	}
	
	public boolean trataadicionar(String desc, Long combo)
	{
		Query query = manager.createQuery("SELECT t FROM TipoTerapeuticasFollowUP t WHERE t.descricao =:desc");
		query.setParameter("desc", desc);
		
		if(query.getResultList().isEmpty())
		{
			
			UnidadesGeral unid = new UnidadesGeral();
			unid.setId_unidades(combo);
			
			TipoTerapeuticasFollowUP terap = new TipoTerapeuticasFollowUP();
			terap.setDescricao(desc);
			terap.setUnidades(unid);
			adiciona(terap);
			
			return true;
		}
		else
		{
			return false;
		}
	}
	
	public boolean trataalterar(Long id, String desc, Long combo)
	{
		
		UnidadesGeral unid = new UnidadesGeral();
		unid.setId_unidades(combo);
		
		TipoTerapeuticasFollowUP terap = new TipoTerapeuticasFollowUP();
		terap.setId_TipoTerapeuticasFollowUp(id);
		terap.setDescricao(desc);
		terap.setUnidades(unid);
		atualiza(terap);
			
		return true;
	}
	
	public boolean remover(Long id)
	{
		TipoTerapeuticasFollowUP terap = new TipoTerapeuticasFollowUP();
		terap = buscaPorId(id);
		remove(terap);
			
		return true;
	}
	
	
}
