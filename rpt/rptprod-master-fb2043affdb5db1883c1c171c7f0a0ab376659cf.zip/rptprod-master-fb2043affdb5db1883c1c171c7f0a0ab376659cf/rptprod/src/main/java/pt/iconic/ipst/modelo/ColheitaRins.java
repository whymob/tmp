package pt.iconic.ipst.modelo;

import java.util.Calendar;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name = "COLHEITA_RINS")
public class ColheitaRins {

	private Long idcolheitarins;
	private Calendar iniciorins;
	private Calendar fimrins;
	private boolean coracaoparadorins;
	private int arteriasrimesq;
	private int patchartrimesq;
	private int veiasrimesq;
	private int patchveiasrimesq;
	private int ureterrimesq;
	private int alteracoesrimesq;
	private boolean biopsiarimesq;
	private String notasrimesq;
	private int arteriasrimdir;
	private int patchartrimdir;
	private int veiasrimdir;
	private int patchveiasrimdir;
	private int ureterrimdir;
	private int alteracoesrimdir;
	private boolean biopsiarimdir;
	private String notasrimdir;
	private String notastraprins;
	private int estadorimesq;
	private int estadorimdir;
	private AnaliseDador analiseDador;
	private String codrimesq;
	private String codrimdir;
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="ID_COLHEITA_RINS")
	public Long getIdcolheitarins() {
		return idcolheitarins;
	}
	public void setIdcolheitarins(Long idcolheitarins) {
		this.idcolheitarins = idcolheitarins;
	}
	
	@Column(name="INICIO")
	public Calendar getIniciorins() {
		return iniciorins;
	}
	public void setIniciorins(Calendar iniciorins) {
		this.iniciorins = iniciorins;
	}
	
	@Column(name="FIM")
	public Calendar getFimrins() {
		return fimrins;
	}
	public void setFimrins(Calendar fimrins) {
		this.fimrins = fimrins;
	}
	
	@Column(name="CORACAO_PARADO")
	public boolean isCoracaoparadorins() {
		return coracaoparadorins;
	}
	public void setCoracaoparadorins(boolean coracaoparadorins) {
		this.coracaoparadorins = coracaoparadorins;
	}
	
	@Column(name="ARTERIAS_ESQ")
	public int getArteriasrimesq() {
		return arteriasrimesq;
	}
	public void setArteriasrimesq(int arteriasrimesq) {
		this.arteriasrimesq = arteriasrimesq;
	}
	
	@Column(name="PATCH_ARTERIAS_ESQ")
	public int getPatchartrimesq() {
		return patchartrimesq;
	}
	public void setPatchartrimesq(int patchartrimesq) {
		this.patchartrimesq = patchartrimesq;
	}
	
	@Column(name="VEIAS_ESQ")
	public int getVeiasrimesq() {
		return veiasrimesq;
	}
	public void setVeiasrimesq(int veiasrimesq) {
		this.veiasrimesq = veiasrimesq;
	}
	
	@Column(name="PATCH_VEIAS_ESQ")
	public int getPatchveiasrimesq() {
		return patchveiasrimesq;
	}
	public void setPatchveiasrimesq(int patchveiasrimesq) {
		this.patchveiasrimesq = patchveiasrimesq;
	}
	
	@Column(name="URETER_ESQ")
	public int getUreterrimesq() {
		return ureterrimesq;
	}
	public void setUreterrimesq(int ureterrimesq) {
		this.ureterrimesq = ureterrimesq;
	}
	
	@Column(name="ALTERACOES_ESQ")
	public int getAlteracoesrimesq() {
		return alteracoesrimesq;
	}
	public void setAlteracoesrimesq(int alteracoesrimesq) {
		this.alteracoesrimesq = alteracoesrimesq;
	}
	
	@Column(name="BIOPSIA_ESQ")
	public boolean isBiopsiarimesq() {
		return biopsiarimesq;
	}
	public void setBiopsiarimesq(boolean biopsiarimesq) {
		this.biopsiarimesq = biopsiarimesq;
	}
	
	@Column(name="NOTAS_ESQ")
	public String getNotasrimesq() {
		return notasrimesq;
	}
	public void setNotasrimesq(String notasrimesq) {
		this.notasrimesq = notasrimesq;
	}
	
	@Column(name="ARTERIAS_DIR")
	public int getArteriasrimdir() {
		return arteriasrimdir;
	}
	public void setArteriasrimdir(int arteriasrimdir) {
		this.arteriasrimdir = arteriasrimdir;
	}
	
	@Column(name="PATCH_ARTERIAS_DIR")
	public int getPatchartrimdir() {
		return patchartrimdir;
	}
	public void setPatchartrimdir(int patchartrimdir) {
		this.patchartrimdir = patchartrimdir;
	}
	
	@Column(name="VEIAS_DIR")
	public int getVeiasrimdir() {
		return veiasrimdir;
	}
	public void setVeiasrimdir(int veiasrimdir) {
		this.veiasrimdir = veiasrimdir;
	}
	
	@Column(name="PATCH_VEIAS_DIR")
	public int getPatchveiasrimdir() {
		return patchveiasrimdir;
	}
	public void setPatchveiasrimdir(int patchveiasrimdir) {
		this.patchveiasrimdir = patchveiasrimdir;
	}
	
	@Column(name="URETER_DIR")
	public int getUreterrimdir() {
		return ureterrimdir;
	}
	public void setUreterrimdir(int ureterrimdir) {
		this.ureterrimdir = ureterrimdir;
	}
	
	@Column(name="ALTERACOES_DIR")
	public int getAlteracoesrimdir() {
		return alteracoesrimdir;
	}
	public void setAlteracoesrimdir(int alteracoesrimdir) {
		this.alteracoesrimdir = alteracoesrimdir;
	}
	
	@Column(name="BIOPSIA_DIR")
	public boolean isBiopsiarimdir() {
		return biopsiarimdir;
	}
	public void setBiopsiarimdir(boolean biopsiarimdir) {
		this.biopsiarimdir = biopsiarimdir;
	}
	
	@Column(name="NOTAS_DIR")
	public String getNotasrimdir() {
		return notasrimdir;
	}
	public void setNotasrimdir(String notasrimdir) {
		this.notasrimdir = notasrimdir;
	}
	
	@Column(name="NOTAS_TERAPEUTICA")
	public String getNotastraprins() {
		return notastraprins;
	}
	public void setNotastraprins(String notastraprins) {
		this.notastraprins = notastraprins;
	}
	
	@Column(name="ESTADO_RIM_ESQ")
	public int getEstadorimesq() {
		return estadorimesq;
	}
	public void setEstadorimesq(int estadorimesq) {
		this.estadorimesq = estadorimesq;
	}

	
	@Column(name="ESTADO_RIM_DIR")
	public int getEstadorimdir() {
		return estadorimdir;
	}
	public void setEstadorimdir(int estadorimdir) {
		this.estadorimdir = estadorimdir;
	}
	
	@OneToOne(fetch=FetchType.EAGER)
	@JoinColumn(name="ID_ANALISEDADOR")
	public AnaliseDador getAnaliseDador() {
		return analiseDador;
	}
	public void setAnaliseDador(AnaliseDador analiseDador) {
		this.analiseDador = analiseDador;
	}
	
	@Column(name="COD_RIM_ESQ")
	public String getCodrimesq() {
		return codrimesq;
	}
	public void setCodrimesq(String codrimesq) {
		this.codrimesq = codrimesq;
	}
	
	@Column(name="COD_RIM_DIR")
	public String getCodrimdir() {
		return codrimdir;
	}
	public void setCodrimdir(String codrimdir) {
		this.codrimdir = codrimdir;
	}
}
