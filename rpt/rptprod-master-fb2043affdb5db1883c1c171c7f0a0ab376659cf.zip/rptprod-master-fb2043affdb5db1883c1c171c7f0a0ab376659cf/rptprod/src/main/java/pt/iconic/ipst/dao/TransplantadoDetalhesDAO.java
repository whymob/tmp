package pt.iconic.ipst.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import pt.iconic.ipst.modelo.TransplantadoDetalhes;

@Repository
public class TransplantadoDetalhesDAO 
{
	@PersistenceContext
	private EntityManager manager;
	
	@Transactional
	public void adiciona(TransplantadoDetalhes transp){
		manager.persist(transp);	
	}
	
	@Transactional
	public void atualiza(TransplantadoDetalhes transp){
		manager.merge(transp);
	}
	
/*	@SuppressWarnings("unchecked")
	public List<TransplantadoDetalhes> ListaTransplantadoDetalhes(){
		return manager.createQuery("select d from TransplantadoDetalhes d").getResultList();
	}*/
	
/*	public TransplantadoDetalhes buscaPorId(Long id){
		return manager.find(TransplantadoDetalhes.class, id);
	}
	
	public void remove(TransplantadoDetalhes transp){
		TransplantadoDetalhes transprem = buscaPorId(transp.getId_tranplantadodetalhes());
		manager.remove(transprem);
	}*/
	
	@SuppressWarnings("rawtypes")
	public TransplantadoDetalhes buscaTransplantadoDetalhes(Long idtransplante)
	{
		Query query = manager.createQuery("select d from TransplantadoDetalhes d JOIN d.tranplantado transp WHERE transp.id_transplante =:idtransplante");
		query.setParameter("idtransplante", idtransplante);
		
		List results = query.getResultList();
		TransplantadoDetalhes detalhes = null;
		
		if(!results.isEmpty()){
			detalhes = (TransplantadoDetalhes) results.get(0);
		}
		return detalhes;
	}
}
