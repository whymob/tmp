package pt.iconic.ipst.modelo;

import java.util.Calendar;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name = "HCGERAL")
public class HCGeral {

	private Long Id_HCGeral;
	private AnaliseDador analiseDador;
	private int hipertensao;
	private int hipertensaoanos;
	private int diabetes;
	private int diabetesanos;
	private int tabagismo;
	private int alcoolismo;
	private boolean statusharmgeral;
	private Calendar datagravacao;
/*	private String Hipertensao_Tratamento;
	private String Tratamento_Insulina;
	private String Indice_Tabagico;
	private String Indice_Alcoolismo;*/
	//String[] hiperval = {"option1", "option2", "option3"};
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="ID_HCGERAL")
	public Long getId_HCGeral() {
		return Id_HCGeral;
	}
	public void setId_HCGeral(Long id_HCGeral) {
		Id_HCGeral = id_HCGeral;
	}
	
//	public String[] getHiperval() {
//	    return hiperval;
//	}
//	public void setHiperval(String[] hiperval) {
//	    this.hiperval = hiperval;
//	}
	
	
	@OneToOne
	@JoinColumn(name="ID_ANALISEDADOR")
	public AnaliseDador getAnaliseDador() {
		return analiseDador;
	}
	public void setAnaliseDador(AnaliseDador analiseDador) {
		this.analiseDador = analiseDador;
	}
	
	@Column(name="HIPERTENSAO")
	public int getHipertensao() {
		return hipertensao;
	}
	public void setHipertensao(int hipertensao) {
		this.hipertensao = hipertensao;
	}
	
	@Column(name="HIPERTENSAOANOS")
	public int getHipertensaoanos() {
		return hipertensaoanos;
	}
	public void setHipertensaoanos(int hipertensaoanos) {
		this.hipertensaoanos = hipertensaoanos;
	}
	
	@Column(name="DIABETES")
	public int getDiabetes() {
		return diabetes;
	}
	public void setDiabetes(int diabetes) {
		this.diabetes = diabetes;
	}
	
	@Column(name="DIABETESANOS")
	public int getDiabetesanos() {
		return diabetesanos;
	}
	public void setDiabetesanos(int diabetesanos) {
		this.diabetesanos = diabetesanos;
	}
	
	@Column(name="TABAGISMO")
	public int getTabagismo() {
		return tabagismo;
	}
	public void setTabagismo(int tabagismo) {
		this.tabagismo = tabagismo;
	}
	
	@Column(name="ALCOOLISMO")
	public int getAlcoolismo() {
		return alcoolismo;
	}
	public void setAlcoolismo(int alcoolismo) {
		this.alcoolismo = alcoolismo;
	}
	
	@Column(name="STATUSHARMONIO")
	public boolean isStatusharmgeral() {
		return statusharmgeral;
	}
	public void setStatusharmgeral(boolean statusharmgeral) {
		this.statusharmgeral = statusharmgeral;
	}
	
	@Column(name="DATAGRAVACAO")
	public Calendar getDatagravacao() {
		return datagravacao;
	}


	public void setDatagravacao(Calendar datagravacao) {
		this.datagravacao = datagravacao;
	}
	

	/*public String getHipertensao_Tratamento() {
		return Hipertensao_Tratamento;
	}
	public void setHipertensao_Tratamento(String hipertensao_Tratamento) {
		Hipertensao_Tratamento = hipertensao_Tratamento;
	}
	public String getTratamento_Insulina() {
		return Tratamento_Insulina;
	}
	public void setTratamento_Insulina(String tratamento_Insulina) {
		Tratamento_Insulina = tratamento_Insulina;
	}
	public String getIndice_Tabagico() {
		return Indice_Tabagico;
	}
	public void setIndice_Tabagico(String indice_Tabagico) {
		Indice_Tabagico = indice_Tabagico;
	}
	public String getIndice_Alcoolismo() {
		return Indice_Alcoolismo;
	}
	public void setIndice_Alcoolismo(String indice_Alcoolismo) {
		Indice_Alcoolismo = indice_Alcoolismo;
	}*/
	
	
	
	
}
