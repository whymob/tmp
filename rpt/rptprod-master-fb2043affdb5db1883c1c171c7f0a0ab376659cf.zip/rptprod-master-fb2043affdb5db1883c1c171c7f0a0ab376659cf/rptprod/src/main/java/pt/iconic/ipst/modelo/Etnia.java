package pt.iconic.ipst.modelo;

import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name = "ETNIA")
public class Etnia {

	private Long Id_Etnia;
	private String Etnia;
	private List<HCExameFisico> hcexamefisico;
	private List<RecetorDetalhes> recetordetalhes;
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="ID_ETNIA")
	public Long getId_Etnia() {
		return Id_Etnia;
	}
	public void setId_Etnia(Long id_Etnia) {
		Id_Etnia = id_Etnia;
	}
	
	@Column(name="ETNIA")
	public String getEtnia() {
		return Etnia;
	}
	public void setEtnia(String etnia) {
		Etnia = etnia;
	}
	
	@OneToMany(fetch = FetchType.LAZY, mappedBy = "etnia")
	public List<HCExameFisico> getHcexamefisico() {
		return hcexamefisico;
	}
	public void setHcexamefisico(List<HCExameFisico> hcexamefisico) {
		this.hcexamefisico = hcexamefisico;
	}
	
	@OneToMany(fetch = FetchType.LAZY, mappedBy = "etnia")
	public List<RecetorDetalhes> getRecetordetalhes() {
		return recetordetalhes;
	}
	public void setRecetordetalhes(List<RecetorDetalhes> recetordetalhes) {
		this.recetordetalhes = recetordetalhes;
	}	
}