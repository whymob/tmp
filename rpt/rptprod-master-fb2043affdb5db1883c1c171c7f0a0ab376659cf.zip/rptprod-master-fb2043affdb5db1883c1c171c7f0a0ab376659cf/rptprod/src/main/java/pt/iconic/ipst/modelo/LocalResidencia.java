package pt.iconic.ipst.modelo;

import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name = "RESIDENCIA")
public class LocalResidencia
{
	private int id_residencia;
	private String nome;
	private List<RecetorDetalhes> recetordetalhesres;
	private List<TransplantadoDetalhes> tranpdetres;
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="ID_RESIDENCIA")
	public int getId_residencia() {
		return id_residencia;
	}
	public void setId_residencia(int id_residencia) {
		this.id_residencia = id_residencia;
	}
	
	@Column(name="NOME")
	public String getNome() {
		return nome;
	}
	public void setNome(String nome) {
		this.nome = nome;
	}
	
	@OneToMany(fetch = FetchType.LAZY, mappedBy = "residencia")
	public List<RecetorDetalhes> getRecetordetalhesres() {
		return recetordetalhesres;
	}
	public void setRecetordetalhesres(List<RecetorDetalhes> recetordetalhesres) {
		this.recetordetalhesres = recetordetalhesres;
	}
	
	@OneToMany(fetch = FetchType.LAZY, mappedBy = "residenciatransplantado")
	public List<TransplantadoDetalhes> getTranpdetres() {
		return tranpdetres;
	}
	public void setTranpdetres(List<TransplantadoDetalhes> tranpdetres) {
		this.tranpdetres = tranpdetres;
	}
}