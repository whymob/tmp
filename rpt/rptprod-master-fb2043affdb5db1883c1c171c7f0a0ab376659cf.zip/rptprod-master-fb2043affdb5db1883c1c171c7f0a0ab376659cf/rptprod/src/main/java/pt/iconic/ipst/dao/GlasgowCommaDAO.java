package pt.iconic.ipst.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import pt.iconic.ipst.modelo.GlasgowComma;

@Repository
@Transactional
public class GlasgowCommaDAO 
{
	@PersistenceContext
	private EntityManager manager;
	
	public void adiciona(GlasgowComma glasgowcomma){
		manager.persist(glasgowcomma);	
	}
	
	public void atualiza(GlasgowComma glasgowcomma){
		manager.merge(glasgowcomma);
	}

	@SuppressWarnings("unchecked")
	public List<GlasgowComma> ListaGlasgowComma(){
		return manager.createQuery("select g from GlasgowComma g").getResultList();
	}
	
	public GlasgowComma buscaPorId(Long id){
		return manager.find(GlasgowComma.class, id);
	}
	
	
	public void remove(GlasgowComma glasgowcomma){
		GlasgowComma GlasgowcommaARemover = buscaPorId(glasgowcomma.getId_GlasgowComma());
		manager.remove(GlasgowcommaARemover);
	}
	
	public boolean trataadicionar(String desc)
	{
		Query query = manager.createQuery("SELECT g FROM GlasgowComma g WHERE g.descricaoGlasgowComma =:desc");
		query.setParameter("desc", desc);
		
		if(query.getResultList().isEmpty())
		{
			GlasgowComma glasgow = new GlasgowComma();
			glasgow.setDescricaoGlasgowComma(desc);
			adiciona(glasgow);
			
			return true;
		}
		else
		{
			return false;
		}
	}
	
	public boolean trataalterar(Long id, String desc)
	{
		GlasgowComma glasgow = new GlasgowComma();
		glasgow.setId_GlasgowComma(id);
		glasgow.setDescricaoGlasgowComma(desc);
		atualiza(glasgow);
			
		return true;
	}
	
	public boolean remover(Long id)
	{
		GlasgowComma glasgow = new GlasgowComma();
		glasgow = buscaPorId(id);
		remove(glasgow);
			
		return true;
	}
}