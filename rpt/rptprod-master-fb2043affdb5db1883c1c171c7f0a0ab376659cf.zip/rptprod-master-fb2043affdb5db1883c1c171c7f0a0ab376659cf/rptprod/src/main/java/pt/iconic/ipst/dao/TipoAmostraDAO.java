package pt.iconic.ipst.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.springframework.stereotype.Repository;

import pt.iconic.ipst.modelo.TipoAmostraFO;



@Repository
public class TipoAmostraDAO {

	@PersistenceContext
	private EntityManager manager;
	
	
/*	public void adiciona(TipoAmostraFO tipoamostra){
		manager.persist(tipoamostra);	
	}
	
	public void atualiza(TipoAmostraFO tipoamostra){
		manager.merge(tipoamostra);
	}*/
	

	@SuppressWarnings("unchecked")
	public List<TipoAmostraFO> ListaTipoAmostra(){
		return manager.createQuery("select t from TipoAmostraFO t").getResultList();
	}
	
	public TipoAmostraFO buscaPorId(Long id){
		return manager.find(TipoAmostraFO.class, id);
	}
	
	
/*	public void remove(TipoAmostraFO tipoamostra){
		TipoAmostraFO tipoamostraARemover = buscaPorId(tipoamostra.getId_tipoamostra());
		manager.remove(tipoamostraARemover);
	}*/
}
