package pt.iconic.ipst.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import pt.iconic.ipst.modelo.ColheitaPele;

@Repository
@Transactional
public class ColheitaPeleDAO {
	
	@PersistenceContext
	private EntityManager manager;
	
	public void adiciona(ColheitaPele colheita){
		manager.persist(colheita);	
	}
	

	public void atualiza(ColheitaPele colheita){
		manager.merge(colheita);
	}
	

/*	@SuppressWarnings("unchecked")
	public List<ColheitaPele> ListaColheitaPele(){
		return manager.createQuery("select a from ColheitaPele a").getResultList();
	}*/
	
/*	public ColheitaPele buscaPorId(Long id){
		return manager.find(ColheitaPele.class, id);
	}
	
	
	public void remove(ColheitaPele colheita){
		ColheitaPele colheitaARemover = buscaPorId(colheita.getIdcolheitapele());
		manager.remove(colheitaARemover);
		
	}*/
	
	@SuppressWarnings("unchecked")
	public ColheitaPele buscacolheitaPeleanalise(Long idanalise){
		
		Query query = manager.createQuery("select b from ColheitaPele b JOIN b.analiseDador a WHERE a.id_AnaliseDador =:idanalise");
		query.setParameter("idanalise", idanalise);
		
		List<ColheitaPele> results = query.getResultList();
		ColheitaPele colheita = null;
		if(!results.isEmpty()){
			colheita = (ColheitaPele) results.get(0);
		}
		return colheita;
		
	}

}
