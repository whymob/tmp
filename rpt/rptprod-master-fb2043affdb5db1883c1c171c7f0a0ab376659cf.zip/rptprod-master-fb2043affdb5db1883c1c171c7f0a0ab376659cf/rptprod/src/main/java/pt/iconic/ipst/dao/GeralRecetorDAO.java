package pt.iconic.ipst.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import pt.iconic.ipst.modelo.GeralRecetor;

@Repository
public class GeralRecetorDAO 
{
	@PersistenceContext
	private EntityManager manager;
	
	@Transactional
	public void adiciona(GeralRecetor grav){
		manager.persist(grav);	
	}
	
	@Transactional
	public void atualiza(GeralRecetor grav){
		manager.merge(grav);
	}

/*	@SuppressWarnings("unchecked")
	public List<GeralRecetor> ListaGeralRecetor(){
		return manager.createQuery("select d from GeralRecetor d").getResultList();
	}*/
	
/*	public GeralRecetor buscaPorId(Long id){
		return manager.find(GeralRecetor.class, id);
	}
	
	public void remove(GeralRecetor grav){
		GeralRecetor gravrem = buscaPorId(grav.getId_geralrecetor());
		manager.remove(gravrem);
	}*/
	
	@SuppressWarnings({ "rawtypes" })
	public GeralRecetor buscageralrecetor(Long analiserecetor)
	{		
		Query query = manager.createQuery("select a from GeralRecetor a JOIN a.analiserecetor ger WHERE ger.id_analiserecetor =:analiserecetor");
		query.setParameter("analiserecetor", analiserecetor);
		
		List results = query.getResultList();
		GeralRecetor geral = null;
		
		if(!results.isEmpty()){
			geral = (GeralRecetor) results.get(0);
		}
		
		return geral;
	}
}