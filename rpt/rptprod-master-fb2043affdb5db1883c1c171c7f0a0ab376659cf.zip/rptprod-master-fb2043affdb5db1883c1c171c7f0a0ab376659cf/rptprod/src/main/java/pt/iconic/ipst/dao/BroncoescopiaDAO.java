package pt.iconic.ipst.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import pt.iconic.ipst.modelo.Broncoescopia;

@Repository
@Transactional
public class BroncoescopiaDAO
{
	@PersistenceContext
	private EntityManager manager;
	
	public void adiciona(Broncoescopia bronco){
		manager.persist(bronco);	
	}

	public void atualiza(Broncoescopia bronco){
		manager.merge(bronco);
	}

/*	public Broncoescopia buscaPorId(Long id){
		return manager.find(Broncoescopia.class, id);
	}
	
	public void remove(Broncoescopia bronco){
		Broncoescopia bronc = buscaPorId(bronco.getId_Broncoescopia());
		manager.remove(bronc);
	}*/
	

	@SuppressWarnings("rawtypes")
	public Broncoescopia ListaBroncoescopia(Long id)
	{
		Query query = manager.createQuery("select e from Broncoescopia e JOIN e.analiseDador analisedador WHERE analisedador.id_AnaliseDador =:idanalise");
		query.setParameter("idanalise", id);

		List results = query.getResultList();
		Broncoescopia bronc = null;
		
		if(!results.isEmpty())
		{
			bronc = (Broncoescopia) results.get(0);
		}
		
		return bronc;
	}
}