package pt.iconic.ipst.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import pt.iconic.ipst.modelo.TransplanteCoracao;

@Repository
@Transactional
public class TransplanteCoracaoDAO {

	@PersistenceContext
	private EntityManager manager;
	
	public void adiciona(TransplanteCoracao transplante){
		manager.persist(transplante);	
	}
	
	public void atualiza(TransplanteCoracao transplante){
		manager.merge(transplante);
	}
	
/*	@SuppressWarnings("unchecked")
	public List<TransplanteCoracao> ListaTransplanteCoracao(){
		return manager.createQuery("select a from TransplanteCoracao a").getResultList();
	}*/
	
	public TransplanteCoracao buscaPorId(Long id){
		return manager.find(TransplanteCoracao.class, id);
	}
	
/*	public void remove(TransplanteCoracao transplante){
		TransplanteCoracao transplanteARemover = buscaPorId(transplante.getIdtransplantecoracao());
		manager.remove(transplanteARemover);
	}*/
	
	@SuppressWarnings("unchecked")
	public TransplanteCoracao buscaTransplanteCoracaoAssigorgao(Long idassigorg){
		
		Query query = manager.createQuery("select p from TransplanteCoracao p JOIN p.assigorgao a WHERE a.id_assignacao =:idassigorg");
		query.setParameter("idassigorg", idassigorg);
		
		List<TransplanteCoracao> results = query.getResultList();
		TransplanteCoracao transplante = null;
		if(!results.isEmpty()){
			transplante = (TransplanteCoracao) results.get(0);
		}
		return transplante;
	}
}
