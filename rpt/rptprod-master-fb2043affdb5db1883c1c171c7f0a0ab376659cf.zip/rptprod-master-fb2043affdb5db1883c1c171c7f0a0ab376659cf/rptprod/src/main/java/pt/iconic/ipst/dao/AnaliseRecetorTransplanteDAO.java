package pt.iconic.ipst.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import pt.iconic.ipst.modelo.AnaliseRecetorTransplante;

@Repository
public class AnaliseRecetorTransplanteDAO {

	@PersistenceContext
	private EntityManager manager;
	
	@Transactional
	public void adiciona(AnaliseRecetorTransplante analiserecetortransp){
		manager.persist(analiserecetortransp);	
	}
	
	@Transactional
	public void atualiza(AnaliseRecetorTransplante analiserecetortransp){
		manager.merge(analiserecetortransp);
	}

	@SuppressWarnings("unchecked")
	public List<AnaliseRecetorTransplante> ListaAnaliseRecetorTransplante(){
		return manager.createQuery("select d from AnaliseRecetorTransplante d").getResultList();
	}
	
	public AnaliseRecetorTransplante buscaPorId(Long id){
		return manager.find(AnaliseRecetorTransplante.class, id);
	}
	
/*	public void remove(AnaliseRecetorTransplante analiserecetortransp){
		AnaliseRecetorTransplante analiserecetortransprem = buscaPorId(analiserecetortransp.getId_analiserecetortranspl());
		manager.remove(analiserecetortransprem);
	}*/
	
/*	@SuppressWarnings("unchecked")
	public AnaliseRecetorTransplante buscaAnaliseRecetorTransplante(Long id){
		
		Query query = manager.createQuery("select a from AnaliseRecetorTransplante a JOIN a.recetor recetor WHERE recetor.id_recetor =:idrecetor");
		query.setParameter("idrecetor", id);
		
		List<AnaliseRecetorTransplante> results = query.getResultList();
		AnaliseRecetorTransplante analiserecetortransp = null;
		
		if(!results.isEmpty()){
			analiserecetortransp = (AnaliseRecetorTransplante) results.get(0);
		}
		return analiserecetortransp;
	}*/

	@SuppressWarnings("unchecked")
	public AnaliseRecetorTransplante buscaAnaliseRecetorTransplanteOrgao(Long idrecetor, Long idassigorg) {
		
		Query query = manager.createQuery("select a from AnaliseRecetorTransplante a JOIN a.recetor recetor JOIN a.assigorgao assig WHERE recetor.id_recetor =:idrecetor AND assig.id_assignacao = :idassigorg");
		query.setParameter("idrecetor", idrecetor);
		query.setParameter("idassigorg", idassigorg);
		
		List<AnaliseRecetorTransplante> results = query.getResultList();
		AnaliseRecetorTransplante analiserecetortransp = null;
		
		if(!results.isEmpty()){
			analiserecetortransp = (AnaliseRecetorTransplante) results.get(0);
		}
		return analiserecetortransp;
	}

	@SuppressWarnings("unchecked")
	public boolean buscaRecetorSeleccionadoDoTransplante(Long idassigorg) {
		Query query = manager.createQuery("select a from AnaliseRecetorTransplante a JOIN a.assigorgao assig JOIN a.estadoanaliserecetor estado WHERE assig.id_assignacao = :idassigorg AND estado.idestadoanalise =3");

		query.setParameter("idassigorg", idassigorg);
		
		List<AnaliseRecetorTransplante> results = query.getResultList();
		
		if(!results.isEmpty()){
			return true;
		}
		return false;
		
	}

/*	@SuppressWarnings("unchecked")
	public AnaliseRecetorTransplante buscaAnaliseRecetorTransplanteAssigOrg(Long idassigorg) {
		
		Query query = manager.createNativeQuery("select * from ANALISE_RECETOR_TRANSPLANTE art where art.ID_ASSIGORG = :id_assignacao and art.ID_ESTADO_ANALISE_RECETOR = 3", AnaliseRecetorTransplante.class);
		query.setParameter("id_assignacao", idassigorg);
		
		List<AnaliseRecetorTransplante> results = query.getResultList();
		AnaliseRecetorTransplante analiserecetortransp = null;
		
		if(!results.isEmpty()){
			analiserecetortransp = (AnaliseRecetorTransplante) results.get(0);
		}
		return analiserecetortransp;
	}*/
}
