package pt.iconic.ipst.modelo;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name = "POS_OPERAT_EXPLANTE")
public class PosOperatorioExplante {

	
	private Long id_posoperatexplante;
	private String th;
	private String diasuci;
	private String notas;
	private AnaliseDador analiseDador;
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="ID_POS_OPERAT_EXPLANTE")
	public Long getId_posoperatexplante() {
		return id_posoperatexplante;
	}
	public void setId_posoperatexplante(Long id_posoperatexplante) {
		this.id_posoperatexplante = id_posoperatexplante;
	}
	
	@Column(name="TH")
	public String getTh() {
		return th;
	}
	public void setTh(String th) {
		this.th = th;
	}
	
	@Column(name="DIAS_UCI")
	public String getDiasuci() {
		return diasuci;
	}
	public void setDiasuci(String diasuci) {
		this.diasuci = diasuci;
	}
	
	@Column(name="NOTAS")
	public String getNotas() {
		return notas;
	}
	public void setNotas(String notas) {
		this.notas = notas;
	}
	
	@OneToOne(fetch=FetchType.EAGER)
	@JoinColumn(name="ID_ANALISEDADOR")	
	public AnaliseDador getAnaliseDador() {
		return analiseDador;
	}
	public void setAnaliseDador(AnaliseDador analiseDador) {
		this.analiseDador = analiseDador;
	}
	

	
	
}
