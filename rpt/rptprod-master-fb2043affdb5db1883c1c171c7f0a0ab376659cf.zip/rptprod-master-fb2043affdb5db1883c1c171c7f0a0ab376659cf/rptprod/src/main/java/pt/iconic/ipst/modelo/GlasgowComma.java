package pt.iconic.ipst.modelo;

import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name = "GLASGOWCOMMA")
public class GlasgowComma {

	private Long Id_GlasgowComma;
	private String DescricaoGlasgowComma;
	private List<BDAvaliacaoInicial> BDAvaliacaoInicial;
	private List<Dador> Dadores;
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="ID_GLASGOWCOMMA")
	public Long getId_GlasgowComma() {
		return Id_GlasgowComma;
	}
	public void setId_GlasgowComma(Long id_GlasgowComma) {
		Id_GlasgowComma = id_GlasgowComma;
	}
		
	@Column(name="DESCRICAOGLASGOWCOMMA")
    public String getDescricaoGlasgowComma() {
		return DescricaoGlasgowComma;
	}
	public void setDescricaoGlasgowComma(String descricaoGlasgowComma) {
		DescricaoGlasgowComma = descricaoGlasgowComma;
	}
	
	@OneToMany(fetch = FetchType.LAZY, mappedBy = "glasgowComma")
	public List<BDAvaliacaoInicial> getBDAvaliacaoInicial() {
		return BDAvaliacaoInicial;
	}
	public void setBDAvaliacaoInicial(List<BDAvaliacaoInicial> bDAvaliacaoInicial) {
		BDAvaliacaoInicial = bDAvaliacaoInicial;
	}
	
	@OneToMany(fetch = FetchType.LAZY, mappedBy = "glasgowComma")
	public List<Dador> getDadores() {
		return Dadores;
	}
	public void setDadores(List<Dador> dadores) {
		Dadores = dadores;
	}

	
	
}
