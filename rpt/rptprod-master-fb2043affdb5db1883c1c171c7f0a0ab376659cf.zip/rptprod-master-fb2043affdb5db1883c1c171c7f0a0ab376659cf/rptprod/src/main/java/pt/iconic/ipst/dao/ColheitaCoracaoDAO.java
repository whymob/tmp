package pt.iconic.ipst.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import pt.iconic.ipst.modelo.ColheitaCoracao;


@Repository
@Transactional
public class ColheitaCoracaoDAO {

	@PersistenceContext
	private EntityManager manager;
	
	public void adiciona(ColheitaCoracao colheita){
		manager.persist(colheita);	
	}
	

	public void atualiza(ColheitaCoracao colheita){
		manager.merge(colheita);
	}
	

/*	@SuppressWarnings("unchecked")
	public List<ColheitaCoracao> ListaColheitaCoracao(){
		return manager.createQuery("select a from ColheitaCoracao a").getResultList();
	}*/
	
/*	public ColheitaCoracao buscaPorId(Long id){
		return manager.find(ColheitaCoracao.class, id);
	}
	
	
	public void remove(ColheitaCoracao colheita){
		ColheitaCoracao colheitaARemover = buscaPorId(colheita.getIdcolheitacoracao());
		manager.remove(colheitaARemover);
		
	}*/
	
	@SuppressWarnings("unchecked")
	public ColheitaCoracao buscacolheitaCoracaoanalise(Long idanalise){
		
		Query query = manager.createQuery("select b from ColheitaCoracao b JOIN b.analiseDador a WHERE a.id_AnaliseDador =:idanalise");
		query.setParameter("idanalise", idanalise);
		
		List<ColheitaCoracao> results = query.getResultList();
		ColheitaCoracao colheita = null;
		if(!results.isEmpty()){
			colheita = (ColheitaCoracao) results.get(0);
		}
		return colheita;
		
	}
}
