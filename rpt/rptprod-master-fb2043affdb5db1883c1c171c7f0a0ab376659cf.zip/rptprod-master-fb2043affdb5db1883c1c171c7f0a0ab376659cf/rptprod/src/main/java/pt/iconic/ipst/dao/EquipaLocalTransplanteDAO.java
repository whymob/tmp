package pt.iconic.ipst.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import pt.iconic.ipst.modelo.EquipaLocalTransplante;;

@Repository
@Transactional
public class EquipaLocalTransplanteDAO {

	
	
	@PersistenceContext
	private EntityManager manager;
	
	
	public void adiciona(EquipaLocalTransplante el){
		manager.persist(el);	
	}
	
	public void atualiza(EquipaLocalTransplante el){
		manager.merge(el);
	}
	

/*	@SuppressWarnings("unchecked")
	public List<EquipaLocalTransplante> ListaEquipaLocalTransplante(){
		return manager.createQuery("select a from EquipaLocalTransplante a").getResultList();
	}
	
	public EquipaLocalTransplante buscaPorId(Long id){
		return manager.find(EquipaLocalTransplante.class, id);
	}
	
	
	public void remove(EquipaLocalTransplante el){
		EquipaLocalTransplante elARemover = buscaPorId(el.getIdequipalocaltransplante());
		manager.remove(elARemover);
	}*/
	
	@SuppressWarnings("unchecked")
	public EquipaLocalTransplante buscaequipalocaltransplante(Long idassigorg){
		
//		Query query = manager.createQuery("select el from EquipaLocalTransplante el JOIN el.dador dador WHERE dador.id_Dador =:iddador");
//		query.setParameter("iddador", iddador);
		
		Query query = manager.createQuery("select el from EquipaLocalTransplante el JOIN el.assigorgao ass WHERE ass.id_assignacao =:idassigorg");
		query.setParameter("idassigorg", idassigorg);
		
		
		List<EquipaLocalTransplante> results = query.getResultList();
		EquipaLocalTransplante el = null;
		if(!results.isEmpty()){
			el = (EquipaLocalTransplante) results.get(0);
		}

		return el;
		
	}
	
	@SuppressWarnings("unchecked")
	public boolean existeequipalocaltransplanteassig(Long idassigorg){
		
		Query query = manager.createQuery("select el from EquipaLocalTransplante el JOIN el.assigorgao ass WHERE ass.id_assignacao =:idassigorg");
		query.setParameter("idassigorg", idassigorg);
		
		
		List<EquipaLocalTransplante> results = query.getResultList();
		if(!results.isEmpty()){
			return true;
		}else{
			
			return false;
		}
		
	}
}
