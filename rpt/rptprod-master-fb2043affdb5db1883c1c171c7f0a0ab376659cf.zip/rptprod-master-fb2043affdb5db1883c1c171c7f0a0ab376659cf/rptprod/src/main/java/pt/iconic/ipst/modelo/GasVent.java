package pt.iconic.ipst.modelo;

import java.util.Calendar;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name = "GASVENT")
public class GasVent {

	
	private Long id_gasvent;
	//private Exames Exames;
	private AnaliseDador analiseDador;
	//private List<GasVentAmostras> GasVentAmostras;
	private int fio2gasvent;
	private float valorgasvent;
	private int peep;
//	private int unidadesgasvent;
	private Calendar datagasvent;
	private String observacoesgasvent;
	private TipoGasVent tipoGasVent;
//	private UnidadesGasVent unidadesGasVent;
	
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="ID_GASVENT")
	public Long getId_gasvent() {
		return id_gasvent;
	}
	public void setId_gasvent(Long id_gasvent) {
		this.id_gasvent = id_gasvent;
	}
	

	@ManyToOne
	@JoinColumn(name="ID_ANALISEDADOR")
	public AnaliseDador getAnaliseDador() {
		return analiseDador;
	}
	public void setAnaliseDador(AnaliseDador analiseDador) {
		this.analiseDador = analiseDador;
	}
	
	@Column(name="FIO2GASVENT")
	public int getFio2gasvent() {
		return fio2gasvent;
	}
	public void setFio2gasvent(int fio2gasvent) {
		this.fio2gasvent = fio2gasvent;
	}

	@Column(name="VALORGASVENT")
	public float getValorgasvent() {
		return valorgasvent;
	}
	public void setValorgasvent(float valorgasvent) {
		this.valorgasvent = valorgasvent;
	}
	
//	@Column(name="UNIDADESGASVENT")
//	public int getUnidadesgasvent() {
//		return unidadesgasvent;
//	}
//	public void setUnidadesgasvent(int unidadesgasvent) {
//		this.unidadesgasvent = unidadesgasvent;
//	}
	
	@Column(name="PEEP")
	public int getPeep() {
		return peep;
	}
	public void setPeep(int peep) {
		this.peep = peep;
	}
	@Column(name="DATAGASVENT")
	public Calendar getDatagasvent() {
		return datagasvent;
	}
	public void setDatagasvent(Calendar datagasvent) {
		this.datagasvent = datagasvent;
	}
	
	@Column(name="OBSERVACOESGASVENT")
	public String getObservacoesgasvent() {
		return observacoesgasvent;
	}
	public void setObservacoesgasvent(String observacoesgasvent) {
		this.observacoesgasvent = observacoesgasvent;
	}
	
    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "ID_TIPOGASVENT")
	public TipoGasVent getTipoGasVent() {
		return tipoGasVent;
	}
	public void setTipoGasVent(TipoGasVent tipoGasVent) {
		this.tipoGasVent = tipoGasVent;
	}
 /*   @OneToMany(fetch = FetchType.LAZY, mappedBy = "gasVent")
	public List<GasVentAmostras> getGasVentAmostras() {
		return GasVentAmostras;
	}
	public void setGasVentAmostras(List<GasVentAmostras> gasVentAmostras) {
		GasVentAmostras = gasVentAmostras;
	}
*/
//    @ManyToOne(fetch = FetchType.EAGER)
//    @JoinColumn(name = "ID_UNIDADESGASVENT")
//	public UnidadesGasVent getUnidadesGasVent() {
//		return unidadesGasVent;
//	}
//	public void setUnidadesGasVent(UnidadesGasVent unidadesGasVent) {
//		this.unidadesGasVent = unidadesGasVent;
//	}
	


}
