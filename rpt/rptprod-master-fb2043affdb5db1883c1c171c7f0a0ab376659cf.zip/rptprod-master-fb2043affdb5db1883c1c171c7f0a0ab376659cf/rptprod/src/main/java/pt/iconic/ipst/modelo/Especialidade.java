package pt.iconic.ipst.modelo;

import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name = "ESPECIALIDADE")
public class Especialidade {

	
	private Long Id_Especialidade;
	private String Especialidade;
	private List<Utilizador> utilizadores;
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="ID_ESPECIALIDADE")
	public Long getId_Especialidade() {
		return Id_Especialidade;
	}
	public void setId_Especialidade(Long id_Especialidade) {
		Id_Especialidade = id_Especialidade;
	}
	
	@Column(name="ESPECIALIDADE")
	public String getEspecialidade() {
		return Especialidade;
	}
	public void setEspecialidade(String especialidade) {
		Especialidade = especialidade;
	}
	
    @OneToMany(fetch = FetchType.LAZY, mappedBy = "especialidade")
	public List<Utilizador> getUtilizadores() {
		return utilizadores;
	}
	public void setUtilizadores(List<Utilizador> utilizadores) {
		this.utilizadores = utilizadores;
	}

	
	
	
}
