package pt.iconic.ipst.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import pt.iconic.ipst.modelo.TransplanteRinsComplicacoes;

@Repository
@Transactional
public class TransplanteRinsComplicacoesDAO {

	@PersistenceContext
	private EntityManager manager;
	
	
	public void adiciona(TransplanteRinsComplicacoes transplante){
		manager.persist(transplante);	
	}
	

	public void atualiza(TransplanteRinsComplicacoes transplante){
		manager.merge(transplante);
	}
	

/*	@SuppressWarnings("unchecked")
	public List<TransplanteRinsComplicacoes> ListaTransplanteRinsComplicacoes(){
		return manager.createQuery("select a from TransplanteRinsComplicacoes a").getResultList();
	}*/
	
	public TransplanteRinsComplicacoes buscaPorId(Long id){
		return manager.find(TransplanteRinsComplicacoes.class, id);
	}
	
	
	public void remove(TransplanteRinsComplicacoes transplante){
		TransplanteRinsComplicacoes transplanteARemover = buscaPorId(transplante.getIdtransprinscompl());
		manager.remove(transplanteARemover);
		
	}
	
	@SuppressWarnings("unchecked")
	public List<TransplanteRinsComplicacoes> listatransplanteRinscomplassig(Long idassigorg){
		
		Query query = manager.createQuery("select b from TransplanteRinsComplicacoes b JOIN b.assigorgao a WHERE a.id_assignacao =:idassigorg");
		query.setParameter("idassigorg", idassigorg);
		
		List<TransplanteRinsComplicacoes> results = query.getResultList();
		return results;
		
	}
	
}
