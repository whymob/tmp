package pt.iconic.ipst.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import pt.iconic.ipst.modelo.ColheitaPancreas;

@Repository
@Transactional
public class ColheitaPancreasDAO {

	@PersistenceContext
	private EntityManager manager;
	
	
	public void adiciona(ColheitaPancreas colheita){
		manager.persist(colheita);	
	}
	

	public void atualiza(ColheitaPancreas colheita){
		manager.merge(colheita);
	}
	

/*	@SuppressWarnings("unchecked")
	public List<ColheitaPancreas> ListaColheitaPancreas(){
		return manager.createQuery("select a from ColheitaPancreas a").getResultList();
	}
	
	public ColheitaPancreas buscaPorId(Long id){
		return manager.find(ColheitaPancreas.class, id);
	}
	
	
	public void remove(ColheitaPancreas colheita){
		ColheitaPancreas colheitaARemover = buscaPorId(colheita.getIdcolheitapancreas());
		manager.remove(colheitaARemover);
		
	}*/
	
	@SuppressWarnings("unchecked")
	public ColheitaPancreas buscacolheitaPancreasanalise(Long idanalise){
		
		Query query = manager.createQuery("select b from ColheitaPancreas b JOIN b.analiseDador a WHERE a.id_AnaliseDador =:idanalise");
		query.setParameter("idanalise", idanalise);
		
		List<ColheitaPancreas> results = query.getResultList();
		ColheitaPancreas colheita = null;
		if(!results.isEmpty()){
			colheita = (ColheitaPancreas) results.get(0);
		}
		return colheita;
		
	}
}
