package pt.iconic.ipst.dao;


import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import pt.iconic.ipst.modelo.AnaliseRecetor;
import pt.iconic.ipst.modelo.ContatosRecetor;

@Repository
public class ContatosRecetorDAO 
{
	@PersistenceContext
	private EntityManager manager;
	
/*	public void adiciona(ContatosRecetor cont){
		manager.persist(cont);	
	}*/
	
	@Transactional
	public void atualiza(ContatosRecetor cont){
		manager.merge(cont);
	}

/*	@SuppressWarnings("unchecked")
	public List<ContatosRecetor> ListaContatos(){
		return manager.createQuery("select d from ContatosRecetor d").getResultList();
	}*/
	
	public ContatosRecetor buscaPorId(Long id){
		return manager.find(ContatosRecetor.class, id);
	}
	
	public void remove(ContatosRecetor cont){
		ContatosRecetor contrem = buscaPorId(cont.getId_contato());
		manager.remove(contrem);
	}
	
	@Transactional
	public boolean adicionacontato(String nome, String telefone, String telefone2, String email, AnaliseRecetor analise)
	{
		ContatosRecetor cont = new ContatosRecetor();
		
		cont.setEmail(email);
		cont.setNome(nome);
		cont.setTelefone(telefone);
		cont.setTelefone2(telefone2);
		cont.setAnaliserecetor(analise);
		
		manager.persist(cont);
		
		return true;
	}
	
	@SuppressWarnings({ "unchecked" })
	public List<ContatosRecetor> buscacontatosrecetor(Long analiserecetor)
	{		
		Query query = manager.createQuery("select a from ContatosRecetor a JOIN a.analiserecetor an WHERE an.id_analiserecetor =:analiserecetor");
		query.setParameter("analiserecetor", analiserecetor);
		
		List<ContatosRecetor> results = query.getResultList();

		
//        int count = 0;  
//        for (Iterator i = results.iterator(); i.hasNext();) {  
//        	ContatosRecetor values = (ContatosRecetor) i.next();  
//            System.out.println(++count + ": " + values.getId_contato() + ", " + values.getNome() + ", " + values.getTelefone() +"<br />");  
//
//        } 
		return results;
	}
}