package pt.iconic.ipst.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import pt.iconic.ipst.modelo.TransplanteRinsPerfusao;

@Repository
@Transactional
public class TransplanteRinsPerfusaoDAO {

	@PersistenceContext
	private EntityManager manager;
	
	
	public void adiciona(TransplanteRinsPerfusao transplante){
		manager.persist(transplante);	
	}
	

	public void atualiza(TransplanteRinsPerfusao transplante){
		manager.merge(transplante);
	}
	

/*	@SuppressWarnings("unchecked")
	public List<TransplanteRinsPerfusao> ListaTransplanteRinsPerfusao(){
		return manager.createQuery("select a from TransplanteRinsPerfusao a").getResultList();
	}*/
	
	public TransplanteRinsPerfusao buscaPorId(Long id){
		return manager.find(TransplanteRinsPerfusao.class, id);
	}
	
	
	public void remove(TransplanteRinsPerfusao transplante){
		TransplanteRinsPerfusao transplanteARemover = buscaPorId(transplante.getIdperfusaorins());
		manager.remove(transplanteARemover);
		
	}
	
	@SuppressWarnings("unchecked")
	public List<TransplanteRinsPerfusao> ListaTransplanteRinsPerfusaoassig(Long idassigorg){
		
		Query query = manager.createQuery("select p from TransplanteRinsPerfusao p JOIN p.assigorgao a WHERE a.id_assignacao =:idassigorg");
		query.setParameter("idassigorg", idassigorg);
		
		List<TransplanteRinsPerfusao> results = query.getResultList();

		return results;
		
	}
}
