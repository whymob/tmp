package pt.iconic.ipst.modelo;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name = "CONTATOSRECETOR")
public class ContatosRecetor 
{
	private Long id_contato;
	private String telefone;
	private String telefone2;
	private String email;
	private String nome;
	private AnaliseRecetor analiserecetor;
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "ID_CONTATO")
	public Long getId_contato() {
		return id_contato;
	}
	public void setId_contato(Long id_contato) {
		this.id_contato = id_contato;
	}
	
	@Column(name = "TELEFONE")
	public String getTelefone() {
		return telefone;
	}
	public void setTelefone(String telefone) {
		this.telefone = telefone;
	}
	
	@Column(name = "TELEFONE2")
	public String getTelefone2() {
		return telefone2;
	}
	public void setTelefone2(String telefone2) {
		this.telefone2 = telefone2;
	}
	
	@Column(name = "EMAIL")
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	
	@Column(name = "NOME")
	public String getNome() {
		return nome;
	}
	public void setNome(String nome) {
		this.nome = nome;
	}
	
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name="ID_ANALISERECETOR")
	public AnaliseRecetor getAnaliserecetor() {
		return analiserecetor;
	}
	public void setAnaliserecetor(AnaliseRecetor analiserecetor) {
		this.analiserecetor = analiserecetor;
	}
}