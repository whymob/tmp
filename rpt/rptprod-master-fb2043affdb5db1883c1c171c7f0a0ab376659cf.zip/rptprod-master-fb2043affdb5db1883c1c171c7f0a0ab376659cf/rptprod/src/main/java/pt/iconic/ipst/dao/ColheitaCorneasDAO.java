package pt.iconic.ipst.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import pt.iconic.ipst.modelo.ColheitaCorneas;


@Repository
@Transactional
public class ColheitaCorneasDAO {

	@PersistenceContext
	private EntityManager manager;
	
	public void adiciona(ColheitaCorneas colheita){
		manager.persist(colheita);	
	}
	

	public void atualiza(ColheitaCorneas colheita){
		manager.merge(colheita);
	}
	

/*	@SuppressWarnings("unchecked")
	public List<ColheitaCorneas> ListaColheitaCorneas(){
		return manager.createQuery("select a from ColheitaCorneas a").getResultList();
	}
	
	public ColheitaCorneas buscaPorId(Long id){
		return manager.find(ColheitaCorneas.class, id);
	}
	
	
	public void remove(ColheitaCorneas colheita){
		ColheitaCorneas colheitaARemover = buscaPorId(colheita.getIdcolheitacorneas());
		manager.remove(colheitaARemover);
		
	}*/
	
	@SuppressWarnings("unchecked")
	public ColheitaCorneas buscacolheitaCorneasanalise(Long idanalise){
		
		Query query = manager.createQuery("select b from ColheitaCorneas b JOIN b.analiseDador a WHERE a.id_AnaliseDador =:idanalise");
		query.setParameter("idanalise", idanalise);
		
		List<ColheitaCorneas> results = query.getResultList();
		ColheitaCorneas colheita = null;
		if(!results.isEmpty()){
			colheita = (ColheitaCorneas) results.get(0);
		}
		return colheita;
		
	}
}
