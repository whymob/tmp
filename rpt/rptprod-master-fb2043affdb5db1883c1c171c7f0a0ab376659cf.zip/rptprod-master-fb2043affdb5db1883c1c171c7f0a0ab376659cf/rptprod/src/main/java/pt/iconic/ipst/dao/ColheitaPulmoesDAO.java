package pt.iconic.ipst.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import pt.iconic.ipst.modelo.ColheitaPulmoes;

@Repository
@Transactional
public class ColheitaPulmoesDAO {

	@PersistenceContext
	private EntityManager manager;
	
	
	public void adiciona(ColheitaPulmoes colheita){
		manager.persist(colheita);	
	}
	

	public void atualiza(ColheitaPulmoes colheita){
		manager.merge(colheita);
	}
	

/*	@SuppressWarnings("unchecked")
	public List<ColheitaPulmoes> ListaColheitaPulmoes(){
		return manager.createQuery("select a from ColheitaPulmoes a").getResultList();
	}
	
	public ColheitaPulmoes buscaPorId(Long id){
		return manager.find(ColheitaPulmoes.class, id);
	}
	
	
	public void remove(ColheitaPulmoes colheita){
		ColheitaPulmoes colheitaARemover = buscaPorId(colheita.getIdcolheitapulmoes());
		manager.remove(colheitaARemover);
		
	}*/
	
	@SuppressWarnings("unchecked")
	public ColheitaPulmoes buscacolheitaPulmoesanalise(Long idanalise){
		
		Query query = manager.createQuery("select b from ColheitaPulmoes b JOIN b.analiseDador a WHERE a.id_AnaliseDador =:idanalise");
		query.setParameter("idanalise", idanalise);
		
		List<ColheitaPulmoes> results = query.getResultList();
		ColheitaPulmoes colheita = null;
		if(!results.isEmpty()){
			colheita = (ColheitaPulmoes) results.get(0);
		}
		return colheita;
		
	}
}
