package pt.iconic.ipst.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import pt.iconic.ipst.modelo.Microbiologia;



@Repository
public class MicrobiologiaDAO {

	@PersistenceContext
	private EntityManager manager;
	
	
	public void adiciona(Microbiologia microbiologia){
		manager.persist(microbiologia);	
	}
	
	@Transactional
	public void atualiza(Microbiologia microbiologia){
		manager.merge(microbiologia);
	}
	

/*	@SuppressWarnings("unchecked")
	public List<Microbiologia> ListaMicrobiologia(){
		return manager.createQuery("select a from Microbiologia a").getResultList();
	}*/
	
/*	public Microbiologia buscaPorId(Long id){
		return manager.find(Microbiologia.class, id);
	}
	
	
	public void remove(Microbiologia microbiologia){
		Microbiologia microbiologiaARemover = buscaPorId(microbiologia.getId_Microbiologia());
		manager.remove(microbiologiaARemover);
		
	}*/
	
	@SuppressWarnings("unchecked")
	public Microbiologia buscaMicrobiologiaAnalise(Long idanalise){
		
		Query query = manager.createQuery("select a from Microbiologia a JOIN a.analiseDador an WHERE an.id_AnaliseDador =:idanalise");
		query.setParameter("idanalise", idanalise);
		List<Microbiologia> results = query.getResultList();

		
		Microbiologia microbiologia = null;
		if(!results.isEmpty()){
			microbiologia = (Microbiologia) results.get(0);
		}
		return microbiologia;

	}
	
}
