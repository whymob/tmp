package pt.iconic.ipst.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import pt.iconic.ipst.modelo.GrupoSanguineo;

@Repository
@Transactional
public class GrupoSanguineoDAO {

	
	@PersistenceContext
	private EntityManager manager;
	
	
	public void adiciona(GrupoSanguineo gruposanguineo){
		manager.persist(gruposanguineo);	
	}
	
	
	public void atualiza(GrupoSanguineo gruposanguineo){
		manager.merge(gruposanguineo);
	}
	

/*	@SuppressWarnings("unchecked")
	public List<GrupoSanguineo> ListaGrupoSanguineo(){
		return manager.createQuery("select a from GrupoSanguineo a").getResultList();
	}
	
	public GrupoSanguineo buscaPorId(Long id){
		return manager.find(GrupoSanguineo.class, id);
	}
	
	
	public void remove(GrupoSanguineo gruposanguineo){
		GrupoSanguineo gruposanguineoARemover = buscaPorId(gruposanguineo.getId_gruposanguineo());
		manager.remove(gruposanguineoARemover);
		
	}*/
	
	@SuppressWarnings("unchecked")
	public GrupoSanguineo buscaGrupoSanguineoAnalise(Long idanalise){
		
		Query query = manager.createQuery("select b from GrupoSanguineo b JOIN b.analiseDador a WHERE a.id_AnaliseDador =:idanalise");
		query.setParameter("idanalise", idanalise);
		
		List<GrupoSanguineo> results = query.getResultList();
		GrupoSanguineo gruposanguineo = null;
		if(!results.isEmpty()){
			gruposanguineo = (GrupoSanguineo) results.get(0);
		}
		
		return gruposanguineo;

	}
}
