package pt.iconic.ipst.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import pt.iconic.ipst.modelo.TerapeuticasFollowUP;

@Repository
public class TerapeuticasFollowUpDAO {
	@PersistenceContext
	private EntityManager manager;
	
	@Transactional
	public void adiciona(TerapeuticasFollowUP terapeuticas){
		manager.persist(terapeuticas);	
	}
	
	@Transactional
	public void atualiza(TerapeuticasFollowUP terapeuticas){
		manager.merge(terapeuticas);
	}
	

/*	@SuppressWarnings("unchecked")
	public List<TerapeuticasFollowUP> ListaTerapeuticas(){
		return manager.createQuery("select c from TerapeuticasFollowUP c").getResultList();
	}*/
	
	public TerapeuticasFollowUP buscaPorId(Long id){
		return manager.find(TerapeuticasFollowUP.class, id);
	}
	
	
	public void remove(TerapeuticasFollowUP terapeuticas){
		TerapeuticasFollowUP terapeuticasARemover = buscaPorId(terapeuticas.getId_terapeutica());
		manager.remove(terapeuticasARemover);
	}
	
	@SuppressWarnings("unchecked")
	public List<TerapeuticasFollowUP> buscaterapeuticastransplantado(Long id_transplantado){
		Query query = manager.createQuery("select a from TerapeuticasFollowUP a JOIN a.transplantado an  WHERE an.id_transplante =:id_transplante");
		query.setParameter("id_transplante", id_transplantado);
		
		List<TerapeuticasFollowUP> results = query.getResultList();
		
		
		return results;
	
	}
	
}
