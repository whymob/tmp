package pt.iconic.ipst.modelo;

import java.util.Calendar;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import org.springframework.format.annotation.DateTimeFormat;

@Entity
@Table(name = "RECETOR")
public class Recetores 
{
	private Long id_recetor;
	private String codigorecetor;
	private String nomerecetor;
	private Calendar dataregisto;
	private int sns;
//	private int posicao; //posicao prioridade para rins, alternativa ao LUSOT momentanea
//	private int estado;
	private RecetorDetalhes recetordetalhe;
	private UnidadeTransplante unidadetransp;
	private OrgaosOferta orgao;
	private Hospital hospital;
	private AnaliseRecetor analiserecetor;
//	private String caminhodocrecetor;
//	private String nomedocrecetor;
	private List<AnaliseRecetorTransplante> analiserecetortransp;
	private Utilizador utilizador;
	private List<Transplantes> transplantes;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="ID_RECETOR")
	public Long getId_recetor() {
		return id_recetor;
	}
	public void setId_recetor(Long id_recetor) {
		this.id_recetor = id_recetor;
	}
	
	@Column(name="CODIGORECETOR")
	public String getCodigorecetor() {
		return codigorecetor;
	}
	public void setCodigorecetor(String codigorecetor) {
		this.codigorecetor = codigorecetor;
	}
	
	@Column(name="NOMERECETOR")
	public String getNomerecetor() {
		return nomerecetor;
	}
	public void setNomerecetor(String nomerecetor) {
		this.nomerecetor = nomerecetor;
	}
	
	@DateTimeFormat(pattern="dd/MM/yyyy")
	@Temporal(TemporalType.DATE)
	@Column(name="DATAREGISTO")
	public Calendar getDataregisto() {
		return dataregisto;
	}
	public void setDataregisto(Calendar dataregisto) {
		this.dataregisto = dataregisto;
	}

//	@ManyToOne(fetch=FetchType.EAGER)
//	@JoinColumn(name="ID_ORGAO")
//	public Orgaos getOrgaos() {
//		return orgaos;
//	}
//	public void setOrgaos(Orgaos orgaos) {
//		this.orgaos = orgaos;
//	}

	@OneToOne(fetch = FetchType.EAGER, mappedBy = "recetor")
	public RecetorDetalhes getRecetordetalhe() {
		return recetordetalhe;
	}
	public void setRecetordetalhe(RecetorDetalhes recetordetalhe) {
		this.recetordetalhe = recetordetalhe;
	}
	
	@ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "ID_HOSPITAL")
	public Hospital getHospital() {
		return hospital;
	}
	public void setHospital(Hospital hospital) {
		this.hospital = hospital;
	}

	@Column(name="SNS")
	public int getSns() {
		return sns;
	}

	public void setSns(int sns) {
		this.sns = sns;
	}

	@OneToOne(fetch = FetchType.LAZY, mappedBy = "recetor")
	public AnaliseRecetor getAnaliserecetor() {
		return analiserecetor;
	}

	public void setAnaliserecetor(AnaliseRecetor analiserecetor) {
		this.analiserecetor = analiserecetor;
	}
	
	@ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "ID_UNIDADETRANSP")
	public UnidadeTransplante getUnidadetransp() {
		return unidadetransp;
	}
	public void setUnidadetransp(UnidadeTransplante unidadetransp) {
		this.unidadetransp = unidadetransp;
	}
	
/*	@Column(name="POSICAO")
	public int getPosicao() {
		return posicao;
	}
	public void setPosicao(int posicao) {
		this.posicao = posicao;
	}*/
	
/*	@Column(name="ESTADO")
	public int getEstado() {
		return estado;
	}
	
	public void setEstado(int estado) {
		this.estado = estado;
	}*/
	
/*	@Column(name="CAMINHO_DOC_RECETOR")
	public String getCaminhodocrecetor() {
		return caminhodocrecetor;
	}
	public void setCaminhodocrecetor(String caminhodocrecetor) {
		this.caminhodocrecetor = caminhodocrecetor;
	}
	
	@Column(name="NOME_DOC_RECETOR")
	public String getNomedocrecetor() {
		return nomedocrecetor;
	}
	public void setNomedocrecetor(String nomedocrecetor) {
		this.nomedocrecetor = nomedocrecetor;
	}*/
	
	@OneToMany(fetch = FetchType.EAGER, mappedBy = "recetor")
	public List<AnaliseRecetorTransplante> getAnaliserecetortransp() {
		return analiserecetortransp;
	}
	public void setAnaliserecetortransp(List<AnaliseRecetorTransplante> analiserecetortransp) {
		this.analiserecetortransp = analiserecetortransp;
	}
	
	@ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "ID_UTILIZADOR")
	public Utilizador getUtilizador() {
		return utilizador;
	}
	public void setUtilizador(Utilizador utilizador) {
		this.utilizador = utilizador;
	}
	
	
	@OneToMany(fetch = FetchType.LAZY, mappedBy = "recetor")
	public List<Transplantes> getTransplantes() {
		return transplantes;
	}
	public void setTransplantes(List<Transplantes> transplantes) {
		this.transplantes = transplantes;
	}
	
	@ManyToOne(fetch=FetchType.EAGER)
	@JoinColumn(name="ID_ORGAO")
	public OrgaosOferta getOrgao() {
		return orgao;
	}
	public void setOrgao(OrgaosOferta orgao) {
		this.orgao = orgao;
	}
}