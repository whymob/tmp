package pt.iconic.ipst.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import pt.iconic.ipst.modelo.PPHepaticoComplicacoes;

@Repository
public class PPHepaticoComplicacoesDAO {

	@PersistenceContext
	private EntityManager manager;
	
	@Transactional
	public void adiciona(PPHepaticoComplicacoes hep){
		manager.persist(hep);	
	}
	
	@Transactional
	public void atualiza(PPHepaticoComplicacoes hep){
		manager.merge(hep);
	}
	
/*	@SuppressWarnings("unchecked")
	public List<PPHepaticoComplicacoes> ListaPPHepaticoComplicacoes(){
		return manager.createQuery("select p from PPHepaticoComplicacoes p").getResultList();
	}*/
	
	public PPHepaticoComplicacoes buscaPorId(Long id){
		return manager.find(PPHepaticoComplicacoes.class, id);
	}
	
	@Transactional
	public void remove(PPHepaticoComplicacoes hep){
		PPHepaticoComplicacoes heprem = buscaPorId(hep.getId_pphepaticocomplicacao());
		manager.remove(heprem);
	}
	
	@SuppressWarnings({ "rawtypes", "unchecked" })
	public List<PPHepaticoComplicacoes> ListaPPHepaticoComplicacoesAnalise(Long id)
	{
		Query query = manager.createQuery("select e from PPHepaticoComplicacoes e JOIN e.analiserecetor analiserecetor WHERE analiserecetor.id_analiserecetor =:idanalise");
		query.setParameter("idanalise", id);

		List results = query.getResultList();
		
		return results;
	}
}
