package pt.iconic.ipst.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import pt.iconic.ipst.modelo.HCSituacoesRisco;



@Repository
public class HCSituacoesRiscoDAO {

	
	@PersistenceContext
	private EntityManager manager;
	
	
	public void adiciona(HCSituacoesRisco sitrisco){
		manager.persist(sitrisco);	
	}
	
	@Transactional
	public void atualiza(HCSituacoesRisco sitrisco){
		manager.merge(sitrisco);
	}
	

/*	@SuppressWarnings("unchecked")
	public List<HCSituacoesRisco> ListaHCSituacoesRisco(){
		return manager.createQuery("select h from HCSituacoesRisco h").getResultList();
	}*/
	
/*	public HCSituacoesRisco buscaPorId(Long id){
		return manager.find(HCSituacoesRisco.class, id);
	}
	
	
	public void remove(HCSituacoesRisco sitrisco){
		HCSituacoesRisco sitriscoARemover = buscaPorId(sitrisco.getId_HCSituacoesRisco());
		manager.remove(sitriscoARemover);
		
	}*/

	@SuppressWarnings("unchecked")
	public HCSituacoesRisco buscaSituacoesRiscoAvaliacao(Long idanalise) {
		
		Query query = manager.createQuery("select b from HCSituacoesRisco b JOIN b.analiseDador a WHERE a.id_AnaliseDador =:idanalise");
		query.setParameter("idanalise", idanalise);
		
		List<HCSituacoesRisco> results = query.getResultList();
		HCSituacoesRisco sitrisco = null;
		if(!results.isEmpty()){
			sitrisco = (HCSituacoesRisco) results.get(0);
		}
			
		return sitrisco;
	}
}
