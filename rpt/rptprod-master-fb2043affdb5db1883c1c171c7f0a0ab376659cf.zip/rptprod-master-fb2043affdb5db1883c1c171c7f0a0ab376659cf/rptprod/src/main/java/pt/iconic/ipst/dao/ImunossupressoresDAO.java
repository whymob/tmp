package pt.iconic.ipst.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import pt.iconic.ipst.modelo.Imunossupressores;

@Repository
public class ImunossupressoresDAO 
{
	@PersistenceContext
	private EntityManager manager;
	
	@Transactional
	public void adiciona(Imunossupressores imu){
		manager.persist(imu);	
	}
	
	@Transactional
	public void atualiza(Imunossupressores imu){
		manager.merge(imu);
	}

/*	@SuppressWarnings("unchecked")
	public List<Imunossupressores> ListaImunossupressores(){
		return manager.createQuery("select d from Imunossupressores d").getResultList();
	}*/
	
	public Imunossupressores buscaPorId(Long id){
		return manager.find(Imunossupressores.class, id);
	}
	
	public void remove(Imunossupressores imu){
		Imunossupressores imurem = buscaPorId(imu.getId_imunossupressor());
		manager.remove(imurem);
	}
	
	@SuppressWarnings("unchecked")
	public List<Imunossupressores> buscaImunopressore(Long id_transplante)
	{		
		Query query = manager.createQuery("select f from Imunossupressores f JOIN f.transplante t WHERE t.id_transplante =:id_transplante");
		query.setParameter("id_transplante", id_transplante);
		
		List<Imunossupressores> results = query.getResultList();

		return results;
	}
}
