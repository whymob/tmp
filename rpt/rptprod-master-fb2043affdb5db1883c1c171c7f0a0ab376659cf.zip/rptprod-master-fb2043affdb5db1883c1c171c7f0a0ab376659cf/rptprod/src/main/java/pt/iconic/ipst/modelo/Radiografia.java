package pt.iconic.ipst.modelo;

import java.util.Calendar;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name = "RADIOGRAFIA")
public class Radiografia 
{
	private Long Id_Radiografia;
	private Calendar DataRadiografia;
	private int ValorUm;
	private int ValorDois;
	private int Valortres;
	private String Notas;
	private String caminho;
	private String nomedoc;
	private AnaliseDador analiseDador;
	private boolean statusharmrx;
	private Calendar datagravacao;
	
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="ID_RADIOGRAFIA")
	public Long getId_Radiografia() {
		return Id_Radiografia;
	}
	public void setId_Radiografia(Long id_Radiografia) {
		Id_Radiografia = id_Radiografia;
	}
	
	@Column(name="DATARADIOGRAFIA")
	public Calendar getDataRadiografia() {
		return DataRadiografia;
	}
	public void setDataRadiografia(Calendar dataRadiografia) {
		DataRadiografia = dataRadiografia;
	}
	
	@Column(name="VALORUM")
	public int getValorUm() {
		return ValorUm;
	}
	public void setValorUm(int valorUm) {
		ValorUm = valorUm;
	}
	
	@Column(name="VALORDOIS")
	public int getValorDois() {
		return ValorDois;
	}
	public void setValorDois(int valorDois) {
		ValorDois = valorDois;
	}
	
	@Column(name="VALORTRES")
	public int getValortres() {
		return Valortres;
	}
	public void setValortres(int valortres) {
		Valortres = valortres;
	}
	
	@Column(name="NOTAS")
	public String getNotas() {
		return Notas;
	}
	public void setNotas(String notas) {
		Notas = notas;
	}

	@OneToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="ID_ANALISEDADOR")
	public AnaliseDador getAnaliseDador() {
		return analiseDador;
	}
	public void setAnaliseDador(AnaliseDador analiseDador) {
		this.analiseDador = analiseDador;
	}
	
	@Column(name="CAMINHODOC")
	public String getCaminho() {
		return caminho;
	}
	public void setCaminho(String caminho) {
		this.caminho = caminho;
	}
	
	@Column(name="NOMEDOC")
	public String getNomedoc() {
		return nomedoc;
	}
	public void setNomedoc(String nomedoc) {
		this.nomedoc = nomedoc;
	}
	
	@Column(name="STATUSHARMONIO")	
	public boolean isStatusharmrx() {
		return statusharmrx;
	}
	public void setStatusharmrx(boolean statusharmrx) {
		this.statusharmrx = statusharmrx;
	}
	
	@Column(name="DATAGRAVACAO")
	public Calendar getDatagravacao() {
		return datagravacao;
	}


	public void setDatagravacao(Calendar datagravacao) {
		this.datagravacao = datagravacao;
	}
}