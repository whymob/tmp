package pt.iconic.ipst.dao;



import java.math.BigInteger;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import pt.iconic.ipst.modelo.Hospital;
import pt.iconic.ipst.modelo.Utilizador;

@Repository
public class UtilizadorDAO {
	
	
	@PersistenceContext
	private EntityManager manager;
	
	
	public void adiciona(Utilizador utilizador){
		
		BCryptPasswordEncoder passwordEncoder = new BCryptPasswordEncoder();
		String hashedPassword = passwordEncoder.encode(utilizador.getSenha());
		utilizador.setSenha(hashedPassword);
		manager.persist(utilizador);	
	}
	
	@Transactional
	public void atualiza(Utilizador utilizador){
//		BCryptPasswordEncoder passwordEncoder = new BCryptPasswordEncoder();
//		String hashedPassword = passwordEncoder.encode(utilizador.getSenha());
//		utilizador.setSenha(hashedPassword);
		manager.merge(utilizador);
	}
	
/*	@SuppressWarnings("unchecked")
	public List<Utilizador> ListaUtilizadores(){
		return manager.createQuery("select u from Utilizador u").getResultList();
	}*/
	
	@SuppressWarnings("unchecked")
	public List<Object> ListaUtilizadorActividadeRecente(){
		
		//List<Object[]> out = null;
		
		return manager.createQuery("select u.ID_Utilizador, u.utilizador, u.login, u.email "
				//+ ", j.dataActividade, a.descricaoActividade "
				+ "from Utilizador u "
			//	+ "LEFT JOIN u.actividades j LEFT JOIN j.actividade a"
				+ "").getResultList();
/*		
Query query = manager.createNativeQuery("select Utilizador.ID_Utilizador, Utilizador.utilizador, Utilizador.login, Utilizador.email , Utilizador_Actividade.dataActividade, Actividade.descricaoActividade from Utilizador "+ 
		"LEFT JOIN Utilizador_Actividade on (Utilizador_Actividade.ID_Utilizador = Utilizador.ID_Utilizador)"+
		"LEFT JOIN Actividade on (Utilizador_Actividade.Id_Actividade = Actividade.id_Actividade)");
out = query.getResultList();
int count = 0;  
for (Iterator i = out.iterator(); i.hasNext();) {  
    Object[] values = (Object[]) i.next();  
    System.out.println(++count + ": " + values[0] + ", " + values[1] + " ," + values[2] +"," + values[3] +"," + values[4] +" ," + values[5] +"<br />");  

}  */
	}
	
	public Utilizador buscaPorId(Long id){
		return manager.find(Utilizador.class, id);
	}
	
	@SuppressWarnings("unchecked")
	public List<Object> buscaUserActividadePorId(Long id){
		
		List<Object> out = null;
		Query query = manager.createQuery("select u.ID_Utilizador, u.utilizador, u.login, u.email "
				//+ ",j.dataActividade, a.descricaoActividade "
				+ "from Utilizador u "
				//+ "LEFT JOIN u.actividades j LEFT JOIN j.actividade a "
				+ "WHERE u.ID_Utilizador =:idutilizador");
		query.setParameter("idutilizador", id) ;
		out = query.getResultList();
		return out;
	}
	
/*	public void remove(Utilizador utilizador){
		Utilizador utilizadorARemover = buscaPorId(utilizador.getID_Utilizador());
		manager.remove(utilizadorARemover);
	}*/

	public String buscaNomeUser(Utilizador utilizador){
		String out = "";
		
		
		Query query = manager.createNativeQuery("SELECT UTILIZADOR FROM UTILIZADOR u WHERE u.LOGIN COLLATE Latin1_General_CS_AS =:login");
		query.setParameter("login", utilizador.getLogin()) ;
		out = query.getSingleResult().toString();
		//System.out.println("O resultado do query �: "+out);
		return out;
	}
	
	

	public Long buscaIdUser(Utilizador utilizador){

		Query query = manager.createNativeQuery("SELECT ID_UTILIZADOR FROM UTILIZADOR u WHERE u.LOGIN COLLATE Latin1_General_CS_AS =:login");
		//TypedQuery<Long> query = manager.createQuery("select u.ID_Utilizador from Utilizador u WHERE u.login =:login",Long.class);
		query.setParameter("login", utilizador.getLogin());
		BigInteger id = (BigInteger) query.getSingleResult();	
		
		
		
		//Query query = manager.createQuery("select u.ID_Utilizador from Utilizador u WHERE u.login =:login");
		//query.setParameter("login", utilizador.getLogin()) ;
		//out = query.getSingleResult().getClass().;
		//System.out.println("O resultado do query �: "+out);
		//return out;
		return id.longValue();
	}
	
	
	public boolean existeUtilizador(Utilizador utilizador) {

//		String password = utilizador.getSenha();
		BCryptPasswordEncoder passwordEncoder = new BCryptPasswordEncoder();
//		String hashedPassword = passwordEncoder.encode(password);
//		System.out.println("Senha utilizador: "+hashedPassword);
		
		String senha = "";
		
		Utilizador user = buscaPorLogin(utilizador.getLogin());
		if(user==null){
			senha = "";
		}else{
			senha = user.getSenha();
		}
		
	//	System.out.println("Senha utilizador: "+senha);		
					
		if(passwordEncoder.matches(utilizador.getSenha(), senha)){
			//System.out.println("A password corresponde");
			return true;
		}else{
			//System.out.println("A password n�o corresponde");
			return false;
		}
		
	
//			Query query = manager.createNativeQuery("SELECT * FROM UTILIZADOR u "
//					+ "WHERE u.LOGIN COLLATE Latin1_General_CS_AS =:login "
//					+ "AND u.SENHA =:senha");
//			query.setParameter("login", utilizador.getLogin()) ;
//			query.setParameter("senha", utilizador.getSenha());
//			if(query.getResultList().isEmpty()){
////				System.out.println("N�o existe utilizador");
//				return false;
//			}else{
////				System.out.println("Existe utilizador");
//				return true;
//			}


	}
	
	public boolean existeUtilizadoremail(String email) {

		Query query = manager.createQuery("SELECT u FROM Utilizador u WHERE u.email =:email");
		query.setParameter("email", email) ;
		if(query.getResultList().isEmpty()){
			//System.out.println("N�o existe utilizador");
			return false;
		}else{
			//System.out.println("Existe utilizador");
			return true;
		}


	}
	
	public boolean existeUtilizadorLogin(String login) {
		Query query = manager.createNativeQuery("SELECT * FROM UTILIZADOR u WHERE u.LOGIN COLLATE Latin1_General_CS_AS =:login",Utilizador.class);
		//Query query = manager.createQuery("SELECT u FROM Utilizador u WHERE u.login =:login");
		query.setParameter("login", login) ;
		if(query.getResultList().isEmpty()){
			//System.out.println("N�o existe utilizador");
			return false;
		}else{
			//System.out.println("Existe utilizador");
			return true;
		}


	}
	
	public boolean existeUtilizadorcodigoUUID(String codigo) {

		Query query = manager.createQuery("SELECT u FROM Utilizador u WHERE u.codigo =:codigo");
		query.setParameter("codigo", codigo) ;
		if(query.getResultList().isEmpty()){
			//System.out.println("N�o existe utilizador");
			return false;
		}else{
			//System.out.println("Existe utilizador");
			return true;
		}


	}
	
	@SuppressWarnings("rawtypes")
	public Utilizador buscaPorEmail(String email){
		
		Query query = manager.createQuery("select u from Utilizador u WHERE u.email =:email");
		query.setParameter("email", email) ;
		
		List results = query.getResultList();
		Utilizador utilizador = null;
		if(!results.isEmpty()){
		    // ignores multiple results
			utilizador = (Utilizador) results.get(0);
		}
		return utilizador;
		//return (Utilizador) query.getSingleResult();
	}
	
	@SuppressWarnings("rawtypes")
	public Utilizador buscaPorLogin(String login){
		
		Query query = manager.createNativeQuery("SELECT * FROM UTILIZADOR u WHERE u.LOGIN COLLATE Latin1_General_CS_AS =:login",Utilizador.class);
	//	Query query = manager.createQuery("select u from Utilizador u WHERE u.login =:login");
		query.setParameter("login", login) ;
		
		List results = query.getResultList();
		Utilizador utilizador = null;
		if(!results.isEmpty()){
		    // ignores multiple results
			utilizador = (Utilizador) results.get(0);
		}
		return utilizador;
		
		
		
	//	return (Utilizador) query.getSingleResult();
	}
	
	@SuppressWarnings("rawtypes")
	public Utilizador buscaPorCodigo(String codigo){
		
		Query query = manager.createQuery("select u from Utilizador u WHERE u.codigo =:codigo");
		query.setParameter("codigo", codigo) ;
		
		List results = query.getResultList();
		Utilizador utilizador = null;
		if(!results.isEmpty()){
		    // ignores multiple results
			utilizador = (Utilizador) results.get(0);
		}
		return utilizador;
	}

	
	@Transactional
	public void iniciamaster(Utilizador user) {
		adiciona(user);
		inserepermissoesmaster(user);	
	}

private void inserepermissoesmaster(Utilizador user) {

    Query query = manager.createNativeQuery("insert into PERMISSAO_LOCALIZACAO (ID_HOSPITAL, ID_POSICAO , ID_UTILIZADOR , LEITURAESCRITA) "
    		+ "select ID_Hospital, 1 , :iduser , 'true' from HOSPITAL");
        query.setParameter("iduser", user.getID_Utilizador());
        query.executeUpdate();
}

@SuppressWarnings("unchecked")
public List<Utilizador> buscacirurgioes() {
	
    Query query =  manager.createQuery("select u from Utilizador u  JOIN u.especialidade e WHERE e.id_Especialidade = 4 OR e.id_Especialidade =1 OR e.id_Especialidade =5 "
    		+ "OR e.id_Especialidade = 2 OR e.id_Especialidade =7 ");
    List<Utilizador> out =  query.getResultList();
    return out;
}
	
@SuppressWarnings("rawtypes")
public Utilizador buscadadoscirurgiao(Long iduser) {
	
    Query query =  manager.createQuery("select u from Utilizador u WHERE u.ID_Utilizador =:iduser");
    query.setParameter("iduser", iduser);
    List results = query.getResultList();
	Utilizador utilizador = null;
	if(!results.isEmpty()){
	    // ignores multiple results
		utilizador = (Utilizador) results.get(0);
	}
	return utilizador;
}

@SuppressWarnings("unchecked")
public List<Hospital> buscahospitaissempermissaouser(Long iduser) {

    Query query =  manager.createNativeQuery("select * from HOSPITAL where ID_HOSPITAL not in "
    		+ "(select ID_HOSPITAL from PERMISSAO_LOCALIZACAO where ID_UTILIZADOR= :iduser)", Hospital.class);
    query.setParameter("iduser", iduser);
    List<Hospital> out =  query.getResultList();
    return out;
}

public int CalculaVidasSalvasReferenciador(Long id_utilizador){
	
	Query query = manager.createNativeQuery("select count(r.ID_RECETOR) "
			+ "from DADOR d "
			+ "inner join ASSIGNACAO_ORGAOS ao on (ao.ID_DADOR = d.ID_DADOR) "
			+ "inner join ANALISE_RECETOR_TRANSPLANTE art on (art.ID_ASSIGORG = ao.ID_ASSIGNACAO_ORGAOS) "
			+ "inner join RECETOR r on (r.ID_RECETOR = art.ID_RECETOR) "
			+ "left join TRANSPLANTE_CORACAO tc on (tc.ID_ASSIGNACAO_ORGAOS = art.ID_ASSIGORG) "
			+ "left join TRANSPLANTE_FIGADO tf on (tf.ID_ASSIGNACAO_ORGAOS = art.ID_ASSIGORG) "
			+ "left join TRANSPLANTE_PANCREAS tp on (tp.ID_ASSIGNACAO_ORGAOS = art.ID_ASSIGORG) "
			+ "left join TRANSPLANTE_PULMOES tpu on (tpu.ID_ASSIGNACAO_ORGAOS = art.ID_ASSIGORG) "
			+ "left join TRANSPLANTE_PULMOES tr on (tr.ID_ASSIGNACAO_ORGAOS = art.ID_ASSIGORG) "
			+ "where d.ID_UTILIZADOR =:id_utilizador and art.ID_ESTADO_ANALISE_RECETOR = 3 and "
			+ "(tc.ESTADO = 1 OR (tf.ESTADO = 1 OR tf.ESTADO = 2) OR (tp.ESTADO = 1 OR tp.ESTADO = 2) "
			+ "OR (tpu.ESTADO = 1) OR (tr.ESTADO = 1 OR tr.ESTADO = 2))");
	query.setParameter("id_utilizador", id_utilizador);
	int num =  (int) query.getSingleResult();
	//System.out.println("vidas: "+num);
	return num;
}

@SuppressWarnings("unchecked")
public List<Object> Carregadadoresreferenciadosorgaostransplantados(Long id_utilizador){
	
	Query query = manager.createNativeQuery("select d.CODIGODADOR, d.DATAREGISTO, oo.NOME_ORGAO "
			+ "from DADOR d "
			+ "inner join ASSIGNACAO_ORGAOS ao on (ao.ID_DADOR = d.ID_DADOR) "
			+ "inner join ORGAOS_OFERTA oo on (ao.ID_ORGAOOFERTA = oo.ID_ORGAO_OFERTA) "
			+ "left join ANALISE_RECETOR_TRANSPLANTE art on (art.ID_ASSIGORG = ao.ID_ASSIGNACAO_ORGAOS) "
			+ "left join RECETOR r on (r.ID_RECETOR = art.ID_RECETOR) "
			+ "left join TRANSPLANTE_CORACAO tc on (tc.ID_ASSIGNACAO_ORGAOS = art.ID_ASSIGORG) "
			+ "left join TRANSPLANTE_FIGADO tf on (tf.ID_ASSIGNACAO_ORGAOS = art.ID_ASSIGORG) "
			+ "left join TRANSPLANTE_PANCREAS tp on (tp.ID_ASSIGNACAO_ORGAOS = art.ID_ASSIGORG) "
			+ "left join TRANSPLANTE_PULMOES tpu on (tpu.ID_ASSIGNACAO_ORGAOS = art.ID_ASSIGORG) "
			+ "left join TRANSPLANTE_PULMOES tr on (tr.ID_ASSIGNACAO_ORGAOS = art.ID_ASSIGORG) "
			+ "where d.ID_UTILIZADOR = :id_utilizador "
			+ "and art.ID_ESTADO_ANALISE_RECETOR = 3 "
			+ "and (tc.ESTADO = 1 OR (tf.ESTADO = 1 OR tf.ESTADO = 2) OR (tp.ESTADO = 1 OR tp.ESTADO = 2) "
			+ "OR (tpu.ESTADO = 1) OR (tr.ESTADO = 1 OR tr.ESTADO = 2))");
	query.setParameter("id_utilizador", id_utilizador);
	List<Object> out = query.getResultList();
	return out;
}

@SuppressWarnings("unchecked")
public List<Long> buscausershospitaldadorreferenciado(Long id_Hospital) { // Dador referenciado notifica��o

/*	Query query = manager.createNativeQuery("select distinct perm.ID_UTILIZADOR "
			+ "from PERMISSAO_LOCALIZACAO perm "
			+ "where perm.ID_HOSPITAL = :id_Hospital "
			+ "and perm.ID_POSICAO = 2 OR perm.ID_POSICAO = 6");*/
	
	//GCCT, CHD, EC, IPST
/*	Query query = manager.createNativeQuery("select distinct perm.ID_UTILIZADOR "
			+ "from PERMISSAO_LOCALIZACAO perm "
			+ "where perm.ID_HOSPITAL = :id_Hospital "
			+ "and (perm.ID_POSICAO = 2 OR perm.ID_POSICAO = 6 "
			+ "OR perm.ID_POSICAO = 4 OR perm.ID_POSICAO = 7)");*/
	
	//GCCT, CHD, EC desse hospital e todos do IPST
	Query query = manager.createNativeQuery("select distinct perm.ID_UTILIZADOR "
			+ "from PERMISSAO_LOCALIZACAO perm "
			+ "where perm.ID_HOSPITAL = :id_Hospital "
			+ "and (perm.ID_POSICAO = 6 "
			+ "OR perm.ID_POSICAO = 4 OR perm.ID_POSICAO = 7) OR perm.ID_POSICAO = 2 ");
	query.setParameter("id_Hospital", id_Hospital);
	List<Long> out = query.getResultList();
	return out;
	
}

@SuppressWarnings("unchecked")
public List<Long> buscausershospitaldadoraprovadoreprovado(Long id_Hospital, Long iddador) { //Dador aprovado e reprovado notifica��o
	//(GCCT, CHD, EC) desse hospital, ECC e ECT desses orgaos e dador,  e todos do IPST
	Query query = manager.createNativeQuery("select distinct (perm.ID_UTILIZADOR) "
			+ "from PERMISSAO_LOCALIZACAO perm "
			+ "where perm.ID_HOSPITAL = :id_Hospital "
			+ "and (perm.ID_POSICAO = 6 "
			+ "OR perm.ID_POSICAO = 4 OR perm.ID_POSICAO = 7) OR perm.ID_POSICAO = 2 "
			+ "UNION "
			//ECC
			+ "select distinct(ec.ID_UTILIZADOR) from EQUIPA_CIRURGIA ec "
			+ "where ec.ID_DADOR = :iddador and ec.ID_UTILIZADOR IS NOT NULL "
			+ "UNION "
			//ECT
			+ "select distinct (et.ID_UTILIZADOR) from EQUIPA_CIRURGIA_TRANSPLANTE et "
			+ "where et.ID_UTILIZADOR IS NOT NULL and et.ID_ASSIG_ORGAO IN ( "
			+ "select ao.ID_ASSIGNACAO_ORGAOS from ASSIGNACAO_ORGAOS ao where ao.ID_DADOR = :iddador ) ");
	query.setParameter("id_Hospital", id_Hospital);
	query.setParameter("iddador", iddador);
	List<Long> out = query.getResultList();
	return out;
}

@SuppressWarnings("unchecked")
public List<Long> buscausershospitalavaliacaoiniciada(Long id_Hospital) { // Avalia��o iniciada notifica��o
	//GCCT, CHD e todos do IPST
	Query query = manager.createNativeQuery("select distinct perm.ID_UTILIZADOR "
			+ "from PERMISSAO_LOCALIZACAO perm "
			+ "where perm.ID_HOSPITAL = :id_Hospital "
			+ "and (perm.ID_POSICAO = 6 "
			+ "OR perm.ID_POSICAO = 4) OR perm.ID_POSICAO = 2 ");
	query.setParameter("id_Hospital", id_Hospital);
	List<Long> out = query.getResultList();
	return out;
}

@SuppressWarnings("unchecked")
public List<Long> buscausershospitalcolheitainiciada(Long id_Hospital) { // Colheita iniciada notifica��o
	//GCCT do hospital e todos do IPST
	Query query = manager.createNativeQuery("select distinct perm.ID_UTILIZADOR "
			+ "from PERMISSAO_LOCALIZACAO perm "
			+ "where (perm.ID_HOSPITAL = :id_Hospital "
			+ "and perm.ID_POSICAO = 4) OR perm.ID_POSICAO = 2 ");
	query.setParameter("id_Hospital", id_Hospital);
	List<Long> out = query.getResultList();
	return out;
}

@SuppressWarnings("unchecked")
public List<Long> buscausershospitalcolheitaterminada(Long id_Hospital, Long iddador) { // Colheita terminada notifica��o
	
	//(GCCT, CHD, EC) do hospital e todos do IPST e ECT orgao dador
	Query query = manager.createNativeQuery("select distinct (perm.ID_UTILIZADOR) "
			+ "from PERMISSAO_LOCALIZACAO perm "
			+ "where perm.ID_HOSPITAL = :id_Hospital "
			+ "and (perm.ID_POSICAO = 6 "
			+ "OR perm.ID_POSICAO = 4 OR perm.ID_POSICAO = 7) OR perm.ID_POSICAO = 2 "
			+ "UNION "
			//ECT
			+ "select distinct (et.ID_UTILIZADOR) from EQUIPA_CIRURGIA_TRANSPLANTE et "
			+ "where et.ID_UTILIZADOR IS NOT NULL and et.ID_ASSIG_ORGAO IN ( "
			+ "select ao.ID_ASSIGNACAO_ORGAOS from ASSIGNACAO_ORGAOS ao where ao.ID_DADOR = :iddador ) ");
	query.setParameter("id_Hospital", id_Hospital);
	query.setParameter("iddador", iddador);
	List<Long> out = query.getResultList();
	return out;
}

@SuppressWarnings("unchecked")
public List<Long> buscausershospitalcandidatoanalise(Long id_hospital) { //Novo candidato em an�lise
	
	//EC e todos do IPST
	Query query = manager.createNativeQuery("select distinct perm.ID_UTILIZADOR "
			+ "from PERMISSAO_LOCALIZACAO perm "
			+ "where (perm.ID_HOSPITAL = :id_hospital "
			+ "and perm.ID_POSICAO = 7) OR perm.ID_POSICAO = 2 ");
	query.setParameter("id_hospital", id_hospital);
	List<Long> out = query.getResultList();
	return out;
}

@SuppressWarnings("unchecked")
public List<Long> buscausershospitalanalisecandidatodisponivel(Long id_hospital) { //Analise candidato disponivel
	//EC
	Query query = manager.createNativeQuery("select distinct perm.ID_UTILIZADOR "
			+ "from PERMISSAO_LOCALIZACAO perm "
			+ "where perm.ID_HOSPITAL = :id_hospital "
			+ "and perm.ID_POSICAO = 7");
	query.setParameter("id_hospital", id_hospital);
	List<Long> out = query.getResultList();
	return out;
}

@SuppressWarnings("unchecked")
public List<Long> buscausershospitalcandidatoseleccionado(Long id_hospital, Long iddador) { //Candidato seleccionado
	//(GCCT, EC) do hospital, ECT do orgao dador, e todos do IPST
	Query query = manager.createNativeQuery("select distinct (perm.ID_UTILIZADOR) "
			+ "from PERMISSAO_LOCALIZACAO perm "
			+ "where perm.ID_HOSPITAL = :id_hospital "
			+ "and (perm.ID_POSICAO = 4 "
			+ "OR perm.ID_POSICAO = 7) OR perm.ID_POSICAO = 2 "
			+ "UNION "
			//ECT
			+ "select distinct (et.ID_UTILIZADOR) from EQUIPA_CIRURGIA_TRANSPLANTE et "
			+ "where et.ID_UTILIZADOR IS NOT NULL and et.ID_ASSIG_ORGAO IN ( "
			+ "select ao.ID_ASSIGNACAO_ORGAOS from ASSIGNACAO_ORGAOS ao where ao.ID_DADOR = :iddador ) ");
	query.setParameter("id_hospital", id_hospital);
	query.setParameter("iddador", iddador);
	List<Long> out = query.getResultList();
	return out;
}

@SuppressWarnings("unchecked")
public List<Long> buscausershospitalorgaorecusado(Long idhosp, Long iddador) { // org�o recusado
	//(GCCT, EC) do hospital, ECT do orgao dador, e todos do IPST
	Query query = manager.createNativeQuery("select distinct (perm.ID_UTILIZADOR) "
			+ "from PERMISSAO_LOCALIZACAO perm "
			+ "where perm.ID_HOSPITAL = :id_hospital "
			+ "and (perm.ID_POSICAO = 4 "
			+ "OR perm.ID_POSICAO = 7) OR perm.ID_POSICAO = 2 "
			+ "UNION "
			//ECT
			+ "select distinct (et.ID_UTILIZADOR) from EQUIPA_CIRURGIA_TRANSPLANTE et "
			+ "where et.ID_UTILIZADOR IS NOT NULL and et.ID_ASSIG_ORGAO IN ( "
			+ "select ao.ID_ASSIGNACAO_ORGAOS from ASSIGNACAO_ORGAOS ao where ao.ID_DADOR = :iddador ) ");
	query.setParameter("id_hospital", idhosp);
	query.setParameter("iddador", iddador);
	List<Long> out = query.getResultList();
	return out;
}


@SuppressWarnings("unchecked")
public List<Long> buscausershospitalonderecetoroutrasinscricoes(Long id_hospital, int idorgaooferta, int sns) { // candidato seleccionado em outro hospital
	
	//EC
	Query query = manager.createNativeQuery("select distinct perm.ID_UTILIZADOR "
			+ "from PERMISSAO_LOCALIZACAO perm "
			+ "where perm.ID_POSICAO = 7 "
			+ "and perm.ID_HOSPITAL in (select r.ID_HOSPITAL "
			+ "from RECETOR r "
			+ "where r.ID_ORGAO = :idorgaooferta and r.SNS = :sns and r.ID_HOSPITAL<> :id_hospital "
			+ "and r.ID_RECETOR not in (select ar.ID_RECETOR from ESTADORECETOR e "
			+ "inner join ANALISERECETOR ar on (ar.ID_ANALISERECETOR = e.ID_ANALISERECETOR) "
			+ "where e.ESTADO = 5 and ar.ID_RECETOR = r.ID_RECETOR))");
	query.setParameter("id_hospital", id_hospital);
	query.setParameter("idorgaooferta", idorgaooferta);
	query.setParameter("sns", sns);
	
	List<Long> out = query.getResultList();
	return out;
}

@SuppressWarnings("unchecked")
public List<Long> buscausersnotificacaolocalcolheitagravado(Long idlocal, Long iddador) { // Local da colheita gravado
	//EC do hospital e ECC da cirurgia
	Query query = manager.createNativeQuery("select distinct perm.ID_UTILIZADOR "
			+ "from PERMISSAO_LOCALIZACAO perm "
			+ "where perm.ID_HOSPITAL = :id_hospital "
			+ "and perm.ID_POSICAO = 7 "
			+ "UNION "
			//ECC
			+ "select distinct(ec.ID_UTILIZADOR) from EQUIPA_CIRURGIA ec "
			+ "where ec.ID_DADOR = :iddador and ec.ID_UTILIZADOR IS NOT NULL ");
	query.setParameter("id_hospital", idlocal);
	query.setParameter("iddador", iddador);
	List<Long> out = query.getResultList();
	return out;
}

@SuppressWarnings("unchecked")
public List<Long> buscausersnotificacaodatahoradacolheitagravado(Long idlocal, Long iddador) { //Data e hora da colheita gravado
	//EC do hospital e ECC da cirurgia 				IPST??
	Query query = manager.createNativeQuery("select distinct perm.ID_UTILIZADOR "
			+ "from PERMISSAO_LOCALIZACAO perm "
			+ "where perm.ID_HOSPITAL = :id_hospital "
			+ "and perm.ID_POSICAO = 7 "
			+ "UNION "
			//ECC
			+ "select distinct(ec.ID_UTILIZADOR) from EQUIPA_CIRURGIA ec "
			+ "where ec.ID_DADOR = :iddador and ec.ID_UTILIZADOR IS NOT NULL ");
	query.setParameter("id_hospital", idlocal);
	query.setParameter("iddador", iddador);
	List<Long> out = query.getResultList();
	return out;
}

@SuppressWarnings("unchecked")
public List<Long> buscausersnotificacaolocaltransplantegravado(Long idlocal, Long iddador) { //Local de transplante gravado
	//EC do hospital e ECT do transplante de orgao, 		IPST??
	Query query = manager.createNativeQuery("select distinct perm.ID_UTILIZADOR "
			+ "from PERMISSAO_LOCALIZACAO perm "
			+ "where perm.ID_HOSPITAL = :id_hospital "
			+ "and perm.ID_POSICAO = 7 "
			+ "UNION "
			//ECT
			+ "select distinct (et.ID_UTILIZADOR) from EQUIPA_CIRURGIA_TRANSPLANTE et "
			+ "where et.ID_UTILIZADOR IS NOT NULL and et.ID_ASSIG_ORGAO IN ( "
			+ "select ao.ID_ASSIGNACAO_ORGAOS from ASSIGNACAO_ORGAOS ao where ao.ID_DADOR = :iddador)");
	query.setParameter("id_hospital", idlocal);
	query.setParameter("iddador", iddador);
	List<Long> out = query.getResultList();
	return out;
}

@SuppressWarnings("unchecked")
public List<Long> buscausersnotificacaodatahoradatransplantegravado(Long idlocal, Long iddador) { //Data e hora do transplante gravado

	//EC do hospital e ECT da cirurgia 				IPST??
	Query query = manager.createNativeQuery("select distinct perm.ID_UTILIZADOR "
			+ "from PERMISSAO_LOCALIZACAO perm "
			+ "where perm.ID_HOSPITAL = :id_hospital "
			+ "and perm.ID_POSICAO = 7 "
			+ "UNION "
			//ECT
			+ "select distinct (et.ID_UTILIZADOR) from EQUIPA_CIRURGIA_TRANSPLANTE et "
			+ "where et.ID_UTILIZADOR IS NOT NULL and et.ID_ASSIG_ORGAO IN ( "
			+ "select ao.ID_ASSIGNACAO_ORGAOS from ASSIGNACAO_ORGAOS ao where ao.ID_DADOR = :iddador)");
	query.setParameter("id_hospital", idlocal);
	query.setParameter("iddador", iddador);
	List<Long> out = query.getResultList();
	return out;
}

@SuppressWarnings("unchecked")
public List<Long> buscausershospitalorgaocolhidoValidadoNaoValidado(Long idhosp, Long iddador) { //Orgao colhido validado ou n�o validado

	//EC do hospital ,ECT da cirurgia e todos do IPST
	Query query = manager.createNativeQuery("select distinct perm.ID_UTILIZADOR "
			+ "from PERMISSAO_LOCALIZACAO perm "
			+ "where (perm.ID_HOSPITAL = :id_hospital "
			+ "and perm.ID_POSICAO = 7) OR perm.ID_POSICAO = 2 "
			+ "UNION "
			//ECT
			+ "select distinct (et.ID_UTILIZADOR) from EQUIPA_CIRURGIA_TRANSPLANTE et "
			+ "where et.ID_UTILIZADOR IS NOT NULL and et.ID_ASSIG_ORGAO IN ( "
			+ "select ao.ID_ASSIGNACAO_ORGAOS from ASSIGNACAO_ORGAOS ao where ao.ID_DADOR = :iddador)");
	query.setParameter("id_hospital", idhosp);
	query.setParameter("iddador", iddador);
	List<Long> out = query.getResultList();
	return out;
}


}
