package pt.iconic.ipst.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import pt.iconic.ipst.modelo.TransplantePancreasComplicacoes;

@Repository
@Transactional
public class TransplantePancreasComplicacoesDAO {

	@PersistenceContext
	private EntityManager manager;
	
	
	public void adiciona(TransplantePancreasComplicacoes transplante){
		manager.persist(transplante);	
	}
	

	public void atualiza(TransplantePancreasComplicacoes transplante){
		manager.merge(transplante);
	}
	

/*	@SuppressWarnings("unchecked")
	public List<TransplantePancreasComplicacoes> ListaTransplantePancreasComplicacoes(){
		return manager.createQuery("select a from TransplantePancreasComplicacoes a").getResultList();
	}*/
	
	public TransplantePancreasComplicacoes buscaPorId(Long id){
		return manager.find(TransplantePancreasComplicacoes.class, id);
	}
	
	
	public void remove(TransplantePancreasComplicacoes transplante){
		TransplantePancreasComplicacoes transplanteARemover = buscaPorId(transplante.getIdtransppancreascompl());
		manager.remove(transplanteARemover);
		
	}
	
	@SuppressWarnings("unchecked")
	public List<TransplantePancreasComplicacoes> listatransplantePancreascomplassig(Long idassigorg){
		
		Query query = manager.createQuery("select b from TransplantePancreasComplicacoes b JOIN b.assigorgao a WHERE a.id_assignacao =:idassigorg");
		query.setParameter("idassigorg", idassigorg);
		
		List<TransplantePancreasComplicacoes> results = query.getResultList();
		return results;
		
	}
}
