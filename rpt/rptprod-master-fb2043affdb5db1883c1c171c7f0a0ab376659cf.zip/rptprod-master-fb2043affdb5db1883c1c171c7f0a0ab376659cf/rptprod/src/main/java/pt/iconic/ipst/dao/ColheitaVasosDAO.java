package pt.iconic.ipst.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import pt.iconic.ipst.modelo.ColheitaVasos;

@Repository
@Transactional
public class ColheitaVasosDAO {

	@PersistenceContext
	private EntityManager manager;
	
	public void adiciona(ColheitaVasos colheita){
		manager.persist(colheita);	
	}
	

	public void atualiza(ColheitaVasos colheita){
		manager.merge(colheita);
	}
	

/*	@SuppressWarnings("unchecked")
	public List<ColheitaVasos> ListaColheitaVasos(){
		return manager.createQuery("select a from ColheitaVasos a").getResultList();
	}
	
	public ColheitaVasos buscaPorId(Long id){
		return manager.find(ColheitaVasos.class, id);
	}
	
	
	public void remove(ColheitaVasos colheita){
		ColheitaVasos colheitaARemover = buscaPorId(colheita.getIdcolheitavasos());
		manager.remove(colheitaARemover);
		
	}*/
	
	@SuppressWarnings("unchecked")
	public ColheitaVasos buscacolheitaVasosanalise(Long idanalise){
		
		Query query = manager.createQuery("select b from ColheitaVasos b JOIN b.analiseDador a WHERE a.id_AnaliseDador =:idanalise");
		query.setParameter("idanalise", idanalise);
		
		List<ColheitaVasos> results = query.getResultList();
		ColheitaVasos colheita = null;
		if(!results.isEmpty()){
			colheita = (ColheitaVasos) results.get(0);
		}
		return colheita;
		
	}
}
