package pt.iconic.ipst.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import pt.iconic.ipst.modelo.FuncoesOrgao;

@Repository
public class FuncoesOrgaoDAO {

	
	@PersistenceContext
	private EntityManager manager;
	
	
	public void adiciona(FuncoesOrgao funcoesorgao){
		manager.persist(funcoesorgao);	
	}
	
	@Transactional
	public void atualiza(FuncoesOrgao funcoesorgao){
		manager.merge(funcoesorgao);
	}
	

/*	@SuppressWarnings("unchecked")
	public List<FuncoesOrgao> ListaFuncoesOrgao(){
		return manager.createQuery("select a from FuncoesOrgao a").getResultList();
	}*/
	
/*	public FuncoesOrgao buscaPorId(Long id){
		return manager.find(FuncoesOrgao.class, id);
	}
	
	
	public void remove(FuncoesOrgao funcoesorgao){
		FuncoesOrgao funcoesorgaoARemover = buscaPorId(funcoesorgao.getId_FuncoesOrgao());
		manager.remove(funcoesorgaoARemover);
		
	}*/
	
	@SuppressWarnings("unchecked")
	public FuncoesOrgao buscaFuncoesOrgaoAnalise(Long idanalise){
		
		Query query = manager.createQuery("select b from FuncoesOrgao b JOIN b.analiseDador a WHERE a.id_AnaliseDador =:idanalise");
		query.setParameter("idanalise", idanalise);
		
		List<FuncoesOrgao> results = query.getResultList();
		FuncoesOrgao funcoesorgao = null;
		if(!results.isEmpty()){
			funcoesorgao = (FuncoesOrgao) results.get(0);
		}
		return funcoesorgao;
		
	}
	
}
