package pt.iconic.ipst.modelo;

import java.util.Calendar;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name = "BDORGAOS")
public class BDOrgaos {

	private Long id_bdorgaos;
	private AnaliseDador analiseDador;
	private boolean coracao;
	private boolean pulmoes;
	private boolean pulmaoEsq;
	private boolean pulmaoDir;
	private boolean figado;
	private boolean rimEsquerdo;
	private boolean rimDireito;
	private boolean rimpar;
	private boolean pancreas;
	private boolean corneas;
	private boolean tme;	
	private boolean tecidos; // pele
	private boolean tc;
	private boolean vasos;
	private boolean statusharmonio;
	private Calendar datagravacao;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="ID_BDORGAOS")
	public Long getId_bdorgaos() {
		return id_bdorgaos;
	}
	public void setId_bdorgaos(Long id_bdorgaos) {
		this.id_bdorgaos = id_bdorgaos;
	}
	
	
	@OneToOne
	@JoinColumn(name="ID_ANALISEDADOR")
	public AnaliseDador getAnaliseDador() {
		return analiseDador;
	}
	public void setAnaliseDador(AnaliseDador analiseDador) {
		this.analiseDador = analiseDador;
	}


	@Column(name="CORACAO")
	public boolean isCoracao() {
		return coracao;
	}
	public void setCoracao(boolean coracao) {
		this.coracao = coracao;
	}


	@Column(name="PULMOES")
	public boolean isPulmoes() {
		return pulmoes;
	}
	public void setPulmoes(boolean pulmoes) {
		this.pulmoes = pulmoes;
	}

	@Column(name="PULMAOESQ")
	public boolean isPulmaoEsq() {
		return pulmaoEsq;
	}
	public void setPulmaoEsq(boolean pulmaoEsq) {
		this.pulmaoEsq = pulmaoEsq;
	}
	
	@Column(name="PULMAODIR")
	public boolean isPulmaoDir() {
		return pulmaoDir;
	}
	public void setPulmaoDir(boolean pulmaoDir) {
		this.pulmaoDir = pulmaoDir;
	}
	@Column(name="FIGADO")
	public boolean isFigado() {
		return figado;
	}
	public void setFigado(boolean figado) {
		this.figado = figado;
	}
	
	@Column(name="RIMESQUERDO")
	public boolean isRimEsquerdo() {
		return rimEsquerdo;
	}
	public void setRimEsquerdo(boolean rimEsquerdo) {
		this.rimEsquerdo = rimEsquerdo;
	}
	
	@Column(name="RIMDIREITO")
	public boolean isRimDireito() {
		return rimDireito;
	}
	public void setRimDireito(boolean rimDireito) {
		this.rimDireito = rimDireito;
	}

	@Column(name="RIMPAR")
	public boolean isRimpar() {
		return rimpar;
	}
	public void setRimpar(boolean rimpar) {
		this.rimpar = rimpar;
	}
	
	@Column(name="PANCREAS")
	public boolean isPancreas() {
		return pancreas;
	}
	public void setPancreas(boolean pancreas) {
		this.pancreas = pancreas;
	}
	
	@Column(name="CORNEAS")
	public boolean isCorneas() {
		return corneas;
	}
	public void setCorneas(boolean corneas) {
		this.corneas = corneas;
	}

	@Column(name="TME")
	public boolean isTme() {
		return tme;
	}
	public void setTme(boolean tme) {
		this.tme = tme;
	}


	
	@Column(name="TECIDOS")
	public boolean isTecidos() {
		return tecidos;
	}
	public void setTecidos(boolean tecidos) {
		this.tecidos = tecidos;
	}
	
	@Column(name="TC")
	public boolean isTc() {
		return tc;
	}
	public void setTc(boolean tc) {
		this.tc = tc;
	}
	
	@Column(name="VASOS")
	public boolean isVasos() {
		return vasos;
	}
	public void setVasos(boolean vasos) {
		this.vasos = vasos;
	}
	@Column(name="STATUSHARMONIO")
	public boolean isStatusharmonio() {
		return statusharmonio;
	}
	public void setStatusharmonio(boolean statusharmonio) {
		this.statusharmonio = statusharmonio;
	}
	
	@Column(name="DATAGRAVACAO")
	public Calendar getDatagravacao() {
		return datagravacao;
	}


	public void setDatagravacao(Calendar datagravacao) {
		this.datagravacao = datagravacao;
	}
	
	
}
