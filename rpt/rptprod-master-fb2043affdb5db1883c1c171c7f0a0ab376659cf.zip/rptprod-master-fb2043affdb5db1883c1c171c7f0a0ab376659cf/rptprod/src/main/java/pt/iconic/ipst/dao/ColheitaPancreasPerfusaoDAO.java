package pt.iconic.ipst.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import pt.iconic.ipst.modelo.ColheitaPancreasPerfusao;

@Repository
@Transactional
public class ColheitaPancreasPerfusaoDAO {

	@PersistenceContext
	private EntityManager manager;
	
	
	public void adiciona(ColheitaPancreasPerfusao colheita){
		manager.persist(colheita);	
	}
	

	public void atualiza(ColheitaPancreasPerfusao colheita){
		manager.merge(colheita);
	}
	

/*	@SuppressWarnings("unchecked")
	public List<ColheitaPancreasPerfusao> ListaColheitaPancreasPerfusao(){
		return manager.createQuery("select a from ColheitaPancreasPerfusao a").getResultList();
	}*/
	
	public ColheitaPancreasPerfusao buscaPorId(Long id){
		return manager.find(ColheitaPancreasPerfusao.class, id);
	}
	
	
	public void remove(ColheitaPancreasPerfusao colheita){
		ColheitaPancreasPerfusao colheitaARemover = buscaPorId(colheita.getIdperfusaopancreas());
		manager.remove(colheitaARemover);
		
	}
	
	@SuppressWarnings("unchecked")
	public List<ColheitaPancreasPerfusao> ListaColheitaPancreasPerfusaoanalise(Long idanalise){
		
		Query query = manager.createQuery("select b from ColheitaPancreasPerfusao b JOIN b.analiseDador a WHERE a.id_AnaliseDador =:idanalise");
		query.setParameter("idanalise", idanalise);
		
		List<ColheitaPancreasPerfusao> results = query.getResultList();

		return results;
		
	}
}
