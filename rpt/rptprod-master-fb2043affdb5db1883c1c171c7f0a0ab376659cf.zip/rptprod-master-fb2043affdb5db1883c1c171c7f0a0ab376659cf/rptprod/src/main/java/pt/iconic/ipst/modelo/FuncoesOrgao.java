package pt.iconic.ipst.modelo;



import java.util.Calendar;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name = "FUNCOESORGAO")
public class FuncoesOrgao {

	
	private Long Id_FuncoesOrgao;
	private AnaliseDador analiseDador;
	private String gravindex;
	private boolean statusharmfo;
	private Calendar datagravacao;
	
//	private float BetaHCG;
//	private List<AmostrasFuncoesOrgao> Amostras;
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="ID_FUNCOESORGAO")
	public Long getId_FuncoesOrgao() {
		return Id_FuncoesOrgao;
	}
	public void setId_FuncoesOrgao(Long id_FuncoesOrgao) {
		Id_FuncoesOrgao = id_FuncoesOrgao;
	}
	
	@OneToOne
	@JoinColumn(name="ID_ANALISEDADOR")
	public AnaliseDador getAnaliseDador() {
		return analiseDador;
	}
	public void setAnaliseDador(AnaliseDador analiseDador) {
		this.analiseDador = analiseDador;
	}
	
	@Column(name="GRAVINDEX")
	public String getGravindex() {
		return gravindex;
	}
	public void setGravindex(String gravindex) {
		this.gravindex = gravindex;
	}

	@Column(name="STATUSHARMONIO")
	public boolean isStatusharmfo() {
		return statusharmfo;
	}
	public void setStatusharmfo(boolean statusharmfo) {
		this.statusharmfo = statusharmfo;
	}

	@Column(name="DATAGRAVACAO")
	public Calendar getDatagravacao() {
		return datagravacao;
	}


	public void setDatagravacao(Calendar datagravacao) {
		this.datagravacao = datagravacao;
	}
	
//	@Column(name="BETAHCG")
//	public float getBetaHCG() {
//		return BetaHCG;
//	}
//	public void setBetaHCG(float betaHCG) {
//		BetaHCG = betaHCG;
//	}
	
 /*   @OneToMany(fetch = FetchType.LAZY, mappedBy = "funcaoOrgao")
	public List<AmostrasFuncoesOrgao> getAmostras() {
		return Amostras;
	}
	public void setAmostras(List<AmostrasFuncoesOrgao> amostras) {
		Amostras = amostras;
	}
	*/



}
