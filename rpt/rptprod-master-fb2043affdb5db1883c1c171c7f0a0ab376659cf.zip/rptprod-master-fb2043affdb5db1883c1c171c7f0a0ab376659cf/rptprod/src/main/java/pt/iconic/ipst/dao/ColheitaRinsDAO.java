package pt.iconic.ipst.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import pt.iconic.ipst.modelo.ColheitaRins;


@Repository
@Transactional
public class ColheitaRinsDAO {

	
	@PersistenceContext
	private EntityManager manager;
	
	
	public void adiciona(ColheitaRins colheita){
		manager.persist(colheita);	
	}
	

	public void atualiza(ColheitaRins colheita){
		manager.merge(colheita);
	}
	

/*	@SuppressWarnings("unchecked")
	public List<ColheitaRins> ListaColheitaRins(){
		return manager.createQuery("select a from ColheitaRins a").getResultList();
	}
	
	public ColheitaRins buscaPorId(Long id){
		return manager.find(ColheitaRins.class, id);
	}
	
	
	public void remove(ColheitaRins colheita){
		ColheitaRins colheitaARemover = buscaPorId(colheita.getIdcolheitarins());
		manager.remove(colheitaARemover);
		
	}*/
	
	@SuppressWarnings("unchecked")
	public ColheitaRins buscacolheitaRinsanalise(Long idanalise){
		
		Query query = manager.createQuery("select b from ColheitaRins b JOIN b.analiseDador a WHERE a.id_AnaliseDador =:idanalise");
		query.setParameter("idanalise", idanalise);
		
		List<ColheitaRins> results = query.getResultList();
		ColheitaRins colheita = null;
		if(!results.isEmpty()){
			colheita = (ColheitaRins) results.get(0);
		}
		return colheita;
		
	}
}
