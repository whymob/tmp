package pt.iconic.ipst.dao;

import java.math.BigInteger;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import pt.iconic.ipst.modelo.GCCT;
import pt.iconic.ipst.modelo.Hospital;

@Repository
@Transactional
public class HospitalDAO {

	
	@PersistenceContext
	private EntityManager manager;
	
	public void adiciona(Hospital hospital){
		manager.persist(hospital);	
	}
	
	
	public void atualiza(Hospital hospital){
		manager.merge(hospital);

	}
	
	@SuppressWarnings("unchecked")
	public List<Hospital> ListaHospitais(){
		return manager.createQuery("select h from Hospital h").getResultList();
	}
	
	public Hospital buscaPorId(Long id){
		return manager.find(Hospital.class, id);
	}
	
	public void remove(Hospital hospital){
		Hospital hospitalARemover = buscaPorId(hospital.getId_Hospital());
		manager.remove(hospitalARemover);
	}
	
	public Long buscaIdHospital(String nome)
	{
		String query = "select h.id_Hospital from Hospital h WHERE h.nomeHospital =:nomeh";
		TypedQuery<Long> query2 = manager.createQuery(query,Long.class);
		query2.setParameter("nomeh", nome) ;
		
		Long id = query2.getSingleResult().longValue();	
		
		return id;
	}

	@SuppressWarnings("unchecked")
	public List<Hospital> ListaHospitaisPermissao(Long idposicao, Long idutilizador){
		
		List<Hospital> out = null;
		
		Query query = manager.createQuery("select h from Hospital h join h.permissoes permissao join permissao.utilizador utilizador WHERE permissao.posicao.id_Posicao =:idposicao AND utilizador.ID_Utilizador = :idutilizador");
		
		//String sql = "select distinct POSICAO.* from POSICAO inner join PERMISSAO_LOCALIZACAO on (PERMISSAO_LOCALIZACAO.ID_POSICAO = POSICAO.ID_POSICAO) "
		//		+ "inner join UTILIZADOR on (PERMISSAO_LOCALIZACAO.ID_UTILIZADOR = UTILIZADOR.ID_UTILIZADOR) "
		//		+ "where UTILIZADOR.ID_UTILIZADOR = :idutilizador";
		//Query query = manager.createNativeQuery(sql, Hospital.class);
		query.setParameter("idposicao", idposicao);
		query.setParameter("idutilizador", idutilizador);	
		out = query.getResultList();

		return out;
		
		
	}

	public boolean trataadicionar(String desc, Long combo)
	{
		Query query = manager.createQuery("SELECT e FROM Hospital e WHERE e.nomeHospital =:desc");
		query.setParameter("desc", desc);
		
		if(query.getResultList().isEmpty())
		{
			
			GCCT gcct = new GCCT();
			gcct.setId_GCCT(combo);
			
			Hospital hosp = new Hospital();
			hosp.setNomeHospital(desc);
			hosp.setGcct(gcct);
			adiciona(hosp);
			
			return true;
		}
		else
		{
			return false;
		}
	}

	public boolean trataalterar(Long id, String desc, Long combo)
	{
//		Query query = manager.createQuery("SELECT e FROM Hospital e WHERE e.nomeHospital =:desc");
//		query.setParameter("desc", desc);
//		
//		if(query.getResultList().isEmpty())
//		{
//			
			GCCT gcct = new GCCT();
			gcct.setId_GCCT(combo);
			
			Hospital hosp = new Hospital();
			hosp.setNomeHospital(desc);
			hosp.setGcct(gcct);
			hosp.setId_Hospital(id);
			atualiza(hosp);
				
			return true;
//		}
//		else
//		{
//			return false;
//		}
	}
	

	public boolean remover(Long id) 
	{
		Hospital hosp = new Hospital();
		hosp = buscaPorId(id);
		remove(hosp);
		return true;
	}



//		@SuppressWarnings("unchecked")
//		public List<Hospital> ListaHospitaisEditaPermissao(Long idutilizador){
//			
//			List<Hospital> out = null;
//			
//			Query query = manager.createQuery("select distinct h from Hospital h join h.permissoes permissao join permissao.utilizador utilizador WHERE utilizador.ID_Utilizador = :idutilizador");
//			
//			//String sql = "select distinct POSICAO.* from POSICAO inner join PERMISSAO_LOCALIZACAO on (PERMISSAO_LOCALIZACAO.ID_POSICAO = POSICAO.ID_POSICAO) "
//			//		+ "inner join UTILIZADOR on (PERMISSAO_LOCALIZACAO.ID_UTILIZADOR = UTILIZADOR.ID_UTILIZADOR) "
//			//		+ "where UTILIZADOR.ID_UTILIZADOR = :idutilizador";
//			//Query query = manager.createNativeQuery(sql, Hospital.class);
//			query.setParameter("idutilizador", idutilizador);	
//			out = query.getResultList();
//
//			return out;
//			
//			
//		}
	

	@SuppressWarnings("unchecked")
	public List<Object> ListaHospitaisEditaPermissao(Long idutilizador){
	
		List<Object> out = null;
		String sql = "select distinct h.ID_HOSPITAL, h.NOMEHOSPITAL, "
				+ "(select (p1.LEITURAESCRITA) from PERMISSAO_LOCALIZACAO p1 where (p1.ID_HOSPITAL = h.ID_HOSPITAL) AND (p1.ID_POSICAO = 1)AND p1.ID_UTILIZADOR = :idutilizador) as 'Admin', "
				+ "(select (p1.LEITURAESCRITA) from PERMISSAO_LOCALIZACAO p1 where (p1.ID_HOSPITAL = h.ID_HOSPITAL) AND (p1.ID_POSICAO = 2)AND p1.ID_UTILIZADOR = :idutilizador)as 'IPST', "
				+ "(select (p1.LEITURAESCRITA) from PERMISSAO_LOCALIZACAO p1 where (p1.ID_HOSPITAL = h.ID_HOSPITAL) AND (p1.ID_POSICAO = 3)AND p1.ID_UTILIZADOR = :idutilizador) as 'ACSS', "
				+ "(select (p1.LEITURAESCRITA) from PERMISSAO_LOCALIZACAO p1 where (p1.ID_HOSPITAL = h.ID_HOSPITAL) AND (p1.ID_POSICAO = 4)AND p1.ID_UTILIZADOR = :idutilizador)as 'GCCT', "
				+ "(select (p1.LEITURAESCRITA) from PERMISSAO_LOCALIZACAO p1 where (p1.ID_HOSPITAL = h.ID_HOSPITAL) AND (p1.ID_POSICAO = 5)AND p1.ID_UTILIZADOR = :idutilizador) as 'Coord. Colh. e Transpl.', "
				+ "(select (p1.LEITURAESCRITA) from PERMISSAO_LOCALIZACAO p1 where (p1.ID_HOSPITAL = h.ID_HOSPITAL) AND (p1.ID_POSICAO = 6)AND p1.ID_UTILIZADOR = :idutilizador)as 'Coord. Hosp. Doa��o',  "
				+ "(select (p1.LEITURAESCRITA) from PERMISSAO_LOCALIZACAO p1 where (p1.ID_HOSPITAL = h.ID_HOSPITAL) AND (p1.ID_POSICAO = 7)AND p1.ID_UTILIZADOR = :idutilizador) as 'Eq. Transplantes', "
				+ "(select (p1.LEITURAESCRITA) from PERMISSAO_LOCALIZACAO p1 where (p1.ID_HOSPITAL = h.ID_HOSPITAL) AND (p1.ID_POSICAO = 8)AND p1.ID_UTILIZADOR = :idutilizador)as 'Eq. Colheita', "
				+ "(select (p1.LEITURAESCRITA) from PERMISSAO_LOCALIZACAO p1 where (p1.ID_HOSPITAL = h.ID_HOSPITAL) AND (p1.ID_POSICAO = 9)AND p1.ID_UTILIZADOR = :idutilizador) as 'Av.& Man.', "
				+ "(select (p1.LEITURAESCRITA) from PERMISSAO_LOCALIZACAO p1 where (p1.ID_HOSPITAL = h.ID_HOSPITAL) AND (p1.ID_POSICAO = 10)AND p1.ID_UTILIZADOR = :idutilizador)as 'Follow Up' "
				+ "from PERMISSAO_LOCALIZACAO p "
				+ "inner join HOSPITAL h on (p.ID_HOSPITAL = h.ID_HOSPITAL) "
				+ "where p.ID_UTILIZADOR = :idutilizador "
				+ "order by h.ID_HOSPITAL ";

		Query query = manager.createNativeQuery(sql);
		query.setParameter("idutilizador", idutilizador);
		out = query.getResultList();
		return out;
	}
	
	
	@SuppressWarnings("unchecked")
	public List<Hospital> ListaHospitaisEntidade(Long id){
		
		List<Hospital> out = null;
		
		Query query = manager.createQuery("select h from Hospital h join h.entidade entidade WHERE entidade.id_Entidade =:id");
		query.setParameter("id", id);
	
		out = query.getResultList();

		return out;
	}
	
	public Long buscaIdEntidade(Long idhosp)
	{
		Query query = manager.createNativeQuery("select h.id_entidade from Hospital h WHERE h.id_hospital =:idhosp");
		query.setParameter("idhosp", idhosp);
		
		BigInteger id = (BigInteger) query.getSingleResult();	

		return id.longValue();
	}
	
}
