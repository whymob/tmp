package pt.iconic.ipst.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import pt.iconic.ipst.dao.OrgaosOfertaDAO;

@Controller
public class OrgaoController {
	private OrgaosOfertaDAO daoorgaooferta;
	
	@Autowired
	public OrgaoController(OrgaosOfertaDAO daoorgaooferta) {
		this.daoorgaooferta = daoorgaooferta;
	}

	@RequestMapping("abreorgaos")
	public String abreorgaos(Long id, Model model){
		model.addAttribute("orgao", daoorgaooferta.ListaOrgaosOferta());
	return "admin/divdetalheorgaos";
	}	
}