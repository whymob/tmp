package pt.iconic.ipst.modelo;

import java.util.Calendar;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.persistence.Transient;

import org.springframework.format.annotation.DateTimeFormat;

@Entity
@Table(name = "RECETORDETALHES")
public class RecetorDetalhes 
{
	private Long id_recetordetalhes;
	private String moradarecetor;
	private String codpostalrecetor;
	private String localidaderecetor;
	private String emailrecetor;
	private Calendar datanascimento;
	private int telemovel;
	private int telefone;
	private boolean sexo;
	private boolean tipocidadao;
	private Paises nacionalidade;
	private LocalResidencia residencia;
	private int numidentificacao;
	private int tiponumidentificacao;
	private int numidentificacao2;
	private int tiponumidentificacao2;
	private Recetores recetor;
	private Etnia etnia;
	private double peso;
	private int altura;
	private boolean rh;
	private int abo;
	private int idade;
	private int pin;
	
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="ID_RECETORDETALHES")
	public Long getId_recetordetalhes() {
		return id_recetordetalhes;
	}
	public void setId_recetordetalhes(Long id_recetordetalhes) {
		this.id_recetordetalhes = id_recetordetalhes;
	}
	
	@Column(name="MORADARECETOR")
	public String getMoradarecetor() {
		return moradarecetor;
	}
	public void setMoradarecetor(String moradarecetor) {
		this.moradarecetor = moradarecetor;
	}
	
	@Column(name="CODPOSTALRECETOR")
	public String getCodpostalrecetor() {
		return codpostalrecetor;
	}
	public void setCodpostalrecetor(String codpostalrecetor) {
		this.codpostalrecetor = codpostalrecetor;
	}
	
	@Column(name="LOCALIDADERECETOR")
	public String getLocalidaderecetor() {
		return localidaderecetor;
	}
	public void setLocalidaderecetor(String localidaderecetor) {
		this.localidaderecetor = localidaderecetor;
	}
	
	@Column(name="EMAILRECETOR")
	public String getEmailrecetor() {
		return emailrecetor;
	}
	public void setEmailrecetor(String emailrecetor) {
		this.emailrecetor = emailrecetor;
	}
	
	@DateTimeFormat(pattern="dd/MM/yyyy")
	@Temporal(TemporalType.DATE)
	@Column(name="DATANASCIMENTORECETOR")
	public Calendar getDatanascimento() {
		return datanascimento;
	}
	public void setDatanascimento(Calendar datanascimento) {
		this.datanascimento = datanascimento;
	}
	
	@Column(name="TELEMOVELRECETOR")
	public int getTelemovel() {
		return telemovel;
	}
	public void setTelemovel(int telemovel) {
		this.telemovel = telemovel;
	}
	
	@Column(name="TELEFONERECETOR")
	public int getTelefone() {
		return telefone;
	}
	public void setTelefone(int telefone) {
		this.telefone = telefone;
	}
	
	@OneToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="ID_RECETOR")
	public Recetores getRecetor() {
		return recetor;
	}
	public void setRecetor(Recetores recetor) {
		this.recetor = recetor;
	}
	
	@Column(name="SEXO")
	public boolean isSexo() {
		return sexo;
	}
	public void setSexo(boolean sexo) {
		this.sexo = sexo;
	}
	
	@Column(name="TIPOCIDADAO")
	public boolean isTipocidadao() {
		return tipocidadao;
	}
	public void setTipocidadao(boolean tipocidadao) {
		this.tipocidadao = tipocidadao;
	}
	
	@ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "ID_PAIS")
	public Paises getNacionalidade() {
		return nacionalidade;
	}
	public void setNacionalidade(Paises nacionalidade) {
		this.nacionalidade = nacionalidade;
	}
	
	@ManyToOne(fetch=FetchType.EAGER)
	@JoinColumn(name="ID_RESIDENCIA")
	public LocalResidencia getResidencia() {
		return residencia;
	}
	public void setResidencia(LocalResidencia residencia) {
		this.residencia = residencia;
	}

	@Column(name="NUMIDENTIFICACAO")
	public int getNumidentificacao() {
		return numidentificacao;
	}
	public void setNumidentificacao(int numidentificacao) {
		this.numidentificacao = numidentificacao;
	}
	
	@Column(name="NUMIDENTIFICACAO2")
	public int getNumidentificacao2() {
		return numidentificacao2;
	}
	public void setNumidentificacao2(int numidentificacao2) {
		this.numidentificacao2 = numidentificacao2;
	}
	
	@Column(name="TIPOIDENTIFICACAO")
	public int getTiponumidentificacao() {
		return tiponumidentificacao;
	}
	public void setTiponumidentificacao(int tiponumidentificacao) {
		this.tiponumidentificacao = tiponumidentificacao;
	}
	
	@Column(name="TIPOIDENTIFICACAO2")
	public int getTiponumidentificacao2() {
		return tiponumidentificacao2;
	}
	public void setTiponumidentificacao2(int tiponumidentificacao2) {
		this.tiponumidentificacao2 = tiponumidentificacao2;
	}
	
	@ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "ID_ETNIA")
	public Etnia getEtnia() {
		return etnia;
	}
	public void setEtnia(Etnia etnia) {
		this.etnia = etnia;
	}
	
	@Column(name="PESO")
	public double getPeso() {
		return peso;
	}
	public void setPeso(double peso) {
		this.peso = peso;
	}
	
	@Column(name="ALTURA")
	public int getAltura() {
		return altura;
	}
	public void setAltura(int altura) {
		this.altura = altura;
	}
	
	@Column(name="RH")
	public boolean isRh() {
		return rh;
	}
	public void setRh(boolean rh) {
		this.rh = rh;
	}
	
	@Column(name="ABO")
	public int getAbo() {
		return abo;
	}
	public void setAbo(int abo) {
		this.abo = abo;
	}
	
	
	
	@Transient
	@Column(name="IDADE")
    public int getIdade() {
    	this.idade = elapsed(datanascimento, Calendar.getInstance(), Calendar.YEAR);
        return idade;
    }
    
	public void setIdade(int idade) {
		this.idade = idade;
	}
	
    private static int elapsed(Calendar before, Calendar after, int field) {
        checkBeforeAfter(before, after);
        Calendar clone = (Calendar) before.clone(); // Otherwise changes are been reflected.
        int elapsed = -1;
        while (!clone.after(after)) {
            clone.add(field, 1);
            elapsed++;
        }
        return elapsed;
    }
    
    private static void checkBeforeAfter(Calendar before, Calendar after) {
        if (before.after(after)) {
            throw new IllegalArgumentException(
                "O primeiro calend�rio deve ser definido antes do segundo calendario.");
        }
    }
    
    @Column(name="PIN")
	public int getPin() {
		return pin;
	}
	public void setPin(int pin) {
		this.pin = pin;
	}
}