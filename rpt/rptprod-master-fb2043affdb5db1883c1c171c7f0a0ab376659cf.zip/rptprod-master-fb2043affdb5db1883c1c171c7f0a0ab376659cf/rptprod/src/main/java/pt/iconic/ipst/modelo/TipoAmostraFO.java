package pt.iconic.ipst.modelo;

import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name = "TIPOAMOSTRAFO")
public class TipoAmostraFO {

	
	private Long id_tipoamostra;
	private String descricao;
	private List<AmostrasFuncoesOrgao> Amostra;
//	private List<PPAnalisesRecetor> Analises;	
//	private List<PPAnalisesFollowUp> AnalisesFollowup;
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="ID_TIPOAMOSTRA")
	public Long getId_tipoamostra() {
		return id_tipoamostra;
	}
	
	public void setId_tipoamostra(Long id_tipoamostra) {
		this.id_tipoamostra = id_tipoamostra;
	}
	
	@Column(name="DESCRICAO")
	public String getDescricao() {
		return descricao;
	}
	public void setDescricao(String descricao) {
		this.descricao = descricao;
	}
	
    @OneToMany(fetch = FetchType.LAZY, mappedBy = "tipoAmostra")
	public List<AmostrasFuncoesOrgao> getAmostra() {
		return Amostra;
	}
	public void setAmostra(List<AmostrasFuncoesOrgao> amostra) {
		Amostra = amostra;
	}

//    @OneToMany(fetch = FetchType.LAZY, mappedBy = "tipoAmostra")
//	public List<PPAnalisesRecetor> getAnalises() {
//		return Analises;
//	}
//
//	public void setAnalises(List<PPAnalisesRecetor> analises) {
//		Analises = analises;
//	}
//
//    @OneToMany(fetch = FetchType.LAZY, mappedBy = "tipoAmostra")
//	public List<PPAnalisesFollowUp> getAnalisesFollowup() {
//		return AnalisesFollowup;
//	}
//
//	public void setAnalisesFollowup(List<PPAnalisesFollowUp> analisesFollowup) {
//		AnalisesFollowup = analisesFollowup;
//	}
//	
	
	
}
