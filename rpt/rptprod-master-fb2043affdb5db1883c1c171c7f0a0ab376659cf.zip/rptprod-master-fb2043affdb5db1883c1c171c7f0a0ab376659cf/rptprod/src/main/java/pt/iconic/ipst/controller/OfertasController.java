package pt.iconic.ipst.controller;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import javax.servlet.http.HttpSession;

import org.json.simple.JSONArray;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import pt.iconic.ipst.dao.AmostrasFODAO;
import pt.iconic.ipst.dao.AmostrasFuncoesOrgaoDAO;
import pt.iconic.ipst.dao.AnaliseDadorDAO;
import pt.iconic.ipst.dao.AssignacaoHospitalDAO;
import pt.iconic.ipst.dao.AssignacaoOrgaosDAO;
import pt.iconic.ipst.dao.BDAvaliacaoInicialDAO;
import pt.iconic.ipst.dao.BDOrgaosDAO;
import pt.iconic.ipst.dao.BiopsiaHepaticaDAO;
import pt.iconic.ipst.dao.BiopsiaRenalDAO;
import pt.iconic.ipst.dao.BiopsiarenalItensDAO;
import pt.iconic.ipst.dao.BroncoescopiaDAO;
import pt.iconic.ipst.dao.CausaMorteDAO;
import pt.iconic.ipst.dao.ColheitaCoracaoDAO;
import pt.iconic.ipst.dao.ColheitaFigadoDAO;
import pt.iconic.ipst.dao.ColheitaFigadoPerfusaoDAO;
import pt.iconic.ipst.dao.ColheitaPancreasDAO;
import pt.iconic.ipst.dao.ColheitaPancreasPerfusaoDAO;
import pt.iconic.ipst.dao.ColheitaPancreasProdutoDAO;
import pt.iconic.ipst.dao.ColheitaPulmoesDAO;
import pt.iconic.ipst.dao.ColheitaPulmoesTratamentoDAO;
import pt.iconic.ipst.dao.ColheitaRinsDAO;
import pt.iconic.ipst.dao.ColheitaRinsPerfusaoDAO;
import pt.iconic.ipst.dao.ColheitaRinsTerapeuticasDAO;
import pt.iconic.ipst.dao.CoronografiaDAO;
import pt.iconic.ipst.dao.DadorDAO;
import pt.iconic.ipst.dao.DadorDetalhesDAO;
import pt.iconic.ipst.dao.DadosAbdFigadoDAO;
import pt.iconic.ipst.dao.DadosAbdPancreasDAO;
import pt.iconic.ipst.dao.DadosAbdRinsDAO;
import pt.iconic.ipst.dao.DadosCoronografiaDAO;
import pt.iconic.ipst.dao.EcofigadoDAO;
import pt.iconic.ipst.dao.EcopancreasDAO;
import pt.iconic.ipst.dao.EcorinsDAO;
import pt.iconic.ipst.dao.EcotoraxicoDAO;
import pt.iconic.ipst.dao.EletrocardiogramaDAO;
import pt.iconic.ipst.dao.EquipaCirurgiaDAO;
import pt.iconic.ipst.dao.EquipaCirurgiaTransplanteDAO;
import pt.iconic.ipst.dao.EquipaLocalDAO;
import pt.iconic.ipst.dao.EquipaLocalTransplanteDAO;
import pt.iconic.ipst.dao.EquipaSuporteDAO;
import pt.iconic.ipst.dao.EquipaSuporteTransplanteDAO;
import pt.iconic.ipst.dao.EtniaDAO;
import pt.iconic.ipst.dao.FuncoesOrgaoDAO;
import pt.iconic.ipst.dao.GasVentDAO;
import pt.iconic.ipst.dao.GlasgowCommaDAO;
import pt.iconic.ipst.dao.GrupoSanguineoDAO;
import pt.iconic.ipst.dao.HCDoencasPreExistentesDAO;
import pt.iconic.ipst.dao.HCExameFisicoDAO;
import pt.iconic.ipst.dao.HCGeralDAO;
import pt.iconic.ipst.dao.HCSituacoesRiscoDAO;
import pt.iconic.ipst.dao.HistoricoAssignacaoDAO;
import pt.iconic.ipst.dao.HospitalDAO;
import pt.iconic.ipst.dao.ImunologiaDAO;
import pt.iconic.ipst.dao.LesoesRadiografiaDAO;
import pt.iconic.ipst.dao.MBAnalisesDAO;
import pt.iconic.ipst.dao.MecanismoMorteDAO;
import pt.iconic.ipst.dao.MicrobiologiaDAO;
import pt.iconic.ipst.dao.OrgaosOfertaDAO;
import pt.iconic.ipst.dao.PatologiaBroncoescopiaDAO;
import pt.iconic.ipst.dao.QuadrantesDAO;
import pt.iconic.ipst.dao.RadiografiaDAO;
import pt.iconic.ipst.dao.TerapeuticasDAO;
import pt.iconic.ipst.dao.TipoMicroorganismoDAO;
import pt.iconic.ipst.dao.TransfusoesDAO;
import pt.iconic.ipst.dao.TransporteEquipaDAO;
import pt.iconic.ipst.dao.UtilizadorDAO;
import pt.iconic.ipst.dao.VirologiaDAO;
import pt.iconic.ipst.modelo.AnaliseDador;
import pt.iconic.ipst.modelo.AssignacaoHospital;
import pt.iconic.ipst.modelo.AssignacaoOrgaos;
import pt.iconic.ipst.modelo.BDOrgaos;
import pt.iconic.ipst.modelo.ColheitaCoracao;
import pt.iconic.ipst.modelo.ColheitaFigado;
import pt.iconic.ipst.modelo.ColheitaPancreas;
import pt.iconic.ipst.modelo.ColheitaPulmoes;
import pt.iconic.ipst.modelo.ColheitaRins;
import pt.iconic.ipst.modelo.Dador;
import pt.iconic.ipst.modelo.EquipaCirurgia;
import pt.iconic.ipst.modelo.EquipaCirurgiaTransplante;
import pt.iconic.ipst.modelo.EquipaLocal;
import pt.iconic.ipst.modelo.EquipaLocalTransplante;
import pt.iconic.ipst.modelo.EquipaSuporte;
import pt.iconic.ipst.modelo.EquipaSuporteTransplante;
import pt.iconic.ipst.modelo.HistoricoAssignacao;
import pt.iconic.ipst.modelo.Hospital;
import pt.iconic.ipst.modelo.OrgaosOferta;
import pt.iconic.ipst.modelo.Quadrantes;
import pt.iconic.ipst.modelo.StatusAssignacaoHospital;
import pt.iconic.ipst.modelo.StatusAssignacaoOrgaos;
import pt.iconic.ipst.modelo.TransporteEquipa;
import pt.iconic.ipst.modelo.Utilizador;
import pt.iconic.ipst.modelo.Virologia;


@Controller
public class OfertasController 
{
	private DadorDAO daoDador;
	private BDOrgaosDAO daobdorg;
	private AssignacaoOrgaosDAO daoAssigOrg;
	private AssignacaoHospitalDAO daoAssighosp;
	private HospitalDAO daohosp;
	private HistoricoAssignacaoDAO daohistorico;
	private GlasgowCommaDAO daoglasg;
	private CausaMorteDAO daocausamorte;
	private MecanismoMorteDAO daomecmorte;
	private EtniaDAO daoetnia;
	private DadorDetalhesDAO daodaddet;
	private BDAvaliacaoInicialDAO daobdavalinicial;
	private AnaliseDadorDAO daoanalisedador;
	private HCExameFisicoDAO daoexamefisico;
	private QuadrantesDAO daoquadrantes;
	private HCGeralDAO daogeral;
	private HCDoencasPreExistentesDAO daodoencaspreex;
	private HCSituacoesRiscoDAO daositrisco;
	private GrupoSanguineoDAO daogrupsang;
	private AmostrasFuncoesOrgaoDAO daoamostrasfo;
	private AmostrasFODAO daoamostrasmestre;
	private FuncoesOrgaoDAO daofuncaorgao;
	private MBAnalisesDAO daombanalises;
	private TipoMicroorganismoDAO daotipoorg;
	private ImunologiaDAO daoimuno;
	private VirologiaDAO daoviro;
	private GasVentDAO daogasvent;
	private EletrocardiogramaDAO daoeletro;
	private DadosCoronografiaDAO daodadoscoronografia;
	private LesoesRadiografiaDAO daolesaorx;
	private EcotoraxicoDAO daotora;
	private EcofigadoDAO daofigado;
	private RadiografiaDAO daorx;
	private EcopancreasDAO daopancreas;
	private CoronografiaDAO daocorona;
	private BroncoescopiaDAO daobronco;
	private EcorinsDAO daorins;
	private DadosAbdFigadoDAO daolesaofigado;
	private DadosAbdRinsDAO daolesaorins;
	private DadosAbdPancreasDAO daolesaopancreas;
	private PatologiaBroncoescopiaDAO daopatbronco;
	private TransfusoesDAO daotransf;
	private TerapeuticasDAO daoterap;
	private EquipaLocalDAO daoequipalocal;
	private EquipaCirurgiaDAO daoequipacirurgia;
	private UtilizadorDAO daouser;
	private EquipaSuporteDAO daoequipsuporte;
	private TransporteEquipaDAO daotranspequipa;
	private EquipaLocalTransplanteDAO daoequipalocaltransplante;
	private EquipaCirurgiaTransplanteDAO daoequipacirurgiatransplante;
	private EquipaSuporteTransplanteDAO daoequipasuportetransplante;
	private BiopsiaRenalDAO daobiorenal;
	private BiopsiarenalItensDAO daobiorenalitens;
	private BiopsiaHepaticaDAO daobiohepatica;
	private MicrobiologiaDAO daomicro;
	private ColheitaFigadoDAO daocolheitafigado;
	private ColheitaCoracaoDAO daocolheitacoracao;
	private ColheitaRinsDAO daocolheitarins;
	private ColheitaPulmoesDAO daocolheitapulmoes;
	private ColheitaPancreasDAO daocolheitapancreas;
	private ColheitaPancreasPerfusaoDAO daocolheitaperfpancreas;
	private ColheitaPancreasProdutoDAO daocolheitapancreasprod;
	private ColheitaFigadoPerfusaoDAO daocolheitaperffigado;
	private ColheitaPulmoesTratamentoDAO daocolheitapulmoestrat;
	private ColheitaRinsPerfusaoDAO daocolheitaperfrins;
	private ColheitaRinsTerapeuticasDAO daocolheitarinsterap;
	private OrgaosOfertaDAO daoorgaooferta;
	
	@Autowired
	public OfertasController(DadorDAO daoDador, BDOrgaosDAO daobdorg, AssignacaoOrgaosDAO daoAssigOrg, AssignacaoHospitalDAO daoAssighosp, HospitalDAO daohosp,
			HistoricoAssignacaoDAO daohistorico, GlasgowCommaDAO daoglasg, CausaMorteDAO daocausamorte, MecanismoMorteDAO daomecmorte, EtniaDAO daoetnia , DadorDetalhesDAO daodaddet,
			BDAvaliacaoInicialDAO daobdavalinicial, AnaliseDadorDAO daoanalisedador, HCExameFisicoDAO daoexamefisico , QuadrantesDAO daoquadrantes, HCGeralDAO daogeral,
			HCDoencasPreExistentesDAO daodoencaspreex, HCSituacoesRiscoDAO daositrisco, GrupoSanguineoDAO daogrupsang, AmostrasFuncoesOrgaoDAO daoamostrasfo,
			AmostrasFODAO daoamostrasmestre, FuncoesOrgaoDAO daofuncaorgao, MBAnalisesDAO daombanalises, TipoMicroorganismoDAO daotipoorg,
			ImunologiaDAO daoimuno, VirologiaDAO daoviro, GasVentDAO daogasvent, EletrocardiogramaDAO daoeletro, DadosCoronografiaDAO daodadoscoronografia, LesoesRadiografiaDAO daolesaorx,
			EcotoraxicoDAO daotora, EcofigadoDAO daofigado, RadiografiaDAO daorx, EcopancreasDAO daopancreas, CoronografiaDAO daocorona, BroncoescopiaDAO daobronco, EcorinsDAO daorins,
			DadosAbdFigadoDAO daolesaofigado, DadosAbdRinsDAO daolesaorins, DadosAbdPancreasDAO daolesaopancreas, PatologiaBroncoescopiaDAO daopatbronco, TransfusoesDAO daotransf,
			TerapeuticasDAO daoterap, EquipaLocalDAO daoequipalocal, EquipaCirurgiaDAO daoequipacirurgia, UtilizadorDAO daouser, EquipaSuporteDAO daoequipsuporte, TransporteEquipaDAO daotranspequipa,
			EquipaLocalTransplanteDAO daoequipalocaltransplante, EquipaCirurgiaTransplanteDAO daoequipacirurgiatransplante, EquipaSuporteTransplanteDAO daoequipasuportetransplante,
			BiopsiaRenalDAO daobiorenal, BiopsiarenalItensDAO daobiorenalitens, BiopsiaHepaticaDAO daobiohepatica, MicrobiologiaDAO daomicro, ColheitaFigadoDAO daocolheitafigado,
			ColheitaCoracaoDAO daocolheitacoracao, ColheitaRinsDAO daocolheitarins, ColheitaPulmoesDAO daocolheitapulmoes, ColheitaPancreasDAO daocolheitapancreas,
			ColheitaPancreasPerfusaoDAO daocolheitaperfpancreas, ColheitaPancreasProdutoDAO daocolheitapancreasprod, ColheitaFigadoPerfusaoDAO daocolheitaperffigado,
			ColheitaPulmoesTratamentoDAO daocolheitapulmoestrat, ColheitaRinsPerfusaoDAO daocolheitaperfrins, ColheitaRinsTerapeuticasDAO daocolheitarinsterap
			,OrgaosOfertaDAO daoorgaooferta)
	{
		this.daoDador = daoDador;
		this.daobdorg = daobdorg;
		this.daoAssigOrg = daoAssigOrg;
		this.daoAssighosp = daoAssighosp;
		this.daohosp = daohosp;
		this.daohistorico = daohistorico;
		this.daoglasg = daoglasg;
		this.daocausamorte = daocausamorte;
		this.daomecmorte = daomecmorte;
		this.daoetnia = daoetnia;
		this.daodaddet = daodaddet;
		this.daobdavalinicial = daobdavalinicial;
		this.daoanalisedador = daoanalisedador;
		this.daoexamefisico = daoexamefisico;
		this.daoquadrantes = daoquadrantes;
		this.daogeral = daogeral;
		this.daodoencaspreex = daodoencaspreex;
		this.daositrisco = daositrisco;
		this.daogrupsang = daogrupsang;
		this.daoamostrasfo = daoamostrasfo;
		this.daoamostrasmestre = daoamostrasmestre;
		this.daofuncaorgao = daofuncaorgao;
		this.daombanalises = daombanalises;
		this.daotipoorg = daotipoorg;
		this.daoimuno = daoimuno;
		this.daoviro = daoviro;
		this.daogasvent = daogasvent;
		this.daoeletro = daoeletro;
		this.daodadoscoronografia = daodadoscoronografia;
		this.daolesaorx = daolesaorx;
		this.daotora = daotora;
		this.daofigado = daofigado;
		this.daorx = daorx;
		this.daopancreas = daopancreas;
		this.daocorona = daocorona;
		this.daobronco = daobronco;
		this.daorins = daorins;
		this.daolesaofigado = daolesaofigado;
		this.daolesaorins = daolesaorins;
		this.daolesaopancreas= daolesaopancreas;
		this.daopatbronco = daopatbronco;
		this.daotransf = daotransf;
		this.daoterap = daoterap;
		this.daoequipalocal = daoequipalocal;
		this.daoequipacirurgia = daoequipacirurgia;
		this.daouser = daouser;
		this.daoequipsuporte = daoequipsuporte;
		this.daotranspequipa = daotranspequipa;
		this.daoequipalocaltransplante= daoequipalocaltransplante; 
		this.daoequipacirurgiatransplante = daoequipacirurgiatransplante;
		this.daoequipasuportetransplante = daoequipasuportetransplante;
		this.daobiorenal = daobiorenal;
		this.daobiorenalitens = daobiorenalitens;
		this.daobiohepatica = daobiohepatica;
		this.daomicro = daomicro;
		this.daocolheitafigado = daocolheitafigado;
		this.daocolheitacoracao = daocolheitacoracao;
		this.daocolheitarins = daocolheitarins;
		this.daocolheitapulmoes = daocolheitapulmoes;
		this.daocolheitapancreas = daocolheitapancreas;
		this.daocolheitaperfpancreas = daocolheitaperfpancreas;
		this.daocolheitapancreasprod = daocolheitapancreasprod;
		this.daocolheitaperffigado = daocolheitaperffigado;
		this.daocolheitapulmoestrat = daocolheitapulmoestrat;
		this.daocolheitaperfrins = daocolheitaperfrins;
		this.daocolheitarinsterap = daocolheitarinsterap;
		this.daoorgaooferta = daoorgaooferta;
	}
	
	@RequestMapping(value = "abreofertaorgao", method = RequestMethod.POST)
	public String abreavaliacaocoord(@RequestParam("iddador") Long iddador, @RequestParam("idanalise") Long idanalise, Model model, HttpSession session)
	{
		
		Dador dador = daoDador.buscaPorId(iddador);
		
		AnaliseDador analise = daoanalisedador.buscaAnaliseDoDador(dador.getId_Dador());
		session.setAttribute("id_analise", analise.getId_AnaliseDador());
		session.setAttribute("leituraescrita", false);
		
		
		//coloca em sessao o dador
		session.setAttribute("dadororgao", dador);
		
		BDOrgaos orgaos = daobdorg.buscabdorgaosdaavaliacao(idanalise);
		//alterar para ir buscar org�os da assigna��o de org�os criada quando clicou no dador, j� com os org�os disponiveis desse dador
		// cada vez que abrir a assigna��o desse dador atualizar os org�os disponiveis e fazer ajustes necess�rios nas ofertas, etc.. cancelar se dador j� n�o oferece org�o, etc..
		model.addAttribute("bdorgaos", orgaos);		
		
		//se j� existe Assigna��o para os org�os desse dador
		if(daoDador.verificaexisteassignacao(iddador)){
			
/////////////////verificar se houve altera��o nos org�os
			//System.out.println("Assigna��o Existente");
			StatusAssignacaoOrgaos status = new StatusAssignacaoOrgaos();
			status.setIdstatus(1);
			
			OrgaosOferta orgaooferta = new OrgaosOferta();
			
			if(orgaos.isCoracao() && (daoAssigOrg.buscaassignacaoorgaodador(dador.getId_Dador(), 1)==null)){
				AssignacaoOrgaos ass1 = new AssignacaoOrgaos();
				//inserir orgao cora��o para assigna��o neste dador
				ass1.setDadoroferta(dador);
				orgaooferta.setIdorgoferta(1);
				ass1.setOrgoferta(orgaooferta);
				ass1.setStatusassignacao(status);
				daoAssigOrg.adiciona(ass1);
			}
			if(orgaos.isFigado() && (daoAssigOrg.buscaassignacaoorgaodador(dador.getId_Dador(), 2)==null)){
				//inserir orgao figado para assigna��o neste dador
				AssignacaoOrgaos ass1 = new AssignacaoOrgaos();
				ass1.setDadoroferta(dador);
				orgaooferta.setIdorgoferta(2);
				ass1.setOrgoferta(orgaooferta);
				ass1.setStatusassignacao(status);
				daoAssigOrg.adiciona(ass1);
			}
			if(orgaos.isPulmoes() && (daoAssigOrg.buscaassignacaoorgaodador(dador.getId_Dador(), 3)==null)){
				//inserir orgao pulmoes para assigna��o neste dador
				AssignacaoOrgaos ass1 = new AssignacaoOrgaos();
				ass1.setDadoroferta(dador);
				orgaooferta.setIdorgoferta(3);
				ass1.setOrgoferta(orgaooferta);
				ass1.setStatusassignacao(status);
				daoAssigOrg.adiciona(ass1);
			}
			if(orgaos.isPulmaoEsq() && (daoAssigOrg.buscaassignacaoorgaodador(dador.getId_Dador(), 4)==null)){
				//inserir orgao pulmao esquerdo para assigna��o neste dador
				AssignacaoOrgaos ass1 = new AssignacaoOrgaos();
				ass1.setDadoroferta(dador);
				orgaooferta.setIdorgoferta(4);
				ass1.setOrgoferta(orgaooferta);
				ass1.setStatusassignacao(status);
				daoAssigOrg.adiciona(ass1);
			}
			if(orgaos.isPulmaoDir() && (daoAssigOrg.buscaassignacaoorgaodador(dador.getId_Dador(), 5)==null)){
				//inserir orgao pulmao direito para assigna��o neste dador
				AssignacaoOrgaos ass1 = new AssignacaoOrgaos();
				ass1.setDadoroferta(dador);
				orgaooferta.setIdorgoferta(5);
				ass1.setOrgoferta(orgaooferta);
				ass1.setStatusassignacao(status);
				daoAssigOrg.adiciona(ass1);
			}
			if(orgaos.isPancreas() && (daoAssigOrg.buscaassignacaoorgaodador(dador.getId_Dador(), 6)==null)){
				//inserir orgao pancreas para assigna��o neste dador
				AssignacaoOrgaos ass1 = new AssignacaoOrgaos();
				ass1.setDadoroferta(dador);
				orgaooferta.setIdorgoferta(6);
				ass1.setOrgoferta(orgaooferta);
				ass1.setStatusassignacao(status);
				daoAssigOrg.adiciona(ass1);
			}
			if(orgaos.isRimpar() && (daoAssigOrg.buscaassignacaoorgaodador(dador.getId_Dador(), 7)==null)){
				//inserir orgao rim par para assigna��o neste dador
				AssignacaoOrgaos ass1 = new AssignacaoOrgaos();
				ass1.setDadoroferta(dador);
				orgaooferta.setIdorgoferta(7);
				ass1.setOrgoferta(orgaooferta);
				ass1.setStatusassignacao(status);
				daoAssigOrg.adiciona(ass1);
			}
			if(orgaos.isRimEsquerdo() && (daoAssigOrg.buscaassignacaoorgaodador(dador.getId_Dador(), 8)==null)){
				//inserir orgao rim esquerdo para assigna��o neste dador
				AssignacaoOrgaos ass1 = new AssignacaoOrgaos();
				ass1.setDadoroferta(dador);
				orgaooferta.setIdorgoferta(8);
				ass1.setOrgoferta(orgaooferta);
				ass1.setStatusassignacao(status);
				daoAssigOrg.adiciona(ass1);
			}
			if(orgaos.isRimDireito() && (daoAssigOrg.buscaassignacaoorgaodador(dador.getId_Dador(), 9)==null)){
				//inserir orgao rim direito para assigna��o neste dador
				AssignacaoOrgaos ass1 = new AssignacaoOrgaos();
				ass1.setDadoroferta(dador);
				orgaooferta.setIdorgoferta(9);
				ass1.setOrgoferta(orgaooferta);
				ass1.setStatusassignacao(status);
				daoAssigOrg.adiciona(ass1);
			}
			if(orgaos.isCorneas() && (daoAssigOrg.buscaassignacaoorgaodador(dador.getId_Dador(), 10)==null)){
				//inserir orgao rim direito para assigna��o neste dador
				AssignacaoOrgaos ass1 = new AssignacaoOrgaos();
				ass1.setDadoroferta(dador);
				orgaooferta.setIdorgoferta(10);
				ass1.setOrgoferta(orgaooferta);
				ass1.setStatusassignacao(status);
				daoAssigOrg.adiciona(ass1);
			}
			if(orgaos.isTme() && (daoAssigOrg.buscaassignacaoorgaodador(dador.getId_Dador(), 11)==null)){
				//inserir orgao rim direito para assigna��o neste dador
				AssignacaoOrgaos ass1 = new AssignacaoOrgaos();
				ass1.setDadoroferta(dador);
				orgaooferta.setIdorgoferta(11);
				ass1.setOrgoferta(orgaooferta);
				ass1.setStatusassignacao(status);
				daoAssigOrg.adiciona(ass1);
			}
			if(orgaos.isTc() && (daoAssigOrg.buscaassignacaoorgaodador(dador.getId_Dador(), 12)==null)){
				//inserir orgao rim direito para assigna��o neste dador
				AssignacaoOrgaos ass1 = new AssignacaoOrgaos();
				ass1.setDadoroferta(dador);
				orgaooferta.setIdorgoferta(12);
				ass1.setOrgoferta(orgaooferta);
				ass1.setStatusassignacao(status);
				daoAssigOrg.adiciona(ass1);
			}
			if(orgaos.isVasos() && (daoAssigOrg.buscaassignacaoorgaodador(dador.getId_Dador(), 13)==null)){
				//inserir orgao rim direito para assigna��o neste dador
				AssignacaoOrgaos ass1 = new AssignacaoOrgaos();
				ass1.setDadoroferta(dador);
				orgaooferta.setIdorgoferta(13);
				ass1.setOrgoferta(orgaooferta);
				ass1.setStatusassignacao(status);
				daoAssigOrg.adiciona(ass1);
			}
			if(orgaos.isTecidos() && (daoAssigOrg.buscaassignacaoorgaodador(dador.getId_Dador(), 14)==null)){
				//inserir orgao rim direito para assigna��o neste dador
				AssignacaoOrgaos ass1 = new AssignacaoOrgaos();
				ass1.setDadoroferta(dador);
				orgaooferta.setIdorgoferta(14);
				ass1.setOrgoferta(orgaooferta);
				ass1.setStatusassignacao(status);
				daoAssigOrg.adiciona(ass1);
			}
			
			
			
			
////////////////////////////			
			
			
			
			//lista assigna��es dos org�os do dador
			model.addAttribute("assignacao", daoAssigOrg.ListaAssignacaoOrgaosDadorAtrib(iddador));
			
			
		}else{
			
			//System.out.println("Nova Assigna��o");
			
			
		//Se n�o existe assigna��o, criar para org�os do dador	
		
			//criar equipa local para esse dador
			
			if(daoequipalocal.buscaequipalocal(iddador)==null){
			EquipaLocal el = new EquipaLocal();
			el.setDador(dador);
			Hospital hospital = new Hospital();
			hospital.setId_Hospital((Long)session.getAttribute("idlocalizacao"));
			el.setHospital(hospital);
			daoequipalocal.adiciona(el);
			}
			
			
			//definir o dador para a assigna��o de org�o

			//definir o status como n�o atribuido
			StatusAssignacaoOrgaos status = new StatusAssignacaoOrgaos();
			status.setIdstatus(1);
			
			OrgaosOferta orgaooferta = new OrgaosOferta();
			
			//verificar org�os do dador e introduzir para assigna��o de orgaos com status 1 (Por assignar)
			if(orgaos.isCoracao()){
				AssignacaoOrgaos ass1 = new AssignacaoOrgaos();
				//inserir orgao cora��o para assigna��o neste dador
				ass1.setDadoroferta(dador);
				orgaooferta.setIdorgoferta(1);
				ass1.setOrgoferta(orgaooferta);
				ass1.setStatusassignacao(status);
				daoAssigOrg.adiciona(ass1);
			}
			if(orgaos.isFigado()){
				//inserir orgao cora��o para assigna��o neste dador
				AssignacaoOrgaos ass1 = new AssignacaoOrgaos();
				ass1.setDadoroferta(dador);
				orgaooferta.setIdorgoferta(2);
				ass1.setOrgoferta(orgaooferta);
				ass1.setStatusassignacao(status);
				daoAssigOrg.adiciona(ass1);
			}
			if(orgaos.isPulmoes()){
				//inserir orgao cora��o para assigna��o neste dador
				AssignacaoOrgaos ass1 = new AssignacaoOrgaos();
				ass1.setDadoroferta(dador);
				orgaooferta.setIdorgoferta(3);
				ass1.setOrgoferta(orgaooferta);
				ass1.setStatusassignacao(status);
				daoAssigOrg.adiciona(ass1);
			}
			if(orgaos.isPulmaoEsq()){
				//inserir orgao cora��o para assigna��o neste dador
				AssignacaoOrgaos ass1 = new AssignacaoOrgaos();
				ass1.setDadoroferta(dador);
				orgaooferta.setIdorgoferta(4);
				ass1.setOrgoferta(orgaooferta);
				ass1.setStatusassignacao(status);
				daoAssigOrg.adiciona(ass1);
			}
			if(orgaos.isPulmaoDir()){
				//inserir orgao cora��o para assigna��o neste dador
				AssignacaoOrgaos ass1 = new AssignacaoOrgaos();
				ass1.setDadoroferta(dador);
				orgaooferta.setIdorgoferta(5);
				ass1.setOrgoferta(orgaooferta);
				ass1.setStatusassignacao(status);
				daoAssigOrg.adiciona(ass1);
			}
			if(orgaos.isPancreas()){
				//inserir orgao cora��o para assigna��o neste dador
				AssignacaoOrgaos ass1 = new AssignacaoOrgaos();
				ass1.setDadoroferta(dador);
				orgaooferta.setIdorgoferta(6);
				ass1.setOrgoferta(orgaooferta);
				ass1.setStatusassignacao(status);
				daoAssigOrg.adiciona(ass1);
			}
			if(orgaos.isRimpar()){
				//inserir orgao cora��o para assigna��o neste dador
				AssignacaoOrgaos ass1 = new AssignacaoOrgaos();
				ass1.setDadoroferta(dador);
				orgaooferta.setIdorgoferta(7);
				ass1.setOrgoferta(orgaooferta);
				ass1.setStatusassignacao(status);
				daoAssigOrg.adiciona(ass1);
			}
			if(orgaos.isRimEsquerdo()){
				//inserir orgao cora��o para assigna��o neste dador
				AssignacaoOrgaos ass1 = new AssignacaoOrgaos();
				ass1.setDadoroferta(dador);
				orgaooferta.setIdorgoferta(8);
				ass1.setOrgoferta(orgaooferta);
				ass1.setStatusassignacao(status);
				daoAssigOrg.adiciona(ass1);
			}
			if(orgaos.isRimDireito()){
				//inserir orgao cora��o para assigna��o neste dador
				AssignacaoOrgaos ass1 = new AssignacaoOrgaos();
				ass1.setDadoroferta(dador);
				orgaooferta.setIdorgoferta(9);
				ass1.setOrgoferta(orgaooferta);
				ass1.setStatusassignacao(status);
				daoAssigOrg.adiciona(ass1);
			}
			if(orgaos.isCorneas()){
				//inserir orgao cora��o para assigna��o neste dador
				AssignacaoOrgaos ass1 = new AssignacaoOrgaos();
				ass1.setDadoroferta(dador);
				orgaooferta.setIdorgoferta(10);
				ass1.setOrgoferta(orgaooferta);
				ass1.setStatusassignacao(status);
				daoAssigOrg.adiciona(ass1);
			}
			if(orgaos.isTme()){
				//inserir orgao cora��o para assigna��o neste dador
				AssignacaoOrgaos ass1 = new AssignacaoOrgaos();
				ass1.setDadoroferta(dador);
				orgaooferta.setIdorgoferta(11);
				ass1.setOrgoferta(orgaooferta);
				ass1.setStatusassignacao(status);
				daoAssigOrg.adiciona(ass1);
			}
			if(orgaos.isTc()){
				//inserir orgao cora��o para assigna��o neste dador
				AssignacaoOrgaos ass1 = new AssignacaoOrgaos();
				ass1.setDadoroferta(dador);
				orgaooferta.setIdorgoferta(12);
				ass1.setOrgoferta(orgaooferta);
				ass1.setStatusassignacao(status);
				daoAssigOrg.adiciona(ass1);
			}
			if(orgaos.isVasos()){
				//inserir orgao cora��o para assigna��o neste dador
				AssignacaoOrgaos ass1 = new AssignacaoOrgaos();
				ass1.setDadoroferta(dador);
				orgaooferta.setIdorgoferta(13);
				ass1.setOrgoferta(orgaooferta);
				ass1.setStatusassignacao(status);
				daoAssigOrg.adiciona(ass1);
			}
			if(orgaos.isTecidos()){
				//inserir orgao cora��o para assigna��o neste dador
				AssignacaoOrgaos ass1 = new AssignacaoOrgaos();
				ass1.setDadoroferta(dador);
				orgaooferta.setIdorgoferta(14);
				ass1.setOrgoferta(orgaooferta);
				ass1.setStatusassignacao(status);
				daoAssigOrg.adiciona(ass1);
			}
			
		//assim fica estado do org�o no sem�foro e � para ficar estado da atribui��o ao hospital	
			model.addAttribute("assignacao", daoAssigOrg.ListaAssignacaoOrgaosDadorAtrib(iddador));
			
		//	model.addAttribute("assignacao", daoAssighosp.
		}


		model.addAttribute("Dador", dador);
		model.addAttribute("historico", daohistorico.ListaHistoricoAssignacaoDador(dador.getId_Dador()));
		return "gcct/divatribuicaodetalhe";
	}
	
	@RequestMapping(value="carregaseparadordador")
	public String carregaseparadordador(Model model, HttpSession session){
		
		Dador dador = (Dador)session.getAttribute("dadororgao");
		
		Long id_analise = (Long)session.getAttribute("id_analise");
		
		model.addAttribute("leituraescrita",false);
		
		model.addAttribute("dador", dador);
		model.addAttribute("glasgowcomma", daoglasg.ListaGlasgowComma());
		model.addAttribute("causademorte", daocausamorte.ListaCausaMorte());
		model.addAttribute("mecanismomorte", daomecmorte.ListaMecanismoMorte());
		BDOrgaos orgaos = daobdorg.buscabdorgaosdaavaliacao(id_analise);
		model.addAttribute("bdorgaos", orgaos);
		model.addAttribute("dadordetalhe", daodaddet.buscadetalhesdador(dador.getId_Dador()));
		model.addAttribute("bdavalinicial", daobdavalinicial.buscaavaliacaoinicial(id_analise));
		model.addAttribute("examefisico", daoexamefisico.buscaexamefisico(id_analise));
		Quadrantes quad = daoquadrantes.buscaquadrantesanalise(id_analise);
		model.addAttribute("quadrantes", quad);
		model.addAttribute("etnia", daoetnia.ListaEtnia());
		model.addAttribute("hcgeral", daogeral.buscageralanalise(id_analise));
		model.addAttribute("doencas", daodoencaspreex.buscaDoencasPreExistentesAvaliacao(id_analise));	
		model.addAttribute("sitrisco", daositrisco.buscaSituacoesRiscoAvaliacao(id_analise));
		
		return "gcct/divseparadordador";
	}
	
	
	@RequestMapping(value="carregaseparadorexames")
	public String carregaseparadorexames(Model model, HttpSession session){
		
		Dador dador = (Dador)session.getAttribute("dadororgao");
		
		Long id_analise = (Long)session.getAttribute("id_analise");
		
		model.addAttribute("leituraescrita",false);
		
		//ECG
		model.addAttribute("ecgcoddador", dador);
		model.addAttribute("dadosgeraiseletrocardiograma", daoeletro.ListaEletrocardiograma(id_analise));

		//Coronografia
		model.addAttribute("coronografiacoddador", dador);
		model.addAttribute("dadoscoronografia", daocorona.ListaCoronografia(id_analise));
		model.addAttribute("dadoslesoescoronografia", daodadoscoronografia.buscalesoesDescendente(id_analise));
		
		//RX/TAC
		model.addAttribute("rxcoddador", dador);
		model.addAttribute("lesoes", daolesaorx.buscalesoesDescendente(id_analise));
		model.addAttribute("dadosradiografia", daorx.ListaRadiografia(id_analise));
		
		//Ecocardiograma
		model.addAttribute("toraxicocoddador", dador);
		model.addAttribute("dadosecotoraxico", daotora.ListaEcoToraxico(id_analise));
		
		//Eco Abdominal Figado
		model.addAttribute("dadosecofigado", daofigado.ListaEcoAbdFigado(id_analise));
		model.addAttribute("lesoesfigado", daolesaofigado.buscalesoesDescendente(id_analise));
		
		//Eco Abdominal Rins
		model.addAttribute("dadosrins", daorins.ListaEcoAbdFigado(id_analise));
		model.addAttribute("lesoesrins", daolesaorins.buscalesoesDescendente(id_analise));
		
		//Eco Abdominal Pancreas
		model.addAttribute("dadosecopancreas", daopancreas.ListaEcoPancreas(id_analise));
		model.addAttribute("lesoespancreas", daolesaopancreas.buscalesoesDescendente(id_analise));
		
		//Broncoescopia
		model.addAttribute("dadosbroncoescopia", daobronco.ListaBroncoescopia(id_analise));
		model.addAttribute("dadospatologiabronco", daopatbronco.buscalesoesDescendente(id_analise));		
		
		//Biopsia Renal
		model.addAttribute("biorenal", daobiorenal.buscabiopsiarenalanalise(id_analise));
		model.addAttribute("biorenalitens",daobiorenalitens.buscabiopsiarenalitensanalise(id_analise));
		
		//Biopsia Hepatica
		model.addAttribute("biohepatica", daobiohepatica.buscabiopsiahepaticaanalise(id_analise));
		
		return "gcct/divseparadorexames";
	}
	
	@RequestMapping(value="carregaseparadoranalises")
	public String carregaseparadoranalises(Model model, HttpSession session){
		
		Long id_analise = (Long)session.getAttribute("id_analise");
		
		model.addAttribute("leituraescrita",false);
		//grupo sanguineo
		model.addAttribute("gs", daogrupsang.buscaGrupoSanguineoAnalise(id_analise));
		//funcoes orgao
		model.addAttribute("amostras", daoamostrasfo.buscaamostrasanaliseDescendente(id_analise));
		model.addAttribute("combamostras", daoamostrasmestre.ListaAmostrasAnalise(id_analise));
		model.addAttribute("funcoesorgao", daofuncaorgao.buscaFuncoesOrgaoAnalise(id_analise));
		//microbiologia
		model.addAttribute("microbio", daomicro.buscaMicrobiologiaAnalise(id_analise));
		model.addAttribute("microbiologia", daombanalises.ListaMBAnalisesAnalise(id_analise));	
		model.addAttribute("tipomicrorganismo", daotipoorg.ListaTipoMicroorganismo());
		//imunologia
		model.addAttribute("imunologia", daoimuno.buscaImunologiaAnalise(id_analise));
		//virologia
		List<Virologia> tabviro = daoviro.buscaVirologiaAnalisePretrans(id_analise);
		model.addAttribute("viro", tabviro);
		
		model.addAttribute("tipoviro", tabviro.get(0));
		//gasimetria e ventila��o
		model.addAttribute("gasventilacao", daogasvent.ListaGasVentAnalise(id_analise));
		return "gcct/divseparadoranalises";
	}
	
	
	@RequestMapping(value="carregaseparadortt")
	public String carregaseparadortt(Model model, HttpSession session){
		
		Long id_analise = (Long)session.getAttribute("id_analise");
		Dador dador = (Dador)session.getAttribute("dadororgao");
		
		model.addAttribute("leituraescrita",false);
		
		//transfusoes
		model.addAttribute("amostrashemo", daoamostrasfo.buscatipoamostrasanalisetransfusao(id_analise));
		model.addAttribute("dadortransf", daodaddet.buscapesodador(dador.getId_Dador()));
		model.addAttribute("transf", daotransf.buscatransfusoesanalise(id_analise));	
		
		//terapeuticas
		model.addAttribute("terapeuticas", daoterap.buscaterapeuticasanalise(id_analise));

		return "gcct/divseparadortt";
	}
	
	
	@RequestMapping(value="carregaseparadorequipa")
	public String carregaseparadorequipa(Model model, HttpSession session){
		
//		Long id_analise = (Long)session.getAttribute("id_analise");
		Dador dador = (Dador)session.getAttribute("dadororgao");
		
		
		model.addAttribute("leituraescrita",false);
		model.addAttribute("local",daohosp.ListaHospitais());
		model.addAttribute("el",daoequipalocal.buscaequipalocal(dador.getId_Dador()));
		model.addAttribute("equipacirurgia",daoequipacirurgia.buscaequipacirurgiadador(dador.getId_Dador()));
		model.addAttribute("assignacao", daoAssigOrg.ListaAssignacaoOrgaosDador(dador.getId_Dador()));
		model.addAttribute("cirurgiao", daouser.buscacirurgioes());
		model.addAttribute("equipasuporte",daoequipsuporte.buscaequipacsuportedador(dador.getId_Dador()));
		model.addAttribute("transpequipa",daotranspequipa.buscatranspequipadador(dador.getId_Dador()));
		model.addAttribute("idhospitaluser", session.getAttribute("idlocalizacao"));
		return "gcct/divseparadorequipa";
	}
	
	@RequestMapping(value="abrirhospitaisassignacao", method = RequestMethod.POST)
	public String abrirhospitaisassignacao(@RequestParam("idassignacaoorg") Long idassignacaoorg, @RequestParam("idorgao") int idorgao, Model model) {
		
		Long unidadetransp = 0L;
		if(idorgao==1){
			//cardiaca
			unidadetransp = 1L;
		}else if(idorgao==2){
			//hep�tica
			unidadetransp = 2L;	
		}else if(idorgao==3){
			//hep�tica
			unidadetransp = 3L;	
		}else if(idorgao==4){
			//hep�tica
			unidadetransp = 3L;	
		}
		else if(idorgao==5){
			//hep�tica
			unidadetransp = 3L;	
		}else if(idorgao==6){
			//hep�tica
			unidadetransp = 4L;	
		}else if(idorgao==7){
			//hep�tica
			unidadetransp = 5L;	
		}
		else if(idorgao==8){
			//hep�tica
			unidadetransp = 5L;	
		}
		else{
			//hep�tica
			unidadetransp = 5L;	
		}
		model.addAttribute("assigorghosp", daoAssighosp.listaHospitaisAssignOrgao(idassignacaoorg, unidadetransp));
		
		return "gcct/divhospitaisofertaorgao";
	}
	
	@RequestMapping(value="inserehospitalorgao", method = RequestMethod.POST)
	@ResponseBody
	public String inserehospitalorgao(@RequestParam("idassigorgao") Long idassigorgao , @RequestParam("idhospital") Long idhospital, @RequestParam("valor") boolean valor, HttpSession session){
		
		//System.out.println("idassigorgao : "+idassigorgao+", idhospital: "+idhospital+", valor: "+valor);
		
		AssignacaoHospital ah = new AssignacaoHospital();
		ah.setHospital(daohosp.buscaPorId(idhospital));
		ah.setAssignacaoorgao(daoAssigOrg.buscaPorId(idassigorgao));
		ah.setEscolher(valor);
		StatusAssignacaoHospital estado = new StatusAssignacaoHospital();
		estado.setIdestado(1);
		ah.setEstadoassighosp(estado);
		daoAssighosp.adiciona(ah);
		
		//passar estado assigna��o desse org�o para em an�lise

		AssignacaoOrgaos ao = daoAssigOrg.buscaPorId(idassigorgao);
		if(ao.getStatusassignacao().getIdstatus()!=2 ){
		StatusAssignacaoOrgaos statusassignacao = new StatusAssignacaoOrgaos();
		statusassignacao.setIdstatus(2);
		ao.setStatusassignacao(statusassignacao);
		daoAssigOrg.atualiza(ao);
		}
		//criar hist�rico de adi��o
		
		HistoricoAssignacao hist = new HistoricoAssignacao();
		hist.setAssighosp(ah);
		hist.setDatahistorico(Calendar.getInstance());
		hist.setEstadoassig(estado);
		hist.setDador((Dador)session.getAttribute("dadororgao"));
		daohistorico.adiciona(hist);
		
		
		
		
		//retornar id inserido da assigna��o hospital:
		return ""+ah.getId_assignacaohospital();
	}
	
	
	@RequestMapping(value="atualizahospitalorgao", method = RequestMethod.POST)
	@ResponseBody
	public String atualizahospitalorgao(@RequestParam("idassighosp") Long idassighosp , @RequestParam("idassigorgao") Long idassigorgao , @RequestParam("idhospital") Long idhospital, 
			@RequestParam("valor") boolean valor, HttpSession session){
		
		AssignacaoHospital ah = daoAssighosp.buscaPorId(idassighosp);
		ah.setEscolher(valor);
		
		StatusAssignacaoHospital estado = new StatusAssignacaoHospital();
		if(valor){

		estado.setIdestado(1);

		}
		else{
			estado.setIdestado(5);	
		}
		ah.setEstadoassighosp(estado);
		daoAssighosp.atualiza(ah);
		
		AssignacaoOrgaos ao = daoAssigOrg.buscaPorId(idassigorgao);
		if(ao.getStatusassignacao().getIdstatus()!=2 && valor){
		StatusAssignacaoOrgaos statusassignacao = new StatusAssignacaoOrgaos();
		statusassignacao.setIdstatus(2);
		ao.setStatusassignacao(statusassignacao);
		daoAssigOrg.atualiza(ao);
		}
		
		//criar hist�rico
		
		HistoricoAssignacao hist = new HistoricoAssignacao();
		hist.setAssighosp(ah);
		hist.setDatahistorico(Calendar.getInstance());
		hist.setEstadoassig(estado);
		hist.setDador((Dador)session.getAttribute("dadororgao"));
		daohistorico.adiciona(hist);
		
		//retornar id inserido da assigna��o hospital:
		return ""+ah.getId_assignacaohospital();
	}
	
	@RequestMapping(value="recarregahistorico", method = RequestMethod.POST)
	public String recarregahistorico(Model model, HttpSession session){
		
			
		model.addAttribute("historico", daohistorico.ListaHistoricoAssignacaoDador(((Dador) session.getAttribute("dadororgao")).getId_Dador()));
		return "gcct/divhistoricoassig";
	}
	
	@SuppressWarnings("unchecked")
	@RequestMapping(value="gravarequipalocal", method = RequestMethod.POST)
	@ResponseBody
	public String gravarequipalocal(@RequestParam("idlocal") Long idlocal, @RequestParam("sala") String sala, @RequestParam("data") String data, Model model, HttpSession session) throws ParseException{
		
		Dador dador = (Dador)session.getAttribute("dadororgao");
		//System.out.println("idlocal: "+idlocal+ ", data :"+data+ ", iddador: "+dador.getId_Dador()+ ", sala: "+sala);
		
		DateFormat df = new SimpleDateFormat("dd/MM/yyyy");
/*		Date date = df.parse(data);
		Calendar cal = Calendar.getInstance();
		cal.setTime(date);*/
		
		EquipaLocal el = daoequipalocal.buscaequipalocal(dador.getId_Dador());
		if(el == null){
			el = new EquipaLocal();
			el.setDador(dador);
			if(!data.isEmpty() && data != null){
				Date date = df.parse(data);
				Calendar cal = Calendar.getInstance();
				cal.setTime(date);
				el.setData(cal);
			}else{
				el.setData(null);
			}
			el.setHospital(daohosp.buscaPorId(idlocal));
			el.setSala(sala);
			daoequipalocal.adiciona(el);
		}else{
			if(!data.isEmpty() && data != null){
				Date date = df.parse(data);
				Calendar cal = Calendar.getInstance();
				cal.setTime(date);
				el.setData(cal);
			}else{
				el.setData(null);
			}
			el.setHospital(daohosp.buscaPorId(idlocal));
			el.setSala(sala);
			daoequipalocal.atualiza(el);
		}
		
		
//		notificacao local colheita gravado:

			List<Long> users = daouser.buscausersnotificacaolocalcolheitagravado(idlocal, dador.getId_Dador());
			NotificationsController notificacao = new NotificationsController();
			JSONArray perfis = new JSONArray();
			perfis.add("");
		/*	perfis.add("EC");
			perfis.add("ECC");*/
			String nomehospital = (String)session.getAttribute("localizacao");
			String msg = "Colheita "+dador.getCodigoDador()+" marcada no hospital "+nomehospital+" - Sala "+sala;
			notificacao.envianotificacao(users, 13, perfis, "", msg, dador.getCodigoDador(), 3);
		
		return "true";
	}
	
	@SuppressWarnings("unchecked")
	@RequestMapping(value="gravarequipalocaltransplante", method = RequestMethod.POST)
	@ResponseBody
	public String gravarequipalocaltransplante(@RequestParam("idlocal") Long idlocal, @RequestParam("sala") String sala, @RequestParam("data") String data, Model model, HttpSession session) throws ParseException{
		
		Long id_assigorg = (Long) session.getAttribute("id_assigorgao");
		
		
		DateFormat df = new SimpleDateFormat("dd/MM/yyyy");
		Hospital h = daohosp.buscaPorId(idlocal);
		
		EquipaLocalTransplante el = daoequipalocaltransplante.buscaequipalocaltransplante(id_assigorg);
		if(el == null){
			el = new EquipaLocalTransplante();
			el.setAssigorgao(daoAssigOrg.buscaPorId(id_assigorg));
			if(!data.isEmpty() && data != null){
				Date date = df.parse(data);
				Calendar cal = Calendar.getInstance();
				cal.setTime(date);
				el.setData(cal);
			}else{
				el.setData(null);
			}
			el.setHospital(h);
			el.setSala(sala);
			daoequipalocaltransplante.adiciona(el);
		}else{
			if(!data.isEmpty() && data != null){
				Date date = df.parse(data);
				Calendar cal = Calendar.getInstance();
				cal.setTime(date);
				el.setData(cal);
			}else{
				el.setData(null);
			}
			el.setHospital(h);
			el.setSala(sala);
			daoequipalocaltransplante.atualiza(el);
		}
		
//		notificacao local transplante gravado:
			Dador dador = (Dador)session.getAttribute("dadororgao");
			List<Long> users = daouser.buscausersnotificacaolocaltransplantegravado(idlocal, dador.getId_Dador());
			NotificationsController notificacao = new NotificationsController();
			JSONArray perfis = new JSONArray();
			perfis.add("");
/*			perfis.add("EC");
			perfis.add("ECT");*/
			String msg = "Transplante "+dador.getCodigoDador()+" marcado no hospital "+h.getNomeHospital()+" - Sala "+sala;
			notificacao.envianotificacao(users, 13, perfis, "", msg, dador.getCodigoDador(), 3);
		return "true";
	}
	
	
	@RequestMapping(value="carregadadoscirurgiao" , method = RequestMethod.POST, produces="application/json; charset=UTF-8")
	@ResponseBody
	public String carregadadoscirurgiao(@RequestParam("iduser") Long iduser, Model model){
		
			Utilizador user = daouser.buscadadoscirurgiao(iduser);
			String contato = "";
			if(user.getTelemovel()==null || user.getTelemovel().isEmpty())
			{
				contato = user.getTelefone();
				
			}else{
				contato = user.getTelemovel();
			}
		return "[\""+user.getUtilizador()+"\",\""+contato+"\"]";
	}
		
	
	@SuppressWarnings("unchecked")
	@RequestMapping(value="gravartabelafase", method = RequestMethod.POST)
	public String gravartabelafaseorgao(@RequestParam("fase") Long fase, @RequestParam("hora") String hora, @RequestParam("iduser") Long iduser, @RequestParam("nome") String nome, @RequestParam("om") int om,
			@RequestParam("nummec") String nummec, @RequestParam("contato") int contato, @RequestParam("transporte") String transporte, @RequestParam("principal") boolean principal, Model model, HttpSession session) throws ParseException{
	
		
		
		Dador dador = (Dador)session.getAttribute("dadororgao");
		
		DateFormat df = new SimpleDateFormat("HH:mm");
		Date date = df.parse(hora);
	
		Calendar cal = Calendar.getInstance();
		cal.setTime(date);	
		
		EquipaCirurgia ec = new EquipaCirurgia();		
		ec.setDador(dador);
		ec.setHoraprevista(cal);
		
		if(fase==99){
			ec.setInicio(99);
			daoequipacirurgia.adiciona(ec);
			
			//	notificacao data e hora da colheita gravado:
				DateFormat data = new SimpleDateFormat("dd/MM/yyyy");
				Calendar cal3 = cal;
				Date hora2 = cal3.getTime();
				
				EquipaLocal el = daoequipalocal.buscaequipalocal(dador.getId_Dador());

				List<Long> users = daouser.buscausersnotificacaodatahoradacolheitagravado((Long) session.getAttribute("idlocalizacao"), dador.getId_Dador());
				NotificationsController notificacao = new NotificationsController();
				JSONArray perfis = new JSONArray();
				perfis.add("");
				String msg = "";
				
				if(el.getData() == null){
					msg = "Colheita "+ dador.getCodigoDador()+ " prevista iniciar �s "+df.format(hora2);
				}else{
					msg = "Colheita "+ dador.getCodigoDador()+ " prevista iniciar �s "+df.format(hora2)+ " de "+data.format(el.getData().getTime());
				}
				
				//System.out.println(msg);
				notificacao.envianotificacao(users, 14, perfis, "", msg, dador.getCodigoDador(), 3);
			
			
			
		}else if (fase!=99){
			ec.setAssigorgao(daoAssigOrg.buscaassignacaoorgaodador(dador.getId_Dador(), fase.intValue()));
			ec.setInicio(0);
			ec.setContato(contato);
			ec.setNomecirurgiao(nome);
			ec.setPrincipal(principal);
			ec.setNummecanografico(nummec);
			ec.setOrdem(om);
			ec.setTransporte(transporte);
			ec.setUtilizador(daouser.buscaPorId(iduser));
			
			daoequipacirurgia.adiciona(ec);
			
			
//			notificacao assignado a equipa de colheita:
				//OrgaosOferta orgao = daoorgaooferta.buscaPorId((int)session.getAttribute("orgaodadoroferta"));
				//Hospital h = daohosp.buscaPorId(idhosp);
				//List<Long> users = daouser.buscausersnotificacaoassignadoequipacolheita(idhosp);
			if(iduser != 0){
				JSONArray users = new JSONArray();
				users.add(iduser);
				NotificationsController notificacao = new NotificationsController();
				JSONArray perfis = new JSONArray();
				perfis.add("");
				String msg = "Nova colheita "+ dador.getCodigoDador();
				notificacao.envianotificacao(users, 12, perfis, "", msg, dador.getCodigoDador(), 2);
			}
		}
			
		model.addAttribute("equipacirurgia",daoequipacirurgia.buscaequipacirurgiadador(dador.getId_Dador()));
		
		return "gcct/tabfasehorasequipa";

	}
	
	@SuppressWarnings("unchecked")
	@RequestMapping(value="gravartabelafasetransplante", method = RequestMethod.POST)
	public String gravartabelafasetransplante(@RequestParam("fase") Long fase, @RequestParam("hora") String hora, @RequestParam("iduser") Long iduser, @RequestParam("nome") String nome, @RequestParam("om") int om,
			@RequestParam("nummec") String nummec, @RequestParam("contato") int contato, @RequestParam("transporte") String transporte, @RequestParam("principal") boolean principal, Model model, HttpSession session) throws ParseException{
	
		Long id_assigorg = (Long) session.getAttribute("id_assigorgao");
		
		DateFormat df = new SimpleDateFormat("HH:mm");
		Date date = df.parse(hora);
	
		Calendar cal = Calendar.getInstance();
		cal.setTime(date);	
		
		EquipaCirurgiaTransplante ec = new EquipaCirurgiaTransplante();		
		ec.setAssigorgao(daoAssigOrg.buscaPorId(id_assigorg));
		ec.setHoraprevista(cal);
		
		if(fase==99L){
			ec.setInicio(99L);
			daoequipacirurgiatransplante.adiciona(ec);
			
			//	notificacao data e hora do transplante gravado:
			DateFormat data = new SimpleDateFormat("dd/MM/yyyy");
			Calendar cal3 = cal;
			Date hora2 = cal3.getTime();
			Dador dador = (Dador)session.getAttribute("dadororgao");
			EquipaLocalTransplante elt = daoequipalocaltransplante.buscaequipalocaltransplante(id_assigorg);
			List<Long> users = daouser.buscausersnotificacaodatahoradatransplantegravado(elt.getHospital().getId_Hospital(), dador.getId_Dador());
			NotificationsController notificacao = new NotificationsController();
			JSONArray perfis = new JSONArray();
			perfis.add("");
			String msg = "Transplante "+ dador.getCodigoDador()+ " previsto iniciar �s "+df.format(hora2)+ " de "+data.format(elt.getData().getTime());
			/*System.out.println(elt.getHospital().getId_Hospital());
			System.out.println(msg);*/
			notificacao.envianotificacao(users, 14, perfis, "", msg, dador.getCodigoDador(), 3);
			
		}else if (fase!=99L){
			ec.setAssigorgao(daoAssigOrg.buscaPorId(id_assigorg));
			ec.setInicio(fase);
			ec.setContato(contato);
			ec.setNomecirurgiao(nome);
			ec.setPrincipal(principal);
			ec.setNummecanografico(nummec);
			ec.setOrdem(om);
			ec.setTransporte(transporte);
			ec.setUtilizador(daouser.buscaPorId(iduser));
			
			daoequipacirurgiatransplante.adiciona(ec);
			
//			notificacao assignado a equipa de colheita:
				//OrgaosOferta orgao = daoorgaooferta.buscaPorId((int)session.getAttribute("orgaodadoroferta"));
				//Hospital h = daohosp.buscaPorId(idhosp);
				//List<Long> users = daouser.buscausersnotificacaoassignadoequipacolheita(idhosp);
			if(iduser != 0){
				Dador dador = (Dador)session.getAttribute("dadororgao");
				JSONArray users = new JSONArray();
				users.add(iduser);
				NotificationsController notificacao = new NotificationsController();
				JSONArray perfis = new JSONArray();
				perfis.add("");
				String msg = "Novo transplante "+ dador.getCodigoDador();
				//System.out.println(msg);
				notificacao.envianotificacao(users, 15, perfis, "", msg, dador.getCodigoDador(), 2);
			}
		}
			
		model.addAttribute("equipacirurgia",daoequipacirurgiatransplante.buscaequipacirurgiatransplanteassigorgao(id_assigorg));
		
		return "gcct/tabfasehorasequipa";

	}
	
	
	@RequestMapping(value="eliminaequipacirurgia", method = RequestMethod.POST)
	@ResponseBody
	public void eliminaequipacirurgia(@RequestParam("idequipacirurg") Long idequipacirurg){
		
			daoequipacirurgia.remove(daoequipacirurgia.buscaPorId(idequipacirurg));
	
	}
	
	@RequestMapping(value="eliminaequipacirurgiatransplante", method = RequestMethod.POST)
	@ResponseBody
	public void eliminaequipacirurgiatransplante(@RequestParam("idequipacirurg") Long idequipacirurg){
		
			daoequipacirurgiatransplante.remove(daoequipacirurgiatransplante.buscaPorId(idequipacirurg));
	
	}
	
	
	@RequestMapping(value="atualizatabelafase", method = RequestMethod.POST)
	public String atualizatabelafase(@RequestParam("idequipacirurg")  Long idequipacirurg, @RequestParam("fase") int fase, @RequestParam("hora") String hora, @RequestParam("iduser") Long iduser, @RequestParam("nome") String nome, @RequestParam("om") int om,
			@RequestParam("nummec") String nummec, @RequestParam("contato") int contato, @RequestParam("transporte") String transporte, @RequestParam("principal") boolean principal, Model model, HttpSession session) throws ParseException{
	
		
		Dador dador = (Dador)session.getAttribute("dadororgao");
		
		DateFormat df = new SimpleDateFormat("HH:mm");
		Date date = df.parse(hora);
	
		Calendar cal = Calendar.getInstance();
		cal.setTime(date);	
		
		EquipaCirurgia ec = daoequipacirurgia.buscaPorId(idequipacirurg);	
		
		ec.setHoraprevista(cal);
		
		if(fase==99){
			ec.setInicio(99);
			daoequipacirurgia.atualiza(ec);
			
		}else if (fase!=99){
			AssignacaoOrgaos ao = daoAssigOrg.buscaassignacaoorgaodador(dador.getId_Dador(), fase);
			ec.setAssigorgao(ao);
			ec.setInicio(0);
			ec.setContato(contato);
			ec.setPrincipal(principal);
			ec.setNomecirurgiao(nome);
			ec.setNummecanografico(nummec);
			ec.setOrdem(om);
			ec.setTransporte(transporte);
			ec.setUtilizador(daouser.buscaPorId(iduser));
			
			daoequipacirurgia.atualiza(ec);
		}
			
		model.addAttribute("equipacirurgia",daoequipacirurgia.buscaequipacirurgiadador(dador.getId_Dador()));
		
		return "gcct/tabfasehorasequipa";
	}
	
	@RequestMapping(value="atualizatabelafasetransplante", method = RequestMethod.POST)
	public String atualizatabelafasetransplante(@RequestParam("idequipacirurg")  Long idequipacirurg, @RequestParam("fase") Long fase, @RequestParam("hora") String hora, @RequestParam("iduser") Long iduser, @RequestParam("nome") String nome, @RequestParam("om") int om,
			@RequestParam("nummec") String nummec, @RequestParam("contato") int contato, @RequestParam("transporte") String transporte, @RequestParam("principal") boolean principal, Model model, HttpSession session) throws ParseException{
	
		
	//	Dador dador = (Dador)session.getAttribute("dadororgao");
		
		DateFormat df = new SimpleDateFormat("HH:mm");
		Date date = df.parse(hora);
	
		Calendar cal = Calendar.getInstance();
		cal.setTime(date);	
		
		EquipaCirurgiaTransplante ec = daoequipacirurgiatransplante.buscaPorId(idequipacirurg);	
		Long id_assigorg = (Long) session.getAttribute("id_assigorgao");
		ec.setHoraprevista(cal);
		
		if(fase==0){
			ec.setInicio(0L);
			daoequipacirurgiatransplante.atualiza(ec);
			
		}else if (fase!=99){
			ec.setInicio(fase);
			ec.setContato(contato);
			ec.setNomecirurgiao(nome);
			ec.setPrincipal(principal);
			ec.setNummecanografico(nummec);
			ec.setOrdem(om);
			ec.setTransporte(transporte);
			ec.setUtilizador(daouser.buscaPorId(iduser));
			
			daoequipacirurgiatransplante.atualiza(ec);
		}
			
		model.addAttribute("equipacirurgia",daoequipacirurgiatransplante.buscaequipacirurgiatransplanteassigorgao(id_assigorg));
		
		return "gcct/tabfasehorasequipa";
	}
	
	//----------------------Equipa Suporte Local--------------------------------------///
	
	@RequestMapping(value="regequipasuportelocal", method = RequestMethod.POST)
	public String regequipasuportelocal(EquipaSuporte es, Model model, HttpSession session){
	
		
		Dador dador = (Dador)session.getAttribute("dadororgao");
		es.setDador(dador);
		daoequipsuporte.adiciona(es);
		
		model.addAttribute("equipasuporte",daoequipsuporte.buscaequipacsuportedador(dador.getId_Dador()));
		
		return "gcct/tabequipasuportelocal";
	}
	
	@RequestMapping(value="regequipasuportelocaltransplante", method = RequestMethod.POST)
	public String regequipasuportelocaltransplante(EquipaSuporteTransplante es, Model model, HttpSession session){
	
		Long id_assigorg = (Long) session.getAttribute("id_assigorgao");
	//	Dador dador = (Dador)session.getAttribute("dadororgao");
		es.setAssigorgao(daoAssigOrg.buscaPorId(id_assigorg));
		daoequipasuportetransplante.adiciona(es);
		
		model.addAttribute("equipasuporte",daoequipasuportetransplante.buscaequipacsuportetransplanteassigorgao(id_assigorg));
		
		return "gcct/tabequipasuportelocal";
	}
	
	@RequestMapping(value="atualizaequipasuportelocal", method = RequestMethod.POST)
	public String atualizaequipasuportelocal(EquipaSuporte es, Model model, HttpSession session){
	
		
		Dador dador = (Dador)session.getAttribute("dadororgao");
		
		EquipaSuporte es1 = daoequipsuporte.buscaPorId(es.getIdequipasuporte());
		es1.setContatos(es.getContatos());
		es1.setFuncao(es.getFuncao());
		es1.setNome(es.getNome());
		es1.setOrdem(es.getOrdem());
		daoequipsuporte.atualiza(es1);
		
		model.addAttribute("equipasuporte",daoequipsuporte.buscaequipacsuportedador(dador.getId_Dador()));
		
		return "gcct/tabequipasuportelocal";
	}
	
	@RequestMapping(value="atualizaequipasuportelocaltransplante", method = RequestMethod.POST)
	public String atualizaequipasuportelocaltransplante(EquipaSuporteTransplante es, Model model, HttpSession session){
	
		Long id_assigorg = (Long) session.getAttribute("id_assigorgao");
	//	Dador dador = (Dador)session.getAttribute("dadororgao");
		
		EquipaSuporteTransplante es1 = daoequipasuportetransplante.buscaPorId(es.getIdequipasuporte());
		es1.setContatos(es.getContatos());
		es1.setFuncao(es.getFuncao());
		es1.setNome(es.getNome());
		es1.setOrdem(es.getOrdem());
		daoequipasuportetransplante.atualiza(es1);
		
		model.addAttribute("equipasuporte",daoequipasuportetransplante.buscaequipacsuportetransplanteassigorgao(id_assigorg));
		
		return "gcct/tabequipasuportelocal";
	}
	
	
	@RequestMapping(value="eliminaequipasuportelocal", method = RequestMethod.POST)
	@ResponseBody
	public void eliminaequipasuportelocal(@RequestParam("idequipasuporte") Long idequipasuporte){
		
		daoequipsuporte.remove(daoequipsuporte.buscaPorId(idequipasuporte));
	}
	
	@RequestMapping(value="eliminaequipasuportelocaltransplante", method = RequestMethod.POST)
	@ResponseBody
	public void eliminaequipasuportelocaltransplante(@RequestParam("idequipasuporte") Long idequipasuporte){
		
		daoequipasuportetransplante.remove(daoequipasuportetransplante.buscaPorId(idequipasuporte));
	}
	
	
	//---------------------------TRANSPORTE EQUIPA -----------------------//
	
	
	@RequestMapping(value="regtransporte", method = RequestMethod.POST)
	public String regtransporte(@RequestParam("transportador") String transportador, @RequestParam("assigorgaotransp") Long assigorgaotransp, @RequestParam("contato") String contato, @RequestParam("horaprevista") String horaprevista,
			@RequestParam("destino") String destino, @RequestParam("horatransplante") String horatransplante, Model model, HttpSession session) throws ParseException{
	
	//	System.out.println("assigorgaotransp: "+assigorgaotransp +", transporte: "+transportador+","+contato+","+horaprevista+","+destino+","+horatransplante);
		Dador dador = (Dador)session.getAttribute("dadororgao");
		
		DateFormat df = new SimpleDateFormat("dd/MM/yyyy HH:mm");
		
		TransporteEquipa te = new TransporteEquipa();
		te.setAssigorgao(daoAssigOrg.buscaPorId(assigorgaotransp));
		te.setDador(dador);
		te.setContato(contato);
		te.setDestino(destino);
		Date date = df.parse(horaprevista);
		Calendar cal = Calendar.getInstance();
		cal.setTime(date);
		te.setHoraprevista(cal);
		Date date2 = df.parse(horatransplante);
		Calendar cal2 = Calendar.getInstance();
		cal2.setTime(date2);
		te.setHoratransplante(cal2);
		te.setTransportador(transportador);
		daotranspequipa.adiciona(te);
		
		
		model.addAttribute("transpequipa",daotranspequipa.buscatranspequipadador(dador.getId_Dador()));
		
		return "gcct/tabelatransporte";
	}
	
	
	@RequestMapping(value="atualizatransporte", method = RequestMethod.POST)
	public String atualizatransporte(@RequestParam("transportador") String transportador, @RequestParam("assigorgaotransp") Long assigorgaotransp, @RequestParam("contato") String contato, @RequestParam("horaprevista") String horaprevista,
			@RequestParam("destino") String destino, @RequestParam("horatransplante") String horatransplante, @RequestParam("idtransporte") Long idtransporte,  Model model, HttpSession session) throws ParseException{
	
	//	System.out.println("assigorgaotransp: "+assigorgaotransp +", transporte: "+transportador+","+contato+","+horaprevista+","+destino+","+horatransplante);
		Dador dador = (Dador)session.getAttribute("dadororgao");
		
		//System.out.println("idtransporte: "+idtransporte);
		DateFormat df = new SimpleDateFormat("dd/MM/yyyy HH:mm");
		
		TransporteEquipa te = daotranspequipa.buscaPorId(idtransporte);
		
		te.setAssigorgao(daoAssigOrg.buscaPorId(assigorgaotransp));
		te.setDador(dador);
		te.setContato(contato);
		te.setDestino(destino);
		Date date = df.parse(horaprevista);
		Calendar cal = Calendar.getInstance();
		cal.setTime(date);
		te.setHoraprevista(cal);
		Date date2 = df.parse(horatransplante);
		Calendar cal2 = Calendar.getInstance();
		cal2.setTime(date2);
		te.setHoratransplante(cal2);
		te.setTransportador(transportador);
		daotranspequipa.atualiza(te);
		
		
		model.addAttribute("transpequipa",daotranspequipa.buscatranspequipadador(dador.getId_Dador()));
		
		return "gcct/tabelatransporte";
	}
	
	@RequestMapping(value="eliminatransporte", method = RequestMethod.POST)
	@ResponseBody
	public void eliminatransporte(@RequestParam("idtransporte") Long idtransporte){
		
		daotranspequipa.remove(daotranspequipa.buscaPorId(idtransporte));
	}


	
	//------------------------OFERTAS---------------------------------------------------------------------//
	
	
	@RequestMapping(value="carregaseparadorofertas")
	public String carregaseparadorofertas(Model model, HttpSession session){
				
		//ofertas que recebeu este GCCT
		model.addAttribute("ofertas", daoDador.listaofertasgcct((Long) session.getAttribute("idlocalizacao")));

		return "gcct/divseparadorofertas";
	}
	
	
	@RequestMapping(value="abredadoroferta")
	public String abredadoroferta(@RequestParam("iddador") Long iddador, @RequestParam("idanalise") Long idanalise, @RequestParam("idorgao") int idorgao, Model model, HttpSession session){
				
		Dador dador = daoDador.buscaPorId(iddador);
		
		AssignacaoOrgaos assigorg = daoAssigOrg.buscaassignacaoorgaodador(iddador, idorgao);
		
		session.setAttribute("id_assigorgao", assigorg.getId_assignacao());
		
		//Verifica se j� existe equipa local para o transplante desse org�o
		if(!daoequipalocaltransplante.existeequipalocaltransplanteassig(assigorg.getId_assignacao())){
		
		EquipaLocalTransplante elt = new EquipaLocalTransplante();
		elt.setAssigorgao(assigorg);
		daoequipalocaltransplante.adiciona(elt);
		}
		
		AnaliseDador analise = daoanalisedador.buscaAnaliseDoDador(iddador);
		
		session.setAttribute("id_analise", analise.getId_AnaliseDador());
		session.setAttribute("leituraescrita", false);

		//coloca em sessao o dador ofertas
		//session.setAttribute("dadoroferta", dador);
		session.setAttribute("dadororgao", dador);
		model.addAttribute("Dador", dador);
		
		session.setAttribute("orgaodadoroferta", idorgao);
		
		Long id_analise = (Long)session.getAttribute("id_analise");
		
		model.addAttribute("leituraescrita",false);
		
		model.addAttribute("dador", dador);
		model.addAttribute("glasgowcomma", daoglasg.ListaGlasgowComma());
		model.addAttribute("causademorte", daocausamorte.ListaCausaMorte());
		model.addAttribute("mecanismomorte", daomecmorte.ListaMecanismoMorte());
		BDOrgaos orgaos = daobdorg.buscabdorgaosdaavaliacao(id_analise);
		model.addAttribute("bdorgaos", orgaos);
		model.addAttribute("dadordetalhe", daodaddet.buscadetalhesdador(iddador));
		model.addAttribute("bdavalinicial", daobdavalinicial.buscaavaliacaoinicial(id_analise));
		model.addAttribute("examefisico", daoexamefisico.buscaexamefisico(id_analise));
		Quadrantes quad = daoquadrantes.buscaquadrantesanalise(id_analise);
		model.addAttribute("quadrantes", quad);
		model.addAttribute("etnia", daoetnia.ListaEtnia());
		model.addAttribute("hcgeral", daogeral.buscageralanalise(id_analise));
		model.addAttribute("doencas", daodoencaspreex.buscaDoencasPreExistentesAvaliacao(id_analise));	
		model.addAttribute("sitrisco", daositrisco.buscaSituacoesRiscoAvaliacao(id_analise));
		
		//se transplante true vai abrir dados explante como leitura
		session.setAttribute("transplante", true);
		
		
		Long idhosp = (Long) session.getAttribute("idlocalizacao");
		AssignacaoHospital assighosp = daoAssighosp.buscaassighosporgaohospital(assigorg.getId_assignacao(), idhosp);
		
		model.addAttribute("aceitacao", assighosp.getEstadoassighosp().getIdestado());
		//System.out.println("idorgao: "+session.getAttribute("orgaodadoroferta"));
		model.addAttribute("idorgao", session.getAttribute("orgaodadoroferta"));
		
		return "gcct/divofertasdetalhe";
	}
	
	@RequestMapping(value="carregaseparadorequipaoferta")
	public String carregaseparadorequipaoferta(Model model, HttpSession session){
		
		
		//TROCAR PARA ASSIG ORG�O
		Long id_assigorg = (Long) session.getAttribute("id_assigorgao");

//		System.out.println("id_assigorg: "+id_assigorg);
		Dador dador = (Dador)session.getAttribute("dadororgao");
		
		model.addAttribute("local",daohosp.ListaHospitais());
		model.addAttribute("el",daoequipalocaltransplante.buscaequipalocaltransplante(id_assigorg));
		model.addAttribute("equipacirurgia",daoequipacirurgiatransplante.buscaequipacirurgiatransplanteassigorgao(id_assigorg));
		model.addAttribute("assignacao", daoAssigOrg.ListaAssignacaoOrgaosDador(dador.getId_Dador())); // mudar para apenas esse org�o
		model.addAttribute("cirurgiao", daouser.buscacirurgioes());
		model.addAttribute("equipasuporte",daoequipasuportetransplante.buscaequipacsuportetransplanteassigorgao(id_assigorg));
		model.addAttribute("idorgaooferta",daoorgaooferta.buscaPorId((int)session.getAttribute("orgaodadoroferta")));
		model.addAttribute("idhospitaluser", session.getAttribute("idlocalizacao"));
		if((boolean)session.getAttribute("leituraescritaeqcirurgica")){
			return "gcct/divseparadorequipaofertatransplante";
		}else{
			return "gcct/divseparadorequipaofertaleitura";
		}
	}
	
	@RequestMapping(value="carregaseparadorfuncaoorgaooferta")
	public String carregaseparadorfuncaoorgaooferta(Model model, HttpSession session){
		

		
		Dador dador = (Dador)session.getAttribute("dadororgao");
		
		Long id_analise = (Long)session.getAttribute("id_analise");
		
		model.addAttribute("leituraescrita",false);
		
		
		int idorgao= (int)session.getAttribute("orgaodadoroferta");
		
		AssignacaoOrgaos assigorg = daoAssigOrg.buscaassignacaoorgaodador(dador.getId_Dador(), idorgao);
		
		session.setAttribute("id_assigorgao", assigorg.getId_assignacao());

		boolean transp = (boolean) session.getAttribute("transplante");
	
		if(transp){
			model.addAttribute("leituraescritaeqcirurgica", false);
			
		}else{
		boolean leitesceqcirurgica = (boolean) session.getAttribute("leituraescritaeqcirurgica");
		model.addAttribute("leituraescritaeqcirurgica", leitesceqcirurgica);
		}
		
		AnaliseDador analise = new AnaliseDador();
		analise.setId_AnaliseDador(id_analise);
		
		
		if(idorgao==1){
			//Coracao
			//ECG
			model.addAttribute("ecgcoddador", dador);
			model.addAttribute("dadosgeraiseletrocardiograma", daoeletro.ListaEletrocardiograma(id_analise));
			
			//Coronografia
			model.addAttribute("coronografiacoddador", dador);
			model.addAttribute("dadoscoronografia", daocorona.ListaCoronografia(id_analise));
			model.addAttribute("dadoslesoescoronografia", daodadoscoronografia.buscalesoesDescendente(id_analise));
			
			//RX/TAC
			model.addAttribute("rxcoddador", dador);
			model.addAttribute("lesoes", daolesaorx.buscalesoesDescendente(id_analise));
			model.addAttribute("dadosradiografia", daorx.ListaRadiografia(id_analise));
			
			//Ecocardiograma
			model.addAttribute("toraxicocoddador", dador);
			model.addAttribute("dadosecotoraxico", daotora.ListaEcoToraxico(id_analise));
			
			//Explante/colheita coracao
			ColheitaCoracao cc = daocolheitacoracao.buscacolheitaCoracaoanalise(id_analise);
			
			//Se n�o existe colheita coracao cria
		
			if(cc==null){
				ColheitaCoracao colheitacoracao = new ColheitaCoracao();
				colheitacoracao.setAnaliseDador(analise);
				daocolheitacoracao.adiciona(colheitacoracao);
				model.addAttribute("colheitacoracao", colheitacoracao);
			}else{
				model.addAttribute("colheitacoracao", cc);
			}	

			return "gcct/divseparadorfichaorgaocoracao";
			
		}else if(idorgao==2){
			
			//Eco Abdominal Figado
			model.addAttribute("dadosecofigado", daofigado.ListaEcoAbdFigado(id_analise));
			model.addAttribute("lesoesfigado", daolesaofigado.buscalesoesDescendente(id_analise));
			
			//Biopsia Hep�tica
			model.addAttribute("biohepatica", daobiohepatica.buscabiopsiahepaticaanalise(id_analise));
			
			//Explante/colheita figado
			ColheitaFigado cf = daocolheitafigado.buscacolheitaFigadoanalise(id_analise);
			
			//Se n�o existe colheita figado cria
		
			if(cf==null){
				ColheitaFigado colheitafigado = new ColheitaFigado();
				colheitafigado.setAnaliseDador(analise);
				daocolheitafigado.adiciona(colheitafigado);
				model.addAttribute("colheitafigado", colheitafigado);
			}else{
				model.addAttribute("colheitafigado", cf);
			}
			

			//Tabela perfus�o do harmonio figado
			model.addAttribute("figadoperfusao", daocolheitaperffigado.ListaColheitaFigadoPerfusaoanalise(id_analise));
			
			return "gcct/divseparadorfichaorgaofigado";
			
		}else if(idorgao==3 ||idorgao==4 || idorgao==5){
			
			//Broncoescopia
			model.addAttribute("dadosbroncoescopia", daobronco.ListaBroncoescopia(id_analise));
			model.addAttribute("dadospatologiabronco", daopatbronco.buscalesoesDescendente(id_analise));
			
			
			//RX/TAC
			model.addAttribute("rxcoddador", dador);
			model.addAttribute("lesoes", daolesaorx.buscalesoesDescendente(id_analise));
			model.addAttribute("dadosradiografia", daorx.ListaRadiografia(id_analise));
			
			//Explante/colheita pulmoes
			ColheitaPulmoes cpul = daocolheitapulmoes.buscacolheitaPulmoesanalise(id_analise);
			
			
			//Se n�o existe colheita pulm�es cria
			
			if(cpul==null){
				ColheitaPulmoes colheitapulmoes = new ColheitaPulmoes();
				colheitapulmoes.setAnaliseDador(analise);
				daocolheitapulmoes.adiciona(colheitapulmoes);
				model.addAttribute("colheitapulmoes", colheitapulmoes);
			}else{
				model.addAttribute("colheitapulmoes", cpul);
			}	
			
			
			//tabela tratamento pulmoes
			model.addAttribute("tratpulmoes", daocolheitapulmoestrat.listacolheitapulmoestratamentoanalise(id_analise));
			
			return "gcct/divseparadorfichaorgaopulmoes";
			
		}else if(idorgao==6){
		
		
			//Eco Abdominal Pancreas
			model.addAttribute("dadosecopancreas", daopancreas.ListaEcoPancreas(id_analise));
			model.addAttribute("lesoespancreas", daolesaopancreas.buscalesoesDescendente(id_analise));
			
			//Explante/colheita pancreas
			ColheitaPancreas cp = daocolheitapancreas.buscacolheitaPancreasanalise(id_analise);
			
			
			//Se n�o existe colheita pancreas cria
			
			if(cp==null){
				ColheitaPancreas colheitapancreas = new ColheitaPancreas();
				colheitapancreas.setAnaliseDador(analise);
				daocolheitapancreas.adiciona(colheitapancreas);
				model.addAttribute("colheitapancreas", colheitapancreas);
			}else{
				model.addAttribute("colheitapancreas", cp);
			}
			
			
			//tabela perfus�o pancreas
			//Tabela perfus�o do harmonio pancreas
			model.addAttribute("pancreasperfusao", daocolheitaperfpancreas.ListaColheitaPancreasPerfusaoanalise(id_analise));
			
			//tabela produtos pancreas
			model.addAttribute("produtopancreas", daocolheitapancreasprod.listacolheitapancreasprodutoanalise(id_analise));
			
			
			return "gcct/divseparadorfichaorgaopancreas";
		

		}else{

			//Eco Abdominal Rins
			model.addAttribute("dadosrins", daorins.ListaEcoAbdFigado(id_analise));
			model.addAttribute("lesoesrins", daolesaorins.buscalesoesDescendente(id_analise));
			
			//Biopsia Renal
			model.addAttribute("biorenal", daobiorenal.buscabiopsiarenalanalise(id_analise));
			model.addAttribute("biorenalitens",daobiorenalitens.buscabiopsiarenalitensanalise(id_analise));
			
		//-----------------------------------Explante/colheita rins---------------------
			ColheitaRins cr = daocolheitarins.buscacolheitaRinsanalise(id_analise);
			
			
			//Se n�o existe colheita rins cria
			
			if(cr==null){
				ColheitaRins colheitarins = new ColheitaRins();
				colheitarins.setAnaliseDador(analise);
				daocolheitarins.adiciona(colheitarins);
				model.addAttribute("colheitarins", colheitarins);
			}else{
				model.addAttribute("colheitarins", cr);
			}
			
			//Tabela perfus�o toracica do harmonio geral
			model.addAttribute("rimperfusao", daocolheitaperfrins.ListaColheitaRinsPerfusaoanalise(id_analise));
			//tabela terapeuticas rins
			model.addAttribute("terapeuticasrins", daocolheitarinsterap.listacolheitarinsterapeuticasanalise(id_analise));
			
			return "gcct/divseparadorfichaorgaorins";
		
		}
		
	}
	
	@RequestMapping(value="gravacombodadoscompletosassig")
	@ResponseBody
	public void gravacombodadoscompletosassig(@RequestParam("combo") int combo, Model model, HttpSession session){
		Dador dador = (Dador)session.getAttribute("dadororgao");
		dador.setDadoscompletostransp(combo);
		daoDador.atualiza(dador);
	}
	
	@RequestMapping(value="carregagcctatribuicao")
	public String carregagcctatribuicao(Model model, HttpSession session){

		model.addAttribute("atribuicoes", daoDador.listaatribuicoes((Long) session.getAttribute("idlocalizacao")));
		return "gcct/loadgcctatribuicao";
	}
	
	@RequestMapping(value = "atualizastatusorgaosemhospital"  , method = RequestMethod.POST)
	@ResponseBody
	public void atualizastatusorgaosemhospital(@RequestParam("idassigorgao") Long idassigorgao){
		
		StatusAssignacaoOrgaos status = new StatusAssignacaoOrgaos();
		status.setIdstatus(1);
		
		AssignacaoOrgaos ao =  daoAssigOrg.buscaPorId(idassigorgao);
		ao.setStatusassignacao(status);
		daoAssigOrg.atualiza(ao);
		
	}
}
