package pt.iconic.ipst.dao;


import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import pt.iconic.ipst.modelo.Microrgmbanalisemb;

@Repository
public class MicrorgmbanalisembDAO {

	@PersistenceContext
	private EntityManager manager;
	
	@Transactional
	public void adiciona(Microrgmbanalisemb microrgmbanalisemb){
		manager.persist(microrgmbanalisemb);	
	}
	
	@Transactional
	public void atualiza(Microrgmbanalisemb microrgmbanalisemb){
		manager.merge(microrgmbanalisemb);
	}
	

/*	@SuppressWarnings("unchecked")
	public List<Microrgmbanalisemb> ListaAmostrasFO(){
		return manager.createQuery("select a from Microrgmbanalisemb a").getResultList();
	}*/
	
	public Microrgmbanalisemb buscaPorId(Long id){
		return manager.find(Microrgmbanalisemb.class, id);
	}
	
	
/*	public void remove(Microrgmbanalisemb microrgmbanalisemb){
		Microrgmbanalisemb microrgmbanalisembARemover = buscaPorId(microrgmbanalisemb.getId_microrgmbanalisemb());
		manager.remove(microrgmbanalisembARemover);
		
	}*/
	
	
	@SuppressWarnings("unchecked")
	public List<Object[]> listaMicrorgmbanalisembanalise(Long idmbanalise){
		
		List<Object[]> out = null;
		
		String sql = "select ma.ID_MBANALISES, ma.ID_MICRORGMBANALISE, case ma.VALOR when 1 then 'true' else 'false' end as VALOR, m.MICRODESCRICAO, ma.ID_MICRORGANISMO, m.ID_TIPOMICROORGANISMO "
				+ "from MICRORGMBANALISE ma right join MICROORGANISMOS m on (m.ID_MICROORGANISMOS = ma.ID_MICRORGANISMO) where ma.ID_MBANALISES = :idmbanalise "
				+ "union "
				+ "select :idmbanalise, null, 'false', m.MICRODESCRICAO, m.ID_MICROORGANISMOS, m.ID_TIPOMICROORGANISMO "
				+ "from MICRORGMBANALISE ma right join MICROORGANISMOS m on (m.ID_MICROORGANISMOS = ma.ID_MICRORGANISMO) where m.ID_MICROORGANISMOS not in(select m.ID_MICROORGANISMOS "
				+ "from MICRORGMBANALISE ma right join MICROORGANISMOS m on (m.ID_MICROORGANISMOS = ma.ID_MICRORGANISMO) where ma.ID_MBANALISES = :idmbanalise) Order by MICRODESCRICAO ASC";

		Query query = manager.createNativeQuery(sql);
		query.setParameter("idmbanalise", idmbanalise);
	//	User user = (User) query.getSingleResult();
		
	//	Query query = manager.createQuery("select a from AmostrasFuncoesOrgao a JOIN a.analiseDador an JOIN a.tipoAmostra t Join a.amostra am WHERE an.id_AnaliseDador =:idanalise ORDER BY t.id_tipoamostra, am.nomeamostra  ASC");
		
		//List<Microrgmbanalisemb> results = query.getResultList();
	//	int num = results.size();
	//	System.out.println("numero de registros: "+num);
		
		
		out = query.getResultList();
//		int count = 0;  
//		for (Iterator i = out.iterator(); i.hasNext();) {  
//		    Object[] values = (Object[]) i.next();  
//		    System.out.println(++count + ": " + values[0] + ", " + values[1] + " ," + values[2] +"," + values[3] + " ," + values[4] + " ," + values[5] +"<br />");  
//
//		}

		
		return out;
	}
	
}
