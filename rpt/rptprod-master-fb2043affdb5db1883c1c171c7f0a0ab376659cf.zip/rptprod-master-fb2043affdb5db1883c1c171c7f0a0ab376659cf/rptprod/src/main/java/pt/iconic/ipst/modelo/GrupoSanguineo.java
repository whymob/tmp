package pt.iconic.ipst.modelo;

import java.util.Calendar;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name = "GRUPOSANGUINEO")
public class GrupoSanguineo {
	
	private Long id_gruposanguineo;
	private AnaliseDador analiseDador;
	private boolean rh;
	private int abo;
	private String gruposangespecificacoes;
	private boolean statusharmgruposang;
	private Calendar datagravacao;
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="ID_GRUPOSANGUINEO")
	public Long getId_gruposanguineo() {
		return id_gruposanguineo;
	}
	public void setId_gruposanguineo(Long id_gruposanguineo) {
		this.id_gruposanguineo = id_gruposanguineo;
	}
	
	@OneToOne
	@JoinColumn(name="ID_ANALISEDADOR")
	public AnaliseDador getAnaliseDador() {
		return analiseDador;
	}
	public void setAnaliseDador(AnaliseDador analiseDador) {
		this.analiseDador = analiseDador;
	}
	
	@Column(name="RH")
	public boolean isRh() {
		return rh;
	}
	public void setRh(boolean rh) {
		this.rh = rh;
	}
	
	@Column(name="ABO")
	public int getAbo() {
		return abo;
	}
	public void setAbo(int abo) {
		this.abo = abo;
	}
	
	@Column(name="GRUPOSANGESPECIFICACOES")
	public String getGruposangespecificacoes() {
		return gruposangespecificacoes;
	}
	public void setGruposangespecificacoes(String gruposangespecificacoes) {
		this.gruposangespecificacoes = gruposangespecificacoes;
	}
	
	@Column(name="STATUSHARMONIO")
	public boolean isStatusharmgruposang() {
		return statusharmgruposang;
	}
	public void setStatusharmgruposang(boolean statusharmgruposang) {
		this.statusharmgruposang = statusharmgruposang;
	}
	
	@Column(name="DATAGRAVACAO")
	public Calendar getDatagravacao() {
		return datagravacao;
	}


	public void setDatagravacao(Calendar datagravacao) {
		this.datagravacao = datagravacao;
	}
}
