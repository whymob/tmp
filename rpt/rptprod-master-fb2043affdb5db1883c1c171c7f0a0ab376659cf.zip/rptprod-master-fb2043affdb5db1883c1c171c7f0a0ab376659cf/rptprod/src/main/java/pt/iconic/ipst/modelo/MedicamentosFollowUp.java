package pt.iconic.ipst.modelo;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;


@Entity
@Table(name = "MEDICAMENTOSFOLLOWUP") 
public class MedicamentosFollowUp {

	private Long idmedicamento;
	private String nome;
	private String dosagem;
	private int periodicidade;
	private int numdias;
	private String notas;
	private FollowUp marcacao;
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "ID_MEDICAMENTO")
	public Long getIdmedicamento() {
		return idmedicamento;
	}
	public void setIdmedicamento(Long idmedicamento) {
		this.idmedicamento = idmedicamento;
	}
	
	@Column(name = "NOME")
	public String getNome() {
		return nome;
	}
	public void setNome(String nome) {
		this.nome = nome;
	}
	
	@Column(name = "DOSAGEM")
	public String getDosagem() {
		return dosagem;
	}
	public void setDosagem(String dosagem) {
		this.dosagem = dosagem;
	}
	
	@Column(name = "PERIODICIDADE")
	public int getPeriodicidade() {
		return periodicidade;
	}
	public void setPeriodicidade(int periodicidade) {
		this.periodicidade = periodicidade;
	}
	
	@Column(name = "NUMDIAS")
	public int getNumdias() {
		return numdias;
	}
	public void setNumdias(int numdias) {
		this.numdias = numdias;
	}
	
	@Column(name = "NOTAS")
	public String getNotas() {
		return notas;
	}
	public void setNotas(String notas) {
		this.notas = notas;
	}
	
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "ID_FOLLOWUP")
	public FollowUp getMarcacao() {
		return marcacao;
	}
	public void setMarcacao(FollowUp marcacao) {
		this.marcacao = marcacao;
	}
}
