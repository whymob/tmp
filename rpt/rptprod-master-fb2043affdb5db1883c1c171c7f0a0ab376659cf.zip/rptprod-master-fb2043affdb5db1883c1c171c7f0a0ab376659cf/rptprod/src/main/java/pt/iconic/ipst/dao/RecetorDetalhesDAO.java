package pt.iconic.ipst.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import pt.iconic.ipst.modelo.RecetorDetalhes;

@Repository
@Transactional
public class RecetorDetalhesDAO 
{
	@PersistenceContext
	private EntityManager manager;
	
	public void adiciona(RecetorDetalhes recetordetalhes){
		manager.persist(recetordetalhes);	
	}
	
	public void atualiza(RecetorDetalhes recetordetalhes){
		manager.merge(recetordetalhes);
	}
	
	
	@SuppressWarnings("rawtypes")
	public RecetorDetalhes buscadetalhesrecetor(Long idrecetor)
	{
		Query query = manager.createQuery("select d from RecetorDetalhes d JOIN d.recetor recetor WHERE recetor.id_recetor =:idrecetor");
		query.setParameter("idrecetor", idrecetor);
		
		List results = query.getResultList();
		RecetorDetalhes detalhes = null;
		
		if(!results.isEmpty()){
			detalhes = (RecetorDetalhes) results.get(0);
		}
		return detalhes;
	}

	@SuppressWarnings("rawtypes")
	public boolean verificaexistepin(String pin) {
		
		int pin2 = Integer.parseInt(pin);
		Query query = manager.createQuery("select d from RecetorDetalhes d WHERE d.pin =:pin");
		query.setParameter("pin", pin2);
		
		List results = query.getResultList();
		
		if(!results.isEmpty()){
			return true;
		}else{
			return false;
		}
	}
}
