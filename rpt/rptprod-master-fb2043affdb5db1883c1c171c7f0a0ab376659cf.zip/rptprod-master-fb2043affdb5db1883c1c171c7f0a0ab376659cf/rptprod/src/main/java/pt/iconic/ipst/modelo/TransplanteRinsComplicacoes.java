package pt.iconic.ipst.modelo;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name = "TRANSPLANTE_RINS_COMPLICACOES")
public class TransplanteRinsComplicacoes {

	private Long idtransprinscompl;
	private int complicacao;
	private String notascomplicacao;
	private AssignacaoOrgaos assigorgao;
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="ID_TRANSP_RINS_COMPL")
	public Long getIdtransprinscompl() {
		return idtransprinscompl;
	}
	public void setIdtransprinscompl(Long idtransprinscompl) {
		this.idtransprinscompl = idtransprinscompl;
	}
	
	@Column(name="COMPLICACAO")
	public int getComplicacao() {
		return complicacao;
	}
	public void setComplicacao(int complicacao) {
		this.complicacao = complicacao;
	}
	
	@Column(name="NOTAS")
	public String getNotascomplicacao() {
		return notascomplicacao;
	}
	public void setNotascomplicacao(String notascomplicacao) {
		this.notascomplicacao = notascomplicacao;
	}
	
	@ManyToOne(fetch=FetchType.EAGER)
	@JoinColumn(name="ID_ASSIGNACAO_ORGAOS")
	public AssignacaoOrgaos getAssigorgao() {
		return assigorgao;
	}
	public void setAssigorgao(AssignacaoOrgaos assigorgao) {
		this.assigorgao = assigorgao;
	}
}
