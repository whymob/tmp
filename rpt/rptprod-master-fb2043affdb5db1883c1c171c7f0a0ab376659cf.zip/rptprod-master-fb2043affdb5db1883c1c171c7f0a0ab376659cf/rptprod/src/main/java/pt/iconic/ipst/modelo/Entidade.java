package pt.iconic.ipst.modelo;

import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name = "ENTIDADE")
public class Entidade 
{
	private Long Id_Entidade;
	private String nome;
	private int nif;
	private List<Hospital> hospital;
	private List<GCCTColheita> gcctcolheita;
	private List<Objetivos> objetivos;
	private List<Premios> premios;
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="ID_ENTIDADE")
	public Long getId_Entidade() {
		return Id_Entidade;
	}
	public void setId_Entidade(Long id_Entidade) {
		Id_Entidade = id_Entidade;
	}
	
	@Column(name="NOME")
	public String getNome() {
		return nome;
	}
	public void setNome(String nome) {
		this.nome = nome;
	}
	
	@Column(name="NIF")
	public int getNif() {
		return nif;
	}
	public void setNif(int nif) {
		this.nif = nif;
	}
	
	@OneToMany(fetch = FetchType.LAZY, mappedBy = "entidade")
	public List<Hospital> getHospital() {
		return hospital;
	}
	public void setHospital(List<Hospital> hospital) {
		this.hospital = hospital;
	}
	
	@OneToMany(fetch = FetchType.LAZY, mappedBy = "entidade")
	public List<GCCTColheita> getGcctcolheita() {
		return gcctcolheita;
	}
	public void setGcctcolheita(List<GCCTColheita> gcctcolheita) {
		this.gcctcolheita = gcctcolheita;
	}
	
	@OneToMany(fetch = FetchType.LAZY, mappedBy = "entidade")
	public List<Objetivos> getObjetivos() {
		return objetivos;
	}
	public void setObjetivos(List<Objetivos> objetivos) {
		this.objetivos = objetivos;
	}
	
	@OneToMany(fetch = FetchType.LAZY, mappedBy = "entidade")
	public List<Premios> getPremios() {
		return premios;
	}
	public void setPremios(List<Premios> premios) {
		this.premios = premios;
	}
}
