package pt.iconic.ipst.modelo;

import java.util.Calendar;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import org.springframework.format.annotation.DateTimeFormat;

@Entity
@Table(name = "IMUNOPRESSORES")
public class Imunossupressores 
{
	private Long id_imunossupressor;
	private int imunossupressor;
	private int dias;
	private int tipoimuno;
	private String obs;
	private Calendar dataimuno;
	private Transplantes transplante;
	private ImunossupressorMestre imuno;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="ID_IMUNOSSUPRESSOR")
	public Long getId_imunossupressor() {
		return id_imunossupressor;
	}

	public void setId_imunossupressor(Long id_imunossupressor) {
		this.id_imunossupressor = id_imunossupressor;
	}

	@Column(name="IMUNOSSUPRESSOR")
	public int getImunossupressor() {
		return imunossupressor;
	}

	public void setImunossupressor(int imunossupressor) {
		this.imunossupressor = imunossupressor;
	}

	@Column(name="DIAS")
	public int getDias() {
		return dias;
	}

	public void setDias(int dias) {
		this.dias = dias;
	}

	@Column(name="TIPO")
	public int getTipoimuno() {
		return tipoimuno;
	}

	public void setTipoimuno(int tipoimuno) {
		this.tipoimuno = tipoimuno;
	}

	@Column(name="OBS")
	public String getObs() {
		return obs;
	}

	public void setObs(String obs) {
		this.obs = obs;
	}

	@DateTimeFormat(pattern="dd/MM/yyyy")
	@Temporal(TemporalType.DATE)
	@Column(name="DATA")
	public Calendar getDataimuno() {
		return dataimuno;
	}

	public void setDataimuno(Calendar dataimuno) {
		this.dataimuno = dataimuno;
	}

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name="ID_TRANSPLANTE")
	public Transplantes getTransplante() {
		return transplante;
	}

	public void setTransplante(Transplantes transplante) {
		this.transplante = transplante;
	}

	@ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "ID_IMUNO")
	public ImunossupressorMestre getImuno() {
		return imuno;
	}

	public void setImuno(ImunossupressorMestre imuno) {
		this.imuno = imuno;
	}
}
