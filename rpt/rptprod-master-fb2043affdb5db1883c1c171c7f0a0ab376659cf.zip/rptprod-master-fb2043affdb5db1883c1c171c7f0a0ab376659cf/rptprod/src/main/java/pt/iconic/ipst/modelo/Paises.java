package pt.iconic.ipst.modelo;

import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name = "PAISES")
public class Paises {

	private int id_pais;
	private String nome;
	private List<Dador> dadores;
	private List<RecetorDetalhes> recetordetalhesnac;
	private List<TransplantadoDetalhes> tranpdetnac;
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="ID_PAIS")
	public int getId_pais() {
		return id_pais;
	}
	public void setId_pais(int id_pais) {
		this.id_pais = id_pais;
	}
	
	@Column(name="NOME")
	public String getNome() {
		return nome;
	}
	public void setNome(String nome) {
		this.nome = nome;
	}
	
	@OneToMany(fetch = FetchType.LAZY, mappedBy = "pais")
	public List<Dador> getDadores() {
		return dadores;
	}
	public void setDadores(List<Dador> dadores) {
		this.dadores = dadores;
	}
	
	@OneToMany(fetch = FetchType.LAZY, mappedBy = "nacionalidade")
	public List<RecetorDetalhes> getRecetordetalhesnac() {
		return recetordetalhesnac;
	}
	public void setRecetordetalhesnac(List<RecetorDetalhes> recetordetalhesnac) {
		this.recetordetalhesnac = recetordetalhesnac;
	}
	
	@OneToMany(fetch = FetchType.LAZY, mappedBy = "nacionalidadetransplantado")
	public List<TransplantadoDetalhes> getTranpdetnac() {
		return tranpdetnac;
	}
	public void setTranpdetnac(List<TransplantadoDetalhes> tranpdetnac) {
		this.tranpdetnac = tranpdetnac;
	}
}