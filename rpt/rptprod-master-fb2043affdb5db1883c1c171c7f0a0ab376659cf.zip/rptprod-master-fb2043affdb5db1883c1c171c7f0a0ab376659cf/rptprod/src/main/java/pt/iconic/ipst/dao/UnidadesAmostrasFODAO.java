package pt.iconic.ipst.dao;



import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;

import pt.iconic.ipst.modelo.UnidadesAmostrasFO;


@Repository
public class UnidadesAmostrasFODAO {

	@PersistenceContext
	private EntityManager manager;
	
	
	public void adiciona(UnidadesAmostrasFO unidades){
		manager.persist(unidades);	
	}
	
/*	@Transactional
	public void atualiza(UnidadesAmostrasFO unidades){
		manager.merge(unidades);
	}*/
	

	
	public UnidadesAmostrasFO buscaPorId(Long id){
		return manager.find(UnidadesAmostrasFO.class, id);
	}
	
	
	public void remove(UnidadesAmostrasFO unidades){
		UnidadesAmostrasFO unidadesARemover = buscaPorId(unidades.getId_unidades_amostras());
		manager.remove(unidadesARemover);
		
	}
	
	@SuppressWarnings("unchecked")
	public List<UnidadesAmostrasFO> listaunidadesamostrafo( Long idamostrafo){
		
		Query query = manager.createQuery("select u from UnidadesAmostrasFO u JOIN u.amostraFO amostras WHERE amostras.id_amostrafo = :idamostrafo");
		query.setParameter("idamostrafo", idamostrafo);
		
		List<UnidadesAmostrasFO> results = query.getResultList();

		return results;
		
	}

}
