package pt.iconic.ipst.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import pt.iconic.ipst.modelo.EstadoDador;



@Repository
@Transactional
public class EstadoDadorDAO {

	
	@PersistenceContext
	private EntityManager manager;
	
	
	public void adiciona(EstadoDador estadodador){
		manager.persist(estadodador);	
	}
	
	public void atualiza(EstadoDador estadodador){
		manager.merge(estadodador);
	}
	

	@SuppressWarnings("unchecked")
	public List<EstadoDador> ListaEstadoDador(){
		return manager.createQuery("select e from EstadoDador e").getResultList();
	}
	/*
	public EstadoDador buscaPorId(int id){
		return manager.find(EstadoDador.class, id);
	}*/

	public EstadoDador buscaPorId(int id){
		return manager.find(EstadoDador.class, id);
	}
	
	
	public void remove(EstadoDador estadodador){
		EstadoDador estadodadorARemover = buscaPorId(estadodador.getId_EstadoDador());
		manager.remove(estadodadorARemover);
	}
	
	public boolean trataadicionar(String desc)
	{
		Query query = manager.createQuery("SELECT e FROM EstadoDador e WHERE e.estado =:desc");
		query.setParameter("desc", desc);
		
		if(query.getResultList().isEmpty())
		{
			EstadoDador est = new EstadoDador();
			est.setEstado(desc);;
			adiciona(est);
			
			return true;
		}
		else
		{
			return false;
		}
	}
	
	public boolean trataalterar(int id, String desc)
	{
		Query query = manager.createQuery("SELECT e FROM EstadoDador e WHERE e.estado =:desc");
		query.setParameter("desc", desc);
		
		if(query.getResultList().isEmpty())
		{
			EstadoDador est = new EstadoDador();
			est.setEstado(desc);;
			est.setId_EstadoDador(id);;
			atualiza(est);
				
			return true;
		}
		else
		{
			return false;
		}
	}
	
	public boolean remover(int id) 
	{
		EstadoDador est = new EstadoDador();
		est = buscaPorId(id);

		remove(est);
		return true;
	}
}
