package pt.iconic.ipst.modelo;

import java.util.Calendar;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import org.springframework.format.annotation.DateTimeFormat;

@Entity
@Table(name = "TRANSPLANTE_CORACAO")
public class TransplanteCoracao {

	private Long idtransplantecoracao;
	private Calendar inicio;
	private Calendar clampaorta;
	private Calendar reperfusao;
	private Calendar fim;
	private String isquemia;
	private int reesterno;
	private int recetor;
	private int inotropicos;
	private int assistencia;
	private int ecmo;
	private int univentric;
	private int tecnica;
	private int balao;
	private int circulextra;
	private int procextra;
	private boolean hemorragia;
	private boolean falencenxerto;
	private boolean hipertensao;
	private boolean outra;
	private String notas;
	private int saidarecetor;
	private int saidasuporte;
	private int saidano;
	private int saidapacing;
	private int saidabalao;
	private int saidaecmo;
	private String saidaobs;
	private int complicacoes;
	private Calendar entrada;
	private Calendar saida;
	private int estado;
	private AssignacaoOrgaos assigorgao;
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="ID_TRANSP_CORACAO")
	public Long getIdtransplantecoracao() {
		return idtransplantecoracao;
	}
	public void setIdtransplantecoracao(Long idtransplantecoracao) {
		this.idtransplantecoracao = idtransplantecoracao;
	}
	
	@Column(name="INICIO")
	public Calendar getInicio() {
		return inicio;
	}
	public void setInicio(Calendar inicio) {
		this.inicio = inicio;
	}
	
	@Column(name="CLAMP_AORTA")
	public Calendar getClampaorta() {
		return clampaorta;
	}
	public void setClampaorta(Calendar clampaorta) {
		this.clampaorta = clampaorta;
	}
	
	@Column(name="REPERFUSAO")
	public Calendar getReperfusao() {
		return reperfusao;
	}
	public void setReperfusao(Calendar reperfusao) {
		this.reperfusao = reperfusao;
	}
	
	@Column(name="FIM")
	public Calendar getFim() {
		return fim;
	}
	public void setFim(Calendar fim) {
		this.fim = fim;
	}
	
	@Column(name="ISQUEMIA")
	public String getIsquemia() {
		return isquemia;
	}
	public void setIsquemia(String isquemia) {
		this.isquemia = isquemia;
	}
	
	@Column(name="REESTERNOTOMIA")
	public int getReesterno() {
		return reesterno;
	}
	public void setReesterno(int reesterno) {
		this.reesterno = reesterno;
	}
	
	@Column(name="RECETOR")
	public int getRecetor() {
		return recetor;
	}
	public void setRecetor(int recetor) {
		this.recetor = recetor;
	}
	
	@Column(name="INOTROPICOS")
	public int getInotropicos() {
		return inotropicos;
	}
	public void setInotropicos(int inotropicos) {
		this.inotropicos = inotropicos;
	}
	
	@Column(name="ASSISTENCIA")
	public int getAssistencia() {
		return assistencia;
	}
	public void setAssistencia(int assistencia) {
		this.assistencia = assistencia;
	}
	
	@Column(name="ECMO")
	public int getEcmo() {
		return ecmo;
	}
	public void setEcmo(int ecmo) {
		this.ecmo = ecmo;
	}
	
	@Column(name="UNIVENTRICULAR")
	public int getUniventric() {
		return univentric;
	}
	public void setUniventric(int univentric) {
		this.univentric = univentric;
	}
	
	@Column(name="TECNICA")
	public int getTecnica() {
		return tecnica;
	}
	public void setTecnica(int tecnica) {
		this.tecnica = tecnica;
	}
	
	@Column(name="BALAO_INTRA")
	public int getBalao() {
		return balao;
	}
	public void setBalao(int balao) {
		this.balao = balao;
	}
	
	@Column(name="CIRCUL_EXTRA_CORP")
	public int getCirculextra() {
		return circulextra;
	}
	public void setCirculextra(int circulextra) {
		this.circulextra = circulextra;
	}
	
	@Column(name="PROCED_EXTRA")
	public int getProcextra() {
		return procextra;
	}
	public void setProcextra(int procextra) {
		this.procextra = procextra;
	}
	
	@Column(name="HEMORRAGIA")
	public boolean isHemorragia() {
		return hemorragia;
	}
	public void setHemorragia(boolean hemorragia) {
		this.hemorragia = hemorragia;
	}
	
	@Column(name="FALENCIA_ENXERTO")
	public boolean isFalencenxerto() {
		return falencenxerto;
	}
	public void setFalencenxerto(boolean falencenxerto) {
		this.falencenxerto = falencenxerto;
	}
	
	@Column(name="HIPERTENS_PULMONAR")
	public boolean isHipertensao() {
		return hipertensao;
	}
	public void setHipertensao(boolean hipertensao) {
		this.hipertensao = hipertensao;
	}
	
	@Column(name="OUTRA")
	public boolean isOutra() {
		return outra;
	}
	public void setOutra(boolean outra) {
		this.outra = outra;
	}
	
	@Column(name="NOTAS")
	public String getNotas() {
		return notas;
	}
	public void setNotas(String notas) {
		this.notas = notas;
	}
	
	@Column(name="SAIDA_RECETOR")
	public int getSaidarecetor() {
		return saidarecetor;
	}
	public void setSaidarecetor(int saidarecetor) {
		this.saidarecetor = saidarecetor;
	}
	
	@Column(name="SAIDA_SUPORTE")
	public int getSaidasuporte() {
		return saidasuporte;
	}
	public void setSaidasuporte(int saidasuporte) {
		this.saidasuporte = saidasuporte;
	}
	
	@Column(name="SAIDA_NO")
	public int getSaidano() {
		return saidano;
	}
	public void setSaidano(int saidano) {
		this.saidano = saidano;
	}
	
	@Column(name="SAIDA_PACING")
	public int getSaidapacing() {
		return saidapacing;
	}
	public void setSaidapacing(int saidapacing) {
		this.saidapacing = saidapacing;
	}
	
	@Column(name="SAIDA_BALAO_INTRAORT")
	public int getSaidabalao() {
		return saidabalao;
	}
	public void setSaidabalao(int saidabalao) {
		this.saidabalao = saidabalao;
	}
	
	@Column(name="SAIDA_ECMO")
	public int getSaidaecmo() {
		return saidaecmo;
	}
	public void setSaidaecmo(int saidaecmo) {
		this.saidaecmo = saidaecmo;
	}
	
	@Column(name="SAIDA_OBS")
	public String getSaidaobs() {
		return saidaobs;
	}
	public void setSaidaobs(String saidaobs) {
		this.saidaobs = saidaobs;
	}
	
	@Column(name="COMPLICACOES")
	public int getComplicacoes() {
		return complicacoes;
	}
	public void setComplicacoes(int complicacoes) {
		this.complicacoes = complicacoes;
	}
	
	@DateTimeFormat(pattern = "dd/MM/yyyy")
	@Column(name="ENTRADA")
	public Calendar getEntrada() {
		return entrada;
	}
	public void setEntrada(Calendar entrada) {
		this.entrada = entrada;
	}
	
	@DateTimeFormat(pattern = "dd/MM/yyyy")
	@Column(name="SAIDA")
	public Calendar getSaida() {
		return saida;
	}
	public void setSaida(Calendar saida) {
		this.saida = saida;
	}
	
	@Column(name="ESTADO")
	public int getEstado() {
		return estado;
	}
	public void setEstado(int estado) {
		this.estado = estado;
	}
	
	@OneToOne(fetch=FetchType.EAGER)
	@JoinColumn(name="ID_ASSIGNACAO_ORGAOS")
	public AssignacaoOrgaos getAssigorgao() {
		return assigorgao;
	}
	public void setAssigorgao(AssignacaoOrgaos assigorgao) {
		this.assigorgao = assigorgao;
	}
	
	
}
