package pt.iconic.ipst.controller;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Random;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import pt.iconic.ipst.dao.AmostrasFODAO;
import pt.iconic.ipst.dao.AnaliseRecetorDAO;
import pt.iconic.ipst.dao.ContatosRecetorDAO;
import pt.iconic.ipst.dao.EspecialidadesDAO;
import pt.iconic.ipst.dao.EstadoRecetorDAO;
import pt.iconic.ipst.dao.EtniaDAO;
import pt.iconic.ipst.dao.FollowUpDAO;
import pt.iconic.ipst.dao.GeralRecetorDAO;
import pt.iconic.ipst.dao.GravidadeOrgaoDAO;
import pt.iconic.ipst.dao.GravidadeRecetorDAO;
import pt.iconic.ipst.dao.HospitalDAO;
import pt.iconic.ipst.dao.ImunossupressorMestreDAO;
import pt.iconic.ipst.dao.ImunossupressoresDAO;
import pt.iconic.ipst.dao.LocalResidenciaDAO;
import pt.iconic.ipst.dao.MedicamentosFollowUpDAO;
import pt.iconic.ipst.dao.MedicamentosPreTranspDAO;
import pt.iconic.ipst.dao.OrgaosOfertaDAO;
import pt.iconic.ipst.dao.PPAnalisesFollowUpDAO;
import pt.iconic.ipst.dao.PPAnalisesRecetorDAO;
import pt.iconic.ipst.dao.PPCardiacoDAO;
import pt.iconic.ipst.dao.PPHepaticoComorbilidadesDAO;
import pt.iconic.ipst.dao.PPHepaticoComplicacoesDAO;
import pt.iconic.ipst.dao.PPHepaticoDAO;
import pt.iconic.ipst.dao.PPHepaticoDiagnosticoDAO;
import pt.iconic.ipst.dao.PPHistoricoDAO;
import pt.iconic.ipst.dao.PPPancreaticoDAO;
import pt.iconic.ipst.dao.PPPulmonarDAO;
import pt.iconic.ipst.dao.PPRenalDAO;
import pt.iconic.ipst.dao.PaisesDAO;
import pt.iconic.ipst.dao.PermissaoDAO;
import pt.iconic.ipst.dao.RecetorDetalhesDAO;
import pt.iconic.ipst.dao.RecetoresDAO;
import pt.iconic.ipst.dao.TerapeuticasFollowUpDAO;
import pt.iconic.ipst.dao.TipoComplicacoesDAO;
import pt.iconic.ipst.dao.TipoDiagnosticoDAO;
import pt.iconic.ipst.dao.TipoTerapeuticasFollowUpDAO;
import pt.iconic.ipst.dao.TransplantadoDetalhesDAO;
import pt.iconic.ipst.dao.TransplantesDAO;
import pt.iconic.ipst.dao.UnidadeTransplanteDAO;
import pt.iconic.ipst.dao.UnidadesDAO;
import pt.iconic.ipst.dao.UtilizadorDAO;
import pt.iconic.ipst.dao.VirologiaRecetorDAO;
import pt.iconic.ipst.modelo.AnaliseRecetor;
import pt.iconic.ipst.modelo.ContatosRecetor;
import pt.iconic.ipst.modelo.EstadoRecetor;
import pt.iconic.ipst.modelo.Etnia;
import pt.iconic.ipst.modelo.FollowUp;
import pt.iconic.ipst.modelo.GeralRecetor;
import pt.iconic.ipst.modelo.GravidadeOrgao;
import pt.iconic.ipst.modelo.GravidadeRecetor;
import pt.iconic.ipst.modelo.Hospital;
import pt.iconic.ipst.modelo.ImunossupressorMestre;
import pt.iconic.ipst.modelo.Imunossupressores;
import pt.iconic.ipst.modelo.LocalResidencia;
import pt.iconic.ipst.modelo.MedicamentosFollowUp;
import pt.iconic.ipst.modelo.MedicamentosPreTransp;
import pt.iconic.ipst.modelo.OrgaosOferta;
import pt.iconic.ipst.modelo.PPAnalisesFollowUp;
import pt.iconic.ipst.modelo.PPAnalisesRecetor;
import pt.iconic.ipst.modelo.PPCardiaco;
import pt.iconic.ipst.modelo.PPHepatico;
import pt.iconic.ipst.modelo.PPHepaticoComorbilidades;
import pt.iconic.ipst.modelo.PPHepaticoComplicacoes;
import pt.iconic.ipst.modelo.PPHepaticoDiagnostico;
import pt.iconic.ipst.modelo.PPPancreatico;
import pt.iconic.ipst.modelo.PPPulmonar;
import pt.iconic.ipst.modelo.PPRenal;
import pt.iconic.ipst.modelo.Paises;
import pt.iconic.ipst.modelo.RecetorDetalhes;
import pt.iconic.ipst.modelo.Recetores;
import pt.iconic.ipst.modelo.TerapeuticasFollowUP;
import pt.iconic.ipst.modelo.TipoComplicacoes;
import pt.iconic.ipst.modelo.TipoDiagnostico;
import pt.iconic.ipst.modelo.TransplantadoDetalhes;
import pt.iconic.ipst.modelo.Transplantes;
import pt.iconic.ipst.modelo.UnidadeTransplante;
import pt.iconic.ipst.modelo.Utilizador;
import pt.iconic.ipst.modelo.VirologiaRecetor;

@Controller
public class TransplanteController 
{
	private RecetoresDAO daorecetor;
	private ContatosRecetorDAO daocontrecetor;
	private RecetorDetalhesDAO daorecetordetalhe;
	private GravidadeRecetorDAO daogravrecetor;
	private GeralRecetorDAO daogeralrec;
	private PPAnalisesRecetorDAO daoanalise;
	private EtniaDAO daoetnia;
	private HospitalDAO daohospital;
	private AnaliseRecetorDAO daoanaliserecetor;
	private PPPulmonarDAO daopppulmonar;
	private PPHepaticoDAO daopphepatico;
	private PPPancreaticoDAO daopppancreatico;
	private PPRenalDAO daorenal;
	private PPCardiacoDAO daocardiaco;
	private TransplantesDAO daotransp;
	private TransplantadoDetalhesDAO daotranspdet;
	private UnidadeTransplanteDAO daounidtransp;
	private PaisesDAO daopais;
	private LocalResidenciaDAO daores;
	private UtilizadorDAO daouser;
	private EspecialidadesDAO daoespec;
	private PermissaoDAO daoperm;
	private EstadoRecetorDAO daoestado;
	private AmostrasFODAO daoamostrasmestre;
	private UnidadesDAO daounid;
	private GravidadeOrgaoDAO daogravorgao;	
	private PPAnalisesFollowUpDAO daoanalisefollow;
	private FollowUpDAO daofollowup;
	private ImunossupressoresDAO daoimuno;
	private TerapeuticasFollowUpDAO daoterapfollowup;
	private TipoTerapeuticasFollowUpDAO daotipoterfollow;
	private ImunossupressorMestreDAO daoimunomestre;
	private VirologiaRecetorDAO daovirorecetor;
	private PPHepaticoComorbilidadesDAO daopphepaticocomorb;
	private PPHepaticoDiagnosticoDAO daopphepaticodiag;
	private TipoDiagnosticoDAO daotipodiag;
	private PPHepaticoComplicacoesDAO daopphepaticocompl;
	private TipoComplicacoesDAO daotipocompl;
	private PPHistoricoDAO daopphistorico;
	private MedicamentosPreTranspDAO daomedicamentopretransp;
	private MedicamentosFollowUpDAO daomedicamentosfollowup;
	private OrgaosOfertaDAO daoorgaooferta;
	
	@Autowired
	public TransplanteController(RecetoresDAO daorecetor, ContatosRecetorDAO daocontrecetor, RecetorDetalhesDAO daorecetordetalhe, GravidadeRecetorDAO daogravrecetor, GeralRecetorDAO daogeralrec, 
			PPAnalisesRecetorDAO daoanalise, EtniaDAO daoetnia, HospitalDAO daohospital, AnaliseRecetorDAO daoanaliserecetor, PPPulmonarDAO daopppulmonar, PPHepaticoDAO daopphepatico,
			PPPancreaticoDAO daopppancreatico, PPRenalDAO daorenal, PPCardiacoDAO daocardiaco, TransplantesDAO daotransp, TransplantadoDetalhesDAO daotranspdet, UnidadeTransplanteDAO daounidtransp,
			PaisesDAO daopais, LocalResidenciaDAO daores, UtilizadorDAO daouser, EspecialidadesDAO daoespec, PermissaoDAO daoperm ,EstadoRecetorDAO daoestado, AmostrasFODAO daoamostrasmestre,
			UnidadesDAO daounid, GravidadeOrgaoDAO daogravorgao, PPAnalisesFollowUpDAO daoanalisefollow, FollowUpDAO daofollowup,ImunossupressoresDAO daoimuno, TerapeuticasFollowUpDAO daoterapfollowup,
			TipoTerapeuticasFollowUpDAO daotipoterfollow, ImunossupressorMestreDAO daoimunomestre, VirologiaRecetorDAO daovirorecetor, PPHepaticoComorbilidadesDAO daopphepaticocomorb, 
			PPHepaticoDiagnosticoDAO daopphepaticodiag, TipoDiagnosticoDAO daotipodiag, PPHepaticoComplicacoesDAO daopphepaticocompl, TipoComplicacoesDAO daotipocompl, PPHistoricoDAO daopphistorico, 
			MedicamentosPreTranspDAO daomedicamentopretransp, MedicamentosFollowUpDAO daomedicamentosfollowup, OrgaosOfertaDAO daoorgaooferta) 
	{
		this.daorecetor = daorecetor;
		this.daocontrecetor = daocontrecetor;
		this.daorecetordetalhe = daorecetordetalhe;
		this.daogravrecetor = daogravrecetor;
		this.daogeralrec = daogeralrec;
		this.daoanalise = daoanalise;
		this.daoetnia = daoetnia;
	//	this.daoorgaos = daoorgaos;
		this.daohospital= daohospital;
		this.daoanaliserecetor = daoanaliserecetor;
		this.daopppulmonar = daopppulmonar;
		this.daopphepatico = daopphepatico;
		this.daopppancreatico = daopppancreatico;
		this.daorenal = daorenal;
		this.daocardiaco = daocardiaco;
		this.daotransp = daotransp;
		this.daotranspdet = daotranspdet;
		this.daounidtransp = daounidtransp;
		this.daopais = daopais;
		this.daores = daores;
		this.daouser = daouser;
		this.daoespec = daoespec;
		this.daoperm = daoperm;
		this.daoestado = daoestado;
		this.daoamostrasmestre = daoamostrasmestre;
		this.daounid = daounid;
		this.daogravorgao = daogravorgao;
		this.daoanalisefollow = daoanalisefollow;
		this.daofollowup = daofollowup;
		this.daoimuno = daoimuno;
		this.daoterapfollowup = daoterapfollowup;
		this.daotipoterfollow = daotipoterfollow;
		this.daoimunomestre = daoimunomestre;
		this.daovirorecetor = daovirorecetor;
		this.daopphepaticocomorb = daopphepaticocomorb;
		this.daopphepaticodiag = daopphepaticodiag;
		this.daotipodiag = daotipodiag;
		this.daopphepaticocompl= daopphepaticocompl;
		this.daotipocompl = daotipocompl;
		this.daopphistorico = daopphistorico;
		this.daomedicamentopretransp = daomedicamentopretransp;
		this.daomedicamentosfollowup = daomedicamentosfollowup;
		this.daoorgaooferta = daoorgaooferta;
	}
	
	@RequestMapping(value = "carregaorgaosunidade", method = RequestMethod.POST)
	public String carregaorgaosunidade(@RequestParam("uni") Long uni, Model model, HttpSession session) throws ParseException 
	{
		model.addAttribute("listaorgaos", daoorgaooferta.buscaOrgaosporUnidade(uni));
		
		return  "/pptransplante/comboorgaos";
	}
	
	@RequestMapping(value = "carregaorgaosunidade2", method = RequestMethod.POST)
	public String carregaorgaosunidade2(@RequestParam("uni") Long uni, Model model, HttpSession session) throws ParseException 
	{
		model.addAttribute("listaorgaos", daoorgaooferta.buscaOrgaosporUnidade(uni));
		
		return  "/pptransplante/comboorgaos2";
	}
	
	@RequestMapping(value = "gravarpulmonar", method = RequestMethod.POST)
	@ResponseBody
	@Transactional
	public String gravarpulmonar(@RequestParam("ulimatransfusaopulmonar") String ulimatransfusaopulmonar, @RequestParam("etnia") Long etnia, @RequestParam("peso") String peso, @RequestParam("altura") int altura,
			@RequestParam("transfusoes") int transfusoes, @RequestParam("gestacoes") int gestacoes, @RequestParam("imc") float imc,  @RequestParam("pertoraxico") int pertoraxico, 
			@RequestParam("diagnostico") int diagnostico, @RequestParam("observacoes") String observacoes, @RequestParam("idrecetor") Long idrecetor, 
			@RequestParam("rh") boolean rh, @RequestParam("abovalor") int abovalor, @RequestParam("classefunc") int classefunc, @RequestParam("fev") int fev, 
			@RequestParam("colonizacao") boolean colonizacao, HttpSession session) throws ParseException 
	{
		
		
		
		DateFormat dum = new SimpleDateFormat("dd/MM/yyyy");
		Date date = dum.parse(ulimatransfusaopulmonar);
		Calendar cal = Calendar.getInstance();
		cal.setTime(date);
		
		Long id_analiserecetor = (Long) session.getAttribute("id_analiserecetor");
				
		
		PPPulmonar ppp2 = daopppulmonar.ListaPPPulmonarAnalise(id_analiserecetor);
		
		Etnia et = daoetnia.buscaPorId(etnia);
		
		RecetorDetalhes recetordetalhes = daorecetordetalhe.buscadetalhesrecetor(idrecetor);
		
		recetordetalhes.setAltura(altura);
		recetordetalhes.setEtnia(et);
		recetordetalhes.setPeso(Double.parseDouble(peso));
		recetordetalhes.setRh(rh);
		recetordetalhes.setAbo(abovalor);
		
		ppp2.setDiagnosticopulmonar(diagnostico);
		ppp2.setGestacoespulmonar(gestacoes);
		ppp2.setImcpulmonar(imc);
		ppp2.setObservacoespulmonar(observacoes);
		ppp2.setPertoraxicopulmonar(pertoraxico);
		ppp2.setTransfusoespulmonar(transfusoes);
		
		if(!ulimatransfusaopulmonar.equals("01/01/1970")){
		ppp2.setUlimatransfusaopulmonar(cal);
		}
		ppp2.setClassefunc(classefunc);
		ppp2.setFev(fev);
		ppp2.setColonizacao(colonizacao);
		
		daopppulmonar.atualiza(ppp2);
		
		return "true";
	}
	
	@RequestMapping(value = "gravarhepatico", method = RequestMethod.POST)
	@ResponseBody
	@Transactional
	public String gravarhepatico(@RequestParam("ulimatransfusaohepatico") String ulimatransfusaohepatico, @RequestParam("etnia") Long etnia, @RequestParam("peso") String peso, @RequestParam("altura") int altura,
			@RequestParam("transfusoes") int transfusoes, @RequestParam("gestacoes") int gestacoes, @RequestParam("imc") float imc,  @RequestParam("pertoraxico") int pertoraxico, 
			@RequestParam("dhepaticacronica") boolean dhepaticacronica, @RequestParam("dhepaticaaguda") boolean dhepaticaaguda, @RequestParam("dmetabolica") boolean dmetabolica, @RequestParam("tumor") boolean tumor,
			@RequestParam("outras") boolean outras, @RequestParam("nodulos") String nodulos, @RequestParam("tamanhomaior") String tamanhomaior, @RequestParam("tamanhoglobal") String tamanhoglobal,
			@RequestParam("invvascular") boolean invvascular, @RequestParam("l1") boolean l1, @RequestParam("l2") boolean l2, @RequestParam("l3") boolean l3, @RequestParam("l4") boolean l4,
			@RequestParam("l5") boolean l5, @RequestParam("l6") boolean l6, @RequestParam("l7") boolean l7, @RequestParam("l8") boolean l8, @RequestParam("idrecetor") Long idrecetor, 
			@RequestParam("cirurgia") boolean cirurgia, @RequestParam("rf") boolean rf, @RequestParam("quimioemb") boolean quimioemb,
			@RequestParam("microondas") boolean microondas, @RequestParam("alccolizacao") boolean alccolizacao, @RequestParam("outros") boolean outros, @RequestParam("observacoes") String observacoes,
			@RequestParam("rh") boolean rh, @RequestParam("abovalor") int abovalor, HttpSession session) throws ParseException 
	{

		
		Long id_analiserecetor = (Long) session.getAttribute("id_analiserecetor");
		PPHepatico pph = daopphepatico.ListaPPHepaticoAnalise(id_analiserecetor);;
		
		Etnia et = daoetnia.buscaPorId(etnia);
		
		
		RecetorDetalhes recetordetalhes = daorecetordetalhe.buscadetalhesrecetor(idrecetor);
		
		recetordetalhes.setAltura(altura);
		recetordetalhes.setEtnia(et);
		recetordetalhes.setPeso(Double.parseDouble(peso));
		recetordetalhes.setRh(rh);
		recetordetalhes.setAbo(abovalor);
		

		pph.setGestacoeshepatico(gestacoes);
		pph.setImchepatico(imc);
		pph.setPertoraxicohepatico(pertoraxico);
		pph.setTransfusoeshepatico(transfusoes);
		pph.setDhepaticacronica(dhepaticacronica);
		pph.setDhepaticaaguda(dhepaticaaguda);
		pph.setDmetabolica(dmetabolica);
		pph.setTumor(tumor);
		pph.setOutras(outras);
		pph.setNodulos(nodulos);
		pph.setTamanhomaior(tamanhomaior);
		pph.setTamanhoglobal(tamanhoglobal);
		pph.setInvvascular(invvascular);
		pph.setL1(l1);
		pph.setL2(l2);
		pph.setL3(l3);
		pph.setL4(l4);
		pph.setL5(l5);
		pph.setL6(l6);
		pph.setL7(l7);
		pph.setL8(l8);
		pph.setCirurgia(cirurgia);
		pph.setRf(rf);
		pph.setQuimioemb(quimioemb);
		pph.setMicroondas(microondas);
		pph.setAlccolizacao(alccolizacao);
		pph.setOutros(outros);
		pph.setObservacoes(observacoes);
				
		
		//-----tratamento datas vazias, pelo plugin Date vem a zero (01/01/1970)------------------------//
		if(!ulimatransfusaohepatico.equals("01/01/1970")){
		DateFormat dum = new SimpleDateFormat("dd/MM/yyyy");
		Date date = dum.parse(ulimatransfusaohepatico);
		Calendar cal = Calendar.getInstance();
		cal.setTime(date);
		pph.setUlimatransfusaohepatico(cal);
		}
		
		daopphepatico.atualiza(pph);
		
		return "true";
	}
	
	@RequestMapping(value = "gravarpancreatico", method = RequestMethod.POST)
	@ResponseBody
	@Transactional
	public String gravarpancreatico(@RequestParam("ulimatransfusaopancreatico") String ulimatransfusaopancreatico, @RequestParam("etnia") Long etnia, @RequestParam("peso") String peso, @RequestParam("altura") int altura,
			@RequestParam("transfusoes") int transfusoes, @RequestParam("gestacoes") int gestacoes, @RequestParam("imc") float imc,  @RequestParam("pertoraxico") int pertoraxico, 
			@RequestParam("diagnostico") int diagnostico, @RequestParam("observacoes") String observacoes,
			@RequestParam("rh") boolean rh, @RequestParam("abovalor") int abovalor, 
			@RequestParam("candidatoa") int candidatoa, @RequestParam("idrecetor") Long idrecetor, 
			@RequestParam("datadiagnostico") String datadiagnostico, @RequestParam("duracao") String duracao, @RequestParam("retinopatia") boolean retinopatia, 
			@RequestParam("retinonotas") String retinonotas, @RequestParam("arteriopatia") boolean arteriopatia, @RequestParam("arterionotas") String arterionotas, @RequestParam("neuropatia") boolean neuropatia, 
			@RequestParam("neuronotas") String neuronotas, HttpSession session) throws ParseException 
	{
		
		Long id_analiserecetor = (Long) session.getAttribute("id_analiserecetor");
		PPPancreatico ppp = daopppancreatico.ListaPPPancreaticoAnalise(id_analiserecetor);
		
		Etnia et = daoetnia.buscaPorId(etnia);
		
		RecetorDetalhes recetordetalhes = daorecetordetalhe.buscadetalhesrecetor(idrecetor);
		
		recetordetalhes.setAltura(altura);
		recetordetalhes.setEtnia(et);
		recetordetalhes.setPeso(Double.parseDouble(peso));
		recetordetalhes.setRh(rh);
		recetordetalhes.setAbo(abovalor);
		
		ppp.setDiagnosticopancreatico(diagnostico);
		ppp.setGestacoespancreatico(gestacoes);
		ppp.setCandidatoa(candidatoa);
		ppp.setImcpancreatico(imc);
		ppp.setObservacoespancreatico(observacoes);
		ppp.setPertoraxicopancreatico(pertoraxico);
		ppp.setTransfusoespancreatico(transfusoes);
		ppp.setRetinopatia(retinopatia);
		ppp.setRetinonotas(retinonotas);
		ppp.setArteriopatia(arteriopatia);
		ppp.setArterionotas(arterionotas);
		ppp.setNeuropatia(neuropatia);
		ppp.setNeuronotas(neuronotas);
		
		
		//-----tratamento datas vazias, pelo plugin Date vem a zero (01/01/1970)------------------------//
		if(!ulimatransfusaopancreatico.equals("01/01/1970")){
		DateFormat dum = new SimpleDateFormat("dd/MM/yyyy");
		Date date = dum.parse(ulimatransfusaopancreatico);
		Calendar cal = Calendar.getInstance();
		cal.setTime(date);
		ppp.setUlimatransfusaopancreatico(cal);
		}
		
		if(!datadiagnostico.equals("01/01/1970")){
		DateFormat dum = new SimpleDateFormat("dd/MM/yyyy");
		Date date2 = dum.parse(datadiagnostico);
		Calendar cal2 = Calendar.getInstance();
		cal2.setTime(date2);
		ppp.setDatadiagnostico(cal2);
		}
		daopppancreatico.atualiza(ppp);
		
		return "true";
	}

	@RequestMapping(value = "gravarcardiaco", method = RequestMethod.POST)
	@ResponseBody
	@Transactional
	public String gravarcardiaco(@RequestParam("ulimatransfusaocardiaco") String ulimatransfusaocardiaco, @RequestParam("etnia") Long etnia, @RequestParam("peso") String peso, @RequestParam("altura") int altura,
			@RequestParam("transfusoes") int transfusoes, @RequestParam("gestacoes") int gestacoes, @RequestParam("imc") float imc,  @RequestParam("pertoraxico") int pertoraxico, 
			@RequestParam("diagnostico") int diagnostico, @RequestParam("observacoes") String observacoes,  @RequestParam("idrecetor") Long idrecetor, 
			@RequestParam("rh") boolean rh, @RequestParam("abovalor") int abovalor, @RequestParam("bilirrubinacardiaco") float bilirrubinacardiaco,
			@RequestParam("creatininacardiaco") int creatininacardiaco, @RequestParam("tamaxcardiaco") int tamaxcardiaco, @RequestParam("tamincardiaco") int tamincardiaco, 
			@RequestParam("tadatamedicaocardiaco") String tadatamedicaocardiaco, @RequestParam("creatininadatamedicaocardiaco") String creatininadatamedicaocardiaco, 
			@RequestParam("bilirrubinadatamedicaocardiaco") String bilirrubinadatamedicaocardiaco, @RequestParam("classefunc") int classefunc, 
			@RequestParam("disfrenal") boolean disfrenal, @RequestParam("disfhepat") boolean disfhepat, HttpSession session) throws ParseException 
	{
		
		
		Long id_analiserecetor = (Long) session.getAttribute("id_analiserecetor");
		PPCardiaco ppc = daocardiaco.ListaPPCardiacoAnalise(id_analiserecetor);
		
		Etnia et = daoetnia.buscaPorId(etnia);
		RecetorDetalhes recetordetalhes = daorecetordetalhe.buscadetalhesrecetor(idrecetor);
		
		recetordetalhes.setAltura(altura);
		recetordetalhes.setEtnia(et);
		recetordetalhes.setPeso(Double.parseDouble(peso));
		recetordetalhes.setRh(rh);
		recetordetalhes.setAbo(abovalor);

		ppc.setDiagnosticocardiaco(diagnostico);
		ppc.setGestacoescardiaco(gestacoes);
		ppc.setImccardiaco(imc);
		ppc.setObservacoescardiaco(observacoes);
		ppc.setPertoraxicocardiaco(pertoraxico);

		ppc.setTransfusoescardiaco(transfusoes);
		ppc.setTamaxcardiaco(tamaxcardiaco);
		ppc.setTamincardiaco(tamincardiaco);
		ppc.setBilirrubinacardiaco(bilirrubinacardiaco);
		ppc.setCreatininacardiaco(creatininacardiaco);
		
		ppc.setClassefunc(classefunc);
		ppc.setDisfhepat(disfhepat);
		ppc.setDisfrenal(disfrenal);
		
		
		//-----tratamento datas vazias------------------------//
		if(!ulimatransfusaocardiaco.equals("01/01/1970")){
		DateFormat dum = new SimpleDateFormat("dd/MM/yyyy");
		Date date = dum.parse(ulimatransfusaocardiaco);
		Calendar cal = Calendar.getInstance();
		cal.setTime(date);
		ppc.setUlimatransfusaocardiaco(cal);
		}
		
		if(!tadatamedicaocardiaco.equals("01/01/1970")){
		DateFormat dum2 = new SimpleDateFormat("dd/MM/yyyy");
		Date date2 = dum2.parse(tadatamedicaocardiaco);
		Calendar cal2 = Calendar.getInstance();
		cal2.setTime(date2);
		ppc.setTadatamedicaocardiaco(cal2);		
		}
		
		if(!creatininadatamedicaocardiaco.equals("01/01/1970")){
		DateFormat dum3 = new SimpleDateFormat("dd/MM/yyyy");
		Date date3 = dum3.parse(creatininadatamedicaocardiaco);
		Calendar cal3 = Calendar.getInstance();
		cal3.setTime(date3);
		ppc.setCreatininadatamedicaocardiaco(cal3);
		}
		
		if(!bilirrubinadatamedicaocardiaco.equals("01/01/1970")){
		DateFormat dum4 = new SimpleDateFormat("dd/MM/yyyy");
		Date date4 = dum4.parse(bilirrubinadatamedicaocardiaco);
		Calendar cal4 = Calendar.getInstance();
		cal4.setTime(date4);
		ppc.setBilirrubinadatamedicaocardiaco(cal4);
		}
	
		daocardiaco.atualiza(ppc);
		
		return "true";
	}
	
	@RequestMapping(value = "gravarrenal", method = RequestMethod.POST)
	@ResponseBody
	@Transactional
	public String gravarrenal(@RequestParam("ulimatransfusaorenal") String ulimatransfusaorenal, @RequestParam("etnia") Long etnia, @RequestParam("peso") String peso, @RequestParam("altura") int altura,
			@RequestParam("transfusoesrenal") int transfusoesrenal, @RequestParam("gestacoes") int gestacoes, @RequestParam("imc") float imc,  @RequestParam("pertoraxico") int pertoraxico, 
			@RequestParam("diagnostico") int diagnostico, @RequestParam("observacoes") String observacoes, @RequestParam("retransplantado") boolean retransplantado, 
			@RequestParam("hb") boolean hb, @RequestParam("hc") boolean hc, @RequestParam("rh") boolean rh, @RequestParam("abovalor") int abovalor, @RequestParam("tratamento") int tratamento, 
			@RequestParam("iniciotratamentorenal") String iniciotratamentorenal, @RequestParam("biopsiarenal") boolean biopsiarenal, @RequestParam("cdialiserenal") int cdialiserenal, 
			@RequestParam("etiologiarenal") int etiologiarenal, @RequestParam("ltratamentorenal") int ltratamentorenal, @RequestParam("idrecetor") Long idrecetor,  HttpSession session) throws ParseException 
	{

		
		
		Long id_analiserecetor = (Long) session.getAttribute("id_analiserecetor");
		PPRenal ppr = daorenal.ListaPPRenalAnalise(id_analiserecetor);
		
		Etnia et = daoetnia.buscaPorId(etnia);

		RecetorDetalhes recetordetalhes = daorecetordetalhe.buscadetalhesrecetor(idrecetor);
		
		recetordetalhes.setAltura(altura);
		recetordetalhes.setEtnia(et);
		recetordetalhes.setPeso(Double.parseDouble(peso));
		recetordetalhes.setRh(rh);
		recetordetalhes.setAbo(abovalor);
		
		ppr.setDiagnosticorenal(diagnostico);
		ppr.setGestacoesrenal(gestacoes);
		ppr.setImcrenal(imc);
		ppr.setObservacoesrenal(observacoes);
		ppr.setPertoraxicorenal(pertoraxico);
		ppr.setRetransplantadorenal(retransplantado);
		ppr.setTransfusoesrenal(transfusoesrenal);
		ppr.setCdialiserenal(cdialiserenal);
		ppr.setEtiologiarenal(etiologiarenal);
		ppr.setLtratamentorenal(ltratamentorenal);
		
		//-----tratamento datas vazias------------------------//
		if(!ulimatransfusaorenal.equals("01/01/1970")){
		DateFormat dum = new SimpleDateFormat("dd/MM/yyyy");
		Date date = dum.parse(ulimatransfusaorenal);
		Calendar cal = Calendar.getInstance();
		cal.setTime(date);
		ppr.setUlimatransfusaorenal(cal);
		}
		
		if(!iniciotratamentorenal.equals("01/01/1970")){
		DateFormat dum2 = new SimpleDateFormat("dd/MM/yyyy");
		Date date2 = dum2.parse(iniciotratamentorenal);
		Calendar cal2 = Calendar.getInstance();
		cal2.setTime(date2);
		ppr.setIniciotratamentorenal(cal2);
		}
		
		daorenal.atualiza(ppr);
		
		return "true";
	}

	@RequestMapping(value = "gravardetalhesrecetor", method = RequestMethod.POST)
	@ResponseBody
	public String gravardetalhesrecetor(@RequestParam("nomerecetor") String nomerecetor, @RequestParam("moradarecetor") String moradarecetor, @RequestParam("localidaderecetor") String localidaderecetor, 
			@RequestParam("codpostalrecetor") String codpostalrecetor, @RequestParam("telefonerecetor") int telefonerecetor, @RequestParam("telemovelrecetor") int telemovelrecetor, 
			@RequestParam("datarecetor") String datarecetor, @RequestParam("emailrecetor") String emailrecetor, @RequestParam("orgaorecetor") int orgaorecetor, @RequestParam("unidaderecetor") Long unidaderecetor,
			@RequestParam("tiponumidentificacao") int tiponumidentificacao, @RequestParam("numidentificacao") int numidentificacao, @RequestParam("tiponumidentificacao2") int tiponumidentificacao2, 
			@RequestParam("numidentificacao2") int numidentificacao2, @RequestParam("sexorecetor") boolean sexorecetor, @RequestParam("tipocidadao") boolean tipocidadao, 
			@RequestParam("residencia") int residencia, @RequestParam("nacionalidade") int nacionalidade, @RequestParam("snsrecetor") int snsrecetor, @RequestParam("codigorecetor") String codigorecetor, HttpSession session) throws ParseException 
	{
		
		

		Recetores rec = daorecetor.buscaPorId((Long) session.getAttribute("id_recetor"));
		RecetorDetalhes recd = daorecetordetalhe.buscadetalhesrecetor((Long) session.getAttribute("id_recetor"));
		Paises nac = daopais.buscaPorId(nacionalidade);
		LocalResidencia res = daores.buscaPorId(residencia);
		
		DateFormat dum = new SimpleDateFormat("dd/MM/yyyy, HH:mm");
		Date date = dum.parse(datarecetor);
		Calendar cal = Calendar.getInstance();
		cal.setTime(date);
		
		recd.setNumidentificacao(numidentificacao);
		recd.setNumidentificacao2(numidentificacao2);
		recd.setResidencia(res);
		recd.setSexo(sexorecetor);
		recd.setTipocidadao(tipocidadao);
		recd.setTiponumidentificacao(tiponumidentificacao);
		recd.setTiponumidentificacao2(tiponumidentificacao2);
		recd.setNacionalidade(nac);
		recd.setCodpostalrecetor(codpostalrecetor);
		recd.setEmailrecetor(emailrecetor);
		recd.setLocalidaderecetor(localidaderecetor);
		recd.setMoradarecetor(moradarecetor);
		recd.setTipocidadao(tipocidadao);
		recd.setTelefone(telefonerecetor);

		if(recd.getTelemovel()!= telemovelrecetor){

			recd.setTelemovel(telemovelrecetor);
			
	    	//enviar sms user candidato 2 se telem�vel tiver alterado:

			String pin = gerapin();
			while(daorecetordetalhe.verificaexistepin(pin)){
				pin = gerapin();
			}
			recd.setPin(Integer.parseInt(pin));
			
				SMSController sms = new SMSController();
	    	sms.sms(Integer.toString(recd.getTelemovel()), pin, 2);
		}
		
		recd.setDatanascimento(cal);
		
		daorecetordetalhe.atualiza(recd);
		
		UnidadeTransplante uni = daounidtransp.buscaPorId(unidaderecetor);

		rec.setNomerecetor(nomerecetor);
		rec.setSns(snsrecetor);
		rec.setCodigorecetor(codigorecetor);
		rec.setUnidadetransp(uni);
		OrgaosOferta orgao = daoorgaooferta.buscaPorId(orgaorecetor);
		rec.setOrgao(orgao);
		
		daorecetor.atualiza(rec);

		return "true";
	}

	
	@RequestMapping(value = "carreganovagravidade")
	@Transactional
	public String carreganovagravidade(@RequestParam("gravidade") Long gravidade, @RequestParam("datagravidade") String datagravidade, @RequestParam("notasgravidade") String notasgravidade, Model model, HttpSession session) throws ParseException 
	{
		Long id_analiserecetor = (Long) session.getAttribute("id_analiserecetor");
		GravidadeRecetor gravrec = new GravidadeRecetor();
		AnaliseRecetor analiserec = daoanaliserecetor.buscaPorId(id_analiserecetor);
		GravidadeOrgao gravorg = daogravorgao.buscaPorId(gravidade);
		
		DateFormat dum = new SimpleDateFormat("dd/MM/yyyy, HH:mm");
		Date date = dum.parse(datagravidade);
		Calendar cal = Calendar.getInstance();
		cal.setTime(date);
		
		gravrec.setDatagravidade(cal);
		gravrec.setGravorg(gravorg);
		gravrec.setNotas(notasgravidade);
		gravrec.setAnaliserecetor(analiserec);
		
		daogravrecetor.adiciona(gravrec);
		
		model.addAttribute("gravidaderecetor", daogravrecetor.buscagravidaderecetor(id_analiserecetor));
		
		return "/pptransplante/divgravidade";
	}
	
	@RequestMapping(value = "alteragravidade")
	@Transactional
	public String alteragravidade(@RequestParam("gravidade") Long gravidade, @RequestParam("notas") String notas, @RequestParam("id") Long id, Model model, HttpSession session) 
	{
		Long id_analiserecetor = (Long) session.getAttribute("id_analiserecetor");
		GravidadeRecetor gravrec = daogravrecetor.buscaPorId(id);
		GravidadeOrgao gravorg = daogravorgao.buscaPorId(gravidade);
		
		gravrec.setGravorg(gravorg);
		gravrec.setNotas(notas);

		daogravrecetor.atualiza(gravrec);
		
		model.addAttribute("gravidaderecetor", daogravrecetor.buscagravidaderecetor(id_analiserecetor));
		
		return "/pptransplante/divgravidade";
	}
	
	@RequestMapping(value = "removegravidade")
	@Transactional
	public String removegravidade(@RequestParam("id") Long id, Model model, HttpSession session) 
	{
		Long id_analiserecetor = (Long) session.getAttribute("id_analiserecetor");
		GravidadeRecetor gravrec = daogravrecetor.buscaPorId(id);
		
		daogravrecetor.remove(gravrec);
		
		model.addAttribute("gravidaderecetor", daogravrecetor.buscagravidaderecetor(id_analiserecetor));
		
		return "/pptransplante/divgravidade";
	}
	
	@RequestMapping(value = "revalidagravidade")
	@Transactional
	public String revalidagravidade(Model model, HttpSession session) 
	{
		Long id_analiserecetor = (Long) session.getAttribute("id_analiserecetor");
		
		GravidadeRecetor gravrec = new GravidadeRecetor();
		GravidadeOrgao gravorg = new GravidadeOrgao();
		AnaliseRecetor anarec = daoanaliserecetor.buscaPorId(id_analiserecetor);
		
		GravidadeRecetor grav = daogravrecetor.buscaUltimaGravidadeRecetor(id_analiserecetor).get(0);
		gravrec.setNotas(grav.getNotas());
		
		gravorg = grav.getGravorg();
		gravrec.setGravorg(gravorg);
		gravrec.setAnaliserecetor(anarec);
		gravrec.setDatagravidade(grav.getDatagravidade());
		
		daogravrecetor.adiciona(gravrec);
		
		model.addAttribute("gravidaderecetor", daogravrecetor.buscagravidaderecetor(id_analiserecetor));
		
		return "/pptransplante/divgravidade";
	}
	
	@RequestMapping(value = "alteraestadocandidato")
	@Transactional
	public String alteraestadocandidato(@RequestParam("estado") int estado, @RequestParam("notas") String notas, @RequestParam("id") Long id, @RequestParam("data") String data, @RequestParam("tipo") int tipo, 
			@RequestParam("jejum") boolean jejum, @RequestParam("urina") boolean urina, Model model, HttpSession session) throws ParseException 
	{
		Long id_analiserecetor = (Long) session.getAttribute("id_analiserecetor");

		EstadoRecetor estrec = daoestado.buscaPorId(id);
		
		DateFormat dum = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss");
	
		if(!data.isEmpty() && data != null){
			
			Date date = dum.parse(data);
			Calendar cal = Calendar.getInstance();
			cal.setTime(date);
			estrec.setData(cal);	
		}else{
			estrec.setData(null);
		}
		
		estrec.setJejum(jejum);
		estrec.setUrina(urina);
		estrec.setTipo(tipo);
		estrec.setEstado(estado);
		estrec.setNotas(notas);
		
		daoestado.atualiza(estrec);
		
/*		if(estado==5){
		mudaestadorecetor((Long) session.getAttribute("id_recetor"));
		}*/
		
		model.addAttribute("estadoecetor", daoestado.buscaestadorecetor(id_analiserecetor));
		
		return "/pptransplante/divestado";
	}
	
	@RequestMapping(value = "removeestado")
	@Transactional
	public String removeestado(@RequestParam("id") Long id, Model model, HttpSession session) 
	{
		Long id_analiserecetor = (Long) session.getAttribute("id_analiserecetor");
		EstadoRecetor estrec = daoestado.buscaPorId(id);
		
		daoestado.remove(estrec);
		
		model.addAttribute("estadoecetor", daoestado.buscaestadorecetor(id_analiserecetor));
		
		return "/pptransplante/divestado";
	}
	
	@RequestMapping(value = "carreganovoestado")
	@Transactional
	public String carreganovoestado(@RequestParam("data") String data, @RequestParam("tipo") int tipo, @RequestParam("estado") int estado, @RequestParam("notas") String notas, 
			@RequestParam("jejum") boolean jejum, @RequestParam("urina") boolean urina, Model model, HttpSession session) throws ParseException 
	{
		Long id_analiserecetor = (Long) session.getAttribute("id_analiserecetor");
		AnaliseRecetor analiserec = daoanaliserecetor.buscaPorId(id_analiserecetor);
		
		
		EstadoRecetor estrec = new EstadoRecetor();
		
		
		DateFormat dum = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss");
		
		if(!data.isEmpty() && data != null){
			
			Date date = dum.parse(data);
			Calendar cal = Calendar.getInstance();
			cal.setTime(date);
			estrec.setData(cal);	
		}else{
			estrec.setData(null);
		}
		
		estrec.setJejum(jejum);
		estrec.setUrina(urina);
		estrec.setTipo(tipo);
		estrec.setEstado(estado);
		estrec.setNotas(notas);
		//estrec.setData(cal);
		estrec.setAnaliserecetor(analiserec);
		
		Utilizador user = new Utilizador();
		user.setID_Utilizador((Long)session.getAttribute("iduser"));
		estrec.setUser(user);
		
		daoestado.adiciona(estrec);
/*		if(estado==5){
		mudaestadorecetor((Long) session.getAttribute("id_recetor"));
		}*/
		model.addAttribute("estadoecetor", daoestado.buscaestadorecetor(id_analiserecetor));
		
		return "/pptransplante/divestado";
	}
	
	
	@RequestMapping(value = "carreganovoestadomedicacao")
	@Transactional
	@ResponseBody
	public String carreganovoestadomedicacao(@RequestParam("data") String data, @RequestParam("tipo") int tipo, @RequestParam("estado") int estado, @RequestParam("notas") String notas,
			@RequestParam("jejum") boolean jejum, @RequestParam("urina") boolean urina, HttpSession session) throws ParseException 
	{
		Long id_analiserecetor = (Long) session.getAttribute("id_analiserecetor");
		AnaliseRecetor analiserec = daoanaliserecetor.buscaPorId(id_analiserecetor);
		
		DateFormat dum = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss");
		Date date = dum.parse(data);
		Calendar cal = Calendar.getInstance();
		cal.setTime(date);
		
		Utilizador user = new Utilizador();
		user.setID_Utilizador((Long)session.getAttribute("iduser"));
		
		EstadoRecetor estrec = new EstadoRecetor();
		estrec.setTipo(tipo);
		estrec.setEstado(estado);
		estrec.setNotas(notas);
		estrec.setData(cal);
		estrec.setAnaliserecetor(analiserec);
		estrec.setJejum(jejum);
		estrec.setUrina(urina);
		estrec.setUser(user);
		
		daoestado.adiciona(estrec);
/*		if(estado==5){
		mudaestadorecetor((Long) session.getAttribute("id_recetor"));
		}*/
		//model.addAttribute("estadoecetor", daoestado.buscaestadorecetor(id_analiserecetor));
		
		return estrec.getId_estadorecetor().toString();
	}
	
	@RequestMapping(value = "refrescatabestadorecetor")
	@Transactional
	public String refrescatabestadorecetor(Model model, HttpSession session) throws ParseException 
	{
		Long id_analiserecetor = (Long) session.getAttribute("id_analiserecetor");
		
		model.addAttribute("estadoecetor", daoestado.buscaestadorecetor(id_analiserecetor));
		
		return "/pptransplante/divestado";
	}

	
	@RequestMapping(value = "adicionamedicamento")
	@Transactional
	public String adicionamedicamento(@RequestParam("idestado") Long idestado, @RequestParam("nome") String nome, @RequestParam("dose") String dose, @RequestParam("periodicidade") int periodicidade, @RequestParam("qtddias") int qtddias, @RequestParam("notas") String notas, Model model, HttpSession session) throws ParseException 
	{
		//Long id_analiserecetor = (Long) session.getAttribute("id_analiserecetor");
		
		EstadoRecetor estrec = daoestado.buscaPorId(idestado);
		
		MedicamentosPreTransp med = new MedicamentosPreTransp();
		
		med.setNome(nome);
		med.setDosagem(dose);
		med.setPeriodicidade(periodicidade);
		med.setNumdias(qtddias);
		med.setNotas(notas);
		med.setMarcacao(estrec);

		
		daomedicamentopretransp.adiciona(med);

		model.addAttribute("medicamentospretransp", daomedicamentopretransp.buscamedicamentosmarcacao(estrec.getId_estadorecetor()));
		
		return "/pptransplante/load/tabmedicacao";
	}
	
	
	@RequestMapping(value = "carregatabelamedicacao")
	@Transactional
	public String carregatabelamedicacao(@RequestParam("idestado") Long idestado, Model model, HttpSession session) throws ParseException 
	{

		model.addAttribute("medicamentospretransp", daomedicamentopretransp.buscamedicamentosmarcacao(idestado));
		
		return "/pptransplante/load/tabmedicacao";
	}
	
	
	@RequestMapping(value = "removemedicamento")
	@ResponseBody
	public String removemedicamento(@RequestParam("idmedicamento") Long idmedicamento) throws ParseException 
	{
		MedicamentosPreTransp med = new MedicamentosPreTransp();
		med.setIdmedicamento(idmedicamento);

		daomedicamentopretransp.remove(med);
		
		return "true";
	}
	
	
	@RequestMapping(value = "gravaeditmedicamento")
	@Transactional
	public String gravaeditmedicamento(@RequestParam("idmedicamento") Long idmedicamento, @RequestParam("idestado") Long idestado, @RequestParam("nome") String nome, @RequestParam("dose") String dose, @RequestParam("periodicidade") int periodicidade, @RequestParam("qtddias") int qtddias, @RequestParam("notas") String notas, Model model, HttpSession session) throws ParseException 
	{
		//Long id_analiserecetor = (Long) session.getAttribute("id_analiserecetor");
		
	
		
		MedicamentosPreTransp med = daomedicamentopretransp.buscaPorId(idmedicamento);
		
		med.setNome(nome);
		med.setDosagem(dose);
		med.setPeriodicidade(periodicidade);
		med.setNumdias(qtddias);
		med.setNotas(notas);

		
		daomedicamentopretransp.atualiza(med);

		model.addAttribute("medicamentospretransp", daomedicamentopretransp.buscamedicamentosmarcacao(idestado));
		
		return "/pptransplante/load/tabmedicacao";
	}
	
/*	public void mudaestadorecetor(Long idrecetor) 
	{
		Recetores rec = daorecetor.buscaPorId(idrecetor);
		
		//verificar se recetor j� foi colocado como transplantado, se sim abortar:
		if(!daotransp.buscaseexiste(rec.getId_recetor())){ //se n�o existe
			
		
			RecetorDetalhes recdet = daorecetordetalhe.buscadetalhesrecetor(idrecetor);
			
			Transplantes novotransp = new Transplantes();
			TransplantadoDetalhes transpdet = new TransplantadoDetalhes();
			
			novotransp.setCodigotransplantado(rec.getCodigorecetor());
			novotransp.setNometransplantado(rec.getNomerecetor());
			novotransp.setSns(rec.getSns());
			novotransp.setHospital(rec.getHospital());
			novotransp.setUnidadetransp(rec.getUnidadetransp());
			novotransp.setEstadotransplantado(1);
			novotransp.setDatatransplante(Calendar.getInstance());
			novotransp.setRecetor(rec);
			
			OrgaosOferta orgaosof = new OrgaosOferta();
			Long idut = rec.getUnidadetransp().getId_unidadetransplante();
			if(idut==1L){
				orgaosof.setIdorgoferta(1);
			}else if(idut==2L){
				orgaosof.setIdorgoferta(2);
			}else if(idut==3L){
				orgaosof.setIdorgoferta(3);
			}else if(idut==4L){
				orgaosof.setIdorgoferta(6);
			}else if(idut==5L){
				orgaosof.setIdorgoferta(7);
			}
			
			Orgaos orgaos = new Orgaos();
			orgaos.setId_Orgao(idut);
			novotransp.setOrgaos(orgaos);
			novotransp.setOrgaosoferta(orgaosof);
			
			daotransp.adiciona(novotransp);
			
			transpdet.setCodpostaltranplantado(recdet.getCodpostalrecetor());
			transpdet.setDatanascimentotransplantado(recdet.getDatanascimento());
			transpdet.setEmailtranplantado(recdet.getEmailrecetor());
			transpdet.setLocalidadetranplantado(recdet.getLocalidaderecetor());
			transpdet.setMoradatranplantado(recdet.getMoradarecetor());
			transpdet.setNacionalidadetransplantado(recdet.getNacionalidade());
			transpdet.setNumidentificacaotransplantado(recdet.getNumidentificacao());
			transpdet.setNumidentificacaotransplantado2(recdet.getNumidentificacao2());
			transpdet.setResidenciatransplantado(recdet.getResidencia());
			transpdet.setSexotransplantado(recdet.isSexo());
			transpdet.setTelefonetransplantado(recdet.getTelefone());
			transpdet.setTelemoveltransplantado(recdet.getTelemovel());
			transpdet.setTipocidadaotransplantado(recdet.isTipocidadao());
			transpdet.setTiponumidentificacaotransplantado(recdet.getTiponumidentificacao());
			transpdet.setTiponumidentificacaotransplantado2(recdet.getTiponumidentificacao2());
			transpdet.setTranplantado(novotransp);
			
			daotranspdet.adiciona(transpdet);
		}
	}*/
	
	@RequestMapping(value = "removerecetor")
	public String removerecetor(@RequestParam("idrecetor") Long idrecetor, Model model, HttpSession session) 
	{
		
		
		Long id_hosp = daohospital.buscaIdHospital((String) session.getAttribute("localizacao"));
		model.addAttribute("recetores", daorecetor.buscarecetoreshospital(id_hosp));
		
		return "/pptransplante/divtotalrecetor";
	}
	
	@RequestMapping(value = "abredetalherecetor")
	public String abredetalherecetor(Long id, Model model, HttpSession session) 
	{
		session.setAttribute("id_recetor", id);	
		
		AnaliseRecetor analiserecetor = new AnaliseRecetor();

		analiserecetor = daoanaliserecetor.buscaAnaliseRecetor(id);
	//	System.out.println("id_analise: "+analiserecetor.getId_analiserecetor());
		session.setAttribute("id_analiserecetor", analiserecetor.getId_analiserecetor());
		
		Recetores recetor = daorecetor.buscaPorId(id);
			
		model.addAttribute("recetor", recetor);
		
		model.addAttribute("detalherecetor", daorecetordetalhe.buscadetalhesrecetor(id));
		
		Long id_h = daohospital.buscaIdHospital((String) session.getAttribute("localizacao"));
		
		model.addAttribute("unidaderecetor", daounidtransp.buscaUnidadesporHosp(id_h));
		//System.out.println("asdadasd: "+daorecetor.buscaPorId(id).getUnidadetransp().getId_unidadetransplante());
		//model.addAttribute("listaorgaos2", daoorgaos.buscaOrgaosporUnidade(daorecetor.buscaPorId(id).getUnidadetransp().getId_unidadetransplante()));
		model.addAttribute("listaorgaos2", daoorgaooferta.buscaOrgaosporUnidade(recetor.getUnidadetransp().getId_unidadetransplante()));
		model.addAttribute("paises", daopais.ListaPaises());
		model.addAttribute("residencia", daores.ListaLocalResidencia());
				
		return "/pptransplante/divdetalherecetor";
	}
	
	@RequestMapping(value = "abredadosclinicosrecetor")
	public String abredadosclinicosrecetor(@RequestParam("idorgao") int idorgao, Model model, HttpSession session) 
	{
		Long id_analiserecetor = (Long) session.getAttribute("id_analiserecetor");
		model.addAttribute("etniarecetor", daoetnia.ListaEtnia());
		
		Long id_recetor = (Long) session.getAttribute("id_recetor");
		model.addAttribute("detalherecetor", daorecetordetalhe.buscadetalhesrecetor(id_recetor));
		
		//model.addAttribute(attributeName, recetordetalhes);
		
	//	System.out.println("idorgao: "+idorgao);
		if(idorgao == 3 || idorgao == 4 || idorgao == 5)
		{
			model.addAttribute("pppulmonar", daopppulmonar.ListaPPPulmonarAnalise(id_analiserecetor));
			
			return "/pptransplante/divpulmonar";
		}
		else if(idorgao == 2)
		{
			model.addAttribute("pphepatico", daopphepatico.ListaPPHepaticoAnalise(id_analiserecetor));
			model.addAttribute("comorbilidades", daopphepaticocomorb.ListaPPHepaticoComorbilidadesAnalise(id_analiserecetor));
			model.addAttribute("diagnostico", daopphepaticodiag.ListaPPHepaticoDiagnosticoAnalise(id_analiserecetor));	
			model.addAttribute("tipodiagnostico", daotipodiag.ListaTipoDiagnostico());	
			model.addAttribute("complicacoes", daopphepaticocompl.ListaPPHepaticoComplicacoesAnalise(id_analiserecetor));
			model.addAttribute("tipocomplicacao", daotipocompl.ListaTipoComplicacoes());
			
			return "/pptransplante/divfigado";
		}
		else if(idorgao == 6)
		{
			model.addAttribute("pppancreatico", daopppancreatico.ListaPPPancreaticoAnalise(id_analiserecetor));
			
			return "/pptransplante/divpancreas";
		}
		else if(idorgao == 7 || idorgao == 8 || idorgao == 9)
		{
			model.addAttribute("pprenal", daorenal.ListaPPRenalAnalise(id_analiserecetor));
			
			model.addAttribute("recetor", daorecetor.buscaPorId((Long) session.getAttribute("id_recetor")));
			return "/pptransplante/divrenal";
		}
		else
		{
			model.addAttribute("ppcardiaco", daocardiaco.ListaPPCardiacoAnalise(id_analiserecetor));
			
			return "/pptransplante/divcoracao";
		}
	}
	
	@RequestMapping(value = "abregravidaderecetor")
	public String abregravidaderecetor(Model model, HttpSession session) 
	{
		  Long id_analiserecetor = (Long) session.getAttribute("id_analiserecetor");
		  Long id_recetor = (Long) session.getAttribute("id_recetor");
		  int idorgao = daorecetor.buscaidorgaorecetor(id_recetor);
		  
		  model.addAttribute("recetororgao", daorecetor.buscaPorId((Long) session.getAttribute("id_recetor")));
		  model.addAttribute("gravidaderecetor", daogravrecetor.buscagravidaderecetor(id_analiserecetor));
		  model.addAttribute("gravidadeorgao", daogravorgao.buscagravidadeorgao(idorgao));
		  
		return "/pptransplante/divdetalhegravidade";
	}
	
	@RequestMapping(value = "abrehistoricorecetor")
	public String abrehistoricorecetor(Model model, HttpSession session) 
	{
		Long id_recetor = (Long) session.getAttribute("id_recetor");
		
		Long idhosp = daorecetor.buscaPorId(id_recetor).getHospital().getId_Hospital();
		String orgao = daorecetor.buscaPorId(id_recetor).getOrgao().getNomeorgaooferta();
		int sns = daorecetor.buscaPorId(id_recetor).getSns();
		
		
		if(daorecetor.pesquisahistorico(idhosp, orgao, sns))
		{
			model.addAttribute("historicorecetorgravidade", daorecetor.listaHistorico(idhosp, orgao, sns));
			model.addAttribute("historicorecetordata", daorecetor.listaHistoricodata(idhosp, orgao, sns));
			model.addAttribute("historicorecetorunidade", daorecetor.listaHistoricounidade(idhosp, sns, id_recetor, orgao, (Long)session.getAttribute("idlocalizacao")));
		}
		
		model.addAttribute("historicotransp", daopphistorico.buscahistoricocandidato(sns));
		
		return "/pptransplante/divdetalhehistorico";
	}
	
	@RequestMapping(value = "abreestadorecetor")
	public String abreestadorecetor(Model model, HttpSession session) 
	{
		Long id_analiserecetor = (Long) session.getAttribute("id_analiserecetor");
		model.addAttribute("estadoecetor", daoestado.buscaestadorecetor(id_analiserecetor));

		return "/pptransplante/divdetalheestadocand";
	}
	
	@RequestMapping(value = "abreanalisesrecetor")
	public String abreanalisesrecetor(Model model, HttpSession session) 
	{
		Long id_analiserecetor = (Long) session.getAttribute("id_analiserecetor");
		model.addAttribute("amostras", daoanalise.buscaamostrasanaliseDescendente(id_analiserecetor));
	//	model.addAttribute("tipoamostras", daotipoamostra.ListaTipoAmostra());
		model.addAttribute("unidades", daounid.ListaUnidadesGeral());
		
		return "/pptransplante/divdetalheanalises";
	}
	
	@RequestMapping(value = "abregeralrecetor")
	public String abregeralrecetor(Model model, HttpSession session) 
	{
		Long id_analiserecetor = (Long) session.getAttribute("id_analiserecetor");
		model.addAttribute("geralrecetor", daogeralrec.buscageralrecetor(id_analiserecetor));

		return "/pptransplante/divdetalhegeral";
	}
	
	@RequestMapping(value = "gravargeralrecetor", method = RequestMethod.POST)
	@ResponseBody
	@Transactional
	public String gravargeralrecetor(GeralRecetor gr, HttpSession session, Model model) 
	{
		Long id_analiserecetor = (Long) session.getAttribute("id_analiserecetor");
		GeralRecetor gr2 = daogeralrec.buscageralrecetor(id_analiserecetor);

		gr2.setCapacidadefisica(gr.getCapacidadefisica());
		gr2.setDesfimplantado(gr.isDesfimplantado());
		gr2.setDialise(gr.isDialise());
		gr2.setEventocerebrovascular(gr.isEventocerebrovascular());
		gr2.setHospitalizado(gr.isHospitalizado());
		gr2.setIntcardant(gr.isIntcardant());
		gr2.setIntpulmant(gr.isIntpulmant());
		gr2.setNotasgeral(gr.getNotasgeral());
		gr2.setOutros(gr.isOutros());
		gr2.setSupventant(gr.isSupventant());
		gr2.setTipoacademica(gr.getTipoacademica());
		gr2.setTipoatividade(gr.getTipoatividade());
		gr2.setTipotrabalho(gr.getTipotrabalho());
		gr2.setTratamentoiv(gr.isTratamentoiv());
		
		daogeralrec.atualiza(gr2);
		
		return "true";
	}
	
	@RequestMapping(value = "abrecontatosrecetor")
	public String abrecontatosrecetor(Model model, HttpSession session) 
	{
		Long id_analiserecetor = (Long) session.getAttribute("id_analiserecetor");
		model.addAttribute("contatosrecetor", daocontrecetor.buscacontatosrecetor(id_analiserecetor));
		
		return "/pptransplante/divdetalhecontatos";
	}
	
	@RequestMapping(value = "carreganovocontato")
	@Transactional
	public String carreganovocontato(@RequestParam("nome") String nome, @RequestParam("telefone") String telefone, @RequestParam("telefone2") String telefone2, @RequestParam("email") String email, Model model, HttpSession session) 
	{
		Long id_analiserecetor = (Long) session.getAttribute("id_analiserecetor");
		AnaliseRecetor analiserec = daoanaliserecetor.buscaPorId(id_analiserecetor);

		daocontrecetor.adicionacontato(nome, telefone, telefone2, email, analiserec);
		
		model.addAttribute("contatosrecetor2", daocontrecetor.buscacontatosrecetor(id_analiserecetor));
		
		return "/pptransplante/divcontatos";
	}
	
	@RequestMapping(value = "removecontato")
	@Transactional
	public String removecontato(@RequestParam("id") Long id, Model model, HttpSession session) 
	{
		Long id_analiserecetor = (Long) session.getAttribute("id_analiserecetor");
		ContatosRecetor cont = daocontrecetor.buscaPorId(id);
		
		daocontrecetor.remove(cont);
		
		model.addAttribute("contatosrecetor2", daocontrecetor.buscacontatosrecetor(id_analiserecetor));
		
		return "/pptransplante/divcontatos";
	}

	@RequestMapping(value = "alteracontato")
	@Transactional
	public String alteracontato(@RequestParam("nome") String nome, @RequestParam("telefone") String telefone, @RequestParam("telefone2") String telefone2, @RequestParam("email") String email, 
			@RequestParam("id") Long id, Model model, HttpSession session) 
	{
		Long id_analiserecetor = (Long) session.getAttribute("id_analiserecetor");
		ContatosRecetor cont2 = daocontrecetor.buscaPorId(id);
		
		cont2.setEmail(email);
		cont2.setNome(nome);
		cont2.setTelefone(telefone);
		cont2.setTelefone2(telefone2);

		daocontrecetor.atualiza(cont2);
		
		model.addAttribute("contatosrecetor2", daocontrecetor.buscacontatosrecetor(id_analiserecetor));
		
		return "/pptransplante/divcontatos";
	}
	
	@RequestMapping(value = "abredivnovorecetor")
	public String abredivnovorecetor(Model model, HttpSession session) 
	{
		Long id_h = daohospital.buscaIdHospital((String) session.getAttribute("localizacao"));
		
		model.addAttribute("listaunidades", daounidtransp.buscaUnidadesporHosp(id_h));
	//	model.addAttribute("listaorgaos", daoorgaos.ListaOrgaos());
		model.addAttribute("paises", daopais.ListaPaises());
		model.addAttribute("residencia", daores.ListaLocalResidencia());
		
		return "/pptransplante/divnovorecetor";
	}
	
	@RequestMapping(value = "salvarnovorecetor")
	@ResponseBody
	@Transactional
	public String salvarnovorecetor(@RequestParam("nomerecetornovo") String nomerecetornovo, @RequestParam("moradarecetornovo") String moradarecetornovo, @RequestParam("localidaderecetornovo") String localidaderecetornovo, 
			@RequestParam("codpostalrecetornovo") String codpostalrecetornovo, @RequestParam("telefonerecetornovo") int telefonerecetornovo, @RequestParam("telemovelrecetornovo") int telemovelrecetornovo, 
			@RequestParam("datarecetornovo") String datarecetornovo, @RequestParam("emailrecetornovo") String emailrecetornovo, @RequestParam("unidaderecetornovo") Long unidaderecetornovo, 
			@RequestParam("orgaorecetornovo") int orgaorecetornovo, @RequestParam("tipoidentrecetornovo") int tipoidentrecetornovo, @RequestParam("numidentificacaorecetornovo") int numidentificacaorecetornovo, 
			@RequestParam("tipoidentrecetornovo2") int tipoidentrecetornovo2, @RequestParam("numidentificacaorecetornovo2") int numidentificacaorecetornovo2, @RequestParam("sexorecetornovo") boolean sexorecetornovo, 
			@RequestParam("tipocidadaorecetornovo") boolean tipocidadaorecetornovo, @RequestParam("residenciarecetornovo") int residenciarecetornovo, 
			@RequestParam("nacioalidaderecetornovo") int nacioalidaderecetornovo, @RequestParam("snsrecetornovo") int snsrecetornovo, Model model, HttpSession session) throws ParseException
	{
		
		
		String resp = "";
		
		Long id_h = (Long) session.getAttribute("idlocalizacao");
		
		if(daorecetor.verificainscricoes(id_h, daoorgaooferta.buscaPorId(orgaorecetornovo).getIdorgoferta(), snsrecetornovo))
		{
			resp = "O utente j� se encontra registado no sistema com o org�o e hospital pretendido.";
		}
		else
			if(daorecetor.verificainscricoeshospitais(orgaorecetornovo, snsrecetornovo))
			{
				resp = "O utente j� se encontra registado no sistema com o org�o pretendido em dois hospitais.";
			}
			else
			{
				Recetores rec = new Recetores();
				Hospital h = daohospital.buscaPorId(id_h);
				UnidadeTransplante unid = daounidtransp.buscaPorId(unidaderecetornovo);
				Paises nacionalidade = daopais.buscaPorId(nacioalidaderecetornovo);
				LocalResidencia residencia = daores.buscaPorId(residenciarecetornovo);
				
				DateFormat dum = new SimpleDateFormat("dd/MM/yyyy, HH:mm");
				Date date = dum.parse(datarecetornovo);
				Calendar cal = Calendar.getInstance();
				cal.setTime(date);
				
				rec.setCodigorecetor("PTA");
				rec.setDataregisto(Calendar.getInstance());
				rec.setNomerecetor(nomerecetornovo);
				OrgaosOferta orgao = new OrgaosOferta();
				orgao.setIdorgoferta(orgaorecetornovo);
				rec.setOrgao(orgao);
				//rec.setOrgaos(org);
				rec.setHospital(h);
				rec.setSns(snsrecetornovo);
				rec.setUnidadetransp(unid);
				
				Utilizador utilizador = new Utilizador();
				utilizador.setID_Utilizador((Long) session.getAttribute("iduser"));
				rec.setUtilizador(utilizador);
				daorecetor.adiciona(rec);
				
				RecetorDetalhes det = new RecetorDetalhes();
				
				det.setRecetor(rec);
				det.setCodpostalrecetor(codpostalrecetornovo);
				det.setDatanascimento(cal);
				det.setEmailrecetor(emailrecetornovo);
				det.setLocalidaderecetor(localidaderecetornovo);
				det.setMoradarecetor(moradarecetornovo);
				det.setNacionalidade(nacionalidade);
				det.setNumidentificacao(numidentificacaorecetornovo);
				det.setNumidentificacao2(numidentificacaorecetornovo2);
				det.setResidencia(residencia);
				det.setSexo(sexorecetornovo);
				det.setTelefone(telefonerecetornovo);
				det.setTelemovel(telemovelrecetornovo);
				det.setTipocidadao(tipocidadaorecetornovo);
				det.setTiponumidentificacao(tipoidentrecetornovo);
				det.setTiponumidentificacao2(tipoidentrecetornovo2);
				
				String pin = gerapin();
				while(daorecetordetalhe.verificaexistepin(pin)){
					pin = gerapin();
				}
				det.setPin(Integer.parseInt(pin));
				
				daorecetordetalhe.adiciona(det);
				
		    	//enviar sms user paciente = 2
				   SMSController sms = new SMSController();
				    sms.sms(Integer.toString(det.getTelemovel()), pin,2);
				
				AnaliseRecetor analiserecetor = new AnaliseRecetor();
				
				analiserecetor.setRecetor(rec);
				daoanaliserecetor.adiciona(analiserecetor);

				GeralRecetor grec = new GeralRecetor();
				grec.setAnaliserecetor(analiserecetor);
					
				daogeralrec.adiciona(grec);
				
				if(unidaderecetornovo == 1)
				{
					PPCardiaco ppcard = new PPCardiaco();
					ppcard.setAnaliserecetor(analiserecetor);
					
					daocardiaco.adiciona(ppcard);
				}
				else 
				if(unidaderecetornovo == 2)
				{					
					PPHepatico pphep = new PPHepatico();
					pphep.setAnaliserecetor(analiserecetor);
					
					daopphepatico.adiciona(pphep);
				}
				else
				if(unidaderecetornovo == 3)
				{
					
					PPPulmonar pppulm = new PPPulmonar();
					pppulm.setAnaliserecetor(analiserecetor);
					
					daopppulmonar.adiciona(pppulm);
				}
				else
				if(unidaderecetornovo == 4)
				{
					
					PPPancreatico pppanc = new PPPancreatico();
					pppanc.setAnaliserecetor(analiserecetor);
					
					daopppancreatico.adiciona(pppanc);
				}
				else
				if(unidaderecetornovo == 5)
				{
					
					PPRenal ppren = new PPRenal();
					ppren.setAnaliserecetor(analiserecetor);
					
					daorenal.adiciona(ppren);
				}
				
				
				//carrega virologias a editar
				daovirorecetor.carregaamostrasvirologiarecetorpretransf(analiserecetor.getId_analiserecetor());
				
				
				resp = rec.getId_recetor().toString();
			}
		return resp;
	}
	
    private String gerapin() {
    	Random r = new Random();
    	List<Integer> codes = new ArrayList<>();
    	for (int i = 0; i < 10; i++)
    	{
    	    int x = r.nextInt(999999);
    	    while (codes.contains(x))
    	        x = r.nextInt(999999);
    	    codes.add(x);
    	}
    	String str = String.format("%06d", codes.get(0));
    	return str;
	}
	
	@RequestMapping("verificaestados")
	@ResponseBody
	public String verificaestados(Model model , HttpSession session) 
	{
		if((int) session.getAttribute("verestados") == 0)
		{
			Long id_hosp = daohospital.buscaIdHospital((String) session.getAttribute("localizacao"));
		
			if(daorecetor.verificaestado(id_hosp))
			{
				session.setAttribute("verestados", 1);	
				return "1";
			}
			else
			{
				session.setAttribute("verestados", 1);
				
				return "2";
			}
		}
		else
			return "2";
	}
	
	
	@RequestMapping("abrerecetores")
	public String abrerecetores(Model model , HttpSession session) 
	{
		Long id_hosp = daohospital.buscaIdHospital((String) session.getAttribute("localizacao"));
		model.addAttribute("recetores", daorecetor.buscarecetoreshospital(id_hosp));
		
		return "/pptransplante/divtotalrecetor";
	}
	
	@RequestMapping("buscatransplantados")
	public String buscatransplantados(Model model , HttpSession session) 
	{
		model.addAttribute("transplantados", daotransp.ListaTransplantesHospital((Long)session.getAttribute("idlocalizacao")));

		return "/pptransplante/divtransplantados";
	}
	
	@RequestMapping(value = "abrefollowuptransplantado")
	public String abrefollowuptransplantado(Model model, HttpSession session) 
	{
		model.addAttribute("followup", daofollowup.buscafollowup((Long) session.getAttribute("id_transplantado")));
		
		return "/pptransplante/divfollowup";
	}
	
	@RequestMapping(value = "alterafollowup")
	@Transactional
	public String alterafollowup(@RequestParam("complicacoes") int complicacoes, @RequestParam("tipo") int tipo, @RequestParam("sitclinica") int sitclinica, 
			@RequestParam("alertabio") boolean alertabio, @RequestParam("obs") String obs, @RequestParam("id") Long id, @RequestParam("tipomarc") int tipomarc,
			@RequestParam("jejum") boolean jejum, @RequestParam("urina") boolean urina, @RequestParam("data") String data, Model model, HttpSession session) throws ParseException 
	{
		FollowUp followup = daofollowup.buscaPorId(id);

		DateFormat dum = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss");
		
		if(!data.isEmpty() && data != null){
			
			Date date = dum.parse(data);
			Calendar cal = Calendar.getInstance();
			cal.setTime(date);
			followup.setDatafollowup(cal);	
		}else{
			followup.setDatafollowup(null);
		}
		
		followup.setJejum(jejum);
		followup.setUrina(urina);
		followup.setTipomarcacao(tipomarc);
		followup.setAlertabio(alertabio);
		followup.setComplicacoes(complicacoes);
		followup.setObservacoes(obs);
		followup.setSitclinica(sitclinica);
		followup.setTipo(tipo);
		
		daofollowup.atualiza(followup);
		
		model.addAttribute("followup", daofollowup.buscafollowup((Long) session.getAttribute("id_transplantado")));
		
		return "/pptransplante/divloadfollowup";
	}
	
	@RequestMapping(value = "salvarnovofollowup")
	@Transactional
	public String salvarnovofollowup(@RequestParam("data") String data, @RequestParam("complicacoes") int complicacoes, @RequestParam("tipo") int tipo, @RequestParam("sitclinica") int sitclinica, 
			@RequestParam("alertabio") boolean alertabio, @RequestParam("obs") String obs, @RequestParam("tipomarc") int tipomarc, @RequestParam("jejum") boolean jejum, @RequestParam("urina") boolean urina, Model model, HttpSession session) throws ParseException 
	{
		Transplantes transp = daotransp.buscaPorId((Long) session.getAttribute("id_transplantado"));
		
		DateFormat dum = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss");
		
		Utilizador user = new Utilizador();
		user.setID_Utilizador((Long)session.getAttribute("iduser"));
		
		FollowUp followup = new FollowUp();
		
		followup.setComplicacoes(complicacoes);
		
		if(!data.isEmpty() && data != null){
		Date date = dum.parse(data);
		Calendar cal = Calendar.getInstance();
		cal.setTime(date);
		followup.setDatafollowup(cal);
		}else{
			followup.setDatafollowup(null);
		}
		followup.setObservacoes(obs);
		followup.setSitclinica(sitclinica);
		followup.setTipo(tipo);
		followup.setTipomarcacao(tipomarc);
		followup.setJejum(jejum);
		followup.setUrina(urina);
		followup.setAlertabio(alertabio);
		followup.setTransplante(transp);
		followup.setUser(user);
		
		daofollowup.adiciona(followup);
		
		model.addAttribute("followup", daofollowup.buscafollowup((Long) session.getAttribute("id_transplantado")));
		
		return "/pptransplante/divloadfollowup";
	}
	
	@RequestMapping(value = "removefollowup")
	@Transactional
	public String removefollowup(@RequestParam("id") Long id, Model model, HttpSession session) 
	{
		FollowUp followup = daofollowup.buscaPorId(id);
		
		daofollowup.remove(followup);
		
		model.addAttribute("followup", daofollowup.buscafollowup((Long) session.getAttribute("id_transplantado")));
		
		return "/pptransplante/divloadfollowup";
	}
	
	
	@RequestMapping(value = "refrescatabfollowup")
	@Transactional
	public String refrescatabfollowup(Model model, HttpSession session) throws ParseException 
	{
		Long id_transplantado = (Long) session.getAttribute("id_transplantado");
		
		model.addAttribute("followup", daofollowup.buscafollowup(id_transplantado));
		
		return "/pptransplante/divloadfollowup";
	}
	
	@RequestMapping(value = "carreganovofollowupmedicacao")
	@Transactional
	@ResponseBody
	public String carreganovofollowupmedicacao(@RequestParam("data") String data, @RequestParam("complicacoes") int complicacoes, @RequestParam("tipo") int tipo, @RequestParam("sitclinica") int sitclinica, 
			@RequestParam("alertabio") boolean alertabio, @RequestParam("obs") String obs, @RequestParam("tipomarc") int tipomarc, @RequestParam("jejum") boolean jejum, @RequestParam("urina") boolean urina, HttpSession session) throws ParseException 
	{
		
		Transplantes transp = daotransp.buscaPorId((Long) session.getAttribute("id_transplantado"));
		
		DateFormat dum = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss");
		
		Utilizador user = new Utilizador();
		user.setID_Utilizador((Long)session.getAttribute("iduser"));
		
		FollowUp followup = new FollowUp();
		
		followup.setComplicacoes(complicacoes);
		
		if(!data.isEmpty() && data != null){
		Date date = dum.parse(data);
		Calendar cal = Calendar.getInstance();
		cal.setTime(date);
		followup.setDatafollowup(cal);
		}else{
			followup.setDatafollowup(null);
		}
		followup.setObservacoes(obs);
		followup.setSitclinica(sitclinica);
		followup.setTipo(tipo);
		followup.setTipomarcacao(tipomarc);
		followup.setJejum(jejum);
		followup.setUrina(urina);
		followup.setAlertabio(alertabio);
		followup.setTransplante(transp);
		followup.setUser(user);
		
		daofollowup.adiciona(followup);

		//model.addAttribute("estadoecetor", daoestado.buscaestadorecetor(id_analiserecetor));
		
		return followup.getId_followup().toString();
	}
	
	//--------------- MEDICA��O FOLLOW UP -----------------------------//
	@RequestMapping(value = "adicionamedicamentofollowup")
	@Transactional
	public String adicionamedicamentofollowup(@RequestParam("idfollowup") Long idfollowup, @RequestParam("nome") String nome, @RequestParam("dose") String dose, @RequestParam("periodicidade") int periodicidade, @RequestParam("qtddias") int qtddias, @RequestParam("notas") String notas, Model model, HttpSession session) throws ParseException 
	{
		//Long id_analiserecetor = (Long) session.getAttribute("id_analiserecetor");
		
		FollowUp followup = daofollowup.buscaPorId(idfollowup);
		
		MedicamentosFollowUp med = new MedicamentosFollowUp();
		
		med.setNome(nome);
		med.setDosagem(dose);
		med.setPeriodicidade(periodicidade);
		med.setNumdias(qtddias);
		med.setNotas(notas);
		med.setMarcacao(followup);

		
		daomedicamentosfollowup.adiciona(med);

		model.addAttribute("medicamentosfollowup", daomedicamentosfollowup.buscamedicamentosmarcacaofollowup(idfollowup));
		
		return "/pptransplante/load/tabmedicacaofollowup";
	}
	
	
	@RequestMapping(value = "carregatabelamedicacaofollowup")
	@Transactional
	public String carregatabelamedicacaofollowup(@RequestParam("idfollowup") Long idfollowup, Model model, HttpSession session) throws ParseException 
	{

		model.addAttribute("medicamentosfollowup", daomedicamentosfollowup.buscamedicamentosmarcacaofollowup(idfollowup));
		
		return "/pptransplante/load/tabmedicacaofollowup";
	}
	
	
	@RequestMapping(value = "removemedicamentofollowup")
	@ResponseBody
	public String removemedicamentofollowup(@RequestParam("idmedicamento") Long idmedicamento) throws ParseException 
	{
		MedicamentosFollowUp med = new MedicamentosFollowUp();
		med.setIdmedicamento(idmedicamento);

		daomedicamentosfollowup.remove(med);
		
		return "true";
	}
	
	
	@RequestMapping(value = "gravaeditmedicamentofollowup")
	@Transactional
	public String gravaeditmedicamentofollowup(@RequestParam("idmedicamento") Long idmedicamento, @RequestParam("idmarcacao") Long idfollowup, @RequestParam("nome") String nome, @RequestParam("dose") String dose, @RequestParam("periodicidade") int periodicidade, @RequestParam("qtddias") int qtddias, @RequestParam("notas") String notas, Model model, HttpSession session) throws ParseException 
	{
		//Long id_analiserecetor = (Long) session.getAttribute("id_analiserecetor");
		
	
		
		MedicamentosFollowUp med = daomedicamentosfollowup.buscaPorId(idmedicamento);
		
		med.setNome(nome);
		med.setDosagem(dose);
		med.setPeriodicidade(periodicidade);
		med.setNumdias(qtddias);
		med.setNotas(notas);

		
		daomedicamentosfollowup.atualiza(med);

		model.addAttribute("medicamentosfollowup", daomedicamentosfollowup.buscamedicamentosmarcacaofollowup(idfollowup));
		
		return "/pptransplante/load/tabmedicacaofollowup";
	}
	
	//-----------------------------FIM MEDICA��O FOLLOW UP ---------------------------------------//
	
	
	
	@RequestMapping(value = "removeimunopressor")
	@Transactional
	public String removeimunopressor(@RequestParam("id") Long id, Model model, HttpSession session) 
	{
		Imunossupressores imunop = daoimuno.buscaPorId(id);
		
		daoimuno.remove(imunop);
		
		model.addAttribute("imunopressores", daoimuno.buscaImunopressore((Long) session.getAttribute("id_transplantado")));
		
		return "/pptransplante/divloadimunopressores";
	}
	
	@RequestMapping(value = "salvarnovoimuno")
	@Transactional
	public String salvarnovoimuno(@RequestParam("data") String data, @RequestParam("imuno") Long imuno, @RequestParam("dias") int dias, @RequestParam("tipo") int tipo, 
			@RequestParam("obs") String obs, Model model, HttpSession session) throws ParseException 
	{
		Transplantes transp = daotransp.buscaPorId((Long) session.getAttribute("id_transplantado"));
		ImunossupressorMestre imu = daoimunomestre.buscaPorId(imuno);
		
		DateFormat dum = new SimpleDateFormat("dd/MM/yyyy, HH:mm");
		Date date = dum.parse(data);
		Calendar cal = Calendar.getInstance();
		cal.setTime(date);
		
		Imunossupressores imun = new Imunossupressores();
		
		imun.setDataimuno(cal);
		imun.setDias(dias);
		imun.setImuno(imu);
		imun.setObs(obs);
		imun.setTipoimuno(tipo);
		imun.setTransplante(transp);
		
		daoimuno.adiciona(imun);
		
		model.addAttribute("imunopressores", daoimuno.buscaImunopressore((Long) session.getAttribute("id_transplantado")));
		
		return "/pptransplante/divloadimunopressores";
	}
	
	@RequestMapping(value = "editarimuno")
	@Transactional
	public String editarimuno(@RequestParam("id") Long id, @RequestParam("imuno") Long imuno, @RequestParam("dias") int dias, @RequestParam("tipo") int tipo, 
			@RequestParam("obs") String obs, Model model, HttpSession session)
	{
		Imunossupressores imun = daoimuno.buscaPorId(id);
		ImunossupressorMestre imu = daoimunomestre.buscaPorId(imuno);
		
		imun.setDias(dias);
		imun.setImuno(imu);
		imun.setObs(obs);
		imun.setTipoimuno(tipo);
		
		daoimuno.atualiza(imun);
		
		model.addAttribute("imunopressores", daoimuno.buscaImunopressore((Long) session.getAttribute("id_transplantado")));
		
		return "/pptransplante/divloadimunopressores";
	}
	
	@RequestMapping(value = "abreimunosupressorestransplantado")
	public String abreimunosupressorestransplantado(Model model, HttpSession session) 
	{
		model.addAttribute("imunopressoresmestre", daoimunomestre.ListaImunossupressorMestre());
		model.addAttribute("imunopressores", daoimuno.buscaImunopressore((Long) session.getAttribute("id_transplantado")));
		
		return "/pptransplante/divfollowimunossupressores";
	}
	
	@RequestMapping(value = "abreterapeuticastransplantado")
	public String abreterapeuticastransplantado(Model model, HttpSession session) 
	{
		Long id_transplantado = (Long) session.getAttribute("id_transplantado");
		
		model.addAttribute("tipoterapeuticas", daotipoterfollow.ListaTipoTerapeuticas());
		model.addAttribute("unidades", daounid.ListaUnidadesGeral());
		model.addAttribute("terapeuticas", daoterapfollowup.buscaterapeuticastransplantado(id_transplantado));
		model.addAttribute("leituraescrita",session.getAttribute("leituraescrita"));
	
		return "/pptransplante/divfollowterapeuticas";
	}
	
	
	//-------------------An�lises Pr�-Transplante-------------------------------------//
	
		@RequestMapping(value = "carreganovasanalises")
		@Transactional
		public String carreganovaanalise(@RequestParam("data") String data, Model model, HttpSession session) throws ParseException 
		{
			Long id_analiserecetor = (Long) session.getAttribute("id_analiserecetor");
//			PPAnalisesRecetor analis = new PPAnalisesRecetor();
//			AnaliseRecetor analiserec = daoanaliserecetor.buscaPorId(id_analiserecetor);
			
			//data das amostras
			DateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mm");
			Date date = df.parse(data);
			Calendar cal = Calendar.getInstance();
			cal.setTime(date);

			daoanalise.adicionaitensamostras(cal, id_analiserecetor);
		//	daoanalise.adicionaitensamostras(amostra, cal, id_analiserecetor);
			
			model.addAttribute("amostras", daoanalise.buscaamostrasanaliseDescendente(id_analiserecetor));
			model.addAttribute("unidades", daounid.ListaUnidadesGeral());
			return "/pptransplante/divdetalheanalises";
		}
		
		
		@RequestMapping(value="alteraanalise", method = RequestMethod.POST)
		public String alteraanalise(@RequestParam("id") Long id, @RequestParam("data") String data, @RequestParam("observacoes") String observacoes, @RequestParam("valor") float valor, @RequestParam("idamostra") Long idamostra, @RequestParam("unidades") Long idunidades, Model model, HttpSession session) throws ParseException{		
			Long id_analiserecetor = (Long) session.getAttribute("id_analiserecetor");
			
			//data das amostras
			DateFormat df = new SimpleDateFormat("dd/MM/yyyy HH:mm");
		//	DateFormat df = new SimpleDateFormat("yyyy/MM/dd HH:mm");
			Date date = df.parse(data);
			Calendar cal = Calendar.getInstance();
			cal.setTime(date);
			
//			System.out.println("id: "+id+", data: "+data+", observ: "+observacoes+",valor: "+valor+",idamostra: "+idamostra+",idtipo: "+idtipo+",idunidades: "+idunidades);
		//	AmostrasFuncoesOrgao amostra = daoamostrasfo.buscaPorId(id);
			PPAnalisesRecetor analis = daoanalise.buscaPorId(id);
//			System.out.println(cal.getTime());
			analis.setDatahora(cal);
			analis.setObservamostras(observacoes);
			analis.setValoramostra(valor);
			analis.setAmostra(daoamostrasmestre.buscaPorId(idamostra));
			analis.setAnaliserecetor(daoanaliserecetor.buscaPorId(id_analiserecetor));
			analis.setUnidades(daounid.buscaPorId(idunidades));
			daoanalise.atualiza(analis);
			
			model.addAttribute("amostras", daoanalise.buscaamostrasanaliseDescendente(id_analiserecetor));
			model.addAttribute("unidades", daounid.ListaUnidadesGeral());
			return "/pptransplante/divdetalheanalises";
		}

		
	//------------------------Fim An�lise Pr�-transplante-----------------------------------------//	
	
//---------------------------An�lises Transplantado FollowUP---------------------------//	
	
	@RequestMapping(value = "abreanalisestransplantado")
	public String abreanalisestransplantado(Model model, HttpSession session) 
	{
		Long id_transplantado = (Long) session.getAttribute("id_transplantado");
		model.addAttribute("amostras", daoanalisefollow.buscaamostrasanaliseDescendente(id_transplantado));
		model.addAttribute("unidades", daounid.ListaUnidadesGeral());

		return "/pptransplante/divfollowanalises";
	}
	
	@RequestMapping(value = "carreganovasanalisesfollowup")
	@Transactional
	public String carreganovasanalisesfollowup(@RequestParam("data") String data,  Model model, HttpSession session) throws ParseException 
	{
		
		Long id_transplantado = (Long) session.getAttribute("id_transplantado");
		
		//data das amostras
		DateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mm");
		Date date = df.parse(data);
		Calendar cal = Calendar.getInstance();
		cal.setTime(date);

		daoanalisefollow.adicionaitensamostras(cal, id_transplantado);
		
		model.addAttribute("amostras", daoanalisefollow.buscaamostrasanaliseDescendente(id_transplantado));
		model.addAttribute("unidades", daounid.ListaUnidadesGeral());
		return "/pptransplante/divfollowanalises";
	}
	
	
	@RequestMapping(value="alteraanalisefollowup", method = RequestMethod.POST)
	public String alteraanalisefollowup(@RequestParam("id") Long id, @RequestParam("data") String data, @RequestParam("observacoes") String observacoes, @RequestParam("valor") float valor, @RequestParam("idamostra") Long idamostra, @RequestParam("unidades") Long idunidades, Model model, HttpSession session) throws ParseException{		
		//Long id_analiserecetor = (Long) session.getAttribute("id_analiserecetor");
		Long id_transplantado = (Long) session.getAttribute("id_transplantado");
		//data das amostras
		DateFormat df = new SimpleDateFormat("dd/MM/yyyy HH:mm");

		Date date = df.parse(data);
		Calendar cal = Calendar.getInstance();
		cal.setTime(date);
		

		PPAnalisesFollowUp analis = daoanalisefollow.buscaPorId(id);
//		System.out.println(cal.getTime());
		analis.setDatahora(cal);
		analis.setObservamostras(observacoes);
		analis.setValoramostra(valor);
		analis.setAmostra(daoamostrasmestre.buscaPorId(idamostra));
		analis.setTransplantado(daotransp.buscaPorId(id_transplantado));

		analis.setUnidades(daounid.buscaPorId(idunidades));
		daoanalisefollow.atualiza(analis);
		

		model.addAttribute("amostras", daoanalisefollow.buscaamostrasanaliseDescendente(id_transplantado));
		model.addAttribute("unidades", daounid.ListaUnidadesGeral());
		return "/pptransplante/divfollowanalises";
	}
	
	
//------------------------------Fim An�lises Transplantado FollowUP---------------------------------------------------------//	
	
	@RequestMapping(value = "abrehistoricotransplantado")
	public String abrehistoricotransplantado(Model model, HttpSession session) 
	{
		Long id_transplantado = (Long) session.getAttribute("id_transplantado");
		int sns = daotransp.buscaPorId(id_transplantado).getSns();
		model.addAttribute("historicotransp", daopphistorico.buscahistoricocandidato(sns));
		return "/pptransplante/divfollowhistorico";
	}
	
	@RequestMapping(value = "abredetalhetransplantados")
	public String abredetalhetransplantados(Long id, Model model, HttpSession session) 
	{
		session.setAttribute("id_transplantado", id);	
		model.addAttribute("transplantado", daotransp.buscaPorId(id));
		model.addAttribute("detalhetransplantado", daotranspdet.buscaTransplantadoDetalhes(id));
	//	model.addAttribute("listaorgaostransplantado", daoorgaos.ListaOrgaos());
		model.addAttribute("listaorgaostransplantado", daoorgaooferta.ListaOrgaosOferta());
		model.addAttribute("paises", daopais.ListaPaises());
		model.addAttribute("residencia", daores.ListaLocalResidencia());
		
		Long id_h = daohospital.buscaIdHospital((String) session.getAttribute("localizacao"));
		model.addAttribute("unidadetransplantado", daounidtransp.buscaUnidadesporHosp(id_h));
		
		return "/pptransplante/divdetalhetransplantado";
	}
	
	@RequestMapping(value = "gravardetalhestransplantado", method = RequestMethod.POST)
	@ResponseBody
	@Transactional
	public String gravardetalhestransplantado(@RequestParam("nometransplantado") String nometransplantado, @RequestParam("moradatransplantado") String moradatransplantado, 
			@RequestParam("localidadetransplantado") String localidadetransplantado, @RequestParam("codpostaltransplantado") String codpostaltransplantado, @RequestParam("telefonetransplantado") int telefonetransplantado, 
			@RequestParam("telemoveltransplantado") int telemoveltransplantado, @RequestParam("datatransplantado") String datatransplantado, @RequestParam("emailtransplantado") String emailtransplantado,
			@RequestParam("tiponumidentificacaotransplantado") int tiponumidentificacaotransplantado, 
			@RequestParam("numidentificacaotransplantado") int numidentificacaotransplantado, @RequestParam("tiponumidentificacaotransplantado2") int tiponumidentificacaotransplantado2, 
			@RequestParam("numidentificacaotransplantado2") int numidentificacaotransplantado2, @RequestParam("sexotransplantado") boolean sexotransplantado, @RequestParam("tipocidadaotransplantado") boolean tipocidadaotransplantado, 
			@RequestParam("residenciatransplantado") int residenciatransplantado, @RequestParam("nacionalidadetransplantado") int nacionalidadetransplantado, @RequestParam("snstransplantado") int snstransplantado, 
			@RequestParam("id_estadotransplantado") int id_estadotransplantado, @RequestParam("codigotransplantado") String codigotransplantado, @RequestParam("datacirurgia") String datacirurgia,
			HttpSession session) throws ParseException 
	{
		TransplantadoDetalhes transpdet = daotranspdet.buscaTransplantadoDetalhes((Long) session.getAttribute("id_transplantado"));
		Transplantes transp = daotransp.buscaPorId((Long) session.getAttribute("id_transplantado"));
		Paises nacionalidade = daopais.buscaPorId(nacionalidadetransplantado);
		LocalResidencia residencia = daores.buscaPorId(residenciatransplantado);
		
		DateFormat dum = new SimpleDateFormat("dd/MM/yyyy, HH:mm");
		Date date = dum.parse(datatransplantado);
		Calendar cal = Calendar.getInstance();
		cal.setTime(date);
		
		DateFormat dum2 = new SimpleDateFormat("dd/MM/yyyy, HH:mm");
		Date date2 = dum2.parse(datacirurgia);
		Calendar cal2 = Calendar.getInstance();
		cal2.setTime(date2);		
		
		transp.setCodigotransplantado(codigotransplantado);
		transp.setEstadotransplantado(id_estadotransplantado);
		transp.setNometransplantado(nometransplantado);
		transp.setSns(snstransplantado);
		transp.setDatatransplante(cal2);
		
		daotransp.atualiza(transp);
		
		transpdet.setCodpostaltranplantado(codpostaltransplantado);
		transpdet.setEmailtranplantado(emailtransplantado);
		transpdet.setLocalidadetranplantado(localidadetransplantado);
		transpdet.setMoradatranplantado(moradatransplantado);
		transpdet.setNacionalidadetransplantado(nacionalidade);
		transpdet.setNumidentificacaotransplantado(numidentificacaotransplantado);
		transpdet.setNumidentificacaotransplantado2(numidentificacaotransplantado2);
		transpdet.setResidenciatransplantado(residencia);
		transpdet.setSexotransplantado(sexotransplantado);
		transpdet.setTelefonetransplantado(telefonetransplantado);
		transpdet.setTelemoveltransplantado(telemoveltransplantado);
		transpdet.setTipocidadaotransplantado(tipocidadaotransplantado);
		transpdet.setTiponumidentificacaotransplantado2(tiponumidentificacaotransplantado2);
		transpdet.setTiponumidentificacaotransplantado(tiponumidentificacaotransplantado);
		transpdet.setDatanascimentotransplantado(cal);
		
		daotranspdet.atualiza(transpdet);

		return "true";
	}
	
	//permiss�es utilizador logado
	@RequestMapping("editautilizadorPPTrans")
	public String editarUtilizador2(Model model, HttpSession session) {
	model.addAttribute("utilizador", daouser.buscaPorId((Long) session.getAttribute("iduser")));
	model.addAttribute("especialidades", daoespec.ListaEspecialidade());
	model.addAttribute("tipoalteracao", 1);
	
  	//carregar hospitais permissao do utilizador
	model.addAttribute("permissaohosp", daoperm.ListaHospitaisPermissao((Long) session.getAttribute("iduser")));
	
	//carrega posi��o para bot�o criar novo user
	model.addAttribute("idposicao", session.getAttribute("idposicao"));
	
	return "pptransplante/detalheUtilizadorPPtrans";
	}
	
	//-------------------------------Terapeuticas follow up-----------------------------------//
	
	@RequestMapping(value="addterapeuticafollowup", method = RequestMethod.POST)
	public String addterapeutica(@RequestParam("tipoterap") Long tipoterap, @RequestParam("data") String data, @RequestParam("unidterap") Long unidterap, @RequestParam("observ") String observ, 
			@RequestParam("dose") float dose, Model model, HttpSession session) throws ParseException {
		
		//data das amostras
		DateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mm");
		Date date = df.parse(data);
		Calendar cal = Calendar.getInstance();
		cal.setTime(date);

		
		Long id_transplantado = (Long) session.getAttribute("id_transplantado");

		
		TerapeuticasFollowUP ter = new TerapeuticasFollowUP();
		ter.setTransplantado(daotransp.buscaPorId(id_transplantado));
		ter.setTipoTerapeuticas(daotipoterfollow.buscaPorId(tipoterap));
		ter.setDoseterapeutica(dose);
		ter.setDatahoraterapeutica(cal);
		ter.setObsterapeutica(observ);
		
		daoterapfollowup.adiciona(ter);
		
		model.addAttribute("terapeuticas", daoterapfollowup.buscaterapeuticastransplantado(id_transplantado));
		return "pptransplante/tabelaterapeuticasfollowup";
		}
	
	@RequestMapping(value="editdadosterapfollowup", method = RequestMethod.POST)
	public String editdadosterap(@RequestParam("id") Long id, @RequestParam("tipoterap") Long tipoterap, @RequestParam("unidterap") Long unidterap, @RequestParam("data") String data, @RequestParam("dose") float dose, @RequestParam("observ") String observ, Model model, HttpSession session) throws ParseException{		
	
		Long id_transplantado = (Long) session.getAttribute("id_transplantado");
		
		DateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mm");
		Date date = df.parse(data);
		Calendar cal = Calendar.getInstance();
		cal.setTime(date);		

		TerapeuticasFollowUP ter2 = daoterapfollowup.buscaPorId(id);
		ter2.setTransplantado(daotransp.buscaPorId(id_transplantado));
		ter2.setTipoTerapeuticas(daotipoterfollow.buscaPorId(tipoterap));
		ter2.setDatahoraterapeutica(cal);
		ter2.setDoseterapeutica(dose);
		ter2.setObsterapeutica(observ);
		daoterapfollowup.atualiza(ter2);
	
		model.addAttribute("terapeuticas", daoterapfollowup.buscaterapeuticastransplantado(id_transplantado));
		
		return "pptransplante/tabelaterapeuticasfollowup";
	}
	
	
	
	@RequestMapping(value="carregaunidadesterapeuticafollowup", method = RequestMethod.POST)
	public String carregaunidadesterapeutica(@RequestParam("id_tipoterapeutica") Long id_tipoterapeutica, Model model){
		
	model.addAttribute("unidades", daounid.loadunidadesterapeutica(id_tipoterapeutica));
		
		return "admin/loads/combounidadesterapeutica";	
	}
	
	
	@RequestMapping(value="eliminaterapeutfollowup", method = RequestMethod.POST)
	@ResponseBody
	@Transactional
	public String eliminaterapeut(@RequestParam("idterap") Long idterap) throws ParseException{		
		
		
		TerapeuticasFollowUP ter = daoterapfollowup.buscaPorId(idterap);
		daoterapfollowup.remove(ter);
		return "OK";
	}
	

	
	//-------------------------------Fim de Terapeuticas follow up-----------------------------------//
	
	//--------------------------INICIO Virologia Pr�-transplante------------------------------//

	//
	@RequestMapping(value="abrevirologiarecetor", method = RequestMethod.POST)
	public String abrevirologiarecetor(Model model, HttpSession session){
		
		Long id_analiserecetor = (Long) session.getAttribute("id_analiserecetor");
			
		//verifica se j� possui todas os tipos de virologia, se true adicionar
		if(daovirorecetor.verificatiposmestreadiciona(id_analiserecetor)){	
			daovirorecetor.adicionavirologiaexistentes(id_analiserecetor);
		}
		
		List<VirologiaRecetor> tabviro = daovirorecetor.buscaVirologiaRecetorPretransplante(id_analiserecetor);
		model.addAttribute("viro", tabviro);
		
		model.addAttribute("tipoviro", tabviro.get(0));
		
		model.addAttribute("leituraescrita",session.getAttribute("leituraescrita"));
	
		return "pptransplante/divvirologiapretransp";	
	}
	
	
	@RequestMapping(value="gravavirologiasrecetor", method = RequestMethod.POST)
	@ResponseBody
	public void gravavirologiasrecetor(@RequestParam(value = "dados[]") String dados, HttpSession session){		
		daovirorecetor.guardadadosviro(dados, (Long)session.getAttribute("id_analise"));
	}
	
	
	
	//--------------------------Fim Virologia Pr�-transplante------------------------------//
	
	//carrega caminho upload do ficheiro Dados clinicos Renal
	@RequestMapping(value="carreganomedocpptrenal", method = RequestMethod.POST)
	public String carreganomedocpptrenal(@RequestParam("idrecetor") Long id, Model model, HttpSession session) {

		Long id_analiserecetor = (Long) session.getAttribute("id_analiserecetor");
		
		model.addAttribute("pprenal", daorenal.ListaPPRenalAnalise(id_analiserecetor));
		
		return "pptransplante/caminhodocpptrenal";
		}
	
	
	//---------------------COMORBILIDADES DADOS CLINICOS PPHEPATICO------------------------//
	
	@RequestMapping(value="regcomorb", method = RequestMethod.POST)
	public String regcomorb(@RequestParam("indicacao") int indicacao, @RequestParam("notas") String notas, Model model, HttpSession session) {

		Long id_analiserecetor = (Long) session.getAttribute("id_analiserecetor");
		
		PPHepaticoComorbilidades comorb = new PPHepaticoComorbilidades();
		comorb.setIndicacao(indicacao);
		comorb.setNotas(notas);
		comorb.setAnaliserecetor(daoanaliserecetor.buscaPorId(id_analiserecetor));
		daopphepaticocomorb.adiciona(comorb);
		
		model.addAttribute("comorbilidades", daopphepaticocomorb.ListaPPHepaticoComorbilidadesAnalise(id_analiserecetor));
		
		return "pptransplante/load/tabcomorbilidades";
		}
	
	
	@RequestMapping(value="delcomorb", method = RequestMethod.POST)
	@ResponseBody
	public String delcomorb(@RequestParam("id_pphepaticocomorb") Long id_pphepaticocomorb,  Model model, HttpSession session) {

		
		PPHepaticoComorbilidades comorb = daopphepaticocomorb.buscaPorId(id_pphepaticocomorb);
		daopphepaticocomorb.remove(comorb);
		
		return "true";
		}
	
	
	@RequestMapping(value="gravacomorb", method = RequestMethod.POST)
	public String gravacomorb(@RequestParam("id") Long  id, @RequestParam("indicacao") int indicacao, @RequestParam("notas") String notas, Model model, HttpSession session) {

		Long id_analiserecetor = (Long) session.getAttribute("id_analiserecetor");
		
		PPHepaticoComorbilidades comorb = daopphepaticocomorb.buscaPorId(id);
		comorb.setIndicacao(indicacao);
		comorb.setNotas(notas);
		daopphepaticocomorb.atualiza(comorb);
		
		model.addAttribute("comorbilidades", daopphepaticocomorb.ListaPPHepaticoComorbilidadesAnalise(id_analiserecetor));
		
		return "pptransplante/load/tabcomorbilidades";
		}
	
	//--------------------- FIM COMORBILIDADES DADOS CLINICOS PPHEPATICO------------------------//
	
	
	//---------------------TABELA DIAGNOSTICO DADOS CLINICOS PPHEPATICO------------------------//
	
	@RequestMapping(value="regdiagnostico", method = RequestMethod.POST)
	public String regdiagnostico(@RequestParam("diagnostico") int diagnostico, @RequestParam("chk") boolean chk, Model model, HttpSession session) {

		Long id_analiserecetor = (Long) session.getAttribute("id_analiserecetor");
		
		PPHepaticoDiagnostico diag = new PPHepaticoDiagnostico();
		TipoDiagnostico tipodiag = new TipoDiagnostico();
		tipodiag.setIdtipodiagnostico(diagnostico);
		
		diag.setTipodiagnostico(tipodiag);
		diag.setEsc(chk);
		diag.setAnaliserecetor(daoanaliserecetor.buscaPorId(id_analiserecetor));
		daopphepaticodiag.adiciona(diag);
		
		model.addAttribute("diagnostico", daopphepaticodiag.ListaPPHepaticoDiagnosticoAnalise(id_analiserecetor));
		
		return "pptransplante/load/tabdiagnostico";
		}
	
	
	@RequestMapping(value="deldiagnostico", method = RequestMethod.POST)
	@ResponseBody
	public String deldiagnostico(@RequestParam("id_pphepaticodiagnostico") Long id_pphepaticodiagnostico) {
		
		PPHepaticoDiagnostico diag = daopphepaticodiag.buscaPorId(id_pphepaticodiagnostico);
		daopphepaticodiag.remove(diag);
		
		return "true";
		}
	
	
	@RequestMapping(value="gravadiagnostico", method = RequestMethod.POST)
	public String gravadiagnostico(@RequestParam("id") Long  id, @RequestParam("diagnostico") int diagnostico, @RequestParam("chk") boolean chk, Model model, HttpSession session) {

		Long id_analiserecetor = (Long) session.getAttribute("id_analiserecetor");
		
		TipoDiagnostico tipodiag = new TipoDiagnostico();
		tipodiag.setIdtipodiagnostico(diagnostico);
		
		PPHepaticoDiagnostico diag = daopphepaticodiag.buscaPorId(id);
		diag.setTipodiagnostico(tipodiag);
		diag.setEsc(chk);
		daopphepaticodiag.atualiza(diag);
		
		model.addAttribute("diagnostico", daopphepaticodiag.ListaPPHepaticoDiagnosticoAnalise(id_analiserecetor));
		
		return "pptransplante/load/tabdiagnostico";
		}

	//---------------------TABELA COMPLICACOES DADOS CLINICOS PPHEPATICO------------------------//
	
	
	@RequestMapping(value="regcomplicacao", method = RequestMethod.POST)
	public String regcomplicacao(@RequestParam("complicacao") int complicacao, @RequestParam("chk") boolean chk, Model model, HttpSession session) {

		Long id_analiserecetor = (Long) session.getAttribute("id_analiserecetor");
		
		PPHepaticoComplicacoes compl = new PPHepaticoComplicacoes();
		TipoComplicacoes tipocompl = new TipoComplicacoes();
		tipocompl.setIdtipocomplicacao(complicacao);
		
		compl.setTipocomplicacoes(tipocompl);
		compl.setEsc(chk);
		compl.setAnaliserecetor(daoanaliserecetor.buscaPorId(id_analiserecetor));
		daopphepaticocompl.adiciona(compl);
		
		model.addAttribute("complicacoes", daopphepaticocompl.ListaPPHepaticoComplicacoesAnalise(id_analiserecetor));
		
		return "pptransplante/load/tabcomplicacao";
		}
	
	
	@RequestMapping(value="gravacomplicacao", method = RequestMethod.POST)
	public String gravacomplicacao(@RequestParam("id") Long  id, @RequestParam("complicacao") int complicacao, @RequestParam("chk") boolean chk, Model model, HttpSession session) {

		Long id_analiserecetor = (Long) session.getAttribute("id_analiserecetor");
		
		TipoComplicacoes tipocompl = new TipoComplicacoes();
		tipocompl.setIdtipocomplicacao(complicacao);
		
		PPHepaticoComplicacoes compl = daopphepaticocompl.buscaPorId(id);
		compl.setTipocomplicacoes(tipocompl);
		compl.setEsc(chk);
		daopphepaticocompl.atualiza(compl);
		
		model.addAttribute("complicacoes", daopphepaticocompl.ListaPPHepaticoComplicacoesAnalise(id_analiserecetor));
		
		return "pptransplante/load/tabcomplicacao";
		}
	
	
	@RequestMapping(value="delcomplicacao", method = RequestMethod.POST)
	@ResponseBody
	public String delcomplicacao(@RequestParam("id_pphepaticocomplicacao") Long id_pphepaticocomplicacao) {
		
		PPHepaticoComplicacoes compl = daopphepaticocompl.buscaPorId(id_pphepaticocomplicacao);
		daopphepaticocompl.remove(compl);
		
		return "true";
		}
	
}