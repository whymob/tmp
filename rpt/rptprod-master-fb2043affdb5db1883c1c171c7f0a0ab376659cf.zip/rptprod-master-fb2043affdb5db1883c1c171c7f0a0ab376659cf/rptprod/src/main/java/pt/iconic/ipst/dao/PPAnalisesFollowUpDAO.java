package pt.iconic.ipst.dao;

import java.util.Calendar;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import pt.iconic.ipst.modelo.AmostrasFO;
import pt.iconic.ipst.modelo.PPAnalisesFollowUp;
import pt.iconic.ipst.modelo.Transplantes;

@Repository
@Transactional
public class PPAnalisesFollowUpDAO {

	
	@PersistenceContext
	private EntityManager manager;
	

/*	public void adiciona(PPAnalisesFollowUp anali){
		manager.persist(anali);	
	}*/
	

	public void atualiza(PPAnalisesFollowUp anali){
		manager.merge(anali);
	}

/*	@SuppressWarnings("unchecked")
	public List<PPAnalisesFollowUp> ListaGravidade(){
		return manager.createQuery("select d from PPAnalisesFollowUp d").getResultList();
	}*/
	
	public PPAnalisesFollowUp buscaPorId(Long id){
		return manager.find(PPAnalisesFollowUp.class, id);
	}
	
/*	public void remove(PPAnalisesFollowUp anali){
		PPAnalisesFollowUp analirem = buscaPorId(anali.getId_analisefollowup());
		manager.remove(analirem);
	}*/
	
/*	@SuppressWarnings("unchecked")
	public List<PPAnalisesFollowUp> buscaanaliserecetor(Long transplantado)
	{		
		Query query = manager.createQuery("select a from PPAnalisesFollowUp a JOIN a.transplantado tr WHERE tr.id_transplante =:transplantado");
		query.setParameter("transplantado", transplantado);
		
		List<PPAnalisesFollowUp> results = query.getResultList();

		return results;
	}*/

	//adiciona as 40 amostras � tabela
	@SuppressWarnings("unchecked")
	public boolean adicionaitensamostras(Calendar data, Long id_transplante){

	//	public boolean adicionaitensamostras(Long amostra, Calendar data, Long id_transplante){	
		Query nomesamostras = manager.createQuery("select a from AmostrasFO a");
		
		List<AmostrasFO> amostras = nomesamostras.getResultList();
		
		Transplantes transplantado = manager.find(Transplantes.class, id_transplante);
		
		

		for (int i=0; i<amostras.size(); i++){
		//	AmostrasFuncoesOrgao amostrafo = new AmostrasFuncoesOrgao();
			PPAnalisesFollowUp analises = new PPAnalisesFollowUp();
			analises.setTransplantado(transplantado);
		//	System.out.println("amostraaaaaa: "+amostras.get(i));
			analises.setAmostra(amostras.get(i));
			analises.setDatahora(data);
		//	analises.setTipoAmostra(manager.find(TipoAmostraFO.class, amostra));
			manager.persist(analises);
		}
		
		return true;
	}


	//carrega as amostras quando insere as 40 para que as da ultima amostra apare�am em cima
	@SuppressWarnings("unchecked")
	public List<PPAnalisesFollowUp> buscaamostrasanaliseDescendente(Long id_transplante){
		
		Query query = manager.createQuery("select a from PPAnalisesFollowUp a JOIN a.transplantado tr LEFT JOIN a.amostra amostrafo WHERE tr.id_transplante =:id_transplante  ORDER BY a.datahora DESC");
		query.setParameter("id_transplante", id_transplante);
		
		List<PPAnalisesFollowUp> results = query.getResultList();

		return results;
	}
}
