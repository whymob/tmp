package pt.iconic.ipst.modelo;

import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name="TIPOGASVENT")
public class TipoGasVent {

	private Long id_tipogasvent;
	private String desctipogasvent;
	private List<GasVent> GasVent;
	private UnidadesGeral unidades;
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="ID_TIPOGASVENT")
	public Long getId_tipogasvent() {
		return id_tipogasvent;
	}
	public void setId_tipogasvent(Long id_tipogasvent) {
		this.id_tipogasvent = id_tipogasvent;
	}

	@Column(name="DESCTIPOGASVENT")
	public String getDesctipogasvent() {
		return desctipogasvent;
	}
	public void setDesctipogasvent(String desctipogasvent) {
		this.desctipogasvent = desctipogasvent;
	}
	@OneToMany(fetch = FetchType.LAZY, mappedBy = "tipoGasVent")
	public List<GasVent> getGasVent() {
		return GasVent;
	}
	public void setGasVent(List<GasVent> gasVent) {
		GasVent = gasVent;
	}
	

    @ManyToOne(fetch = FetchType.EAGER, optional=true)
    @JoinColumn(name = "ID_UNIDADES")
	public UnidadesGeral getUnidades() {
		return unidades;
	}
	public void setUnidades(UnidadesGeral unidades) {
		this.unidades = unidades;
	}	

  /*  @OneToMany(fetch = FetchType.LAZY, mappedBy = "tipoGasVent")
	public List<GasVentAmostras> getGasVentAmostras() {
		return GasVentAmostras;
	}
	public void setGasVentAmostras(List<GasVentAmostras> gasVentAmostras) {
		GasVentAmostras = gasVentAmostras;
	}*/
	
}
