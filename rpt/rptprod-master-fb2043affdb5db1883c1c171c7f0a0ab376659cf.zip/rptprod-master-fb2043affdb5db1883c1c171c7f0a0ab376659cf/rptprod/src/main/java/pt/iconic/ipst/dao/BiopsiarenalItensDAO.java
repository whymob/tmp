package pt.iconic.ipst.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import pt.iconic.ipst.modelo.BiopsiarenalItens;


@Repository
@Transactional
public class BiopsiarenalItensDAO {

	
	@PersistenceContext
	private EntityManager manager;
	
	
	public void adiciona(BiopsiarenalItens biorenalitens){
		manager.persist(biorenalitens);	
	}
	

/*	public void atualiza(BiopsiarenalItens biorenalitens){
		manager.merge(biorenalitens);
	}*/
	

/*	@SuppressWarnings("unchecked")
	public List<BiopsiarenalItens> ListaAmostrasFO(){
		return manager.createQuery("select a from BiopsiarenalItens a").getResultList();
	}*/
	
	public BiopsiarenalItens buscaPorId(Long id){
		return manager.find(BiopsiarenalItens.class, id);
	}
	
	
	public void remove(BiopsiarenalItens biorenalitens){
		BiopsiarenalItens biorenalitensARemover = buscaPorId(biorenalitens.getIditem());
		manager.remove(biorenalitensARemover);
		
	}
	
	@SuppressWarnings("unchecked")
	public List<BiopsiarenalItens> buscabiopsiarenalitensanalise(Long idanalise){
		
		Query query = manager.createQuery("select b from BiopsiarenalItens b JOIN b.analiseDador a WHERE a.id_AnaliseDador =:idanalise");
		query.setParameter("idanalise", idanalise);
		
		List<BiopsiarenalItens> results = query.getResultList();
		
		return results;
		
	}
}
