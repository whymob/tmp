package pt.iconic.ipst.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import pt.iconic.ipst.modelo.NomeTransfusoes;
import pt.iconic.ipst.modelo.TipoTransfusoes;
import pt.iconic.ipst.modelo.UnidadesGeral;


@Repository
@Transactional
public class NomeTransfusoesDAO {

	
	@PersistenceContext
	private EntityManager manager;
	
	
	public void adiciona(NomeTransfusoes nometransfusao){
		manager.persist(nometransfusao);	
	}
	
	public void atualiza(NomeTransfusoes nometransfusao){
		manager.merge(nometransfusao);
	}
	

	@SuppressWarnings("unchecked")
	public List<NomeTransfusoes> ListaNomeTransfusoes(){
		return manager.createQuery("select d from NomeTransfusoes d").getResultList();
	}
	
	public NomeTransfusoes buscaPorId(Long id){
		return manager.find(NomeTransfusoes.class, id);
	}
	
	
	public void remove(NomeTransfusoes nometransfusao){
		NomeTransfusoes nometransfusaoARemover = buscaPorId(nometransfusao.getId_nometransfusao());
		manager.remove(nometransfusaoARemover);
		
	}

	public boolean trataadicionar(String desc, Long combo, Long unid)
	{
		Query query = manager.createQuery("SELECT e FROM NomeTransfusoes e WHERE e.desctransf =:desc");
		query.setParameter("desc", desc);
		
		if(query.getResultList().isEmpty())
		{
			
			UnidadesGeral un = new UnidadesGeral();
			un.setId_unidades(unid);
			
			TipoTransfusoes formula = new TipoTransfusoes();
			formula.setId_tipotransfusoes(combo);
			
			NomeTransfusoes transf = new NomeTransfusoes();
			transf.setDesctransf(desc);
			transf.setUnidades(un);
			transf.setTipoTransf(formula);
			adiciona(transf);
			
			return true;
		}
		else
		{
			return false;
		}
	}

	public boolean trataalterar(Long id, String desc, Long combo, Long unid)
	{
//		Query query = manager.createQuery("SELECT e FROM Hospital e WHERE e.nomeHospital =:desc");
//		query.setParameter("desc", desc);
//		
//		if(query.getResultList().isEmpty())
//		{
//			
		UnidadesGeral un = new UnidadesGeral();
		un.setId_unidades(unid);
		
		TipoTransfusoes formula = new TipoTransfusoes();
		formula.setId_tipotransfusoes(combo);
			
			NomeTransfusoes transf = new NomeTransfusoes();
			transf.setId_nometransfusao(id);
			transf.setDesctransf(desc);
			transf.setUnidades(un);
			transf.setTipoTransf(formula);
			atualiza(transf);
				
			return true;
//		}
//		else
//		{
//			return false;
//		}
	}
	

	public boolean remover(Long id) 
	{
		NomeTransfusoes transf = new NomeTransfusoes();
		transf = buscaPorId(id);
		remove(transf);
		return true;
	}
}
