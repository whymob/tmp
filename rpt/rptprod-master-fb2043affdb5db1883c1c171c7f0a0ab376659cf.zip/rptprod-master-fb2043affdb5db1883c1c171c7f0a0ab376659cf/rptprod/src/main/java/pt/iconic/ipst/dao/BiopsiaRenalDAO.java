package pt.iconic.ipst.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import pt.iconic.ipst.modelo.BiopsiaRenal;

@Repository
@Transactional
public class BiopsiaRenalDAO {

	@PersistenceContext
	private EntityManager manager;
	
	
	public void adiciona(BiopsiaRenal biorenal){
		manager.persist(biorenal);	
	}
	

	public void atualiza(BiopsiaRenal biorenal){
		manager.merge(biorenal);
	}
	

/*	@SuppressWarnings("unchecked")
	public List<BiopsiaRenal> ListaBiopsiaRenal(){
		return manager.createQuery("select a from BiopsiaRenal a").getResultList();
	}*/
	
	public BiopsiaRenal buscaPorId(Long id){
		return manager.find(BiopsiaRenal.class, id);
	}
	
	
/*	public void remove(BiopsiaRenal biorenal){
		BiopsiaRenal biorenalARemover = buscaPorId(biorenal.getIdbiopsiarenal());
		manager.remove(biorenalARemover);
		
	}*/
	
	@SuppressWarnings("unchecked")
	public BiopsiaRenal buscabiopsiarenalanalise(Long idanalise){
		
		Query query = manager.createQuery("select b from BiopsiaRenal b JOIN b.analiseDador a WHERE a.id_AnaliseDador =:idanalise");
		query.setParameter("idanalise", idanalise);
		
		List<BiopsiaRenal> results = query.getResultList();
		BiopsiaRenal biorenal = null;
		if(!results.isEmpty()){
			biorenal = (BiopsiaRenal) results.get(0);
		}
		return biorenal;
		
	}
}
