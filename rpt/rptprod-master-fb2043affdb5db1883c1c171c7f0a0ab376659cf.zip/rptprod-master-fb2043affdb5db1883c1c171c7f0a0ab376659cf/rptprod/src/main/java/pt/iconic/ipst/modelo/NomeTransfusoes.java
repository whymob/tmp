package pt.iconic.ipst.modelo;

import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name="NOMETRANSFUSOES")
public class NomeTransfusoes {

	
	private Long id_nometransfusao;
	private String desctransf;
	private TipoTransfusoes tipoTransf;
	private UnidadesGeral unidades;
	private List<Transfusoes> Transfusoes;
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="ID_NOMETRANSFUSAO")
	public Long getId_nometransfusao() {
		return id_nometransfusao;
	}
	public void setId_nometransfusao(Long id_nometransfusao) {
		this.id_nometransfusao = id_nometransfusao;
	}
	
	@Column(name="DESCRICAO")
	public String getDesctransf() {
		return desctransf;
	}
	public void setDesctransf(String desctransf) {
		this.desctransf = desctransf;
	}
	
//	@Column(name="FORMULATRANSFUSAO")
//	public String getFormulaTransfusao() {
//		return FormulaTransfusao;
//	}
//	public void setFormulaTransfusao(String formulaTransfusao) {
//		FormulaTransfusao = formulaTransfusao;
//	}
	
    @OneToMany(fetch = FetchType.LAZY, mappedBy = "nomeTransfusoes")
	public List<Transfusoes> getTransfusoes() {
		return Transfusoes;
	}
	public void setTransfusoes(List<Transfusoes> transfusoes) {
		Transfusoes = transfusoes;
	}
	
    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "ID_TIPOTRANSFUSAO")
	public TipoTransfusoes getTipoTransf() {
		return tipoTransf;
	}
	public void setTipoTransf(TipoTransfusoes tipoTransf) {
		this.tipoTransf = tipoTransf;
	}
	
    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "ID_UNIDADES")
	public UnidadesGeral getUnidades() {
		return unidades;
	}
	public void setUnidades(UnidadesGeral unidades) {
		this.unidades = unidades;
	}	
}
