package pt.iconic.ipst.controller;

import java.math.BigDecimal;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import pt.iconic.ipst.dao.AmostrasFODAO;
import pt.iconic.ipst.dao.CausaMorteDAO;
import pt.iconic.ipst.dao.EspecialidadesDAO;
import pt.iconic.ipst.dao.EstadoDadorDAO;
import pt.iconic.ipst.dao.EtniaDAO;
import pt.iconic.ipst.dao.GCCTDAO;
import pt.iconic.ipst.dao.GlasgowCommaDAO;
import pt.iconic.ipst.dao.HospitalDAO;
import pt.iconic.ipst.dao.ImunossupressorMestreDAO;
import pt.iconic.ipst.dao.MecanismoMorteDAO;
import pt.iconic.ipst.dao.MicroorganismosDAO;
import pt.iconic.ipst.dao.NomeTransfusoesDAO;
import pt.iconic.ipst.dao.SensibilidadeDAO;
import pt.iconic.ipst.dao.TipoComplicacoesDAO;
import pt.iconic.ipst.dao.TipoDiagnosticoDAO;
import pt.iconic.ipst.dao.TipoGasVentDAO;
import pt.iconic.ipst.dao.TipoMBAnaliseDAO;
import pt.iconic.ipst.dao.TipoTerapeuticasDAO;
import pt.iconic.ipst.dao.TipoTerapeuticasFollowUpDAO;
import pt.iconic.ipst.dao.TipoVirologiaDAO;
import pt.iconic.ipst.dao.UnidadeTransplanteDAO;
import pt.iconic.ipst.dao.UnidadeTransplanteHospitalDAO;
import pt.iconic.ipst.dao.UnidadesAmostrasFODAO;
import pt.iconic.ipst.dao.UnidadesDAO;
import pt.iconic.ipst.modelo.Unidade_Hospital;
import pt.iconic.ipst.modelo.UnidadesAmostrasFO;


@Controller
public class DadosMestreController 
{
//	private VasopressorDAO daovasop;
	private EtniaDAO daoetnia;
	private GlasgowCommaDAO daoglasgow;
	private MecanismoMorteDAO daomecanismo;
	private CausaMorteDAO daocausamorte;
	private TipoGasVentDAO daogasi;
	private TipoTerapeuticasDAO daoterap;
	private HospitalDAO daoHosp;
	private SensibilidadeDAO daosensi;
	private MicroorganismosDAO daomicroorg;
	private AmostrasFODAO daoamostrasfo;
	private EspecialidadesDAO daoesp;
	private EstadoDadorDAO daoestdador;
	private GCCTDAO daogcct;
	private UnidadesDAO daounid;
	private NomeTransfusoesDAO daonometransf;
	private TipoMBAnaliseDAO daotipomb;
	private TipoVirologiaDAO daotipoviro;
	private UnidadesAmostrasFODAO daounidamostras;
	private UnidadeTransplanteDAO daounidtranspl;
	private TipoTerapeuticasFollowUpDAO daotipoterfollow;
	private ImunossupressorMestreDAO daoimunomestre;
	private UnidadeTransplanteHospitalDAO daounidtransplhosp;
	private TipoDiagnosticoDAO daotipodiag;
	private TipoComplicacoesDAO daotipocompl;
	
	@Autowired
	public DadosMestreController(EtniaDAO daoetnia, GlasgowCommaDAO daoglasgow, MecanismoMorteDAO daomecanismo, CausaMorteDAO daocausamorte, TipoGasVentDAO daogasi, TipoTerapeuticasDAO daoterap,
			HospitalDAO daoHosp, MicroorganismosDAO daomicroorg, SensibilidadeDAO daosensi, AmostrasFODAO daoamostrasfo, EspecialidadesDAO daoesp, EstadoDadorDAO daoestdador, GCCTDAO daogcct,
			UnidadesDAO daounid, NomeTransfusoesDAO daonometransf, TipoMBAnaliseDAO daotipomb, TipoVirologiaDAO daotipoviro, UnidadesAmostrasFODAO daounidamostras, UnidadeTransplanteDAO daounidtranspl,
			TipoTerapeuticasFollowUpDAO daotipoterfollow, ImunossupressorMestreDAO daoimunomestre, UnidadeTransplanteHospitalDAO daounidtransplhosp, TipoDiagnosticoDAO daotipodiag, TipoComplicacoesDAO daotipocompl) 
	{

		this.daoetnia = daoetnia;
		this.daoglasgow = daoglasgow;
		this.daomecanismo = daomecanismo;
		this.daocausamorte = daocausamorte;
		this.daogasi = daogasi;
		this.daoterap = daoterap;
		this.daoHosp = daoHosp;
		this.daosensi = daosensi;
		this.daomicroorg = daomicroorg;
		this.daoamostrasfo = daoamostrasfo;
		this.daoesp = daoesp;
		this.daoestdador = daoestdador;
		this.daogcct = daogcct;
		this.daounid = daounid;
		this.daonometransf = daonometransf;
		this.daotipomb = daotipomb;
		this.daotipoviro = daotipoviro;
		this.daounidamostras = daounidamostras;
		this.daounidtranspl = daounidtranspl;
		this.daotipoterfollow = daotipoterfollow;
		this.daoimunomestre = daoimunomestre;
		this.daounidtransplhosp = daounidtransplhosp;
		this.daotipodiag = daotipodiag;
		this.daotipocompl = daotipocompl;
	}
	
	@RequestMapping(value="carregadadosmestre")
	public String carregadadosmestre(Model model, int id) 
	{
		if(id == 1)
		{
//			System.out.println("Carrega etnia");
			model.addAttribute("etniam", daoetnia.ListaEtnia());
			return "admin/dadosmestre/divmestreetnia";
		}
		else
		if(id == 2)
		{
//			System.out.println("Carrega glasgow comma");
			model.addAttribute("glasgow", daoglasgow.ListaGlasgowComma());
			return "admin/dadosmestre/divmestreglasgowcomma";
		}
		else
		if(id == 3)
		{
//			System.out.println("Carrega Gas. e vent.");
			model.addAttribute("unidades", daounid.ListaUnidadesGeral());
			model.addAttribute("gasi", daogasi.ListaTipoGasVent());
			return "admin/dadosmestre/divmestregasvent";
		}
		else
		if(id == 4)
		{
//			System.out.println("Carrega Mecanismo de Morte");
			model.addAttribute("mecanismomorte", daomecanismo.ListaMecanismoMorte());
			return "admin/dadosmestre/divmestremecanismomorte";
		}
		else
		if(id == 5)
		{
//			System.out.println("Carrega Causa de Morte");
			model.addAttribute("causa", daocausamorte.ListaCausaMorte());
			return "admin/dadosmestre/divmestrecausamorte";
		}	
		else
		if(id == 6)
		{
//			System.out.println("Carrega Tipo Terapeuticas");
			model.addAttribute("unidades", daounid.ListaUnidadesGeral());
			model.addAttribute("terap", daoterap.ListaTipoTerapeuticas());
			return "admin/dadosmestre/divmestreterapeuticas";
		}
		else
		if(id == 7)
		{
//			System.out.println("Carrega Transfus�es");
			model.addAttribute("unidades", daounid.ListaUnidadesGeral());
			model.addAttribute("transf", daonometransf.ListaNomeTransfusoes());
			return "admin/dadosmestre/divmestretransfusoes";
		}
		else
		if(id == 8)
		{
			model.addAttribute("sens", daosensi.ListaSensibilidade());
			return "admin/dadosmestre/divmestresensibilidade";
		}
		else
		if(id == 9)
		{
			model.addAttribute("microorg", daomicroorg.ListaMicroorganismos());
			return "admin/dadosmestre/divmestremicroorganismo";
		}
		else
		if(id == 10)
		{
			model.addAttribute("gcct", daogcct.ListaGCCT());
			model.addAttribute("hosp", daoHosp.ListaHospitais());
			return "admin/dadosmestre/divmestrehospitais";
		}
		else
		if(id == 11)
		{
			model.addAttribute("amostras", daoamostrasfo.ListaAmostrasFO());
			return "admin/dadosmestre/divmestreamostrasfo";
		}
		else
		if(id == 12)
		{
			model.addAttribute("espec", daoesp.ListaEspecialidade());
			return "admin/dadosmestre/divmestreespecialidade";
		}
		else
		if(id == 13)
		{
			model.addAttribute("estdador", daoestdador.ListaEstadoDador());
			return "admin/dadosmestre/divmestreestadodador";
		}
		else
		if(id == 14)
		{
			model.addAttribute("gcct", daogcct.ListaGCCT());
			return "admin/dadosmestre/divmestregcct";
		}
		else
		if(id == 15)
		{
			model.addAttribute("mb", daotipomb.ListaTipoMBAnalise());
			return "admin/dadosmestre/divmestretipomb";
		}
		else
		if(id == 16)
		{
			model.addAttribute("viro", daotipoviro.ListaTipoVirologia());
			return "admin/dadosmestre/divmestretipoviro";
		}
		else
		if(id == 17)
		{
			model.addAttribute("unid", daounid.ListaUnidadesGeral());
			return "admin/dadosmestre/divmestreunidades";
		}
		else
		if(id == 18)
		{
			model.addAttribute("hospital", daoHosp.ListaHospitais());
			model.addAttribute("unidtranspl", daounidtranspl.ListaUnidadeTransplante());
			return "admin/dadosmestre/divmestreunidtranspl";
		}
		else
		if(id == 19)
		{
			model.addAttribute("imuno", daoimunomestre.ListaImunossupressorMestre());
			return "admin/dadosmestre/divmestreimunosupressor";
		}
		else
		if(id == 20)
		{
			model.addAttribute("unidades", daounid.ListaUnidadesGeral());
			model.addAttribute("terap", daotipoterfollow.ListaTipoTerapeuticas());
			return "admin/dadosmestre/divmestreterapeuticasfollowup";
		}
		else
		if(id == 21)
		{
			
			model.addAttribute("hosp", daoHosp.ListaHospitais());
		//	model.addAttribute("unidtranspl", daounidtranspl.ListaUnidadeTransplante());
		//	model.addAttribute("unidhospital", daounidtransplhosp.ListaUnidade_Hospital());
			return "admin/dadosmestre/divmestrehospitalunidtransp";
		}
		else
		if(id == 22)
		{
			
			model.addAttribute("tipodiag", daotipodiag.ListaTipoDiagnostico());
			return "admin/dadosmestre/divmestretipodiagnosticohepatico";
		}
		else
		if(id == 23)
		{
			
			model.addAttribute("tipocompl", daotipocompl.ListaTipoComplicacoes());
			return "admin/dadosmestre/divmestretipocomplicacoeshepatico";
		}
		else
		return "admin/utilizadores";				
	}
	
	
	@RequestMapping("criavalordadosmestre2")
	@ResponseBody
	public String criavalordadosmestre2(int id, String desc, Long combo) 
	{	
		if(id == 10)
		{
			if(daoHosp.trataadicionar(desc, combo))
				return "true";
			else
				return "false";
		}else if(id == 6)
		{
			if(daoterap.trataadicionar(desc, combo))
				return "true";
			else
				return "false";
		}else if(id == 20)
		{
			if(daotipoterfollow.trataadicionar(desc, combo))
				return "true";
			else
				return "false";
		}
		else
		if(id == 3)
		{
			
			if(combo==null)
				combo = 21L;
			
//			System.out.println("Adiciona tipo gas. vent.: "+desc);
			if(daogasi.trataadicionar(desc, combo))
				return "true";
			else
				return "false";
		}
		else
			return "false";
	}
	
	@RequestMapping("criavalordadosmestre3")
	@ResponseBody
	public String criavalordadosmestre3(int id, String desc, Long combo, Long unid) 
	{	
		if(id == 7)
		{
			if(daonometransf.trataadicionar(desc, combo, unid))
				return "true";
			else
				return "false";
		}
		else
			return "false";
	}
	
	@RequestMapping("criavalordadosmestre")
	@ResponseBody
	public String criavalordadosmestre(int id, String desc) 
	{
		if(id == 1)
		{
//			System.out.println("Adiciona etnia: "+desc);
			if(daoetnia.trataadicionar(desc))
				return "true";
			else
				return "false";
		}
		else
		if(id == 2)
		{
//			System.out.println("Adiciona glasgow comma: "+desc);
			if(daoglasgow.trataadicionar(desc))
				return "true";
			else
				return "false";
		}
		else
		if(id == 4)
		{
//			System.out.println("Adiciona mecanimso morte: "+desc);
			if(daomecanismo.trataadicionar(desc))
				return "true";
			else
				return "false";
		}
		else
		if(id == 5)
		{
//			System.out.println("Adiciona causa morte: "+desc);
			if(daocausamorte.trataadicionar(desc))
				return "true";
			else
				return "false";
		}
		else
		if(id == 8)
		{
//			System.out.println("Adiciona vasopressor: "+desc);
			if(daosensi.trataadicionar(desc))
				return "true";
			else
				return "false";
		}
		else
		if(id == 9)
		{
//			System.out.println("Adiciona vasopressor: "+desc);
			if(daomicroorg.trataadicionar(desc))
				return "true";
			else
				return "false";
		}
		else
		if(id == 11)
		{
//			System.out.println("Adiciona vasopressor: "+desc);
			if(daoamostrasfo.trataadicionar(desc))
				return "true";
			else
				return "false";
		}
		else
		if(id == 12)
		{
//			System.out.println("Adiciona vasopressor: "+desc);
			if(daoesp.trataadicionar(desc))
				return "true";
			else
				return "false";
		}
		else
		if(id == 13)
		{
//			System.out.println("Adiciona vasopressor: "+desc);
			if(daoestdador.trataadicionar(desc))
				return "true";
			else
				return "false";
		}
		else
		if(id == 14)
		{
//			System.out.println("Adiciona vasopressor: "+desc);
			if(daogcct.trataadicionar(desc))
				return "true";
			else
				return "false";
		}
		else
		if(id == 15)
		{
//			System.out.println("Adiciona vasopressor: "+desc);
			if(daotipomb.trataadicionar(desc))
				return "true";
			else
				return "false";
		}
		else
		if(id == 16)
		{
//			System.out.println("Adiciona vasopressor: "+desc);
			if(daotipoviro.trataadicionar(desc))
				return "true";
			else
				return "false";
		}
		else
		if(id == 17)
		{
//			System.out.println("Adiciona vasopressor: "+desc);
			if(daounid.trataadicionar(desc))
				return "true";
			else
				return "false";
		}
		else
		if(id == 18)
		{
			if(daounidtranspl.trataadicionar(desc))
				return "true";
			else
				return "false";
		}
		else
		if(id == 19)
			{
//				System.out.println("Adiciona glasgow comma: "+desc);
				if(daoimunomestre.trataadicionar(desc))
					return "true";
				else
					return "false";
		}
		else
		if(id == 22)
			{

				if(daotipodiag.trataadicionar(desc))
					return "true";
				else
					return "false";
		}
		else
		if(id == 23)
			{

				if(daotipocompl.trataadicionar(desc))
					return "true";
				else
					return "false";
		}
		else
		return "false";
	}
	
	
	@RequestMapping("guardavalordadosmestre2")
	@ResponseBody
	public String guardavalordadosmestre2(Long id, String desc, int idtabela, Long combo) 
	{
		
		if(idtabela == 10)
		{
			if(daoHosp.trataalterar(id, desc, combo))
				return "true";
			else
				return "false";
		}		else
		if(idtabela == 6)
		{
//			System.out.println("Adiciona terapeutica: "+desc);
			if(daoterap.trataalterar(id, desc, combo))
				return "true";
			else
				return "false";
		}
		else
		if(idtabela == 3)
		{
//			System.out.println("Adiciona tipo gas. vent.: "+desc);
//			if(combo==null)
//				combo = 21L;
			
			if(daogasi.trataalterar(id, desc, combo))
				return "true";
			else
				return "false";
		}
		else
			if(idtabela == 20)
			{
//				System.out.println("Adiciona terapeutica: "+desc);
				if(daotipoterfollow.trataalterar(id, desc, combo))
					return "true";
				else
					return "false";
			}
		else
		return "false";
	}
	
	
	@RequestMapping("guardavalordadosmestre3")
	@ResponseBody
	public String guardavalordadosmestre3(Long id, String desc, int idtabela, Long combo, Long unid) 
	{
		
		if(idtabela == 7)
		{
			if(daonometransf.trataalterar(id, desc, combo, unid))
				return "true";
			else
				return "false";
		}
		else
		return "false";
	}
	
	@RequestMapping("guardavalordadosmestre")
	@ResponseBody
	public String guardavalordadosmestre(Long id, String desc, int idtabela) 
	{
		if(idtabela == 1)
		{
//			System.out.println("Altera etnia: "+desc);
			if(daoetnia.trataalterar(id, desc))
				return "true";
			else
				return "false";
		}
		else
		if(idtabela == 2)
		{
//			System.out.println("Altera glasgow comma: "+desc);
			if(daoglasgow.trataalterar(id, desc))
				return "true";
			else
				return "false";
		}
		else
		if(idtabela == 4)
		{
//			System.out.println("Altera mecanimos morte: "+desc);
			if(daomecanismo.trataalterar(id, desc))
				return "true";
			else
				return "false";
		}
		else
		if(idtabela == 5)
		{
//			System.out.println("Adiciona causa morte: "+desc);
			if(daocausamorte.trataalterar(id, desc))
				return "true";
			else
				return "false";
		}

		else
		if(idtabela == 8)
		{
			if(daosensi.trataalterar(id, desc))
				return "true";
			else
				return "false";
		}
		else
		if(idtabela == 9)
		{
			if(daomicroorg.trataalterar(id, desc))
				return "true";
			else
				return "false";
		}

		else
		if(idtabela == 11)
		{
			if(daoamostrasfo.trataalterar(id, desc))
				return "true";
			else
				return "false";
		}
		else
		if(idtabela == 12)
		{
			if(daoesp.trataalterar(id, desc))
				return "true";
			else
				return "false";
		}
		else
		if(idtabela == 13)
		{
			if(daoestdador.trataalterar(new BigDecimal(id).intValueExact(), desc))
				return "true";
			else
				return "false";
		}
		else
		if(idtabela == 14)
		{
			if(daogcct.trataalterar(id, desc))
				return "true";
			else
				return "false";
		}
		else
		if(idtabela == 15)
		{
			if(daotipomb.trataalterar(id, desc))
				return "true";
			else
				return "false";
		}
		else
		if(idtabela == 16)
		{
			if(daotipoviro.trataalterar(id, desc))
				return "true";
			else
				return "false";
		}
		else
		if(idtabela == 17)
		{
			if(daounid.trataalterar(id, desc))
				return "true";
			else
				return "false";
		}
		
		else if(idtabela == 18)
			{
				if(daounidtranspl.trataalterar(id, desc))
					return "true";
				else
					return "false";
		}
		else
		if(idtabela == 19)
			{
//				System.out.println("Altera glasgow comma: "+desc);
				if(daoimunomestre.trataalterar(id, desc))
					return "true";
				else
					return "false";
		}
		else
		return "false";
	}
	
	@RequestMapping("guardavalordadosmestretipodiag")
	@ResponseBody
	public String guardavalordadosmestretipodiag(int id, String desc, int idtabela) 
	{
		if(idtabela == 22)
		{
//			System.out.println("Altera glasgow comma: "+desc);
			if(daotipodiag.trataalterar(id, desc))
				return "true";
			else
				return "false";
		}
		else 
		if(idtabela == 23)
			{
//				System.out.println("Altera glasgow comma: "+desc);
				if(daotipocompl.trataalterar(id, desc))
					return "true";
				else
					return "false";
			}
		
		
		else
			return "false";
	}
	
	@RequestMapping("removedadosmestre")
	@ResponseBody
	public String removedadosmestre(Long id, int idtabela) 
	{
		if(idtabela == 1)
		{
//			System.out.println("Apagar etnia");
			if(daoetnia.remover(id))
				return "true";
			else
				return "false";
		}
		else
		if(idtabela == 2)
		{
//			System.out.println("Apagar glasgow comma");
			if(daoglasgow.remover(id))
				return "true";
			else
				return "false";
		}
		else
		if(idtabela == 3)
		{
//			System.out.println("Apagar tipo gas. vent.");
			if(daogasi.remover(id))
				return "true";
			else
				return "false";
		}
		else
		if(idtabela == 4)
		{
//			System.out.println("Apagar mecanismo morte");
			if(daomecanismo.remover(id))
				return "true";
			else
				return "false";
		}
		else
		if(idtabela == 5)
		{
//			System.out.println("Apagar causa morte");
			if(daocausamorte.remover(id))
				return "true";
			else
				return "false";
		}
		else
		if(idtabela == 6)
		{
//			System.out.println("Apagar terapeuticas");
			if(daoterap.remover(id))
				return "true";
			else
				return "false";
		}
		else
		if(idtabela == 7)
		{
////			System.out.println("Apagar transfus�o");
			if(daonometransf.remover(id))
				return "true";
			else
				return "false";
		}
		else
		if(idtabela == 8)
		{
			if(daosensi.remover(id))
				return "true";
			else
				return "false";
		}
		else
		if(idtabela == 9)
		{
			if(daomicroorg.remover(id))
				return "true";
			else
				return "false";
		}
		else
		if(idtabela == 10)
		{
			if(daoHosp.remover(id))
				return "true";
			else
				return "false";
		}
		else
		if(idtabela == 11)
		{
			if(daoamostrasfo.remover(id))
				return "true";
			else
				return "false";
		}
		else
		if(idtabela == 12)
		{
			if(daoesp.remover(id))
				return "true";
			else
				return "false";
		}
		else
		if(idtabela == 13)
		{
			if(daoestdador.remover(new BigDecimal(id).intValueExact()))
				return "true";
			else
				return "false";
		}
		else
		if(idtabela == 14)
		{
			if(daogcct.remover(id))
				return "true";
			else
				return "false";
		}
		else
		if(idtabela == 15)
		{
			if(daotipomb.remover(id))
				return "true";
			else
				return "false";
		}
		else
		if(idtabela == 16)
		{
			if(daotipoviro.remover(id))
				return "true";
			else
				return "false";
		}
		else
		if(idtabela == 17)
		{
			if(daounid.remover(id))
				return "true";
			else
				return "false";
		}
		else
		if(idtabela == 18)
		{
			if(daounidtranspl.remover(id))
				return "true";
			else
				return "false";
		}
		else
		if(idtabela == 19)
		{
			if(daoimunomestre.remover(id))
				return "true";
			else
				return "false";
		}
		else
			if(idtabela == 20)
			{
				if(daotipoterfollow.remover(id))
					return "true";
				else
					return "false";
			}
		else
		return "true";
	}

	@RequestMapping("removedadosmestretipodiag")
	@ResponseBody
	public String removedadosmestretipodiag(int id, int idtabela) 
	{
		
		if(idtabela == 22)
		{
//			System.out.println("Apagar etnia");
			if(daotipodiag.remover(id))
				return "true";
			else
				return "false";
		}else
		if(idtabela == 23)
			{
//				System.out.println("Apagar etnia");
				if(daotipocompl.remover(id))
					return "true";
				else
					return "false";
			}		
		
		else
		return "true";
		
	}
	
	@RequestMapping("addunidadesamostra")
	@Transactional
	public String addunidadesamostra(@RequestParam("idamostra") Long id_amostra, @RequestParam("unidades") Long id_unidades, Model model) 
	{
		UnidadesAmostrasFO unidamostra = new UnidadesAmostrasFO();
		unidamostra.setAmostraFO(daoamostrasfo.buscaPorId(id_amostra));
		unidamostra.setUnidadesGeral(daounid.buscaPorId(id_unidades));
		daounidamostras.adiciona(unidamostra);
		
		model.addAttribute("unidades", daounid.ListaUnidadesGeral());
		model.addAttribute("unidadesamostra", daounidamostras.listaunidadesamostrafo(id_amostra));
		return "admin/dadosmestre/divamostrasfounidades";	
		
	}
	
	@RequestMapping("removeunidadesamostra")
	@ResponseBody
	@Transactional
	public String removeunidadesamostra(Long id) 
	{
		daounidamostras.remove(daounidamostras.buscaPorId(id));
		return "true";
	}
	@RequestMapping("loadunidadesamostras")
	public String loadunidadesamostras(Long id, Model model) 
	{
		model.addAttribute("unidades", daounid.ListaUnidadesGeral());
		model.addAttribute("unidadesamostra", daounidamostras.listaunidadesamostrafo(id));
		return "admin/dadosmestre/divamostrasfounidades";	
		
	}
	
	@RequestMapping("mostraunidtransphospital")
	public String mostraunidtransphospital(@RequestParam("id_hosp") Long id_hosp, Model model) 
	{
		model.addAttribute("hospital", daoHosp.buscaPorId(id_hosp));
		model.addAttribute("unidhosp", daounidtransplhosp.buscaUnidadesTransplanteHospital(id_hosp));
		model.addAttribute("unidtransp", daounidtransplhosp.buscaUnidadesTransp_HospitalNaoExistentes(id_hosp));
		return "admin/dadosmestre/divmestreabreunidtransphospital";	
		
	}
	
	
	@RequestMapping(value="removeunidtransphospital", method = RequestMethod.POST)
	public String removeunidtransphospital(@RequestParam("id_unidtransp") Long id_unidtransp, @RequestParam("id_hospital") Long id_hospital, Model model) 
	{		

		daounidtransplhosp.removerunidadetransplantedohospital(id_unidtransp, id_hospital);
			
		return mostraunidtransphospital(id_hospital, model);
	}
	
	
	@RequestMapping(value="adicionaunidtransphospital", method = RequestMethod.POST)
	public String adicionaunidtransphospital(@RequestParam("id_unidtransp") Long id_unidtransp, @RequestParam("id_hospital") Long id_hospital, Model model) 
	{		

		Unidade_Hospital uh = new Unidade_Hospital();
		uh.setHosp(daoHosp.buscaPorId(id_hospital));
		uh.setUnidtransp(daounidtranspl.buscaPorId(id_unidtransp));
		daounidtransplhosp.adiciona(uh);
			
		return mostraunidtransphospital(id_hospital, model);
	}
}