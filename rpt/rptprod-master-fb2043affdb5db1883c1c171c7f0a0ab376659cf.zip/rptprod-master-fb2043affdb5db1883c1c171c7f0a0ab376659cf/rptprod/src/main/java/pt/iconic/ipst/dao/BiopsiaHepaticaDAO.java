package pt.iconic.ipst.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import pt.iconic.ipst.modelo.BiopsiaHepatica;


@Repository
@Transactional
public class BiopsiaHepaticaDAO {	
	
	@PersistenceContext
	private EntityManager manager;
	
	
	public void adiciona(BiopsiaHepatica biohepatica){
		manager.persist(biohepatica);	
	}
	

	public void atualiza(BiopsiaHepatica biohepatica){
		manager.merge(biohepatica);
	}
	

/*	@SuppressWarnings("unchecked")
	public List<BiopsiaHepatica> ListaBiopsiaHepatica(){
		return manager.createQuery("select a from BiopsiaHepatica a").getResultList();
	}*/
	
	public BiopsiaHepatica buscaPorId(Long id){
		return manager.find(BiopsiaHepatica.class, id);
	}
	
	
/*	public void remove(BiopsiaHepatica biohepatica){
		BiopsiaHepatica biohepaticaARemover = buscaPorId(biohepatica.getIdbiopsiahepatica());
		manager.remove(biohepaticaARemover);
		
	}*/
	
	@SuppressWarnings("unchecked")
	public BiopsiaHepatica buscabiopsiahepaticaanalise(Long idanalise){
		
		Query query = manager.createQuery("select b from BiopsiaHepatica b JOIN b.analiseDador a WHERE a.id_AnaliseDador =:idanalise");
		query.setParameter("idanalise", idanalise);
		
		List<BiopsiaHepatica> results = query.getResultList();
		BiopsiaHepatica biohepatica = null;
		if(!results.isEmpty()){
			biohepatica = (BiopsiaHepatica) results.get(0);
		}
		return biohepatica;
		
	}
}
