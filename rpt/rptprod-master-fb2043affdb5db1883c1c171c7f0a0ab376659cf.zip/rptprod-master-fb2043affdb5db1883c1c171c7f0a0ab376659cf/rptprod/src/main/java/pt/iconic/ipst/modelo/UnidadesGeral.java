package pt.iconic.ipst.modelo;

import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name="UNIDADES")
public class UnidadesGeral {

	private Long id_unidades;
	private String descricao;
//	private TipoTerapeuticas tipoTerapeuticas;
	private List<NomeTransfusoes> nomeTransfusoes;
	private List<UnidadesAmostrasFO> unidadesAmostrasFO;
	private List<AmostrasFuncoesOrgao> Amostra;
	private List<PPAnalisesRecetor> Analiserecetor;
	private List<TipoTerapeuticas> tipoTerapeuticas;
	private List<TipoGasVent> tipoGasVent;
	private List<TransplantePosOperatorioAnalises> analisestranspposop;
	
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="ID_UNIDADES")
	public Long getId_unidades() {
		return id_unidades;
	}
	public void setId_unidades(Long id_unidades) {
		this.id_unidades = id_unidades;
	}

	@Column(name="DESCRICAO")
	public String getDescricao() {
		return descricao;
	}
	public void setDescricao(String descricao) {
		this.descricao = descricao;
	}
	
	
	@OneToMany(fetch = FetchType.LAZY, mappedBy = "unidadesGeral")
	public List<UnidadesAmostrasFO> getUnidadesAmostrasFO() {
		return unidadesAmostrasFO;
	}
	public void setUnidadesAmostrasFO(List<UnidadesAmostrasFO> unidadesAmostrasFO) {
		this.unidadesAmostrasFO = unidadesAmostrasFO;
	}
	
	@OneToMany(fetch = FetchType.LAZY, mappedBy = "unidades")
	public List<AmostrasFuncoesOrgao> getAmostra() {
		return Amostra;
	}
	public void setAmostra(List<AmostrasFuncoesOrgao> amostra) {
		Amostra = amostra;
	}
	
    @OneToMany(fetch = FetchType.LAZY, mappedBy = "unidades")
	public List<TipoTerapeuticas> getTipoTerapeuticas() {
		return tipoTerapeuticas;
	}
	public void setTipoTerapeuticas(List<TipoTerapeuticas> tipoTerapeuticas) {
		this.tipoTerapeuticas = tipoTerapeuticas;
	}
	
	
    @OneToMany(fetch = FetchType.LAZY, mappedBy = "unidades")
	public List<NomeTransfusoes> getNomeTransfusoes() {
		return nomeTransfusoes;
	}
	public void setNomeTransfusoes(List<NomeTransfusoes> nomeTransfusoes) {
		this.nomeTransfusoes = nomeTransfusoes;
	}
	
    @OneToMany(fetch = FetchType.LAZY, mappedBy = "unidades")	
	public List<TipoGasVent> getTipoGasVent() {
		return tipoGasVent;
	}
	public void setTipoGasVent(List<TipoGasVent> tipoGasVent) {
		this.tipoGasVent = tipoGasVent;
	}
	
	@OneToMany(fetch = FetchType.LAZY, mappedBy = "unidades")
	public List<PPAnalisesRecetor> getAnaliserecetor() {
		return Analiserecetor;
	}
	public void setAnaliserecetor(List<PPAnalisesRecetor> analiserecetor) {
		Analiserecetor = analiserecetor;
	}
	
	@OneToMany(fetch = FetchType.LAZY, mappedBy = "unidades")
	public List<TransplantePosOperatorioAnalises> getAnalisestranspposop() {
		return analisestranspposop;
	}
	public void setAnalisestranspposop(List<TransplantePosOperatorioAnalises> analisestranspposop) {
		this.analisestranspposop = analisestranspposop;
	}
}