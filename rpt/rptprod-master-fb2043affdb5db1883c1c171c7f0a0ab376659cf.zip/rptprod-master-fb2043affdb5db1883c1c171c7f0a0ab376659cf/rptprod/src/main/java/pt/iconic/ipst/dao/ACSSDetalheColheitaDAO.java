package pt.iconic.ipst.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import pt.iconic.ipst.modelo.ACSSDetalheColheita;

@Repository
@Transactional
public class ACSSDetalheColheitaDAO 
{
	@PersistenceContext
	private EntityManager manager;
	
	
/*	public void adiciona(ACSSDetalheColheita acss){
		manager.persist(acss);	
	}*/
	
	public void atualiza(ACSSDetalheColheita acss){
		manager.merge(acss);
	}
	
/*	@SuppressWarnings("unchecked")
	public List<ACSSDetalheColheita> ListaACSSDetalheColheita(){
		return manager.createQuery("select d from ACSSDetalheColheita d").getResultList();
	}*/
	
	public ACSSDetalheColheita buscaPorId(Long id){
		return manager.find(ACSSDetalheColheita.class, id);
	}
	
/*	public void remove(ACSSDetalheColheita acss){
		ACSSDetalheColheita acssARemover = buscaPorId(acss.getIdacssdetalhe());
		manager.remove(acssARemover);
	}*/
	
	@SuppressWarnings("unchecked")
	public List<ACSSDetalheColheita> buscaACSSDetalheColheita(Long idgcct)
	{
		Query query = manager.createQuery("select b from ACSSDetalheColheita b JOIN b.gcctcolheita gcctcolheita WHERE gcctcolheita.idgcctcolheita =:idgcct");
		query.setParameter("idgcct", idgcct);
		
		List<ACSSDetalheColheita> results = query.getResultList();

		return results;
	}
	
	@SuppressWarnings("unchecked")
	public List<Object> buscaACSSDetalheAtos()
	{
		Query query = manager.createNativeQuery("select ACSSDETALHECOLHEITA.ID_ACSSDETALHECOLHEITA, ACSSDETALHECOLHEITA.ENTIDADE, ACSSDETALHECOLHEITA.VALOR, GCCTCOLHEITA.ATO, GCCTCOLHEITA.TIPO, GCCTCOLHEITA.CODIGODADOR, ACSSDETALHECOLHEITA.NOTAS "
				+ "from ACSSDETALHECOLHEITA join GCCTCOLHEITA on (ACSSDETALHECOLHEITA.ID_GCCTCOLHEITA = GCCTCOLHEITA.ID_GCCTCOLHEITA) where ACSSDETALHECOLHEITA.ID_COMPROMISSO is null");
		
		List<Object> results = query.getResultList();

		return results;
	}
	
	@SuppressWarnings("unchecked")
	public List<Object> buscaACSSDetalheAtosporEntidade(String nomeentidade)
	{
		Query query = manager.createNativeQuery("select ACSSDETALHECOLHEITA.ID_ACSSDETALHECOLHEITA, ACSSDETALHECOLHEITA.ENTIDADE, ACSSDETALHECOLHEITA.VALOR, GCCTCOLHEITA.ATO, GCCTCOLHEITA.TIPO, GCCTCOLHEITA.CODIGODADOR, ACSSDETALHECOLHEITA.NOTAS from ACSSDETALHECOLHEITA join GCCTCOLHEITA on (ACSSDETALHECOLHEITA.ID_GCCTCOLHEITA = GCCTCOLHEITA.ID_GCCTCOLHEITA) where ACSSDETALHECOLHEITA.ENTIDADE =:nomeentidade and ACSSDETALHECOLHEITA.ID_COMPROMISSO is null");
		query.setParameter("nomeentidade", nomeentidade);
		
		List<Object> results = query.getResultList();

		return results;
	}
	
	public Object buscaACSSDetalheAto(Long id)
	{
		Query query = manager.createNativeQuery("select ACSSDETALHECOLHEITA.ID_ACSSDETALHECOLHEITA, ACSSDETALHECOLHEITA.ENTIDADE, ACSSDETALHECOLHEITA.VALOR, GCCTCOLHEITA.ATO, GCCTCOLHEITA.TIPO, GCCTCOLHEITA.CODIGODADOR, ACSSDETALHECOLHEITA.NOTAS from ACSSDETALHECOLHEITA join GCCTCOLHEITA on (ACSSDETALHECOLHEITA.ID_GCCTCOLHEITA = GCCTCOLHEITA.ID_GCCTCOLHEITA) where ACSSDETALHECOLHEITA.ID_ACSSDETALHECOLHEITA =:id");
		query.setParameter("id", id);

		return query.getSingleResult();
	}

	@SuppressWarnings({ "unchecked" })
	public List<Object> buscavalorGCCT(long id) {
		
		Query query = manager.createNativeQuery("select (select vc1.VALOR from VALORESCOLHEITAS vc1 where vc1.TIPO = 6 and vc1.ATO = (select case when ((gc1.ATO = 'Colheita-PCC') OR (gc1.ATO = 'Colheita-MC') ) then 2 else 3 end from GCCTCOLHEITA gc1 where gc1.ID_GCCTCOLHEITA =:idgcctc )) as GCCT, "
				+ "(select GCCT.NOMEGCCT from GCCT inner join HOSPITAL h on (h.ID_GCCT = GCCT.ID_GCCT) "
				+ "where h.ID_HOSPITAL = (select gcctc.ID_HOSPITAL from GCCTCOLHEITA gcctc where gcctc.ID_GCCTCOLHEITA =:idgcctc)) as NOMEGCCT");
		query.setParameter("idgcctc", id);

		List<Object> results = query.getResultList();
		/*int count = 0;  
		for (Iterator i = results.iterator(); i.hasNext();) {  
		    Object[] values = (Object[]) i.next();  
		    System.out.println(++count + ": " + values[0] + ", " + values[1] +"<br />");  

		}  */
		return results;
	}

	@SuppressWarnings("unchecked")
	public boolean verificaexisteACSSDetalheColheita(Long idcolheita) {
		Query query = manager.createQuery("select b from ACSSDetalheColheita b JOIN b.gcctcolheita gcctcolheita WHERE gcctcolheita.idgcctcolheita =:idgcct");
		query.setParameter("idgcct", idcolheita);
		
		List<ACSSDetalheColheita> results = query.getResultList();
		
		if(!results.isEmpty()){
		return true;
		}else{
			return false;
		}
	}

	public void insereatoAcssDetalheColheita(Long idcolheita) {
		
		Query query = manager.createNativeQuery("insert into ACSSDETALHECOLHEITA (ENTIDADE, VALOR, ID_GCCTCOLHEITA, ORDEM) "
			+ "select (select GCCT.NOMEGCCT from GCCT inner join HOSPITAL h on (h.ID_GCCT = GCCT.ID_GCCT) where h.ID_HOSPITAL = (select gcctc.ID_HOSPITAL from GCCTCOLHEITA gcctc where gcctc.ID_GCCTCOLHEITA =:idcolheita)) as ENTIDADE, "
			+ "(select vc1.VALOR* ((select (select count(cc.COD_CORACAO) from COLHEITA_CORACAO cc inner join GCCTCOLHEITA gc on (gc.ID_ANALISEDADOR = cc.ID_ANALISEDADOR) where (len(cc.COD_CORACAO) > 0) and gc.ID_GCCTCOLHEITA =:idcolheita) + "
			+ "	(select COUNT(cf.COD_FIGADO) from COLHEITA_FIGADO cf inner join GCCTCOLHEITA gc on (gc.ID_ANALISEDADOR = cf.ID_ANALISEDADOR) where (len(cf.COD_FIGADO) > 0) and gc.ID_GCCTCOLHEITA =:idcolheita) + "
			+ "(select COUNT(cp.COD_PANCREAS) from COLHEITA_PANCREAS cp inner join GCCTCOLHEITA gc on (gc.ID_ANALISEDADOR = cp.ID_ANALISEDADOR) where (len(cp.COD_PANCREAS) > 0) and gc.ID_GCCTCOLHEITA =:idcolheita) + "
			+ "(select case when ((select COUNT(cp.COD_PULM_DIR) from COLHEITA_PULMOES cp inner join GCCTCOLHEITA gc on (gc.ID_ANALISEDADOR = cp.ID_ANALISEDADOR) where (len(cp.COD_PULM_DIR) > 0) and gc.ID_GCCTCOLHEITA =:idcolheita)>0) "
			+ "or ((select COUNT(cp.COD_PULM_ESQ) from COLHEITA_PULMOES cp inner join GCCTCOLHEITA gc on (gc.ID_ANALISEDADOR = cp.ID_ANALISEDADOR) where (len(cp.COD_PULM_ESQ) > 0) and gc.ID_GCCTCOLHEITA =:idcolheita)>0) "
			+ "then 1 else 0 end) + (select case when ((select COUNT(cr.COD_RIM_DIR) from COLHEITA_RINS cr inner join GCCTCOLHEITA gc on (gc.ID_ANALISEDADOR = cr.ID_ANALISEDADOR) where (len(cr.COD_RIM_DIR) > 0) and gc.ID_GCCTCOLHEITA =:idcolheita)>0) "
			+ "or "
			+ "((select COUNT(cr.COD_RIM_ESQ) from COLHEITA_RINS cr inner join GCCTCOLHEITA gc on (gc.ID_ANALISEDADOR = cr.ID_ANALISEDADOR) where (len(cr.COD_RIM_ESQ) > 0) and gc.ID_GCCTCOLHEITA =:idcolheita)>0) "
			+ "then 1 else 0 end))) from VALORESCOLHEITAS vc1 where vc1.TIPO = 6 and vc1.ATO =2) as VALOR, :idcolheita as id, '1' as ord "
			+ "union all "
			+ "select (select h.NOMEHOSPITAL from HOSPITAL h where h.ID_HOSPITAL = (select gcctc.ID_HOSPITAL from GCCTCOLHEITA gcctc where gcctc.ID_GCCTCOLHEITA =:idcolheita)) as ENTIDADE,"
			+ "	(case when 	((select gc.ATO from GCCTCOLHEITA gc where gc.ID_GCCTCOLHEITA =:idcolheita)='Colheita-CP') "
			+ "then (select ROUND(SUM(ORGAOS.VALOR),2) as VALOR  from (	(select	case when (gcd.ORGAO = 'C�rneas') then (select vc.VALOR from VALORESCOLHEITAS vc where vc.TIPO = 2 and vc.ANO =(select MAX(VALORESCOLHEITAS.ANO) from VALORESCOLHEITAS)) "
			+ "when (gcd.ORGAO = 'TME') then (select (vc.VALOR)+(select Case when "
			+ "((Select ((CASE WHEN tme.AEC_NRETIRADO = 'True' THEN 1 ELSE 0 END)+ (CASE WHEN tme.CI_NRETIRADO = 'True' THEN 1 ELSE 0 END) + (CASE WHEN tme.CX_NRETIRADO = 'True' THEN 1 ELSE 0 END) + "
			+ "(CASE WHEN tme.FL_NRETIRADO = 'True' THEN 1 ELSE 0 END) + (CASE WHEN tme.F_NRETIRADO = 'True' THEN 1 ELSE 0 END) + (CASE WHEN tme.HP_NRETIRADO = 'True' THEN 1 ELSE 0 END) + "
			+ "(CASE WHEN tme.OT_NRETIRADO = 'True' THEN 1 ELSE 0 END) + (CASE WHEN tme.P_NRETIRADO = 'True' THEN 1 ELSE 0 END) + (CASE WHEN tme.TACTL_NRETIRADO = 'True' THEN 1 ELSE 0 END) + "
			+ "(CASE WHEN tme.TAC_NRETIRADO = 'True' THEN 1 ELSE 0 END) + (CASE WHEN tme.TAEC_NRETIRADO = 'True' THEN 1 ELSE 0 END)+ (CASE WHEN tme.TG_NRETIRADO = 'True' THEN 1 ELSE 0 END) + "
			+ "(CASE WHEN tme.TM_NRETIRADO = 'True' THEN 1 ELSE 0 END)+ (CASE WHEN tme.TP_NRETIRADO = 'True' THEN 1 ELSE 0 END)+ (CASE WHEN tme.TQ_NRETIRADO = 'True' THEN 1 ELSE 0 END)+ "
			+ "(CASE WHEN tme.TR_NRETIRADO = 'True' THEN 1 ELSE 0 END)+ (CASE WHEN tme.TST_NRETIRADO = 'True' THEN 1 ELSE 0 END)+ (CASE WHEN tme.TTA_NRETIRADO = 'True' THEN 1 ELSE 0 END)+ "
			+ "(CASE WHEN tme.TTP_NRETIRADO = 'True' THEN 1 ELSE 0 END)+ (CASE WHEN tme.U_NRETIRADO = 'True' THEN 1 ELSE 0 END)+ (CASE WHEN tme.VL_NRETIRADO = 'True' THEN 1 ELSE 0 END)) "
			+ "from COLHEITA_TME tme inner join GCCTCOLHEITA gc on (gc.ID_ANALISEDADOR = tme.ID_ANALISEDADOR) where gc.ID_GCCTCOLHEITA =:idcolheita)	>2)	then "
			+ "((Select (((CASE WHEN tme.AEC_NRETIRADO = 'True' THEN 1 ELSE 0 END)+ (CASE WHEN tme.CI_NRETIRADO = 'True' THEN 1 ELSE 0 END) + (CASE WHEN tme.CX_NRETIRADO = 'True' THEN 1 ELSE 0 END) + "
			+ "(CASE WHEN tme.FL_NRETIRADO = 'True' THEN 1 ELSE 0 END) + (CASE WHEN tme.F_NRETIRADO = 'True' THEN 1 ELSE 0 END) + (CASE WHEN tme.HP_NRETIRADO = 'True' THEN 1 ELSE 0 END) + "
			+ "(CASE WHEN tme.OT_NRETIRADO = 'True' THEN 1 ELSE 0 END) + (CASE WHEN tme.P_NRETIRADO = 'True' THEN 1 ELSE 0 END) + (CASE WHEN tme.TACTL_NRETIRADO = 'True' THEN 1 ELSE 0 END) + "
			+ "(CASE WHEN tme.TAC_NRETIRADO = 'True' THEN 1 ELSE 0 END) + (CASE WHEN tme.TAEC_NRETIRADO = 'True' THEN 1 ELSE 0 END)+ (CASE WHEN tme.TG_NRETIRADO = 'True' THEN 1 ELSE 0 END) + "
			+ "(CASE WHEN tme.TM_NRETIRADO = 'True' THEN 1 ELSE 0 END)+ (CASE WHEN tme.TP_NRETIRADO = 'True' THEN 1 ELSE 0 END)+ (CASE WHEN tme.TQ_NRETIRADO = 'True' THEN 1 ELSE 0 END)+ "
			+ "(CASE WHEN tme.TR_NRETIRADO = 'True' THEN 1 ELSE 0 END)+ (CASE WHEN tme.TST_NRETIRADO = 'True' THEN 1 ELSE 0 END)+ (CASE WHEN tme.TTA_NRETIRADO = 'True' THEN 1 ELSE 0 END)+ "
			+ "(CASE WHEN tme.TTP_NRETIRADO = 'True' THEN 1 ELSE 0 END)+ (CASE WHEN tme.U_NRETIRADO = 'True' THEN 1 ELSE 0 END)+ "
			+ "(CASE WHEN tme.VL_NRETIRADO = 'True' THEN 1 ELSE 0 END))-2)*1.0*(select vc.SUPLEMENTAR*1.0 from VALORESCOLHEITAS vc where vc.ATO = 2 and vc.TIPO = 2 and vc.ANO "
			+ "=(select MAX(VALORESCOLHEITAS.ANO) from VALORESCOLHEITAS)) from COLHEITA_TME tme inner join GCCTCOLHEITA gc on (gc.ID_ANALISEDADOR = tme.ID_ANALISEDADOR) "
			+ "where gc.ID_GCCTCOLHEITA =:idcolheita)) else 0 end) "
			+ "from VALORESCOLHEITAS vc where vc.ATO = 2 and vc.TIPO = 2 and vc.ANO =(select MAX(VALORESCOLHEITAS.ANO) from VALORESCOLHEITAS))	"
			+ "when gcd.ORGAO = 'TC' then (select (vc.VALOR) from VALORESCOLHEITAS vc where vc.ATO = 2 and vc.TIPO = 2 and vc.ANO =(select MAX(VALORESCOLHEITAS.ANO) from VALORESCOLHEITAS)) "
			+ "when gcd.ORGAO = 'Pele' then (select (vc.VALOR)+(select Case when  "
			+ "((select cp.PECAS_ABDOMINAL+cp.PECAS_DORSO+cp.PECAS_OUTROS+cp.PECAS_PERNAS_ANT+cp.PECAS_PERNAS_POST+cp.PECAS_TORAX+cp.PECAS_TORSO  from COLHEITA_PELE cp inner join GCCTCOLHEITA gc on (cp.ID_ANALISEDADOR = gc.ID_ANALISEDADOR) where (len(cp.COD_PELE) > 0) and gc.ID_GCCTCOLHEITA =:idcolheita) >2) "
			+ "then (select (cp.PECAS_ABDOMINAL+cp.PECAS_DORSO+cp.PECAS_OUTROS+cp.PECAS_PERNAS_ANT+cp.PECAS_PERNAS_POST+cp.PECAS_TORAX+cp.PECAS_TORSO -2)*1.0*(select vc.SUPLEMENTAR*1.0 from VALORESCOLHEITAS vc where vc.ATO = 2 and vc.TIPO = 2 and vc.ANO = "
			+ "(select MAX(VALORESCOLHEITAS.ANO) from VALORESCOLHEITAS))  from COLHEITA_PELE cp inner join GCCTCOLHEITA gc on (cp.ID_ANALISEDADOR = gc.ID_ANALISEDADOR) where (len(cp.COD_PELE) > 0) and gc.ID_GCCTCOLHEITA =:idcolheita) else 0 end) "
			+ "from VALORESCOLHEITAS vc where vc.ATO = 2 and vc.TIPO = 2 and vc.ANO =(select MAX(VALORESCOLHEITAS.ANO) from VALORESCOLHEITAS)) "
			+ "when gcd.ORGAO = 'Vasos' then 	(select (vc.VALOR)+(select Case when ((select tv.AORTA_ABDOM_RETIRADA + tv.AORTA_TORAC_RETIRADA + tv.BIFURC_RETIRADA + tv.OUTROS_RETIRADA + "
			+ "tv.SEGM_IL_DIR_RETIRADO + tv.SEGM_IL_ESQ_RETIRADO from COLHEITA_VASOS tv inner join GCCTCOLHEITA gc on (gc.ID_ANALISEDADOR = tv.ID_ANALISEDADOR) where gc.ID_GCCTCOLHEITA =:idcolheita) >2) then "
			+ "(select (tv.AORTA_ABDOM_RETIRADA + tv.AORTA_TORAC_RETIRADA + tv.BIFURC_RETIRADA + tv.OUTROS_RETIRADA + tv.SEGM_IL_DIR_RETIRADO + tv.SEGM_IL_ESQ_RETIRADO -2)*1.0*(select vc.SUPLEMENTAR*1.0 from VALORESCOLHEITAS vc where vc.ATO = 2 and vc.TIPO = 2 and vc.ANO = "
			+ "(select MAX(VALORESCOLHEITAS.ANO) from VALORESCOLHEITAS)) from COLHEITA_VASOS tv inner join GCCTCOLHEITA gc on (gc.ID_ANALISEDADOR = tv.ID_ANALISEDADOR) where gc.ID_GCCTCOLHEITA =:idcolheita) else 0 end)  "
			+ "							from VALORESCOLHEITAS vc where vc.ATO = 2 and vc.TIPO = 2 and vc.ANO =(select MAX(VALORESCOLHEITAS.ANO) from VALORESCOLHEITAS))		 "
			+ "	else 0		 "
			+ " end as VALOR "
			+ " from GCCTCOLHEITA gc "
			+ " inner join GCCTCOLHEITADETALHE gcd on (gc.ID_GCCTCOLHEITA = gcd.ID_GCCTCOLHEITA) "
			+ " where gcd.ID_GCCTCOLHEITA =:idcolheita and gcd.ESTADO = 1 "
			+ " )) as ORGAOS "
			+ " ) "
			+ " when  "
			+ " ((select gc.ATO from GCCTCOLHEITA gc where gc.ID_GCCTCOLHEITA =:idcolheita)='Colheita-PCC')	 "
			+ " then	 "
			+ " (select (vc.VALOR) as VALOR from VALORESCOLHEITAS vc where vc.ATO = 2 and vc.TIPO = 5 and vc.ANO =(select MAX(VALORESCOLHEITAS.ANO) from VALORESCOLHEITAS)) "
			+ " when  "
			+ " (((select gc.ATO from GCCTCOLHEITA gc where gc.ID_GCCTCOLHEITA =:idcolheita)='Colheita-MC') and (select gc.TIPO from GCCTCOLHEITA gc where gc.ID_GCCTCOLHEITA =:idcolheita)='Simples') "
			+ " then  "
			+ " (select (vc.VALOR) as VALOR from VALORESCOLHEITAS vc where vc.ATO = 2 and vc.TIPO = 3 and vc.ANO =(select MAX(VALORESCOLHEITAS.ANO) from VALORESCOLHEITAS)) "
			+ "		when  "
			+ "	(((select gc.ATO from GCCTCOLHEITA gc where gc.ID_GCCTCOLHEITA =:idcolheita)='Colheita-MC') and (select gc.TIPO from GCCTCOLHEITA gc where gc.ID_GCCTCOLHEITA =:idcolheita)='Multi') "
			+ " then  "
			+ " (select (vc.VALOR) as VALOR from VALORESCOLHEITAS vc where vc.ATO = 2 and vc.TIPO = 4 and vc.ANO =(select MAX(VALORESCOLHEITAS.ANO) from VALORESCOLHEITAS)) "
			+ "		else 0  "
			+ "	end)*0.85 as TOTAL		 "
			+ " , :idcolheita as id, '2' as ord "
			+ " union all "
			+ " select h.NOMEHOSPITAL, "
			+ " ( select "
			+ " ROUND(SUM((ORGAOS.TOTAL)*0.15)/(select count(perm.ID_HOSPITAL) from EQUIPA_CIRURGIA ec "
			+ " inner join UTILIZADOR u on (u.ID_UTILIZADOR = ec.ID_UTILIZADOR) "
			+ " inner join PERMISSAO_LOCALIZACAO perm on (perm.ID_UTILIZADOR = u.ID_UTILIZADOR) "
			+ " where ec.INICIO = 0 AND ec.PRINCIPAL = 1 AND "
			+ " ec.ID_DADOR = (select gc.ID_DADOR from GCCTCOLHEITA gc where gc.ID_GCCTCOLHEITA =:idcolheita)) "
			+ " ,2)  "
			+ " from (	select (case  "
			+ " 	when  "
			+ " 	((select gc.ATO from GCCTCOLHEITA gc where gc.ID_GCCTCOLHEITA =:idcolheita)='Colheita-CP') "
			+ " then  "
			+ " 			(select ROUND(SUM(ORGAOS.VALOR),2) as VALOR "
			+ " from ( "
			+ " (select "
			+ " 					case  "
			+ " when (gcd.ORGAO = 'C�rneas') then (select vc.VALOR from VALORESCOLHEITAS vc where vc.TIPO = 2 and vc.ANO =(select MAX(VALORESCOLHEITAS.ANO) from VALORESCOLHEITAS)) "						
			+ " when (gcd.ORGAO = 'TME') then (select (vc.VALOR)+(select Case when "
			+ " ((Select ((CASE WHEN tme.AEC_NRETIRADO = 'True' THEN 1 ELSE 0 END)+ (CASE WHEN tme.CI_NRETIRADO = 'True' THEN 1 ELSE 0 END) + "
			+ "(CASE WHEN tme.CX_NRETIRADO = 'True' THEN 1 ELSE 0 END) + (CASE WHEN tme.FL_NRETIRADO = 'True' THEN 1 ELSE 0 END) + "
			+ "(CASE WHEN tme.F_NRETIRADO = 'True' THEN 1 ELSE 0 END) + (CASE WHEN tme.HP_NRETIRADO = 'True' THEN 1 ELSE 0 END) + "
			+ "(CASE WHEN tme.OT_NRETIRADO = 'True' THEN 1 ELSE 0 END) + (CASE WHEN tme.P_NRETIRADO = 'True' THEN 1 ELSE 0 END) + "
			+ "(CASE WHEN tme.TACTL_NRETIRADO = 'True' THEN 1 ELSE 0 END) + (CASE WHEN tme.TAC_NRETIRADO = 'True' THEN 1 ELSE 0 END) + "
			+ "(CASE WHEN tme.TAEC_NRETIRADO = 'True' THEN 1 ELSE 0 END)+ (CASE WHEN tme.TG_NRETIRADO = 'True' THEN 1 ELSE 0 END) + "
			+ "(CASE WHEN tme.TM_NRETIRADO = 'True' THEN 1 ELSE 0 END)+ (CASE WHEN tme.TP_NRETIRADO = 'True' THEN 1 ELSE 0 END)+ "
			+ "(CASE WHEN tme.TQ_NRETIRADO = 'True' THEN 1 ELSE 0 END)+ (CASE WHEN tme.TR_NRETIRADO = 'True' THEN 1 ELSE 0 END)+ "
			+ "(CASE WHEN tme.TST_NRETIRADO = 'True' THEN 1 ELSE 0 END)+ (CASE WHEN tme.TTA_NRETIRADO = 'True' THEN 1 ELSE 0 END)+ "
			+ "(CASE WHEN tme.TTP_NRETIRADO = 'True' THEN 1 ELSE 0 END)+ (CASE WHEN tme.U_NRETIRADO = 'True' THEN 1 ELSE 0 END)+ "
			+ "(CASE WHEN tme.VL_NRETIRADO = 'True' THEN 1 ELSE 0 END))from COLHEITA_TME tme inner join GCCTCOLHEITA gc on (gc.ID_ANALISEDADOR = tme.ID_ANALISEDADOR) where gc.ID_GCCTCOLHEITA =:idcolheita) "
			+ " >2) "
			+ " then "
			+ " ((Select (((CASE WHEN tme.AEC_NRETIRADO = 'True' THEN 1 ELSE 0 END)+ (CASE WHEN tme.CI_NRETIRADO = 'True' THEN 1 ELSE 0 END) + "
			+ "(CASE WHEN tme.CX_NRETIRADO = 'True' THEN 1 ELSE 0 END) + (CASE WHEN tme.FL_NRETIRADO = 'True' THEN 1 ELSE 0 END) + "
			+ "(CASE WHEN tme.F_NRETIRADO = 'True' THEN 1 ELSE 0 END) + (CASE WHEN tme.HP_NRETIRADO = 'True' THEN 1 ELSE 0 END) + "
			+ "(CASE WHEN tme.OT_NRETIRADO = 'True' THEN 1 ELSE 0 END) + (CASE WHEN tme.P_NRETIRADO = 'True' THEN 1 ELSE 0 END) + "
			+ "(CASE WHEN tme.TACTL_NRETIRADO = 'True' THEN 1 ELSE 0 END) + (CASE WHEN tme.TAC_NRETIRADO = 'True' THEN 1 ELSE 0 END) + "
			+ "(CASE WHEN tme.TAEC_NRETIRADO = 'True' THEN 1 ELSE 0 END)+ (CASE WHEN tme.TG_NRETIRADO = 'True' THEN 1 ELSE 0 END) + "
			+ "(CASE WHEN tme.TM_NRETIRADO = 'True' THEN 1 ELSE 0 END)+ (CASE WHEN tme.TP_NRETIRADO = 'True' THEN 1 ELSE 0 END)+ "
			+ "(CASE WHEN tme.TQ_NRETIRADO = 'True' THEN 1 ELSE 0 END)+ (CASE WHEN tme.TR_NRETIRADO = 'True' THEN 1 ELSE 0 END)+ "
			+ "(CASE WHEN tme.TST_NRETIRADO = 'True' THEN 1 ELSE 0 END)+ (CASE WHEN tme.TTA_NRETIRADO = 'True' THEN 1 ELSE 0 END)+ "
			+ "(CASE WHEN tme.TTP_NRETIRADO = 'True' THEN 1 ELSE 0 END)+ (CASE WHEN tme.U_NRETIRADO = 'True' THEN 1 ELSE 0 END)+ "
			+ "(CASE WHEN tme.VL_NRETIRADO = 'True' THEN 1 ELSE 0 END))-2)*1.0*(select vc.SUPLEMENTAR*1.0 from VALORESCOLHEITAS vc where vc.ATO = 2 and vc.TIPO = 2 and vc.ANO = "
			+ "(select MAX(VALORESCOLHEITAS.ANO) from VALORESCOLHEITAS)) from COLHEITA_TME tme inner join GCCTCOLHEITA gc on (gc.ID_ANALISEDADOR = tme.ID_ANALISEDADOR) where gc.ID_GCCTCOLHEITA =:idcolheita)) "
			+ " else 0 end) "
			+ " from VALORESCOLHEITAS vc where vc.ATO = 2 and vc.TIPO = 2 and vc.ANO =(select MAX(VALORESCOLHEITAS.ANO) from VALORESCOLHEITAS))	 "
			+ " when gcd.ORGAO = 'TC' then (select (vc.VALOR) from VALORESCOLHEITAS vc where vc.ATO = 2 and vc.TIPO = 2 and vc.ANO =(select MAX(VALORESCOLHEITAS.ANO) from VALORESCOLHEITAS)) "
			+ " when gcd.ORGAO = 'Pele' then (select (vc.VALOR)+(select Case when  "
			+ " ((select cp.PECAS_ABDOMINAL+cp.PECAS_DORSO+cp.PECAS_OUTROS+cp.PECAS_PERNAS_ANT+cp.PECAS_PERNAS_POST+cp.PECAS_TORAX+cp.PECAS_TORSO  from COLHEITA_PELE cp inner join GCCTCOLHEITA gc on (cp.ID_ANALISEDADOR = gc.ID_ANALISEDADOR) where (len(cp.COD_PELE) > 0) and gc.ID_GCCTCOLHEITA =:idcolheita) "
			+ " >2)  "
			+ " then  "
			+ " (select (cp.PECAS_ABDOMINAL+cp.PECAS_DORSO+cp.PECAS_OUTROS+cp.PECAS_PERNAS_ANT+cp.PECAS_PERNAS_POST+cp.PECAS_TORAX+cp.PECAS_TORSO -2)*1.0*(select vc.SUPLEMENTAR*1.0 from VALORESCOLHEITAS vc where vc.ATO = 2 and vc.TIPO = 2 and vc.ANO =(select MAX(VALORESCOLHEITAS.ANO) from VALORESCOLHEITAS))  from COLHEITA_PELE cp inner join GCCTCOLHEITA gc on (cp.ID_ANALISEDADOR = gc.ID_ANALISEDADOR) where (len(cp.COD_PELE) > 0) and gc.ID_GCCTCOLHEITA =:idcolheita) "	
			+ " else 0 end)  "
			+ " from VALORESCOLHEITAS vc where vc.ATO = 2 and vc.TIPO = 2 and vc.ANO =(select MAX(VALORESCOLHEITAS.ANO) from VALORESCOLHEITAS))	 "
			+ " when gcd.ORGAO = 'Vasos' then 	(select (vc.VALOR)+(select Case when "
			+ " ((select tv.AORTA_ABDOM_RETIRADA + tv.AORTA_TORAC_RETIRADA + tv.BIFURC_RETIRADA + tv.OUTROS_RETIRADA + tv.SEGM_IL_DIR_RETIRADO + tv.SEGM_IL_ESQ_RETIRADO from COLHEITA_VASOS tv inner join GCCTCOLHEITA gc on (gc.ID_ANALISEDADOR = tv.ID_ANALISEDADOR) where gc.ID_GCCTCOLHEITA =:idcolheita) "
			+ " >2) "
			+ " then "
			+ " (select (tv.AORTA_ABDOM_RETIRADA + tv.AORTA_TORAC_RETIRADA + tv.BIFURC_RETIRADA + tv.OUTROS_RETIRADA + tv.SEGM_IL_DIR_RETIRADO + tv.SEGM_IL_ESQ_RETIRADO -2)*1.0*(select vc.SUPLEMENTAR*1.0 from VALORESCOLHEITAS vc where vc.ATO = 2 and vc.TIPO = 2 and vc.ANO =(select MAX(VALORESCOLHEITAS.ANO) from VALORESCOLHEITAS)) from COLHEITA_VASOS tv inner join GCCTCOLHEITA gc on (gc.ID_ANALISEDADOR = tv.ID_ANALISEDADOR) where gc.ID_GCCTCOLHEITA =:idcolheita) "
			+ " else 0 end)  "
			+ " from VALORESCOLHEITAS vc where vc.ATO = 2 and vc.TIPO = 2 and vc.ANO =(select MAX(VALORESCOLHEITAS.ANO) from VALORESCOLHEITAS))	 "
			+ " else 0	 "	
			+ " end as VALOR "
			+ " from GCCTCOLHEITA gc "
			+ " inner join GCCTCOLHEITADETALHE gcd on (gc.ID_GCCTCOLHEITA = gcd.ID_GCCTCOLHEITA) "
			+ " where gcd.ID_GCCTCOLHEITA =:idcolheita and gcd.ESTADO = 1 "
			+ " )) as ORGAOS "
			+ " ) "
			+ " when  "
			+ " ((select gc.ATO from GCCTCOLHEITA gc where gc.ID_GCCTCOLHEITA =:idcolheita)='Colheita-PCC')	 "
			+ " then	 "
			+ " (select (vc.VALOR) as VALOR from VALORESCOLHEITAS vc where vc.ATO = 2 and vc.TIPO = 5 and vc.ANO =(select MAX(VALORESCOLHEITAS.ANO) from VALORESCOLHEITAS)) "		
			+ " when  "
			+ " (((select gc.ATO from GCCTCOLHEITA gc where gc.ID_GCCTCOLHEITA =:idcolheita)='Colheita-MC') and (select gc.TIPO from GCCTCOLHEITA gc where gc.ID_GCCTCOLHEITA =:idcolheita)='Simples') "
			+ " then  "
			+ " (select (vc.VALOR) as VALOR from VALORESCOLHEITAS vc where vc.ATO = 2 and vc.TIPO = 3 and vc.ANO =(select MAX(VALORESCOLHEITAS.ANO) from VALORESCOLHEITAS)) "		
			+ " when "
			+ " (((select gc.ATO from GCCTCOLHEITA gc where gc.ID_GCCTCOLHEITA =:idcolheita)='Colheita-MC') and (select gc.TIPO from GCCTCOLHEITA gc where gc.ID_GCCTCOLHEITA =:idcolheita)='Multi') "
			+ " then  "
			+ " (select (vc.VALOR) as VALOR from VALORESCOLHEITAS vc where vc.ATO = 2 and vc.TIPO = 4 and vc.ANO =(select MAX(VALORESCOLHEITAS.ANO) from VALORESCOLHEITAS)) " 
			+ " else 0  "
			+ " end) as TOTAL "
			+ " ) as ORGAOS ) "
			+ " ,  :idcolheita as id, '3' as ord "
			+ " from EQUIPA_CIRURGIA ec "
			+ " inner join UTILIZADOR u on (u.ID_UTILIZADOR = ec.ID_UTILIZADOR) "
			+ " inner join PERMISSAO_LOCALIZACAO perm on (perm.ID_UTILIZADOR = u.ID_UTILIZADOR) "
			+ " inner join HOSPITAL h on (h.ID_HOSPITAL = perm.ID_HOSPITAL) "
			+ " where ec.INICIO = 0 AND ec.PRINCIPAL = 1 AND "
			+ " ec.ID_DADOR = (select gc.ID_DADOR from GCCTCOLHEITA gc where gc.ID_GCCTCOLHEITA =:idcolheita) "
			+ " order by ord");
		query.setParameter("idcolheita", idcolheita);
		query.executeUpdate();
		
	}

	public void insereatoAcssDetalheTransplante(Long idcolheita, int idorgaooferta, int tipo, Long iddador) {
		
		//org�os multiplos conta como 2
		if(idorgaooferta == 3 || idorgaooferta == 7){
			Query query = manager.createNativeQuery("insert into ACSSDETALHECOLHEITA (ENTIDADE, VALOR, ID_GCCTCOLHEITA, ORDEM) "
					+ "select h.NOMEHOSPITAL as ENTIDADE, (select ROUND(v.VALOR*0.9*2,2) from VALORESCOLHEITAS v "
					+ "where v.ATO =3 and v.TIPO =:tipo ) as VALOR,  :idcolheita as id, '1' as ord "
					+ "from EQUIPA_LOCAL_TRANSPLANTE el "
					+ "inner join HOSPITAL h on (el.ID_HOSPITAL = h.ID_HOSPITAL) "
					+ "inner join ASSIGNACAO_ORGAOS ao on (ao.ID_ASSIGNACAO_ORGAOS = el.ID_ASSIG_ORGAO) "
					+ "where ao.ID_DADOR = :iddador and ao.ID_ORGAOOFERTA = :idorgaooferta");
			
			query.setParameter("idcolheita", idcolheita);
			query.setParameter("idorgaooferta", idorgaooferta);
			query.setParameter("iddador", iddador);
			query.setParameter("tipo", tipo);
			query.executeUpdate();
			
		}else{//orgao simples
		
		
		Query query = manager.createNativeQuery("insert into ACSSDETALHECOLHEITA (ENTIDADE, VALOR, ID_GCCTCOLHEITA, ORDEM) "
				+ "select h.NOMEHOSPITAL as ENTIDADE, (select ROUND(v.VALOR*0.9,2) from VALORESCOLHEITAS v "
				+ "where v.ATO =3 and v.TIPO =:tipo ) as VALOR,  :idcolheita as id, '1' as ord "
				+ "from EQUIPA_LOCAL_TRANSPLANTE el "
				+ "inner join HOSPITAL h on (el.ID_HOSPITAL = h.ID_HOSPITAL) "
				+ "inner join ASSIGNACAO_ORGAOS ao on (ao.ID_ASSIGNACAO_ORGAOS = el.ID_ASSIG_ORGAO) "
				+ "where ao.ID_DADOR = :iddador and ao.ID_ORGAOOFERTA = :idorgaooferta");
				
/*				+ "from EQUIPA_CIRURGIA_TRANSPLANTE ec "
				+ "inner join UTILIZADOR u on (u.ID_UTILIZADOR = ec.ID_UTILIZADOR) "
				+ "inner join PERMISSAO_LOCALIZACAO perm on (perm.ID_UTILIZADOR = u.ID_UTILIZADOR) "
				+ "inner join HOSPITAL h on (h.ID_HOSPITAL = perm.ID_HOSPITAL) "
				+ "where ec.INICIO <> 99 AND ec.PRINCIPAL = 1 AND "
				+ "ec.ID_ASSIG_ORGAO = (select ao.ID_ASSIGNACAO_ORGAOS from GCCTCOLHEITA gc "
				+ "inner join ASSIGNACAO_ORGAOS ao on (ao.ID_DADOR = gc.ID_DADOR) "
				+ "where gc.ID_GCCTCOLHEITA = :idcolheita and ao.ID_ORGAOOFERTA = :idorgaooferta)"
				+ "");*/
		
		query.setParameter("idcolheita", idcolheita);
		query.setParameter("idorgaooferta", idorgaooferta);
		query.setParameter("iddador", iddador);
		query.setParameter("tipo", tipo);
		query.executeUpdate();
		}
		
	}

	public int atualizaACSSDetalheDoCompromisso(Long idcompromisso, String caminho) {
		Query query = manager.createNativeQuery("Update ACSSDETALHECOLHEITA set CAMINHOFATURA = :caminho where ACSSDETALHECOLHEITA.ID_COMPROMISSO =:idcompromisso");
		query.setParameter("idcompromisso", idcompromisso);
		query.setParameter("caminho", caminho);
		return query.executeUpdate();

	}
}
