package pt.iconic.ipst.modelo;

import java.util.Calendar;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name = "AMOSTRASFUNCOESORGAOTAB")
public class AmostrasFuncoesOrgao {

	
	private Long id_amostrasfuncoesorgao;
	private TipoAmostraFO tipoAmostra; //Basal, Amostra2, Amostra3, Amostra4
	private AmostrasFO amostra; //nome das amostras
	private float valoramostra;
	private UnidadesGeral unidades;
	private Calendar datahora;
	private String observamostras;
	private AnaliseDador analiseDador;
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="ID_AMOSTRASFUNCOESORGAO")
	public Long getId_amostrasfuncoesorgao() {
		return id_amostrasfuncoesorgao;
	}
	public void setId_amostrasfuncoesorgao(Long id_amostrasfuncoesorgao) {
		this.id_amostrasfuncoesorgao = id_amostrasfuncoesorgao;
	}
	
    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "ID_TIPOAMOSTRA")
	public TipoAmostraFO getTipoAmostra() {
		return tipoAmostra;
	}
	public void setTipoAmostra(TipoAmostraFO tipoAmostra) {
		this.tipoAmostra = tipoAmostra;
	}

    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "ID_AMOSTRAFO")
	public AmostrasFO getAmostra() {
		return amostra;
	}
	public void setAmostra(AmostrasFO amostra) {
		this.amostra = amostra;
	}
	@Column(name="VALORAMOSTRA")
	public float getValoramostra() {
		return valoramostra;
	}
	public void setValoramostra(float valoramostra) {
		this.valoramostra = valoramostra;
	}
	
    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "ID_UNIDADES")
	public UnidadesGeral getUnidades() {
		return unidades;
	}
	public void setUnidades(UnidadesGeral unidades) {
		this.unidades = unidades;
	}
	@Column(name="DATAHORA")
	public Calendar getDatahora() {
		return datahora;
	}
	public void setDatahora(Calendar datahora) {
		this.datahora = datahora;
	}

	@Column(name="OBSERVAMOSTRAS" , length=100)
    public String getObservamostras() {
		return observamostras;
	}
	public void setObservamostras(String observamostras) {
		this.observamostras = observamostras;
	}
	
	@ManyToOne
	@JoinColumn(name="ID_ANALISEDADOR")
	public AnaliseDador getAnaliseDador() {
		return analiseDador;
	}
	public void setAnaliseDador(AnaliseDador analiseDador) {
		this.analiseDador = analiseDador;
	}

	
}
