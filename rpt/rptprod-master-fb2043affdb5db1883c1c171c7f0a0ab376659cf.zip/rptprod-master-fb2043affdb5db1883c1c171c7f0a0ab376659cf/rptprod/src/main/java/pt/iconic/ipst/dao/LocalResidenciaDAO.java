package pt.iconic.ipst.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.springframework.stereotype.Repository;

import pt.iconic.ipst.modelo.LocalResidencia;

@Repository
public class LocalResidenciaDAO 
{
	@PersistenceContext
	private EntityManager manager;
	
/*	public void adiciona(LocalResidencia res){
		manager.persist(res);	
	}

	public void atualiza(LocalResidencia res){
		manager.merge(res);
	}*/

	public LocalResidencia buscaPorId(int id){
		return manager.find(LocalResidencia.class, id);
	}
	
/*	public void remove(LocalResidencia res){
		LocalResidencia resaremover = buscaPorId(res.getId_residencia());
		manager.remove(resaremover);
	}*/
	
	@SuppressWarnings("unchecked")
	public List<LocalResidencia> ListaLocalResidencia(){
		return manager.createQuery("select c from LocalResidencia c ORDER by c.nome").getResultList();
	}
}