package pt.iconic.ipst.modelo;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name = "BIOPSIA_RENAL_ITENS")
public class BiopsiarenalItens {

	private Long iditem;
	private int item;
	private int quantificacao;
	private boolean diresq;
	private AnaliseDador analiseDador;
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="ID_ITEM")
	public Long getIditem() {
		return iditem;
	}
	public void setIditem(Long iditem) {
		this.iditem = iditem;
	}
	
	@Column(name="ITEM")
	public int getItem() {
		return item;
	}
	public void setItem(int item) {
		this.item = item;
	}
	@Column(name="QUANTIFICACAO")
	public int getQuantificacao() {
		return quantificacao;
	}
	public void setQuantificacao(int quantificacao) {
		this.quantificacao = quantificacao;
	}
	
	@Column(name="DIRESQTABELA")
	public boolean isDiresq() {
		return diresq;
	}
	public void setDiresq(boolean diresq) {
		this.diresq = diresq;
	}
	
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="ID_ANALISEDADOR")
	public AnaliseDador getAnaliseDador() {
		return analiseDador;
	}
	public void setAnaliseDador(AnaliseDador analiseDador) {
		this.analiseDador = analiseDador;
	}
	
}
