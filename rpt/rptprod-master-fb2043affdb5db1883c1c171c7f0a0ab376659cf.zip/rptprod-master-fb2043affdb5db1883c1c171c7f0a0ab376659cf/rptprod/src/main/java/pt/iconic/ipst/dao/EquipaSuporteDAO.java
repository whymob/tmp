package pt.iconic.ipst.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import pt.iconic.ipst.modelo.EquipaSuporte;

@Repository
@Transactional
public class EquipaSuporteDAO {

	
	@PersistenceContext
	private EntityManager manager;
	
	
	public void adiciona(EquipaSuporte es){
		manager.persist(es);	
	}
	
	public void atualiza(EquipaSuporte es){
		manager.merge(es);
	}
	

/*	@SuppressWarnings("unchecked")
	public List<EquipaSuporte> ListaEquipaSuporte(){
		return manager.createQuery("select a from EquipaSuporte a").getResultList();
	}*/
	
	public EquipaSuporte buscaPorId(Long id){
		return manager.find(EquipaSuporte.class, id);
	}
	
	
	public void remove(EquipaSuporte es){
		EquipaSuporte esARemover = buscaPorId(es.getIdequipasuporte());
		manager.remove(esARemover);
	}

	@SuppressWarnings("unchecked")
	public List<EquipaSuporte> buscaequipacsuportedador(Long id_Dador) {
		
		Query query = manager.createQuery("select es from EquipaSuporte es JOIN es.dador d where d.id_Dador =:iddador");
		query.setParameter("iddador", id_Dador);

		List<EquipaSuporte> results = query.getResultList();
		
		return results;
	}
	
}
