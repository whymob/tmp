package pt.iconic.ipst.dao;


import java.util.Calendar;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import pt.iconic.ipst.modelo.AmostrasFO;
import pt.iconic.ipst.modelo.AmostrasFuncoesOrgao;
import pt.iconic.ipst.modelo.AnaliseDador;
import pt.iconic.ipst.modelo.TipoAmostraFO;


@Repository
public class AmostrasFuncoesOrgaoDAO {

	
	@PersistenceContext
	private EntityManager manager;
	
	
/*	public void adiciona(AmostrasFuncoesOrgao amostrasfo){
		manager.persist(amostrasfo);	
	}*/
	
	@Transactional
	public void atualiza(AmostrasFuncoesOrgao amostrasfo){
		manager.merge(amostrasfo);
	}
	

/*	@SuppressWarnings("unchecked")
	public List<AmostrasFuncoesOrgao> ListaAmostrasFuncoesOrgao(){
		return manager.createQuery("select d from AmostrasFuncoesOrgao d").getResultList();
	}*/
	
	public AmostrasFuncoesOrgao buscaPorId(Long id){
		return manager.find(AmostrasFuncoesOrgao.class, id);
	}
	
	
/*	public void remove(AmostrasFuncoesOrgao amostrasfo){
		AmostrasFuncoesOrgao amostrasfoARemover = buscaPorId(amostrasfo.getId_amostrasfuncoesorgao());
		manager.remove(amostrasfoARemover);
		
	}*/
	
//	@SuppressWarnings("unchecked")
//	public List<AmostrasFuncoesOrgao> buscaamostrasanalise(Long idanalise){
//		
//		Query query = manager.createQuery("select a from AmostrasFuncoesOrgao a JOIN a.analiseDador an JOIN a.tipoAmostra t Join a.amostra am WHERE an.id_AnaliseDador =:idanalise ORDER BY t.id_tipoamostra, am.nomeamostra  ASC");
//		query.setParameter("idanalise", idanalise);
//		
//		List<AmostrasFuncoesOrgao> results = query.getResultList();
//
//		return results;
//	}
	
	//carrega as amostras quando insere as 40 para que as da ultima amostra apare�am em cima
	@SuppressWarnings("unchecked")
	public List<AmostrasFuncoesOrgao> buscaamostrasanaliseDescendente(Long idanalise){
		
		Query query = manager.createQuery("select a from AmostrasFuncoesOrgao a JOIN a.analiseDador an JOIN a.tipoAmostra t LEFT JOIN a.amostra amostrafo WHERE an.id_AnaliseDador =:idanalise  ORDER BY t.id_tipoamostra DESC");
		query.setParameter("idanalise", idanalise);
		
		List<AmostrasFuncoesOrgao> results = query.getResultList();

		return results;
	}
	
	
	//adiciona as 40 amostras � tabela
	@SuppressWarnings("unchecked")
	@Transactional
	public boolean adicionaitensamostras(Long amostra, Calendar data, Long id_analise){
//		System.out.println("amostra: "+amostra+",data: "+data.getTime()+" para a amostra: "+id_analise);
		Query nomesamostras = manager.createQuery("select a from AmostrasFO a");
		List<AmostrasFO> amostras = nomesamostras.getResultList();
		
		AnaliseDador analise = manager.find(AnaliseDador.class, id_analise);
		

		for (int i=0; i<amostras.size(); i++){
			AmostrasFuncoesOrgao amostrafo = new AmostrasFuncoesOrgao();
			amostrafo.setAnaliseDador(analise);
		//	System.out.println("amostraaaaaa: "+amostras.get(i));
			amostrafo.setAmostra(amostras.get(i));
			amostrafo.setDatahora(data);
			amostrafo.setTipoAmostra(manager.find(TipoAmostraFO.class, amostra));
			manager.persist(amostrafo);
		}
		
		return true;
	}
	
	//Busca amostras da analise para calculo do minimo
	public Float calculoMinimoAmostrasAnalise(Long idanalise, Long idamostra){
	
		Object valor;
		Query query = manager.createQuery ("select MIN(a.valoramostra) from AmostrasFuncoesOrgao a JOIN a.analiseDador an JOIN a.amostra am WHERE an.id_AnaliseDador =:idanalise AND am.id_amostrafo= :idamostra AND a.valoramostra>0");

		//	Query query = manager.createQuery("select max(a.valoramostra) from AmostrasFuncoesOrgao a JOIN a.analiseDador an JOIN a.amostra am WHERE an.id_AnaliseDador =:idanalise AND am.id_amostrafo= :idamostra");
		query.setParameter("idanalise", idanalise);
		query.setParameter("idamostra", idamostra);
		valor = query.getResultList().get(0);
	//	valor = query.getSingleResult().floatValue();
	//	System.out.println("Minimo: "+ valor);
//		System.out.println("O minimo valor para a amostra "+idamostra+" da an�lise"+idanalise+" � "+valor);
		if(valor == null){
			valor= (float )0;
		}
	//	System.out.println("Minimo2: "+ valor);
	return (float) valor;
	}
	
	//Busca amostras da analise para calculo do maximo
	public float calculoMaximoAmostrasAnalise(Long idanalise, Long idamostra){
		float valor;
		TypedQuery<Float> query = manager.createQuery ("select MAX(a.valoramostra) from AmostrasFuncoesOrgao a JOIN a.analiseDador an JOIN a.amostra am WHERE an.id_AnaliseDador =:idanalise AND am.id_amostrafo= :idamostra",Float.class);

		//	Query query = manager.createQuery("select max(a.valoramostra) from AmostrasFuncoesOrgao a JOIN a.analiseDador an JOIN a.amostra am WHERE an.id_AnaliseDador =:idanalise AND am.id_amostrafo= :idamostra");
		query.setParameter("idanalise", idanalise);
		query.setParameter("idamostra", idamostra);
		valor = query.getSingleResult().floatValue();
//		System.out.println("Maximo: "+ valor);
//		System.out.println("O maximo valor para a amostra "+idamostra+" da an�lise"+idanalise+" � "+valor);

	return valor;
	}
	
	//Busca amostras da analise para calculo do media
	public double calculoMediaAmostrasAnalise(Long idanalise, Long idamostra){
	//	float valor;
		Query query = manager.createNativeQuery("select  AVG(amostras.VALORAMOSTRA) as media "
				+ "from AMOSTRASFUNCOESORGAOTAB amostras "
				+ "inner join ANALISEDADOR analise on amostras.ID_ANALISEDADOR=analise.ID_ANALISEDADOR "
				+ "inner join AMOSTRASFO amostrasfo on amostras.ID_AMOSTRAFO=amostrasfo.ID_AMOSTRAFO "
				+ "where analise.ID_ANALISEDADOR= :idanalise and amostrasfo.ID_AMOSTRAFO= :idamostra and amostras.valoramostra>0");

	//	TypedQuery<Double> query = manager.createQuery ("select AVG(CAST((a.valoramostra) AS DECIMAL(12,2))) from AmostrasFuncoesOrgao a JOIN a.analiseDador an JOIN a.amostra am WHERE an.id_AnaliseDador =:idanalise AND am.id_amostrafo= :idamostra",Double.class);

		//	Query query = manager.createQuery("select max(a.valoramostra) from AmostrasFuncoesOrgao a JOIN a.analiseDador an JOIN a.amostra am WHERE an.id_AnaliseDador =:idanalise AND am.id_amostrafo= :idamostra");
		query.setParameter("idanalise", idanalise);
		query.setParameter("idamostra", idamostra);
		Double valor =  (Double) query.getSingleResult();
//		System.out.println("M�dia: "+valor);
		if(valor==null){
			valor = 0.0;
		}	
			
//		System.out.println("A media dos valores para a amostra "+idamostra+" da an�lise"+idanalise+" � "+valor);

	return valor;
	}
	
	@SuppressWarnings("unchecked")
	public List<AmostrasFuncoesOrgao> buscatipoamostrasanalisetransfusao(Long idanalise){
		
		Query query = manager.createQuery("select distinct t from AmostrasFuncoesOrgao a JOIN a.analiseDador an JOIN a.tipoAmostra t WHERE an.id_AnaliseDador =:idanalise");
		query.setParameter("idanalise", idanalise);
		
		List<AmostrasFuncoesOrgao> results = query.getResultList();

		return results;
	}
	
	
}
