package pt.iconic.ipst.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import pt.iconic.ipst.modelo.ImunossupressorMestre;

@Repository
@Transactional
public class ImunossupressorMestreDAO 
{
	@PersistenceContext
	private EntityManager manager;
	
	public void adiciona(ImunossupressorMestre imu){
		manager.persist(imu);	
	}
	
	public void atualiza(ImunossupressorMestre imu){
		manager.merge(imu);
	}

	@SuppressWarnings("unchecked")
	public List<ImunossupressorMestre> ListaImunossupressorMestre(){
		return manager.createQuery("select d from ImunossupressorMestre d").getResultList();
	}
	
	public ImunossupressorMestre buscaPorId(Long id){
		return manager.find(ImunossupressorMestre.class, id);
	}
	
	public void remove(ImunossupressorMestre imu){
		ImunossupressorMestre imurem = buscaPorId(imu.getId_imuno());
		manager.remove(imurem);
	}
	
	public boolean trataadicionar(String desc)
	{
		Query query = manager.createQuery("SELECT e FROM ImunossupressorMestre e WHERE e.nome =:desc");
		query.setParameter("desc", desc);
		
		if(query.getResultList().isEmpty())
		{
			ImunossupressorMestre im = new ImunossupressorMestre();
			im.setNome(desc);
			adiciona(im);
			
			return true;
		}
		else
		{
			return false;
		}
	}
	
	public boolean trataalterar(Long id, String desc)
	{
		ImunossupressorMestre im = new ImunossupressorMestre();
		im.setId_imuno(id);
		im.setNome(desc);
		atualiza(im);
			
		return true;
	}
	
	public boolean remover(Long id)
	{
		ImunossupressorMestre im = new ImunossupressorMestre();
		im = buscaPorId(id);
		
		remove(im);
		return true;
	}
}
