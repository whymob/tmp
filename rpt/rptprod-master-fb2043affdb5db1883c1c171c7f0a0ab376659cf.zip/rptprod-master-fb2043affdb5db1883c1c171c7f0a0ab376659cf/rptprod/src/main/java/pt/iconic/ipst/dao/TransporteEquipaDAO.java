package pt.iconic.ipst.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import pt.iconic.ipst.modelo.TransporteEquipa;

@Repository
@Transactional
public class TransporteEquipaDAO {

	
	@PersistenceContext
	private EntityManager manager;
	
	
	public void adiciona(TransporteEquipa te){
		manager.persist(te);	
	}
	
	public void atualiza(TransporteEquipa te){
		manager.merge(te);
	}
	

/*	@SuppressWarnings("unchecked")
	public List<TransporteEquipa> ListaTransporteEquipa(){
		return manager.createQuery("select a from TransporteEquipa a").getResultList();
	}*/
	
	public TransporteEquipa buscaPorId(Long id){
		return manager.find(TransporteEquipa.class, id);
	}
	
	
	public void remove(TransporteEquipa te){
		TransporteEquipa teARemover = buscaPorId(te.getIdtransporte());
		manager.remove(teARemover);
	}

	@SuppressWarnings("unchecked")
	public List<TransporteEquipa> buscatranspequipadador(Long id_Dador) {
		Query query = manager.createQuery("select te from TransporteEquipa te JOIN te.dador d where d.id_Dador =:iddador");
		query.setParameter("iddador", id_Dador);

		List<TransporteEquipa> results = query.getResultList();
		
		return results;
	}
}
