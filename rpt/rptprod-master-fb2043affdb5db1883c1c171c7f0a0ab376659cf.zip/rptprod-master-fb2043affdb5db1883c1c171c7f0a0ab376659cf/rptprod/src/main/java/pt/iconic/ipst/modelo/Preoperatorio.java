package pt.iconic.ipst.modelo;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name = "PRE_OPERATORIO")
public class Preoperatorio {

	private Long id_preoperat;
	private int plasmaferese;
	private int rituximab;
	private int imunoglobina;
	private String notas;
//	private AnaliseRecetor analiseRecetor;
	private AssignacaoOrgaos assigorgao;
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="ID_PRE_OPERATORIO")
	public Long getId_preoperat() {
		return id_preoperat;
	}
	public void setId_preoperat(Long id_preoperat) {
		this.id_preoperat = id_preoperat;
	}
	
	@Column(name="PLASMAFERESE")
	public int getPlasmaferese() {
		return plasmaferese;
	}
	public void setPlasmaferese(int plasmaferese) {
		this.plasmaferese = plasmaferese;
	}
	
	@Column(name="RITUXIMAB")
	public int getRituximab() {
		return rituximab;
	}
	public void setRituximab(int rituximab) {
		this.rituximab = rituximab;
	}
	
	@Column(name="IMUNOGLOBINA")
	public int getImunoglobina() {
		return imunoglobina;
	}
	public void setImunoglobina(int imunoglobina) {
		this.imunoglobina = imunoglobina;
	}
	
	@Column(name="NOTAS")
	public String getNotas() {
		return notas;
	}
	public void setNotas(String notas) {
		this.notas = notas;
	}
	
	@OneToOne(fetch=FetchType.EAGER)
	@JoinColumn(name="ID_ASSIGNACAO_ORGAOS")
	public AssignacaoOrgaos getAssigorgao() {
		return assigorgao;
	}
	public void setAssigorgao(AssignacaoOrgaos assigorgao) {
		this.assigorgao = assigorgao;
	}
	
//	@OneToOne(fetch=FetchType.EAGER)
//	@JoinColumn(name="ID_ANALISERECETOR")
//	public AnaliseRecetor getAnaliseRecetor() {
//		return analiseRecetor;
//	}
//	public void setAnaliseRecetor(AnaliseRecetor analiseRecetor) {
//		this.analiseRecetor = analiseRecetor;
//	}
}
