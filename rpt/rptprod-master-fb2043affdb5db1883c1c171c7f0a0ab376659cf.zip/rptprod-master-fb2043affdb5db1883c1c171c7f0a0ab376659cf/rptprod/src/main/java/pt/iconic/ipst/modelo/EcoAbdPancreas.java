package pt.iconic.ipst.modelo;

import java.util.Calendar;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name = "ECOABDPANCREAS")
public class EcoAbdPancreas 
{
	private Long Id_Ecoabdpancreas;
	private Calendar DataEco;
	private boolean Calcificacao;
	private boolean Pancreatite;
	private boolean Lesoes;
	private int Parenchyma;
	private String Notas;
	private AnaliseDador analiseDador;
	private boolean statusharmecopancreas;
	private Calendar datagravacao;
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="ID_ECOABDPANCREAS")
	public Long getId_Ecoabdpancreas() {
		return Id_Ecoabdpancreas;
	}
	public void setId_Ecoabdpancreas(Long id_Ecoabdpancreas) {
		Id_Ecoabdpancreas = id_Ecoabdpancreas;
	}
	
	@Column(name="DATAECOPANCREAS")
	public Calendar getDataEco() {
		return DataEco;
	}
	public void setDataEco(Calendar dataEco) {
		DataEco = dataEco;
	}
	
	@Column(name="CALCIFICACAO")
	public boolean isCalcificacao() {
		return Calcificacao;
	}
	public void setCalcificacao(boolean calcificacao) {
		Calcificacao = calcificacao;
	}
	
	@Column(name="PANCREATITE")
	public boolean isPancreatite() {
		return Pancreatite;
	}
	public void setPancreatite(boolean pancreatite) {
		Pancreatite = pancreatite;
	}
	
	@Column(name="LESOES")
	public boolean isLesoes() {
		return Lesoes;
	}
	public void setLesoes(boolean lesoes) {
		Lesoes = lesoes;
	}
	
	@Column(name="PARENCHYMA")
	public int getParenchyma() {
		return Parenchyma;
	}
	public void setParenchyma(int parenchyma) {
		Parenchyma = parenchyma;
	}
	
	@Column(name="NOTAS")
	public String getNotas() {
		return Notas;
	}
	public void setNotas(String notas) {
		Notas = notas;
	}
	
	@OneToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="ID_ANALISEDADOR")
	public AnaliseDador getAnaliseDador() {
		return analiseDador;
	}
	public void setAnaliseDador(AnaliseDador analiseDador) {
		this.analiseDador = analiseDador;
	}
	
	@Column(name="STATUSHARMONIO")
	public boolean isStatusharmecopancreas() {
		return statusharmecopancreas;
	}
	public void setStatusharmecopancreas(boolean statusharmecopancreas) {
		this.statusharmecopancreas = statusharmecopancreas;
	}
	
	@Column(name="DATAGRAVACAO")
	public Calendar getDatagravacao() {
		return datagravacao;
	}

	public void setDatagravacao(Calendar datagravacao) {
		this.datagravacao = datagravacao;
	}
}