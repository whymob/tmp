package pt.iconic.ipst.modelo;

import java.util.Calendar;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import org.springframework.format.annotation.DateTimeFormat;

@Entity
@Table(name = "TRANSPLANTE_PULMOES")
public class TransplantePulmoes {

	private Long idtransplantepulmoes;
	private Calendar inicio;
	private Calendar fim;
	private String isqdrt;
	private String isqesq;
	private int recetor;
	private int ventinv;
	private int ventinvdias;
	private int ecmo;
	private int ecmodias;
	private String notas;
	private int incisao;
	private boolean inotropico;
	private boolean ecmovenoart;
	private boolean ecmovenoven;
	private boolean cec;
	private boolean semsup;
	private int complicacoes;
	private int saidarecetor;
	private int saidasuporte;
	private int saidano;
	private int saidaecmovenoart;
	private int saidaecmovenoven;
	private String saidaobs;
	private int complicacoesuci;
	private Calendar entrada;
	private Calendar saida;
	private int uciventdias;
	private int uciecmodias;
	private int estado;
	private AssignacaoOrgaos assigorgao;
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="ID_TRANSP_PULMOES")
	public Long getIdtransplantepulmoes() {
		return idtransplantepulmoes;
	}
	public void setIdtransplantepulmoes(Long idtransplantepulmoes) {
		this.idtransplantepulmoes = idtransplantepulmoes;
	}
	
	@Column(name="INICIO")
	public Calendar getInicio() {
		return inicio;
	}
	public void setInicio(Calendar inicio) {
		this.inicio = inicio;
	}
	
	@Column(name="FIM")
	public Calendar getFim() {
		return fim;
	}
	public void setFim(Calendar fim) {
		this.fim = fim;
	}
	
	@Column(name="ISQ_DRT")
	public String getIsqdrt() {
		return isqdrt;
	}
	public void setIsqdrt(String isqdrt) {
		this.isqdrt = isqdrt;
	}
	
	@Column(name="ISQ_ESQ")
	public String getIsqesq() {
		return isqesq;
	}
	public void setIsqesq(String isqesq) {
		this.isqesq = isqesq;
	}
	
	@Column(name="RECETOR")
	public int getRecetor() {
		return recetor;
	}
	public void setRecetor(int recetor) {
		this.recetor = recetor;
	}
	
	@Column(name="VENT_INVASIVA")
	public int getVentinv() {
		return ventinv;
	}
	public void setVentinv(int ventinv) {
		this.ventinv = ventinv;
	}
	
	@Column(name="VENT_INV_DIAS")
	public int getVentinvdias() {
		return ventinvdias;
	}
	public void setVentinvdias(int ventinvdias) {
		this.ventinvdias = ventinvdias;
	}
	
	@Column(name="ECMO")
	public int getEcmo() {
		return ecmo;
	}
	public void setEcmo(int ecmo) {
		this.ecmo = ecmo;
	}
	
	@Column(name="ECMO_DIAS")
	public int getEcmodias() {
		return ecmodias;
	}
	public void setEcmodias(int ecmodias) {
		this.ecmodias = ecmodias;
	}
	
	@Column(name="NOTAS")
	public String getNotas() {
		return notas;
	}
	public void setNotas(String notas) {
		this.notas = notas;
	}
	
	@Column(name="INCISAO")
	public int getIncisao() {
		return incisao;
	}
	public void setIncisao(int incisao) {
		this.incisao = incisao;
	}
	
	@Column(name="INOTROPICO")
	public boolean isInotropico() {
		return inotropico;
	}
	public void setInotropico(boolean inotropico) {
		this.inotropico = inotropico;
	}
	
	@Column(name="ECMO_VENO_ART")
	public boolean isEcmovenoart() {
		return ecmovenoart;
	}
	public void setEcmovenoart(boolean ecmovenoart) {
		this.ecmovenoart = ecmovenoart;
	}
	
	@Column(name="ECMO_VENO_VEN")
	public boolean isEcmovenoven() {
		return ecmovenoven;
	}
	public void setEcmovenoven(boolean ecmovenoven) {
		this.ecmovenoven = ecmovenoven;
	}
	
	@Column(name="CEC")
	public boolean isCec() {
		return cec;
	}
	public void setCec(boolean cec) {
		this.cec = cec;
	}
	
	@Column(name="SEM_SUPORTE")
	public boolean isSemsup() {
		return semsup;
	}
	public void setSemsup(boolean semsup) {
		this.semsup = semsup;
	}
	
	@Column(name="COMPLICACOES")
	public int getComplicacoes() {
		return complicacoes;
	}
	public void setComplicacoes(int complicacoes) {
		this.complicacoes = complicacoes;
	}
	
	@Column(name="SAIDA_RECETOR")
	public int getSaidarecetor() {
		return saidarecetor;
	}
	public void setSaidarecetor(int saidarecetor) {
		this.saidarecetor = saidarecetor;
	}
	
	@Column(name="SAIDA_SUPORTE")
	public int getSaidasuporte() {
		return saidasuporte;
	}
	public void setSaidasuporte(int saidasuporte) {
		this.saidasuporte = saidasuporte;
	}
	
	@Column(name="SAIDA_NO")
	public int getSaidano() {
		return saidano;
	}
	public void setSaidano(int saidano) {
		this.saidano = saidano;
	}
	
	@Column(name="SAIDA_ECMO_VENOART")
	public int getSaidaecmovenoart() {
		return saidaecmovenoart;
	}
	public void setSaidaecmovenoart(int saidaecmovenoart) {
		this.saidaecmovenoart = saidaecmovenoart;
	}
	
	@Column(name="SAIDA_ECMO_VENOVEN")
	public int getSaidaecmovenoven() {
		return saidaecmovenoven;
	}
	public void setSaidaecmovenoven(int saidaecmovenoven) {
		this.saidaecmovenoven = saidaecmovenoven;
	}
	
	@Column(name="SAIDA_OBSERVACOES")
	public String getSaidaobs() {
		return saidaobs;
	}
	public void setSaidaobs(String saidaobs) {
		this.saidaobs = saidaobs;
	}
	
	@Column(name="COMPLICACOES_UCI")
	public int getComplicacoesuci() {
		return complicacoesuci;
	}
	public void setComplicacoesuci(int complicacoesuci) {
		this.complicacoesuci = complicacoesuci;
	}
	
	@DateTimeFormat(pattern = "dd/MM/yyyy")
	@Column(name="ENTRADA")
	public Calendar getEntrada() {
		return entrada;
	}
	public void setEntrada(Calendar entrada) {
		this.entrada = entrada;
	}
	
	@DateTimeFormat(pattern = "dd/MM/yyyy")
	@Column(name="SAIDA")
	public Calendar getSaida() {
		return saida;
	}
	public void setSaida(Calendar saida) {
		this.saida = saida;
	}
	
	@Column(name="UCI_VENT_DIAS")
	public int getUciventdias() {
		return uciventdias;
	}
	public void setUciventdias(int uciventdias) {
		this.uciventdias = uciventdias;
	}
	
	@Column(name="UCI_ECMO_DIAS")
	public int getUciecmodias() {
		return uciecmodias;
	}
	public void setUciecmodias(int uciecmodias) {
		this.uciecmodias = uciecmodias;
	}
	
	@Column(name="ESTADO")
	public int getEstado() {
		return estado;
	}
	public void setEstado(int estado) {
		this.estado = estado;
	}
	@OneToOne(fetch=FetchType.EAGER)
	@JoinColumn(name="ID_ASSIGNACAO_ORGAOS")
	public AssignacaoOrgaos getAssigorgao() {
		return assigorgao;
	}
	public void setAssigorgao(AssignacaoOrgaos assigorgao) {
		this.assigorgao = assigorgao;
	}
	
}
