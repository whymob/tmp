package pt.iconic.ipst.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import pt.iconic.ipst.modelo.PPRenal;

@Repository
public class PPRenalDAO 
{
	@PersistenceContext
	private EntityManager manager;
	
	public void adiciona(PPRenal ren){
		manager.persist(ren);	
	}
	
	@Transactional
	public void atualiza(PPRenal ren){
		manager.merge(ren);
	}
	
/*	@SuppressWarnings("unchecked")
	public List<PPRenal> ListaPPRenal(){
		return manager.createQuery("select p from PPRenal p").getResultList();
	}*/
	
	public PPRenal buscaPorId(Long id){
		return manager.find(PPRenal.class, id);
	}
	
/*	public void remove(PPRenal ren){
		PPRenal renrem = buscaPorId(ren.getId_pprenal());
		manager.remove(renrem);
	}*/
	
	@SuppressWarnings("rawtypes")
	public PPRenal ListaPPRenalAnalise(Long id)
	{
		Query query = manager.createQuery("select e from PPRenal e JOIN e.analiserecetor analiserecetor WHERE analiserecetor.id_analiserecetor =:idanalise");
		query.setParameter("idanalise", id);

		List results = query.getResultList();
		PPRenal rad = null;
		
		if(!results.isEmpty())
		{
			rad = (PPRenal) results.get(0);
		}
		
		return rad;
	}
}