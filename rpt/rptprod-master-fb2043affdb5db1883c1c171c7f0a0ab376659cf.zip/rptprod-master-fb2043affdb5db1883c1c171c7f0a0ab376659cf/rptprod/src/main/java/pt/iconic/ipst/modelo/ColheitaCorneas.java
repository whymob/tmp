package pt.iconic.ipst.modelo;

import java.util.Calendar;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name = "COLHEITA_CORNEAS")
public class ColheitaCorneas {

	private Long idcolheitacorneas;
	private Calendar iniciocorneas;
	private Calendar fimcorneas;
	private int corneadirretirada;
	private int corneaesqretirada;
	private int corneaoutrosretirada;
	private String corneadircodigo;
	private String corneaesqcodigo;
	private String corneaoutroscodigo;
	private String notascorneas;
	private AnaliseDador analiseDador;
	private String codcorneas;
	private int estadocorneas;
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="ID_COLHEITA_CORNEAS")
	public Long getIdcolheitacorneas() {
		return idcolheitacorneas;
	}
	public void setIdcolheitacorneas(Long idcolheitacorneas) {
		this.idcolheitacorneas = idcolheitacorneas;
	}
	
	@Column(name="INICIO")
	public Calendar getIniciocorneas() {
		return iniciocorneas;
	}
	public void setIniciocorneas(Calendar iniciocorneas) {
		this.iniciocorneas = iniciocorneas;
	}
	
	@Column(name="FIM")
	public Calendar getFimcorneas() {
		return fimcorneas;
	}
	public void setFimcorneas(Calendar fimcorneas) {
		this.fimcorneas = fimcorneas;
	}
	
	@Column(name="CORNEA_DIR_RETIRADA")
	public int getCorneadirretirada() {
		return corneadirretirada;
	}
	public void setCorneadirretirada(int corneadirretirada) {
		this.corneadirretirada = corneadirretirada;
	}
	
	@Column(name="CORNEA_ESQ_RETIRADA")
	public int getCorneaesqretirada() {
		return corneaesqretirada;
	}
	public void setCorneaesqretirada(int corneaesqretirada) {
		this.corneaesqretirada = corneaesqretirada;
	}
	
	@Column(name="CORNEA_OUTROS_RETIRADA")
	public int getCorneaoutrosretirada() {
		return corneaoutrosretirada;
	}
	public void setCorneaoutrosretirada(int corneaoutrosretirada) {
		this.corneaoutrosretirada = corneaoutrosretirada;
	}
	
	@Column(name="CORNEA_DIR_CODIGO")
	public String getCorneadircodigo() {
		return corneadircodigo;
	}
	public void setCorneadircodigo(String corneadircodigo) {
		this.corneadircodigo = corneadircodigo;
	}
	
	@Column(name="CORNEA_ESQ_CODIGO")
	public String getCorneaesqcodigo() {
		return corneaesqcodigo;
	}
	public void setCorneaesqcodigo(String corneaesqcodigo) {
		this.corneaesqcodigo = corneaesqcodigo;
	}
	
	@Column(name="CORNEA_OUTROS_CODIGO")
	public String getCorneaoutroscodigo() {
		return corneaoutroscodigo;
	}
	public void setCorneaoutroscodigo(String corneaoutroscodigo) {
		this.corneaoutroscodigo = corneaoutroscodigo;
	}
	@Column(name="NOTAS")
	public String getNotascorneas() {
		return notascorneas;
	}
	public void setNotascorneas(String notascorneas) {
		this.notascorneas = notascorneas;
	}
	
	@OneToOne(fetch=FetchType.EAGER)
	@JoinColumn(name="ID_ANALISEDADOR")
	public AnaliseDador getAnaliseDador() {
		return analiseDador;
	}
	public void setAnaliseDador(AnaliseDador analiseDador) {
		this.analiseDador = analiseDador;
	}
	
	@Column(name="COD_CORNEAS")
	public String getCodcorneas() {
		return codcorneas;
	}
	public void setCodcorneas(String codcorneas) {
		this.codcorneas = codcorneas;
	}
	
	@Column(name="ESTADO_CORNEAS")
	public int getEstadocorneas() {
		return estadocorneas;
	}
	public void setEstadocorneas(int estadocorneas) {
		this.estadocorneas = estadocorneas;
	}
	
}
