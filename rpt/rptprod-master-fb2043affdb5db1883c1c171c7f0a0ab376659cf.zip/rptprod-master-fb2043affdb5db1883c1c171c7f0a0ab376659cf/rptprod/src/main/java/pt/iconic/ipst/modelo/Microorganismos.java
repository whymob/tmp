package pt.iconic.ipst.modelo;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
//import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
//import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;

@Entity
@Table(name = "MICROORGANISMOS")
public class Microorganismos 
{
	private Long Id_Microorganismos;
	private String MicroDescricao;
	private TipoMicroorganismo tipomicroorganismo;
	
//	private Microrgmbanalisemb 	microrgmbanalisemb;
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="ID_MICROORGANISMOS")
	public Long getId_Microorganismos() {
		return Id_Microorganismos;
	}
	
	public void setId_Microorganismos(Long id_Microorganismos) {
		Id_Microorganismos = id_Microorganismos;
	}
	
	@NotNull
	@Column(name="MICRODESCRICAO")
	public String getMicroDescricao() {
		return MicroDescricao;
	}
	
	public void setMicroDescricao(String microDescricao) {
		MicroDescricao = microDescricao;
	}

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "ID_TIPOMICROORGANISMO")
	public TipoMicroorganismo getTipomicroorganismo() {
		return tipomicroorganismo;
	}

	public void setTipomicroorganismo(TipoMicroorganismo tipomicroorganismo) {
		this.tipomicroorganismo = tipomicroorganismo;
	}

//	@OneToOne(fetch = FetchType.LAZY, mappedBy = "microrganismo")
//	public Microrgmbanalisemb getMicrorgmbanalisemb() {
//		return microrgmbanalisemb;
//	}
//
//	public void setMicrorgmbanalisemb(Microrgmbanalisemb microrgmbanalisemb) {
//		this.microrgmbanalisemb = microrgmbanalisemb;
//	}
}