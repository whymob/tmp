package pt.iconic.ipst.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import pt.iconic.ipst.modelo.TipoVirologia;


@Repository
@Transactional
public class TipoVirologiaDAO {

	
	@PersistenceContext
	private EntityManager manager;
	
	
	public void adiciona(TipoVirologia tipovirologia){
		manager.persist(tipovirologia);	
	}
	

	public void atualiza(TipoVirologia tipovirologia){
		manager.merge(tipovirologia);
	}
	
	@SuppressWarnings("unchecked")
	public List<TipoVirologia> ListaTipoVirologia(){
		return manager.createQuery("select a from TipoVirologia a").getResultList();
	}
	
	public TipoVirologia buscaPorId(Long id){
		return manager.find(TipoVirologia.class, id);
	}
	
	
	public void remove(TipoVirologia tipovirologia){
		TipoVirologia tipovirologiaARemover = buscaPorId(tipovirologia.getId_tipovirologia());
		manager.remove(tipovirologiaARemover);
		
	}
	
	public boolean trataadicionar(String desc)
	{
		Query query = manager.createQuery("SELECT e FROM TipoVirologia e WHERE e.desctipovirologia =:desc");
		query.setParameter("desc", desc);
		
		if(query.getResultList().isEmpty())
		{
			TipoVirologia tv = new TipoVirologia();
			tv.setDesctipovirologia(desc);
			adiciona(tv);
			
			return true;
		}
		else
		{
			return false;
		}
	}
	
	public boolean trataalterar(Long id, String desc)
	{
		Query query = manager.createQuery("SELECT e FROM TipoVirologia e WHERE e.desctipovirologia =:desc");
		query.setParameter("desc", desc);
		
		if(query.getResultList().isEmpty())
		{
			TipoVirologia tv = new TipoVirologia();
			tv.setDesctipovirologia(desc);
			tv.setId_tipovirologia(id);
			atualiza(tv);
				
			return true;
		}
		else
		{
			return false;
		}
	}
	
	public boolean remover(Long id) 
	{
		TipoVirologia tv = new TipoVirologia();
		tv = buscaPorId(id);

		remove(tv);
		return true;
	}
}
