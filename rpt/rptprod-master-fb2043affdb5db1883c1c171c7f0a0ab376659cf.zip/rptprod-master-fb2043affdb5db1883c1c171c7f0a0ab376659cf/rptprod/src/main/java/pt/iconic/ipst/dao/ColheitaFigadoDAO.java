package pt.iconic.ipst.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import pt.iconic.ipst.modelo.ColheitaFigado;


@Repository
@Transactional
public class ColheitaFigadoDAO {

	@PersistenceContext
	private EntityManager manager;
	
	
	public void adiciona(ColheitaFigado colheita){
		manager.persist(colheita);	
	}
	

	public void atualiza(ColheitaFigado colheita){
		manager.merge(colheita);
	}
	

/*	@SuppressWarnings("unchecked")
	public List<ColheitaFigado> ListaColheitaFigado(){
		return manager.createQuery("select a from ColheitaFigado a").getResultList();
	}
	
	public ColheitaFigado buscaPorId(Long id){
		return manager.find(ColheitaFigado.class, id);
	}
	
	
	public void remove(ColheitaFigado colheita){
		ColheitaFigado colheitaARemover = buscaPorId(colheita.getIdcolheitafigado());
		manager.remove(colheitaARemover);
		
	}*/
	
	@SuppressWarnings("unchecked")
	public ColheitaFigado buscacolheitaFigadoanalise(Long idanalise){
		
		Query query = manager.createQuery("select b from ColheitaFigado b JOIN b.analiseDador a WHERE a.id_AnaliseDador =:idanalise");
		query.setParameter("idanalise", idanalise);
		
		List<ColheitaFigado> results = query.getResultList();
		ColheitaFigado colheita = null;
		if(!results.isEmpty()){
			colheita = (ColheitaFigado) results.get(0);
		}
		return colheita;
		
	}
}
