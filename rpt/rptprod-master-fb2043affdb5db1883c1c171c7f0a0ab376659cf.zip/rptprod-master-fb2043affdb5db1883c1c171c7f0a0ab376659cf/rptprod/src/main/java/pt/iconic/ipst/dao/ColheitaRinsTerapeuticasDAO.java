package pt.iconic.ipst.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import pt.iconic.ipst.modelo.ColheitaRinsTerapeuticas;

@Repository
@Transactional
public class ColheitaRinsTerapeuticasDAO {

	@PersistenceContext
	private EntityManager manager;
	
	
	public void adiciona(ColheitaRinsTerapeuticas colheita){
		manager.persist(colheita);	
	}
	

	public void atualiza(ColheitaRinsTerapeuticas colheita){
		manager.merge(colheita);
	}
	

/*	@SuppressWarnings("unchecked")
	public List<ColheitaRinsTerapeuticas> ListaColheitaRinsTerapeuticas(){
		return manager.createQuery("select a from ColheitaRinsTerapeuticas a").getResultList();
	}*/
	
	public ColheitaRinsTerapeuticas buscaPorId(Long id){
		return manager.find(ColheitaRinsTerapeuticas.class, id);
	}
	
	
	public void remove(ColheitaRinsTerapeuticas colheita){
		ColheitaRinsTerapeuticas colheitaARemover = buscaPorId(colheita.getIdcolheitaterapeuticarins());
		manager.remove(colheitaARemover);
		
	}
	
	@SuppressWarnings("unchecked")
	public List<ColheitaRinsTerapeuticas> listacolheitarinsterapeuticasanalise(Long idanalise){
		
		Query query = manager.createQuery("select b from ColheitaRinsTerapeuticas b JOIN b.analiseDador a WHERE a.id_AnaliseDador =:idanalise");
		query.setParameter("idanalise", idanalise);
		
		List<ColheitaRinsTerapeuticas> results = query.getResultList();
		return results;
		
	}
}
