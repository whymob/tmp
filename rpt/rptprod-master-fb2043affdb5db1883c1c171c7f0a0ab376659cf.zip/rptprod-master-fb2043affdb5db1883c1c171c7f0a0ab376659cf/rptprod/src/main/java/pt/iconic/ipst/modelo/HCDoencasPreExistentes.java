package pt.iconic.ipst.modelo;

import java.util.Calendar;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;


@Entity
@Table(name = "HCDOENCASPREEXISTENTES")
public class HCDoencasPreExistentes {


	private Long Id_HCDoencasPreExistentes;
	private AnaliseDador analiseDador;
	private boolean neoplasia;
	private boolean neurodegenerativa;
	private boolean hematologicas;
	private boolean infecciosas;
	private boolean infecoessistema;
	private boolean hiv;
	private boolean hepatitesviricas;
	private boolean sifilisgonorreia;
	private boolean cerebrovascular;
	private boolean dermatologica;
	private boolean eam;
	private boolean etiologiadesconhecida;
	private boolean outrosdoencas;
	private String observacoesdoencas;
	private boolean statusharmdpreexist;
	private Calendar datagravacao;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="ID_HCDOENCASPREEXISTENTES")
	public Long getId_HCDoencasPreExistentes() {
		return Id_HCDoencasPreExistentes;
	}
	public void setId_HCDoencasPreExistentes(Long id_HCDoencasPreExistentes) {
		Id_HCDoencasPreExistentes = id_HCDoencasPreExistentes;
	}
	
	@OneToOne
	@JoinColumn(name="ID_ANALISEDADOR")
	public AnaliseDador getAnaliseDador() {
		return analiseDador;
	}
	public void setAnaliseDador(AnaliseDador analiseDador) {
		this.analiseDador = analiseDador;
	}
	
	@Column(name="NEOPLASIA")
	public boolean isNeoplasia() {
		return neoplasia;
	}
	public void setNeoplasia(boolean neoplasia) {
		this.neoplasia = neoplasia;
	}


	
	@Column(name="NEURODEGENERATIVA")
	public boolean isNeurodegenerativa() {
		return neurodegenerativa;
	}
	public void setNeurodegenerativa(boolean neurodegenerativa) {
		this.neurodegenerativa = neurodegenerativa;
	}
	
	@Column(name="HEMATOLOGICAS")
	public boolean isHematologicas() {
		return hematologicas;
	}
	public void setHematologicas(boolean hematologicas) {
		this.hematologicas = hematologicas;
	}
	
	@Column(name="INFECCIOSAS")
	public boolean isInfecciosas() {
		return infecciosas;
	}
	public void setInfecciosas(boolean infecciosas) {
		this.infecciosas = infecciosas;
	}
	
	@Column(name="INFECOESSISTEMA")
	public boolean isInfecoessistema() {
		return infecoessistema;
	}
	public void setInfecoessistema(boolean infecoessistema) {
		this.infecoessistema = infecoessistema;
	}
	
	@Column(name="HIV")
	public boolean isHiv() {
		return hiv;
	}
	public void setHiv(boolean hiv) {
		this.hiv = hiv;
	}
	
	@Column(name="HEPATITESVIRICAS")
	public boolean isHepatitesviricas() {
		return hepatitesviricas;
	}
	public void setHepatitesviricas(boolean hepatitesviricas) {
		this.hepatitesviricas = hepatitesviricas;
	}
	
	@Column(name="SIFILISGONORREIA")
	public boolean isSifilisgonorreia() {
		return sifilisgonorreia;
	}
	public void setSifilisgonorreia(boolean sifilisgonorreia) {
		this.sifilisgonorreia = sifilisgonorreia;
	}
	
	@Column(name="CEREBROVASCULAR")
	public boolean isCerebrovascular() {
		return cerebrovascular;
	}
	public void setCerebrovascular(boolean cerebrovascular) {
		this.cerebrovascular = cerebrovascular;
	}
	
	@Column(name="DERMATOLOGICA")
	public boolean isDermatologica() {
		return dermatologica;
	}
	public void setDermatologica(boolean dermatologica) {
		this.dermatologica = dermatologica;
	}
	
	@Column(name="EAM")
	public boolean isEam() {
		return eam;
	}
	public void setEam(boolean eam) {
		this.eam = eam;
	}
	
	@Column(name="ETIOLOGIADESCONHECIDA")
	public boolean isEtiologiadesconhecida() {
		return etiologiadesconhecida;
	}
	public void setEtiologiadesconhecida(boolean etiologiadesconhecida) {
		this.etiologiadesconhecida = etiologiadesconhecida;
	}
	
	@Column(name="OUTROS")
	public boolean isOutrosdoencas() {
		return outrosdoencas;
	}
	public void setOutrosdoencas(boolean outrosdoencas) {
		this.outrosdoencas = outrosdoencas;
	}
	
	@Column(name="OBSERVACOESDOENCAS")
	public String getObservacoesdoencas() {
		return observacoesdoencas;
	}
	public void setObservacoesdoencas(String observacoesdoencas) {
		this.observacoesdoencas = observacoesdoencas;
	}
	
	@Column(name="STATUSHARMONIO")
	public boolean isStatusharmdpreexist() {
		return statusharmdpreexist;
	}
	public void setStatusharmdpreexist(boolean statusharmdpreexist) {
		this.statusharmdpreexist = statusharmdpreexist;
	}

	@Column(name="DATAGRAVACAO")
	public Calendar getDatagravacao() {
		return datagravacao;
	}


	public void setDatagravacao(Calendar datagravacao) {
		this.datagravacao = datagravacao;
	}
	
}
