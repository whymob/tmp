package pt.iconic.ipst.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import pt.iconic.ipst.modelo.EstadoRecetor;

@Repository
public class EstadoRecetorDAO 
{
	@PersistenceContext
	private EntityManager manager;
	
	@Transactional
	public void adiciona(EstadoRecetor estad){
		manager.persist(estad);	
	}
	
	@Transactional
	public void atualiza(EstadoRecetor estad){
		manager.merge(estad);
	}

/*	@SuppressWarnings("unchecked")
	public List<EstadoRecetor> ListaEstadoRecetor(){
		return manager.createQuery("select d from EstadoRecetor d").getResultList();
	}*/
	
	public EstadoRecetor buscaPorId(Long id){
		return manager.find(EstadoRecetor.class, id);
	}
	
	public void remove(EstadoRecetor estad){
		EstadoRecetor estadrem = buscaPorId(estad.getId_estadorecetor());
		manager.remove(estadrem);
	}
	
	@SuppressWarnings("unchecked")
	public List<EstadoRecetor> buscaestadorecetor(Long analiserecetor)
	{		
		Query query = manager.createQuery("select a from EstadoRecetor a JOIN a.analiserecetor grav WHERE grav.id_analiserecetor =:analiserecetor order by a.id_estadorecetor desc");
		query.setParameter("analiserecetor", analiserecetor);
		
		List<EstadoRecetor> results = query.getResultList();

		return results;
	}

}
