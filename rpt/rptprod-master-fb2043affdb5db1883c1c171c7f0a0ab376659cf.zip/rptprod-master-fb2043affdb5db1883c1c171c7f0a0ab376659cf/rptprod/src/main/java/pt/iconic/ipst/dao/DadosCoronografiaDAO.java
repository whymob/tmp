package pt.iconic.ipst.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import pt.iconic.ipst.modelo.AnaliseDador;
import pt.iconic.ipst.modelo.DadosCoronografia;

@Repository
@Transactional
public class DadosCoronografiaDAO 
{
	@PersistenceContext
	private EntityManager manager;
	
	public void adiciona(DadosCoronografia dadoseco){
		manager.persist(dadoseco);	
	}
	
	@Transactional
	public void atualiza(DadosCoronografia dadoseco){
		manager.merge(dadoseco);
	}

/*	@SuppressWarnings("unchecked")
	public List<DadosCoronografia> DadosCoronografia(){
		return manager.createQuery("select d from DadosCoronografia d").getResultList();
	}*/
	
	public DadosCoronografia buscaPorId(Long id){
		return manager.find(DadosCoronografia.class, id);
	}
	
	public void remove(DadosCoronografia dadoseco){
		DadosCoronografia lesoes = buscaPorId(dadoseco.getId_DadosCoronografia());
		manager.remove(lesoes);
	}
	
	//adiciona a lesao � tabela
	public boolean adicionalesao(String arteria, String estenose, String severidade, Long id_analise)
	{
		AnaliseDador analise = manager.find(AnaliseDador.class, id_analise);
			
		DadosCoronografia lesoes = new DadosCoronografia();
		lesoes.setArteria(arteria);
		lesoes.setEstenose(estenose);
		lesoes.setSeveridade(severidade);
		lesoes.setAnaliseDador(analise);

		adiciona(lesoes);
						
		return true;
	}
	
	//carrega as lesoes quando insere a ultima lesao para que as da ultima apare�am em cima
	@SuppressWarnings("unchecked")
	public List<DadosCoronografia> buscalesoesDescendente(Long idanalise)
	{		
		Query query = manager.createQuery("select a from DadosCoronografia a JOIN a.analiseDador an WHERE an.id_AnaliseDador =:idanalise");
		query.setParameter("idanalise", idanalise);
		
		List<DadosCoronografia> results = query.getResultList();

		return results;
	}
}