package pt.iconic.ipst.modelo;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name = "POS_OPERATORIO_TAB_EXPL")
public class PosOperatorioTabExpl {

	private Long idtipoposop;
	private int tipo;
	private String notas;
	private AnaliseDador analiseDador;
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="ID_POS_OPERATORIO_TAB_EXPL")
	public Long getIdtipoposop() {
		return idtipoposop;
	}
	public void setIdtipoposop(Long idtipoposop) {
		this.idtipoposop = idtipoposop;
	}
	
	@Column(name="TIPO")
	public int getTipo() {
		return tipo;
	}
	public void setTipo(int tipo) {
		this.tipo = tipo;
	}
	
	@Column(name="NOTAS")
	public String getNotas() {
		return notas;
	}
	public void setNotas(String notas) {
		this.notas = notas;
	}
	
	@ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "ID_ANALISE_DADOR")
	public AnaliseDador getAnaliseDador() {
		return analiseDador;
	}
	public void setAnaliseDador(AnaliseDador analiseDador) {
		this.analiseDador = analiseDador;
	}
	
	
}
