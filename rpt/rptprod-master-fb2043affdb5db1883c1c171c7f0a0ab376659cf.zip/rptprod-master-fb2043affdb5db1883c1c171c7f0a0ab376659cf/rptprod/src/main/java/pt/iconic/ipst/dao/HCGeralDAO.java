package pt.iconic.ipst.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;

import pt.iconic.ipst.modelo.HCGeral;


@Repository
public class HCGeralDAO {

	@PersistenceContext
	private EntityManager manager;
	
	
	public void adiciona(HCGeral geral){
		manager.persist(geral);	
	}
	
	public void atualiza(HCGeral geral){
		manager.merge(geral);
	}
	

/*	@SuppressWarnings("unchecked")
	public List<HCGeral> ListaHCGeral(){
		return manager.createQuery("select c from HCGeral c").getResultList();
	}
	
	public HCGeral buscaPorId(Long id){
		return manager.find(HCGeral.class, id);
	}
	
	
	public void remove(HCGeral geral){
		HCGeral geralARemover = buscaPorId(geral.getId_HCGeral());
		manager.remove(geralARemover);
	}*/
	
	@SuppressWarnings("unchecked")
	public HCGeral buscageralanalise(Long idanalise){
		
		Query query = manager.createQuery("select h from HCGeral h JOIN h.analiseDador a WHERE a.id_AnaliseDador =:idanalise");
		query.setParameter("idanalise", idanalise);
		
		List<HCGeral> results = query.getResultList();
		HCGeral geral = null;
		if(!results.isEmpty()){
			geral = (HCGeral) results.get(0);
		}
		return geral;
		
	}
	
}
