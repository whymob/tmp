package pt.iconic.ipst.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import pt.iconic.ipst.modelo.FollowUp;

@Repository
public class FollowUpDAO 
{
	@PersistenceContext
	private EntityManager manager;
	
	@Transactional
	public void adiciona(FollowUp fol){
		manager.persist(fol);	
	}
	
	@Transactional
	public void atualiza(FollowUp fol){
		manager.merge(fol);
	}

/*	@SuppressWarnings("unchecked")
	public List<FollowUp> ListaFollowUp(){
		return manager.createQuery("select d from FollowUp d").getResultList();
	}*/
	
	public FollowUp buscaPorId(Long id){
		return manager.find(FollowUp.class, id);
	}
	
	public void remove(FollowUp fol){
		FollowUp folrem = buscaPorId(fol.getId_followup());
		manager.remove(folrem);
	}
	
	@SuppressWarnings("unchecked")
	public List<FollowUp> buscafollowup(Long id_transplante)
	{		
		Query query = manager.createQuery("select f from FollowUp f JOIN f.transplante t WHERE t.id_transplante =:id_transplante");
		query.setParameter("id_transplante", id_transplante);
		
		List<FollowUp> results = query.getResultList();

		return results;
	}
}
