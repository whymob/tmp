/**
 * 
 */
/**
 * @author Rocky
 *
 */
package pt.iconic.ipst.dao;