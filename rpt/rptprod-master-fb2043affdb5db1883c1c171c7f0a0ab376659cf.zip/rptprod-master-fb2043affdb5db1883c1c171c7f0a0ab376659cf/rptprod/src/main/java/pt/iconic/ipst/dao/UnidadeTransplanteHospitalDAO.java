package pt.iconic.ipst.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import pt.iconic.ipst.modelo.UnidadeTransplante;
import pt.iconic.ipst.modelo.Unidade_Hospital;;

@Repository
@Transactional
public class UnidadeTransplanteHospitalDAO {

	
	@PersistenceContext
	private EntityManager manager;
	
	public void adiciona(Unidade_Hospital unid){
		manager.persist(unid);	
	}
/*	
	public void atualiza(Unidade_Hospital unid){
		manager.merge(unid);

	}
	
	@SuppressWarnings("unchecked")
	public List<Unidade_Hospital> ListaUnidade_Hospital(){
		return manager.createQuery("select u from Unidade_Hospital u").getResultList();
	}
	
	public Unidade_Hospital buscaPorId(Long id){
		return manager.find(Unidade_Hospital.class, id);
	}
	
	public void remove(Unidade_Hospital unid){
		Unidade_Hospital unidARemover = buscaPorId(unid.getId_unidade_hospital());
		manager.remove(unidARemover);
	}*/

	
	@SuppressWarnings("unchecked")
	public List<UnidadeTransplante> buscaUnidadesTransplanteHospital(Long id_hospital) {
		
		List<UnidadeTransplante> out = null;

		String sql = "select UNIDADETRANSPLANTE.* from UNIDADETRANSPLANTE "
				+ "inner join UNIDADETRANSP_HOSPITAL on (UNIDADETRANSP_HOSPITAL.ID_UNIDADETRANSP = UNIDADETRANSPLANTE.ID_UNIDADETRANSP) "
				+ "where UNIDADETRANSP_HOSPITAL.ID_HOSPITAL = :id_hospital";
		
		Query query = manager.createNativeQuery(sql, UnidadeTransplante.class);
		query.setParameter("id_hospital", id_hospital);
		out = query.getResultList();

		return out;
	}
	
	
	@SuppressWarnings("unchecked")
	public List<UnidadeTransplante> buscaUnidadesTransp_HospitalNaoExistentes(Long id_hospital) {
		List<UnidadeTransplante> out = null;
		
		List<UnidadeTransplante> existentes = buscaUnidadesTransplanteHospital(id_hospital);
		
		if(existentes.isEmpty()){
		    // ignores multiple results
			String sql = "select * from UNIDADETRANSPLANTE";
			Query query = manager.createNativeQuery(sql, UnidadeTransplante.class);
			out = query.getResultList();
		}else{
		String sql = "select * from UNIDADETRANSPLANTE where UNIDADETRANSPLANTE.ID_UNIDADETRANSP NOT IN (:unidtransp)";
		Query query = manager.createNativeQuery(sql, UnidadeTransplante.class);
		query.setParameter("unidtransp", existentes);
		out = query.getResultList();
		
		}
		return out;
	}
	
	
	@SuppressWarnings("unchecked")
	public void removerunidadetransplantedohospital(Long id_unidadetransp, Long id_hospital){
		
		Query query = manager.createQuery("select uh from Unidade_Hospital uh JOIN uh.hosp h JOIN uh.unidtransp ut WHERE h.id_Hospital= :id_hospital AND ut.id_unidadetransplante = :id_unidadetransp", Unidade_Hospital.class);
		query.setParameter("id_hospital", id_hospital);
		query.setParameter("id_unidadetransp", id_unidadetransp);
		List <Unidade_Hospital> resultado = query.getResultList();
		
		Unidade_Hospital uh = null;
		if(!resultado.isEmpty()){
		    // ignores multiple results
			uh = (Unidade_Hospital) resultado.get(0);
		}
		manager.remove(uh);
	}
	
}
