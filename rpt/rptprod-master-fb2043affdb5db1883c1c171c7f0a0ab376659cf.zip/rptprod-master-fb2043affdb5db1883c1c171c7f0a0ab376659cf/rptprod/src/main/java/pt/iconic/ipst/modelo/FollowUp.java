package pt.iconic.ipst.modelo;

import java.util.Calendar;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name = "FOLLOWUP")
public class FollowUp //Marca��es Follow UP
{
	private Long id_followup;
	private Calendar datafollowup;
	private int complicacoes;
	private int tipo;
	private int tipomarcacao; //tipomarca��o - consulta, an�lises, exames
	private boolean jejum;
	private boolean urina;
	private int sitclinica;
	private boolean alertabio;
	private String observacoes;
	private Utilizador user;
	private Transplantes transplante;
	private List<MedicamentosFollowUp> medicamentosfollowup;
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "ID_FOLLOW")
	public Long getId_followup() {
		return id_followup;
	}
	public void setId_followup(Long id_followup) {
		this.id_followup = id_followup;
	}
	

	@Column(name = "DATA")
	public Calendar getDatafollowup() {
		return datafollowup;
	}
	public void setDatafollowup(Calendar datafollowup) {
		this.datafollowup = datafollowup;
	}
	
	@Column(name = "COMPLICACOES")
	public int getComplicacoes() {
		return complicacoes;
	}
	public void setComplicacoes(int complicacoes) {
		this.complicacoes = complicacoes;
	}
	
	@Column(name = "TIPO")
	public int getTipo() {
		return tipo;
	}
	public void setTipo(int tipo) {
		this.tipo = tipo;
	}
	
	@Column(name = "TIPOMARCACAO")
	public int getTipomarcacao() {
		return tipomarcacao;
	}
	public void setTipomarcacao(int tipomarcacao) {
		this.tipomarcacao = tipomarcacao;
	}
	
	@Column(name = "JEJUM")
	public boolean isJejum() {
		return jejum;
	}
	public void setJejum(boolean jejum) {
		this.jejum = jejum;
	}
	
	@Column(name = "URINA")
	public boolean isUrina() {
		return urina;
	}
	public void setUrina(boolean urina) {
		this.urina = urina;
	}
	@Column(name = "SITCLINICA")
	public int getSitclinica() {
		return sitclinica;
	}
	public void setSitclinica(int sitclinica) {
		this.sitclinica = sitclinica;
	}
	
	@Column(name = "ALERTABIO")
	public boolean isAlertabio() {
		return alertabio;
	}
	public void setAlertabio(boolean alertabio) {
		this.alertabio = alertabio;
	}
	
	@Column(name = "OBSERVACOES")
	public String getObservacoes() {
		return observacoes;
	}
	public void setObservacoes(String observacoes) {
		this.observacoes = observacoes;
	}
	
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name="ID_TRANSPLANTE")
	public Transplantes getTransplante() {
		return transplante;
	}
	public void setTransplante(Transplantes transplante) {
		this.transplante = transplante;
	}
	
	@OneToMany(fetch = FetchType.LAZY, mappedBy = "marcacao", orphanRemoval= true)
	public List<MedicamentosFollowUp> getMedicamentosfollowup() {
		return medicamentosfollowup;
	}
	public void setMedicamentosfollowup(List<MedicamentosFollowUp> medicamentosfollowup) {
		this.medicamentosfollowup = medicamentosfollowup;
	}
	
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name="ID_UTILIZADOR")
	public Utilizador getUser() {
		return user;
	}
	public void setUser(Utilizador user) {
		this.user = user;
	}	
	
	
}