package pt.iconic.ipst.modelo;

import java.util.Calendar;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name = "TRANSPORTE_EQUIPA")
public class TransporteEquipa {

	private Long idtransporte;
	private AssignacaoOrgaos assigorgao;
	private String transportador;
	private String contato;
	private Calendar horaprevista;
	private String destino;
	private Calendar horatransplante;
	private Dador dador;
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="ID_TRANSPORTE_EQUIPA")
	public Long getIdtransporte() {
		return idtransporte;
	}
	public void setIdtransporte(Long idtransporte) {
		this.idtransporte = idtransporte;
	}
	
    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "ID_ASSIG_ORGAO")
	public AssignacaoOrgaos getAssigorgao() {
		return assigorgao;
	}
	public void setAssigorgao(AssignacaoOrgaos assigorgao) {
		this.assigorgao = assigorgao;
	}
	
	@Column(name="TRANSPORTADOR")
	public String getTransportador() {
		return transportador;
	}
	public void setTransportador(String transportador) {
		this.transportador = transportador;
	}
	
	@Column(name="CONTATO")
	public String getContato() {
		return contato;
	}
	public void setContato(String contato) {
		this.contato = contato;
	}
	
	@Column(name="HORA_PREVISTA")
	public Calendar getHoraprevista() {
		return horaprevista;
	}
	public void setHoraprevista(Calendar horaprevista) {
		this.horaprevista = horaprevista;
	}
	
	@Column(name="DESTINO")
	public String getDestino() {
		return destino;
	}
	public void setDestino(String destino) {
		this.destino = destino;
	}
	
	@Column(name="HORA_TRANSPLANTE")
	public Calendar getHoratransplante() {
		return horatransplante;
	}
	public void setHoratransplante(Calendar horatransplante) {
		this.horatransplante = horatransplante;
	}
	
    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "ID_DADOR")
	public Dador getDador() {
		return dador;
	}
	public void setDador(Dador dador) {
		this.dador = dador;
	}
}
