package pt.iconic.ipst.modelo;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name = "PPHEPATICOCOMORBILIDADES")
public class PPHepaticoComorbilidades {

	private Long id_pphepaticocomorb;
	private AnaliseRecetor analiserecetor;
	private int indicacao;
	private String notas;
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="ID_PPHEPATICO_COMORB")
	public Long getId_pphepaticocomorb() {
		return id_pphepaticocomorb;
	}
	public void setId_pphepaticocomorb(Long id_pphepaticocomorb) {
		this.id_pphepaticocomorb = id_pphepaticocomorb;
	}
	
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="ID_ANALISERECETOR")
	public AnaliseRecetor getAnaliserecetor() {
		return analiserecetor;
	}
	public void setAnaliserecetor(AnaliseRecetor analiserecetor) {
		this.analiserecetor = analiserecetor;
	}
	
	@Column(name="INDICACAO")
	public int getIndicacao() {
		return indicacao;
	}
	public void setIndicacao(int indicacao) {
		this.indicacao = indicacao;
	}
	
	@Column(name="NOTAS")
	public String getNotas() {
		return notas;
	}
	public void setNotas(String notas) {
		this.notas = notas;
	}
	
	
	
}
