package pt.iconic.ipst.modelo;

import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name = "ORGAOS_OFERTA")
public class OrgaosOferta {

	private int idorgoferta;
	private String nomeorgaooferta;
	private List<AssignacaoOrgaos> assignacao;
	private List<Objetivos> orgaosoferta;
	private List<Premios> premios;
	private UnidadeTransplante unidadetransp;
	//private List<Transplantes> transplantados;
	private List<Recetores> recetores;
	private List<GravidadeOrgao> gravorgao;
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="ID_ORGAO_OFERTA")
	public int getIdorgoferta() {
		return idorgoferta;
	}
	public void setIdorgoferta(int idorgoferta) {
		this.idorgoferta = idorgoferta;
	}
	
	@Column(name="NOME_ORGAO")
	public String getNomeorgaooferta() {
		return nomeorgaooferta;
	}
	public void setNomeorgaooferta(String nomeorgaooferta) {
		this.nomeorgaooferta = nomeorgaooferta;
	}
	
	@OneToMany(fetch = FetchType.LAZY, mappedBy = "orgoferta")
	public List<AssignacaoOrgaos> getAssignacao() {
		return assignacao;
	}
	public void setAssignacao(List<AssignacaoOrgaos> assignacao) {
		this.assignacao = assignacao;
	}
	
	@OneToMany(fetch = FetchType.LAZY, mappedBy = "orgaosoferta")
	public List<Objetivos> getOrgaosoferta() {
		return orgaosoferta;
	}
	public void setOrgaosoferta(List<Objetivos> orgaosoferta) {
		this.orgaosoferta = orgaosoferta;
	}
	
	@OneToMany(fetch = FetchType.LAZY, mappedBy = "orgao")
	public List<Premios> getPremios() {
		return premios;
	}
	public void setPremios(List<Premios> premios) {
		this.premios = premios;
	}
	
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "ID_UNIDADE_TRANSP")
	public UnidadeTransplante getUnidadetransp() {
		return unidadetransp;
	}
	public void setUnidadetransp(UnidadeTransplante unidadetransp) {
		this.unidadetransp = unidadetransp;
	}
	
	@OneToMany(fetch = FetchType.LAZY, mappedBy = "orgao")
	public List<Recetores> getRecetores() {
		return recetores;
	}
	public void setRecetores(List<Recetores> recetores) {
		this.recetores = recetores;
	}
	
/*	@OneToMany(fetch = FetchType.LAZY, mappedBy = "orgaosoferta")
	public List<Transplantes> getTransplantados() {
		return transplantados;
	}
	public void setTransplantados(List<Transplantes> transplantados) {
		this.transplantados = transplantados;
	}*/
	@OneToMany(fetch = FetchType.LAZY, mappedBy = "orgao")
	public List<GravidadeOrgao> getGravorgao() {
		return gravorgao;
	}
	public void setGravorgao(List<GravidadeOrgao> gravorgao) {
		this.gravorgao = gravorgao;
	}
	
}
