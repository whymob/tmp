package pt.iconic.ipst.dao;

import java.util.Calendar;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

@Repository
@Transactional
public class EquipaTransplantesDAO {
	
	
	
	@PersistenceContext
	private EntityManager manager;
	
	@SuppressWarnings( "unchecked")
	public List<Object> carregatransplanteshospital(Long idhospital){
		
		List<Object> out = null;

/*		Query query = manager.createNativeQuery("select d.CODIGODADOR , e.ESTADO as estadodador, orgof.NOME_ORGAO, elt.SALA as sala, elt.DATA as datahora, statusorg.STATUS, "
				+ "estadohosp.ESTADO as estadoassighospital, d.ID_DADOR, an.ID_ANALISEDADOR, orgof.ID_ORGAO_OFERTA "
				+ "from ASSIGNACAO_HOSPITAL ah "
				+ "inner join ASSIGNACAO_ORGAOS ao on (ao.ID_ASSIGNACAO_ORGAOS = ah.ID_ASSIGNACAO_ORGAO) "
				+ "left join EQUIPA_LOCAL_TRANSPLANTE elt on (elt.ID_ASSIG_ORGAO = ao.ID_ASSIGNACAO_ORGAOS) "
				+ "inner join ORGAOS_OFERTA orgof on (orgof.ID_ORGAO_OFERTA = ao.ID_ORGAOOFERTA) "
				+ "inner join DADOR d on (d.ID_DADOR = ao.ID_DADOR) "
				+ "inner join ANALISEDADOR an on (an.ID_DADOR = d.ID_DADOR) "
				+ "inner join ESTADODADOR e on (e.ID_ESTADODADOR = d.ID_ESTADODADOR) "
				+ "inner join STATUS_ASSIGNACAO_ORGAOS statusorg on (statusorg.ID_STATUS = ao.ID_STATUS) "
				+ "inner join ESTADO_ASSIGNACAO_HOSPITAL estadohosp on (estadohosp.ID_ESTADO = ah.ID_ESTADO) "
				+ "where ah.ID_HOSPITAL=:idhospital AND (estadohosp.ID_ESTADO = 1 OR  estadohosp.ID_ESTADO = 3 OR estadohosp.ID_ESTADO = 4)");*/
		
		Query query = manager.createNativeQuery("select d.CODIGODADOR , e.ESTADO as estadodador, orgof.NOME_ORGAO, elt.SALA as sala, elt.DATA as datahora, statusorg.STATUS, "
				+ "estadohosp.ESTADO as estadoassighospital, d.ID_DADOR, an.ID_ANALISEDADOR, orgof.ID_ORGAO_OFERTA "
				+ "from ASSIGNACAO_HOSPITAL ah "
				+ "inner join ASSIGNACAO_ORGAOS ao on (ao.ID_ASSIGNACAO_ORGAOS = ah.ID_ASSIGNACAO_ORGAO) "
				+ "left join EQUIPA_LOCAL_TRANSPLANTE elt on (elt.ID_ASSIG_ORGAO = ao.ID_ASSIGNACAO_ORGAOS) "
				+ "inner join ORGAOS_OFERTA orgof on (orgof.ID_ORGAO_OFERTA = ao.ID_ORGAOOFERTA) "
				+ "inner join DADOR d on (d.ID_DADOR = ao.ID_DADOR) "
				+ "inner join ANALISEDADOR an on (an.ID_DADOR = d.ID_DADOR) "
				+ "inner join ESTADODADOR e on (e.ID_ESTADODADOR = d.ID_ESTADODADOR) "
				+ "inner join STATUS_ASSIGNACAO_ORGAOS statusorg on (statusorg.ID_STATUS = ao.ID_STATUS) "
				+ "inner join ESTADO_ASSIGNACAO_HOSPITAL estadohosp on (estadohosp.ID_ESTADO = ah.ID_ESTADO) "
				+ "where ah.ID_HOSPITAL=:idhospital AND (estadohosp.ID_ESTADO = 1 OR  estadohosp.ID_ESTADO = 3 OR estadohosp.ID_ESTADO = 4) "
				+ "and ao.ID_ASSIGNACAO_ORGAOS NOT IN (select t.ID_ASSIG_ORGAO from TRANSPLANTADOS t)");
		query.setParameter("idhospital", idhospital);


		
		out = query.getResultList();
//		int count = 0;  
//		for (Iterator i = out.iterator(); i.hasNext();) {  
//		    Object[] values = (Object[]) i.next();  
//		    System.out.println(++count + ": " + values[0] + ", " + values[1] + " ," + values[2] +"," + values[3] + " ," + values[4] + " ," + values[5] + "<br />");  
//
//		}

		
		return out;
	}

	@SuppressWarnings("unchecked")
	public List<Object> carregatransplanteshospitalfiltro(Calendar dataum, Calendar datadois, Long idhospital) {
		List<Object> out = null;

		Query query = manager.createNativeQuery("select d.CODIGODADOR , e.ESTADO as estadodador, orgof.NOME_ORGAO, elt.SALA as sala, elt.DATA as datahora, statusorg.STATUS, "
				+ "estadohosp.ESTADO as estadoassighospital, d.ID_DADOR, an.ID_ANALISEDADOR, orgof.ID_ORGAO_OFERTA "
				+ "from ASSIGNACAO_HOSPITAL ah "
				+ "inner join ASSIGNACAO_ORGAOS ao on (ao.ID_ASSIGNACAO_ORGAOS = ah.ID_ASSIGNACAO_ORGAO) "
				+ "left join EQUIPA_LOCAL_TRANSPLANTE elt on (elt.ID_ASSIG_ORGAO = ao.ID_ASSIGNACAO_ORGAOS) "
				+ "inner join ORGAOS_OFERTA orgof on (orgof.ID_ORGAO_OFERTA = ao.ID_ORGAOOFERTA) "
				+ "inner join DADOR d on (d.ID_DADOR = ao.ID_DADOR) "
				+ "inner join ANALISEDADOR an on (an.ID_DADOR = d.ID_DADOR) "
				+ "inner join ESTADODADOR e on (e.ID_ESTADODADOR = d.ID_ESTADODADOR) "
				+ "inner join STATUS_ASSIGNACAO_ORGAOS statusorg on (statusorg.ID_STATUS = ao.ID_STATUS) "
				+ "inner join ESTADO_ASSIGNACAO_HOSPITAL estadohosp on (estadohosp.ID_ESTADO = ah.ID_ESTADO) "
				+ "where ah.ID_HOSPITAL=:idhospital AND (estadohosp.ID_ESTADO = 1 OR  estadohosp.ID_ESTADO = 3 OR estadohosp.ID_ESTADO = 4) "
				+ "and ao.ID_ASSIGNACAO_ORGAOS IN (select t.ID_ASSIG_ORGAO from TRANSPLANTADOS t where (cast(t.DATA  as date) BETWEEN :date AND :date2))");
		query.setParameter("idhospital", idhospital);
		query.setParameter("date", dataum);
		query.setParameter("date2", datadois);
		
		out = query.getResultList();
		return out;
	}

}
