package pt.iconic.ipst.modelo;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name = "ACSSDETALHECOLHEITA")
public class ACSSDetalheColheita 
{
	private Long idacssdetalhe;
	private String entidade;
	private float valor;
//	private String desccompromisso;
	private String caminhofatura;
	private GCCTColheita gcctcolheita;
	private Compromisso compromisso;
	private int ordem;
	//private FaturaACSS fatura;
	private String notas;
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="ID_ACSSDETALHECOLHEITA")
	public Long getIdacssdetalhe() {
		return idacssdetalhe;
	}
	public void setIdacssdetalhe(Long idacssdetalhe) {
		this.idacssdetalhe = idacssdetalhe;
	}
	

	@Column(name = "ENTIDADE")
	public String getEntidade() {
		return entidade;
	}
	public void setEntidade(String entidade) {
		this.entidade = entidade;
	}
	@Column(name="VALOR")
	public float getValor() {
		return valor;
	}
	public void setValor(float valor) {
		this.valor = valor;
	}

/*	@Column(name="DESCCOMPROMISSO")
	public String getDesccompromisso() {
		return desccompromisso;
	}
	public void setDesccompromisso(String desccompromisso) {
		this.desccompromisso = desccompromisso;
	}*/
	
	@Column(name="CAMINHOFATURA")
	public String getCaminhofatura() {
		return caminhofatura;
	}
	public void setCaminhofatura(String caminhofatura) {
		this.caminhofatura = caminhofatura;
	}
	
	@ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "ID_GCCTCOLHEITA")
	public GCCTColheita getGcctcolheita() {
		return gcctcolheita;
	}
	public void setGcctcolheita(GCCTColheita gcctcolheita) {
		this.gcctcolheita = gcctcolheita;
	}
	
	@ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "ID_COMPROMISSO")
	public Compromisso getCompromisso() {
		return compromisso;
	}
	public void setCompromisso(Compromisso compromisso) {
		this.compromisso = compromisso;
	}
	
//	@ManyToOne(fetch = FetchType.EAGER)
//    @JoinColumn(name = "ID_FATURA")
//	public FaturaACSS getFatura() {
//		return fatura;
//	}
//	public void setFatura(FaturaACSS fatura) {
//		this.fatura = fatura;
//	}
	
	@Column(name="NOTAS")
	public String getNotas() {
		return notas;
	}
	public void setNotas(String notas) {
		this.notas = notas;
	}
	
	@Column(name="ORDEM")
	public int getOrdem() {
		return ordem;
	}
	public void setOrdem(int ordem) {
		this.ordem = ordem;
	}
}
