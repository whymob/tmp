package pt.iconic.ipst.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;

import pt.iconic.ipst.modelo.DadorDetalhes;

@Repository
public class DadorDetalhesDAO {

	@PersistenceContext
	private EntityManager manager;
	
	
	public void adiciona(DadorDetalhes dadordetalhes){
		manager.persist(dadordetalhes);	
	}
	
	public void atualiza(DadorDetalhes dadordetalhes){
		manager.merge(dadordetalhes);
	}
	

	/*	@SuppressWarnings("unchecked")
	public List<DadorDetalhes> ListaDador(){
		return manager.createQuery("select d from DadorDetalhes d").getResultList();
	}
	
	public DadorDetalhes buscaPorId(Long id){
		return manager.find(DadorDetalhes.class, id);
	}
	
	
	public void remove(DadorDetalhes dadordetalhes){
		DadorDetalhes dadordetalhesARemover = buscaPorId(dadordetalhes.getId_dadordetalhes());
		manager.remove(dadordetalhesARemover);
	}*/
	
	@SuppressWarnings("rawtypes")
	public DadorDetalhes buscadetalhesdador(Long iddador){
		Query query = manager.createQuery("select d from DadorDetalhes d JOIN d.dador dador WHERE dador.id_Dador =:iddador");
		query.setParameter("iddador", iddador);
		
		List results = query.getResultList();
		DadorDetalhes detalhes = null;
		if(!results.isEmpty()){
		    // ignores multiple results
			detalhes = (DadorDetalhes) results.get(0);
		}
		return detalhes;
	}
	
	
	@SuppressWarnings("rawtypes")
	public DadorDetalhes buscapesodador(Long iddador){
		Query query = manager.createQuery("select d from DadorDetalhes d JOIN d.dador dador WHERE dador.id_Dador =:iddador");
		query.setParameter("iddador", iddador);
		
		List results = query.getResultList();
		DadorDetalhes peso = null;
		if(!results.isEmpty()){
		    // ignores multiple results
			peso = (DadorDetalhes) results.get(0);
		}
		return peso;
	}
	
}
