package pt.iconic.ipst.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import pt.iconic.ipst.modelo.PreopTerapeuticas;

@Repository
@Transactional
public class PreopTerapeuticasDAO {

	@PersistenceContext
	private EntityManager manager;
	
	
	public void adiciona(PreopTerapeuticas preop){
		manager.persist(preop);	
	}
	

	public void atualiza(PreopTerapeuticas preop){
		manager.merge(preop);
	}
	
/*
	@SuppressWarnings("unchecked")
	public List<PreopTerapeuticas> ListaPreopTerapeuticas(){
		return manager.createQuery("select a from PreopTerapeuticas a").getResultList();
	}*/
	
	public PreopTerapeuticas buscaPorId(Long id){
		return manager.find(PreopTerapeuticas.class, id);
	}
	
	
	public void remove(PreopTerapeuticas preop){
		PreopTerapeuticas preopARemover = buscaPorId(preop.getId_preopterap());
		manager.remove(preopARemover);
		
	}
	
	@SuppressWarnings("unchecked")
	public List<PreopTerapeuticas> listacolheitapreopterapassignacao(Long idassigorg){
		
		Query query = manager.createQuery("select b from PreopTerapeuticas b JOIN b.assigorgao a WHERE a.id_assignacao =:idassigorg");
		query.setParameter("idassigorg", idassigorg);
		
		List<PreopTerapeuticas> results = query.getResultList();
		return results;
		
	}
}
