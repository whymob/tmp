package pt.iconic.ipst.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import pt.iconic.ipst.modelo.TransplantePulmoesComplicacoes;

@Repository
@Transactional
public class TransplantePulmoesComplicacoesDAO {

	@PersistenceContext
	private EntityManager manager;
	
	
	public void adiciona(TransplantePulmoesComplicacoes transplante){
		manager.persist(transplante);	
	}
	

	public void atualiza(TransplantePulmoesComplicacoes transplante){
		manager.merge(transplante);
	}
	

/*	@SuppressWarnings("unchecked")
	public List<TransplantePulmoesComplicacoes> ListaTransplantePulmoesComplicacoes(){
		return manager.createQuery("select a from TransplantePulmoesComplicacoes a").getResultList();
	}*/
	
	public TransplantePulmoesComplicacoes buscaPorId(Long id){
		return manager.find(TransplantePulmoesComplicacoes.class, id);
	}
	
	
	public void remove(TransplantePulmoesComplicacoes transplante){
		TransplantePulmoesComplicacoes transplanteARemover = buscaPorId(transplante.getIdtransppulmoescompl());
		manager.remove(transplanteARemover);
		
	}
	
	@SuppressWarnings("unchecked")
	public List<TransplantePulmoesComplicacoes> listatransplantePulmoescomplassig(Long idassigorg){
		
		Query query = manager.createQuery("select b from TransplantePulmoesComplicacoes b JOIN b.assigorgao a WHERE a.id_assignacao =:idassigorg");
		query.setParameter("idassigorg", idassigorg);
		
		List<TransplantePulmoesComplicacoes> results = query.getResultList();
		return results;
		
	}
}
