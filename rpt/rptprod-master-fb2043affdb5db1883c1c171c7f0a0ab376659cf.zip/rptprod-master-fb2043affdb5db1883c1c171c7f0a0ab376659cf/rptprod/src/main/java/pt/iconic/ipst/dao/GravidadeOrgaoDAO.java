package pt.iconic.ipst.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;

import pt.iconic.ipst.modelo.GravidadeOrgao;

@Repository
public class GravidadeOrgaoDAO 
{
	@PersistenceContext
	private EntityManager manager;
	
/*	@Transactional
	public void adiciona(GravidadeOrgao grav){
		manager.persist(grav);	
	}
	
	@Transactional
	public void atualiza(GravidadeOrgao grav){
		manager.merge(grav);
	}

	@SuppressWarnings("unchecked")
	public List<GravidadeOrgao> ListaGravidadeOrgao(){
		return manager.createQuery("select d from GravidadeOrgao d").getResultList();
	}*/
	
	public GravidadeOrgao buscaPorId(Long id){
		return manager.find(GravidadeOrgao.class, id);
	}
	
/*	public void remove(GravidadeOrgao grav){
		GravidadeOrgao gravrem = buscaPorId(grav.getId_gravidadeorgao());
		manager.remove(gravrem);
	}*/
	
	@SuppressWarnings("unchecked")
	public List<GravidadeOrgao> buscagravidadeorgao(int idorg)
	{		
		Query query = manager.createQuery("select o from GravidadeOrgao o JOIN o.orgao org WHERE org.idorgoferta =:idorg");
		query.setParameter("idorg", idorg);
		
		List<GravidadeOrgao> results = query.getResultList();

		return results;
	}
}
