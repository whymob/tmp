package pt.iconic.ipst.modelo;

import java.util.Calendar;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import org.springframework.format.annotation.DateTimeFormat;

@Entity
@Table(name = "TRANSPLANTADODETALHES")
public class TransplantadoDetalhes 
{
	private Long id_tranplantadodetalhes;
	private String moradatranplantado;
	private String codpostaltranplantado;
	private String localidadetranplantado;
	private String emailtranplantado;
	private Calendar datanascimentotransplantado;
	private int telemoveltransplantado;
	private int telefonetransplantado;
	private boolean sexotransplantado;
	private boolean tipocidadaotransplantado;
	private Paises nacionalidadetransplantado;
	private LocalResidencia residenciatransplantado;
	private int numidentificacaotransplantado;
	private int tiponumidentificacaotransplantado;
	private int numidentificacaotransplantado2;
	private int tiponumidentificacaotransplantado2;
	private Transplantes tranplantado;
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="ID_TRANSPLANTADODETALHES")
	public Long getId_tranplantadodetalhes() {
		return id_tranplantadodetalhes;
	}
	public void setId_tranplantadodetalhes(Long id_tranplantadodetalhes) {
		this.id_tranplantadodetalhes = id_tranplantadodetalhes;
	}
	
	@Column(name="MORADA")
	public String getMoradatranplantado() {
		return moradatranplantado;
	}
	public void setMoradatranplantado(String moradatranplantado) {
		this.moradatranplantado = moradatranplantado;
	}
	
	@Column(name="CODPOSTAL")
	public String getCodpostaltranplantado() {
		return codpostaltranplantado;
	}
	public void setCodpostaltranplantado(String codpostaltranplantado) {
		this.codpostaltranplantado = codpostaltranplantado;
	}
	
	@Column(name="LOCALIDADE")
	public String getLocalidadetranplantado() {
		return localidadetranplantado;
	}
	public void setLocalidadetranplantado(String localidadetranplantado) {
		this.localidadetranplantado = localidadetranplantado;
	}
	
	@Column(name="EMAIL")
	public String getEmailtranplantado() {
		return emailtranplantado;
	}
	public void setEmailtranplantado(String emailtranplantado) {
		this.emailtranplantado = emailtranplantado;
	}
	
	@DateTimeFormat(pattern="dd/MM/yyyy")
	@Temporal(TemporalType.DATE)
	@Column(name="DATANASCIMENTO")
	public Calendar getDatanascimentotransplantado() {
		return datanascimentotransplantado;
	}
	public void setDatanascimentotransplantado(
			Calendar datanascimentotransplantado) {
		this.datanascimentotransplantado = datanascimentotransplantado;
	}
	
	@Column(name="TELEMOVEL")
	public int getTelemoveltransplantado() {
		return telemoveltransplantado;
	}
	public void setTelemoveltransplantado(int telemoveltransplantado) {
		this.telemoveltransplantado = telemoveltransplantado;
	}
	
	@Column(name="TELEFONE")
	public int getTelefonetransplantado() {
		return telefonetransplantado;
	}
	public void setTelefonetransplantado(int telefonetransplantado) {
		this.telefonetransplantado = telefonetransplantado;
	}
	
	@Column(name="SEXO")
	public boolean isSexotransplantado() {
		return sexotransplantado;
	}
	public void setSexotransplantado(boolean sexotransplantado) {
		this.sexotransplantado = sexotransplantado;
	}
	
	@Column(name="TIPOCIDADAO")
	public boolean isTipocidadaotransplantado() {
		return tipocidadaotransplantado;
	}
	public void setTipocidadaotransplantado(boolean tipocidadaotransplantado) {
		this.tipocidadaotransplantado = tipocidadaotransplantado;
	}

	@ManyToOne(fetch=FetchType.EAGER)
	@JoinColumn(name="ID_PAIS")
	public Paises getNacionalidadetransplantado() {
		return nacionalidadetransplantado;
	}
	public void setNacionalidadetransplantado(Paises nacionalidadetransplantado) {
		this.nacionalidadetransplantado = nacionalidadetransplantado;
	}

	@ManyToOne(fetch=FetchType.EAGER)
	@JoinColumn(name="ID_RESIDENCIA")
	public LocalResidencia getResidenciatransplantado() {
		return residenciatransplantado;
	}
	public void setResidenciatransplantado(LocalResidencia residenciatransplantado) {
		this.residenciatransplantado = residenciatransplantado;
	}
	
	@Column(name="NUMIDENTIFICACAO")
	public int getNumidentificacaotransplantado() {
		return numidentificacaotransplantado;
	}
	public void setNumidentificacaotransplantado(
			int numidentificacaotransplantado) {
		this.numidentificacaotransplantado = numidentificacaotransplantado;
	}
	
	@Column(name="TIPOIDENTIFICACAO")
	public int getTiponumidentificacaotransplantado() {
		return tiponumidentificacaotransplantado;
	}
	public void setTiponumidentificacaotransplantado(
			int tiponumidentificacaotransplantado) {
		this.tiponumidentificacaotransplantado = tiponumidentificacaotransplantado;
	}
	
	@Column(name="NUMIDENTIFICACAO2")
	public int getNumidentificacaotransplantado2() {
		return numidentificacaotransplantado2;
	}
	public void setNumidentificacaotransplantado2(
			int numidentificacaotransplantado2) {
		this.numidentificacaotransplantado2 = numidentificacaotransplantado2;
	}
	
	@Column(name="TIPOIDENTIFICACAO2")
	public int getTiponumidentificacaotransplantado2() {
		return tiponumidentificacaotransplantado2;
	}
	public void setTiponumidentificacaotransplantado2(
			int tiponumidentificacaotransplantado2) {
		this.tiponumidentificacaotransplantado2 = tiponumidentificacaotransplantado2;
	}

	@OneToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="ID_TRANSPLANTE")
	public Transplantes getTranplantado() {
		return tranplantado;
	}
	public void setTranplantado(Transplantes tranplantado) {
		this.tranplantado = tranplantado;
	}
}