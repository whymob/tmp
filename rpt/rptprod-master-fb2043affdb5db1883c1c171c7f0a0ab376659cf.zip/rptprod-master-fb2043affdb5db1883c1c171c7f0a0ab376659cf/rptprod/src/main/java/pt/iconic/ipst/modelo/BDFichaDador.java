package pt.iconic.ipst.modelo;

import java.util.Calendar;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name = "BDFICHADADOR")
public class BDFichaDador {

	private Long Id_BDFichaDador;
	private AnaliseDador analiseDador;
	private Long SNSFichaDador;
	private int NIFFichaDador;
	private String Morada1;
	private String Morada2;
	private String CodPostal;
	private String Localidade;
	private int Telemovel;
	private int Telefone;
	private String Email;
	private int Peso;
	private int Altura;
	private Calendar DataNascimento;
	private Etnia etnia;
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="ID_BDFICHADADOR")
	public Long getId_BDFichaDador() {
		return Id_BDFichaDador;
	}
	public void setId_BDFichaDador(Long id_BDFichaDador) {
		Id_BDFichaDador = id_BDFichaDador;
	}
	
	@OneToOne
	@JoinColumn(name="ID_ANALISEDADOR")
	public AnaliseDador getAnaliseDador() {
		return analiseDador;
	}
	public void setAnaliseDador(AnaliseDador analiseDador) {
		this.analiseDador = analiseDador;
	}


	
	@Column(name="SNSFICHADADOR")
	public Long getSNSFichaDador() {
		return SNSFichaDador;
	}
	public void setSNSFichaDador(Long sNSFichaDador) {
		SNSFichaDador = sNSFichaDador;
	}
	
	@Column(name="NIFFICHADADOR")
	public int getNIFFichaDador() {
		return NIFFichaDador;
	}
	public void setNIFFichaDador(int nIFFichaDador) {
		NIFFichaDador = nIFFichaDador;
	}
	
	@Column(name="MORADA1")
	public String getMorada1() {
		return Morada1;
	}
	public void setMorada1(String morada1) {
		Morada1 = morada1;
	}
	
	@Column(name="MORADA2")
	public String getMorada2() {
		return Morada2;
	}
	public void setMorada2(String morada2) {
		Morada2 = morada2;
	}
	
	@Column(name="CODPOSTAL")
	public String getCodPostal() {
		return CodPostal;
	}
	public void setCodPostal(String codPostal) {
		CodPostal = codPostal;
	}
	
	@Column(name="LOCALIDADE")
	public String getLocalidade() {
		return Localidade;
	}
	public void setLocalidade(String localidade) {
		Localidade = localidade;
	}
	
	@Column(name="TELEMOVEL")
	public int getTelemovel() {
		return Telemovel;
	}
	public void setTelemovel(int telemovel) {
		Telemovel = telemovel;
	}
	
	@Column(name="TELEFONE")
	public int getTelefone() {
		return Telefone;
	}
	public void setTelefone(int telefone) {
		Telefone = telefone;
	}
	
	@Column(name="EMAIL")
	public String getEmail() {
		return Email;
	}
	public void setEmail(String email) {
		Email = email;
	}
	
	@Column(name="PESO")
	public int getPeso() {
		return Peso;
	}
	public void setPeso(int peso) {
		Peso = peso;
	}
	
	@Column(name="ALTURA")
	public int getAltura() {
		return Altura;
	}
	public void setAltura(int altura) {
		Altura = altura;
	}
	
	@Column(name="DATANASCIMENTO")
    public Calendar getDataNascimento() {
		return DataNascimento;
	}
	public void setDataNascimento(Calendar dataNascimento) {
		DataNascimento = dataNascimento;
	}
	
	@OneToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "ID_ETNIA")
	public Etnia getEtnia() {
		return etnia;
	}
	public void setEtnia(Etnia etnia) {
		this.etnia = etnia;
	}
	
	
}
