package pt.iconic.ipst.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;

import pt.iconic.ipst.modelo.OrgaosOferta;

@Repository
public class OrgaosOfertaDAO {
	
	@PersistenceContext
	private EntityManager manager;
	
	@SuppressWarnings("unchecked")
	public List<OrgaosOferta> ListaOrgaosOferta(){
		return manager.createQuery("select o from OrgaosOferta o").getResultList();
	}
	
	public OrgaosOferta buscaPorId(int i){
		return manager.find(OrgaosOferta.class, i);
	}

	@SuppressWarnings("unchecked")
	public Object buscaOrgaosporUnidade(Long uni) {
		Query query = manager.createQuery("select o from OrgaosOferta o JOIN o.unidadetransp u WHERE u.id_unidadetransplante =:iduni");
		query.setParameter("iduni", uni);
		
		List<OrgaosOferta> results = query.getResultList();
		
		return results;
	}
	

}