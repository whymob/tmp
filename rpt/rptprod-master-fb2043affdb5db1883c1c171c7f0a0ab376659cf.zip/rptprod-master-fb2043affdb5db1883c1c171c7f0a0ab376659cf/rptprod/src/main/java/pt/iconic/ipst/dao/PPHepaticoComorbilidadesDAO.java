package pt.iconic.ipst.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;
import pt.iconic.ipst.modelo.PPHepaticoComorbilidades;;

@Repository
public class PPHepaticoComorbilidadesDAO {

	@PersistenceContext
	private EntityManager manager;
	
	@Transactional
	public void adiciona(PPHepaticoComorbilidades hep){
		manager.persist(hep);	
	}
	
	@Transactional
	public void atualiza(PPHepaticoComorbilidades hep){
		manager.merge(hep);
	}
	
/*	@SuppressWarnings("unchecked")
	public List<PPHepaticoComorbilidades> ListaPPHepaticoComorbilidades(){
		return manager.createQuery("select p from PPHepaticoComorbilidades p").getResultList();
	}*/
	
	public PPHepaticoComorbilidades buscaPorId(Long id){
		return manager.find(PPHepaticoComorbilidades.class, id);
	}
	
	@Transactional
	public void remove(PPHepaticoComorbilidades hep){
		PPHepaticoComorbilidades heprem = buscaPorId(hep.getId_pphepaticocomorb());
		manager.remove(heprem);
	}
	
	@SuppressWarnings({ "rawtypes", "unchecked" })
	public List<PPHepaticoComorbilidades> ListaPPHepaticoComorbilidadesAnalise(Long id)
	{
		Query query = manager.createQuery("select e from PPHepaticoComorbilidades e JOIN e.analiserecetor analiserecetor WHERE analiserecetor.id_analiserecetor =:idanalise");
		query.setParameter("idanalise", id);

		List results = query.getResultList();
		
		return results;
	}
}
