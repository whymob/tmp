package pt.iconic.ipst.dao;


import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import pt.iconic.ipst.modelo.Hospital;
import pt.iconic.ipst.modelo.PermissaoLocalizacao;




@Repository
@Transactional
public class PermissaoDAO {

	
	@PersistenceContext
	private EntityManager manager;
	
	public void adiciona(PermissaoLocalizacao permissaolocalizacao){
		manager.persist(permissaolocalizacao);	
	}
	
/*	public void atualiza(PermissaoLocalizacao permissaolocalizacao){
		manager.merge(permissaolocalizacao);
	}*/

	
	public PermissaoLocalizacao buscaPorId(Long id){
		return manager.find(PermissaoLocalizacao.class, id);
	}
	
	
	public void remove(PermissaoLocalizacao permloc){
		PermissaoLocalizacao permlocARemover = buscaPorId(permloc.getId_PermissaoLocalizacao());
		manager.remove(permlocARemover);
	}
	
	
	@SuppressWarnings("unchecked")
	public PermissaoLocalizacao buscaidpermissao(Long id_hospital, Long idutilizador, Long posicao){
		
		String sql = "select * from PERMISSAO_LOCALIZACAO p"
				+ " where p.ID_HOSPITAL = :id_hospital AND p.ID_POSICAO = :posicao AND p.ID_UTILIZADOR = :idutilizador";
		Query query = manager.createNativeQuery(sql, PermissaoLocalizacao.class);
		query.setParameter("id_hospital", id_hospital);
		query.setParameter("posicao", posicao);
		query.setParameter("idutilizador", idutilizador);
		
		List<PermissaoLocalizacao> results = query.getResultList();
		PermissaoLocalizacao perm = null;
		if(!results.isEmpty()){
			perm = (PermissaoLocalizacao) results.get(0);
		}
		
		return perm;
	}
	
	@SuppressWarnings("unchecked")
	public List<Hospital> ListaLocalizacoesPosicao(Long idposicao, Long iduser){
		
		List<Hospital> out = null;
//		System.out.println("Id da Posicao: "+idposicao);
//		System.out.println("Id do user: "+iduser);
		
		String sql = "select Hospital.* from HOSPITAL inner join PERMISSAO_LOCALIZACAO on(PERMISSAO_LOCALIZACAO.ID_HOSPITAL = HOSPITAL.ID_HOSPITAL) "
				+ "inner join UTILIZADOR on (UTILIZADOR.ID_UTILIZADOR = PERMISSAO_LOCALIZACAO.ID_UTILIZADOR) "
				+ "inner join POSICAO on (POSICAO.ID_POSICAO = PERMISSAO_LOCALIZACAO.ID_POSICAO) "
				+ "where UTILIZADOR.ID_UTILIZADOR = :iduser AND POSICAO.ID_POSICAO = :idposicao";
		Query query = manager.createNativeQuery(sql, Hospital.class);
		query.setParameter("iduser", iduser) ;
		query.setParameter("idposicao", idposicao) ;		
		out = (List<Hospital>) query.getResultList();
		//System.out.println("Hospitais"+out.get(0).getNomeHospital());
		return out;	
	}


	@SuppressWarnings("unchecked")
	 public List<PermissaoLocalizacao> ListaPermissoesUtilizador(Long iduser)
	 { 
	  List<PermissaoLocalizacao> out = null;
	  
	  Query query = manager.createQuery("select p from PermissaoLocalizacao p join p.utilizador u WHERE u.ID_Utilizador =:iduser");
	  query.setParameter("iduser", iduser) ;
	    
	  out = (List<PermissaoLocalizacao>) query.getResultList();

	  return out; 
	 }
	
	@SuppressWarnings("unchecked")
	public List<Object[]> ListaHospitaisPermissao(Long iduser){
		
		List<Object[]> out = null;
//		System.out.println("Id da Posicao: "+idposicao);
//		System.out.println("Id do user: "+iduser);
		
		String sql = "select Distinct(NOMEHOSPITAL) from HOSPITAL inner join PERMISSAO_LOCALIZACAO on(PERMISSAO_LOCALIZACAO.ID_HOSPITAL = HOSPITAL.ID_HOSPITAL) "
				+ "inner join UTILIZADOR on (UTILIZADOR.ID_UTILIZADOR = PERMISSAO_LOCALIZACAO.ID_UTILIZADOR) "
				+ "inner join POSICAO on (POSICAO.ID_POSICAO = PERMISSAO_LOCALIZACAO.ID_POSICAO) "
				+ "where UTILIZADOR.ID_UTILIZADOR = :iduser";
		Query query = manager.createNativeQuery(sql);
		query.setParameter("iduser", iduser) ;		
		out = (List<Object[]>) query.getResultList();
		//System.out.println("Hospitais"+out.get(0).getNomeHospital());
		return out;	
	}




	public boolean buscapermissaoposicao(Long id_hospital, Long idutilizador,
			Long id_Posicao) {


		String sql = "select p.LEITURAESCRITA from PERMISSAO_LOCALIZACAO p "
				+ "where (p.ID_HOSPITAL = :id_hospital) "
				+ "AND (p.ID_POSICAO = :id_Posicao) "
				+ "AND (p.ID_UTILIZADOR = :idutilizador)";
		Query query = manager.createNativeQuery(sql);
		query.setParameter("id_hospital", id_hospital);
		query.setParameter("idutilizador", idutilizador);
		query.setParameter("id_Posicao", id_Posicao);
		
		return (boolean) query.getSingleResult();
	}

	public void atualizapermissao(Long id_hospital, Long idutilizador,
			Long id_Posicao, boolean leituraescrita) {
		
	    Query query = manager.createNativeQuery("update PERMISSAO_LOCALIZACAO set PERMISSAO_LOCALIZACAO.LEITURAESCRITA = :leituraescrita "
	    		+ "where PERMISSAO_LOCALIZACAO.ID_HOSPITAL = :id_hospital "
	    		+ "AND PERMISSAO_LOCALIZACAO.ID_POSICAO = :id_Posicao "
	    		+ "AND PERMISSAO_LOCALIZACAO.ID_UTILIZADOR = :idutilizador");
		query.setParameter("leituraescrita", leituraescrita);
		query.setParameter("id_hospital", id_hospital);
		query.setParameter("idutilizador", idutilizador);
		query.setParameter("id_Posicao", id_Posicao);
	        query.executeUpdate();
		
	}
}