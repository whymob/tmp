package pt.iconic.ipst.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import pt.iconic.ipst.modelo.AnaliseDador;
import pt.iconic.ipst.modelo.LesoesRadiografia;

@Repository
@Transactional
public class LesoesRadiografiaDAO
{
	@PersistenceContext
	private EntityManager manager;
	
/*	public void adiciona(LesoesRadiografia amostrasfo){
		manager.persist(amostrasfo);	
	}*/
	
	@Transactional
	public void atualiza(LesoesRadiografia amostrasfo){
		manager.merge(amostrasfo);
	}

/*	@SuppressWarnings("unchecked")
	public List<LesoesRadiografia> LesoesRadiografia(){
		return manager.createQuery("select d from LesoesRadiografia d").getResultList();
	}*/
	
	public LesoesRadiografia buscaPorId(Long id){
		return manager.find(LesoesRadiografia.class, id);
	}
	
	public void remove(LesoesRadiografia lesoesrx){
		LesoesRadiografia lesoes = buscaPorId(lesoesrx.getId_LesaoRadiografia());
		manager.remove(lesoes);
		
	}
	
	//adiciona a lesao � tabela
	@Transactional
	public boolean adicionalesao(String lesao, boolean e, boolean d, boolean m, Long id_analise)
	{
		AnaliseDador analise = manager.find(AnaliseDador.class, id_analise);
		
		LesoesRadiografia lesoes = new LesoesRadiografia();
		lesoes.setAnaliseDador(analise);
		lesoes.setLesao(lesao);
		lesoes.setM(m);
		lesoes.setPD(d);
		lesoes.setPE(e);

		manager.persist(lesoes);
				
		return true;
	}
	
	//carrega as lesoes quando insere a ultima lesao para que as da ultima apare�am em cima
	@SuppressWarnings("unchecked")
	public List<LesoesRadiografia> buscalesoesDescendente(Long idanalise)
	{		
		Query query = manager.createQuery("select a from LesoesRadiografia a JOIN a.analiseDador an WHERE an.id_AnaliseDador =:idanalise");
		query.setParameter("idanalise", idanalise);

		List<LesoesRadiografia> results = query.getResultList();

		return results;
	}
}