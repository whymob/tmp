package pt.iconic.ipst.modelo;

import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name = "UNIDADETRANSPLANTE")
public class UnidadeTransplante 
{
	private Long id_unidadetransplante;
	private String nome;
	private List<Unidade_Hospital> hosp;
//	private Orgaos orgaos;
	private List<OrgaosOferta> orgaosoferta;
	private List<Recetores> recetor;
	private List<Transplantes> transplantes;
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="ID_UNIDADETRANSP")
	public Long getId_unidadetransplante() {
		return id_unidadetransplante;
	}
	public void setId_unidadetransplante(Long id_unidadetransplante) {
		this.id_unidadetransplante = id_unidadetransplante;
	}
	
	@Column(name="NOME")
	public String getNome() {
		return nome;
	}
	public void setNome(String nome) {
		this.nome = nome;
	}
	
	@OneToMany(fetch = FetchType.LAZY, mappedBy = "unidtransp")
	public List<Unidade_Hospital> getHosp() {
		return hosp;
	}
	public void setHosp(List<Unidade_Hospital> hosp) {
		this.hosp = hosp;
	}
	
/*	@OneToOne(fetch = FetchType.LAZY, mappedBy = "unidtransp")
	public Orgaos getOrgaos() {
		return orgaos;
	}
	public void setOrgaos(Orgaos orgaos) {
		this.orgaos = orgaos;
	}*/
	
	@OneToMany(fetch = FetchType.LAZY, mappedBy = "unidadetransp")
	public List<Recetores> getRecetor() {
		return recetor;
	}
	public void setRecetor(List<Recetores> recetor) {
		this.recetor = recetor;
	}
	
	@OneToMany(fetch = FetchType.LAZY, mappedBy = "unidadetransp")
	public List<Transplantes> getTransplantes() {
		return transplantes;
	}
	public void setTransplantes(List<Transplantes> transplantes) {
		this.transplantes = transplantes;
	}
	
	@OneToMany(fetch = FetchType.LAZY, mappedBy = "unidadetransp")
	public List<OrgaosOferta> getOrgaosoferta() {
		return orgaosoferta;
	}
	public void setOrgaosoferta(List<OrgaosOferta> orgaosoferta) {
		this.orgaosoferta = orgaosoferta;
	}
}