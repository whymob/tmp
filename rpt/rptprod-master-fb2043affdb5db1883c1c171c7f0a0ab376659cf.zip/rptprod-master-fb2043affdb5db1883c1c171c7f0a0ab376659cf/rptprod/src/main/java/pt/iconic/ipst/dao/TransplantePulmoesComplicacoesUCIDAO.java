package pt.iconic.ipst.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import pt.iconic.ipst.modelo.TransplantePulmoesComplicacoesUCI;

@Repository
@Transactional
public class TransplantePulmoesComplicacoesUCIDAO {

	@PersistenceContext
	private EntityManager manager;
	
	
	public void adiciona(TransplantePulmoesComplicacoesUCI transplante){
		manager.persist(transplante);	
	}
	

	public void atualiza(TransplantePulmoesComplicacoesUCI transplante){
		manager.merge(transplante);
	}
	

/*	@SuppressWarnings("unchecked")
	public List<TransplantePulmoesComplicacoesUCI> ListaTransplantePulmoesComplicacoesUCI(){
		return manager.createQuery("select a from TransplantePulmoesComplicacoesUCI a").getResultList();
	}*/
	
	public TransplantePulmoesComplicacoesUCI buscaPorId(Long id){
		return manager.find(TransplantePulmoesComplicacoesUCI.class, id);
	}
	
	
	public void remove(TransplantePulmoesComplicacoesUCI transplante){
		TransplantePulmoesComplicacoesUCI transplanteARemover = buscaPorId(transplante.getIdtransppulmoescompluci());
		manager.remove(transplanteARemover);
		
	}
	
	@SuppressWarnings("unchecked")
	public List<TransplantePulmoesComplicacoesUCI> listatransplantePulmoescompluciassig(Long idassigorg){
		
		Query query = manager.createQuery("select b from TransplantePulmoesComplicacoesUCI b JOIN b.assigorgao a WHERE a.id_assignacao =:idassigorg");
		query.setParameter("idassigorg", idassigorg);
		
		List<TransplantePulmoesComplicacoesUCI> results = query.getResultList();
		return results;
		
	}
}
