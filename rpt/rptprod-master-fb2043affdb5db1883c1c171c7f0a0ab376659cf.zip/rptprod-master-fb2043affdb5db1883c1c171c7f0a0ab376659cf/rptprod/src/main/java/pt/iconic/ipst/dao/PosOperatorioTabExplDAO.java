package pt.iconic.ipst.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import pt.iconic.ipst.modelo.PosOperatorioTabExpl;


@Repository
@Transactional
public class PosOperatorioTabExplDAO {

	@PersistenceContext
	private EntityManager manager;
	
	
	public void adiciona(PosOperatorioTabExpl po){
		manager.persist(po);	
	}
	

	public void atualiza(PosOperatorioTabExpl po){
		manager.merge(po);
	}
	

/*	@SuppressWarnings("unchecked")
	public List<PosOperatorioTabExpl> ListaPosOperatorioTabExpl(){
		return manager.createQuery("select a from PosOperatorioTabExpl a").getResultList();
	}*/
	
	public PosOperatorioTabExpl buscaPorId(Long id){
		return manager.find(PosOperatorioTabExpl.class, id);
	}
	
	
	public void remove(PosOperatorioTabExpl po){
		PosOperatorioTabExpl poARemover = buscaPorId(po.getIdtipoposop());
		manager.remove(poARemover);
		
	}
	
	@SuppressWarnings("unchecked")
	public List<PosOperatorioTabExpl> listaPosOperatorioTabExplanalise(Long idanalise){
		
		Query query = manager.createQuery("select po from PosOperatorioTabExpl po JOIN po.analiseDador a WHERE a.id_AnaliseDador =:idanalise");
		query.setParameter("idanalise", idanalise);
		
		List<PosOperatorioTabExpl> results = query.getResultList();
		return results;
		
	}
}
