package pt.iconic.ipst.controller;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import pt.iconic.ipst.dao.ACSSDetalheColheitaDAO;
import pt.iconic.ipst.dao.CompromissoDAO;
import pt.iconic.ipst.dao.EntidadeDAO;
import pt.iconic.ipst.dao.FaturaACSSDAO;
import pt.iconic.ipst.dao.GCCTColheitaDAO;
import pt.iconic.ipst.dao.GCCTColheitaDetalheDAO;
import pt.iconic.ipst.dao.HospitalDAO;
import pt.iconic.ipst.dao.ObjetivosDAO;
import pt.iconic.ipst.dao.OrgaosOfertaDAO;
import pt.iconic.ipst.dao.PremiosDAO;
import pt.iconic.ipst.dao.ValoresColheitaDAO;
import pt.iconic.ipst.modelo.ACSSDetalheColheita;
import pt.iconic.ipst.modelo.Compromisso;
import pt.iconic.ipst.modelo.Entidade;
import pt.iconic.ipst.modelo.FaturaACSS;
import pt.iconic.ipst.modelo.GCCTColheita;
import pt.iconic.ipst.modelo.GCCTColheitaDetalhe;
import pt.iconic.ipst.modelo.Hospital;
import pt.iconic.ipst.modelo.Objetivos;
import pt.iconic.ipst.modelo.OrgaosOferta;
import pt.iconic.ipst.modelo.Premios;
import pt.iconic.ipst.modelo.ValoresColheitas;

@Controller
public class ACSSController 
{
	private HospitalDAO daohosp;
	private GCCTColheitaDAO daogcctcolheita;
	private GCCTColheitaDetalheDAO daogcctcolheitadetalhe;
	private ValoresColheitaDAO daovalorecolheitas;
	private EntidadeDAO daoentidade;
	private OrgaosOfertaDAO daoorgaooferta;
	private ObjetivosDAO daoobjetivos;
	private ACSSDetalheColheitaDAO daoacss;
	private CompromissoDAO daocompromisso;
	private FaturaACSSDAO daofatura;
	private PremiosDAO daopremios;
	
	@Autowired
	public ACSSController(HospitalDAO daohosp, GCCTColheitaDAO daogcctcolheita, GCCTColheitaDetalheDAO daogcctcolheitadetalhe, ValoresColheitaDAO daovalorecolheitas, EntidadeDAO daoentidade, 
			OrgaosOfertaDAO daoorgaooferta, ObjetivosDAO daoobjetivos, ACSSDetalheColheitaDAO daoacss, CompromissoDAO daocompromisso, FaturaACSSDAO daofatura, PremiosDAO daopremios)
	{
		this.daohosp = daohosp;
		this.daogcctcolheita = daogcctcolheita;
		this.daogcctcolheitadetalhe = daogcctcolheitadetalhe;
		this.daovalorecolheitas = daovalorecolheitas;
		this.daoentidade = daoentidade;
		this.daoorgaooferta = daoorgaooferta;
		this.daoobjetivos = daoobjetivos;
		this.daoacss = daoacss;
		this.daocompromisso = daocompromisso;
		this.daofatura = daofatura;
		this.daopremios = daopremios;
	}
	
	//------------------------ GERAL ------------------------//
	
	@RequestMapping(value="buscaultimoano", method = RequestMethod.POST, produces="application/json") // est� no OfertasCOntroller
	@ResponseBody
	public String buscaultimoano()
	{
		return "[\""+daovalorecolheitas.buscaultimoano()+"\"]";
	}
	
	//------------------------ FIM GERAL ------------------------//
	
	//------------------------ GCCT ------------------------//
	
	@RequestMapping(value="carregaseparadorconfirmacao", method = RequestMethod.POST)
	public String carregaseparadorconfirmacao(Model model)
	{
		model.addAttribute("colheitas", daogcctcolheita.ListaGCCTColheita());
		model.addAttribute("anocolheitagcct", daogcctcolheita.buscaAnosgcctcolheitaanalise());
		
		return "gcct/divseparadorconfirmacao";
	}
	
	@RequestMapping(value="buscatodos")
	public String buscatodos(Model model)
	{
		model.addAttribute("colheitas", daogcctcolheita.ListaGCCTColheita());
		
		return "gcct/divseparadorconfirmacaofilt";
	}
	
	@RequestMapping(value="buscacolheitafiltrada", method = RequestMethod.POST)
	public String buscacolheitafiltrada(@RequestParam("ano") int ano, @RequestParam("mes") int mes, Model model)
	{
		model.addAttribute("colheitas", daogcctcolheita.buscagcctcolheitafiltrado(ano, mes));
		
		return "gcct/divseparadorconfirmacaofilt";
	}
	
	@RequestMapping(value="buscaapenasvalidar", method = RequestMethod.POST)
	public String buscaapenasvalidar(Model model)
	{
		model.addAttribute("colheitas", daogcctcolheita.buscagcctcolheitanaovalidadofiltrado());
		
		return "gcct/divseparadorconfirmacaofilt";
	}
	
	@RequestMapping(value="validacolheitagcct", method = RequestMethod.POST)
	public String validacolheitagcct(@RequestParam("idcolheita") Long idcolheita, Model model)
	{
		GCCTColheita gcc = daogcctcolheita.buscaPorId(idcolheita);
		gcc.setEstado(1);
	
		daogcctcolheita.atualiza(gcc);
	
		model.addAttribute("colheitas", daogcctcolheita.buscaPorId(idcolheita));
		
		return "gcct/loads/carregalinhacolheita";
	}
	
	@RequestMapping(value="validaorgaocolheitagcct", method = RequestMethod.POST)
	public String validaorgaocolheitagcct(@RequestParam("id") Long id, Model model)
	{
		GCCTColheitaDetalhe gcd = daogcctcolheitadetalhe.buscaPorId(id);
		gcd.setEstado(1);
	
		daogcctcolheitadetalhe.atualiza(gcd);
	
		model.addAttribute("colheitadetalhe", daogcctcolheitadetalhe.buscaPorId(id));
		
		return "gcct/loads/carregalinhacolheitadetalhe";
	}
	
	@RequestMapping(value="guardaorgaoobs", method = RequestMethod.POST)
	public String guardaorgaoobs(@RequestParam("obs") String obs, @RequestParam("id") Long id, Model model)
	{
		GCCTColheitaDetalhe gcd = daogcctcolheitadetalhe.buscaPorId(id);
		
		gcd.setObservacoes(obs);
		daogcctcolheitadetalhe.atualiza(gcd);
		
		model.addAttribute("colheitadetalhe", daogcctcolheitadetalhe.buscaPorId(id));
		
		return "gcct/loads/carregalinhacolheitadetalhe";
	}
	
	//------------------------ FIM GCCT ------------------------//
	
	//------------------------ IPST ------------------------//
	
	@RequestMapping(value="buscaultimoanoobjetivos", method = RequestMethod.POST, produces="application/json") //Est� no OfertasController
	@ResponseBody
	public String buscaultimoanoobjetivos()
	{
		return "[\""+daoobjetivos.buscaultimoano()+"\"]";
	}
	
	@RequestMapping(value="validacolheitaipst", method = RequestMethod.POST)
	public String validacolheitaipst(@RequestParam("idcolheita") Long idcolheita, Model model, HttpSession session)
	{
		GCCTColheita gcc = daogcctcolheita.buscaPorId(idcolheita);
		gcc.setEstado(2);
	
		daogcctcolheita.atualiza(gcc);
	

		
		if(gcc.getAto().equals("Transplante"))
		{
			
			if(gcc.getTipo().equals("F�gado")){
				//System.out.println("Pagamento de Transplante F�gado");
				int idorgaooferta = 2;
				int tipo = 10;
				daoacss.insereatoAcssDetalheTransplante(idcolheita, idorgaooferta, tipo, gcc.getDador().getId_Dador());
			}else if(gcc.getTipo().equals("P�ncreas")){
				//System.out.println("Pagamento de Transplante P�ncreas");
				int idorgaooferta = 6;
				int tipo = 8;
				daoacss.insereatoAcssDetalheTransplante(idcolheita, idorgaooferta, tipo, gcc.getDador().getId_Dador());		
			}else if(gcc.getTipo().equals("Cora��o")){
				//System.out.println("Pagamento de Transplante Cora��o");
				int idorgaooferta = 1;
				int tipo = 9;
				daoacss.insereatoAcssDetalheTransplante(idcolheita, idorgaooferta, tipo, gcc.getDador().getId_Dador());		
			}
			else if(gcc.getTipo().equals("Rins")){
				//System.out.println("Pagamento de Transplante Rins");
				int idorgaooferta = 7;// ou 8 ou 9
				int tipo = 7;
				daoacss.insereatoAcssDetalheTransplante(idcolheita, idorgaooferta, tipo, gcc.getDador().getId_Dador());		
			}else if(gcc.getTipo().equals("Rim Esq")){
				//System.out.println("Pagamento de Transplante Rim Esq");
				int idorgaooferta = 8;
				int tipo = 7;
				daoacss.insereatoAcssDetalheTransplante(idcolheita, idorgaooferta, tipo, gcc.getDador().getId_Dador());		
			}else if(gcc.getTipo().equals("Rim Drt")){
				//System.out.println("Pagamento de Transplante Rim Drt");
				int idorgaooferta = 9;
				int tipo = 7;
				daoacss.insereatoAcssDetalheTransplante(idcolheita, idorgaooferta, tipo, gcc.getDador().getId_Dador());		
			}else if(gcc.getTipo().equals("Pulm�es")){
				//System.out.println("Pagamento de Transplante Pulm�es");
				int idorgaooferta = 3;// ou 4 ou 5
				int tipo = 11;
				daoacss.insereatoAcssDetalheTransplante(idcolheita, idorgaooferta, tipo, gcc.getDador().getId_Dador());		
			}
			else if(gcc.getTipo().equals("Pulm�o Esq")){
				//System.out.println("Pagamento de Transplante Pulm�o Esq");
				int idorgaooferta = 4;
				int tipo = 11;
				daoacss.insereatoAcssDetalheTransplante(idcolheita, idorgaooferta, tipo, gcc.getDador().getId_Dador());		
			}
			else if(gcc.getTipo().equals("Pulm�o Drt")){
				//System.out.println("Pagamento de Transplante Pulm�o Drt");
				int idorgaooferta = 5;// ou 4 ou 5
				int tipo = 11;
				daoacss.insereatoAcssDetalheTransplante(idcolheita, idorgaooferta, tipo, gcc.getDador().getId_Dador());		
			}else if(gcc.getTipo().equals("C�rnea")){
				//System.out.println("Pagamento de Transplante C�rnea");
				int idorgaooferta = 10;
				int tipo = 12;
				daoacss.insereatoAcssDetalheTransplante(idcolheita, idorgaooferta, tipo, gcc.getDador().getId_Dador());		
			}
			
		}
		else{//Colheitas inserir para ACSSDetalheColheita
			
		if(!daoacss.verificaexisteACSSDetalheColheita(idcolheita)){
			
			daoacss.insereatoAcssDetalheColheita(idcolheita);
			
		}
		
			
			
		}
	
		model.addAttribute("colheitas", daogcctcolheita.buscagcctcolheitaIPSTLinha(idcolheita));
		
		return "ipst/loads/carregalinhacolheitaipst";
	}
	
	@RequestMapping(value="buscacomobjetivos", method = RequestMethod.POST)
	public String buscacomobjetivos(Model model)
	{
		model.addAttribute("objetivos", daoobjetivos.buscacomobjetivos());
		
		return "ipst/loads/tabelaobjetivos";
	}
	
	@RequestMapping(value="buscatodosobjetivos", method = RequestMethod.POST)
	public String buscatodosobjetivos(Model model)
	{
		model.addAttribute("objetivos", daoobjetivos.ListaObjetivos());
		
		return "ipst/loads/tabelaobjetivos";
	}
	
	@RequestMapping(value="abredetalheconfirmacao", method = RequestMethod.POST)
	public String abredetalheconfirmacao(@RequestParam("idgcctcolheita") Long idgcctcolheita, Model model)
	{
		model.addAttribute("colheitadetalhe", daogcctcolheitadetalhe.buscagcctcolheitadetalhe(idgcctcolheita));	
		
		return "gcct/divconfirmacaodetalhe";
	}
	
	@RequestMapping(value="abredetalheipst", method = RequestMethod.POST)
	public String abredetalheipst(@RequestParam("idgcctcolheita") Long idgcctcolheita, Model model)
	{
		model.addAttribute("colheitadetalhe", daogcctcolheitadetalhe.buscagcctcolheitadetalheorgaos(idgcctcolheita));	
		
		return "ipst/divcolheitaipst";
	}
	
	@RequestMapping(value="criavaloripst", method = RequestMethod.POST)
	public String criavaloripst(/*@RequestParam("obs") String obs, @RequestParam("valor") double valor, @RequestParam("suplementar") double suplementar, @RequestParam("ato") String ato,
			@RequestParam("tipo") int tipo, @RequestParam("ano") int ano,*/ 
			ValoresColheitas vc , Model model)
	{
		
		daovalorecolheitas.adiciona(vc);
		
		model.addAttribute("valores", daovalorecolheitas.ListaValoresColheitas());
		
		return "ipst/loads/tabelaincentivos";
	}
	
	@RequestMapping(value="guardavaloripst", method = RequestMethod.POST)
	public String guardavaloripst(@RequestParam("obs") String obs, @RequestParam("id") Long id, @RequestParam("valor") float valor, @RequestParam("suplementar") float suplementar, Model model)
	{
		ValoresColheitas valc = daovalorecolheitas.buscaPorId(id);
		
		valc.setSuplementar(suplementar);
		valc.setObservacoes(obs);
		valc.setValor(valor);
		
		daovalorecolheitas.atualiza(valc);
		
		model.addAttribute("valores", daovalorecolheitas.ListaValoresColheitas());
		
		return "ipst/loads/tabelaincentivos";
	}
	
	@RequestMapping(value="buscacolheitafiltradaipst", method = RequestMethod.POST)
	public String buscacolheitafiltradaipst(@RequestParam("ano") int ano, @RequestParam("mes") int mes, Model model)
	{
		model.addAttribute("colheitas", daogcctcolheita.buscagcctcolheitafiltradoipst(ano, mes));
		
		return "ipst/divseparadorconfirmacaoipstfilt";
	}
	
	@RequestMapping(value="buscaaprovados", method = RequestMethod.POST)
	public String buscaaprovados(Model model)
	{
		model.addAttribute("colheitas", daogcctcolheita.buscagcctcolheitaIPST());
		
		return "ipst/divseparadorconfirmacaoipstfilt";
	}
	
	@RequestMapping(value="buscaporaporvar", method = RequestMethod.POST)
	public String buscaporaporvar(Model model)
	{
		model.addAttribute("colheitas", daogcctcolheita.buscagcctcolheitanaoaprovadofiltrado());

		return "ipst/divseparadorconfirmacaoipstfilt";
	}
	
	@RequestMapping(value="carregaseparadorincentivos", method = RequestMethod.POST)
	public String carregaseparadorincentivos(Model model)
	{
		model.addAttribute("valores", daovalorecolheitas.ListaValoresColheitas());
		
		return "ipst/divincentivos";
	}
	
	@RequestMapping(value="carregaseparadorincentivos2", method = RequestMethod.POST)
	public String carregaseparadorincentivos2(Model model)
	{
		model.addAttribute("valores", daovalorecolheitas.ListaValoresColheitas());
		
		return "ipst/loads/tabelaincentivos";
	}
	
	@RequestMapping(value="carregaseparadorobjetivos", method = RequestMethod.POST)
	public String carregaseparadorobjetivos(Model model)
	{
		model.addAttribute("entidades", daoentidade.ListaEntidade());
		model.addAttribute("orgaos", daoorgaooferta.ListaOrgaosOferta());
		model.addAttribute("objetivos", daoobjetivos.ListaObjetivos());
		
		return "ipst/divseparadorobjetivos";
	}
	
	@RequestMapping(value="carregaseparadorobjetivos2", method = RequestMethod.POST)
	public String carregaseparadorobjetivos2(Model model)
	{
		model.addAttribute("objetivos", daoobjetivos.ListaObjetivos());
		
		return "ipst/loads/tabelaobjetivos";
	}

	@RequestMapping(value="crianovoobjetivo", method = RequestMethod.POST)
	public String crianovoobjetivo(@RequestParam("ano") int ano, @RequestParam("entidade") Long entidade, @RequestParam("local") Long local, @RequestParam("orgao") int orgao, 
			@RequestParam("objetivo") int objetivo, @RequestParam("objetivoref") int objetivoref, Model model)
	{
		Objetivos obj = new Objetivos();
		obj.setAno(ano);
		obj.setRealizado(0);
		obj.setPagamento(false);
		obj.setObjetivo(objetivo);
		obj.setObjetivoref(objetivoref);
		obj.setEntidade(daoentidade.buscaPorId(entidade));
		obj.setHospital(daohosp.buscaPorId(local));
		obj.setOrgaosoferta(daoorgaooferta.buscaPorId(orgao));
		
		daoobjetivos.adiciona(obj);
		
		model.addAttribute("objetivos", daoobjetivos.ListaObjetivos());
		
		return "ipst/loads/tabelaobjetivos";
	}
	
	@RequestMapping(value="gravaobjetivo", method = RequestMethod.POST)
	public String gravaobjetivo(@RequestParam("ano") int ano, @RequestParam("entidade") Long entidade, @RequestParam("local") Long local, @RequestParam("orgao") int orgao, 
			@RequestParam("objetivo") int objetivo, @RequestParam("realizado") int realizado,@RequestParam("id") Long id, @RequestParam("objetivoref") int objetivoref, Model model)
	{
		Objetivos obj = daoobjetivos.buscaPorId(id);
		obj.setAno(ano);
		obj.setRealizado(realizado);
		obj.setObjetivo(objetivo);
		obj.setObjetivoref(objetivoref);
		obj.setEntidade(daoentidade.buscaPorId(entidade));
		obj.setHospital(daohosp.buscaPorId(local));
		obj.setOrgaosoferta(daoorgaooferta.buscaPorId(orgao));
		
		daoobjetivos.atualiza(obj);
		
		model.addAttribute("objetivos", daoobjetivos.ListaObjetivos());
		
		return "ipst/loads/tabelaobjetivos";
	}
	
	@RequestMapping(value="carregalocais", method = RequestMethod.POST)
	public String carregalocais(@RequestParam("id") Long id, Model model)
	{
		model.addAttribute("locais", daohosp.ListaHospitaisEntidade(id));
		
		return "ipst/loads/divcombolocais";
	}
	
	@RequestMapping(value="pagaobjetivoipst", method = RequestMethod.POST)
	public String pagaobjetivoipst(@RequestParam("id") Long id, Model model)
	{
		Objetivos obj = daoobjetivos.buscaPorId(id);
		
		obj.setPagamento(true);
		obj.setDatapagamento(Calendar.getInstance());
		
		daoobjetivos.atualiza(obj);
		
		model.addAttribute("objetivos", daoobjetivos.buscaPorId(id));
		
		return "ipst/loads/linhaobjetivo";
	}
	
	@RequestMapping(value="criarvaloresnovoano", method = RequestMethod.POST)
	@ResponseBody
	public String criarvaloresnovoano(Model model)
	{
		String res = "";
		
		if(daovalorecolheitas.criavaloresnovos())
		{
			model.addAttribute("valores", daovalorecolheitas.ListaValoresColheitas());
			res = "true";
		}
		else
			res = "false";
		
		return res;
	}
	
	@RequestMapping(value="criarvaloresnovoanoobjetivos", method = RequestMethod.POST)
	@ResponseBody
	public String criarvaloresnovoanoobjetivos(Model model)
	{
		String res = "";
		
		if(daoobjetivos.criavaloresnovos())
		{
			model.addAttribute("objetivos", daoobjetivos.ListaObjetivos());
			res = "true";
		}
		else
			res = "false";
		
		return res;
	}
	
	//------------------------ FIM IPST ------------------------//
	
	//------------------------ ACSS ------------------------//
	
	@RequestMapping(value="guardaobscomp", method = RequestMethod.POST)
	public String guardaobscomp(@RequestParam("obs") String obs, @RequestParam("id") Long id, Model model)
	{
		ACSSDetalheColheita acs = daoacss.buscaPorId(id);
		acs.setNotas(obs);
		
		daoacss.atualiza(acs);
		
		model.addAttribute("detalheacsscomp", daoacss.buscaACSSDetalheAto(id));
		
		return "acss/loads/linhacompromisso";
	}
	
	@RequestMapping(value="criacompromisso", method = RequestMethod.POST)
	public String criacompromisso(@RequestParam("valor") String valor, @RequestParam("compromisso") String compromisso, @RequestParam("data") String data, @RequestParam("entidade") String entidade, @RequestParam("atos") String atos, Model model) throws ParseException
	{
		Compromisso comp = new Compromisso();
		
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
		
		Date d = sdf.parse(data);
		sdf.applyPattern("dd/MM/yyyy");
		data = sdf.format(d);
		
		Calendar calendar1=null;
		  
		Date dateObj = sdf.parse(data);
		calendar1 = Calendar.getInstance();
		calendar1 .setTime(dateObj);
		
		comp.setValor(Double.parseDouble(valor));
		comp.setCompromisso(compromisso);
		comp.setData(calendar1);
		comp.setEntidade(daoentidade.buscaPorNome(entidade));
		
		daocompromisso.adiciona(comp);

		atos = atos.replaceAll("\\s+", "");
		String[] parts = atos.split(",");
		
		int tam = parts.length;
		
		for(int i = 0; i < tam; i++)
		{
			ACSSDetalheColheita acd = daoacss.buscaPorId(Long.parseLong(parts[i]));
			
			acd.setCompromisso(comp);
			daoacss.atualiza(acd);
		}
		
		model.addAttribute("compromissos", daocompromisso.ListaComprimisso());
		
		return "acss/loads/tabelacompromissos";
	}
	
	
	@RequestMapping(value="criacompromissounico", method = RequestMethod.POST)
	public String criacompromissounico(@RequestParam("valor") String valor, @RequestParam("compromisso") String compromisso, @RequestParam("data") String data, @RequestParam("identidade") long identidade, Model model) throws ParseException
	{
		Compromisso comp = new Compromisso();
		
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
		
		Date d = sdf.parse(data);
		sdf.applyPattern("dd/MM/yyyy");
		data = sdf.format(d);
		
		Calendar calendar1=null;
		  
		Date dateObj = sdf.parse(data);
		calendar1 = Calendar.getInstance();
		calendar1 .setTime(dateObj);
		
		comp.setValor(Double.parseDouble(valor));
		comp.setCompromisso(compromisso);
		comp.setData(calendar1);
		comp.setEntidade(daoentidade.buscaPorId(identidade));
		
		daocompromisso.adiciona(comp);
		
		model.addAttribute("compromissos", daocompromisso.ListaComprimisso());
		
		return "acss/loads/tabelacompromissos";
	}
	
	
	@RequestMapping(value="carregaseparadordetalheato", method = RequestMethod.POST)
	public String carregaseparadordetalheato(@RequestParam("id") long id, Model model)
	{
		model.addAttribute("valorgcct", daoacss.buscavalorGCCT(id));
		model.addAttribute("detalheacss", daoacss.buscaACSSDetalheColheita(id));
		
		return "acss/detalheato";
	}
	
	@RequestMapping(value="buscacolheitafiltradaacss", method = RequestMethod.POST)
	public String buscacolheitafiltradaacss(@RequestParam("ano") int ano, @RequestParam("mes") int mes, Model model)
	{
		model.addAttribute("colheitas", daogcctcolheita.buscacolheitafiltradaacss(ano, mes));
		
		return "acss/loads/tabelaatos";
	}
	
	@RequestMapping(value="carregaseparadorcompromissos", method = RequestMethod.POST)
	public String carregaseparadorcompromissos(Model model)
	{
		model.addAttribute("entidades", daoentidade.ListaEntidade());
		model.addAttribute("entidades2", daoentidade.ListaEntidadeCompromissos());
		model.addAttribute("detalheacsscomp", daoacss.buscaACSSDetalheAtos());
		model.addAttribute("compromissos", daocompromisso.ListaComprimisso());
		
		return "acss/divseparadorcompromisso";
	}
	
	@RequestMapping(value="filtraatos", method = RequestMethod.POST)
	public String filtraatos(@RequestParam("nomeentidade") String nomeentidade, Model model)
	{
		
		
		if(!nomeentidade.equals("-- Entidade --"))
			model.addAttribute("detalheacsscomp", daoacss.buscaACSSDetalheAtosporEntidade(nomeentidade));
		else
			model.addAttribute("detalheacsscomp", daoacss.buscaACSSDetalheAtos());
		
		return "acss/loads/tabelacompromissoatos";
	}
	
	@RequestMapping(value="filtraatosnovos", method = RequestMethod.POST)
	public String filtraatosnovos(Model model)
	{
		model.addAttribute("detalheacsscomp", daoacss.buscaACSSDetalheAtos());
		
		return "acss/loads/tabelacompromissoatos";
	}
	
	@RequestMapping(value="carregaseparadorpremios", method = RequestMethod.POST)
	public String carregaseparadorpremios(Model model)
	{
		model.addAttribute("entidades", daoentidade.ListaEntidade());
		model.addAttribute("orgaos", daoorgaooferta.ListaOrgaosOferta());
		model.addAttribute("premios", daopremios.ListaPremios());
		
		return "acss/divseparadorpremios";
	}
	
	@RequestMapping(value="carregaseparadorfaturas", method = RequestMethod.POST)
	public String carregaseparadorfaturas(Model model)
	{
		model.addAttribute("faturas", daofatura.buscaFaturaCompromisso());
		
		return "acss/divseparadorfaturas";
	}
	
	@RequestMapping(value="criafatura", method = RequestMethod.POST)
	public String criafatura(@RequestParam("idcomp") Long idcomp, @RequestParam("numfat") String numfat, @RequestParam("datafat") String datafat, @RequestParam("datapag") String datapag, 
			@RequestParam("prob") boolean prob, @RequestParam("pag") boolean pag, @RequestParam("notas") String notas, Model model) throws ParseException
	{
		Compromisso comp = daocompromisso.buscaPorId(idcomp);
		FaturaACSS fat = new FaturaACSS();

		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
		SimpleDateFormat sdf2 = new SimpleDateFormat("yyyy-MM-dd");
		
		Date d = sdf.parse(datafat);
		sdf.applyPattern("dd/MM/yyyy");
		datafat = sdf.format(d);
		
		Date d2 = sdf2.parse(datapag);
		sdf2.applyPattern("dd/MM/yyyy");
		datapag = sdf2.format(d2);
		
		Calendar calendar1=null;
		Calendar calendar2=null;
		  
		Date dateObj = sdf.parse(datafat);
		calendar1 = Calendar.getInstance();
		calendar1 .setTime(dateObj);
		
		Date dateObj2 = sdf2.parse(datapag);
		calendar2 = Calendar.getInstance();
		calendar2 .setTime(dateObj2);
		
		fat.setFatura(numfat);
		fat.setCompromisso(comp);
		fat.setNotas(notas);
		fat.setPaga(pag);
		fat.setProb(prob);
		fat.setData(calendar1);
		fat.setDatapagamento(calendar2);
		
		daofatura.adiciona(fat);
		
		model.addAttribute("faturas", daofatura.buscaFaturaCompromisso());
		model.addAttribute("idfatura", fat.getIdfatura());
		return "acss/loads/tabelacompfaturas";
	}
	
	@RequestMapping(value="abrefaturas", method = RequestMethod.POST)
	public String abrefaturas(Model model)
	{
		model.addAttribute("faturas", daofatura.buscaFaturaCompromisso());
		
		return "acss/loads/tabelacompfaturas";
	}
	
	@RequestMapping(value="abrefaturasfilt", method = RequestMethod.POST)
	public String abrefaturasfilt(Model model)
	{
		model.addAttribute("faturas", daofatura.buscaFaturaCompromissoSem());
		
		return "acss/loads/tabelacompfaturas";
	}
	
	@RequestMapping(value="editafatura", method = RequestMethod.POST)
	public String editafatura(@RequestParam("numfat") String numfat, @RequestParam("datafat") String datafat, @RequestParam("datapag") String datapag, 
			@RequestParam("prob") boolean prob, @RequestParam("pag") boolean pag, @RequestParam("notas") String notas, @RequestParam("idfat") Long idfat, Model model) throws ParseException
	{
		FaturaACSS fat = daofatura.buscaPorId(idfat);

		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
		SimpleDateFormat sdf2 = new SimpleDateFormat("yyyy-MM-dd");
		
		Date d = sdf.parse(datafat);
		sdf.applyPattern("dd/MM/yyyy");
		datafat = sdf.format(d);
		
		Date d2 = sdf2.parse(datapag);
		sdf2.applyPattern("dd/MM/yyyy");
		datapag = sdf2.format(d2);
		
		Calendar calendar1=null;
		Calendar calendar2=null;
		  
		Date dateObj = sdf.parse(datafat);
		calendar1 = Calendar.getInstance();
		calendar1 .setTime(dateObj);
		
		Date dateObj2 = sdf2.parse(datapag);
		calendar2 = Calendar.getInstance();
		calendar2 .setTime(dateObj2);
		
		fat.setFatura(numfat);
		fat.setNotas(notas);
		fat.setPaga(pag);
		fat.setProb(prob);
		fat.setData(calendar1);
		fat.setDatapagamento(calendar2);
		
		daofatura.atualiza(fat);
		
		model.addAttribute("faturas", daofatura.buscaFaturaCompromisso());
		
		return "acss/loads/tabelacompfaturas";
	}
	
		//---CRIAR PREMIOS---//
	@RequestMapping(value="criarpremio", method = RequestMethod.POST)
	public String criarpremio(@RequestParam("ano") int ano, @RequestParam("identidade") Long identidade, @RequestParam("localinput") Long local, 
			@RequestParam("orgao") int orgaooferta, @RequestParam("valorpremio") float valor, @RequestParam("compromissopremio") String compromisso, 
			@RequestParam("faturapremio") String fatura, @RequestParam("pagamentopremio") String pagamento, 
			@RequestParam("notaspremio") String notas,           
			Model model) throws ParseException{
	
		Premios p = new Premios();
		p.setAno(ano);
		
		Entidade e = new Entidade();
		e.setId_Entidade(identidade);
		p.setEntidade(e);
		Hospital h = new Hospital();
		h.setId_Hospital(local);
		p.setHospital(h);
		OrgaosOferta o = new OrgaosOferta();
		o.setIdorgoferta(orgaooferta);
		p.setOrgao(o);
		p.setValor(valor);
		p.setCompromisso(compromisso);
		p.setFatura(fatura);
		DateFormat dum = new SimpleDateFormat("dd/MM/yyyy");
		
		if(!pagamento.isEmpty() && pagamento != null){
		Date d = dum.parse(pagamento);
		Calendar cal3 = Calendar.getInstance();
		cal3.setTime(d);
		p.setPagamento(cal3);
		}else{
			p.setPagamento(null);
		}
		p.setNotas(notas);
	
		daopremios.adiciona(p);
		
		model.addAttribute("premios", daopremios.ListaPremios());
		
		return "acss/loads/tabelapremios";
	}

	
	@RequestMapping(value="gravapremio", method = RequestMethod.POST)
	public String gravapremio(@RequestParam("id") Long idpremio, @RequestParam("ano") int ano, @RequestParam("identidade") Long identidade, @RequestParam("localinput") Long local, 
			@RequestParam("orgao") int orgaooferta, @RequestParam("valorpremio") float valor, @RequestParam("compromissopremio") String compromisso, 
			@RequestParam("faturapremio") String fatura, @RequestParam("pagamentopremio") String pagamento, @RequestParam("notaspremio") String notas,           
			Model model) throws ParseException{
	
		Premios p = daopremios.buscaPorId(idpremio);
		p.setAno(ano);
		
		Entidade e = new Entidade();
		e.setId_Entidade(identidade);
		p.setEntidade(e);
		Hospital h = new Hospital();
		h.setId_Hospital(local);
		p.setHospital(h);
		OrgaosOferta o = new OrgaosOferta();
		o.setIdorgoferta(orgaooferta);
		p.setOrgao(o);
		p.setValor(valor);
		p.setCompromisso(compromisso);
		p.setFatura(fatura);
		DateFormat dum = new SimpleDateFormat("dd/MM/yyyy");
		
		if(!pagamento.isEmpty() && pagamento != null){
		Date d = dum.parse(pagamento);
		Calendar cal3 = Calendar.getInstance();
		cal3.setTime(d);
		p.setPagamento(cal3);
		}else{
			p.setPagamento(null);
		}
		p.setNotas(notas);
	
		daopremios.atualiza(p);
		
		model.addAttribute("premios", daopremios.ListaPremios());
		
		return "acss/loads/tabelapremios";
	}

	//------------------------ FIM ACSS ------------------------//
}
