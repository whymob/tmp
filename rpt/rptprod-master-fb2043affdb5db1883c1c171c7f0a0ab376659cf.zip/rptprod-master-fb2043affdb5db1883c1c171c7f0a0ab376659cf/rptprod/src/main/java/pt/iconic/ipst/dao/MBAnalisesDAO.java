package pt.iconic.ipst.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import pt.iconic.ipst.modelo.MBAnalises;


@Repository
public class MBAnalisesDAO {

	@PersistenceContext
	private EntityManager manager;
	
	@Transactional
	public void adiciona(MBAnalises mbanalises){
		manager.persist(mbanalises);	
	}
	
	@Transactional
	public void atualiza(MBAnalises mbanalises){
		manager.merge(mbanalises);
	}
	

/*	@SuppressWarnings("unchecked")
	public List<MBAnalises> ListaMBAnalises(){
		return manager.createQuery("select a from MBAnalises a").getResultList();
	}*/
	
	public MBAnalises buscaPorId(Long id){
		return manager.find(MBAnalises.class, id);
	}
	
	
	public void remove(MBAnalises mbanalises){
		MBAnalises mbanalisesARemover = buscaPorId(mbanalises.getId_mbanalises());
		manager.remove(mbanalisesARemover);
		
	}
	
	@SuppressWarnings("unchecked")
	public List<MBAnalises> ListaMBAnalisesAnalise(Long idanalise){
		
		Query query = manager.createQuery("select a from MBAnalises a JOIN a.analiseDador an WHERE an.id_AnaliseDador =:idanalise");
		query.setParameter("idanalise", idanalise);
		List<MBAnalises> results = query.getResultList();

		return results;
	}
}
