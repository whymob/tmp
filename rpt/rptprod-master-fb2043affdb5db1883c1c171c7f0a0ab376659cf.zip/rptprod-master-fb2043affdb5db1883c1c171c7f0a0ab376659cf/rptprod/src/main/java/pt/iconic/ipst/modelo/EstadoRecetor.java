package pt.iconic.ipst.modelo;

import java.util.Calendar;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name = "ESTADORECETOR") //Marca��es
public class EstadoRecetor 
{
	private Long id_estadorecetor;
	private int estado;
	private int tipo; //tipomarca��o - consulta, an�lises, exames
	private Calendar data;
	private String notas;
	private boolean jejum;
	private boolean urina;
	private Utilizador user;
	private AnaliseRecetor analiserecetor;
	private List<MedicamentosPreTransp> medicamentosprettransp;
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "ID_ESTADORECETOR")
	public Long getId_estadorecetor() {
		return id_estadorecetor;
	}
	public void setId_estadorecetor(Long id_estadorecetor) {
		this.id_estadorecetor = id_estadorecetor;
	}
	
	@Column(name = "ESTADO")
	public int getEstado() {
		return estado;
	}
	public void setEstado(int estado) {
		this.estado = estado;
	}
	
	@Column(name = "TIPO")
	public int getTipo() {
		return tipo;
	}
	public void setTipo(int tipo) {
		this.tipo = tipo;
	}
	@Column(name = "DATA")
	public Calendar getData() {
		return data;
	}
	public void setData(Calendar data) {
		this.data = data;
	}
	
	@Column(name = "NOTAS")
	public String getNotas() {
		return notas;
	}
	public void setNotas(String notas) {
		this.notas = notas;
	}
	
	@Column(name = "JEJUM")
	public boolean isJejum() {
		return jejum;
	}
	public void setJejum(boolean jejum) {
		this.jejum = jejum;
	}
	
	@Column(name = "URINA")
	public boolean isUrina() {
		return urina;
	}
	public void setUrina(boolean urina) {
		this.urina = urina;
	}
	
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name="ID_ANALISERECETOR")
	public AnaliseRecetor getAnaliserecetor() {
		return analiserecetor;
	}
	public void setAnaliserecetor(AnaliseRecetor analiserecetor) {
		this.analiserecetor = analiserecetor;
	}
	
	@OneToMany(fetch = FetchType.LAZY, mappedBy = "marcacao", orphanRemoval= true)
	public List<MedicamentosPreTransp> getMedicamentosprettransp() {
		return medicamentosprettransp;
	}
	public void setMedicamentosprettransp(List<MedicamentosPreTransp> medicamentosprettransp) {
		this.medicamentosprettransp = medicamentosprettransp;
	}
	
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name="ID_UTILIZADOR")
	public Utilizador getUser() {
		return user;
	}
	public void setUser(Utilizador user) {
		this.user = user;
	}
}