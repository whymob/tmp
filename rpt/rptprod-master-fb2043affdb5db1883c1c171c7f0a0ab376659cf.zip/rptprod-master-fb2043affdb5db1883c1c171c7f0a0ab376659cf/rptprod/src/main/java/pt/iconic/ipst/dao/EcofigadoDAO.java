package pt.iconic.ipst.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import pt.iconic.ipst.modelo.EcoAbdFigado;

@Repository
@Transactional
public class EcofigadoDAO 
{
	@PersistenceContext
	private EntityManager manager;
	
	public void adiciona(EcoAbdFigado eco){
		manager.persist(eco);	
	}

	public void atualiza(EcoAbdFigado eco){
		manager.merge(eco);
	}

/*	public EcoAbdFigado buscaPorId(Long id){
		return manager.find(EcoAbdFigado.class, id);
	}
	
	public void remove(EcoAbdFigado eco){
		EcoAbdFigado ecofigado = buscaPorId(eco.getId_Ecoabdfigado());
		manager.remove(ecofigado);
	}*/
	

	@SuppressWarnings("rawtypes")
	public EcoAbdFigado ListaEcoAbdFigado(Long id)
	{
		Query query = manager.createQuery("select e from EcoAbdFigado e JOIN e.analiseDador analisedador WHERE analisedador.id_AnaliseDador =:idanalise");
		query.setParameter("idanalise", id);

		List results = query.getResultList();
		EcoAbdFigado ecof = null;
		
		if(!results.isEmpty())
		{
			ecof = (EcoAbdFigado) results.get(0);
		}
		
		return ecof;
	}
	

/*	@SuppressWarnings("rawtypes")
	public DadosAbdFigado ListaEcoAbdFigadoDetalhe(Long id)
	{
		Query query = manager.createQuery("select e from DadosAbdFigado e ");
		//query.setParameter("ideco", id);

		List results = query.getResultList();
		DadosAbdFigado eco = null;
		
		if(!results.isEmpty())
		{
			eco = (DadosAbdFigado) results.get(0);
		}
		
		return eco;
	}*/
}