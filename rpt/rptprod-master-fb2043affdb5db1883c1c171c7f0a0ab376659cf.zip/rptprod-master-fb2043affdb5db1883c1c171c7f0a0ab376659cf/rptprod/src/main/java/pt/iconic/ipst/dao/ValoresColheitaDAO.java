package pt.iconic.ipst.dao;

import java.util.Calendar;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import pt.iconic.ipst.modelo.ValoresColheitas;

@Repository
@Transactional
public class ValoresColheitaDAO 
{
	@PersistenceContext
	private EntityManager manager;
	
	public void adiciona(ValoresColheitas valc){
		manager.persist(valc);	
	}
	
	@Transactional
	public void atualiza(ValoresColheitas valc){
		manager.merge(valc);
	}
	
	@SuppressWarnings("unchecked")
	public List<ValoresColheitas> ListaValoresColheitas(){
		return manager.createQuery("select p from ValoresColheitas p ORDER BY p.ano DESC").getResultList();
	}
	
	public ValoresColheitas buscaPorId(Long id){
		return manager.find(ValoresColheitas.class, id);
	}
	
/*	public void remove(ValoresColheitas valc){
		ValoresColheitas valcrem = buscaPorId(valc.getIdvalorcolheita());
		manager.remove(valcrem);
	}*/
	
	public int buscaultimoano()
	{
		Query query = manager.createNativeQuery("select MAX(VALORESCOLHEITAS.ANO) from VALORESCOLHEITAS");
		Calendar cal = Calendar.getInstance();
		
		int recente = cal.get(Calendar.YEAR);
		
		if(!(query.getResultList().get(0)==null)){
			recente = (int) query.getResultList().get(0);
		}
		
		return recente;
	}
	
	@Transactional
	public boolean criavaloresnovos()
	{
		Calendar cal = Calendar.getInstance();
		int anoatual = cal.get(Calendar.YEAR);
		
		Query query = manager.createNativeQuery("select MAX(VALORESCOLHEITAS.ANO) from VALORESCOLHEITAS");
		int recente = (int) query.getResultList().get(0);

		if((recente-anoatual) >= 1)
			return false;
		else
		{
			Query query2 = manager.createNativeQuery("insert into VALORESCOLHEITAS (ANO, ATO, OBSERVACOES, SUPLEMENTAR, TIPO, VALOR)(Select v.ANO+1 as ANO, v.ATO, v.OBSERVACOES, "
					+ "v.SUPLEMENTAR, v.TIPO, v.VALOR  from VALORESCOLHEITAS v where v.ANO= (Select MAX(ANO) from VALORESCOLHEITAS va));");
			query2.executeUpdate();
			
			return true;
		}
	}
}
