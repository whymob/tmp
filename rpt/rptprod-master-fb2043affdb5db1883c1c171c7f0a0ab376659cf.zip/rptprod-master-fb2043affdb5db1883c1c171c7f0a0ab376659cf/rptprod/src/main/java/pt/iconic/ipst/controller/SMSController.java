package pt.iconic.ipst.controller;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

import org.springframework.stereotype.Controller;

@Controller
public class SMSController {

	
	public void sms(String contacto, String pin, int user) {
		
/*		System.out.println("Controlador SMS, user: "+user);
		System.out.println("Contato: "+contacto);
		System.out.println("PIN: "+pin);*/
		
 /*       Connection conn = null;

        Statement stmt = null;
        try { 

            String dbURL2 = "jdbc:oracle:thin:@213.58.198.107:1521:IPS";
            String username = "whymob";
            String password = "why1062";
            conn = DriverManager.getConnection(dbURL2, username, password);
            if (conn != null) {
                
                stmt = conn.createStatement();
                
//                Destination � n� telem�vel 9 posi��es
//                Message � at� 160 caracteres
//                Status � 0
//                Priority � 9
//                Field1
//                Field2
//                Origin � IPST
//                Messagedate � data atual
                
                if(user == 1){ //profissional
                	String sql = "INSERT INTO OUTBOUND (DESTINATION, MESSAGE, STATUS, PRIORITY, ORIGIN, MESSAGEDATE) " +
                			"VALUES ('"+contacto+"', 'Foi criado um utilizador no RPT com este contacto. Verifique o seu email com os passos a seguir e quando requisitado insira o PIN "+pin+". Obrigado. IPST.', 0, 1, 'IPS', sysdate)";
                	stmt.executeUpdate(sql);
                }else { // candidato
                	String sql = "INSERT INTO OUTBOUND (DESTINATION, MESSAGE, STATUS, PRIORITY, ORIGIN, MESSAGEDATE) " +
                            "VALUES ('"+contacto+"', 'Foi criado um utilizador no RPT com este contacto. Para utilizar a app do RPT utilize como cred�ncias de acesso iniciais o Login: "+contacto+" e PIN: "+pin+". Obrigado. IPST.', 0, 1, 'IPS', sysdate)";             	
                    stmt.executeUpdate(sql);
                  //  System.out.println("Envio sms candidato");
                } 
              
            }
 

        } catch (ClassNotFoundException ex) {
            ex.printStackTrace();
        } catch (SQLException ex) {
            ex.printStackTrace();
        } finally {
        	try{
                if(stmt!=null)
                   conn.close();
             }catch(SQLException se){
             }
            try {

                if (conn != null && !conn.isClosed()) {
                    conn.close();
                }
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
        }*/
		
	}
}
