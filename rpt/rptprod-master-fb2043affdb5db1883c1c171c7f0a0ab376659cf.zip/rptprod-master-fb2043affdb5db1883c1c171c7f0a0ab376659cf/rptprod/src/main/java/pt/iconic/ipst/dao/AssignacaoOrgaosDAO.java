package pt.iconic.ipst.dao;


import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import pt.iconic.ipst.modelo.AssignacaoOrgaos;

@Repository
@Transactional
public class AssignacaoOrgaosDAO {

	
	@PersistenceContext
	private EntityManager manager;
	
	
	public void adiciona(AssignacaoOrgaos assignacao){
		manager.persist(assignacao);	
	}
	
	public void atualiza(AssignacaoOrgaos assignacao){
		manager.merge(assignacao);
	}
	

/*	@SuppressWarnings("unchecked")
	public List<AssignacaoOrgaos> ListaAssignacaoOrgaos(){
		return manager.createQuery("select a from AssignacaoOrgaos a").getResultList();
	}*/
	
	public AssignacaoOrgaos buscaPorId(Long id){
		return manager.find(AssignacaoOrgaos.class, id);
	}
	
	
/*	public void remove(AssignacaoOrgaos assignacao){
		AssignacaoOrgaos assARemover = buscaPorId(assignacao.getId_assignacao());
		manager.remove(assARemover);
	}*/

	@SuppressWarnings("unchecked")
	public List<AssignacaoOrgaos> ListaAssignacaoOrgaosDador(Long iddador) {
		Query query = manager.createQuery("select a from AssignacaoOrgaos a join a.dadoroferta d where d.id_Dador =:iddador");
		query.setParameter("iddador", iddador);
		
		return query.getResultList();
	}
	
	@SuppressWarnings({ "unchecked" })
	public List<Object>  ListaAssignacaoOrgaosDadorAtrib(Long iddador) {
/*		Query query = manager.createQuery("select a from AssignacaoOrgaos a join a.dadoroferta d where d.id_Dador =:iddador");
		query.setParameter("iddador", iddador);*/
		List<Object> out = null;

		/* 1- verde
		2- laranja
		3- vermelho
		0- cinzento*/
		Query query = manager.createNativeQuery("select ao.ID_ASSIGNACAO_ORGAOS, ao.ID_ORGAOOFERTA, orgof.NOME_ORGAO, ao.ID_DADOR, ao.ID_STATUS, "
				+ "(select case when exists (select a.ID_ESTADO from ASSIGNACAO_HOSPITAL a inner join ESTADO_ASSIGNACAO_HOSPITAL e on (e.ID_ESTADO = a.ID_ESTADO ) "
				+ "inner join ASSIGNACAO_ORGAOS o on (o.ID_ASSIGNACAO_ORGAOS = a.ID_ASSIGNACAO_ORGAO) "
				+ "where o.ID_DADOR = :iddador and a.ID_ESTADO=3 and o.ID_ASSIGNACAO_ORGAOS = ao.ID_ASSIGNACAO_ORGAOS) "
				+ "then '1' "
				+ "when exists (select a.ID_ESTADO from ASSIGNACAO_HOSPITAL a inner join ESTADO_ASSIGNACAO_HOSPITAL e on (e.ID_ESTADO = a.ID_ESTADO ) "
				+ "inner join ASSIGNACAO_ORGAOS o on (o.ID_ASSIGNACAO_ORGAOS = a.ID_ASSIGNACAO_ORGAO) "
				+ "where o.ID_DADOR = :iddador and a.ID_ESTADO=1 and o.ID_ASSIGNACAO_ORGAOS = ao.ID_ASSIGNACAO_ORGAOS "
				+ "OR (o.ID_DADOR = :iddador and a.ID_ESTADO=4 and o.ID_ASSIGNACAO_ORGAOS = ao.ID_ASSIGNACAO_ORGAOS)) "
				+ "then '2' "
				+ "when exists (select a.ID_ESTADO from ASSIGNACAO_HOSPITAL a inner join ESTADO_ASSIGNACAO_HOSPITAL e on (e.ID_ESTADO = a.ID_ESTADO ) "
				+ "inner join ASSIGNACAO_ORGAOS o on (o.ID_ASSIGNACAO_ORGAOS = a.ID_ASSIGNACAO_ORGAO) "
				+ "where (o.ID_DADOR = :iddador and a.ID_ESTADO=6 and o.ID_ASSIGNACAO_ORGAOS = ao.ID_ASSIGNACAO_ORGAOS) "
				+ "OR(o.ID_DADOR = :iddador and a.ID_ESTADO=5 and o.ID_ASSIGNACAO_ORGAOS = ao.ID_ASSIGNACAO_ORGAOS) "
				+ "OR (o.ID_DADOR = :iddador and a.ID_ESTADO=2 and o.ID_ASSIGNACAO_ORGAOS = ao.ID_ASSIGNACAO_ORGAOS) "
				+ "OR (o.ID_DADOR = :iddador and a.ID_ESTADO=7 and o.ID_ASSIGNACAO_ORGAOS = ao.ID_ASSIGNACAO_ORGAOS) ) "
				+ "then '3' "
				+ "else '0' "
				+ "end) as Semaforo, "
				+ "(select COUNT(*) from ASSIGNACAO_HOSPITAL h "
				+ "inner join ASSIGNACAO_ORGAOS aorg on (h.ID_ASSIGNACAO_ORGAO = aorg.ID_ASSIGNACAO_ORGAOS) "
				+ "where aorg.ID_ASSIGNACAO_ORGAOS = ao.ID_ASSIGNACAO_ORGAOS and h.SELECCIONADO <>0) as Algum "
				+ "from ASSIGNACAO_ORGAOS ao "
				+ "inner join STATUS_ASSIGNACAO_ORGAOS so on (so.ID_STATUS = ao.ID_STATUS) "
				+ "inner join ORGAOS_OFERTA orgof on (orgof.ID_ORGAO_OFERTA=ao.ID_ORGAOOFERTA) "
				+ "where ao.ID_DADOR = :iddador");
		query.setParameter("iddador", iddador);
		
		out = query.getResultList();
		
/*        int count = 0;  
        for (Iterator i = out.iterator(); i.hasNext();) {  
            Object[] values = (Object[]) i.next();  
            System.out.println(++count + ": " + values[0] + ", " + values[1] + ", " + values[2] + ", " + values[3] +  ", " + values[4] +"<br />");  

        } */
		
/*        int count = 0;  
        for (Iterator i = out.iterator(); i.hasNext();) {  
        	AssignacaoOrgaos values = (AssignacaoOrgaos) i.next();  
            System.out.println(++count + ": " + values.getDadoroferta().getId_Dador() + ", " + values.getOrgoferta().getIdorgoferta() + ", " + values.getStatusassignacao().getIdstatus() + "<br />");  
        } */
		return out;
	}
	
	@SuppressWarnings("rawtypes")
	public AssignacaoOrgaos buscaassignacaoorgaodador(Long iddador, int idorg) {
		Query query = manager.createQuery("select a from AssignacaoOrgaos a join a.dadoroferta d JOIN a.orgoferta o where d.id_Dador =:iddador AND o.idorgoferta =:idorg");
		query.setParameter("iddador", iddador);
		query.setParameter("idorg", idorg);
		
  		List results = query.getResultList();
  		AssignacaoOrgaos assig = null;
		if(!results.isEmpty()){
		    // ignores multiple results
			assig = (AssignacaoOrgaos) results.get(0);
		}
		return assig;
	}

	@SuppressWarnings({ "unchecked" })
	public List<String> ListaOrgaosAssignadosDador(Long id_Dador) {
		List<String> out = null;
	//	Query query = manager.createQuery("select a from AssignacaoOrgaos a join a.dadoroferta d join a.orgoferta org where d.id_Dador =:iddador");
		Query query = manager.createQuery("select org.nomeorgaooferta from OrgaosOferta org join org.assignacao a join a.dadoroferta d where d.id_Dador =:iddador", String.class);
		query.setParameter("iddador", id_Dador);
		
	       out = query.getResultList();
		/*int count = 0;  
        for (Iterator i = out.iterator(); i.hasNext();) {  
        	 String values = (String) i.next();  
            System.out.println(++count + ": " + values +  "<br />");  
        } */
 
		return out;
		
	}

}
