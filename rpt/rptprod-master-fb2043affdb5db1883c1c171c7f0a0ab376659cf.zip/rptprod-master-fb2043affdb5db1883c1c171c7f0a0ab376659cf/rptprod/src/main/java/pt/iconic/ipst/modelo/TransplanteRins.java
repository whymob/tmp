package pt.iconic.ipst.modelo;

import java.util.Calendar;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name = "TRANSPLANTE_RINS")
public class TransplanteRins {

	
	private Long idtransplanterins;
	private Calendar inicio;
	private Calendar clampvenosa;
	private Calendar retirargelo;
	private Calendar desclampvenosa;
	private Calendar clamparterial;
	private Calendar desclamparterial;
	private Calendar tempourologinicio;
	private Calendar tempourologfim;
	private Calendar fim;
	private String isqfria;
	private String isqquente;
	private String isqtotal;
	private String clampdescVenosa;
	private String clampdescArterial;
	private String tempourologico;
	private int transprins;
	private int anastarterial;
	private int localizacao;
	private int transpmulti;
	private int anastvenosa;
	private int anastureter;
	private int reclampart;
	private int reclampven;
	private String relatoperat;
	private int complicacoes;
	private int estado;
	private AssignacaoOrgaos assigorgao;
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="ID_TRANSP_RINS")
	public Long getIdtransplanterins() {
		return idtransplanterins;
	}
	public void setIdtransplanterins(Long idtransplanterins) {
		this.idtransplanterins = idtransplanterins;
	}
	
	@Column(name="INICIO")
	public Calendar getInicio() {
		return inicio;
	}
	public void setInicio(Calendar inicio) {
		this.inicio = inicio;
	}
	
	@Column(name="CLAMP_VENOSA")
	public Calendar getClampvenosa() {
		return clampvenosa;
	}
	public void setClampvenosa(Calendar clampvenosa) {
		this.clampvenosa = clampvenosa;
	}
	
	@Column(name="RETIRAR_GELO")
	public Calendar getRetirargelo() {
		return retirargelo;
	}
	public void setRetirargelo(Calendar retirargelo) {
		this.retirargelo = retirargelo;
	}
	
	@Column(name="DESCLAMP_VENOSA")
	public Calendar getDesclampvenosa() {
		return desclampvenosa;
	}
	public void setDesclampvenosa(Calendar desclampvenosa) {
		this.desclampvenosa = desclampvenosa;
	}
	
	@Column(name="CLAMP_ARTERIAL")
	public Calendar getClamparterial() {
		return clamparterial;
	}
	public void setClamparterial(Calendar clamparterial) {
		this.clamparterial = clamparterial;
	}
	
	@Column(name="DESCLAMP_ARTERIAL")
	public Calendar getDesclamparterial() {
		return desclamparterial;
	}
	public void setDesclamparterial(Calendar desclamparterial) {
		this.desclamparterial = desclamparterial;
	}
	
	@Column(name="TEMPO_UROLOG_INICIO")
	public Calendar getTempourologinicio() {
		return tempourologinicio;
	}
	public void setTempourologinicio(Calendar tempourologinicio) {
		this.tempourologinicio = tempourologinicio;
	}
	
	@Column(name="TEMPO_UROLOG_FIM")
	public Calendar getTempourologfim() {
		return tempourologfim;
	}
	public void setTempourologfim(Calendar tempourologfim) {
		this.tempourologfim = tempourologfim;
	}
	
	@Column(name="FIM")
	public Calendar getFim() {
		return fim;
	}
	public void setFim(Calendar fim) {
		this.fim = fim;
	}
	
	@Column(name="ISQUEMIA_FRIA")
	public String getIsqfria() {
		return isqfria;
	}
	public void setIsqfria(String isqfria) {
		this.isqfria = isqfria;
	}
	
	@Column(name="ISQUEMIA_QUENTE")
	public String getIsqquente() {
		return isqquente;
	}
	public void setIsqquente(String isqquente) {
		this.isqquente = isqquente;
	}
	
	@Column(name="ISQUEMIA_TOTAL")
	public String getIsqtotal() {
		return isqtotal;
	}
	public void setIsqtotal(String isqtotal) {
		this.isqtotal = isqtotal;
	}
	@Column(name="CLAMP_DESC_VENOSA")
	public String getClampdescVenosa() {
		return clampdescVenosa;
	}
	public void setClampdescVenosa(String clampdescVenosa) {
		this.clampdescVenosa = clampdescVenosa;
	}
	
	@Column(name="CLAMP_DESC_ARTERIAL")
	public String getClampdescArterial() {
		return clampdescArterial;
	}
	public void setClampdescArterial(String clampdescArterial) {
		this.clampdescArterial = clampdescArterial;
	}
	
	@Column(name="TEMPO_UROLOGICO")
	public String getTempourologico() {
		return tempourologico;
	}
	public void setTempourologico(String tempourologico) {
		this.tempourologico = tempourologico;
	}
	@Column(name="TRANSPS_RINS")
	public int getTransprins() {
		return transprins;
	}
	public void setTransprins(int transprins) {
		this.transprins = transprins;
	}
	
	@Column(name="ANASTOMOSE_ARTERIAL")
	public int getAnastarterial() {
		return anastarterial;
	}
	public void setAnastarterial(int anastarterial) {
		this.anastarterial = anastarterial;
	}
	
	@Column(name="LOCALIZACAO")
	public int getLocalizacao() {
		return localizacao;
	}
	public void setLocalizacao(int localizacao) {
		this.localizacao = localizacao;
	}
	
	@Column(name="TRANSP_MULTI")
	public int getTranspmulti() {
		return transpmulti;
	}
	public void setTranspmulti(int transpmulti) {
		this.transpmulti = transpmulti;
	}
	
	@Column(name="ANAST_VENOSA")
	public int getAnastvenosa() {
		return anastvenosa;
	}
	public void setAnastvenosa(int anastvenosa) {
		this.anastvenosa = anastvenosa;
	}
	
	@Column(name="ANAST_URETER")
	public int getAnastureter() {
		return anastureter;
	}
	public void setAnastureter(int anastureter) {
		this.anastureter = anastureter;
	}
	
	@Column(name="RECLAMP_ART")
	public int getReclampart() {
		return reclampart;
	}
	public void setReclampart(int reclampart) {
		this.reclampart = reclampart;
	}
	
	@Column(name="RECLAMP_VEN")
	public int getReclampven() {
		return reclampven;
	}
	public void setReclampven(int reclampven) {
		this.reclampven = reclampven;
	}
	@Column(name="RELATO_OPERATORIO")
	public String getRelatoperat() {
		return relatoperat;
	}
	public void setRelatoperat(String relatoperat) {
		this.relatoperat = relatoperat;
	}
	
	@Column(name="COMPLICACOES")
	public int getComplicacoes() {
		return complicacoes;
	}
	public void setComplicacoes(int complicacoes) {
		this.complicacoes = complicacoes;
	}
	
	@Column(name="ESTADO")
	public int getEstado() {
		return estado;
	}
	public void setEstado(int estado) {
		this.estado = estado;
	}
	
	@OneToOne(fetch=FetchType.EAGER)
	@JoinColumn(name="ID_ASSIGNACAO_ORGAOS")
	public AssignacaoOrgaos getAssigorgao() {
		return assigorgao;
	}
	public void setAssigorgao(AssignacaoOrgaos assigorgao) {
		this.assigorgao = assigorgao;
	}
	
}
