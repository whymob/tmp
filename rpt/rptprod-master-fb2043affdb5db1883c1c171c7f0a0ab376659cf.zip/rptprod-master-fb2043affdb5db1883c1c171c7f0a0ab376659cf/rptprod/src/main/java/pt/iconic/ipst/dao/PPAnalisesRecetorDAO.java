package pt.iconic.ipst.dao;

import java.util.Calendar;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import pt.iconic.ipst.modelo.AmostrasFO;
import pt.iconic.ipst.modelo.AnaliseRecetor;
import pt.iconic.ipst.modelo.PPAnalisesRecetor;

@Repository
@Transactional
public class PPAnalisesRecetorDAO 
{
	@PersistenceContext
	private EntityManager manager;
	

/*	public void adiciona(PPAnalisesRecetor anali){
		manager.persist(anali);	
	}*/
	

	public void atualiza(PPAnalisesRecetor anali){
		manager.merge(anali);
	}

/*	@SuppressWarnings("unchecked")
	public List<PPAnalisesRecetor> ListaGravidade(){
		return manager.createQuery("select d from PPAnalisesRecetor d").getResultList();
	}*/
	
	public PPAnalisesRecetor buscaPorId(Long id){
		return manager.find(PPAnalisesRecetor.class, id);
	}
	
/*	public void remove(PPAnalisesRecetor anali){
		PPAnalisesRecetor analirem = buscaPorId(anali.getId_analiserecetor());
		manager.remove(analirem);
	}*/
	
/*	@SuppressWarnings("unchecked")
	public List<PPAnalisesRecetor> buscaanaliserecetor(Long analiserecetor)
	{		
		Query query = manager.createQuery("select a from PPAnalisesRecetor a JOIN a.analiserecetor grav WHERE grav.id_analiserecetor =:analiserecetor");
		query.setParameter("analiserecetor", analiserecetor);
		
		List<PPAnalisesRecetor> results = query.getResultList();

		return results;
	}*/

	//adiciona as 40 amostras � tabela
	@SuppressWarnings("unchecked")
	public boolean adicionaitensamostras(Calendar data, Long id_analiserec){
	//	public boolean adicionaitensamostras(Long amostra, Calendar data, Long id_analiserec){
		
		Query nomesamostras = manager.createQuery("select a from AmostrasFO a");
		
		List<AmostrasFO> amostras = nomesamostras.getResultList();
		
		AnaliseRecetor analiserec = manager.find(AnaliseRecetor.class, id_analiserec);
		
		

		for (int i=0; i<amostras.size(); i++){
		//	AmostrasFuncoesOrgao amostrafo = new AmostrasFuncoesOrgao();
			PPAnalisesRecetor analises = new PPAnalisesRecetor();
			analises.setAnaliserecetor(analiserec);
		//	System.out.println("amostraaaaaa: "+amostras.get(i));
			analises.setAmostra(amostras.get(i));
			analises.setDatahora(data);
		//	analises.setTipoAmostra(manager.find(TipoAmostraFO.class, amostra));
			manager.persist(analises);
		}
		
		return true;
	}


	//carrega as amostras quando insere as 40 para que as da ultima amostra apare�am em cima
	@SuppressWarnings("unchecked")
	public List<PPAnalisesRecetor> buscaamostrasanaliseDescendente(Long idanaliserec){
		
		Query query = manager.createQuery("select a from PPAnalisesRecetor a JOIN a.analiserecetor an LEFT JOIN a.amostra amostrafo WHERE an.id_analiserecetor =:idanalise  ORDER BY a.datahora DESC");
		query.setParameter("idanalise", idanaliserec);
		
		List<PPAnalisesRecetor> results = query.getResultList();

		return results;
	}
}