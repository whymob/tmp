package pt.iconic.ipst.modelo;


import java.util.Calendar;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name = "MICROBIOLOGIA")
public class Microbiologia {

	private Long Id_Microbiologia;
	private AnaliseDador analiseDador;
	private boolean gramposneg;
	private boolean statusharmmicrobio;
	private Calendar datagravacao;
//	private List<MBAnalises> MicrobioAnalises;
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="ID_MICROBIOLOGIA")
	public Long getId_Microbiologia() {
		return Id_Microbiologia;
	}
	public void setId_Microbiologia(Long id_Microbiologia) {
		Id_Microbiologia = id_Microbiologia;
	}
	
	@OneToOne
	@JoinColumn(name="ID_ANALISEDADOR")
	public AnaliseDador getAnaliseDador() {
		return analiseDador;
	}
	public void setAnaliseDador(AnaliseDador analiseDador) {
		this.analiseDador = analiseDador;
	}

	@Column(name="GRAMPOSNEG")
	public boolean isGramposneg() {
		return gramposneg;
	}

	public void setGramposneg(boolean gramposneg) {
		this.gramposneg = gramposneg;
	}
	
	@Column(name="STATUSHARMONIO")	
	public boolean isStatusharmmicrobio() {
		return statusharmmicrobio;
	}
	public void setStatusharmmicrobio(boolean statusharmmicrobio) {
		this.statusharmmicrobio = statusharmmicrobio;
	}
	
	@Column(name="DATAGRAVACAO")
	public Calendar getDatagravacao() {
		return datagravacao;
	}


	public void setDatagravacao(Calendar datagravacao) {
		this.datagravacao = datagravacao;
	}

/*    @OneToMany(fetch = FetchType.LAZY, mappedBy = "microbiologia")
	public List<MBAnalises> getMicrobioAnalises() {
		return MicrobioAnalises;
	}

	public void setMicrobioAnalises(List<MBAnalises> microbioAnalises) {
		MicrobioAnalises = microbioAnalises;
	}*/
	
	
}
