package pt.iconic.ipst.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import pt.iconic.ipst.modelo.TipoMBAnalise;

@Repository
@Transactional
public class TipoMBAnaliseDAO {

	@PersistenceContext
	private EntityManager manager;
	
	
	public void adiciona(TipoMBAnalise tipombanalise){
		manager.persist(tipombanalise);	
	}
	

	public void atualiza(TipoMBAnalise tipombanalise){
		manager.merge(tipombanalise);
	}
	
	@SuppressWarnings("unchecked")
	public List<TipoMBAnalise> ListaTipoMBAnalise(){
		return manager.createQuery("select a from TipoMBAnalise a").getResultList();
	}
	
	public TipoMBAnalise buscaPorId(Long id){
		return manager.find(TipoMBAnalise.class, id);
	}
	
	
	public void remove(TipoMBAnalise tipombanalise){
		TipoMBAnalise tipombanaliseARemover = buscaPorId(tipombanalise.getId_tipombanalise());
		manager.remove(tipombanaliseARemover);
		
	}
	
	public boolean trataadicionar(String desc)
	{
		Query query = manager.createQuery("SELECT e FROM TipoMBAnalise e WHERE e.descricaomb =:desc");
		query.setParameter("desc", desc);
		
		if(query.getResultList().isEmpty())
		{
			TipoMBAnalise tmb = new TipoMBAnalise();
			tmb.setDescricaomb(desc);
			adiciona(tmb);
			
			return true;
		}
		else
		{
			return false;
		}
	}
	
	public boolean trataalterar(Long id, String desc)
	{
		Query query = manager.createQuery("SELECT e FROM TipoMBAnalise e WHERE e.descricaomb =:desc");
		query.setParameter("desc", desc);
		
		if(query.getResultList().isEmpty())
		{
			TipoMBAnalise tmb = new TipoMBAnalise();
			tmb.setDescricaomb(desc);
			tmb.setId_tipombanalise(id);
			atualiza(tmb);
				
			return true;
		}
		else
		{
			return false;
		}
	}
	
	public boolean remover(Long id) 
	{
		TipoMBAnalise tmb = new TipoMBAnalise();
		tmb = buscaPorId(id);

		remove(tmb);
		return true;
	}
		
}
