package pt.iconic.ipst.modelo;

import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name = "ESTADO_ASSIGNACAO_HOSPITAL")
public class StatusAssignacaoHospital {

	private int idestado;
	private String estado;
	private List<AssignacaoHospital> assighosp;
	private List<HistoricoAssignacao> historico;
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="ID_ESTADO")
	public int getIdestado() {
		return idestado;
	}
	public void setIdestado(int idestado) {
		this.idestado = idestado;
	}
	
	@Column(name="ESTADO")
	public String getEstado() {
		return estado;
	}
	public void setEstado(String estado) {
		this.estado = estado;
	}
	
	@OneToMany(fetch = FetchType.LAZY, mappedBy = "estadoassighosp")
	public List<AssignacaoHospital> getAssighosp() {
		return assighosp;
	}
	public void setAssighosp(List<AssignacaoHospital> assighosp) {
		this.assighosp = assighosp;
	}
	
	@OneToMany(fetch = FetchType.LAZY, mappedBy = "estadoassig")
	public List<HistoricoAssignacao> getHistorico() {
		return historico;
	}
	public void setHistorico(List<HistoricoAssignacao> historico) {
		this.historico = historico;
	}
	
	
	
}
