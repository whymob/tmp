package pt.iconic.ipst.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import pt.iconic.ipst.modelo.MorteCerebral;



@Repository
public class MorteCerebralDAO {

	
	@PersistenceContext
	private EntityManager manager;
	
	
	public void adiciona(MorteCerebral mc){
		manager.persist(mc);	
	}
	
	@Transactional
	public void atualiza(MorteCerebral mc){
		manager.merge(mc);
	}
	

/*	@SuppressWarnings("unchecked")
	public List<MorteCerebral> ListaMorteCerebral(){
		return manager.createQuery("select m from MorteCerebral m").getResultList();
	}*/
	
	public MorteCerebral buscaPorId(Long id){
		return manager.find(MorteCerebral.class, id);
	}
	
	
/*	public void remove(MorteCerebral mc){
		MorteCerebral mcARemover = buscaPorId(mc.getId_MorteCerebral());
		manager.remove(mcARemover);
		
	}*/

	@SuppressWarnings("unchecked")
	public MorteCerebral buscaMorteCerebralAvaliacao(Long idanalise) {
		
		Query query = manager.createQuery("select b from MorteCerebral b JOIN b.analiseDador a WHERE a.id_AnaliseDador =:idanalise");
		query.setParameter("idanalise", idanalise);
		
		List<MorteCerebral> results = query.getResultList();
		MorteCerebral mc = null;
		if(!results.isEmpty()){
			mc = (MorteCerebral) results.get(0);
		}
			
		return mc;
	}
}
