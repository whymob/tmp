package pt.iconic.ipst.modelo;

import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;

@Entity
@Table(name = "GCCT")
public class GCCT {

	private Long Id_GCCT;
	private String NomeGCCT;
	private List<Hospital> Hospitais;
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="ID_GCCT")
	public Long getId_GCCT() {
		return Id_GCCT;
	}
	public void setId_GCCT(Long id_GCCT) {
		Id_GCCT = id_GCCT;
	}
	
	@NotNull
	@Column(name="NOMEGCCT")
	public String getNomeGCCT() {
		return NomeGCCT;
	}
	public void setNomeGCCT(String nomeGCCT) {
		NomeGCCT = nomeGCCT;
	}
	
    @OneToMany(fetch = FetchType.LAZY, mappedBy = "gcct")	
	public List<Hospital> getHospitais() {
		return Hospitais;
	}
	public void setHospitais(List<Hospital> hospitais) {
		Hospitais = hospitais;
	}
	
	
}
