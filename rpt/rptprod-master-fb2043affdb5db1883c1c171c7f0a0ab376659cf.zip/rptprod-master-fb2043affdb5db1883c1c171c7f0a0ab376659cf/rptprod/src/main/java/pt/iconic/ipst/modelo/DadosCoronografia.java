package pt.iconic.ipst.modelo;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name = "DADOSCORONOGRAFIA")
public class DadosCoronografia 
{
	private Long Id_DadosCoronografia;
	private String Arteria;
	private String Estenose;
	private String Severidade;
	private AnaliseDador analiseDador;
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="ID_DADOSCORONOGRAFIA")
	public Long getId_DadosCoronografia() {
		return Id_DadosCoronografia;
	}
	public void setId_DadosCoronografia(Long id_DadosCoronografia) {
		Id_DadosCoronografia = id_DadosCoronografia;
	}
	
	@Column(name="ARTERIA")
	public String getArteria() {
		return Arteria;
	}
	public void setArteria(String arteria) {
		Arteria = arteria;
	}
	
	@Column(name="ESTENOSE")
	public String getEstenose() {
		return Estenose;
	}
	public void setEstenose(String estenose) {
		Estenose = estenose;
	}
	
	@Column(name="SEVERIDADE")
	public String getSeveridade() {
		return Severidade;
	}
	public void setSeveridade(String severidade) {
		Severidade = severidade;
	}
	
	@ManyToOne
	@JoinColumn(name="ID_ANALISEDADOR")
	public AnaliseDador getAnaliseDador() {
		return analiseDador;
	}
	public void setAnaliseDador(AnaliseDador analiseDador) {
		this.analiseDador = analiseDador;
	}
}