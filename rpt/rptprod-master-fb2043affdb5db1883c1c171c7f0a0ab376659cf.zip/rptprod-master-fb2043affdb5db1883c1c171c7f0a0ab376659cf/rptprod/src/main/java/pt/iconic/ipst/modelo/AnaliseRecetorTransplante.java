package pt.iconic.ipst.modelo;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name = "ANALISE_RECETOR_TRANSPLANTE")
public class AnaliseRecetorTransplante {

	private Long id_analiserecetortranspl;
	private Recetores recetor;
	private AssignacaoOrgaos assigorgao;
	private EstadoAnaliseRecetor estadoanaliserecetor;
	private String caminhodocrecetor;
	private String nomedocrecetor;
	private int posicao; //posicao prioridade para rins, alternativa ao LUSOT momentanea
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="ID_ANALISE_RECETOR_TRANSP")
	public Long getId_analiserecetortranspl() {
		return id_analiserecetortranspl;
	}
	public void setId_analiserecetortranspl(Long id_analiserecetortranspl) {
		this.id_analiserecetortranspl = id_analiserecetortranspl;
	}
	
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "ID_RECETOR")
	public Recetores getRecetor() {
		return recetor;
	}
	public void setRecetor(Recetores recetor) {
		this.recetor = recetor;
	}
	
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "ID_ASSIGORG")
	public AssignacaoOrgaos getAssigorgao() {
		return assigorgao;
	}
	public void setAssigorgao(AssignacaoOrgaos assigorgao) {
		this.assigorgao = assigorgao;
	}
	
    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "ID_ESTADO_ANALISE_RECETOR")
	public EstadoAnaliseRecetor getEstadoanaliserecetor() {
		return estadoanaliserecetor;
	}
	public void setEstadoanaliserecetor(EstadoAnaliseRecetor estadoanaliserecetor) {
		this.estadoanaliserecetor = estadoanaliserecetor;
	}
	
	@Column(name="POSICAO")
	public int getPosicao() {
		return posicao;
	}
	public void setPosicao(int posicao) {
		this.posicao = posicao;
	}
	
	@Column(name="CAMINHO_DOC_RECETOR")
	public String getCaminhodocrecetor() {
		return caminhodocrecetor;
	}
	public void setCaminhodocrecetor(String caminhodocrecetor) {
		this.caminhodocrecetor = caminhodocrecetor;
	}
	
	@Column(name="NOME_DOC_RECETOR")
	public String getNomedocrecetor() {
		return nomedocrecetor;
	}
	public void setNomedocrecetor(String nomedocrecetor) {
		this.nomedocrecetor = nomedocrecetor;
	}

	
}
