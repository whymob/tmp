package pt.iconic.ipst.modelo;

import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;


@Entity
@Table(name = "TIPOMICROORGANISMO")
public class TipoMicroorganismo {

	
	private Long id_tipomicroorganismo;
	private String descricao;
	private List<Microorganismos> microorgamismo;
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="ID_TIPOMICROORGANISMO")
	public Long getId_tipomicroorganismo() {
		return id_tipomicroorganismo;
	}
	public void setId_tipomicroorganismo(Long id_tipomicroorganismo) {
		this.id_tipomicroorganismo = id_tipomicroorganismo;
	}
	
	@Column(name="DESCRICAO")
	public String getDescricao() {
		return descricao;
	}
	public void setDescricao(String descricao) {
		this.descricao = descricao;
	}
	
	@OneToMany(fetch = FetchType.LAZY, mappedBy = "tipomicroorganismo")
	public List<Microorganismos> getMicroorgamismo() {
		return microorgamismo;
	}
	public void setMicroorgamismo(List<Microorganismos> microorgamismo) {
		this.microorgamismo = microorgamismo;
	}
	
	
	
}
