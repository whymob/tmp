package pt.iconic.ipst.modelo;

import java.util.Calendar;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name = "ECOABDFIGADO")
public class EcoAbdFigado 
{
	private Long Id_Ecoabdfigado;
	private Calendar DataEco;
	private boolean Lesoes;
	private String Notas;
	private int Dimensao;
	private int Parenchyma;
	private int Bordo;
	private int ViasBiliares;
	private int VeiaPorta;
	private int Visicula;
	private int Cm;
	private AnaliseDador analiseDador;
	private boolean statusharmecofigado;
	private Calendar datagravacao;
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="ID_ECOABDFIGADO")
	public Long getId_Ecoabdfigado() {
		return Id_Ecoabdfigado;
	}
	public void setId_Ecoabdfigado(Long id_Ecoabdfigado) {
		Id_Ecoabdfigado = id_Ecoabdfigado;
	}
	
	@Column(name="DATAECOFIGADO")
	public Calendar getDataEco() {
		return DataEco;
	}
	public void setDataEco(Calendar dataEco) {
		DataEco = dataEco;
	}
	
	@Column(name="LESOES")
	public boolean isLesoes() {
		return Lesoes;
	}
	public void setLesoes(boolean lesoes) {
		Lesoes = lesoes;
	}
	
	@Column(name="NOTAS")
	public String getNotas() {
		return Notas;
	}
	public void setNotas(String notas) {
		Notas = notas;
	}
	
	@Column(name="DIMENSAO")
	public int getDimensao() {
		return Dimensao;
	}
	public void setDimensao(int dimensao) {
		Dimensao = dimensao;
	}
	
	@Column(name="PARENCHYMA")
	public int getParenchyma() {
		return Parenchyma;
	}
	public void setParenchyma(int parenchyma) {
		Parenchyma = parenchyma;
	}
	
	@Column(name="BORDO")
	public int getBordo() {
		return Bordo;
	}
	public void setBordo(int bordo) {
		Bordo = bordo;
	}
	
	@Column(name="VIASBILIARES")
	public int getViasBiliares() {
		return ViasBiliares;
	}
	public void setViasBiliares(int viasBiliares) {
		ViasBiliares = viasBiliares;
	}
	
	@Column(name="VEIAPORTA")
	public int getVeiaPorta() {
		return VeiaPorta;
	}
	public void setVeiaPorta(int veiaPorta) {
		VeiaPorta = veiaPorta;
	}
	
	@Column(name="CM")
	public int getCm() {
		return Cm;
	}
	public void setCm(int cm) {
		Cm = cm;
	}

	@OneToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="ID_ANALISEDADOR")
	public AnaliseDador getAnaliseDador() {
		return analiseDador;
	}
	public void setAnaliseDador(AnaliseDador analiseDador) {
		this.analiseDador = analiseDador;
	}
	
	@Column(name="VISICULA")
	public int getVisicula() {
		return Visicula;
	}
	public void setVisicula(int visicula) {
		Visicula = visicula;
	}
	
	@Column(name="STATUSHARMONIO")
	public boolean isStatusharmecofigado() {
		return statusharmecofigado;
	}
	public void setStatusharmecofigado(boolean statusharmecofigado) {
		this.statusharmecofigado = statusharmecofigado;
	}	
	
	@Column(name="DATAGRAVACAO")
	public Calendar getDatagravacao() {
		return datagravacao;
	}

	public void setDatagravacao(Calendar datagravacao) {
		this.datagravacao = datagravacao;
	}
}