package pt.iconic.ipst.modelo;

import java.util.Calendar;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name = "PPHEPATICO")
public class PPHepatico
{
	private Long id_pphepatico;
	private AnaliseRecetor analiserecetor;
//	private double pesohepatico;
//	private int alturahepatico;
//	private Etnia etniahepatico;
	private int transfusoeshepatico;
	private int gestacoeshepatico;
	private float imchepatico;
	private int pertoraxicohepatico;
	private Calendar ulimatransfusaohepatico;
//	private boolean hbhepatico;
//	private boolean hchepatico;
//	private boolean rhhepatico;
//	private int abohepatico;
//	private int diagnosticohepatico;
//	private String observacoeshepatico;
//	private boolean retransplantadohepatico;
	private boolean dhepaticacronica;
	private boolean dhepaticaaguda;
	private boolean dmetabolica;
	private boolean tumor;
	private boolean outras;
	private String nodulos;
	private String tamanhomaior;
	private String tamanhoglobal;
	private boolean invvascular;
	private boolean l1;
	private boolean l2;
	private boolean l3;
	private boolean l4;
	private boolean l5;
	private boolean l6;
	private boolean l7;
	private boolean l8;
	private boolean cirurgia;
	private boolean rf;
	private boolean quimioemb;
	private boolean microondas;
	private boolean alccolizacao;
	private boolean outros;
	private String observacoes;
	
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="ID_PPHEPATICO")
	public Long getId_pphepatico() {
		return id_pphepatico;
	}
	public void setId_pphepatico(Long id_pphepatico) {
		this.id_pphepatico = id_pphepatico;
	}
	
	@OneToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="ID_ANALISERECETOR")
	public AnaliseRecetor getAnaliserecetor() {
		return analiserecetor;
	}
	public void setAnaliserecetor(AnaliseRecetor analiserecetor) {
		this.analiserecetor = analiserecetor;
	}
	
//	@Column(name="PESO")
//	public double getPesohepatico() {
//		return pesohepatico;
//	}
//	public void setPesohepatico(double pesohepatico) {
//		this.pesohepatico = pesohepatico;
//	}
//	
//	@Column(name="ALTURA")
//	public int getAlturahepatico() {
//		return alturahepatico;
//	}
//	public void setAlturahepatico(int alturahepatico) {
//		this.alturahepatico = alturahepatico;
//	}
//	
//	@OneToOne(fetch = FetchType.EAGER)
//    @JoinColumn(name = "ID_ETNIA")
//	public Etnia getEtniahepatico() {
//		return etniahepatico;
//	}
//	public void setEtniahepatico(Etnia etniahepatico) {
//		this.etniahepatico = etniahepatico;
//	}
	
	@Column(name="TRANSFUSOES")
	public int getTransfusoeshepatico() {
		return transfusoeshepatico;
	}
	public void setTransfusoeshepatico(int transfusoeshepatico) {
		this.transfusoeshepatico = transfusoeshepatico;
	}
	
	@Column(name="GESTACOES")
	public int getGestacoeshepatico() {
		return gestacoeshepatico;
	}
	public void setGestacoeshepatico(int gestacoeshepatico) {
		this.gestacoeshepatico = gestacoeshepatico;
	}
	
	@Column(name="IMC")
	public float getImchepatico() {
		return imchepatico;
	}
	public void setImchepatico(float imchepatico) {
		this.imchepatico = imchepatico;
	}
	
	@Column(name="PERTORAXICO")
	public int getPertoraxicohepatico() {
		return pertoraxicohepatico;
	}
	public void setPertoraxicohepatico(int pertoraxicohepatico) {
		this.pertoraxicohepatico = pertoraxicohepatico;
	}
	
	@Column(name="ULTIMATRANSFUSAO")
	public Calendar getUlimatransfusaohepatico() {
		return ulimatransfusaohepatico;
	}
	public void setUlimatransfusaohepatico(Calendar ulimatransfusaohepatico) {
		this.ulimatransfusaohepatico = ulimatransfusaohepatico;
	}
	
//	@Column(name="HB")
//	public boolean isHbhepatico() {
//		return hbhepatico;
//	}
//	public void setHbhepatico(boolean hbhepatico) {
//		this.hbhepatico = hbhepatico;
//	}
//	
//	@Column(name="HC")
//	public boolean isHchepatico() {
//		return hchepatico;
//	}
//	public void setHchepatico(boolean hchepatico) {
//		this.hchepatico = hchepatico;
//	}
	
//	@Column(name="RH")
//	public boolean isRhhepatico() {
//		return rhhepatico;
//	}
//	public void setRhhepatico(boolean rhhepatico) {
//		this.rhhepatico = rhhepatico;
//	}
//	
//	@Column(name="ABO")
//	public int getAbohepatico() {
//		return abohepatico;
//	}
//	public void setAbohepatico(int abohepatico) {
//		this.abohepatico = abohepatico;
//	}
	
	@Column(name="DHEPATICACRONICA")
	public boolean isDhepaticacronica() {
		return dhepaticacronica;
	}
	public void setDhepaticacronica(boolean dhepaticacronica) {
		this.dhepaticacronica = dhepaticacronica;
	}
	
	@Column(name="DHEPATICAAGUDA")
	public boolean isDhepaticaaguda() {
		return dhepaticaaguda;
	}
	public void setDhepaticaaguda(boolean dhepaticaaguda) {
		this.dhepaticaaguda = dhepaticaaguda;
	}
	
	@Column(name="DMETABOLICA")
	public boolean isDmetabolica() {
		return dmetabolica;
	}
	public void setDmetabolica(boolean dmetabolica) {
		this.dmetabolica = dmetabolica;
	}
	
	@Column(name="TUMOR")
	public boolean isTumor() {
		return tumor;
	}
	public void setTumor(boolean tumor) {
		this.tumor = tumor;
	}
	
	@Column(name="OUTRAS")
	public boolean isOutras() {
		return outras;
	}
	public void setOutras(boolean outras) {
		this.outras = outras;
	}
	
	@Column(name="NODULOS")
	public String getNodulos() {
		return nodulos;
	}
	public void setNodulos(String nodulos) {
		this.nodulos = nodulos;
	}
	
	@Column(name="TAMANHOMAIOR")
	public String getTamanhomaior() {
		return tamanhomaior;
	}
	public void setTamanhomaior(String tamanhomaior) {
		this.tamanhomaior = tamanhomaior;
	}
	
	@Column(name="TAMANHOGLOBAL")
	public String getTamanhoglobal() {
		return tamanhoglobal;
	}
	public void setTamanhoglobal(String tamanhoglobal) {
		this.tamanhoglobal = tamanhoglobal;
	}
	
	@Column(name="INVASAOVASCULAR")
	public boolean isInvvascular() {
		return invvascular;
	}
	public void setInvvascular(boolean invvascular) {
		this.invvascular = invvascular;
	}
	
	@Column(name="L1")
	public boolean isL1() {
		return l1;
	}
	public void setL1(boolean l1) {
		this.l1 = l1;
	}
	
	@Column(name="L2")
	public boolean isL2() {
		return l2;
	}
	public void setL2(boolean l2) {
		this.l2 = l2;
	}
	
	@Column(name="L3")
	public boolean isL3() {
		return l3;
	}
	public void setL3(boolean l3) {
		this.l3 = l3;
	}
	
	@Column(name="L4")
	public boolean isL4() {
		return l4;
	}
	public void setL4(boolean l4) {
		this.l4 = l4;
	}
	
	@Column(name="L5")
	public boolean isL5() {
		return l5;
	}
	public void setL5(boolean l5) {
		this.l5 = l5;
	}
	
	@Column(name="L6")
	public boolean isL6() {
		return l6;
	}
	public void setL6(boolean l6) {
		this.l6 = l6;
	}
	
	@Column(name="L7")
	public boolean isL7() {
		return l7;
	}
	public void setL7(boolean l7) {
		this.l7 = l7;
	}
	
	@Column(name="L8")
	public boolean isL8() {
		return l8;
	}
	public void setL8(boolean l8) {
		this.l8 = l8;
	}
	
	@Column(name="CIRURGIA")
	public boolean isCirurgia() {
		return cirurgia;
	}
	public void setCirurgia(boolean cirurgia) {
		this.cirurgia = cirurgia;
	}
	
	@Column(name="RF")
	public boolean isRf() {
		return rf;
	}
	public void setRf(boolean rf) {
		this.rf = rf;
	}
	
	@Column(name="QUIMIOEMB")
	public boolean isQuimioemb() {
		return quimioemb;
	}
	public void setQuimioemb(boolean quimioemb) {
		this.quimioemb = quimioemb;
	}
	
	@Column(name="MICROONDAS")
	public boolean isMicroondas() {
		return microondas;
	}
	public void setMicroondas(boolean microondas) {
		this.microondas = microondas;
	}
	
	@Column(name="ALCOOLIZACAO")
	public boolean isAlccolizacao() {
		return alccolizacao;
	}
	public void setAlccolizacao(boolean alccolizacao) {
		this.alccolizacao = alccolizacao;
	}
	
	@Column(name="OUTROS")
	public boolean isOutros() {
		return outros;
	}
	public void setOutros(boolean outros) {
		this.outros = outros;
	}
	
	@Column(name="OBSERVACOES")
	public String getObservacoes() {
		return observacoes;
	}
	public void setObservacoes(String observacoes) {
		this.observacoes = observacoes;
	}
	
//	@Column(name="DIAGNOSTICO")
//	public int getDiagnosticohepatico() {
//		return diagnosticohepatico;
//	}
//	public void setDiagnosticohepatico(int diagnosticohepatico) {
//		this.diagnosticohepatico = diagnosticohepatico;
//	}
//	
//	@Column(name="OBSERVACOES")
//	public String getObservacoeshepatico() {
//		return observacoeshepatico;
//	}
//	public void setObservacoeshepatico(String observacoeshepatico) {
//		this.observacoeshepatico = observacoeshepatico;
//	}
	
//	@Column(name="RETRANSPLANTADO")
//	public boolean isRetransplantadohepatico() {
//		return retransplantadohepatico;
//	}
//	public void setRetransplantadohepatico(boolean retransplantadohepatico) {
//		this.retransplantadohepatico = retransplantadohepatico;
//	}	
}