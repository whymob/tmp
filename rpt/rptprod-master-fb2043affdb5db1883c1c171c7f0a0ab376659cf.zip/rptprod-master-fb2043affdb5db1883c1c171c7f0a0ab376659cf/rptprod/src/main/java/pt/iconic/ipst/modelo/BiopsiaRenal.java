package pt.iconic.ipst.modelo;

import java.util.Calendar;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name = "BIOPSIA_RENAL")
public class BiopsiaRenal {

	
	private Long idbiopsiarenal;
	private String biopsia;
	private Calendar data;
	private int tecnica;
	private String glomerulosesq;
	private int dimensaoesq;
	private String glomerulosdir;
	private int dimensaodir;
	private String notas;
	private AnaliseDador analiseDador;
	private boolean statusharmbiorenal;
	private String caminhodocrenal;
	private String nomedocrenal;
	private Calendar datagravacao;
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="ID_BIOPSIARENAL")
	public Long getIdbiopsiarenal() {
		return idbiopsiarenal;
	}
	public void setIdbiopsiarenal(Long idbiopsiarenal) {
		this.idbiopsiarenal = idbiopsiarenal;
	}
	
	@Column(name="BIOPSIA")
	public String getBiopsia() {
		return biopsia;
	}
	public void setBiopsia(String biopsia) {
		this.biopsia = biopsia;
	}
	
	@Column(name="DATA")
	public Calendar getData() {
		return data;
	}
	public void setData(Calendar data) {
		this.data = data;
	}
	
	@Column(name="TECNICA")
	public int getTecnica() {
		return tecnica;
	}
	public void setTecnica(int tecnica) {
		this.tecnica = tecnica;
	}
	
	@Column(name="GLOMERULOSESQ")
	public String getGlomerulosesq() {
		return glomerulosesq;
	}
	public void setGlomerulosesq(String glomerulosesq) {
		this.glomerulosesq = glomerulosesq;
	}
	
	@Column(name="DIMENSAOESQ")
	public int getDimensaoesq() {
		return dimensaoesq;
	}
	public void setDimensaoesq(int dimensaoesq) {
		this.dimensaoesq = dimensaoesq;
	}
	
	@Column(name="GLOMERULOSDIR")
	public String getGlomerulosdir() {
		return glomerulosdir;
	}
	public void setGlomerulosdir(String glomerulosdir) {
		this.glomerulosdir = glomerulosdir;
	}
	
	@Column(name="DIMENSAODIR")
	public int getDimensaodir() {
		return dimensaodir;
	}
	public void setDimensaodir(int dimensaodir) {
		this.dimensaodir = dimensaodir;
	}
	
	@Column(name="NOTAS")
	public String getNotas() {
		return notas;
	}
	public void setNotas(String notas) {
		this.notas = notas;
	}
	
	@OneToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="ID_ANALISEDADOR")
	public AnaliseDador getAnaliseDador() {
		return analiseDador;
	}
	public void setAnaliseDador(AnaliseDador analiseDador) {
		this.analiseDador = analiseDador;
	}
	
	@Column(name="STATUSHARMONIO")
	public boolean isStatusharmbiorenal() {
		return statusharmbiorenal;
	}
	public void setStatusharmbiorenal(boolean statusharmbiorenal) {
		this.statusharmbiorenal = statusharmbiorenal;
	}
	
	@Column(name="CAMINHO_DOC_RENAL")
	public String getCaminhodocrenal() {
		return caminhodocrenal;
	}
	public void setCaminhodocrenal(String caminhodocrenal) {
		this.caminhodocrenal = caminhodocrenal;
	}
	
	@Column(name="NOME_DOC_RENAL")
	public String getNomedocrenal() {
		return nomedocrenal;
	}
	public void setNomedocrenal(String nomedocrenal) {
		this.nomedocrenal = nomedocrenal;
	}
	
	@Column(name="DATAGRAVACAO")
	public Calendar getDatagravacao() {
		return datagravacao;
	}

	public void setDatagravacao(Calendar datagravacao) {
		this.datagravacao = datagravacao;
	}
}
