package pt.iconic.ipst.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.springframework.stereotype.Repository;

import pt.iconic.ipst.modelo.Paises;

@Repository
public class PaisesDAO {

	@PersistenceContext
	private EntityManager manager;
	
/*	public void adiciona(Paises pais){
		manager.persist(pais);	
	}

	public void atualiza(Paises pais){
		manager.merge(pais);
	}*/

	public Paises buscaPorId(int id){
		return manager.find(Paises.class, id);
	}
	
/*	public void remove(Paises pais){
		Paises paisaremover = buscaPorId(pais.getId_pais());
		manager.remove(paisaremover);
	}*/
	
	@SuppressWarnings("unchecked")
	public List<Paises> ListaPaises(){
		return manager.createQuery("select c from Paises c ORDER by c.nome").getResultList();
	}
}
