package pt.iconic.ipst.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import pt.iconic.ipst.modelo.EcoAbdPancreas;

@Repository
@Transactional
public class EcopancreasDAO 
{
	@PersistenceContext
	private EntityManager manager;
	
	public void adiciona(EcoAbdPancreas eco){
		manager.persist(eco);	
	}

	public void atualiza(EcoAbdPancreas eco){
		manager.merge(eco);
	}

/*	public EcoAbdPancreas buscaPorId(Long id){
		return manager.find(EcoAbdPancreas.class, id);
	}
	
	public void remove(EcoAbdPancreas eco){
		EcoAbdPancreas ecop = buscaPorId(eco.getId_Ecoabdpancreas());
		manager.remove(ecop);
	}*/
	

	@SuppressWarnings("rawtypes")
	public EcoAbdPancreas ListaEcoPancreas(Long id)
	{
		Query query = manager.createQuery("select e from EcoAbdPancreas e JOIN e.analiseDador analisedador WHERE analisedador.id_AnaliseDador =:idanalise");
		query.setParameter("idanalise", id);

		List results = query.getResultList();
		EcoAbdPancreas rad = null;
		
		if(!results.isEmpty())
		{
			rad = (EcoAbdPancreas) results.get(0);
		}
		
		return rad;
	}
}