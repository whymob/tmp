package pt.iconic.ipst.modelo;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name = "COLHEITA_PULMOES_TRATAMENTO")
public class ColheitaPulmoesTratamento {

	private Long idcolheitatratpulmoes;
	private int tratamento;
	private String observacoestratamento;
	private AnaliseDador analiseDador;
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="ID_COLHEITA_TRATAMENTO_PULMOES")
	public Long getIdcolheitatratpulmoes() {
		return idcolheitatratpulmoes;
	}
	public void setIdcolheitatratpulmoes(Long idcolheitatratpulmoes) {
		this.idcolheitatratpulmoes = idcolheitatratpulmoes;
	}
	
	@Column(name="TRATAMENTO")
	public int getTratamento() {
		return tratamento;
	}
	public void setTratamento(int tratamento) {
		this.tratamento = tratamento;
	}
	
	@Column(name="OBSERVACOES_TRATAMENTO")
	public String getObservacoestratamento() {
		return observacoestratamento;
	}
	public void setObservacoestratamento(String observacoestratamento) {
		this.observacoestratamento = observacoestratamento;
	}
	
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "ID_ANALISE_DADOR")
	public AnaliseDador getAnaliseDador() {
		return analiseDador;
	}
	public void setAnaliseDador(AnaliseDador analiseDador) {
		this.analiseDador = analiseDador;
	}
	
	
}
