package pt.iconic.ipst.modelo;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name = "DADORDETALHES")
public class DadorDetalhes {

	private Long id_dadordetalhes;
	private Dador dador;
	private Etnia etnia;
	private int telemovel;
	private int telefone;
	private String email;
	private String morada;
	private String moradacont;	
	private String codpostal;
	private String localidade;
	private int peso;
	private int altura;
	private int nif; // passou a ser o cart�o de cidad�o
	
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="ID_DADORDETALHES")
	public Long getId_dadordetalhes() {
		return id_dadordetalhes;
	}
	public void setId_dadordetalhes(Long id_dadordetalhes) {
		this.id_dadordetalhes = id_dadordetalhes;
	}
	
	@OneToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="ID_DADOR")
	public Dador getDador() {
		return dador;
	}
	public void setDador(Dador dador) {
		this.dador = dador;
	}
	
    @OneToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "ID_ETNIA")
	public Etnia getEtnia() {
		return etnia;
	}
	public void setEtnia(Etnia etnia) {
		this.etnia = etnia;
	}
	
	@Column(name="TELEMOVEL")
	public int getTelemovel() {
		return telemovel;
	}
	public void setTelemovel(int telemovel) {
		this.telemovel = telemovel;
	}
	
	@Column(name="TELEFONE")
	public int getTelefone() {
		return telefone;
	}
	public void setTelefone(int telefone) {
		this.telefone = telefone;
	}
	
	@Column(name="EMAIL")
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	
	@Column(name="MORADA")
	public String getMorada() {
		return morada;
	}
	public void setMorada(String morada) {
		this.morada = morada;
	}
	
	@Column(name="MORADACONT")
	public String getMoradacont() {
		return moradacont;
	}
	public void setMoradacont(String moradacont) {
		this.moradacont = moradacont;
	}
	
	@Column(name="CODIGOPOSTAL")
	public String getCodpostal() {
		return codpostal;
	}
	public void setCodpostal(String codpostal) {
		this.codpostal = codpostal;
	}
	
	@Column(name="LOCALIDADE")
	public String getLocalidade() {
		return localidade;
	}
	public void setLocalidade(String localidade) {
		this.localidade = localidade;
	}
	
	@Column(name="PESO")
	public int getPeso() {
		return peso;
	}
	public void setPeso(int peso) {
		this.peso = peso;
	}
	
	@Column(name="ALTURA")
	public int getAltura() {
		return altura;
	}
	public void setAltura(int altura) {
		this.altura = altura;
	}
	
	@Column(name="NIF")
	public int getNif() {
		return nif;
	}
	public void setNif(int nif) {
		this.nif = nif;
	}
	
	
	
}
