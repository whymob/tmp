package pt.iconic.ipst.modelo;

import java.util.Calendar;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.persistence.Transient;

import org.springframework.format.annotation.DateTimeFormat;

@Entity
@Table(name = "DADOR")
public class Dador {

	private Long Id_Dador;
	private String CodigoDador;
	private String NomeDador;
	private Calendar DataNascimento;
	private boolean Sexo;
	private Hospital hospital;
	private String UCI;
	private GlasgowComma glasgowComma;
//	private String Pais;
	private String Nacionalidade;
	private EstadoDador estadoDador;
	private TipoDador tipoDador;
	private int idade;
	private int sns;
	private Calendar dataregisto;
	private AnaliseDador analiseDador;
	private DadorDetalhes dadordetalhes;
	private Utilizador utilizador;
	private UtilizadorB utilizadorb;
	private Paises pais;
	private String motivoestado;
	private int dadoscompletostransp;
	private List<AssignacaoOrgaos> assignacao;
	private List<HistoricoAssignacao> historico;
	private List<EquipaSuporte> equipasuporte;
	private List<EquipaCirurgia> equipacirurgia;
	private List<EquipaLocal> equipalocal;
	private List<TransporteEquipa> transporteequipa;
//	private List<EquipaLocalTransplante> equipalocaltransplante;
//	private List<EquipaCirurgiaTransplante> equipacirurgiatransplante;
//	private List<EquipaSuporteTransplante> equipasuportetransplante;
	private List<GCCTColheita> gcctcolheita;
	
//	@PrePersist
//	void preInsercao() {
//		Dador.this.setTipoDador();
//		Dador.this.tipoDador.setId_TipoDador(1L);
//	//	Dador.this.estadoDador.setId_EstadoDador(1);
//	}
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="ID_DADOR")
	public Long getId_Dador() {
		return Id_Dador;
	}
	public void setId_Dador(Long id_Dador) {
		Id_Dador = id_Dador;
	}
	
	@OneToOne(fetch = FetchType.LAZY, mappedBy = "dador")
	public AnaliseDador getAnaliseDador() {
		return analiseDador;
	}

	public void setAnaliseDador(AnaliseDador analiseDador) {
		this.analiseDador = analiseDador;
	}

	@OneToOne(fetch = FetchType.LAZY, mappedBy = "dador")
	public DadorDetalhes getDadordetalhes() {
		return dadordetalhes;
	}

	public void setDadordetalhes(DadorDetalhes dadordetalhes) {
		this.dadordetalhes = dadordetalhes;
	}

	@Column(name="CODIGODADOR")
	public String getCodigoDador() {
		return CodigoDador;
	}
	public void setCodigoDador(String codigoDador) {
		CodigoDador = codigoDador;
	}
	
	@Column(name="NOMEDADOR")
	public String getNomeDador() {
		return NomeDador;
	}
	public void setNomeDador(String nomeDador) {
		NomeDador = nomeDador;
	}
	
	@DateTimeFormat(pattern="dd/MM/yyyy")
	@Temporal(TemporalType.DATE)
	@Column(name="DATANASCIMENTO")
	public Calendar getDataNascimento() {
		return DataNascimento;
	}
	public void setDataNascimento(Calendar dataNascimento) {
		DataNascimento = dataNascimento;
	}
	
	@Column(name="SEXO")
	public boolean isSexo() {
		return Sexo;
	}
	public void setSexo(boolean sexo) {
		Sexo = sexo;
	}
	
    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "ID_HOSPITAL")
	public Hospital getHospital() {
		return hospital;
	}
	public void setHospital(Hospital hospital) {
		this.hospital = hospital;
	}
	
	@Column(name="UCI")
	public String getUCI() {
		return UCI;
	}
	public void setUCI(String uCI) {
		UCI = uCI;
	}
	
    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "ID_GLASGOWCOMMA")
	public GlasgowComma getGlasgowComma() {
		return glasgowComma;
	}
	public void setGlasgowComma(GlasgowComma glasgowComma) {
		this.glasgowComma = glasgowComma;
	}
	
//	@Column(name="PAIS")
//	public String getPais() {
//		return Pais;
//	}
//	public void setPais(String pais) {
//		Pais = pais;
//	}
	
	@Column(name="NACIONALIDADE")
	public String getNacionalidade() {
		return Nacionalidade;
	}
	public void setNacionalidade(String nacionalidade) {
		Nacionalidade = nacionalidade;
	}
	
	@ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "ID_ESTADODADOR")
    public EstadoDador getEstadoDador() {
		return estadoDador;
	}

	public void setEstadoDador(EstadoDador estadoDador) {
		this.estadoDador = estadoDador;
	}

	@ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "ID_TIPODADOR")
	public TipoDador getTipoDador() {
		return tipoDador;
	}
	public void setTipoDador(TipoDador tipoDador) {
		this.tipoDador = tipoDador;
	}

	@Column(name="SNS")
	public int getSns() {
		return sns;
	}

	public void setSns(int sns) {
		this.sns = sns;
	}

	@Column(name="DATAREGISTO")
	@DateTimeFormat(pattern="dd/MM/yyyy HH:mm")
	@Temporal(TemporalType.TIMESTAMP)
	public Calendar getDataregisto() {
		return dataregisto;
	}

	public void setDataregisto(Calendar dataregisto) {
		this.dataregisto = dataregisto;
	}

	@Transient
	@Column(name="IDADE")
    public int getIdade() {
		this.idade = 0;
		if(DataNascimento != null){
	    	//this.idade = elapsed(DataNascimento, Calendar.getInstance(), Calendar.YEAR);
			
	        if (DataNascimento.after(dataregisto)) {
	            this.idade = 0;
	        }else{
			
			this.idade = elapsed(DataNascimento, dataregisto, Calendar.YEAR);
	        }
		}
        return idade;
    }
    
	public void setIdade(int idade) {
		this.idade = idade;
	}
	
    private static int elapsed(Calendar before, Calendar after, int field) {
      //  checkBeforeAfter(before, after);
        Calendar clone = (Calendar) before.clone(); // Otherwise changes are been reflected.
        int elapsed = -1;
        while (!clone.after(after)) {
            clone.add(field, 1);
            elapsed++;
        }
        return elapsed;
    }
    
/*    private static void checkBeforeAfter(Calendar before, Calendar after) {
        if (before.after(after)) {
            throw new IllegalArgumentException(
                "O primeiro calend�rio deve ser definido antes do segundo calendario.");
        }
    }*/

    
    @ManyToOne(fetch=FetchType.LAZY)
   	@JoinColumn(name="ID_UTILIZADOR")
   	public Utilizador getUtilizador() {
   		return utilizador;
   	}

   	public void setUtilizador(Utilizador utilizador) {
   		this.utilizador = utilizador;
   	}

   	@ManyToOne(fetch=FetchType.LAZY)
   	@JoinColumn(name="ID_UTILIZADORB")
   	public UtilizadorB getUtilizadorb() {
   		return utilizadorb;
   	}

   	public void setUtilizadorb(UtilizadorB utilizadorb) {
   		this.utilizadorb = utilizadorb;
   	}

    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "ID_PAIS")
	public Paises getPais() {
		return pais;
	}

	public void setPais(Paises pais) {
		this.pais = pais;
	}
	
	@Column(name="MOTIVOESTADO")
	public String getMotivoestado() {
		return motivoestado;
	}
	public void setMotivoestado(String motivoestado) {
		this.motivoestado = motivoestado;
	}
	
	@OneToMany(fetch = FetchType.LAZY, mappedBy = "dadoroferta")
	public List<AssignacaoOrgaos> getAssignacao() {
		return assignacao;
	}
	public void setAssignacao(List<AssignacaoOrgaos> assignacao) {
		this.assignacao = assignacao;
	}
	
	@OneToMany(fetch = FetchType.LAZY, mappedBy = "dador")
	public List<HistoricoAssignacao> getHistorico() {
		return historico;
	}
	public void setHistorico(List<HistoricoAssignacao> historico) {
		this.historico = historico;
	}
	
	@OneToMany(fetch = FetchType.LAZY, mappedBy = "dador")
	public List<EquipaSuporte> getEquipasuporte() {
		return equipasuporte;
	}
	public void setEquipasuporte(List<EquipaSuporte> equipasuporte) {
		this.equipasuporte = equipasuporte;
	}
	
	@OneToMany(fetch = FetchType.LAZY, mappedBy = "dador")
	public List<EquipaCirurgia> getEquipacirurgia() {
		return equipacirurgia;
	}
	public void setEquipacirurgia(List<EquipaCirurgia> equipacirurgia) {
		this.equipacirurgia = equipacirurgia;
	}
	
	@OneToMany(fetch = FetchType.LAZY, mappedBy = "dador")
	public List<EquipaLocal> getEquipalocal() {
		return equipalocal;
	}
	public void setEquipalocal(List<EquipaLocal> equipalocal) {
		this.equipalocal = equipalocal;
	}
	
	@OneToMany(fetch = FetchType.LAZY, mappedBy = "dador")
	public List<TransporteEquipa> getTransporteequipa() {
		return transporteequipa;
	}
	public void setTransporteequipa(List<TransporteEquipa> transporteequipa) {
		this.transporteequipa = transporteequipa;
	}
	
//	@OneToMany(fetch = FetchType.LAZY, mappedBy = "dador")
//	public List<EquipaLocalTransplante> getEquipalocaltransplante() {
//		return equipalocaltransplante;
//	}
//	public void setEquipalocaltransplante(List<EquipaLocalTransplante> equipalocaltransplante) {
//		this.equipalocaltransplante = equipalocaltransplante;
//	}
	
//	@OneToMany(fetch = FetchType.LAZY, mappedBy = "dador")
//	public List<EquipaCirurgiaTransplante> getEquipacirurgiatransplante() {
//		return equipacirurgiatransplante;
//	}
//	public void setEquipacirurgiatransplante(
//			List<EquipaCirurgiaTransplante> equipacirurgiatransplante) {
//		this.equipacirurgiatransplante = equipacirurgiatransplante;
//	}
	
//	@OneToMany(fetch = FetchType.LAZY, mappedBy = "dador")
//	public List<EquipaSuporteTransplante> getEquipasuportetransplante() {
//		return equipasuportetransplante;
//	}
//	public void setEquipasuportetransplante(List<EquipaSuporteTransplante> equipasuportetransplante) {
//		this.equipasuportetransplante = equipasuportetransplante;
//	}
	
	@OneToMany(fetch = FetchType.LAZY, mappedBy = "dador")
	public List<GCCTColheita> getGcctcolheita() {
		return gcctcolheita;
	}
	public void setGcctcolheita(List<GCCTColheita> gcctcolheita) {
		this.gcctcolheita = gcctcolheita;
	}
	
	@Column(name="DADOS_COMPLETOS_TRANSP")
	public int getDadoscompletostransp() {
		return dadoscompletostransp;
	}
	public void setDadoscompletostransp(int dadoscompletostransp) {
		this.dadoscompletostransp = dadoscompletostransp;
	}
	
}
