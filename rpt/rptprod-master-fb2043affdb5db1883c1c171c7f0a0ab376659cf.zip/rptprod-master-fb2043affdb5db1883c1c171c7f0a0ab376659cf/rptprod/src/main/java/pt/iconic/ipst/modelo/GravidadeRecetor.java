package pt.iconic.ipst.modelo;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import org.springframework.format.annotation.DateTimeFormat;

import java.util.Calendar;

@Entity
@Table(name = "GRAVIDADERECETOR")
public class GravidadeRecetor
{
	private Long id_gravidaderecetor;
	private GravidadeOrgao gravorg;
	private Calendar datagravidade;
	private String notas;
	private AnaliseRecetor analiserecetor;
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "ID_GRAVIDADERECETOR")
	public Long getId_gravidaderecetor() {
		return id_gravidaderecetor;
	}
	public void setId_gravidaderecetor(Long id_gravidaderecetor) {
		this.id_gravidaderecetor = id_gravidaderecetor;
	}
	
	@DateTimeFormat(pattern="dd/MM/yyyy")
	@Temporal(TemporalType.DATE)
	@Column(name = "DATAGRAVIDADE")
	public Calendar getDatagravidade() {
		return datagravidade;
	}
	public void setDatagravidade(Calendar datagravidade) {
		this.datagravidade = datagravidade;
	}
	
	@Column(name = "NOTASGRAVIDADE")
	public String getNotas() {
		return notas;
	}
	public void setNotas(String notas) {
		this.notas = notas;
	}
	
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name="ID_ANALISERECETOR")
	public AnaliseRecetor getAnaliserecetor() {
		return analiserecetor;
	}
	public void setAnaliserecetor(AnaliseRecetor analiserecetor) {
		this.analiserecetor = analiserecetor;
	}
	
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name="ID_GRAVIDADEORGAO")
	public GravidadeOrgao getGravorg() {
		return gravorg;
	}
	public void setGravorg(GravidadeOrgao gravorg) {
		this.gravorg = gravorg;
	}
}