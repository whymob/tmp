package pt.iconic.ipst.controller;



import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import javax.servlet.http.HttpSession;

import org.json.simple.JSONArray;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import pt.iconic.ipst.dao.AmostrasFODAO;
import pt.iconic.ipst.dao.AmostrasFuncoesOrgaoDAO;
import pt.iconic.ipst.dao.AnaliseDadorDAO;
import pt.iconic.ipst.dao.BDAvaliacaoInicialDAO;
import pt.iconic.ipst.dao.BDOrgaosDAO;
import pt.iconic.ipst.dao.BiopsiaHepaticaDAO;
import pt.iconic.ipst.dao.BiopsiaRenalDAO;
import pt.iconic.ipst.dao.BiopsiarenalItensDAO;
import pt.iconic.ipst.dao.BroncoescopiaDAO;
import pt.iconic.ipst.dao.CausaMorteDAO;
import pt.iconic.ipst.dao.CoronografiaDAO;
import pt.iconic.ipst.dao.DadorDAO;
import pt.iconic.ipst.dao.DadorDetalhesDAO;
import pt.iconic.ipst.dao.DadosAbdFigadoDAO;
import pt.iconic.ipst.dao.DadosAbdPancreasDAO;
import pt.iconic.ipst.dao.DadosAbdRinsDAO;
import pt.iconic.ipst.dao.DadosCoronografiaDAO;
import pt.iconic.ipst.dao.EcofigadoDAO;
import pt.iconic.ipst.dao.EcopancreasDAO;
import pt.iconic.ipst.dao.EcorinsDAO;
import pt.iconic.ipst.dao.EcotoraxicoDAO;
import pt.iconic.ipst.dao.EletrocardiogramaDAO;
import pt.iconic.ipst.dao.EtniaDAO;
import pt.iconic.ipst.dao.FuncoesOrgaoDAO;
import pt.iconic.ipst.dao.GasVentDAO;
import pt.iconic.ipst.dao.GlasgowCommaDAO;
import pt.iconic.ipst.dao.GrupoSanguineoDAO;
import pt.iconic.ipst.dao.HCDoencasPreExistentesDAO;
import pt.iconic.ipst.dao.HCExameFisicoDAO;
import pt.iconic.ipst.dao.HCGeralDAO;
import pt.iconic.ipst.dao.HCSituacoesRiscoDAO;
import pt.iconic.ipst.dao.ImunologiaDAO;
import pt.iconic.ipst.dao.LesoesRadiografiaDAO;
import pt.iconic.ipst.dao.MBAnalisesDAO;
import pt.iconic.ipst.dao.MecanismoMorteDAO;
import pt.iconic.ipst.dao.MicrobiologiaDAO;
import pt.iconic.ipst.dao.MicroorganismosDAO;
import pt.iconic.ipst.dao.MicrorgmbanalisembDAO;
import pt.iconic.ipst.dao.MorteCerebralDAO;
import pt.iconic.ipst.dao.NomeTransfusoesDAO;
import pt.iconic.ipst.dao.PatologiaBroncoescopiaDAO;
import pt.iconic.ipst.dao.QuadrantesDAO;
import pt.iconic.ipst.dao.RadiografiaDAO;
import pt.iconic.ipst.dao.SensMicroorganismoDAO;
import pt.iconic.ipst.dao.SensibilidadeDAO;
import pt.iconic.ipst.dao.TerapeuticasDAO;
import pt.iconic.ipst.dao.TipoAmostraDAO;
import pt.iconic.ipst.dao.TipoGasVentDAO;
import pt.iconic.ipst.dao.TipoMBAnaliseDAO;
import pt.iconic.ipst.dao.TipoMicroorganismoDAO;
import pt.iconic.ipst.dao.TipoTerapeuticasDAO;
import pt.iconic.ipst.dao.TransfusoesDAO;
import pt.iconic.ipst.dao.UnidadesDAO;
import pt.iconic.ipst.dao.UtilizadorDAO;
import pt.iconic.ipst.dao.VirologiaDAO;
import pt.iconic.ipst.modelo.AmostrasFuncoesOrgao;
import pt.iconic.ipst.modelo.AnaliseDador;
import pt.iconic.ipst.modelo.BDAvaliacaoInicial;
import pt.iconic.ipst.modelo.BDOrgaos;
import pt.iconic.ipst.modelo.BiopsiaHepatica;
import pt.iconic.ipst.modelo.BiopsiaRenal;
import pt.iconic.ipst.modelo.BiopsiarenalItens;
import pt.iconic.ipst.modelo.Broncoescopia;
import pt.iconic.ipst.modelo.CausaMorte;
import pt.iconic.ipst.modelo.Coronografia;
import pt.iconic.ipst.modelo.Dador;
import pt.iconic.ipst.modelo.DadorDetalhes;
import pt.iconic.ipst.modelo.DadosAbdFigado;
import pt.iconic.ipst.modelo.DadosAbdPancreas;
import pt.iconic.ipst.modelo.DadosAbdRins;
import pt.iconic.ipst.modelo.DadosCoronografia;
import pt.iconic.ipst.modelo.EcoAbdFigado;
import pt.iconic.ipst.modelo.EcoAbdPancreas;
import pt.iconic.ipst.modelo.EcoAbdRins;
import pt.iconic.ipst.modelo.EcoToraxico;
import pt.iconic.ipst.modelo.Eletrocardiograma;
import pt.iconic.ipst.modelo.EstadoDador;
import pt.iconic.ipst.modelo.Etnia;
import pt.iconic.ipst.modelo.FuncoesOrgao;
import pt.iconic.ipst.modelo.GasVent;
import pt.iconic.ipst.modelo.GlasgowComma;
import pt.iconic.ipst.modelo.GrupoSanguineo;
import pt.iconic.ipst.modelo.HCDoencasPreExistentes;
import pt.iconic.ipst.modelo.HCExameFisico;
import pt.iconic.ipst.modelo.HCGeral;
import pt.iconic.ipst.modelo.HCSituacoesRisco;
import pt.iconic.ipst.modelo.Imunologia;
import pt.iconic.ipst.modelo.LesoesRadiografia;
import pt.iconic.ipst.modelo.MBAnalises;
import pt.iconic.ipst.modelo.MecanismoMorte;
import pt.iconic.ipst.modelo.Microbiologia;
import pt.iconic.ipst.modelo.Microrgmbanalisemb;
import pt.iconic.ipst.modelo.MorteCerebral;
import pt.iconic.ipst.modelo.PatologiaBroncoescopia;
import pt.iconic.ipst.modelo.Quadrantes;
import pt.iconic.ipst.modelo.Radiografia;
import pt.iconic.ipst.modelo.SensMicroorganalise;
import pt.iconic.ipst.modelo.Terapeuticas;
import pt.iconic.ipst.modelo.Transfusoes;
import pt.iconic.ipst.modelo.Virologia;


@Controller
public class AvaliacaoController {

	private DadorDAO daoDador;
	private GlasgowCommaDAO daoglasg;
	private CausaMorteDAO daocausamorte;
	private MecanismoMorteDAO daomecmorte;
	private EtniaDAO daoetnia;
	private DadorDetalhesDAO daodaddet;
	private GasVentDAO daogasvent;
	private TipoGasVentDAO daotipogasvent;
	private TipoTerapeuticasDAO daotipter;
	private TerapeuticasDAO daoterap;
	private AnaliseDadorDAO daoanalisedador;
	private BDAvaliacaoInicialDAO daobdavalinicial;
	private BDOrgaosDAO daobdorgaos;
	private HCExameFisicoDAO daoexamefisico;
	private QuadrantesDAO daoquadrantes;
	private HCGeralDAO daogeral;
	private HCDoencasPreExistentesDAO daodoencaspreex;
	private HCSituacoesRiscoDAO daositrisco;
	private MorteCerebralDAO daomc;
	private AmostrasFuncoesOrgaoDAO daoamostrasfo;
	private TipoAmostraDAO daotipoamostra;
	private AmostrasFODAO daoamostrasmestre;
	private FuncoesOrgaoDAO daofuncaorgao;
	private MBAnalisesDAO daombanalises;
	private MicrobiologiaDAO daomicro;
	private TipoMBAnaliseDAO daotipoMB;
	private SensibilidadeDAO daosensi;
	private EletrocardiogramaDAO daoeletro;
	private EcotoraxicoDAO daotora;
	private EcofigadoDAO daofigado;
	private RadiografiaDAO daorx;
	private EcopancreasDAO daopancreas;
	private CoronografiaDAO daocorona;
	private BroncoescopiaDAO daobronco;
	private EcorinsDAO daorins;
	private TipoMicroorganismoDAO daotipoorg;
	private MicrorgmbanalisembDAO daomicrombanalise;
	private MicroorganismosDAO daomicroorganismos;
	private SensMicroorganismoDAO daosensmicro;
	private VirologiaDAO daoviro;
	private ImunologiaDAO daoimuno;
	private GrupoSanguineoDAO daogrupsang;
	private TransfusoesDAO daotransf;
	private NomeTransfusoesDAO daonometransf;
	private LesoesRadiografiaDAO daolesaorx;
	private DadosAbdFigadoDAO daolesaofigado;
	private DadosAbdRinsDAO daolesaorins;
	private DadosAbdPancreasDAO daolesaopancreas;
	private DadosCoronografiaDAO daodadoscoronografia;
	private PatologiaBroncoescopiaDAO daopatbronco;
	private UnidadesDAO daounid;
	private BiopsiaRenalDAO daobiorenal;
	private BiopsiarenalItensDAO daobiorenalitens;
	private BiopsiaHepaticaDAO daobiohepatica;
	private UtilizadorDAO daouser;

	
	@Autowired
	public AvaliacaoController(DadorDAO daoDador, GlasgowCommaDAO daoglasg, CausaMorteDAO daocausamorte, MecanismoMorteDAO daomecmorte, EtniaDAO daoetnia , DadorDetalhesDAO daodaddet,
			GasVentDAO daogasvent, TipoGasVentDAO daotipogasvent, TipoTerapeuticasDAO daotipter, TerapeuticasDAO daoterap,
			AnaliseDadorDAO daoanalisedador, BDAvaliacaoInicialDAO daobdavalinicial, BDOrgaosDAO daobdorgaos, HCExameFisicoDAO daoexamefisico , QuadrantesDAO daoquadrantes,
			HCGeralDAO daogeral, HCDoencasPreExistentesDAO daodoencaspreex, HCSituacoesRiscoDAO daositrisco, MorteCerebralDAO daomc, AmostrasFuncoesOrgaoDAO daoamostrasfo,
			TipoAmostraDAO daotipoamostra, AmostrasFODAO daoamostrasmestre, FuncoesOrgaoDAO daofuncaorgao, MBAnalisesDAO daombanalises,
			MicrobiologiaDAO daomicro, SensibilidadeDAO daosensi, EletrocardiogramaDAO daoeletro, EcotoraxicoDAO daotora, EcofigadoDAO daofigado, RadiografiaDAO daorx, EcopancreasDAO daopancreas, 
			CoronografiaDAO daocorona, BroncoescopiaDAO daobronco, EcorinsDAO daorins, TipoMBAnaliseDAO daotipoMB, TipoMicroorganismoDAO daotipoorg, MicrorgmbanalisembDAO daomicrombanalise,
			MicroorganismosDAO daomicroorganismos, SensMicroorganismoDAO daosensmicro, VirologiaDAO daoviro, ImunologiaDAO daoimuno, GrupoSanguineoDAO daogrupsang,
			TransfusoesDAO daotransf, NomeTransfusoesDAO daonometransf, LesoesRadiografiaDAO daolesaorx, DadosAbdFigadoDAO daolesaofigado,
			DadosAbdRinsDAO daolesaorins, DadosAbdPancreasDAO daolesaopancreas, DadosCoronografiaDAO daodadoscoronografia, PatologiaBroncoescopiaDAO daopatbronco, 
			UnidadesDAO daounid, BiopsiaRenalDAO daobiorenal, BiopsiarenalItensDAO daobiorenalitens, BiopsiaHepaticaDAO daobiohepatica, UtilizadorDAO daouser) {
		this.daoDador = daoDador;
		this.daoglasg = daoglasg;
		this.daocausamorte = daocausamorte;
		this.daomecmorte = daomecmorte;
		this.daoetnia = daoetnia;
		this.daodaddet = daodaddet;
		this.daogasvent = daogasvent;
		this.daotipogasvent = daotipogasvent;
		this.daotipter = daotipter;
		this.daoterap = daoterap;
		this.daoanalisedador = daoanalisedador;
		this.daobdavalinicial = daobdavalinicial;
		this.daobdorgaos = daobdorgaos;
		this.daoexamefisico = daoexamefisico;
		this.daoquadrantes = daoquadrantes;
		this.daogeral = daogeral;
		this.daodoencaspreex = daodoencaspreex;
		this.daositrisco = daositrisco;
		this.daomc = daomc;
		this.daoamostrasfo = daoamostrasfo;
		this.daotipoamostra = daotipoamostra;
		this.daoamostrasmestre = daoamostrasmestre;
		this.daofuncaorgao = daofuncaorgao;
		this.daombanalises = daombanalises;
		this.daomicro = daomicro;
		this.daotipoMB = daotipoMB;
		this.daosensi = daosensi;
		this.daoeletro = daoeletro;
		this.daotora = daotora;
		this.daofigado = daofigado;
		this.daorx = daorx;
		this.daopancreas = daopancreas;
		this.daocorona = daocorona;
		this.daobronco = daobronco;
		this.daorins = daorins;
		this.daotipoorg = daotipoorg;
		this.daomicrombanalise = daomicrombanalise;
		this.daomicroorganismos = daomicroorganismos;
		this.daosensmicro = daosensmicro;
		this.daoviro = daoviro;
		this.daoimuno = daoimuno;
		this.daogrupsang = daogrupsang;
		this.daotransf = daotransf;
		this.daonometransf = daonometransf;
		this.daolesaorx = daolesaorx;
		this.daolesaofigado = daolesaofigado;
		this.daolesaorins = daolesaorins;
		this.daolesaopancreas = daolesaopancreas;
		this.daodadoscoronografia = daodadoscoronografia;
		this.daopatbronco = daopatbronco;
		this.daounid = daounid;
		this.daobiorenal = daobiorenal;
		this.daobiorenalitens = daobiorenalitens;
		this.daobiohepatica = daobiohepatica;
		this.daouser = daouser;
	}
	
	@RequestMapping("abreavaliacaocoord")
	public String abreavaliacaocoord(Long id, Model model, HttpSession session){
		Dador d = daoDador.buscaPorId(id);
		session.setAttribute("dador", d);
		model.addAttribute("dador", d);
		
		
		model.addAttribute("glasgowcomma", daoglasg.ListaGlasgowComma());
		model.addAttribute("causademorte", daocausamorte.ListaCausaMorte());
		model.addAttribute("mecanismomorte", daomecmorte.ListaMecanismoMorte());
		model.addAttribute("etnia", daoetnia.ListaEtnia());
		model.addAttribute("dadordetalhe", daodaddet.buscadetalhesdador(id));
	return "admin/divdetalheavaliacaocoord";
	}
	
	
	@RequestMapping(value="abreavaliacao")
	@Transactional
	public String abreavaliacao(Long id, Model model, HttpSession session){
		
		Dador dador = daoDador.buscaPorId(id);
		session.setAttribute("dador", dador);
		
		//define vari�vel global do dador para carregar peso do dador nas transfus�es
		session.setAttribute("id_dador",id);

		AnaliseDador analise = new AnaliseDador();
		
		if(daoDador.verificaexisteavaliacao(id)){
			
			//busca a sua avalia��o
			analise = daoanalisedador.buscaAnaliseDoDador(id);
			
			session.setAttribute("id_analise", analise.getId_AnaliseDador());
			model.addAttribute("numanalise", analise.getId_AnaliseDador());
			
			//enviar mortecerebral dessa analise para id morte cerebral para upload
			model.addAttribute("mortecerebralobj", daomc.buscaMorteCerebralAvaliacao(analise.getId_AnaliseDador()));
			
			//enviar objeto bdavalaiacaoinicial desse id para carregar campo de upload 
			model.addAttribute("bdavalinicial", daobdavalinicial.buscaavaliacaoinicial(analise.getId_AnaliseDador()));
			
			//enviar objecto bdorgaos dessa avaliacao para carregar  divorgaos 
			model.addAttribute("bdorgaos", daobdorgaos.buscabdorgaosdaavaliacao(analise.getId_AnaliseDador()));
			
			//enviar objecto ecgobj dessa avaliacao para carregar  campo de upload 
			model.addAttribute("ecgobj", daoeletro.ListaEletrocardiograma(analise.getId_AnaliseDador()));
			
			//enviar objecto ecgobj dessa avaliacao para carregar  campo de upload 
			model.addAttribute("rxobj", daorx.ListaRadiografia(analise.getId_AnaliseDador()));
			
			//enviar objecto ecgobj dessa avaliacao para carregar  campo de upload 
			model.addAttribute("toraxicoobj", daotora.ListaEcoToraxico(analise.getId_AnaliseDador()));
			
			//enviar objecto ecgobj dessa avaliacao para carregar  campo de upload 
			model.addAttribute("coronografiaobj", daocorona.ListaCoronografia(analise.getId_AnaliseDador()));
			
			//enviar objecto imunoob dessa avaliacao para carregar imunologia
//			model.addAttribute("imunologiaobj", daoimuno.buscaImunologiaAvaliacao(analise.getId_AnaliseDador()));
			
			
		}else{
			
		//criar nova avalia��o
			analise.setDador(dador);
			daoanalisedador.adiciona(analise);
			model.addAttribute("numanalise", analise.getId_AnaliseDador());
			session.setAttribute("id_analise", analise.getId_AnaliseDador());
			
			//ao abrir o dador passar estado para em avalia��o: // � feito na grava��o dos org�os
/*			EstadoDador estado = new EstadoDador();
			estado.setId_EstadoDador(2);
			dador.setEstadoDador(estado);*/
			daoDador.atualiza(dador);
			
			//criar nova BDAValiacaoInicial
			BDAvaliacaoInicial avalinicial = new BDAvaliacaoInicial();
			avalinicial.setAnaliseDador(analise);
			daobdavalinicial.adiciona(avalinicial);
			
			
			//criar nova biopsiarenal
			BiopsiaRenal biorenal = new BiopsiaRenal();
			biorenal.setAnaliseDador(analise);
			daobiorenal.adiciona(biorenal);
			
			//criar nova biopsiahepatica
			BiopsiaHepatica biohepatica = new BiopsiaHepatica();
			biohepatica.setAnaliseDador(analise);
			daobiohepatica.adiciona(biohepatica);
			
			//criar nova BDOrgaos
			BDOrgaos bdorgaos = new BDOrgaos();
			bdorgaos.setAnaliseDador(analise);
			daobdorgaos.adiciona(bdorgaos);
			model.addAttribute("bdorgaos", bdorgaos);
			
			//criar quadrantes para exame f�sico
			Quadrantes quadr = new Quadrantes();
			daoquadrantes.adiciona(quadr);
			
			//criar novo HCGeral
			HCGeral geral = new HCGeral();
			geral.setAnaliseDador(analise);
			daogeral.adiciona(geral);
			
			//criar novo HCDoencasPreExistentes
			HCDoencasPreExistentes doencas = new HCDoencasPreExistentes();
			doencas.setAnaliseDador(analise);
			daodoencaspreex.adiciona(doencas);
			
			//criar novo Situa��es risco
			HCSituacoesRisco sitrisco = new HCSituacoesRisco();
			sitrisco.setAnaliseDador(analise);
			daositrisco.adiciona(sitrisco);
			
			//criar nova mortecerebral
			MorteCerebral mc = new MorteCerebral();
			mc.setAnaliseDador(analise);
			daomc.adiciona(mc);
			
			//criar nova funcoesorgao
			FuncoesOrgao fo = new FuncoesOrgao();
			fo.setAnaliseDador(analise);
			fo.setGravindex("negativo");
			daofuncaorgao.adiciona(fo);
			
			//criar nova microbiologia
			Microbiologia micro = new Microbiologia();
			micro.setAnaliseDador(analise);
			daomicro.adiciona(micro);	
			
			//criar nova virologia
			carreganovavirologia((Long)session.getAttribute("id_analise"));
					
			
			//criar nova Imunologia
			Imunologia im = new Imunologia();
			im.setAnaliseDador(analise);
			daoimuno.adiciona(im);
			
			//criar grupo sanguineo
			GrupoSanguineo gs = new GrupoSanguineo();
			gs.setAnaliseDador(analise);
			daogrupsang.adiciona(gs);
			
			
			//criar novo eletrocardiograma
			Eletrocardiograma ecg = new Eletrocardiograma();
			ecg.setAnaliseDador(analise);
			ecg.setSinoidal(true);
			daoeletro.adiciona(ecg);
			
			//criar novo radiogrfia
			Radiografia rx = new Radiografia();
			rx.setAnaliseDador(analise);
			daorx.adiciona(rx);
			
			//criar novo toraxico
			EcoToraxico eco = new EcoToraxico();
			eco.setAnaliseDador(analise);
			daotora.adiciona(eco);
			
			//criar novo Coronografia
			Coronografia corona = new Coronografia();
			corona.setAnaliseDador(analise);
			daocorona.adiciona(corona);
			
			//criar novo ECOABDRins
			EcoAbdRins ecorins = new EcoAbdRins();
			ecorins.setAnaliseDador(analise);
			daorins.adiciona(ecorins);
			
			//criar novo ECOABDFigado
			EcoAbdFigado ecofig = new EcoAbdFigado();
			ecofig.setAnaliseDador(analise);
			daofigado.adiciona(ecofig);
			
			//criar novo ECOABDPancreas
			EcoAbdPancreas ecopanc = new EcoAbdPancreas();
			ecopanc.setAnaliseDador(analise);
			daopancreas.adiciona(ecopanc);
			
			
			//criar novo Broncoescopia
			Broncoescopia bronco = new Broncoescopia();
			bronco.setAnaliseDador(analise);
			daobronco.adiciona(bronco);
			
			
			//criar novo exame f�sico
			HCExameFisico examefisico = new HCExameFisico();
			examefisico.setAnalisedador(analise);
			examefisico.setQuadrantes(quadr);
			daoexamefisico.adiciona(examefisico);
			
			//enviar mortecerebral dessa analise por causa do id para submeter upload
			model.addAttribute("mortecerebralobj", daomc.buscaPorId(mc.getId_MorteCerebral()));
			model.addAttribute("ecgobj", daoeletro.buscaPorId(ecg.getId_Eletrocardiograma()));
			model.addAttribute("rxobj", daorx.buscaPorId(rx.getId_Radiografia()));
			model.addAttribute("toraxicoobj", daotora.buscaPorId(eco.getId_EcoToraico()));
			model.addAttribute("coronografiaobj", daocorona.buscaPorId(corona.getId_Coronografia()));
			
			model.addAttribute("bdavalinicial", daobdavalinicial.buscaPorId(avalinicial.getId_BDAvaliacaoInicial()));
			
			
		}
		model.addAttribute("dador", dador);		
		model.addAttribute("glasgowcomma", daoglasg.ListaGlasgowComma());
		model.addAttribute("causademorte", daocausamorte.ListaCausaMorte());
		model.addAttribute("mecanismomorte", daomecmorte.ListaMecanismoMorte());
		model.addAttribute("etnia", daoetnia.ListaEtnia());
		model.addAttribute("dadordetalhe", daodaddet.buscadetalhesdador(id));
		model.addAttribute("id_posicao", Integer.parseInt(session.getAttribute("idposicao").toString()));
		model.addAttribute("leituraescrita",session.getAttribute("leituraescrita"));
		
	return "admin/divdetalheavaliacao";
	}
	
	
	
	@RequestMapping(value = "salvartora", method = RequestMethod.POST)
	@ResponseBody
	@Transactional
	public String salvartora(@RequestParam("datahoratora") String datahoratora, @RequestParam("exame") boolean exame, @RequestParam("vasopressores") boolean vasopressores, 
			@RequestParam("efusaoPericardial") boolean efusaoPericardial, @RequestParam("vizualizacao") int viz, @RequestParam("LVEDD") int LVEDD,	@RequestParam("LVPWD") int LVPWD, 
			@RequestParam("LA") int LA, @RequestParam("Morfologia") int morfologia, @RequestParam("LVESD") int LVESD, @RequestParam("LVPWS") int LVPWS, @RequestParam("IVSS") int IVSS, @RequestParam("LVEFS") int LVEFS, 
			@RequestParam("IVSD") int IVSD, @RequestParam("LVEFT") int LVEFT, @RequestParam("LVFS") String LVFS, @RequestParam("LVFD") String LVFD, @RequestParam("LVWMD") String LVWMD, 
			@RequestParam("RVESD") int RVESD, @RequestParam("RVEDD") int RVEDD, @RequestParam("RVTAPASE") int RVTAPASE, @RequestParam("RA") int RA, @RequestParam("RVF") String RVF, 
			@RequestParam("RVM") String RVM, @RequestParam("RVD") String RVD, @RequestParam("aortaDiametro") int aortaDiametro,	@RequestParam("aortaAscedente") int aortaAscedente, 
			@RequestParam("aortaObservacoes") String aortaObservacoes, @RequestParam("MAP") int MAP, @RequestParam("CVP") int CVP, @RequestParam("aorticaEstadoUm") String aorticaEstadoUm, 
			@RequestParam("aorticaEstadoDois") String aorticaEstadoDois, @RequestParam("mitralEstadoUm") String mitralEstadoUm, 
			@RequestParam("mitralEstadoDois") String mitralEstadoDois, @RequestParam("tricuspidalEstadoUm") String tricuspidalEstadoUm,
			@RequestParam("tricuspidalEstadoDois") String tricuspidalEstadoDois, @RequestParam("pulmonarEstadoUm") String pulmonarEstadoUm,
			@RequestParam("pulmonarEstadoDois") String pulmonarEstadoDois, @RequestParam("BPM") int bpm, 
			@RequestParam("notasecotoraxicoexame") String notasecotoraxicoexame, @RequestParam("severidadeve") int severidadeve, HttpSession session) throws ParseException
	{
		Long id_analise = (Long) session.getAttribute("id_analise");
		EcoToraxico eco2 = daotora.ListaEcoToraxico(id_analise);

		DateFormat dum = new SimpleDateFormat("dd/MM/yyyy, HH:mm");
		Date date = dum.parse(datahoratora);
		Calendar cal = Calendar.getInstance();
		cal.setTime(date);

		eco2.setAortaAscedente(aortaAscedente);
		eco2.setAortaDiametro(aortaDiametro);
		eco2.setAortaObservacoes(aortaObservacoes);
		eco2.setAorticaEstadoDois(aorticaEstadoDois);
		eco2.setAorticaEstadoUm(aorticaEstadoUm);
		eco2.setBPM(bpm);
		eco2.setCVP(CVP);
		eco2.setDataToraxico(cal);
		eco2.setEfusaoPericardial(efusaoPericardial);
		eco2.setExame(exame);
		eco2.setIVSD(IVSD);
		eco2.setIVSS(IVSS);
		eco2.setLA(LA);
		eco2.setLVEDD(LVEDD);
		eco2.setLVEFS(LVEFS);
		eco2.setLVEFT(LVEFT);
		eco2.setLVESD(LVESD);
		eco2.setLVFD(LVFD);
		eco2.setLVFS(LVFS);
		eco2.setMorfologiatoraxico(morfologia);
		eco2.setLVPWD(LVPWD);
		eco2.setLVPWS(LVPWS);
		eco2.setLVWMD(LVWMD);
		eco2.setMAP(MAP);
		eco2.setMitralEstadoDois(mitralEstadoDois);
		eco2.setMitralEstadoUm(mitralEstadoUm);
		eco2.setNotas(notasecotoraxicoexame);
		eco2.setPulmonarEstadoDois(pulmonarEstadoDois);
		eco2.setPulmonarEstadoUm(pulmonarEstadoUm);
		eco2.setRA(RA);
		eco2.setRVD(RVD);
		eco2.setRVEDD(RVEDD);
		eco2.setRVESD(RVESD);
		eco2.setRVF(RVF);
		eco2.setRVM(RVM);
		eco2.setRVTAPASE(RVTAPASE);
		eco2.setTricuspidalEstadoDois(tricuspidalEstadoDois);
		eco2.setTricuspidalEstadoUm(tricuspidalEstadoUm);
		eco2.setVasopressores(vasopressores);
		eco2.setVizualizacao(viz);
		eco2.setSeveridadeve(severidadeve);
		eco2.setStatusharmecocardio(true);
		eco2.setDatagravacao(Calendar.getInstance());
		
		daotora.atualiza(eco2);
		
		return "true";
	}

	@RequestMapping(value = "salvarbronco", method = RequestMethod.POST)
	@ResponseBody
	@Transactional
	public String salvarbronco(@RequestParam("datahorabronco") String datahorabronco, @RequestParam("traqueia") int traqueia, @RequestParam("brdireito") int brdireito, 
			@RequestParam("bresquerdo") int bresquerdo, @RequestParam("brsuplementar") int brsuplementar, @RequestParam("secrecaobrdireito") int secrecaobrdireito, @RequestParam("aspiracao") int aspiracao,
			@RequestParam("secrecaobresquerdo") int secrecaobresquerdo, @RequestParam("secrecaobrsuplementar") int secrecaobrsuplementar, @RequestParam("amostralab") boolean amostralab, 
			@RequestParam("orificiosbrdireito") int orificiosbrdireito, @RequestParam("orificiosbresquerdo") int orificiosbresquerdo, @RequestParam("orificiosbrsuplementar") int orificiosbrsuplementar,
			@RequestParam("lesoes") boolean lesoes, @RequestParam("notasbronco") String notasbronco, HttpSession session) throws ParseException
	{
		Long id_analise = (Long) session.getAttribute("id_analise");
		Broncoescopia co2 = daobronco.ListaBroncoescopia(id_analise);

		DateFormat dum = new SimpleDateFormat("dd/MM/yyyy, HH:mm");
		Date date = dum.parse(datahorabronco);
		Calendar cal = Calendar.getInstance();
		cal.setTime(date);
		co2.setAmostralab(amostralab);
		co2.setBrdireito(brdireito);
		co2.setBresquerdo(bresquerdo);
		co2.setBrsuplementar(brsuplementar);
		co2.setDataBroncoescopia(cal);
		co2.setLesoes(lesoes);
		co2.setNotas(notasbronco);
		co2.setSecrecaobrdireito(secrecaobrdireito);
		co2.setSecrecaobresquerdo(secrecaobresquerdo);
		co2.setSecrecaobrsuplementar(secrecaobrsuplementar);
		co2.setTraqueia(traqueia);
		co2.setAspiracao(aspiracao);
		co2.setOrificiosbrdireito(orificiosbrdireito);
		co2.setOrificiosbresquerdo(orificiosbresquerdo);
		co2.setOrificiosbrsuplementar(orificiosbrsuplementar);
		co2.setStatusharmbronco(true);
		co2.setDatagravacao(Calendar.getInstance());
		daobronco.atualiza(co2);
		
		return "true";
	}
	
	@RequestMapping(value = "salvarcorona", method = RequestMethod.POST)
	@ResponseBody
	@Transactional
	public String salvarcorona(@RequestParam("datahoracorona") String datahoracorona, @RequestParam("notascorona") String notascorona, HttpSession session) throws ParseException
	{
		Long id_analise = (Long) session.getAttribute("id_analise");
		Coronografia co2 = daocorona.ListaCoronografia(id_analise);

		DateFormat dum = new SimpleDateFormat("dd/MM/yyyy, HH:mm");
		Date date = dum.parse(datahoracorona);
		Calendar cal = Calendar.getInstance();
		cal.setTime(date);

		co2.setDataCoronografia(cal);
		co2.setNotas(notascorona);
		co2.setStatusharmcoron(true);
		co2.setDatagravacao(Calendar.getInstance());
		daocorona.atualiza(co2);
		
		return "true";
	}

	@RequestMapping(value = "salvarrins", method = RequestMethod.POST)
	@ResponseBody
	@Transactional
	public String salvarrins(@RequestParam("datahorarins") String datahorarins, @RequestParam("lesoes") boolean lesoes, @RequestParam("notasrins") String notasrins,
			@RequestParam("calculos") boolean calculos, @RequestParam("obstrucoes") boolean obstrucoes, @RequestParam("comp") int comp, 
			@RequestParam("larg") int larg, @RequestParam("esp") int esp, @RequestParam("morfo") int morfo, 
			@RequestParam("calculos2") boolean calculos2, @RequestParam("obstrucoes2") boolean obstrucoes2, @RequestParam("comp2") int comp2, 
			@RequestParam("larg2") int larg2, @RequestParam("esp2") int esp2, @RequestParam("morfo2") int morfo2,HttpSession session) throws ParseException
	{
		Long id_analise = (Long) session.getAttribute("id_analise");
		EcoAbdRins er2 = daorins.ListaEcoAbdFigado(id_analise);

		DateFormat dum = new SimpleDateFormat("dd/MM/yyyy, HH:mm");
		Date date = dum.parse(datahorarins);
		Calendar cal = Calendar.getInstance();
		cal.setTime(date);
		
		er2.setDataEco(cal);
		er2.setLesoes(lesoes);
		er2.setNotas(notasrins);
		er2.setCalculos(calculos);
		er2.setObstrucoes(obstrucoes);
		er2.setComprimento(comp);
		er2.setEspessura(esp);
		er2.setLargura(larg);
		er2.setMorfologia(morfo);
		
		er2.setCalculos2(calculos2);
		er2.setObstrucoes2(obstrucoes2);
		er2.setComprimento2(comp2);
		er2.setEspessura2(esp2);
		er2.setLargura2(larg2);
		er2.setMorfologia2(morfo2);
		er2.setStatusharmecorins(true);
		er2.setDatagravacao(Calendar.getInstance());
		daorins.atualiza(er2);
		
		return "true";
	}
	
	@RequestMapping(value = "salvarpancreas", method = RequestMethod.POST)
	@ResponseBody
	@Transactional
	public String salvarpancreas(@RequestParam("datahorapancreas") String datahorapancreas, @RequestParam("lesoes") boolean lesoes, @RequestParam("notaspancreas") String notaspancreas, 
			@RequestParam("parenchymapancreas") int parenchymapancreas, @RequestParam("calcificacao") boolean calcificacao ,@RequestParam("pancreatite") boolean pancreatite, HttpSession session) throws ParseException
	{
		Long id_analise = (Long) session.getAttribute("id_analise");
		EcoAbdPancreas ep2 = daopancreas.ListaEcoPancreas(id_analise);

		DateFormat dum = new SimpleDateFormat("dd/MM/yyyy, HH:mm");
		Date date = dum.parse(datahorapancreas);
		Calendar cal = Calendar.getInstance();
		cal.setTime(date);

		ep2.setCalcificacao(calcificacao);
		ep2.setDataEco(cal);
		ep2.setLesoes(lesoes);
		ep2.setNotas(notaspancreas);
		ep2.setPancreatite(pancreatite);
		ep2.setParenchyma(parenchymapancreas);
		ep2.setStatusharmecopancreas(true);
		ep2.setDatagravacao(Calendar.getInstance());
		daopancreas.atualiza(ep2);
		
		return "true";
	}

	@RequestMapping(value = "salvarfigado", method = RequestMethod.POST)
	@ResponseBody
	@Transactional
	public String salvarfigado(@RequestParam("datahorafigado") String datahorafigado, @RequestParam("lesoes") boolean lesoes, @RequestParam("notasfigado") String notasfigado, 
			@RequestParam("dimensao") int dimensao, @RequestParam("cm") int cm, @RequestParam("parenchyma") int parenchyma, @RequestParam("bordo") int bordo, 
			@RequestParam("viasBiliares") int viasBiliares, @RequestParam("veiaPorta") int veiaPorta, @RequestParam("visicula") int visicula, HttpSession session) throws ParseException
	{
		Long id_analise = (Long) session.getAttribute("id_analise");
		EcoAbdFigado ef2 = daofigado.ListaEcoAbdFigado(id_analise);

		DateFormat dum = new SimpleDateFormat("dd/MM/yyyy, HH:mm");
		Date date = dum.parse(datahorafigado);
		Calendar cal = Calendar.getInstance();
		cal.setTime(date);

		ef2.setBordo(bordo);
		ef2.setCm(cm);
		ef2.setDataEco(cal);
		ef2.setDimensao(dimensao);
		ef2.setLesoes(lesoes);
		ef2.setNotas(notasfigado);
		ef2.setParenchyma(parenchyma);
		ef2.setVeiaPorta(veiaPorta);
		ef2.setViasBiliares(viasBiliares);
		ef2.setVisicula(visicula);
		ef2.setStatusharmecofigado(true);
		ef2.setDatagravacao(Calendar.getInstance());
		daofigado.atualiza(ef2);
		
		return "true";
	}
	
	@RequestMapping(value = "salvarrx", method = RequestMethod.POST)
	@ResponseBody
	@Transactional
	public String salvarrx(@RequestParam("datahorarx") String datahorarx, @RequestParam("um") int um, @RequestParam("dois") int dois, @RequestParam("tres") int tres, @RequestParam("notas") String notas, HttpSession session) throws ParseException
	{
		Long id_analise = (Long) session.getAttribute("id_analise");
		Radiografia rx2 = daorx.ListaRadiografia(id_analise);

		DateFormat dum = new SimpleDateFormat("dd/MM/yyyy, HH:mm");
		Date date = dum.parse(datahorarx);
		Calendar cal = Calendar.getInstance();
		cal.setTime(date);
		
		rx2.setDataRadiografia(cal);
		rx2.setNotas(notas);
		rx2.setValorDois(dois);
		rx2.setValortres(tres);
		rx2.setValorUm(um);
		rx2.setStatusharmrx(true);
		rx2.setDatagravacao(Calendar.getInstance());
		daorx.atualiza(rx2);
		
		return "true";
	}
		
	@RequestMapping(value = "salvarecg", method = RequestMethod.POST)
	@ResponseBody
	@Transactional
	public String salvarecg(@RequestParam("datahoraecg") String datahoraecg, @RequestParam("sinoidal") boolean sinoidal, @RequestParam("bloqueioAV") boolean bloqueioAV, @RequestParam("arrAtrial") boolean arrAtrial, 
			@RequestParam("arrVentri") boolean arrVentri, @RequestParam("qrs") int qrs, 
			@RequestParam("notaseletrocardiograma") String notaseletrocardiograma, @RequestParam("qtc") int qtc, @RequestParam("stt") int stt, @RequestParam("ms") int ms,
			@RequestParam("hipertofia") int hipertofia, HttpSession session) throws ParseException
	{
		Long id_analise = (Long) session.getAttribute("id_analise");
		Eletrocardiograma ecg2 = daoeletro.ListaEletrocardiograma(id_analise);

		DateFormat dum = new SimpleDateFormat("dd/MM/yyyy, HH:mm");
		Date date = dum.parse(datahoraecg);
		Calendar cal = Calendar.getInstance();
		cal.setTime(date);
		
		ecg2.setArrAtrial(arrAtrial);
		ecg2.setArrVentri(arrVentri);
		ecg2.setBloqueioAV(bloqueioAV);
		ecg2.setHipertofia(hipertofia);
		ecg2.setMs(ms);
		ecg2.setNotas(notaseletrocardiograma);
		ecg2.setDataExame(cal);
		ecg2.setQrs(qrs);
		ecg2.setQtc(qtc);
		ecg2.setSinoidal(sinoidal);
		ecg2.setStt(stt);
		ecg2.setStatusharmecg(true);
		ecg2.setDatagravacao(Calendar.getInstance());
		daoeletro.atualiza(ecg2);
		
		return "true";
	}
	
	@RequestMapping(value = "salvarexamefisicobotao", method = RequestMethod.POST)
	@ResponseBody
	@Transactional
	public String salvarexamefisicobotao(HCExameFisico ef, Quadrantes q , HttpSession session)
	{
		
		Long id_analise = (Long) session.getAttribute("id_analise");
		
		//grava quadrantes do exame f�sico:
		daoquadrantes.atualiza(q);
		
		//grava exame f�sico
		HCExameFisico ef2 = daoexamefisico.buscaexamefisico(id_analise);
		ef2.setAltura(ef.getAltura());
		ef2.setAparencia(ef.isAparencia());
		ef2.setEspecificarexame(ef.getEspecificarexame());
		ef2.setEspecificar_quadrantes(ef.getEspecificar_quadrantes());
		ef2.setEtnia(ef.getEtnia());
		ef2.setEvidocularesanormais(ef.isEvidocularesanormais());
		ef2.setHepatomegalia(ef.isHepatomegalia());
		ef2.setIctericia(ef.isIctericia());
		ef2.setLesoescutaneas(ef.isLesoescutaneas());
		ef2.setLesoesgenitais(ef.isLesoesgenitais());
		ef2.setLesoesnecroticas(ef.isLesoesnecroticas());
		ef2.setLesoesperianais(ef.isLesoesperianais());
		ef2.setNoduloslinfaticos(ef.isNoduloslinfaticos());
		ef2.setPerabdominal(ef.getPerabdominal());
		ef2.setPertoracico(ef.getPertoracico());
		ef2.setPeso(ef.getPeso());
		ef2.setPontosbrancosboca(ef.isPontosbrancosboca());
		ef2.setPuncoes(ef.isPuncoes());
		ef2.setTatpiercings(ef.isTatpiercings());
		ef2.setTraumainfecao(ef.isTraumainfecao());
		ef2.setStatusharmonio(true);
		ef2.setDatagravacao(Calendar.getInstance());
		daoexamefisico.atualiza(ef2);
			
		return "true";
	}
	
	@RequestMapping(value = "salvarsitrisco", method = RequestMethod.POST)
	@ResponseBody
	@Transactional
	public String salvarsitrisco(HCSituacoesRisco sr, HttpSession session, Model model)
	{
		Long id_analise = (Long) session.getAttribute("id_analise");
		HCSituacoesRisco sr2 = daositrisco.buscaSituacoesRiscoAvaliacao(id_analise);
	
		sr2.setAlcooldrogasmetaispesados(sr.isAlcooldrogasmetaispesados());
		sr2.setComportamentosexual(sr.isComportamentosexual());
		sr2.setCorticoides(sr.isCorticoides());
		sr2.setCreutzfeldtjacob(sr.isCreutzfeldtjacob());
		sr2.setDrogasiv(sr.isDrogasiv());
		sr2.setHemodialise(sr.isHemodialise());
		sr2.setHemofilia(sr.isHemofilia());
		sr2.setInfecoesbacterianas(sr.isInfecoesbacterianas());
		sr2.setInstituicaoprisional(sr.isInstituicaoprisional());
		sr2.setIntervencaoneurocirurgica(sr.isIntervencaoneurocirurgica());
		sr2.setIrradiacaoquimioterapia(sr.isIrradiacaoquimioterapia());
		sr2.setObservacoessitrisco(sr.getObservacoessitrisco());
		sr2.setOutrossitrisco(sr.isOutrossitrisco());
		sr2.setTatuagenspiercings(sr.isTatuagenspiercings());
		sr2.setTerapeuticahormonal(sr.isTerapeuticahormonal());
		sr2.setToxicofilia(sr.isToxicofilia());
		sr2.setTransfusoes(sr.isTransfusoes());
		sr2.setTransfusoessangue1980(sr.isTransfusoessangue1980());
		sr2.setTransplanteduramater(sr.isTransplanteduramater());
		sr2.setTransplantes(sr.isTransplantes());
		sr2.setVacinacaovirus(sr.isVacinacaovirus());
		sr2.setViagens(sr.isViagens());
		sr2.setStatusharmsitrisco(true);
		sr2.setDatagravacao(Calendar.getInstance());
		daositrisco.atualiza(sr2);
		
		return "true";
	}

	@RequestMapping(value = "salvardoencapreexistentes", method = RequestMethod.POST)
	@ResponseBody
	@Transactional
	public String salvardoencapreexistentes(HCDoencasPreExistentes hcdpe, HttpSession session, Model model)
	{
		Long id_analise = (Long) session.getAttribute("id_analise");
		HCDoencasPreExistentes hcdpe2 = daodoencaspreex.buscaDoencasPreExistentesAvaliacao(id_analise);
		
		hcdpe2.setCerebrovascular(hcdpe.isCerebrovascular());
		hcdpe2.setDermatologica(hcdpe.isDermatologica());
		hcdpe2.setEam(hcdpe.isEam());
		hcdpe2.setEtiologiadesconhecida(hcdpe.isEtiologiadesconhecida());
		hcdpe2.setHematologicas(hcdpe.isHematologicas());
		hcdpe2.setHepatitesviricas(hcdpe.isHepatitesviricas());
		hcdpe2.setHiv(hcdpe.isHiv());
		hcdpe2.setInfecciosas(hcdpe.isInfecciosas());
		hcdpe2.setInfecoessistema(hcdpe.isInfecoessistema());
		hcdpe.setNeoplasia(hcdpe.isNeoplasia());
		hcdpe.setNeurodegenerativa(hcdpe.isNeurodegenerativa());
		hcdpe2.setOutrosdoencas(hcdpe.isOutrosdoencas());
		hcdpe2.setSifilisgonorreia(hcdpe.isSifilisgonorreia());
		hcdpe2.setObservacoesdoencas(hcdpe.getObservacoesdoencas());
		hcdpe2.setStatusharmdpreexist(true);
		hcdpe2.setDatagravacao(Calendar.getInstance());
		daodoencaspreex.atualiza(hcdpe2);
		
		return "true";
	}
	
	@RequestMapping(value = "salvargeral", method = RequestMethod.POST)
	@ResponseBody
	@Transactional
	public String salvargeral(HCGeral hc, HttpSession session, Model model)
	{
		Long id_analise = (Long) session.getAttribute("id_analise");
		HCGeral hc2 = daogeral.buscageralanalise(id_analise);
		
		hc2.setAlcoolismo(hc.getAlcoolismo());
		hc2.setDiabetes(hc.getDiabetes());
		hc2.setDiabetesanos(hc.getDiabetesanos());
		hc2.setHipertensao(hc.getHipertensao());
		hc2.setHipertensaoanos(hc.getHipertensaoanos());
		hc2.setTabagismo(hc.getTabagismo());
		hc2.setStatusharmgeral(true);
		hc2.setDatagravacao(Calendar.getInstance());
		daogeral.atualiza(hc2);
		
		return "true";
	}
	
	@RequestMapping(value = "salvaavinicial", method = RequestMethod.POST)
	@ResponseBody
	@Transactional
	public String salvaavinicial(BDAvaliacaoInicial av, @RequestParam("datahoraconsulta") String datahoraconsulta, @RequestParam("RENNDA") String RENNDA,
			HttpSession session, Model model) throws ParseException 
	{
		
		Long id_analise = (Long) session.getAttribute("id_analise");
		
		BDAvaliacaoInicial av2 = daobdavalinicial.buscaavaliacaoinicial(id_analise);
		
		MecanismoMorte mm = daomecmorte.buscaPorId(av.getMecanismoMorte().getId_MecanismoMorte());
		CausaMorte cm = daocausamorte.buscaPorId(av.getCausaMorte().getId_CausaMorte());
		GlasgowComma gc = daoglasg.buscaPorId(av.getGlasgowComma().getId_GlasgowComma());	
		
/*		DateFormat dum = new SimpleDateFormat("dd/MM/yyyy, HH:mm:ss");
		Date date = dum.parse(datahoraconsulta);
		Calendar cal = Calendar.getInstance();
		cal.setTime(date);*/
		
		av2.setCausaMorte(cm);
		av2.setGlasgowComma(gc);
		av2.setMecanismoMorte(mm);
		
		if(!datahoraconsulta.equals("")){
			DateFormat df = new SimpleDateFormat("dd/MM/yyyy, HH:mm:ss");
			Date date = df.parse(datahoraconsulta);
			Calendar cal = Calendar.getInstance();
			cal.setTime(date);
			av2.setDataConsultaRENNDA(cal);
		}else{
			av2.setDataConsultaRENNDA(null);
		}

		av2.setObservacoes(av.getObservacoes());
		av2.setSTATUSRENNDA(av.getSTATUSRENNDA());
		av2.setStatusharmonio(true);
		av2.setEstado(av.getEstado());
		av2.setDatagravacao(Calendar.getInstance());
		if(RENNDA.equals("0")){
			
			daoDador.mudaestadodador(5,id_analise);
			notificacaoinvalidarvalidardador(id_analise, 2);
		}else{
			daoDador.mudaestadodador(2,id_analise);
		}
		daobdavalinicial.atualiza(av2);
		
		return "true";
	}
	
	@SuppressWarnings("unchecked")
	public void notificacaoinvalidarvalidardador(Long id_analise, int validar){
		
		//validar = 1 -> validar
	//	validar = 2 -> invalidar
		
		Dador d = daoDador.buscadadoranalise(id_analise);
		//System.out.println("idhospital: "+d.getHospital().getId_Hospital());
		
		List<Long> users = daouser.buscausershospitaldadoraprovadoreprovado(d.getHospital().getId_Hospital(), d.getId_Dador());
		NotificationsController notificacao = new NotificationsController();
		JSONArray perfis = new JSONArray();
/*		perfis.add("CHD");*/
		perfis.add("IPST");
/*		perfis.add("GCCT");
		perfis.add("EC");
		perfis.add("ECC");
		perfis.add("ECT");*/
		
		if(validar == 1){
			String msg = "Dador "+d.getCodigoDador()+" validado.";	
			notificacao.envianotificacao(users, 2, perfis, "", msg, d.getCodigoDador(), 2);
		}
		if(validar == 2){
			String msg = "Dador "+d.getCodigoDador()+" n�o validado.";
			notificacao.envianotificacao(users, 3, perfis, "", msg, d.getCodigoDador(), 2);
		}
		
		
	}
	
	@RequestMapping(value = "salvags", method = RequestMethod.POST)
	@ResponseBody
	@Transactional
	public String salvags(GrupoSanguineo gs, HttpSession session, Model model) throws ParseException 
	{
		Long id_analise = (Long) session.getAttribute("id_analise");
		GrupoSanguineo gs2 = daogrupsang.buscaGrupoSanguineoAnalise(id_analise);

		gs2.setAbo(gs.getAbo());
		gs2.setRh(gs.isRh());
		gs2.setGruposangespecificacoes(gs.getGruposangespecificacoes());
		gs2.setStatusharmgruposang(true);
		gs2.setDatagravacao(Calendar.getInstance());
		daogrupsang.atualiza(gs2);
		
		return "true";
	}
	
	@RequestMapping(value = "salvamortecerebral", method = RequestMethod.POST)
	@ResponseBody
	@Transactional
	public String salvamortecerebral(MorteCerebral mc, @RequestParam("datahora1") String datahora1, 
			@RequestParam("durparagem") String durparagem,  @RequestParam("durultreanimacao") String durultreanimacao, HttpSession session, Model model) throws ParseException 
	{
		
		Long id_analise = (Long) session.getAttribute("id_analise");
		MorteCerebral mc2 = daomc.buscaMorteCerebralAvaliacao(id_analise);
		
		
		DateFormat dum = new SimpleDateFormat("dd/MM/yyyy, HH:mm:ss");
		Date date = dum.parse(datahora1);
		Calendar cal = Calendar.getInstance();
		cal.setTime(date);
		

		mc2.setP1_data(cal);
		mc2.setP1_medico1(mc.getP1_medico1());
		mc2.setP1_medico2(mc.getP1_medico2());
		mc2.setP1_om1(mc.getP1_om1());
		mc2.setP1_om2(mc.getP1_om2());
		mc2.setPcr(mc.isPcr());
		mc2.setReanimacoes(mc.getReanimacoes());
		mc2.setStatusharmonio(true);
		mc2.setDatagravacao(Calendar.getInstance());
		DateFormat horas = new SimpleDateFormat("mm:ss");
		
		if(!durparagem.isEmpty() && durparagem != null){
			
			Date h = horas.parse(durparagem);
			Calendar cal3 = Calendar.getInstance();
			cal3.setTime(h);
			mc2.setDuracaoparagem(cal3);	
		}else{
			mc2.setDuracaoparagem(null);
		}

		if(!durultreanimacao.isEmpty() && durultreanimacao != null){
			Date hreanim = horas.parse(durultreanimacao);
			Calendar cal4 = Calendar.getInstance();
			cal4.setTime(hreanim);
			mc2.setDuracaoultimareanimacao(cal4);	
		}else{
			mc2.setDuracaoultimareanimacao(null);	
		}

		daomc.atualiza(mc2);
		
		return "true";
	}
	
	@RequestMapping(value = "salvamortecerebral2", method = RequestMethod.POST)
	@ResponseBody
	@Transactional
	public String salvamortecerebral2(MorteCerebral mc, @RequestParam("datahora1") String datahora1, @RequestParam("datahora2") String datahora2,
			 @RequestParam("durparagem") String durparagem,  @RequestParam("durultreanimacao") String durultreanimacao, HttpSession session, Model model) throws ParseException 
	{
		
		Long id_analise = (Long) session.getAttribute("id_analise");
		MorteCerebral mc2 = daomc.buscaMorteCerebralAvaliacao(id_analise);
		
		DateFormat dum = new SimpleDateFormat("dd/MM/yyyy, HH:mm:ss");
		Date date = dum.parse(datahora1);
		Calendar cal = Calendar.getInstance();
		cal.setTime(date);
		
		DateFormat ddois = new SimpleDateFormat("dd/MM/yyyy, HH:mm:ss");
		Date date2 = ddois.parse(datahora2);
		Calendar cal2 = Calendar.getInstance();
		cal2.setTime(date2);		
		
		mc2.setP1_data(cal);
		mc2.setP1_medico1(mc.getP1_medico1());
		mc2.setP1_medico2(mc.getP1_medico2());
		mc2.setP1_om1(mc.getP1_om1());
		mc2.setP1_om2(mc.getP1_om2());
		mc2.setP2_conf(mc.isP2_conf());
		mc2.setP2_medico1(mc.getP2_medico1());
		mc2.setP2_medico2(mc.getP2_medico2());
		mc2.setP2_om1(mc.getP2_om1());
		mc2.setP2_om2(mc.getP2_om2());
		mc2.setP2_data(cal2);
		mc2.setPcr(mc.isPcr());
		mc2.setReanimacoes(mc.getReanimacoes());
		mc2.setStatusharmonio(true);
		mc2.setDatagravacao(Calendar.getInstance());
		
		DateFormat horas = new SimpleDateFormat("mm:ss");
		
		if(!durparagem.isEmpty() && durparagem != null){
		Date h = horas.parse(durparagem);
		Calendar cal3 = Calendar.getInstance();
		cal3.setTime(h);
		mc2.setDuracaoparagem(cal3);
		}else{
			mc2.setDuracaoparagem(null);
		}
		
		if(!durultreanimacao.isEmpty() && durultreanimacao != null){
		Date hreanim = horas.parse(durultreanimacao);
		Calendar cal4 = Calendar.getInstance();
		cal4.setTime(hreanim);
		mc2.setDuracaoultimareanimacao(cal4);
		}else{
			mc2.setDuracaoultimareanimacao(null);
		}
		
		daomc.atualiza(mc2);
		
		return "true";
	}
	
	@RequestMapping(value = "gravarorgaos", method = RequestMethod.POST)
	@ResponseBody
	@Transactional
	public String gravarorgaos(BDOrgaos bd, HttpSession session, Model model) {
		Long id_analise = (Long) session.getAttribute("id_analise");
		BDOrgaos bd1 = daobdorgaos.buscabdorgaosdaavaliacao(id_analise);

		bd1.setCoracao(bd.isCoracao());
		bd1.setCorneas(bd.isCorneas());
		bd1.setFigado(bd.isFigado());
		bd1.setTme(bd.isTme());
		bd1.setTc(bd.isTc());
		bd1.setVasos(bd.isVasos());
		bd1.setPancreas(bd.isPancreas());
		bd1.setPulmoes(bd.isPulmoes());
		bd1.setPulmaoDir(bd.isPulmaoDir());
		bd1.setPulmaoEsq(bd.isPulmaoEsq());
		bd1.setRimDireito(bd.isRimDireito());
		bd1.setRimEsquerdo(bd.isRimEsquerdo());
		bd1.setRimpar(bd.isRimpar());
		bd1.setTecidos(bd.isTecidos());
		bd1.setStatusharmonio(true);
		bd1.setDatagravacao(Calendar.getInstance());
		daobdorgaos.atualiza(bd1);

		Dador d = daoDador.buscadadoranalise(id_analise);
		if(d.getEstadoDador().getId_EstadoDador()==1){
			daoDador.mudaestadodador(2,id_analise);
		}
		notificacaoavaliacaoiniciada(id_analise);
		
		return "true";
	}
	
	@SuppressWarnings("unchecked")
	public void notificacaoavaliacaoiniciada(Long id_analise){
		
		//validar = 1 -> validar
	//	validar = 2 -> invalidar
		
		Dador d = daoDador.buscadadoranalise(id_analise);
		
		List<Long> users = daouser.buscausershospitalavaliacaoiniciada(d.getHospital().getId_Hospital());
		NotificationsController notificacao = new NotificationsController();
		JSONArray perfis = new JSONArray();
		//perfis.add("CHD");
		perfis.add("IPST");
	//	perfis.add("GCCT");
		
		String msg = "Avalia��o "+d.getCodigoDador()+" iniciada.";
		notificacao.envianotificacao(users, 4, perfis, "", msg, d.getCodigoDador(), 2);	
	}
	

	@RequestMapping(value = "gravaralteracoesdador", method = RequestMethod.POST)
	@ResponseBody
	@Transactional
	public String gravaralteracoesdador(DadorDetalhes dt, Dador d ,@RequestParam("datanascimento") String datanascimento, @RequestParam("iddador") Long iddador, @RequestParam("idetnia") Long idetnia, HttpSession session, Model model) throws ParseException 
	{
		Dador dador = daoDador.buscaPorId(iddador);
		DadorDetalhes dadordet = daodaddet.buscadetalhesdador(iddador);

		dadordet.setAltura(dt.getAltura());
		dadordet.setPeso(dt.getPeso());
		dadordet.setCodpostal(dt.getCodpostal());
		dadordet.setLocalidade(dt.getLocalidade());
		dadordet.setMorada(dt.getMorada());
		dadordet.setMoradacont(dt.getMoradacont());
		dadordet.setTelefone(dt.getTelefone());
		dadordet.setTelemovel(dt.getTelemovel());
		dadordet.setEmail(dt.getEmail());
		dadordet.setNif(dt.getNif());

		Etnia et = daoetnia.buscaPorId(idetnia);
		dadordet.setEtnia(et);

		daodaddet.atualiza(dadordet);

		
		DateFormat dd = new SimpleDateFormat("dd/MM/yyyy");
		
		if(!datanascimento.isEmpty() && datanascimento != null){
			Date datan = dd.parse(datanascimento);
			Calendar cal = Calendar.getInstance();
			cal.setTime(datan);
			dador.setDataNascimento(cal);
		}else{
			dador.setDataNascimento(null);
		}

		dador.setNomeDador(d.getNomeDador());
		dador.setSexo(d.isSexo());
		daoDador.atualiza(dador);

		session.setAttribute("dador", dador);
		return "true";
	}

	@RequestMapping(value = "abrefichadadorgeral")
	public String abrefichadadorgeral(Long id, Model model, HttpSession session) {

		model.addAttribute("dador2", (Dador) session.getAttribute("dador"));
		model.addAttribute("dadordetalhe2", daodaddet.buscadetalhesdador(id));

		return "admin/divfichageraldador";
	}

	@RequestMapping(value = "abrefichadadordetalhe")
	public String abrefichadadordetalhe(Long id, Model model,
			HttpSession session) {
		Dador dador = (Dador) session.getAttribute("dador");

		model.addAttribute("dador", dador);
		model.addAttribute("etnia", daoetnia.ListaEtnia());
		model.addAttribute("dadordetalhe", daodaddet.buscadetalhesdador(id));

		return "admin/divdetalhefichadador";
	}

// criar novas virologias com os tipos de virologias
	@Transactional
	public void carreganovavirologia(Long idanalise) {

		daoviro.carregaamostrasvirologiaanalisepretransf(idanalise);
	}

	@RequestMapping(value = "calcidadedador", method = RequestMethod.POST)
	@ResponseBody
	public String calcidadedador(@RequestParam("iddador") Long iddador,
			@RequestParam("datanasc") String datanasc, Model model,
			HttpSession session) throws ParseException {
		DateFormat di = new SimpleDateFormat("yyyy-MM-dd");


		Dador dador = daoDador.buscaPorId(iddador);
		
		if(!datanasc.equals("")){
			Date date = di.parse(datanasc);
			Calendar cal = Calendar.getInstance();
			cal.setTime(date);
			dador.setDataNascimento(cal);
		}
		
		
		
		daoDador.atualiza(dador);

		String resposta;

		if (dador.getIdade() > 1)
			resposta = dador.getIdade() + " anos";
		else
			resposta = dador.getIdade() + " ano";

		return resposta;
	}
	
	@RequestMapping(value="mudaestadodador", method = RequestMethod.POST)
	@ResponseBody
	public String mudaestadodador(@RequestParam("iddador") Long iddador, @RequestParam("estado") int estado, Model model, HttpSession session)
	{
		Dador dador = daoDador.buscaPorId(iddador);
		EstadoDador e = dador.getEstadoDador();
		e.setId_EstadoDador(5);
		
		dador.setEstadoDador(e);
		daoDador.atualiza(dador);
		
		return "Estado do dador alterado com sucesso";
	}
	
	@RequestMapping(value="filtradadores", method = RequestMethod.POST)
	public String filtradadores(@RequestParam("tipo") int tipo, @RequestParam("dataum") String dataum, @RequestParam("datadois") String datadois, Model model, RedirectAttributes ra, HttpSession session) throws ParseException
	{
		DateFormat di = new SimpleDateFormat("dd/MM/yyyy");
		DateFormat df = new SimpleDateFormat("dd/MM/yyyy");
		
		Date datei = di.parse(dataum);
		Calendar cal = Calendar.getInstance();
		cal.setTime(datei);
		
		Date datef = df.parse(datadois);
		Calendar cal2 = Calendar.getInstance();
		cal2.setTime(datef);
				
		model.addAttribute("dadores",daoDador.ListaDadorPermissaoFiltrado((Long)session.getAttribute("idposicao"), (Long)session.getAttribute("iduser"), tipo, cal, cal2,(Long)session.getAttribute("idlocalizacao")));
		
		return "admin/loads/tabeladadores";
	}
	

	
	@RequestMapping(value="carregaseparadoravaliacao")
	public String carregaseparadoravaliacao(Model model,  HttpSession session) {
	
	if((Long)session.getAttribute("idposicao")==1){

		model.addAttribute("dadores",daoDador.ListaDador());
	}
	else
	{
		model.addAttribute("dadores",daoDador.ListaDadorPermissao((Long)session.getAttribute("idposicao"), (Long)session.getAttribute("iduser"), (Long)session.getAttribute("idlocalizacao")));	
	}
	return "admin/divseparadoravaliacao";
	}
	
	
	
//----------------------------------- CARREGA DIVS HARM�NIOS --------------------------------------------------------------------------//
	
	
	
	@RequestMapping(value="carregaexamefisico")
	public String loadexamefisico(Model model,  HttpSession session) {

	Dador d = (Dador)session.getAttribute("dador");
	model.addAttribute("dadordetalhe", daodaddet.buscadetalhesdador(d.getId_Dador()));
	Long id_analise =	(Long)session.getAttribute("id_analise");
	model.addAttribute("examefisico", daoexamefisico.buscaexamefisico(id_analise));
	Quadrantes quad = daoquadrantes.buscaquadrantesanalise(id_analise);
	model.addAttribute("quadrantes", quad);
	model.addAttribute("etnia", daoetnia.ListaEtnia());
	model.addAttribute("leituraescrita",session.getAttribute("leituraescrita"));
	return "admin/divexamefisico";
	}
	

	
	@RequestMapping(value="carregargeral")
	public String loadgeral(Model model,  HttpSession session) {
	Long id_analise =	(Long)session.getAttribute("id_analise");
	model.addAttribute("dador", daoDador.buscadadoranalise(id_analise));	
	model.addAttribute("hcgeral", daogeral.buscageralanalise(id_analise));
	model.addAttribute("leituraescrita",session.getAttribute("leituraescrita"));
	return "admin/divgeral";
	}
	

	
	@RequestMapping(value="carregaprexistentes")
	public String loadpreexistentes(Model model,  HttpSession session) {
	Long id_analise =	(Long)session.getAttribute("id_analise");	
	model.addAttribute("doencas", daodoencaspreex.buscaDoencasPreExistentesAvaliacao(id_analise));	
	model.addAttribute("leituraescrita",session.getAttribute("leituraescrita"));
	return "admin/divdoencaspreexistentes";
	}

	
	@RequestMapping(value="carregasitrisco")
	public String loadsitrisco(Model model,  HttpSession session) {
	Long id_analise =	(Long)session.getAttribute("id_analise");	
	model.addAttribute("sitrisco", daositrisco.buscaSituacoesRiscoAvaliacao(id_analise));
	model.addAttribute("leituraescrita",session.getAttribute("leituraescrita"));
	return "admin/divsituacoesrisco";
	}
	
	@RequestMapping(value="carregamortecerebral")
	public String loadmortecerebral(Model model,  HttpSession session) {
	Long id_analise =	(Long)session.getAttribute("id_analise");
	model.addAttribute("dador", daoDador.buscadadoranalise(id_analise));
	model.addAttribute("mc", daomc.buscaMorteCerebralAvaliacao(id_analise));	
	model.addAttribute("leituraescrita",session.getAttribute("leituraescrita"));
	return "admin/divmortecerebral";
	}
	
	@RequestMapping(value="carregafuncoesorgao")
	public String loadfuncoesorgao(Model model, HttpSession session) {
	Long id_analise =	(Long)session.getAttribute("id_analise");
	model.addAttribute("amostras", daoamostrasfo.buscaamostrasanaliseDescendente(id_analise));
	model.addAttribute("tipoamostras", daotipoamostra.ListaTipoAmostra());
	model.addAttribute("combamostras", daoamostrasmestre.ListaAmostrasAnalise(id_analise));
	model.addAttribute("unidades", daounid.ListaUnidadesGeral());
	model.addAttribute("funcoesorgao", daofuncaorgao.buscaFuncoesOrgaoAnalise(id_analise));
	model.addAttribute("leituraescrita",session.getAttribute("leituraescrita"));
	return "admin/divfuncoesorgao";
	}
	
	
	@RequestMapping(value="carregamicrobiologia")
	public String loadmicrobiologia(Model model, HttpSession session) {
		
	Long id_analise =	(Long)session.getAttribute("id_analise");		
	model.addAttribute("microbiologia", daombanalises.ListaMBAnalisesAnalise(id_analise));	
	model.addAttribute("microbio", daomicro.buscaMicrobiologiaAnalise(id_analise));
	model.addAttribute("tipomicro", daotipoMB.ListaTipoMBAnalise());
	model.addAttribute("tipomicrorganismo", daotipoorg.ListaTipoMicroorganismo());
	model.addAttribute("leituraescrita",session.getAttribute("leituraescrita"));
	return "admin/divmicrobiologia";
	}
	
	
	@RequestMapping(value="carregavirologia")
	public String loadvirologia(Model model, HttpSession session) {	
	Long id_analise =	(Long)session.getAttribute("id_analise");	

	//verifica se j� possui todas os tipos de virologia, se true adicionar
	if(daoviro.verificatiposmestreadiciona(id_analise)){	
		daoviro.adicionavirologiaexistentes(id_analise);
	}
	
	List<Virologia> tabviro = daoviro.buscaVirologiaAnalisePretrans(id_analise);
	model.addAttribute("viro", tabviro);
	
	model.addAttribute("tipoviro", tabviro.get(0));
	model.addAttribute("leituraescrita",session.getAttribute("leituraescrita"));
	model.addAttribute("statusharmviro", daoanalisedador.buscaPorId(id_analise).isStatusharmviro());
	
	return "admin/divvirologia";
	}
	
	
	@RequestMapping(value="carregaimunologia")
	public String loadimunulogia(Model model, HttpSession session) {

		Long id_analise =	(Long)session.getAttribute("id_analise");
		model.addAttribute("imunologia", daoimuno.buscaImunologiaAnalise(id_analise));
		model.addAttribute("leituraescrita",session.getAttribute("leituraescrita"));
		return "admin/divimunologia";
	}
	
	@RequestMapping(value="carregagruposanguineo")
	public String loadgruposanguineo(Model model, HttpSession session) {
	Long id_analise =	(Long)session.getAttribute("id_analise");	
	model.addAttribute("gs", daogrupsang.buscaGrupoSanguineoAnalise(id_analise));	
	model.addAttribute("leituraescrita",session.getAttribute("leituraescrita"));
	return "admin/divgruposanguineo";
	}
	
	@RequestMapping(value="carregaoutrosexamesespecificos")
	public String loadoutrosexamesespecificos(Model model) {
	return "admin/divoutrosexamesespecificos";
	}
	
	@RequestMapping(value="carregagasimetriaeventilacao")
	public String loadgasimetriaeventilacao(Model model, HttpSession session) {
	Long id_analise =	(Long)session.getAttribute("id_analise");
	model.addAttribute("unidades", daounid.ListaUnidadesGeral());	
	
	List<GasVent> lista = daogasvent.ListaGasVentAnalise(id_analise);
	model.addAttribute("gasventilacao", lista);
	model.addAttribute("tipogasvent", daotipogasvent.ListaTipoGasVent());
	model.addAttribute("leituraescrita",session.getAttribute("leituraescrita"));
	
	model.addAttribute("statusharmgasvent", daoanalisedador.buscaPorId(id_analise).isStatusharmgasvent());
	
	return "admin/divgasimetriaeventilacao";
	}
	
	@RequestMapping(value="carregatransfusao")
	public String loadtransfusao(Model model, HttpSession session) {
	Long id_analise =	(Long)session.getAttribute("id_analise");
	Long id_dador = (Long)session.getAttribute("id_dador");
	model.addAttribute("amostrashemo", daoamostrasfo.buscatipoamostrasanalisetransfusao(id_analise));
	model.addAttribute("dadortransf", daodaddet.buscapesodador(id_dador));
	
	List<Transfusoes> transf = daotransf.buscatransfusoesanalise(id_analise);
	model.addAttribute("transf", transf);
	
	if(transf.isEmpty()){
		model.addAttribute("statusharmtransf", false);
	}else{
		model.addAttribute("statusharmtransf", true);
	}
	
	model.addAttribute("nometransf", daonometransf.ListaNomeTransfusoes());
	model.addAttribute("leituraescrita",session.getAttribute("leituraescrita"));
	return "admin/divtransfusao";
	}
	
	
	@RequestMapping(value="carregadivterapeuticas")
	public String loaddivterapeuticas(Model model, HttpSession session) {

	Long id_analise =	(Long)session.getAttribute("id_analise");
	model.addAttribute("tipoterapeuticas", daotipter.ListaTipoTerapeuticas());
	model.addAttribute("unidades", daounid.ListaUnidadesGeral());
	List<Terapeuticas> terap = daoterap.buscaterapeuticasanalise(id_analise);
	model.addAttribute("terapeuticas", terap);
	
	if(terap.isEmpty()){
		model.addAttribute("statusharmterap", false);
	}else{
		model.addAttribute("statusharmterap", true);
	}
	
	model.addAttribute("leituraescrita",session.getAttribute("leituraescrita"));
	return "admin/divterapeuticas";
	}

	@RequestMapping(value="divavaliacaoinicial")
	public String loaddivavinicial(Model model) {
		return "admin/divavaliacaoinicial";
		}
	
	@RequestMapping(value="carreganomedoc", method = RequestMethod.POST)
	public String carreganomedoc(@RequestParam("idavalinic") Long id, Model model) {
		model.addAttribute("bdavalinicial", daobdavalinicial.buscaPorId(id));
		return "admin/caminhodoc";
		}
	
	
	@RequestMapping(value="carreganomedocmc", method = RequestMethod.POST)
	public String carreganomedocmc(@RequestParam("id_MorteCerebral") Long id, Model model) {
		model.addAttribute("mc", daomc.buscaPorId(id));
		return "admin/caminhodocmc";
		}
	
	@RequestMapping(value="carreganomedocbiorenal", method = RequestMethod.POST)
	public String carreganomedocbiorenal(@RequestParam("id_biorenal") Long id, Model model) {
		model.addAttribute("biorenal", daobiorenal.buscaPorId(id));
		return "admin/caminhodocbiorenal";
		}
	
	@RequestMapping(value="carreganomedocbiohepatica", method = RequestMethod.POST)
	public String carreganomedocbiohepatica(@RequestParam("id_biohepatica") Long id, Model model) {
		model.addAttribute("biohepatica", daobiohepatica.buscaPorId(id));
		return "admin/caminhodocbiohepatica";
		}
	
	@RequestMapping(value="carreganomedocecg", method = RequestMethod.POST)
	public String carreganomedocecg(@RequestParam("idecg") Long idecg, Model model) {
		model.addAttribute("ecgnome", daoeletro.buscaPorId(idecg));
		return "admin/exames/caminhoecg";
	}
	
	@RequestMapping(value="carreganomedocrx", method = RequestMethod.POST)
	public String carreganomedocrx(@RequestParam("idrx") Long idrx, Model model) {
		model.addAttribute("rxnome", daorx.buscaPorId(idrx));
		return "admin/exames/caminhorx";
	}
	
	@RequestMapping(value="carreganomedoctoraxico", method = RequestMethod.POST)
	public String toraxico(@RequestParam("idtoraxico") Long idtoraxico, Model model) {
		model.addAttribute("toraxiconome", daotora.buscaPorId(idtoraxico));
		return "admin/exames/caminhotoraxico";
	}
	
	
	@RequestMapping(value="carreganomedoccoronografia", method = RequestMethod.POST)
	public String coronografia(@RequestParam("idcoronografia") Long idcoronografia, Model model) {
		model.addAttribute("coronografianome", daocorona.buscaPorId(idcoronografia));
		return "admin/exames/caminhocoronografia";
	}
	
	@RequestMapping(value="carregaficheiroecg", method = RequestMethod.POST)
	public String carregaficheiroecg(@RequestParam("idecg") Long idecg, Model model) {
		model.addAttribute("caminhoficheiroecg", daoeletro.buscaPorId(idecg));
		return "admin/exames/ficheiroecg";
	}
	
	@RequestMapping(value="carregaficheirorx", method = RequestMethod.POST)
	public String carregaficheirorx(@RequestParam("idrx") Long idrx, Model model) {
		model.addAttribute("caminhoficheirorx", daorx.buscaPorId(idrx));
		return "admin/exames/ficheirorx";
	}
	
	@RequestMapping(value="carregaficheirotoraxico", method = RequestMethod.POST)
	public String carregaficheirotoraxico(@RequestParam("idtoraxico") Long idtoraxico, Model model) {
		model.addAttribute("caminhoficheirotoraxico", daotora.buscaPorId(idtoraxico));
		return "admin/exames/ficheirotoraxico";
	}
	
	@RequestMapping(value="carregaficheirocoronografia", method = RequestMethod.POST)
	public String carregaficheirocoronografia(@RequestParam("idcoronografia") Long idcoronografia, Model model) {
		model.addAttribute("caminhoficheirocoronografia", daocorona.buscaPorId(idcoronografia));
		return "admin/exames/ficheirocoronografia";
	}
	
	@RequestMapping(value="carregaelectrocardiograma")
	public String carregaelectrocardiograma(Model model, HttpSession session) 
	{
		Long id_analise = (Long)session.getAttribute("id_analise");
				
		Long id_dador = (Long)session.getAttribute("id_dador");
		
		model.addAttribute("ecgcoddador", daoDador.buscaPorId(id_dador));
		model.addAttribute("dadosgeraiseletrocardiograma", daoeletro.ListaEletrocardiograma(id_analise));
		model.addAttribute("leituraescrita",session.getAttribute("leituraescrita"));
		return "admin/exames/diveletrocardiograma";
	}	
	
	@RequestMapping(value="carregaecotoraxico")
	public String carregaecotoraxico(Model model, HttpSession session) 
	{
		Long id_analise = (Long)session.getAttribute("id_analise");
		
		Long id_dador = (Long)session.getAttribute("id_dador");
		
		model.addAttribute("toraxicocoddador", daoDador.buscaPorId(id_dador));
		model.addAttribute("dadosecotoraxico", daotora.ListaEcoToraxico(id_analise));
		
		if((boolean) session.getAttribute("leituraescrita")==true){
			return "admin/exames/divecotoraxico";
		}else{
			return "admin/exames/divecotoraxicoleitura";	
			
		}
	}
	
	@RequestMapping(value="carregaradiografia")
	public String carregaradiografia(Model model, HttpSession session) 
	{
		Long id_analise = (Long)session.getAttribute("id_analise");
		
		Long id_dador = (Long)session.getAttribute("id_dador");
		
		model.addAttribute("rxcoddador", daoDador.buscaPorId(id_dador));
		model.addAttribute("lesoes", daolesaorx.buscalesoesDescendente(id_analise));
		model.addAttribute("dadosradiografia", daorx.ListaRadiografia(id_analise));
		model.addAttribute("leituraescrita",session.getAttribute("leituraescrita"));
		return "admin/exames/divradiografia";
	}
	
	@RequestMapping(value="carregacoronografia")
	public String carregacoronografia(Model model, HttpSession session) 
	{
		Long id_analise = (Long)session.getAttribute("id_analise");
		
		Long id_dador = (Long)session.getAttribute("id_dador");
		
		model.addAttribute("coronografiacoddador", daoDador.buscaPorId(id_dador));
		model.addAttribute("dadoscoronografia", daocorona.ListaCoronografia(id_analise));
		model.addAttribute("dadoslesoescoronografia", daodadoscoronografia.buscalesoesDescendente(id_analise));
		model.addAttribute("leituraescrita",session.getAttribute("leituraescrita"));
		return "admin/exames/divcoronografia";
	}	
	
	@RequestMapping(value="carregabroncoescopia")
	public String carregabroncoescopia(Model model, HttpSession session) 
	{
		Long id_analise = (Long)session.getAttribute("id_analise");
		
		model.addAttribute("dadosbroncoescopia", daobronco.ListaBroncoescopia(id_analise));
		model.addAttribute("dadospatologiabronco", daopatbronco.buscalesoesDescendente(id_analise));
		model.addAttribute("leituraescrita",session.getAttribute("leituraescrita"));
		return "admin/exames/divbroncoescopia";
	}	
	
	@RequestMapping(value="carregaecorins")
	public String carregaecorins(Model model, HttpSession session) 
	{
		Long id_analise = (Long)session.getAttribute("id_analise");
		
		model.addAttribute("dadosrins", daorins.ListaEcoAbdFigado(id_analise));
		model.addAttribute("lesoesrins", daolesaorins.buscalesoesDescendente(id_analise));
		model.addAttribute("leituraescrita",session.getAttribute("leituraescrita"));
		return "admin/exames/divecoabdominalrins";
	}
	
	@RequestMapping(value="carregaecopancreas")
	public String carregaecopancreas(Model model, HttpSession session) 
	{
		Long id_analise = (Long)session.getAttribute("id_analise");
		
		model.addAttribute("dadosecopancreas", daopancreas.ListaEcoPancreas(id_analise));
		model.addAttribute("lesoespancreas", daolesaopancreas.buscalesoesDescendente(id_analise));
		model.addAttribute("leituraescrita",session.getAttribute("leituraescrita"));
		return "admin/exames/divabdominalpancreas";
	}
	
	@RequestMapping(value="carregaecofigado")
	public String carregaecofigado(Model model, HttpSession session) 
	{
		Long id_analise = (Long)session.getAttribute("id_analise");
		
		model.addAttribute("dadosecofigado", daofigado.ListaEcoAbdFigado(id_analise));
		model.addAttribute("lesoesfigado", daolesaofigado.buscalesoesDescendente(id_analise));
		model.addAttribute("leituraescrita",session.getAttribute("leituraescrita"));
		return "admin/exames/divabdominalfigado";
	}

	//-------------------------------BI�PSIA RENAL--------------------------------------//
	
	
	@RequestMapping(value="carregabiopsiarenal")
	public String carregabiopsiarenal(Model model, HttpSession session) 
	{

		Long id_analise = (Long)session.getAttribute("id_analise");
		
		model.addAttribute("biorenal", daobiorenal.buscabiopsiarenalanalise(id_analise));
		model.addAttribute("biorenalitens",daobiorenalitens.buscabiopsiarenalitensanalise(id_analise));
		model.addAttribute("leituraescrita",session.getAttribute("leituraescrita"));
		model.addAttribute("dador", daoDador.buscadadoranalise(id_analise));
		return "admin/exames/divbiopsiarenal";
	}
	
	
	@RequestMapping(value="gravarbiopsiarenal", method= RequestMethod.POST)
	@ResponseBody
	public String gravarbiopsiarenal(@RequestParam("biopsia") String biopsia, @RequestParam("data") String data, @RequestParam("tecnica") int tecnica, @RequestParam("glomerulosesq") String glomerulosesq, 
			@RequestParam("dimensaoesq") int dimensaoesq,  @RequestParam("glomerulosdir") String glomerulosdir, @RequestParam("dimensaodir") int dimensaodir, @RequestParam("notas") String notas,
			Model model, HttpSession session) throws ParseException 
	{
		
		DateFormat df = new SimpleDateFormat("dd/MM/yyyy");
		Date date = df.parse(data);
		Calendar cal = Calendar.getInstance();
		cal.setTime(date);
		
		Long id_analise = (Long)session.getAttribute("id_analise");
		AnaliseDador a = new AnaliseDador();
		a.setId_AnaliseDador(id_analise);
		
		BiopsiaRenal bio = daobiorenal.buscabiopsiarenalanalise(id_analise);
		bio.setAnaliseDador(a);
		bio.setBiopsia(biopsia);
		bio.setData(cal);
		bio.setDimensaodir(dimensaodir);
		bio.setDimensaoesq(dimensaoesq);
		bio.setGlomerulosdir(glomerulosdir);
		bio.setGlomerulosesq(glomerulosesq);
		bio.setNotas(notas);
		bio.setTecnica(tecnica);
		bio.setStatusharmbiorenal(true);
		bio.setDatagravacao(Calendar.getInstance());
		daobiorenal.atualiza(bio);	
		return "true";
	}
	
	@RequestMapping(value="removerbiopsiarenalitem")
	@ResponseBody
	public void removerbiopsiarenalitem(@RequestParam("iditem") Long iditem, HttpSession session) 
	{
		daobiorenalitens.remove(daobiorenalitens.buscaPorId(iditem));
	}
	
	
	@RequestMapping(value="adicionarbiopsiarenalitem")
	public String adicionarbiopsiarenalitem(@RequestParam("item") int item, @RequestParam("qtd") int qtd, @RequestParam("diresq") boolean diresq, Model model, HttpSession session) 
	{
		Long id_analise = (Long)session.getAttribute("id_analise");
		BiopsiarenalItens bioitens = new BiopsiarenalItens();
		AnaliseDador a = new AnaliseDador();
		a.setId_AnaliseDador(id_analise);
		bioitens.setAnaliseDador(a);
		bioitens.setDiresq(diresq);
		bioitens.setItem(item);
		bioitens.setQuantificacao(qtd);
		daobiorenalitens.adiciona(bioitens);
		
		model.addAttribute("biorenalitens",daobiorenalitens.buscabiopsiarenalitensanalise(id_analise));
		
		if(diresq==false){
		return "admin/exames/tabbioesq";
		}
		else
		return "admin/exames/tabbiodir";	
	}
	
	
	
	//-------------------------------BI�PSIA HEPATICA--------------------------------------//
	
	
	@RequestMapping(value="carregabiopsiahepatica")
	public String carregabiopsiahepatica(Model model, HttpSession session) 
	{

		Long id_analise = (Long)session.getAttribute("id_analise");
		
		model.addAttribute("biohepatica", daobiohepatica.buscabiopsiahepaticaanalise(id_analise));
		model.addAttribute("leituraescrita",session.getAttribute("leituraescrita"));
		model.addAttribute("dador", daoDador.buscadadoranalise(id_analise));
		return "admin/exames/divbiopsiahepatica";
	}
	
	@RequestMapping(value="gravarbiopsiahepatica", method= RequestMethod.POST)
	@ResponseBody
	public String gravarbiopsiahepatica(@RequestParam("biopsia") String biopsia, @RequestParam("data") String data, @RequestParam("esteatose") boolean esteatose, @RequestParam("esteatosevesicular") int esteatosevesicular, 
			@RequestParam("esteatoselobular") int esteatoselobular,  @RequestParam("esteatosegravidade") int esteatosegravidade, @RequestParam("fibrose") boolean fibrose, @RequestParam("notas") String notas,
			@RequestParam("inflamacao") boolean inflamacao,	Model model, HttpSession session) throws ParseException 
	{
		
		DateFormat df = new SimpleDateFormat("dd/MM/yyyy");
		Date date = df.parse(data);
		Calendar cal = Calendar.getInstance();
		cal.setTime(date);
		
		Long id_analise = (Long)session.getAttribute("id_analise");
		AnaliseDador a = new AnaliseDador();
		a.setId_AnaliseDador(id_analise);
		
		BiopsiaHepatica bio = daobiohepatica.buscabiopsiahepaticaanalise(id_analise);
		bio.setAnaliseDador(a);
		bio.setBiopsia(biopsia);
		bio.setData(cal);
		bio.setEsteatose(esteatose);
		bio.setEsteatosegravidade(esteatosegravidade);
		bio.setEsteatoselobular(esteatoselobular);
		bio.setEsteatosevesicular(esteatosevesicular);
		bio.setFibrose(fibrose);
		bio.setInflamacao(inflamacao);
		bio.setNotas(notas);
		bio.setStatusharmecohepatica(true);
		bio.setDatagravacao(Calendar.getInstance());
		daobiohepatica.atualiza(bio);	
		return "true";
	}
	
//****************************Fun��es Org�o*********************************************//
	
	@RequestMapping(value="gravadivfo", method = RequestMethod.POST)
	@ResponseBody
	public String gravadivfo(FuncoesOrgao fo, Model model, HttpSession session){
		
		Long id_analise =	(Long)session.getAttribute("id_analise");
		FuncoesOrgao fo2 = daofuncaorgao.buscaFuncoesOrgaoAnalise(id_analise);
		fo2.setGravindex(fo.getGravindex());
		fo2.setStatusharmfo(true);
		daofuncaorgao.atualiza(fo2);
		return "true";
		}
	
	
	
	
	@RequestMapping(value="addamostratabela", method = RequestMethod.POST)
	public String carregalinhasamostras(@RequestParam("amostra") Long amostra, @RequestParam("data") String data, @RequestParam("nome") String nome, Model model, HttpSession session) throws ParseException {
		
		//data das amostras
		DateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mm");
		Date date = df.parse(data);
		Calendar cal = Calendar.getInstance();
		cal.setTime(date);
		
		Long id_analise =	(Long)session.getAttribute("id_analise");
		
		//actualiza status harmonio
		FuncoesOrgao fo = daofuncaorgao.buscaFuncoesOrgaoAnalise(id_analise);
		fo.setStatusharmfo(true);
		fo.setDatagravacao(Calendar.getInstance());
		daofuncaorgao.atualiza(fo);
		
		
		daoamostrasfo.adicionaitensamostras(amostra, cal, id_analise);
		return "redirect:carregafuncoesorgao";
		}
	
	
	@RequestMapping(value="carregaunidadesamostra", method = RequestMethod.POST)
	public String carregaunidadesamostra(@RequestParam("idamostra") Long idamostra ,Model model, HttpSession session){
		
		model.addAttribute("unidades", daounid.ListaUnidadesAmostraFO(idamostra));	
		return "admin/loads/combounidadesamostrafo";
	}
	
	@RequestMapping(value="carregacomboamostras", method = RequestMethod.POST)
	public String carregacomboamostras(Model model, HttpSession session){
		Long id_analise =	(Long)session.getAttribute("id_analise");
		model.addAttribute("combamostras", daoamostrasmestre.ListaAmostrasAnalise(id_analise));	
		return "admin/loads/combamostrasanalisefo";
	}
	
	@RequestMapping(value="calcminimoamostra", method = RequestMethod.POST)
	@ResponseBody
	public String calculavalorminimoamostra(@RequestParam("amostra") Long amostra, HttpSession session){
		
		Long id_analise =	(Long)session.getAttribute("id_analise");
		
		float minimo = daoamostrasfo.calculoMinimoAmostrasAnalise(id_analise, amostra);
		return String.valueOf(minimo);
	}
	
	
	@RequestMapping(value="calcmaxamostra", method = RequestMethod.POST)
	@ResponseBody
	public String calculavalormaximoamostra(@RequestParam("amostra") Long amostra, HttpSession session){
		
		Long id_analise =	(Long)session.getAttribute("id_analise");
		
		float maximo = daoamostrasfo.calculoMaximoAmostrasAnalise(id_analise, amostra);
		return String.valueOf(maximo);
	}
	
	@RequestMapping(value="calcmediaamostra", method = RequestMethod.POST)
	@ResponseBody
	public String calculavalormediaamostra(@RequestParam("amostra") Long amostra, HttpSession session){
		
		Long id_analise =	(Long)session.getAttribute("id_analise");
		
		double media = daoamostrasfo.calculoMediaAmostrasAnalise(id_analise, amostra);
		return String.valueOf(media);
	}
	
	
	@RequestMapping(value="editardadosamostra", method = RequestMethod.POST)
	public String editardadosamostra(@RequestParam("id") Long id, @RequestParam("data") String data, @RequestParam("observacoes") String observacoes, @RequestParam("valor") float valor, @RequestParam("idamostra") Long idamostra, @RequestParam("idtipo") Long idtipo, @RequestParam("unidades") Long idunidades, Model model, HttpSession session) throws ParseException{		
		Long id_analise =	(Long)session.getAttribute("id_analise");
		
		//data das amostras
		DateFormat df = new SimpleDateFormat("dd/MM/yyyy HH:mm");
		Date date = df.parse(data);
		Calendar cal = Calendar.getInstance();
		cal.setTime(date);

		AmostrasFuncoesOrgao amostra = daoamostrasfo.buscaPorId(id);

		amostra.setDatahora(cal);
		amostra.setObservamostras(observacoes);
		amostra.setValoramostra(valor);
		amostra.setAmostra(daoamostrasmestre.buscaPorId(idamostra));
		amostra.setAnaliseDador(daoanalisedador.buscaPorId(id_analise));
		amostra.setTipoAmostra(daotipoamostra.buscaPorId(idtipo));
		amostra.setUnidades(daounid.buscaPorId(idunidades));
		daoamostrasfo.atualiza(amostra);	

		return "redirect:carregafuncoesorgao";
	}
	
//*****************************Microbiologia***************************//
	
	@RequestMapping(value="addanalisetabelamb", method = RequestMethod.POST)
	public String carregalinhaanaliseMB(@RequestParam("analisemb") Long analisemb, @RequestParam("data") String data, @RequestParam("posneg") int posneg, @RequestParam("observ") String observ, 
			@RequestParam("dataresult") String dataresult, Model model, HttpSession session) throws ParseException {

		
		//data das amostras
		DateFormat df = new SimpleDateFormat("dd/MM/yyyy, HH:mm:ss");
		//DateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mm");
		Date date = df.parse(data);
		Calendar cal = Calendar.getInstance();
		cal.setTime(date);
		
		Long id_analise =	(Long)session.getAttribute("id_analise");
		
		//actualizar status harmonio
		Microbiologia micro = daomicro.buscaMicrobiologiaAnalise(id_analise);
		micro.setStatusharmmicrobio(true);
		micro.setDatagravacao(Calendar.getInstance());
		daomicro.atualiza(micro);
		
		MBAnalises analisemicrob = new MBAnalises();
		analisemicrob.setAnaliseDador(daoanalisedador.buscaPorId(id_analise));
		analisemicrob.setTipoMBAnalise(daotipoMB.buscaPorId(analisemb));
		analisemicrob.setPosneg(posneg);
		analisemicrob.setDatahora(cal);
		analisemicrob.setObservmicro(observ);
		if(!dataresult.equals("NA")){
		Date date2 = df.parse(dataresult);
		Calendar cal2 = Calendar.getInstance();
		cal2.setTime(date2);
		analisemicrob.setDatahoraresult(cal2);
		}
		daombanalises.adiciona(analisemicrob);
		
		model.addAttribute("microbiologia", daombanalises.ListaMBAnalisesAnalise(id_analise));
		return "admin/loads/analisemicrobiologianova";
		}

	
	@RequestMapping(value="editardadosanaliseamb", method = RequestMethod.POST)
	public String editardadosanaliseamb(@RequestParam("idmb") Long idmb, @RequestParam("tipomb") Long tipomb, @RequestParam("posneg") int posneg, @RequestParam("datamb") String datamb, @RequestParam("dataresult") String dataresult, @RequestParam("observmb") String observmb, Model model, HttpSession session) throws ParseException{		
		Long id_analise =	(Long)session.getAttribute("id_analise");
		
		//data das amostras
		DateFormat df = new SimpleDateFormat("dd/MM/yyyy, HH:mm:ss");
		Date date = df.parse(datamb);
		Calendar cal = Calendar.getInstance();
		cal.setTime(date);

		MBAnalises analisemicrob  = daombanalises.buscaPorId(idmb);
		analisemicrob.setAnaliseDador(daoanalisedador.buscaPorId(id_analise));
		analisemicrob.setTipoMBAnalise(daotipoMB.buscaPorId(tipomb));
		analisemicrob.setPosneg(posneg);
		analisemicrob.setDatahora(cal);
		analisemicrob.setObservmicro(observmb);
		
		if(!dataresult.equals("NA")){
			Date date2 = df.parse(dataresult);
			Calendar cal2 = Calendar.getInstance();
			cal2.setTime(date2);
			analisemicrob.setDatahoraresult(cal2);
			}
		
		daombanalises.atualiza(analisemicrob);

		model.addAttribute("microbiologia", daombanalises.ListaMBAnalisesAnalise(id_analise));
		return "admin/loads/analisemicrobiologianova";
	}
	
	
	@RequestMapping(value="eliminaanalisemb", method = RequestMethod.POST)
	@ResponseBody
	@Transactional
	public String eliminaanalisemb(@RequestParam("id_mbanalise") Long id_mbanalise) throws ParseException{		

		MBAnalises mb = daombanalises.buscaPorId(id_mbanalise);
		daombanalises.remove(mb);
		return "OK";
	}
	
	@RequestMapping(value="inseremicroorganalise", method = RequestMethod.POST)
	@ResponseBody
	public String inseremicroorganalise(@RequestParam("mbanalise") Long mbanalise, @RequestParam("idmicrorg") Long idmicrorg, @RequestParam("valor") boolean valor, Model model){		


		Microrgmbanalisemb micro = new Microrgmbanalisemb();
		micro.setMbAnalises(daombanalises.buscaPorId(mbanalise));
		micro.setMicrorganismo(daomicroorganismos.buscaPorId(idmicrorg));
		micro.setValor(valor);
		daomicrombanalise.adiciona(micro);
		
		return ""+micro.getId_microrgmbanalisemb();
	}
	
	
	@RequestMapping(value="editamicroorganalise", method = RequestMethod.POST)
	public String editamicroorganalise(@RequestParam("mbanalise") Long mbanalise, @RequestParam("microorganalise") Long microorganalise, @RequestParam("idmicrorg") Long idmicrorg, @RequestParam("valor") boolean valor, Model model){		


		Microrgmbanalisemb micro = daomicrombanalise.buscaPorId(microorganalise);
		micro.setMbAnalises(daombanalises.buscaPorId(mbanalise));
		micro.setMicrorganismo(daomicroorganismos.buscaPorId(idmicrorg));
		micro.setValor(valor);
		daomicrombanalise.atualiza(micro);

		if(valor==false){
			//limpar valores para o microorganismo removido
			daosensmicro.removesensibilidadedomicrorganismoremovido(microorganalise);
		}
		
		model.addAttribute("microorgs", micro);
		return "admin/loads/linhamicrorganismo";
	}
	
	
	@RequestMapping(value="buscamicrorganalise", method = RequestMethod.POST)
	public String buscamicrorganalise(@RequestParam("mbanalise") Long mbanalise, Model model, HttpSession session){		


		model.addAttribute("microorgs", daomicrombanalise.listaMicrorgmbanalisembanalise(mbanalise));
		if((boolean) session.getAttribute("leituraescrita")==true)
		{
			return "admin/loads/tabelamicroorganismos";
		}
		else{
			return "admin/loads/tabelamicroorganismosleitura";
		}
	}
	
	
//**********************Microbiologia sensibilidades************************************//
	
	@RequestMapping(value="abresensmicroanalise", method = RequestMethod.POST)
	public String abresensmicroanalise(@RequestParam("idmicroorg") Long idmicroorg, Model model, HttpSession session){		


		daosensmicro.ListaSensibilidadesOrganismoAnalise(idmicroorg);
		model.addAttribute("sensibilidade", daosensmicro.ListaSensibilidadesOrganismoAnalise(idmicroorg));
		
		if((boolean) session.getAttribute("leituraescrita")==true)
		{
		return "admin/loads/tabelasensibilidades";
		}else{
			return "admin/loads/tabelasensibilidadesleitura";	
	
		}
	}
	
	//insere nova sensibilidade na an�lise
	@RequestMapping(value="inseresensmicroanalise", method = RequestMethod.POST)
	@ResponseBody
	public String inseresensmicroanalise(@RequestParam("microorganismo") Long microorganismo, @RequestParam("idsens") Long idsens, @RequestParam("valor") boolean valor) throws ParseException{		

		SensMicroorganalise sensmicro = new SensMicroorganalise();
		sensmicro.setMicrorganismoanalise(daomicrombanalise.buscaPorId(microorganismo));
		sensmicro.setSensibilidade(daosensi.buscaPorId(idsens));
		sensmicro.setValorsens(valor);
		daosensmicro.adiciona(sensmicro);
		return ""+sensmicro.getId_sensmicroorganalise();
	}
	
	//altera valor da sensibilidade do microorganismo da analise
	@RequestMapping(value="editasensmicroanalise", method = RequestMethod.POST)
	@ResponseBody
	public String editasensmicroanalise(@RequestParam("sensmicro") Long sensmicro, @RequestParam("microorganismo") Long microorganismo, @RequestParam("idsens") Long idsens, @RequestParam("valor") boolean valor) throws ParseException{		

		SensMicroorganalise sensmic = daosensmicro.buscaPorId(sensmicro);
		sensmic.setMicrorganismoanalise(daomicrombanalise.buscaPorId(microorganismo));
		sensmic.setSensibilidade(daosensi.buscaPorId(idsens));
		sensmic.setValorsens(valor);
		daosensmicro.atualiza(sensmic);
		return "OK";
	}
	
	
//************************Virologia	********************//
	
	
	@RequestMapping(value="mudaprepostransviro", method = RequestMethod.POST)
	public String mudaprepostransviro(@RequestParam("tipo") boolean tipo, Model model, HttpSession session){		
		Long id_analise =	(Long)session.getAttribute("id_analise");
		
		model.addAttribute("viro", daoviro.buscaVirologiaAnalisePretrans(id_analise));

		if((boolean) session.getAttribute("leituraescrita")==true)
		{
			return "admin/divviroprepostransf";
		}else{
			
			return "admin/divviroprepostransfleitura";		
		}
	}
	
	
	@RequestMapping(value="gravavirologias", method = RequestMethod.POST)
	@ResponseBody
	public void gravavirologias(@RequestParam(value = "dados[]") String dados, HttpSession session){		
		daoviro.guardadadosviro(dados, (Long)session.getAttribute("id_analise"));
	}
	
	
	@RequestMapping(value="gravatipovirologia", method = RequestMethod.POST)
	@ResponseBody
	public void gravatipovirologia(@RequestParam(value = "tipo") boolean tipo, HttpSession session){		
		Long id_analise =	(Long)session.getAttribute("id_analise");
		daoviro.actualizatipotransfviro(tipo, id_analise);
	}
	
	@RequestMapping(value="gravastatusharmvirologia", method = RequestMethod.POST)
	@ResponseBody
	public void gravastatusharmvirologia(HttpSession session){		
		Long id_analise =	(Long)session.getAttribute("id_analise");
		AnaliseDador analise = daoanalisedador.buscaPorId(id_analise);
		analise.setStatusharmviro(true);
		analise.setDatagravacaoviro(Calendar.getInstance());
		daoanalisedador.atualiza(analise);
	}
	
	
//******************Gasimetria e Ventila��o************************//
	   
	@RequestMapping(value="registagasvent", method = RequestMethod.POST)
	public String registagasvent(@RequestParam("tipogasvent") Long tipogasvent, @RequestParam("data") String data, @RequestParam("valor") float valor, 
			@RequestParam("fio2") int fio2,  @RequestParam("observ") String observ,  Model model, @RequestParam("peep") int peep, HttpSession session) throws ParseException{		
		
		Long id_analise =	(Long)session.getAttribute("id_analise");
//		//data da gasimetria
		DateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mm");
		Date date = df.parse(data);
		Calendar cal = Calendar.getInstance();
		cal.setTime(date);		

		GasVent gv = new GasVent();
		gv.setAnaliseDador(daoanalisedador.buscaPorId(id_analise));
		gv.setDatagasvent(cal);
		gv.setPeep(peep);
		gv.setFio2gasvent(fio2);
		gv.setObservacoesgasvent(observ);
		gv.setTipoGasVent(daotipogasvent.buscaPorId(tipogasvent));
		gv.setValorgasvent(valor);
		daogasvent.adiciona(gv);

		model.addAttribute("gasventilacao", daogasvent.ListaGasVentAnalise(id_analise));
		
		return "admin/loads/tabelagasvent";

		
	}
	
	
	
	@RequestMapping(value="editargasvent", method = RequestMethod.POST)
	public String editargasvent(@RequestParam("idgasvent") Long idgasvent, @RequestParam("idtipo") Long idtipo, @RequestParam("peep") int peep, @RequestParam("valor") float valor, @RequestParam("fio2") int fio2, @RequestParam("observ") String observ, @RequestParam("data") String data, Model model, HttpSession session) throws ParseException{		
	
		Long id_analise =	(Long)session.getAttribute("id_analise");
		
		DateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mm");
		Date date = df.parse(data);
		Calendar cal = Calendar.getInstance();
		cal.setTime(date);		

		GasVent gv = daogasvent.buscaPorId(idgasvent);
		gv.setAnaliseDador(daoanalisedador.buscaPorId(id_analise));
		gv.setDatagasvent(cal);
		gv.setFio2gasvent(fio2);
		gv.setPeep(peep);
		gv.setObservacoesgasvent(observ);
		gv.setTipoGasVent(daotipogasvent.buscaPorId(idtipo));
		gv.setValorgasvent(valor);
		daogasvent.atualiza(gv);
	
		model.addAttribute("gas", gv);

		return "admin/loads/linhaatualizadagasvent";

	}
	
	@RequestMapping(value="carregaunidadesgasvent", method = RequestMethod.POST)
	public String carregaunidadesgasvent(@RequestParam("id_gasvent") Long id_gasvent, Model model){
		
	model.addAttribute("unidades", daounid.loadunidadesgasvent(id_gasvent));
		
		return "admin/loads/combounidgasvent";	
	}
	
	@RequestMapping(value="carregaunidadesgasventedit", method = RequestMethod.POST)
	public String carregaunidadesgasventedit(@RequestParam("id_gasvent") Long id_gasvent, Model model){
		
	model.addAttribute("unidades", daounid.loadunidadesgasvent(id_gasvent));
		
		return "admin/loads/combounidgasventedit";	
	}
	
	@RequestMapping(value="eliminagasvent", method = RequestMethod.POST)
	@ResponseBody
	@Transactional
	public String eliminagasvent(@RequestParam("idgasvent") Long idgasvent) throws ParseException{		

		GasVent gv = daogasvent.buscaPorId(idgasvent);
		daogasvent.remove(gv);
		return "OK";
	}
	
	@RequestMapping(value="gravastatusharmgasvent", method = RequestMethod.POST)
	@ResponseBody
	public void gravastatusharmgasvent(HttpSession session){		
		Long id_analise =	(Long)session.getAttribute("id_analise");
		AnaliseDador analise = daoanalisedador.buscaPorId(id_analise);
		analise.setStatusharmgasvent(true);
		analise.setDatagravacaogasvent(Calendar.getInstance());
		daoanalisedador.atualiza(analise);
	}
	
	
//**********************EXAMES*****************************//
	
	@RequestMapping(value = "addlesaotabela", method = RequestMethod.POST)
	public String carregalinhaslesao(@RequestParam("lesao") String lesao,
			@RequestParam("e") boolean e, @RequestParam("d") boolean d,
			@RequestParam("m") boolean m, Model model, HttpSession session){
		Long id_analise = (Long) session.getAttribute("id_analise");

		daolesaorx.adicionalesao(lesao, e, d, m, id_analise);
		model.addAttribute("lesoes",
				daolesaorx.buscalesoesDescendente(id_analise));

		return "admin/exames/examerxnova";
	}

	@RequestMapping(value = "addlesaotabelafigado", method = RequestMethod.POST)
	public String carregalinhaslesaofigado(
			@RequestParam("tipolesao") String tipolesao,
			@RequestParam("numero") int numero,
			@RequestParam("segmento") int segmento,
			@RequestParam("notas") String notas, Model model,
			HttpSession session){
		Long id_analise = (Long) session.getAttribute("id_analise");

		daolesaofigado.adicionalesao(tipolesao, numero, segmento, notas,
				id_analise);
		model.addAttribute("lesoesfigado",
				daolesaofigado.buscalesoesDescendente(id_analise));

		return "admin/exames/exameecofigadonova";
	}

	@RequestMapping(value = "addlesaotabelarins", method = RequestMethod.POST)
	public String addlesaotabelarins(
			@RequestParam("tipolesao") String tipolesao,
			@RequestParam("localizacao") String localizacao,
			@RequestParam("notas") String notas, Model model,
			HttpSession session){
		Long id_analise = (Long) session.getAttribute("id_analise");

		daolesaorins.adicionalesao(tipolesao, localizacao, notas, id_analise);
		model.addAttribute("lesoesrins",
				daolesaorins.buscalesoesDescendente(id_analise));

		return "admin/exames/exameecorinsnova";
	}

	@RequestMapping(value = "addlesaotabelapancreas", method = RequestMethod.POST)
	public String addlesaotabelapancreas(
			@RequestParam("tipolesao") String tipolesao,
			@RequestParam("localizacao") String localizacao,
			@RequestParam("notas") String notas, Model model,
			HttpSession session){
		Long id_analise = (Long) session.getAttribute("id_analise");

		daolesaopancreas.adicionalesao(tipolesao, localizacao, notas,
				id_analise);
		model.addAttribute("lesoespancreas",
				daolesaopancreas.buscalesoesDescendente(id_analise));

		return "admin/exames/exameecopancreasnova";
	}

	@RequestMapping(value="addlesaotabelacoronografia", method = RequestMethod.POST)
	public String addlesaotabelacoronografia(@RequestParam("arteria") String arteria, @RequestParam("estenose") String estenose, @RequestParam("severidade") String severidade, Model model, HttpSession session){
		
		Long id_analise = (Long) session.getAttribute("id_analise");

		daodadoscoronografia.adicionalesao(arteria, estenose, severidade,
				id_analise);
		model.addAttribute("dadoslesoescoronografia",
				daodadoscoronografia.buscalesoesDescendente(id_analise));

		return "admin/exames/examecoronografianova";
	}

	@RequestMapping(value = "addlesaotabelabroncoescopia", method = RequestMethod.POST)
	public String addlesaotabelabroncoescopia(
			@RequestParam("patologia") String patologia,
			@RequestParam("t") boolean t, @RequestParam("bd") boolean bd,
			@RequestParam("be") boolean be, @RequestParam("bs") boolean bs, Model model, HttpSession session){
		Long id_analise = (Long) session.getAttribute("id_analise");

		daopatbronco.adicionalesao(patologia, t, bd, be, bs, id_analise);
		model.addAttribute("dadospatologiabronco",
				daopatbronco.buscalesoesDescendente(id_analise));

		return "admin/exames/examebroncoescopianova";
	}

	@RequestMapping(value = "editarlesao", method = RequestMethod.POST)
	public String editarlesao(@RequestParam("idlesao") Long idlesao,
			@RequestParam("nomelesao") String nomelesao,
			@RequestParam("e") boolean e, @RequestParam("d") boolean d,
			@RequestParam("m") boolean m, Model model, HttpSession session){
		Long id_analise = (Long) session.getAttribute("id_analise");

		LesoesRadiografia lesaonova = daolesaorx.buscaPorId(idlesao);

		lesaonova.setId_LesaoRadiografia(idlesao);
		lesaonova.setLesao(nomelesao);
		lesaonova.setM(m);
		lesaonova.setPE(e);
		lesaonova.setPD(d);
		lesaonova.setAnaliseDador(daoanalisedador.buscaPorId(id_analise));

		daolesaorx.atualiza(lesaonova);

		model.addAttribute("lesoes",
				daolesaorx.buscalesoesDescendente(id_analise));
		return "admin/exames/examerxnova";
	}

	@RequestMapping(value = "editarlesaofigado", method = RequestMethod.POST)
	public String editarlesaofigado(@RequestParam("idlesao") Long idlesao,
			@RequestParam("tipolesao") String tipolesao,
			@RequestParam("numero") int numero,
			@RequestParam("segmento") int segmento,
			@RequestParam("notas") String notas, Model model,
			HttpSession session){
		Long id_analise = (Long) session.getAttribute("id_analise");

		DadosAbdFigado lesaonova = daolesaofigado.buscaPorId(idlesao);

		lesaonova.setAnaliseDador(daoanalisedador.buscaPorId(id_analise));
		lesaonova.setId_DadosAbdFigado(idlesao);
		lesaonova.setNumero(numero);
		lesaonova.setObservacoes(notas);
		lesaonova.setSegmento(segmento);
		lesaonova.setTipo(tipolesao);

		daolesaofigado.atualiza(lesaonova);

		model.addAttribute("lesoesfigado",
				daolesaofigado.buscalesoesDescendente(id_analise));
		return "admin/exames/exameecofigadonova";
	}

	@RequestMapping(value = "editarlesaorins", method = RequestMethod.POST)
	public String editarlesaorins(@RequestParam("idlesao") Long idlesao,
			@RequestParam("tipolesao") String tipolesao,
			@RequestParam("localizacao") String localizacao,
			@RequestParam("notas") String notas, Model model,
			HttpSession session){
		Long id_analise = (Long) session.getAttribute("id_analise");

		DadosAbdRins lesaonova = daolesaorins.buscaPorId(idlesao);

		lesaonova.setAnaliseDador(daoanalisedador.buscaPorId(id_analise));
		lesaonova.setId_DadosAbdRins(idlesao);
		lesaonova.setLocalizacao(localizacao);
		lesaonova.setTipo(tipolesao);
		lesaonova.setNotas(notas);

		daolesaorins.atualiza(lesaonova);

		model.addAttribute("lesoesrins",
				daolesaorins.buscalesoesDescendente(id_analise));
		return "admin/exames/exameecorinsnova";
	}

	@RequestMapping(value = "editarlesaopancreas", method = RequestMethod.POST)
	public String editarlesaopancreas(@RequestParam("idlesao") Long idlesao,
			@RequestParam("tipolesao") String tipolesao,
			@RequestParam("localizacao") String localizacao,
			@RequestParam("notas") String notas, Model model,
			HttpSession session){
		Long id_analise = (Long) session.getAttribute("id_analise");

		DadosAbdPancreas lesaonova = daolesaopancreas.buscaPorId(idlesao);

		lesaonova.setAnaliseDador(daoanalisedador.buscaPorId(id_analise));
		lesaonova.setId_DadosAbdPancreas(idlesao);
		lesaonova.setLocalizacao(localizacao);
		lesaonova.setTipo(tipolesao);
		lesaonova.setNotas(notas);

		daolesaopancreas.atualiza(lesaonova);

		model.addAttribute("lesoespancreas",
				daolesaopancreas.buscalesoesDescendente(id_analise));
		return "admin/exames/exameecopancreasnova";
	}

	@RequestMapping(value = "editarlesaocoronografia", method = RequestMethod.POST)
	public String editarlesaocoronografia(
			@RequestParam("idcoronografia") Long idcoronografia,
			@RequestParam("arteria") String arteria,
			@RequestParam("estenose") String estenose,
			@RequestParam("severidade") String severidade, Model model,
			HttpSession session){
		Long id_analise = (Long) session.getAttribute("id_analise");

		DadosCoronografia lesaonova = daodadoscoronografia
				.buscaPorId(idcoronografia);

		lesaonova.setAnaliseDador(daoanalisedador.buscaPorId(id_analise));
		lesaonova.setArteria(arteria);
		lesaonova.setEstenose(estenose);
		lesaonova.setSeveridade(severidade);
		lesaonova.setId_DadosCoronografia(idcoronografia);

		daodadoscoronografia.atualiza(lesaonova);

		model.addAttribute("dadoslesoescoronografia",
				daodadoscoronografia.buscalesoesDescendente(id_analise));
		return "admin/exames/examecoronografianova";
	}

	@RequestMapping(value = "editarlesaobroncoescopia", method = RequestMethod.POST)
	public String editarlesaobroncoescopia(
			@RequestParam("idbroncoescopia") Long idbroncoescopia,
			@RequestParam("patologia") String patologia,
			@RequestParam("t") boolean t, @RequestParam("bd") boolean bd,
			@RequestParam("be") boolean be, @RequestParam("bs") boolean bs, Model model, HttpSession session){
		Long id_analise = (Long) session.getAttribute("id_analise");

		PatologiaBroncoescopia lesaonova = daopatbronco
				.buscaPorId(idbroncoescopia);

		lesaonova.setAnaliseDador(daoanalisedador.buscaPorId(id_analise));
		lesaonova.setBD(bd);
		lesaonova.setBE(be);
		lesaonova.setT(t);
		lesaonova.setBS(bs);
		lesaonova.setPatologia(patologia);
		lesaonova.setId_PatologiaBroncoescopia(idbroncoescopia);

		daopatbronco.atualiza(lesaonova);

		model.addAttribute("dadospatologiabronco",
				daopatbronco.buscalesoesDescendente(id_analise));

		return "admin/exames/examebroncoescopianova";
	}

	@RequestMapping(value = "removerlesao", method = RequestMethod.POST)
	public String removerlesao(@RequestParam("idlesao") Long idlesao, Model model, HttpSession session){
		Long id_analise = (Long) session.getAttribute("id_analise");

		LesoesRadiografia lesaoremover = daolesaorx.buscaPorId(idlesao);
		daolesaorx.remove(lesaoremover);

		model.addAttribute("lesoes",
				daolesaorx.buscalesoesDescendente(id_analise));
		return "admin/exames/examerxnova";
	}

	@RequestMapping(value = "removerlesaofigado", method = RequestMethod.POST)
	public String removerlesaofigado(@RequestParam("idlesao") Long idlesao, Model model,
			HttpSession session) throws ParseException {
		Long id_analise = (Long) session.getAttribute("id_analise");

		DadosAbdFigado lesaonova = daolesaofigado.buscaPorId(idlesao);
		daolesaofigado.remove(lesaonova);

		model.addAttribute("lesoesfigado",
				daolesaofigado.buscalesoesDescendente(id_analise));
		return "admin/exames/exameecofigadonova";
	}

	@RequestMapping(value = "removerlesaorins", method = RequestMethod.POST)
	public String removerlesaorins(@RequestParam("idlesao") Long idlesao,  Model model,
			HttpSession session){
		Long id_analise = (Long) session.getAttribute("id_analise");

		DadosAbdRins lesaonova = daolesaorins.buscaPorId(idlesao);
		daolesaorins.remove(lesaonova);

		model.addAttribute("lesoesrins",
				daolesaorins.buscalesoesDescendente(id_analise));
		return "admin/exames/exameecorinsnova";
	}

	@RequestMapping(value = "removerlesaopancreas", method = RequestMethod.POST)
	public String removerlesaopancreas(@RequestParam("idlesao") Long idlesao, Model model,
			HttpSession session){
		Long id_analise = (Long) session.getAttribute("id_analise");

		DadosAbdPancreas lesaonova = daolesaopancreas.buscaPorId(idlesao);
		daolesaopancreas.remove(lesaonova);

		model.addAttribute("lesoespancreas",
				daolesaopancreas.buscalesoesDescendente(id_analise));
		return "admin/exames/exameecopancreasnova";
	}

	@RequestMapping(value = "removerlesaocoronografia", method = RequestMethod.POST)
	public String removerlesaocoronografia(	@RequestParam("idcoronografia") Long idcoronografia, Model model,
			HttpSession session){
		Long id_analise = (Long) session.getAttribute("id_analise");

		DadosCoronografia lesaonova = daodadoscoronografia.buscaPorId(idcoronografia);
		daodadoscoronografia.remove(lesaonova);

		model.addAttribute("dadoslesoescoronografia",
				daodadoscoronografia.buscalesoesDescendente(id_analise));
		return "admin/exames/examecoronografianova";
	}

	@RequestMapping(value = "removerlesaobroncoescopia", method = RequestMethod.POST)
	public String removerlesaobroncoescopia(
			@RequestParam("idbroncoescopia") Long idbroncoescopia, Model model, HttpSession session){
		Long id_analise = (Long) session.getAttribute("id_analise");

		PatologiaBroncoescopia lesaonova = daopatbronco.buscaPorId(idbroncoescopia);
		daopatbronco.remove(lesaonova);

		model.addAttribute("dadospatologiabronco",
				daopatbronco.buscalesoesDescendente(id_analise));

		return "admin/exames/examebroncoescopianova";
	}
	
	@RequestMapping(value = "salvarimunologia", method = RequestMethod.POST)
	@ResponseBody
	@Transactional
	public String salvarimunologia(@RequestParam("aum") double aum,@RequestParam("adois") double adois,@RequestParam("bum") double bum,@RequestParam("bdois") double bdois,
			@RequestParam("cum") double cum,@RequestParam("cdois") double cdois,@RequestParam("drum") double drum,@RequestParam("drdois") double drdois,@RequestParam("dqum") double dqum,
			@RequestParam("dqdois") double dqdois, Model model,HttpSession session) throws ParseException {
	
		Long id_analise = (Long) session.getAttribute("id_analise");
		Imunologia imatualiza = daoimuno.buscaImunologiaAnalise(id_analise);
		
		imatualiza.setAum(aum);
		imatualiza.setAdois(adois);
		imatualiza.setBum(bum);
		imatualiza.setBdois(bdois);
		imatualiza.setCum(cum);
		imatualiza.setCdois(cdois);
		imatualiza.setDrum(drum);
		imatualiza.setDrdois(drdois);
		imatualiza.setDqum(dqum);
		imatualiza.setDqdois(dqdois);
		imatualiza.setStatusharmimuno(true);
		imatualiza.setDatagravacao(Calendar.getInstance());
		daoimuno.atualiza(imatualiza);

		return "true";
	}
	
	//******************Terapeuticas************************//	
	
	@RequestMapping(value="addterapeutica", method = RequestMethod.POST)
	public String addterapeutica(@RequestParam("tipoterap") Long tipoterap, @RequestParam("data") String data, @RequestParam("unidterap") Long unidterap, @RequestParam("observ") String observ, 
			@RequestParam("dose") float dose, Model model, HttpSession session) throws ParseException {

		
		//data das amostras
		DateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mm");
		Date date = df.parse(data);
		Calendar cal = Calendar.getInstance();
		cal.setTime(date);
		
		Long id_analise =	(Long)session.getAttribute("id_analise");
		
		AnaliseDador analise = daoanalisedador.buscaPorId(id_analise);
		
		Terapeuticas ter = new Terapeuticas();
		ter.setAnaliseDador(analise);
		ter.setTipoTerapeuticas(daotipter.buscaPorId(tipoterap));
		ter.setDoseterapeutica(dose);
		ter.setDatahoraterapeutica(cal);
		ter.setObsterapeutica(observ);
		
		daoterap.adiciona(ter);
		
		
		analise.setDatagravacaoterapeuticas(Calendar.getInstance());
		daoanalisedador.atualiza(analise);
		
		model.addAttribute("terapeuticas", daoterap.buscaterapeuticasanalise(id_analise));
		return "admin/loads/tabelaterapeuticas";
		}
	
	@RequestMapping(value="editdadosterap", method = RequestMethod.POST)
	public String editdadosterap(@RequestParam("id") Long id, @RequestParam("tipoterap") Long tipoterap, @RequestParam("unidterap") Long unidterap, @RequestParam("data") String data, @RequestParam("dose") float dose, @RequestParam("observ") String observ, Model model, HttpSession session) throws ParseException{		
	
		Long id_analise =	(Long)session.getAttribute("id_analise");
		
		DateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mm");
		Date date = df.parse(data);
		Calendar cal = Calendar.getInstance();
		cal.setTime(date);		

		Terapeuticas ter2 = daoterap.buscaPorId(id);
		ter2.setAnaliseDador(daoanalisedador.buscaPorId(id_analise));
		ter2.setTipoTerapeuticas(daotipter.buscaPorId(tipoterap));
		ter2.setDatahoraterapeutica(cal);
		ter2.setDoseterapeutica(dose);
		ter2.setObsterapeutica(observ);
		daoterap.atualiza(ter2);
	
		model.addAttribute("terapeuticas", daoterap.buscaterapeuticasanalise(id_analise));
		
		return "admin/loads/tabelaterapeuticas";
	}
	
	
	
	@RequestMapping(value="carregaunidadesterapeutica", method = RequestMethod.POST)
	public String carregaunidadesterapeutica(@RequestParam("id_tipoterapeutica") Long id_tipoterapeutica, Model model){
		
	model.addAttribute("unidades", daounid.loadunidadesterapeutica(id_tipoterapeutica));
		
		return "admin/loads/combounidadesterapeutica";	
	}
	
	
	@RequestMapping(value="eliminaterapeut", method = RequestMethod.POST)
	@ResponseBody
	@Transactional
	public String eliminaterapeut(@RequestParam("idterap") Long idterap) throws ParseException{		
		
		
		Terapeuticas ter = daoterap.buscaPorId(idterap);
		daoterap.remove(ter);
		return "OK";
	}
	
	
	//******************Transfus�es************************//	
	
	
	@RequestMapping(value="addtransftabela", method = RequestMethod.POST)
	public String addtransftabela(@RequestParam("transf") Long transf, @RequestParam("vol") int vol, Model model, HttpSession session) throws ParseException {

		Long id_analise =	(Long)session.getAttribute("id_analise");
		AnaliseDador analise = daoanalisedador.buscaPorId(id_analise);
		Transfusoes tr = new Transfusoes();
		tr.setAnaliseDador(analise);
		tr.setNomeTransfusoes(daonometransf.buscaPorId(transf));
		tr.setVolunidade(vol);
		daotransf.adiciona(tr);
		
		
		analise.setDatagravacaotransfusoes(Calendar.getInstance());
		daoanalisedador.atualiza(analise);
		
		model.addAttribute("transf", daotransf.buscatransfusoesanalise(id_analise));
		return "admin/loads/tabelatransfusoes";
		}
	
	
	@RequestMapping(value="edittransftabela", method = RequestMethod.POST)
	public String edittransftabela(@RequestParam("idtransf") Long idtransf, @RequestParam("idnome") Long idnome, @RequestParam("vol") int vol, Model model) throws ParseException{		

		Transfusoes tr = daotransf.buscaPorId(idtransf);
		tr.setNomeTransfusoes(daonometransf.buscaPorId(idnome));
		tr.setVolunidade(vol);
		daotransf.atualiza(tr);
	
		model.addAttribute("transf", daotransf.buscaPorId(idtransf));
		
		return "admin/loads/linhatransfusao";
	}
	
	@RequestMapping(value="eliminatransfusao", method = RequestMethod.POST)
	@ResponseBody
	@Transactional
	public String eliminatransfusao(@RequestParam("idtransf") Long idtransf) throws ParseException{		
		
		
		Transfusoes tr = daotransf.buscaPorId(idtransf);
		daotransf.remove(tr);
		return "OK";
	}
	
	
	@RequestMapping(value="loadcombohemotransf", method = RequestMethod.POST)
	public String atualizacombohemodiluicaoamostras(Model model, HttpSession session){
		
		Long id_analise =	(Long)session.getAttribute("id_analise");
		
		model.addAttribute("amostrashemo", daoamostrasfo.buscatipoamostrasanalisetransfusao(id_analise));
		return "admin/loads/combotransfhemodiluicao";	
	}
	
	
	@RequestMapping(value="calchemodiluicao", headers = "Content-Type=application/json", method = RequestMethod.POST, produces="application/json")
	@ResponseBody 
	public String calchemodiluicao(HttpSession session){
		
		Long id_analise =	(Long)session.getAttribute("id_analise");
		
	ArrayList<Long> valores = new ArrayList<Long>();
	valores.add(daotransf.calculahemodiluicaoA(id_analise));
	valores.add(daotransf.calculahemodiluicaoB(id_analise));
	valores.add(daotransf.calculahemodiluicaoC(id_analise));
	
		return valores.toString();	
	}
	
	@RequestMapping(value="valalbuminaproteina", method = RequestMethod.POST, produces="application/json")
	@ResponseBody
	public String valalbuminaproteina(@RequestParam("id_amostra") Long id_amostra, HttpSession session){

		Long id_analise =	(Long)session.getAttribute("id_analise");
		
		List<Float> lista =  daotransf.buscaalbuminaproteinatransfusao(id_analise, id_amostra);
	

		ArrayList<String> valores = new ArrayList<String>();
		valores.add(lista.get(0).toString());
		valores.add(lista.get(1).toString());
		return valores.toString();	
	}
	
	
	//--------------------------Base Dador Avalia��o Inicial -----------------------------------//
	
	
	
	@RequestMapping(value="atualizatabdadores", method = RequestMethod.POST)
	public String atualizatabdadores(Model model, HttpSession session){
		
    	if((Long)session.getAttribute("idposicao")==1){
    		model.addAttribute("dadores",daoDador.ListaDador());
    	}
    	else{
    		model.addAttribute("dadores",daoDador.ListaDadorPermissao((Long)session.getAttribute("idposicao"), (Long)session.getAttribute("iduser"), (Long)session.getAttribute("idlocalizacao")));	
    	}
		
		return "admin/loads/tabeladadores";	
	}
	
	//---------------------------------------validar dador avalia��o pelos bot�es--------------------------//
	
	
	@RequestMapping(value="validarestado")
	public String validarestado(String iddador, int estado,Model model, HttpSession session){


		model.addAttribute("id_dador", iddador);
		model.addAttribute("estado", estado);
		return "admin/alteraestadodador";	
	}
	
	
	@RequestMapping(value="mudaestadodadorbtns", method = RequestMethod.POST)
	@ResponseBody
	public String mudaestadodadorbtns(Long iddadorpop, int idestadopop, String motivopop, HttpSession session){

		EstadoDador estado = new EstadoDador();
		estado.setId_EstadoDador(idestadopop);
		
		Dador d = daoDador.buscaPorId(iddadorpop);
		d.setEstadoDador(estado);
		d.setMotivoestado(motivopop);
		daoDador.atualiza(d);
		
		Long id_analise = (Long) session.getAttribute("id_analise");
		if(idestadopop == 5){
			//n�o validado
			notificacaoinvalidarvalidardador(id_analise, 2);
		}else{
		//	validado
			notificacaoinvalidarvalidardador(id_analise, 1);
		}
		
		return "true";	
	}
	
	
	//carrega motivo do estado do dador qd clica imagem
	@RequestMapping(value="carregamotivoestado")
	@ResponseBody
	public String carregamotivoestado(Long iddador){

		Dador d = daoDador.buscaPorId(iddador);
		
		return d.getMotivoestado();	
	}
	
	
/*	@RequestMapping(value = "/{id}/preview2", method = RequestMethod.GET)
	@ResponseBody public void getPreview2(@PathVariable("id") String id, HttpServletResponse response) {
	    try {
	        String path = "E://video//26.mov";
	        File file = new File(path);
	        response.setContentType(MediaType.APPLICATION_OCTET_STREAM_VALUE);
	        response.setHeader("Content-Disposition", "attachment; filename="+file.getName().replace(" ", "_"));
	        InputStream iStream = new FileInputStream(file);
	        IOUtils.copy(iStream, response.getOutputStream());
	        response.flushBuffer();
	    } catch (java.nio.file.NoSuchFileException e) {
	        response.setStatus(HttpStatus.NOT_FOUND.value());
	    } catch (Exception e) {
	        response.setStatus(HttpStatus.INTERNAL_SERVER_ERROR.value());
	    }
	}*/
	
}
