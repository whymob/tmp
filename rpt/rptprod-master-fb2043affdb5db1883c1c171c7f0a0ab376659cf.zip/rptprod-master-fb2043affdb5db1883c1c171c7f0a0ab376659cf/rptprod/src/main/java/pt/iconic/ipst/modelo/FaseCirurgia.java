package pt.iconic.ipst.modelo;
//package com.ipst.modelo;
//
//import java.util.List;
//
//import javax.persistence.Column;
//import javax.persistence.Entity;
//import javax.persistence.FetchType;
//import javax.persistence.GeneratedValue;
//import javax.persistence.GenerationType;
//import javax.persistence.Id;
//import javax.persistence.OneToMany;
//import javax.persistence.Table;
//
//@Entity
//@Table(name = "FASE_CIRURGIA")
//public class FaseCirurgia {
//
//	private int idfase;
//	private int fase;
//	private List<EquipaCirurgia> equipacirurgia;
//	
//	@Id
//	@GeneratedValue(strategy = GenerationType.IDENTITY)
//	@Column(name="ID_FASE")
//	public int getIdfase() {
//		return idfase;
//	}
//	public void setIdfase(int idfase) {
//		this.idfase = idfase;
//	}
//	
//	@Column(name="FASE")
//	public int getFase() {
//		return fase;
//	}
//	public void setFase(int fase) {
//		this.fase = fase;
//	}
//	
//	@OneToMany(fetch = FetchType.LAZY, mappedBy = "fase")
//	public List<EquipaCirurgia> getEquipacirurgia() {
//		return equipacirurgia;
//	}
//	public void setEquipacirurgia(List<EquipaCirurgia> equipacirurgia) {
//		this.equipacirurgia = equipacirurgia;
//	}
//	
//
//	
//	
//}
