package pt.iconic.ipst.controller;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Iterator;
import java.util.List;

import javax.servlet.http.HttpSession;

import org.json.simple.JSONArray;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import pt.iconic.ipst.dao.AmostrasFODAO;
import pt.iconic.ipst.dao.AnaliseDadorDAO;
import pt.iconic.ipst.dao.AnaliseRecetorDAO;
import pt.iconic.ipst.dao.AnaliseRecetorTransplanteDAO;
import pt.iconic.ipst.dao.AssignacaoHospitalDAO;
import pt.iconic.ipst.dao.AssignacaoOrgaosDAO;
import pt.iconic.ipst.dao.BDAvaliacaoInicialDAO;
import pt.iconic.ipst.dao.BDOrgaosDAO;
import pt.iconic.ipst.dao.BiopsiaHepaticaDAO;
import pt.iconic.ipst.dao.BiopsiaRenalDAO;
import pt.iconic.ipst.dao.CausaMorteDAO;
import pt.iconic.ipst.dao.ColheitaFigadoDAO;
import pt.iconic.ipst.dao.ColheitaGeralDAO;
import pt.iconic.ipst.dao.ColheitaPancreasDAO;
import pt.iconic.ipst.dao.ContatosRecetorDAO;
import pt.iconic.ipst.dao.DadorDAO;
import pt.iconic.ipst.dao.DadorDetalhesDAO;
import pt.iconic.ipst.dao.EntidadeDAO;
import pt.iconic.ipst.dao.EquipaCirurgiaTransplanteDAO;
import pt.iconic.ipst.dao.EquipaLocalTransplanteDAO;
import pt.iconic.ipst.dao.EquipaSuporteTransplanteDAO;
import pt.iconic.ipst.dao.EquipaTransplantesDAO;
import pt.iconic.ipst.dao.EstadoRecetorDAO;
import pt.iconic.ipst.dao.EtniaDAO;
import pt.iconic.ipst.dao.GCCTColheitaDAO;
import pt.iconic.ipst.dao.GCCTColheitaDetalheDAO;
import pt.iconic.ipst.dao.GlasgowCommaDAO;
import pt.iconic.ipst.dao.GrupoSanguineoDAO;
import pt.iconic.ipst.dao.HCDoencasPreExistentesDAO;
import pt.iconic.ipst.dao.HCExameFisicoDAO;
import pt.iconic.ipst.dao.HCGeralDAO;
import pt.iconic.ipst.dao.HCSituacoesRiscoDAO;
import pt.iconic.ipst.dao.HistoricoAssignacaoDAO;
import pt.iconic.ipst.dao.HospitalDAO;
import pt.iconic.ipst.dao.MecanismoMorteDAO;
import pt.iconic.ipst.dao.MorteCerebralDAO;
import pt.iconic.ipst.dao.OrgaosOfertaDAO;
import pt.iconic.ipst.dao.PPCardiacoDAO;
import pt.iconic.ipst.dao.PPPancreaticoDAO;
import pt.iconic.ipst.dao.PPPulmonarDAO;
import pt.iconic.ipst.dao.PPRenalDAO;
import pt.iconic.ipst.dao.PreopTerapeuticasDAO;
import pt.iconic.ipst.dao.PreoperatorioDAO;
import pt.iconic.ipst.dao.QuadrantesDAO;
import pt.iconic.ipst.dao.RecetorDetalhesDAO;
import pt.iconic.ipst.dao.RecetoresDAO;
import pt.iconic.ipst.dao.TransplantadoDetalhesDAO;
import pt.iconic.ipst.dao.TransplanteCoracaoComplicacoesDAO;
import pt.iconic.ipst.dao.TransplanteCoracaoDAO;
import pt.iconic.ipst.dao.TransplanteFigadoComplicacoesDAO;
import pt.iconic.ipst.dao.TransplanteFigadoDAO;
import pt.iconic.ipst.dao.TransplanteFigadoPerfusaoDAO;
import pt.iconic.ipst.dao.TransplanteFigadoTransfusaoDAO;
import pt.iconic.ipst.dao.TransplantePancreasComplicacoesDAO;
import pt.iconic.ipst.dao.TransplantePancreasDAO;
import pt.iconic.ipst.dao.TransplantePancreasPerfusaoDAO;
import pt.iconic.ipst.dao.TransplantePancreasTransfusaoDAO;
import pt.iconic.ipst.dao.TransplantePosOperatorioAnalisesDAO;
import pt.iconic.ipst.dao.TransplantePosOperatorioComplicacoesDAO;
import pt.iconic.ipst.dao.TransplantePosOperatorioDAO;
import pt.iconic.ipst.dao.TransplantePosOperatorioTerapeuticasDAO;
import pt.iconic.ipst.dao.TransplantePulmoesComplicacoesDAO;
import pt.iconic.ipst.dao.TransplantePulmoesComplicacoesUCIDAO;
import pt.iconic.ipst.dao.TransplantePulmoesDAO;
import pt.iconic.ipst.dao.TransplantePulmoesTransfusaoDAO;
import pt.iconic.ipst.dao.TransplanteRinsComplicacoesDAO;
import pt.iconic.ipst.dao.TransplanteRinsDAO;
import pt.iconic.ipst.dao.TransplanteRinsPerfusaoDAO;
import pt.iconic.ipst.dao.TransplanteRinsTransfusaoDAO;
import pt.iconic.ipst.dao.TransplantesDAO;
import pt.iconic.ipst.dao.UnidadesDAO;
import pt.iconic.ipst.dao.UtilizadorDAO;
import pt.iconic.ipst.dao.VirologiaDAO;
import pt.iconic.ipst.dao.VirologiaRecetorDAO;
import pt.iconic.ipst.modelo.AnaliseDador;
import pt.iconic.ipst.modelo.AnaliseRecetor;
import pt.iconic.ipst.modelo.AnaliseRecetorTransplante;
import pt.iconic.ipst.modelo.AssignacaoHospital;
import pt.iconic.ipst.modelo.AssignacaoOrgaos;
import pt.iconic.ipst.modelo.BDOrgaos;
import pt.iconic.ipst.modelo.ColheitaGeral;
import pt.iconic.ipst.modelo.Dador;
import pt.iconic.ipst.modelo.EstadoAnaliseRecetor;
import pt.iconic.ipst.modelo.EstadoRecetor;
import pt.iconic.ipst.modelo.GCCTColheita;
import pt.iconic.ipst.modelo.GCCTColheitaDetalhe;
import pt.iconic.ipst.modelo.GrupoSanguineo;
import pt.iconic.ipst.modelo.Hospital;
import pt.iconic.ipst.modelo.OrgaosOferta;
import pt.iconic.ipst.modelo.PreopTerapeuticas;
import pt.iconic.ipst.modelo.Preoperatorio;
import pt.iconic.ipst.modelo.Quadrantes;
import pt.iconic.ipst.modelo.RecetorDetalhes;
import pt.iconic.ipst.modelo.Recetores;
import pt.iconic.ipst.modelo.TransplantadoDetalhes;
import pt.iconic.ipst.modelo.TransplanteCoracao;
import pt.iconic.ipst.modelo.TransplanteCoracaoComplicacoes;
import pt.iconic.ipst.modelo.TransplanteFigado;
import pt.iconic.ipst.modelo.TransplanteFigadoComplicacoes;
import pt.iconic.ipst.modelo.TransplanteFigadoPerfusao;
import pt.iconic.ipst.modelo.TransplanteFigadoTransfusao;
import pt.iconic.ipst.modelo.TransplantePancreas;
import pt.iconic.ipst.modelo.TransplantePancreasComplicacoes;
import pt.iconic.ipst.modelo.TransplantePancreasPerfusao;
import pt.iconic.ipst.modelo.TransplantePancreasTransfusao;
import pt.iconic.ipst.modelo.TransplantePosOperatorio;
import pt.iconic.ipst.modelo.TransplantePosOperatorioAnalises;
import pt.iconic.ipst.modelo.TransplantePosOperatorioComplicacoes;
import pt.iconic.ipst.modelo.TransplantePosOperatorioTerapeuticas;
import pt.iconic.ipst.modelo.TransplantePulmoes;
import pt.iconic.ipst.modelo.TransplantePulmoesComplicacoes;
import pt.iconic.ipst.modelo.TransplantePulmoesComplicacoesUCI;
import pt.iconic.ipst.modelo.TransplantePulmoesTransfusao;
import pt.iconic.ipst.modelo.TransplanteRins;
import pt.iconic.ipst.modelo.TransplanteRinsComplicacoes;
import pt.iconic.ipst.modelo.TransplanteRinsPerfusao;
import pt.iconic.ipst.modelo.TransplanteRinsTransfusao;
import pt.iconic.ipst.modelo.Transplantes;
import pt.iconic.ipst.modelo.Utilizador;
import pt.iconic.ipst.modelo.Virologia;
import pt.iconic.ipst.modelo.VirologiaRecetor;


@Controller
public class EquipaTransplanteController {

	private DadorDAO daoDador;
	private BDOrgaosDAO daobdorg;
	private GlasgowCommaDAO daoglasg;
	private CausaMorteDAO daocausamorte;
	private MecanismoMorteDAO daomecmorte;
	private EtniaDAO daoetnia;
	private DadorDetalhesDAO daodaddet;
	private BDAvaliacaoInicialDAO daobdavalinicial;
	private HCExameFisicoDAO daoexamefisico;
	private QuadrantesDAO daoquadrantes;
	private HCGeralDAO daogeral;
	private HCDoencasPreExistentesDAO daodoencaspreex;
	private HCSituacoesRiscoDAO daositrisco;
	private VirologiaDAO daoviro;
	private RecetoresDAO daorecetor;
	private RecetorDetalhesDAO daorecetordetalhe;
	private ContatosRecetorDAO daocontatosrecetor;
	private AnaliseRecetorDAO daoanaliserec;
	private VirologiaRecetorDAO daovirorecetor;
	private GrupoSanguineoDAO daogruposang;
	private MorteCerebralDAO daomc;
	private PPPancreaticoDAO daopppancreatico;
	private PreoperatorioDAO daopreoperatorio;
	private AssignacaoOrgaosDAO daoassigorg;
	private PreopTerapeuticasDAO daoterappreop;
	private TransplanteFigadoDAO daotranspfigado;
	private AnaliseDadorDAO daoanalisedador;
	private ColheitaGeralDAO daocolheitageral;
	private TransplanteFigadoPerfusaoDAO daotranspfigadoperf;
	private TransplanteFigadoComplicacoesDAO daotranspfigadocompl;
	private TransplanteFigadoTransfusaoDAO daotranspfigadotransf;
	private TransplantePancreasDAO daotransppancreas;
	private TransplantePancreasPerfusaoDAO daotransppancreasperf;
	private TransplantePancreasComplicacoesDAO daotransppancreascompl;
	private TransplantePancreasTransfusaoDAO daotransppancreastransf;
	private TransplanteCoracaoDAO daotranspcoracao;
	private TransplanteCoracaoComplicacoesDAO daotranspcoracaocompl;
	private TransplantePulmoesDAO daotransppulmoes;
	private TransplantePulmoesComplicacoesDAO daotransppulmoescompl;
	private TransplantePulmoesTransfusaoDAO daotransppulmoestransf;
	private TransplantePulmoesComplicacoesUCIDAO daotransppulmoescompluci;
	private TransplanteRinsDAO daotransprins;
	private TransplanteRinsPerfusaoDAO daotransprinsperf;
	private TransplanteRinsComplicacoesDAO daotransprinscompl;
	private TransplanteRinsTransfusaoDAO daotransprinstransf;
	private HospitalDAO daohosp;
	private EquipaLocalTransplanteDAO daoequipalocaltransplante;
	private EquipaCirurgiaTransplanteDAO daoequipacirurgiatransplante;
	private EquipaSuporteTransplanteDAO daoequipasuportetransplante;
	private UtilizadorDAO daouser;
	private AssignacaoOrgaosDAO daoAssigOrg;
	private TransplantePosOperatorioDAO daotranspposop;
	private TransplantePosOperatorioComplicacoesDAO daotranspposopcompl;
	private TransplantePosOperatorioTerapeuticasDAO daotranspposopterap;
	private TransplantePosOperatorioAnalisesDAO daotranspposopanalises;
	private AmostrasFODAO daoamostrasfo;
	private UnidadesDAO daounidades;
	private AssignacaoHospitalDAO daoAssighosp;
	private HistoricoAssignacaoDAO daohistorico;
	private OrgaosOfertaDAO daoorgaooferta;
	private PPCardiacoDAO daocardiaco;
	private PPPulmonarDAO daopppulmonar;
	private PPRenalDAO daorenal;
	private ColheitaFigadoDAO daocolheitafigado;
	private ColheitaPancreasDAO daocolheitapancreas;
	private BiopsiaHepaticaDAO daobiohepatica;
	private BiopsiaRenalDAO daobiorenal;
	private AnaliseRecetorTransplanteDAO daoanaliserectransp;
	private EstadoRecetorDAO daoestadorecetor;
	private TransplantesDAO daotransp;
	private TransplantadoDetalhesDAO daotranspdet;
	private GCCTColheitaDAO daogcctcolheita;
	private EntidadeDAO daoentidade;
	private GCCTColheitaDetalheDAO daogcctcolheitadet;
	private EquipaTransplantesDAO daoeqtransplantes;
	
	@Autowired
	public EquipaTransplanteController(DadorDAO daoDador, BDOrgaosDAO daobdorg, GlasgowCommaDAO daoglasg, CausaMorteDAO daocausamorte, MecanismoMorteDAO daomecmorte, EtniaDAO daoetnia , DadorDetalhesDAO daodaddet,
			BDAvaliacaoInicialDAO daobdavalinicial, HCExameFisicoDAO daoexamefisico , QuadrantesDAO daoquadrantes, HCGeralDAO daogeral,
			HCDoencasPreExistentesDAO daodoencaspreex, HCSituacoesRiscoDAO daositrisco, VirologiaDAO daoviro, RecetoresDAO daorecetor, RecetorDetalhesDAO daorecetordetalhe, ContatosRecetorDAO daocontatosrecetor,
			AnaliseRecetorDAO daoanaliserec, VirologiaRecetorDAO daovirorecetor, GrupoSanguineoDAO daogruposang, MorteCerebralDAO daomc, PPPancreaticoDAO daopppancreatico, PreoperatorioDAO daopreoperatorio,
			AssignacaoOrgaosDAO daoassigorg, PreopTerapeuticasDAO daoterappreop, TransplanteFigadoDAO daotranspfigado, AnaliseDadorDAO daoanalisedador, ColheitaGeralDAO daocolheitageral,
			TransplanteFigadoPerfusaoDAO daotranspfigadoperf, TransplanteFigadoComplicacoesDAO daotranspfigadocompl, TransplanteFigadoTransfusaoDAO daotranspfigadotransf,
			TransplantePancreasDAO daotransppancreas, TransplantePancreasPerfusaoDAO daotransppancreasperf, TransplantePancreasComplicacoesDAO daotransppancreascompl,
			TransplantePancreasTransfusaoDAO daotransppancreastransf, TransplanteCoracaoDAO daotranspcoracao, TransplanteCoracaoComplicacoesDAO daotranspcoracaocompl,
			TransplantePulmoesDAO daotransppulmoes, TransplantePulmoesComplicacoesDAO daotransppulmoescompl, TransplantePulmoesTransfusaoDAO daotransppulmoestransf,
			TransplantePulmoesComplicacoesUCIDAO daotransppulmoescompluci, TransplanteRinsDAO daotransprins, TransplanteRinsPerfusaoDAO daotransprinsperf,
			TransplanteRinsComplicacoesDAO daotransprinscompl, TransplanteRinsTransfusaoDAO daotransprinstransf, HospitalDAO daohosp, EquipaLocalTransplanteDAO daoequipalocaltransplante,
			EquipaCirurgiaTransplanteDAO daoequipacirurgiatransplante, EquipaSuporteTransplanteDAO daoequipasuportetransplante, UtilizadorDAO daouser, AssignacaoOrgaosDAO daoAssigOrg,
			TransplantePosOperatorioDAO daotranspposop, TransplantePosOperatorioComplicacoesDAO daotranspposopcompl, TransplantePosOperatorioTerapeuticasDAO daotranspposopterap,
			TransplantePosOperatorioAnalisesDAO daotranspposopanalises, AmostrasFODAO daoamostrasfo, UnidadesDAO daounidades, AssignacaoHospitalDAO daoAssighosp, HistoricoAssignacaoDAO daohistorico, 
			OrgaosOfertaDAO daoorgaooferta, PPCardiacoDAO daocardiaco, PPPulmonarDAO daopppulmonar, PPRenalDAO daorenal, ColheitaFigadoDAO daocolheitafigado, ColheitaPancreasDAO daocolheitapancreas, 
			BiopsiaHepaticaDAO daobiohepatica, BiopsiaRenalDAO daobiorenal, AnaliseRecetorTransplanteDAO daoanaliserectransp, EstadoRecetorDAO daoestadorecetor, TransplantesDAO daotransp, 
			TransplantadoDetalhesDAO daotranspdet, GCCTColheitaDAO daogcctcolheita, EntidadeDAO daoentidade, GCCTColheitaDetalheDAO daogcctcolheitadet, EquipaTransplantesDAO daoeqtransplantes) {
		
			this.daoDador=daoDador;
			this.daobdorg = daobdorg;
			this.daoglasg = daoglasg;
			this.daocausamorte = daocausamorte;
			this.daomecmorte = daomecmorte;
			this.daoetnia = daoetnia;
			this.daodaddet = daodaddet;
			this.daobdavalinicial = daobdavalinicial;
			this.daoexamefisico = daoexamefisico;
			this.daoquadrantes = daoquadrantes;
			this.daogeral = daogeral;
			this.daodoencaspreex = daodoencaspreex;
			this.daositrisco = daositrisco;
			this.daoviro = daoviro;
			this.daorecetor = daorecetor;
			this.daorecetordetalhe = daorecetordetalhe;
			this.daocontatosrecetor = daocontatosrecetor;
			this.daoanaliserec = daoanaliserec;
			this.daovirorecetor = daovirorecetor;
			this.daogruposang = daogruposang;
			this.daomc = daomc;
			this.daopppancreatico = daopppancreatico;
			this.daopreoperatorio = daopreoperatorio;
			this.daoassigorg = daoassigorg;
			this.daoterappreop = daoterappreop;
			this.daotranspfigado = daotranspfigado;
			this.daoanalisedador = daoanalisedador;
			this.daocolheitageral = daocolheitageral;
			this.daotranspfigadoperf = daotranspfigadoperf;
			this.daotranspfigadocompl = daotranspfigadocompl;
			this.daotranspfigadotransf = daotranspfigadotransf;
			this.daotransppancreas = daotransppancreas;
			this.daotransppancreasperf = daotransppancreasperf;
			this.daotransppancreascompl = daotransppancreascompl;
			this.daotransppancreastransf = daotransppancreastransf;
			this.daotranspcoracao = daotranspcoracao;
			this.daotranspcoracaocompl = daotranspcoracaocompl;
			this.daotransppulmoes = daotransppulmoes;
			this.daotransppulmoescompl = daotransppulmoescompl;
			this.daotransppulmoestransf = daotransppulmoestransf;
			this.daotransppulmoescompluci = daotransppulmoescompluci;
			this.daotransprins = daotransprins;
			this.daotransprinsperf = daotransprinsperf;
			this.daotransprinscompl = daotransprinscompl;
			this.daotransprinstransf = daotransprinstransf;
			this.daohosp = daohosp;
			this.daoequipalocaltransplante = daoequipalocaltransplante;
			this.daoequipacirurgiatransplante = daoequipacirurgiatransplante;
			this.daoequipasuportetransplante = daoequipasuportetransplante;
			this.daouser = daouser;
			this.daoAssigOrg = daoAssigOrg;
			this.daotranspposop = daotranspposop;
			this.daotranspposopcompl = daotranspposopcompl;
			this.daotranspposopterap = daotranspposopterap;
			this.daotranspposopanalises = daotranspposopanalises;
			this.daoamostrasfo = daoamostrasfo;
			this.daounidades = daounidades;
			this.daoAssighosp = daoAssighosp;
			this.daohistorico = daohistorico;
			this.daoorgaooferta = daoorgaooferta;
			this.daocardiaco = daocardiaco;
			this.daopppulmonar = daopppulmonar;
			this.daorenal = daorenal;
			this.daocolheitafigado = daocolheitafigado;
			this.daocolheitapancreas = daocolheitapancreas;
			this.daobiohepatica = daobiohepatica;
			this.daobiorenal = daobiorenal;
			this.daoanaliserectransp = daoanaliserectransp;
			this.daoestadorecetor = daoestadorecetor;
			this.daotransp = daotransp;
			this.daotranspdet = daotranspdet;
			this.daogcctcolheita = daogcctcolheita;
			this.daoentidade = daoentidade;
			this.daogcctcolheitadet = daogcctcolheitadet;
			this.daoeqtransplantes = daoeqtransplantes;
	}
	
	@RequestMapping(value="abretransplanteequipa")
	public String abretransplanteequipa(@RequestParam("iddador") Long iddador, @RequestParam("idanalise") Long idanalise, @RequestParam("idorgao") int idorgao, Model model, HttpSession session){
				
		Dador dador = daoDador.buscaPorId(iddador);
		
		
		
		AssignacaoOrgaos assigorg = daoassigorg.buscaassignacaoorgaodador(dador.getId_Dador(), idorgao);
		
		session.setAttribute("id_assigorgao", assigorg.getId_assignacao());	
		session.setAttribute("id_analise", idanalise);
		session.setAttribute("leituraescrita", false);

		//coloca em sessao o dador ofertas
		//session.setAttribute("dadoroferta", dador);
		session.setAttribute("dadororgao", dador);
		
		model.addAttribute("Dador", dador);
		
		session.setAttribute("orgaodadoroferta", idorgao);
		
		Long id_analise = (Long)session.getAttribute("id_analise");
		
		model.addAttribute("leituraescrita",false);
		
		model.addAttribute("dador", dador);
		model.addAttribute("glasgowcomma", daoglasg.ListaGlasgowComma());
		model.addAttribute("causademorte", daocausamorte.ListaCausaMorte());
		model.addAttribute("mecanismomorte", daomecmorte.ListaMecanismoMorte());
		BDOrgaos orgaos = daobdorg.buscabdorgaosdaavaliacao(id_analise);
		model.addAttribute("bdorgaos", orgaos);
		model.addAttribute("dadordetalhe", daodaddet.buscadetalhesdador(dador.getId_Dador()));
		model.addAttribute("bdavalinicial", daobdavalinicial.buscaavaliacaoinicial(id_analise));
		model.addAttribute("examefisico", daoexamefisico.buscaexamefisico(id_analise));
		Quadrantes quad = daoquadrantes.buscaquadrantesanalise(id_analise);
		model.addAttribute("quadrantes", quad);
		model.addAttribute("etnia", daoetnia.ListaEtnia());
		model.addAttribute("hcgeral", daogeral.buscageralanalise(id_analise));
		model.addAttribute("doencas", daodoencaspreex.buscaDoencasPreExistentesAvaliacao(id_analise));	
		model.addAttribute("sitrisco", daositrisco.buscaSituacoesRiscoAvaliacao(id_analise));
		model.addAttribute("idorgao", session.getAttribute("orgaodadoroferta"));
	
		Long idhosp = (Long) session.getAttribute("idlocalizacao");
		AssignacaoHospital assighosp = daoAssighosp.buscaassighosporgaohospital(assigorg.getId_assignacao(), idhosp);
		
		model.addAttribute("aceitacao", assighosp.getEstadoassighosp().getIdestado());
		return "eqtransplante/divdetalhe";
	}
	
//-----------------POS OPERAT�RIO-------------------------------------//	
	@RequestMapping(value="carregaseparadorposoperatorio")
	public String carregaseparadorposoperatorio(Model model, HttpSession session){

		AssignacaoOrgaos assigorg = daoAssigOrg.buscaPorId((Long)session.getAttribute("id_assigorgao"));
		
		//Se n�o existe pos operatorio cria
		TransplantePosOperatorio po = daotranspposop.buscaTransplantePosOperatorioAssigorgao(assigorg.getId_assignacao());
		if(po==null){
			TransplantePosOperatorio posop = new TransplantePosOperatorio();
			posop.setAssigorgao(assigorg);
			daotranspposop.adiciona(posop);
			model.addAttribute("posop", posop);
		}else{
			model.addAttribute("posop", po);
		}
		
		//tabela complica��es
		model.addAttribute("complposop", daotranspposopcompl.listaTranspPosOperatoriocomplassig(assigorg.getId_assignacao()));
		
		//tabela terapeuticas
		model.addAttribute("terapposop", daotranspposopterap.listaTranspPosOperatorioterapassig(assigorg.getId_assignacao()));
		
		//tabela analises
		model.addAttribute("analisesposop", daotranspposopanalises.listaTranspPosOperatorioanalisesassig(assigorg.getId_assignacao()));
		model.addAttribute("analises", daoamostrasfo.ListaAmostrasFO());
		model.addAttribute("unidades", daounidades.ListaUnidadesGeral());
		return "eqtransplante/divposoperatorio";
	}
	
	
	
	
	
	@RequestMapping(value="gravaposoperatoriotransplante")
	@ResponseBody
	public String gravaposoperatoriotransplante(TransplantePosOperatorio posop, HttpSession session){
		
		daotranspposop.atualiza(posop);
		
		return "OK";
	}
	
	
	//--------------------------------Inicio tabela complica��es posoperatorio----------------------------//


			@RequestMapping(value="adicionatranspcomplicacoesposop")
			public String adicionatranspcomplicacoesposop(@RequestParam("terapeutica") int terapeutica, @RequestParam("observacaoterap") String observacaoterap, Model model, HttpSession session){

				Long id_assignacao = (Long) session.getAttribute("id_assigorgao");
				//colheita.setAnaliseDador(daoanalisedador.buscaPorId(id_analise));
				TransplantePosOperatorioComplicacoes tf = new TransplantePosOperatorioComplicacoes();
				
				AssignacaoOrgaos assig = new AssignacaoOrgaos();
				assig.setId_assignacao(id_assignacao);
				
				tf.setAssigorgao(assig);;
				tf.setComplicacao(terapeutica);
				tf.setNotascomplicacao(observacaoterap);
				
				daotranspposopcompl.adiciona(tf);
				
				model.addAttribute("complposop", tf);
				return "eqtransplante/loads/carregalinhacomplposop";
			}



			@RequestMapping(value="gravatranspcomplicacoesposop")
			public String gravatranspcomplicacoesposop(@RequestParam("terapeutica") int terapeutica, @RequestParam("observacaoterap") String observacaoterap, @RequestParam("idcolheitaterap") Long idcolheitaterap, Model model){

				//colheita.setAnaliseDador(daoanalisedador.buscaPorId(id_analise));
				TransplantePosOperatorioComplicacoes tf = daotranspposopcompl.buscaPorId(idcolheitaterap);
				tf.setComplicacao(terapeutica);
				tf.setNotascomplicacao(observacaoterap);
				
				daotranspposopcompl.atualiza(tf);
				
				model.addAttribute("complposop", tf);
				return "eqtransplante/loads/carregalinhacomplposop";
			}


			@RequestMapping(value="deltranspcomplicacoesposop")
			@ResponseBody
			public void deltranspcomplicacoesposop(@RequestParam("idcolheitaterap") Long idcolheitaterap, Model model){

				//colheita.setAnaliseDador(daoanalisedador.buscaPorId(id_analise));
				TransplantePosOperatorioComplicacoes tf = daotranspposopcompl.buscaPorId(idcolheitaterap);

				daotranspposopcompl.remove(tf);
			}
			//-----------fim tabela complica��es posoperatorio----------------------//	
			
			
			//--------------------------------Inicio tabela terapeuticas posoperatorio----------------------------//


			@RequestMapping(value="adicionaterapiaposop")
			public String adicionaterapiaposop(@RequestParam("terapeutica") int terapeutica, @RequestParam("observacaoterap") String observacaoterap, Model model, HttpSession session){

				Long id_assignacao = (Long) session.getAttribute("id_assigorgao");
				//colheita.setAnaliseDador(daoanalisedador.buscaPorId(id_analise));
				TransplantePosOperatorioTerapeuticas tf = new TransplantePosOperatorioTerapeuticas();
				
				AssignacaoOrgaos assig = new AssignacaoOrgaos();
				assig.setId_assignacao(id_assignacao);
				
				tf.setAssigorgao(assig);;
				tf.setComplicacao(terapeutica);
				tf.setNotascomplicacao(observacaoterap);
				
				daotranspposopterap.adiciona(tf);
				
				model.addAttribute("terapposop", tf);
				return "eqtransplante/loads/carregalinhaterapposop";
			}



			@RequestMapping(value="gravaterapeuticaposop")
			public String gravaterapeuticaposop(@RequestParam("terapeutica") int terapeutica, @RequestParam("observacaoterap") String observacaoterap, @RequestParam("idcolheitaterap") Long idcolheitaterap, Model model){

				//colheita.setAnaliseDador(daoanalisedador.buscaPorId(id_analise));
				TransplantePosOperatorioTerapeuticas tf = daotranspposopterap.buscaPorId(idcolheitaterap);
				tf.setComplicacao(terapeutica);
				tf.setNotascomplicacao(observacaoterap);
				
				daotranspposopterap.atualiza(tf);
				
				model.addAttribute("terapposop", tf);
				return "eqtransplante/loads/carregalinhaterapposop";
			}


			@RequestMapping(value="delterapeuticaposop")
			@ResponseBody
			public void delterapeuticaposop(@RequestParam("idcolheitaterap") Long idcolheitaterap, Model model){

				//colheita.setAnaliseDador(daoanalisedador.buscaPorId(id_analise));
				TransplantePosOperatorioTerapeuticas tf = daotranspposopterap.buscaPorId(idcolheitaterap);

				daotranspposopterap.remove(tf);
			}
			//-----------fim tabela terapeuticas posoperatorio----------------------//	
	
			
//--------------------------------Inicio tabela analises posoperatorio----------------------------//


			@RequestMapping(value="adicionaanaliseposop")
			public String adicionaanaliseposop(@RequestParam("data") String data, @RequestParam("analise") Long analise, @RequestParam("valor") float valor, @RequestParam("unidades") Long unidades, @RequestParam("obs") String obs, Model model, HttpSession session) throws ParseException{

				
				Long id_assignacao = (Long) session.getAttribute("id_assigorgao");
			
				TransplantePosOperatorioAnalises ta = new TransplantePosOperatorioAnalises();
				
				AssignacaoOrgaos assig = new AssignacaoOrgaos();
				assig.setId_assignacao(id_assignacao);
				
				ta.setAssigorgao(assig);
				
				DateFormat df = new SimpleDateFormat("dd/MM/yyyy");
				Date date = df.parse(data);
				Calendar cal = Calendar.getInstance();
				cal.setTime(date);		
				ta.setData(cal);
				ta.setAnalise(daoamostrasfo.buscaPorId(analise));
				ta.setValor(valor);
				ta.setUnidades(daounidades.buscaPorId(unidades));
				ta.setObs(obs);
				
				daotranspposopanalises.adiciona(ta);
				
				model.addAttribute("analise", ta);
				return "eqtransplante/loads/carregalinhaanaliseposop";
			}



			@RequestMapping(value="gravaanaliseposop")
			public String gravaanaliseposop(@RequestParam("data") String data, @RequestParam("analise") Long analise, @RequestParam("valor") float valor, @RequestParam("unidades") Long unidades, @RequestParam("obs") String obs, 
					@RequestParam("idanaliseposop") Long idanaliseposop ,Model model, HttpSession session) throws ParseException{

				Long id_assignacao = (Long) session.getAttribute("id_assigorgao");
				
				TransplantePosOperatorioAnalises ta = daotranspposopanalises.buscaPorId(idanaliseposop);
				
				AssignacaoOrgaos assig = new AssignacaoOrgaos();
				assig.setId_assignacao(id_assignacao);
				
				ta.setAssigorgao(assig);
				
				DateFormat df = new SimpleDateFormat("dd/MM/yyyy");
				Date date = df.parse(data);
				Calendar cal = Calendar.getInstance();
				cal.setTime(date);		
				ta.setData(cal);
				ta.setAnalise(daoamostrasfo.buscaPorId(analise));
				ta.setValor(valor);
				ta.setUnidades(daounidades.buscaPorId(unidades));
				ta.setObs(obs);
				
				daotranspposopanalises.atualiza(ta);
				
				model.addAttribute("analise", ta);
				return "eqtransplante/loads/carregalinhaanaliseposop";
			}


			@RequestMapping(value="delanaliseposop")
			@ResponseBody
			public void delanaliseposop(@RequestParam("idcolheitaterap") Long idcolheitaterap, Model model){

				//colheita.setAnaliseDador(daoanalisedador.buscaPorId(id_analise));
				TransplantePosOperatorioAnalises tf = daotranspposopanalises.buscaPorId(idcolheitaterap);

				daotranspposopanalises.remove(tf);
			}
			
			@RequestMapping(value="carregaunidanaliseposop", method = RequestMethod.POST)
			public String carregaunidanaliseposop(@RequestParam("id_analise") Long id_analise, @RequestParam("tipo") int tipo, Model model){
				
				model.addAttribute("unidades", daounidades.ListaUnidadesAmostraFO(id_analise));
				if(tipo==1){
					return "eqtransplante/loads/combounidanaliseposop";		
				}else{
					
					return "eqtransplante/loads/combounidanaliseposopedit";
				}
				
					
			}
			
//------------------------------fim tabela analises posoperatorio----------------------//		
			
			
			
			
	
	
//-------------- FIM POS OPERATORIO---------------------------------------//
	
// -------------------- SELEC��O DE CANDIDATO-----------------------------//	
	@RequestMapping(value="carregaseparadorselecaocandidato")
	public String carregaseparadorselecaocandidato(Model model, HttpSession session){


		
		Long id_hospital = (Long)session.getAttribute("idlocalizacao");
		
		//carregar recetores desse org�o
		int idorgaooferta =  (int) session.getAttribute("orgaodadoroferta");
		
		Long idassigorg = (Long) session.getAttribute("id_assigorgao");
		
	//	System.out.println("idassigorgao: "+idassigorg);
		if(idorgaooferta==1){
			//carrega candidatos cora��o UT1
			model.addAttribute("candidatos", daorecetor.buscacandidatosorgaohospital(1L, id_hospital, idassigorg, idorgaooferta));
			//verifica se esses candidatos j� t�m an�lise
			
			return "eqtransplante/divselecaocandidato";	
		}else
		if(idorgaooferta==2){
				//carrega candidatos figado UT2
			model.addAttribute("candidatos", daorecetor.buscacandidatosorgaohospital(2L, id_hospital, idassigorg, idorgaooferta));
				
			return "eqtransplante/divselecaocandidato";		
		}else
		if(idorgaooferta==3 || idorgaooferta==4 || idorgaooferta==5){
			//carrega candidatos pulm�o UT3
			model.addAttribute("candidatos", daorecetor.buscacandidatosorgaohospital(3L, id_hospital, idassigorg, idorgaooferta));
			return "eqtransplante/divselecaocandidato";	
			
		}else
			if(idorgaooferta==6){
				//carrega candidatos p�ncreas UT4
				model.addAttribute("candidatos", daorecetor.buscacandidatosorgaohospital(4L, id_hospital, idassigorg, idorgaooferta));
				return "eqtransplante/divselecaocandidato";	
		
		}else{
			//carrega candidatos rins UT5
			model.addAttribute("candidatos", daorecetor.buscacandidatosorgaohospital(5L, id_hospital, idassigorg, idorgaooferta));
			return "eqtransplante/divselecaocandidatorins";
		}
		
	//	return null;

	}
	
	
	@RequestMapping(value="abrecandidatotransplante")
	public String abrecandidatotransplante(@RequestParam("idrecetor") Long idrecetor, Model model, HttpSession session){
		
		//idanalise do dador:
		Long id_analise = (Long)session.getAttribute("id_analise");
		//idanalise do recetor:
		Long id_analiserecetor = daoanaliserec.buscaAnaliseRecetor(idrecetor).getId_analiserecetor();
		
		//org�o a transplantar
		int idorgaooferta =  (int) session.getAttribute("orgaodadoroferta");
		
		Dador dador = (Dador) session.getAttribute("dadororgao");
		model.addAttribute("Dador", dador);
		
		GrupoSanguineo gs = daogruposang.buscaGrupoSanguineoAnalise(id_analise);
		model.addAttribute("gs", gs);
		
		Recetores rec = daorecetor.buscaPorId(idrecetor);
		
		model.addAttribute("candidato", rec);
		model.addAttribute("detalhes", daorecetordetalhe.buscadetalhesrecetor(idrecetor));
		
		String grorgrec = "";
		if(daorecetor.buscagravidaderecetor(idrecetor) == null){
			grorgrec = "Sem gravidade";
		}else{
			 grorgrec = daorecetor.buscagravidaderecetor(idrecetor).getGravidade();
		}
		
		model.addAttribute("gravidaderec", grorgrec);
		
		model.addAttribute("contatos", daocontatosrecetor.buscacontatosrecetor(id_analiserecetor));
		//carregar dados do candidato para harmonio contatos
		
		model.addAttribute("viro", daoviro.buscaVirologiaSelecaoCandidato(id_analise));
		
		//Carrega estado pela an�lise recetor transplante
		Long idassigorg = (Long) session.getAttribute("id_assigorgao");

		
		
		//verifica se existe analiserecetortransplante, se n�o existe cria
		AnaliseRecetorTransplante art = daoanaliserectransp.buscaAnaliseRecetorTransplanteOrgao(idrecetor, idassigorg);
		
		if(art == null){
			
//			System.out.println("Vazio");
			
			//criar analiserectransp
			AnaliseRecetorTransplante art2 = new AnaliseRecetorTransplante();
			art2.setAssigorgao(daoassigorg.buscaPorId(idassigorg));
			art2.setRecetor(daorecetor.buscaPorId(idrecetor));
			
			EstadoAnaliseRecetor ear = new EstadoAnaliseRecetor();
			ear.setIdestadoanalise(1);
			art2.setEstadoanaliserecetor(ear);
			daoanaliserectransp.adiciona(art2);
			model.addAttribute("analiserectransp", art2);
			
		}else{
			
			model.addAttribute("analiserectransp", art);
		}
		
		
		
		if(idorgaooferta==1){
			//coracao
			model.addAttribute("ppcardiaco", daocardiaco.ListaPPCardiacoAnalise(id_analiserecetor));
			return "eqtransplante/coracao/divdetalheselecaocandidatocoracao";
		}else
		if(idorgaooferta==3|| idorgaooferta==4 || idorgaooferta==5){
				//pulm�es
				model.addAttribute("pppulmonar", daopppulmonar.ListaPPPulmonarAnalise(id_analiserecetor));
			return "eqtransplante/pulmoes/divdetalheselecaocandidatopulmoes";
		}else
		if(idorgaooferta==2){
			//figado
			model.addAttribute("mc", daomc.buscaMorteCerebralAvaliacao(id_analise));
			model.addAttribute("diagnosticorec", daorecetor.buscadiagnosticohepatico(id_analiserecetor));
			model.addAttribute("complicacaorec", daorecetor.buscacomplicacaohepatico(id_analiserecetor));
			model.addAttribute("colheitafigado", daocolheitafigado.buscacolheitaFigadoanalise(id_analise));
			model.addAttribute("biohepatica", daobiohepatica.buscabiopsiahepaticaanalise(id_analise));
			return "eqtransplante/fig/divdetalheselecaocandidatofigado";
		}else
		if(idorgaooferta==6)
		{
			//pancreas
			model.addAttribute("mc", daomc.buscaMorteCerebralAvaliacao(id_analise));
			model.addAttribute("pppancreatico", daopppancreatico.ListaPPPancreaticoAnalise(id_analiserecetor));
			model.addAttribute("colheitapancreas", daocolheitapancreas.buscacolheitaPancreasanalise(id_analise));
			return "eqtransplante/pancreas/divdetalheselecaocandidatopancreas";	
		}else{
			model.addAttribute("mc", daomc.buscaMorteCerebralAvaliacao(id_analise));
			model.addAttribute("pprenal", daorenal.ListaPPRenalAnalise(id_analiserecetor));
			model.addAttribute("hc", daogeral.buscageralanalise(id_analise));
			model.addAttribute("critexpanalises", daoamostrasfo.buscacreatininaproteinuria(id_analise));
			model.addAttribute("biorenal", daobiorenal.buscabiopsiarenalanalise(id_analise));
			return "eqtransplante/rins/divdetalheselecaocandidatorins";	
			}
	}
	
	@RequestMapping(value="abreharmonioscandidatotransplantepancreas")
	public String abreharmonioscandidatotransplantepancreas(@RequestParam("idrecetor") Long idrecetor, Model model, HttpSession session){

		//idanalise do dador:
		Long id_analise = (Long)session.getAttribute("id_analise");
		//idanalise do recetor:
		Long id_analiserecetor = daoanaliserec.buscaAnaliseRecetor(idrecetor).getId_analiserecetor();
		
		
		Dador dador = (Dador) session.getAttribute("dadororgao");
		model.addAttribute("Dador", dador);
		
		GrupoSanguineo gs = daogruposang.buscaGrupoSanguineoAnalise(id_analise);
		model.addAttribute("gs", gs);
		
		model.addAttribute("mc", daomc.buscaMorteCerebralAvaliacao(id_analise));
		
		List<Virologia> tabviro = daoviro.buscaVirologiaAnalisePretrans(id_analise);
		model.addAttribute("viro", tabviro);
		model.addAttribute("tipoviro", tabviro.get(0));
		
		model.addAttribute("pppancreatico", daopppancreatico.ListaPPPancreaticoAnalise(id_analiserecetor));
		model.addAttribute("candidato", daorecetor.buscaPorId(idrecetor));
		
//		String grorgrec = "";
//		if(daorecetor.buscagravidaderecetor(idrecetor) == null){
//			grorgrec = "Sem gravidade";
//		}else{
//			 grorgrec = daorecetor.buscagravidaderecetor(idrecetor).getGravidade();
//		}
//		
//		model.addAttribute("gravidaderec", grorgrec);
		
	//	model.addAttribute("diagnosticorec", daorecetor.buscadiagnosticohepatico(id_analiserecetor));
	//	model.addAttribute("complicacaorec", daorecetor.buscacomplicacaohepatico(id_analiserecetor));
		
		List<VirologiaRecetor> tabvirorec = daovirorecetor.buscaVirologiaRecetorPretransplante(id_analiserecetor);
		model.addAttribute("virorec", tabvirorec);
		
		//carregar dados do candidato para harmonio contatos
		model.addAttribute("contatos", daocontatosrecetor.buscacontatosrecetor(id_analiserecetor));
		model.addAttribute("detalhes", daorecetordetalhe.buscadetalhesrecetor(idrecetor));
		
		return "eqtransplante/pancreas/divharmoniosselecaocandidatopancreas";
	}
	
	@RequestMapping(value="gravaposicaocandidato")
	@ResponseBody
	public String gravaposicaocandidato(@RequestParam("cand") Long idrecetor, @RequestParam("pos") int pos, Model model, HttpSession session){
		
	//	Recetores recetor = daorecetor.buscaPorId(idrecetor);
		
		Long idassigorg = (Long) session.getAttribute("id_assigorgao");
		
		//buscar analise recetor transplante para atualizar a posicao	
		AnaliseRecetorTransplante art = daoanaliserectransp.buscaAnaliseRecetorTransplanteOrgao(idrecetor, idassigorg);
		if(art == null){
			//criar analise recetor transplante para esse recetor e org�o com essa posi��o
			AnaliseRecetorTransplante art2 = new AnaliseRecetorTransplante();
			art2.setRecetor(daorecetor.buscaPorId(idrecetor));
			art2.setAssigorgao(daoassigorg.buscaPorId(idassigorg));
			art2.setPosicao(pos);
			EstadoAnaliseRecetor estado = new  EstadoAnaliseRecetor();
			estado.setIdestadoanalise(1);
			art2.setEstadoanaliserecetor(estado);
			daoanaliserectransp.adiciona(art2);
			
			
		}else{
			art.setPosicao(pos);
			daoanaliserectransp.atualiza(art);
		}

		
	return "OK";
	}
	
	
//----------------------FIM SELEC��O DE CANDIDATO-------------------------------------------//	

//----------------------------INICIO SEPARADOR PRE OPERATORIO-----------------------------------------------------//
	@RequestMapping(value="carregaseparadorpreoperatorio")
	public String carregaseparadorpreoperatorio(Model model, HttpSession session){
		
		AssignacaoOrgaos assigorg = daoassigorg.buscaPorId((Long)session.getAttribute("id_assigorgao"));
		

		
		//Se n�o existe pre operatorio cria
		Preoperatorio po = daopreoperatorio.buscaPreoperatorioDadorOrgao(assigorg.getId_assignacao());
		if(po==null){
			Preoperatorio preop = new Preoperatorio();
			preop.setAssigorgao(assigorg);
			daopreoperatorio.adiciona(preop);
			model.addAttribute("preoperat", preop);
		}else{
			model.addAttribute("preoperat", po);
		}

		//tabela tipo
				model.addAttribute("preopterap", daoterappreop.listacolheitapreopterapassignacao(assigorg.getId_assignacao()));
		
		return "eqtransplante/divpreoperatorio";
	}
	
	
	//----- Grava Aba Pre-Operat�rio
	@RequestMapping(value="gravapreoperatoriotransplante")
	@ResponseBody
	public String gravapreoperatoriotransplante(Preoperatorio preop, HttpSession session){
		
		daopreoperatorio.atualiza(preop);
		
		return "OK";
	}
	
//---------------Tabela Preoperat�rio terapeuticas--------------------//	
	@RequestMapping(value="adicionaterapeuticapreoperatorio")
	public String adicionaterapeuticapreoperatorio(@RequestParam("tipo") int tipo, @RequestParam("terapeutica") int terapeutica, @RequestParam("observacao") String observacao, Model model, HttpSession session){


		Long id_assignacao = (Long) session.getAttribute("id_assigorgao");
		
		PreopTerapeuticas pot = new PreopTerapeuticas();
		
		AssignacaoOrgaos assig = new AssignacaoOrgaos();
		assig.setId_assignacao(id_assignacao);
		
		pot.setAssigorgao(assig);
		pot.setTipo(tipo);
		pot.setTerapeutica(terapeutica);
		pot.setObservacoes(observacao);
		
		daoterappreop.adiciona(pot);
		
		model.addAttribute("tp", pot);
		return "eqtransplante/loads/carregalinhaterappreop";
	}



	@RequestMapping(value="gravaterapeuticapreop")
	public String gravaterapeuticapreop(@RequestParam("tipo") int tipo, @RequestParam("terapeutica") int terapeutica, @RequestParam("observacao") String observacao, @RequestParam("idpreop") Long idpreop, Model model){

		//colheita.setAnaliseDador(daoanalisedador.buscaPorId(id_analise));
		PreopTerapeuticas pot = daoterappreop.buscaPorId(idpreop);
		pot.setTipo(tipo);
		pot.setTerapeutica(terapeutica);
		pot.setObservacoes(observacao);
		
		daoterappreop.atualiza(pot);
		
		model.addAttribute("tp", pot);
		return "eqtransplante/loads/carregalinhaterappreop";
	}


	@RequestMapping(value="delterapeuticapreop")
	@ResponseBody
	public void delterapeuticapreop(@RequestParam("id_preopterap") Long id_preopterap, Model model){

		//colheita.setAnaliseDador(daoanalisedador.buscaPorId(id_analise));
		PreopTerapeuticas pot = daoterappreop.buscaPorId(id_preopterap);

		daoterappreop.remove(pot);
	}
	
	
	
	//----------------------------FIM SEPARADOR PRE OPERATORIO------------------------------------------//
	
	
	
	//----------------------------------------Carrega Ficha Org�o transplantes ------------------------------------------------//
	@RequestMapping(value="carregatransplante")
	public String carregatransplante(Model model, HttpSession session){
		
		
	//	naoexistecandidatoseleccionao
		Long idassigorg = (Long) session.getAttribute("id_assigorgao");
		
		if(!daoanaliserectransp.buscaRecetorSeleccionadoDoTransplante(idassigorg))
		{
			return "eqtransplante/naoexistecandidatoseleccionado";
		}else{
				int idorgao= (int)session.getAttribute("orgaodadoroferta");		
				
				boolean gcct = (boolean) session.getAttribute("gcct");
				
				if(gcct){
					model.addAttribute("leituraescritaeqcirurgica", false);
				}
				
				
				if(idorgao==1){	
					
				//TransplanteCoracao----------------------------------------------------
					
					//Se n�o existe transplante coracao cria
					TransplanteCoracao tc = daotranspcoracao.buscaTransplanteCoracaoAssigorgao((Long)session.getAttribute("id_assigorgao"));
					if(tc==null){
						TransplanteCoracao transplantecoracao = new TransplanteCoracao();
						transplantecoracao.setAssigorgao(daoassigorg.buscaPorId((Long)session.getAttribute("id_assigorgao")));
						daotranspcoracao.adiciona(transplantecoracao);
						model.addAttribute("transplantecoracao", transplantecoracao);
					}else{
						model.addAttribute("transplantecoracao", tc);
					}
					
					//tabela complica��es coracao
					model.addAttribute("complcoracao", daotranspcoracaocompl.listatransplanteCoracaocomplassig((Long)session.getAttribute("id_assigorgao")));
					
					return "eqtransplante/transplante-coracao";
				}
				else if(idorgao==2){
					
				//TransplanteFigado----------------------------------------------------
					
					//Se n�o existe transplante figado cria
					TransplanteFigado tf = daotranspfigado.buscaTransplanteFigadoAssigorgao((Long)session.getAttribute("id_assigorgao"));
					if(tf==null){
						TransplanteFigado transplantefigado = new TransplanteFigado();
						transplantefigado.setAssigorgao(daoassigorg.buscaPorId((Long)session.getAttribute("id_assigorgao")));
						daotranspfigado.adiciona(transplantefigado);
						model.addAttribute("transplantefigado", transplantefigado);
					}else{
						model.addAttribute("transplantefigado", tf);
					}
					
					//tabela perfus�o figado
					model.addAttribute("figadoperfusao", daotranspfigadoperf.ListaTransplanteFigadoPerfusaoassig((Long)session.getAttribute("id_assigorgao")));
					
					//tabela complica��es figado
					model.addAttribute("complfigado", daotranspfigadocompl.listatransplantefigadocomplassig((Long)session.getAttribute("id_assigorgao")));
					
					//tabela transfus�es figado
					model.addAttribute("transffigado", daotranspfigadotransf.ListaTransplanteFigadoTransfusaoassig((Long)session.getAttribute("id_assigorgao")));
					
					return "eqtransplante/transplante-figado";
					
					}
				else if(idorgao==3 ||idorgao==4 || idorgao==5){
				//TransplantePulmoes----------------------------------------------------
					
					//Se n�o existe transplante pulmoes cria
					
					TransplantePulmoes tpu = daotransppulmoes.buscaTransplantePulmoesAssigorgao((Long)session.getAttribute("id_assigorgao"));
					if(tpu==null){
						TransplantePulmoes transplantepulmoes = new TransplantePulmoes();
						transplantepulmoes.setAssigorgao(daoassigorg.buscaPorId((Long)session.getAttribute("id_assigorgao")));
						daotransppulmoes.adiciona(transplantepulmoes);
						model.addAttribute("transplantepulmoes", transplantepulmoes);
					}else{
						model.addAttribute("transplantepulmoes", tpu);
					}
					
					//tabela complica��es pulmoes
					model.addAttribute("complpulmoes", daotransppulmoescompl.listatransplantePulmoescomplassig((Long)session.getAttribute("id_assigorgao")));
					
					//tabela transfus�es pulmoes
					model.addAttribute("transfpulmoes", daotransppulmoestransf.ListaTransplantePulmoesTransfusaoassig((Long)session.getAttribute("id_assigorgao")));
					
					//tabela complica��es pulmoes UCI
					model.addAttribute("complpulmoesuci", daotransppulmoescompluci.listatransplantePulmoescompluciassig((Long)session.getAttribute("id_assigorgao")));
					
					return "eqtransplante/transplante-pulmoes";
					}
				else if(idorgao==6){
					
				//TransplantePancreas----------------------------------------------------
					
					//Se n�o existe transplante figado cria
					TransplantePancreas tp = daotransppancreas.buscaTransplantePancreasAssigorgao((Long)session.getAttribute("id_assigorgao"));
					if(tp==null){
						TransplantePancreas transplantepancreas = new TransplantePancreas();
						transplantepancreas.setAssigorgao(daoassigorg.buscaPorId((Long)session.getAttribute("id_assigorgao")));
						daotransppancreas.adiciona(transplantepancreas);
						model.addAttribute("transplantepancreas", transplantepancreas);
					}else{
						model.addAttribute("transplantepancreas", tp);
					}
					
					//tabela perfus�o pancreas
					model.addAttribute("pancreasperfusao", daotransppancreasperf.ListaTransplantePancreasPerfusaoassig((Long)session.getAttribute("id_assigorgao")));
					
					
					//tabela complica��es pancreas
					model.addAttribute("complpancreas", daotransppancreascompl.listatransplantePancreascomplassig((Long)session.getAttribute("id_assigorgao")));
					
					//tabela transfus�es pancreas
					model.addAttribute("transfpancreas", daotransppancreastransf.ListaTransplantePancreasTransfusaoassig((Long)session.getAttribute("id_assigorgao")));
					
					return "eqtransplante/transplante-pancreas";
		
					}
				
				else {
					
				//TransplanteRins----------------------------------------------------
					
					//Se n�o existe transplante rins cria
					TransplanteRins tr = daotransprins.buscaTransplanteRinsAssigorgao((Long)session.getAttribute("id_assigorgao"));
					if(tr==null){
						TransplanteRins transplanterins = new TransplanteRins();
						transplanterins.setAssigorgao(daoassigorg.buscaPorId((Long)session.getAttribute("id_assigorgao")));
						daotransprins.adiciona(transplanterins);
						model.addAttribute("transplanterins", transplanterins);
					}else{
						model.addAttribute("transplanterins", tr);
					}
					
					//tabela perfus�o rins
					model.addAttribute("rinsperfusao", daotransprinsperf.ListaTransplanteRinsPerfusaoassig((Long)session.getAttribute("id_assigorgao")));
					
					//tabela complica��es rins
					model.addAttribute("complrins", daotransprinscompl.listatransplanteRinscomplassig((Long)session.getAttribute("id_assigorgao")));
					
					//tabela transfus�es rins
					model.addAttribute("transfrins", daotransprinstransf.ListaTransplanteRinsTransfusaoassig((Long)session.getAttribute("id_assigorgao")));
					
					
					return "eqtransplante/transplante-rins";
					}
		}
	}
	
	
	//-----------------------------------TRANSPLANTE FIGADO---------------------------------------------//
	@RequestMapping(value="registahorastransplantefigado" , produces="application/json")
	@ResponseBody
	public String registahorasfigado(@RequestParam("tipo") int tipo, HttpSession session){

		Long id_assignacao = (Long) session.getAttribute("id_assigorgao");
		
		//String time = "";
		int horas = 0;
		int mins = 0;
		long secs = 0;
		String isqtotal = "";
		String cdah = "";
		
		Calendar calfig = Calendar.getInstance();
		
		TransplanteFigado tf = daotranspfigado.buscaTransplanteFigadoAssigorgao(id_assignacao);
		
		if(tipo==1){
			tf.setInicioanestesia(calfig);
		}else if(tipo==2){
			tf.setIniciocirurgia(calfig);
		}else if(tipo==3){
			tf.setClampAH(calfig);
		}else if(tipo==4){
			tf.setClampVP(calfig);
		}else if(tipo==5){
			tf.setClampVCIH(calfig);
		}else if(tipo==6){
			tf.setClampVCSH(calfig);
		}else if(tipo==7){
			tf.setExcisaofigado(calfig);
		}else if(tipo==8){
			tf.setRetirargelo(calfig);
			Dador dador = (Dador)session.getAttribute("dadororgao");
			AnaliseDador analise = daoanalisedador.buscaAnaliseDoDador(dador.getId_Dador());
			ColheitaGeral cg = daocolheitageral.buscacolheitageralanalise(analise.getId_AnaliseDador());
			
			Date date1 = cg.getClampagemgeral().getTime();
			Date date2 = calfig.getTime();
			//long difference = date2.getTime() - date1.getTime(); //em milisegundos
			
			secs = (date2.getTime() - date1.getTime())/1000;

			horas = (int) (secs / 3600);    
			secs = secs % 3600;

			mins = (int) (secs / 60);
			secs = secs % 60;

			String hr = String.format("%02d", horas);
			String mi = String.format("%02d", mins);
			String sec = String.format("%02d", secs);
			
//			System.out.println("Horas: "+hr);
//			System.out.println("Minutos: "+mi);
//			System.out.println("Segundos: "+sec);
			tf.setIsqfria(hr+":"+mi+":"+sec);
			
		}else if(tipo==9){
			tf.setAnastVCSHinicio(calfig);
		}else if(tipo==10){
			tf.setAnastVCSHfim(calfig);
			
			Date date1cd = tf.getAnastVCSHinicio().getTime();
			Date date2cd = calfig.getTime();
			
			long secscd = (date2cd.getTime() - date1cd.getTime())/1000;
			int horascd = (int) (secscd / 3600);    
			secscd = secscd % 3600;
			int minscd = (int) (secscd / 60);
			secscd = secscd % 60;
			
			String hrcd = String.format("%02d", horascd);
			String micd = String.format("%02d", minscd);
			String seccd = String.format("%02d", secscd);
			
			isqtotal = hrcd+":"+micd+":"+seccd;
			
			tf.setAnastVCSH(isqtotal);
			
		}else if(tipo==11){
			tf.setAnastVCIHinicio(calfig);
		}else if(tipo==12){
			tf.setAnastVCIHfim(calfig);
			
			Date date1cd = tf.getAnastVCIHinicio().getTime();
			Date date2cd = calfig.getTime();
			
			long secscd = (date2cd.getTime() - date1cd.getTime())/1000;
			int horascd = (int) (secscd / 3600);    
			secscd = secscd % 3600;
			int minscd = (int) (secscd / 60);
			secscd = secscd % 60;
			
			String hrcd = String.format("%02d", horascd);
			String micd = String.format("%02d", minscd);
			String seccd = String.format("%02d", secscd);
			
			isqtotal = hrcd+":"+micd+":"+seccd;
			
			tf.setAnastVCIH(isqtotal);
		}else if(tipo==13){
			tf.setAnastVPinicio(calfig);
		}else if(tipo==14){
			tf.setAnastVPfim(calfig);
			
			Date date1cd = tf.getAnastVPinicio().getTime();
			Date date2cd = calfig.getTime();
			
			long secscd = (date2cd.getTime() - date1cd.getTime())/1000;
			int horascd = (int) (secscd / 3600);    
			secscd = secscd % 3600;
			int minscd = (int) (secscd / 60);
			secscd = secscd % 60;
			
			String hrcd = String.format("%02d", horascd);
			String micd = String.format("%02d", minscd);
			String seccd = String.format("%02d", secscd);
			
			isqtotal = hrcd+":"+micd+":"+seccd;
			
			tf.setAnastVeiaP(isqtotal);
			
		}else if(tipo==15){
			tf.setDesclampVCSH(calfig);
			
			Date date1cd = tf.getClampVCSH().getTime();
			Date date2cd = calfig.getTime();
			
			long secscd = (date2cd.getTime() - date1cd.getTime())/1000;
			int horascd = (int) (secscd / 3600);    
			secscd = secscd % 3600;
			int minscd = (int) (secscd / 60);
			secscd = secscd % 60;
			
			String hrcd = String.format("%02d", horascd);
			String micd = String.format("%02d", minscd);
			String seccd = String.format("%02d", secscd);
			
			isqtotal = hrcd+":"+micd+":"+seccd;
			
			tf.setClampdescVCSH(isqtotal);
			
		}else if(tipo==16){
			tf.setDesclampVCIH(calfig);
			
			Date date1cd = tf.getClampVCIH().getTime();
			Date date2cd = calfig.getTime();
			
			long secscd = (date2cd.getTime() - date1cd.getTime())/1000;
			int horascd = (int) (secscd / 3600);    
			secscd = secscd % 3600;
			int minscd = (int) (secscd / 60);
			secscd = secscd % 60;
			
			String hrcd = String.format("%02d", horascd);
			String micd = String.format("%02d", minscd);
			String seccd = String.format("%02d", secscd);
			
			isqtotal = hrcd+":"+micd+":"+seccd;
			
			tf.setClampdescVCIH(isqtotal);
			
		}else if(tipo==17){
			tf.setDesclampVP(calfig);
			
			Date date1cd = tf.getClampVP().getTime();
			Date date2cd = calfig.getTime();
			
			long secscd = (date2cd.getTime() - date1cd.getTime())/1000;
			int horascd = (int) (secscd / 3600);    
			secscd = secscd % 3600;
			int minscd = (int) (secscd / 60);
			secscd = secscd % 60;
			
			String hrcd = String.format("%02d", horascd);
			String micd = String.format("%02d", minscd);
			String seccd = String.format("%02d", secscd);
			
			isqtotal = hrcd+":"+micd+":"+seccd;
			
			tf.setClampdescVeiaP(isqtotal);
		}else if(tipo==18){
			tf.setAnastAHinicio(calfig);
		}else if(tipo==19){
			tf.setAnastAHfim(calfig);
			
			Date date1cd = tf.getAnastAHinicio().getTime();
			Date date2cd = calfig.getTime();
			
			long secscd = (date2cd.getTime() - date1cd.getTime())/1000;
			int horascd = (int) (secscd / 3600);    
			secscd = secscd % 3600;
			int minscd = (int) (secscd / 60);
			secscd = secscd % 60;
			
			String hrcd = String.format("%02d", horascd);
			String micd = String.format("%02d", minscd);
			String seccd = String.format("%02d", secscd);
			
			isqtotal = hrcd+":"+micd+":"+seccd;
			
			tf.setAnastArHep(isqtotal);
		}else if(tipo==20){
			tf.setDesclampAH(calfig);
			
			//isq quente
			Date date1 = tf.getRetirargelo().getTime();
			Date date2 = calfig.getTime();
			
			secs = (date2.getTime() - date1.getTime())/1000;

			horas = (int) (secs / 3600);    
			secs = secs % 3600;

			mins = (int) (secs / 60);
			secs = secs % 60;

			String hrq = String.format("%02d", horas);
			String miq = String.format("%02d", mins);
			String secq = String.format("%02d", secs);
			tf.setIsqquente(hrq+":"+miq+":"+secq);
			
			//isq total
			Dador dador = (Dador)session.getAttribute("dadororgao");
			AnaliseDador analise = daoanalisedador.buscaAnaliseDoDador(dador.getId_Dador());
			ColheitaGeral cg = daocolheitageral.buscacolheitageralanalise(analise.getId_AnaliseDador());
			
			Date date1t = cg.getClampagemgeral().getTime();
			Date date2t = calfig.getTime();
			//long difference = date2.getTime() - date1.getTime(); //em milisegundos
			
			long secst = (date2t.getTime() - date1t.getTime())/1000;
			int horast = (int) (secst / 3600);    
			secst = secst % 3600;
			int minst = (int) (secst / 60);
			secst = secst % 60;
			
			String hr = String.format("%02d", horast);
			String mi = String.format("%02d", minst);
			String sec = String.format("%02d", secst);
			
			tf.setIsqtotal(hr+":"+mi+":"+sec);
			
			isqtotal = hr+":"+mi+":"+sec;
			
			Date date1ah = tf.getClampAH().getTime();
			Date date2ah = calfig.getTime();
			
			long secsah = (date2ah.getTime() - date1ah.getTime())/1000;
			int horasah = (int) (secsah / 3600);    
			secsah = secsah % 3600;
			int minsah = (int) (secsah / 60);
			secsah = secsah % 60;
			
			String hrah = String.format("%02d", horasah);
			String miah = String.format("%02d", minsah);
			String secah = String.format("%02d", secsah);
			
			cdah = hrah+":"+miah+":"+secah;
			
			tf.setClampdescArHep(cdah);
			
		}else if(tipo==21){
			tf.setAnastVBinicio(calfig);
		}else if(tipo==22){
			tf.setAnastVBfim(calfig);
			
		//	Date date1cd = tf.getAnastVPinicio().getTime();
			Date date1cd = tf.getAnastVBinicio().getTime();
			Date date2cd = calfig.getTime();
			
			long secscd = (date2cd.getTime() - date1cd.getTime())/1000;
			int horascd = (int) (secscd / 3600);    
			secscd = secscd % 3600;
			int minscd = (int) (secscd / 60);
			secscd = secscd % 60;
			
			String hrcd = String.format("%02d", horascd);
			String micd = String.format("%02d", minscd);
			String seccd = String.format("%02d", secscd);
			
			isqtotal = hrcd+":"+micd+":"+seccd;
			
			tf.setAnastViaB(isqtotal);
		}else if(tipo==23){
			tf.setFim(calfig);
		}
		
		daotranspfigado.atualiza(tf);
		
		DateFormat dum = new SimpleDateFormat("dd/MM/yyyy HH:mm");
		String date = dum.format(calfig.getTime());
		return "[\""+date+"\",\""+horas+"\",\""+mins+"\",\""+secs+"\",\""+isqtotal+"\",\""+cdah+"\"]";
	}
	
	@RequestMapping(value="gravatransplantefigado")
	@ResponseBody
	public String gravatransplantefigado(TransplanteFigado transplante, HttpSession session){

		TransplanteFigado tf = daotranspfigado.buscaPorId(transplante.getIdtransplantefigado());
		tf.setTranspfigado(transplante.getTranspfigado());
		tf.setHepatectomia(transplante.getHepatectomia());
		tf.setAscite(transplante.getAscite());
		tf.setVolume(transplante.getVolume());
		tf.setBypass(transplante.getBypass());
		tf.setAnastarterial(transplante.getAnastarterial());
		tf.setOrgtotal(transplante.getOrgtotal());
		tf.setImpltopica(transplante.getImpltopica());
		tf.setInplauxiliar(transplante.getInplauxiliar());
		tf.setReconstbiliar(transplante.getReconstbiliar());
		tf.setReclampart(transplante.getReclampart());
		tf.setReclampven(transplante.getReclampven());
		tf.setRelatoperat(transplante.getRelatoperat());
		tf.setComplicacoes(transplante.getComplicacoes());
		
		daotranspfigado.atualiza(tf);
		
		return "OK";
	}
	
	
	//-------------------------------- Inicio Tabela perfus�o figado----------------------------------//


	@RequestMapping(value="adicionaperftransplantefigado")
	public String adicionaperftransplantefigado(@RequestParam("perfusao") int perfusao, @RequestParam("tipo") int tipo,  @RequestParam("volume") float volume,
			@RequestParam("inicio") String inicio, @RequestParam("fim") String fim, @RequestParam("qualidade") int qualidade, 
			@RequestParam("teste") boolean teste, Model model, HttpSession session) throws ParseException{

		Long id_assignacao = (Long) session.getAttribute("id_assigorgao");
		//colheita.setAnaliseDador(daoanalisedador.buscaPorId(id_analise));
		TransplanteFigadoPerfusao perf = new TransplanteFigadoPerfusao();
		
		
		AssignacaoOrgaos assig = new AssignacaoOrgaos();
		assig.setId_assignacao(id_assignacao);
		
		
		perf.setAssigorgao(assig);
		perf.setPerfusao(perfusao);
		perf.setTipo(tipo);
		perf.setVolume(volume);
		
		DateFormat df = new SimpleDateFormat("HH:mm");
		Date date = df.parse(inicio);
		Calendar in = Calendar.getInstance();
		in.setTime(date);
		perf.setInicio(in);
		
		Date date2 = df.parse(fim);
		Calendar f = Calendar.getInstance();
		f.setTime(date2);
		perf.setFim(f);
		
		perf.setQualidade(qualidade);
		perf.setIr(teste);
				
		daotranspfigadoperf.adiciona(perf);
		
		model.addAttribute("figadoperf", perf);
		return "eqtransplante/loads/carregalinhaperfusaofigado";
	}


	@RequestMapping(value="gravaperftransplantefigado")
	public String gravaperftransplantefigado(@RequestParam("idperffigado") Long idperffigado, @RequestParam("perfusao") int perfusao, @RequestParam("tipo") int tipo,  
			@RequestParam("volume") float volume,	@RequestParam("inicio") String inicio, @RequestParam("fim") String fim, 
			@RequestParam("qualidade") int qualidade, @RequestParam("teste") boolean teste, Model model) throws ParseException{
		
		TransplanteFigadoPerfusao perf = daotranspfigadoperf.buscaPorId(idperffigado);
		perf.setPerfusao(perfusao);
		perf.setTipo(tipo);
		//perf.setVia(via);
		perf.setVolume(volume);
		
		DateFormat df = new SimpleDateFormat("HH:mm");
		Date date = df.parse(inicio);
		Calendar in = Calendar.getInstance();
		in.setTime(date);
		perf.setInicio(in);
		
		Date date2 = df.parse(fim);
		Calendar f = Calendar.getInstance();
		f.setTime(date2);
		perf.setFim(f);
		perf.setQualidade(qualidade);
		perf.setIr(teste);
		
		daotranspfigadoperf.atualiza(perf);
		
		model.addAttribute("figadoperf", perf);
		return "eqtransplante/loads/carregalinhaperfusaofigado";
	}

	@RequestMapping(value="delperftransplantefigado")
	@ResponseBody
	public void delperftransplantefigado(@RequestParam("idperffigado") Long idperffigado, Model model){

		//colheita.setAnaliseDador(daoanalisedador.buscaPorId(id_analise));
		TransplanteFigadoPerfusao perf = daotranspfigadoperf.buscaPorId(idperffigado);

		daotranspfigadoperf.remove(perf);
	}
	//-------------------------------- Fim Tabela perfus�o figado----------------------------------//
	
	//--------------------------------Inicio tabela complica��es figado----------------------------//


	@RequestMapping(value="adicionatranspcomplicacoesfigado")
	public String adicionatranspcomplicacoesfigado(@RequestParam("terapeutica") int terapeutica, @RequestParam("observacaoterap") String observacaoterap, Model model, HttpSession session){

		Long id_assignacao = (Long) session.getAttribute("id_assigorgao");
		//colheita.setAnaliseDador(daoanalisedador.buscaPorId(id_analise));
		TransplanteFigadoComplicacoes tf = new TransplanteFigadoComplicacoes();
		
		AssignacaoOrgaos assig = new AssignacaoOrgaos();
		assig.setId_assignacao(id_assignacao);
		
		tf.setAssigorgao(assig);;
		tf.setComplicacao(terapeutica);
		tf.setNotascomplicacao(observacaoterap);
		
		daotranspfigadocompl.adiciona(tf);
		
		model.addAttribute("complfigado", tf);
		return "eqtransplante/loads/carregalinhacomplfigado";
	}



	@RequestMapping(value="gravatranspcomplicacoesfigado")
	public String gravatranspcomplicacoesfigado(@RequestParam("terapeutica") int terapeutica, @RequestParam("observacaoterap") String observacaoterap, @RequestParam("idcolheitaterap") Long idcolheitaterap, Model model){

		//colheita.setAnaliseDador(daoanalisedador.buscaPorId(id_analise));
		TransplanteFigadoComplicacoes tf = daotranspfigadocompl.buscaPorId(idcolheitaterap);
		tf.setComplicacao(terapeutica);
		tf.setNotascomplicacao(observacaoterap);
		
		daotranspfigadocompl.atualiza(tf);
		
		model.addAttribute("complfigado", tf);
		return "eqtransplante/loads/carregalinhacomplfigado";
	}


	@RequestMapping(value="deltranspcomplicacoesfigado")
	@ResponseBody
	public void deltranspcomplicacoesfigado(@RequestParam("idcolheitaterap") Long idcolheitaterap, Model model){

		//colheita.setAnaliseDador(daoanalisedador.buscaPorId(id_analise));
		TransplanteFigadoComplicacoes tf = daotranspfigadocompl.buscaPorId(idcolheitaterap);

		daotranspfigadocompl.remove(tf);
	}
	//-----------fim tabela complica��es figado----------------------//	
	
	//--------------------------------Inicio tabela transfus�es figado----------------------------//


	@RequestMapping(value="adicionatransptransffigado")
	public String adicionatransptransffigado(@RequestParam("terapeutica") int terapeutica, @RequestParam("observacaoterap") String observacaoterap,
			@RequestParam("qtd") int qtd, Model model, HttpSession session){

		Long id_assignacao = (Long) session.getAttribute("id_assigorgao");

		TransplanteFigadoTransfusao tf = new TransplanteFigadoTransfusao();
		
		AssignacaoOrgaos assig = new AssignacaoOrgaos();
		assig.setId_assignacao(id_assignacao);
		
		tf.setAssigorgao(assig);;
		tf.setTransfusao(terapeutica);
		tf.setQtd(qtd);
		tf.setObservacoestransf(observacaoterap);
		
		daotranspfigadotransf.adiciona(tf);
		
		model.addAttribute("transffigado", tf);
		return "eqtransplante/loads/carregalinhatransfusaofigado";
	}



	@RequestMapping(value="gravatransptransffigado")
	public String gravatransptransffigado(@RequestParam("terapeutica") int terapeutica, @RequestParam("observacaoterap") String observacaoterap, 
			@RequestParam("qtd") int qtd, @RequestParam("idcolheitaterap") Long idcolheitaterap, Model model){

		//colheita.setAnaliseDador(daoanalisedador.buscaPorId(id_analise));
		TransplanteFigadoTransfusao tf = daotranspfigadotransf.buscaPorId(idcolheitaterap);
		tf.setTransfusao(terapeutica);
		tf.setQtd(qtd);
		tf.setObservacoestransf(observacaoterap);
		
		daotranspfigadotransf.atualiza(tf);
		
		model.addAttribute("transffigado", tf);
		return "eqtransplante/loads/carregalinhatransfusaofigado";
	}


	@RequestMapping(value="deltransptransffigado")
	@ResponseBody
	public void deltransptransffigado(@RequestParam("idcolheitaterap") Long idcolheitaterap, Model model){

		//colheita.setAnaliseDador(daoanalisedador.buscaPorId(id_analise));
		TransplanteFigadoTransfusao tf = daotranspfigadotransf.buscaPorId(idcolheitaterap);

		daotranspfigadotransf.remove(tf);
	}
	//-----------fim tabela transfus�es figado----------------------//	
	
	@SuppressWarnings("rawtypes")
	@RequestMapping(value="gravatransplanteestadofigado")
	@ResponseBody
	public String gravatransplanteestadofigado(int estado, HttpSession session){

		Long id_assignacao = (Long) session.getAttribute("id_assigorgao");

		TransplanteFigado tf = daotranspfigado.buscaTransplanteFigadoAssigorgao(id_assignacao);

		tf.setEstado(estado);
		
		daotranspfigado.atualiza(tf);
		

		//passar para transplantado em todas as inscri��es nos hospitais onde estiver para mesmo org�o
		AnaliseRecetor ar = daoanaliserec.buscaAnaliseRecetorAssigOrg(id_assignacao);
		Recetores rec = daorecetor.buscaPorId(ar.getRecetor().getId_recetor());
		
		if(!daotransp.verificajafoitransplantado(rec.getId_recetor(), id_assignacao)){
	
				int snsrec = rec.getSns();
				Long unidadetr = rec.getUnidadetransp().getId_unidadetransplante();
				List<AnaliseRecetor> analisesrec= daorecetor.atualizainscricoestransplantado(snsrec, unidadetr, estado);
				if(!analisesrec.isEmpty()){
					Long idanaliserec = 0L;
					for (Iterator i = analisesrec.iterator(); i.hasNext();) {  
						AnaliseRecetor values = (AnaliseRecetor) i.next();
			        	idanaliserec =  values.getId_analiserecetor();
			        	
			        	EstadoRecetor estrec = new EstadoRecetor();
			    		AnaliseRecetor analiserec = new AnaliseRecetor();
			    		analiserec.setId_analiserecetor(idanaliserec);
			    		
			    		estrec.setAnaliserecetor(analiserec);
			    		estrec.setEstado(5);
			    		String notas = "";
			    		 if(estado==1){
			    				notas = "Vivo com enxerto";
			    			}else if(estado==2){
			    				notas = "Vivo sem enxerto";
			    			}else if(estado==3){
			    				notas = "Falecido";
			    			}
			    		estrec.setNotas(notas);
			    		estrec.setData(Calendar.getInstance());
			    		Utilizador user = new Utilizador();
			    		user.setID_Utilizador((Long)session.getAttribute("iduser"));
			    		estrec.setUser(user);
			        	
			        	daoestadorecetor.adiciona(estrec);
			        }
				}
		
		mudaestadorecetor(ar.getRecetor().getId_recetor(), id_assignacao);
		}
		return "OK";
	}
	
	//passar para transplantado/followup
	public void mudaestadorecetor(Long idrecetor, Long id_assignacao) 
	{
		Recetores rec = daorecetor.buscaPorId(idrecetor);
		
		//verificar se recetor j� foi colocado como transplantado, se sim abortar:
		if(!daotransp.buscaseexiste(rec.getId_recetor())){ //se n�o existe
		
		
			RecetorDetalhes recdet = daorecetordetalhe.buscadetalhesrecetor(idrecetor);
			
			Transplantes novotransp = new Transplantes();
			TransplantadoDetalhes transpdet = new TransplantadoDetalhes();
			
			novotransp.setCodigotransplantado(rec.getCodigorecetor());
			novotransp.setNometransplantado(rec.getNomerecetor());
			novotransp.setSns(rec.getSns());
			novotransp.setHospital(rec.getHospital());
			novotransp.setUnidadetransp(rec.getUnidadetransp());
			novotransp.setEstadotransplantado(1);
			novotransp.setDatatransplante(Calendar.getInstance());
			novotransp.setRecetor(rec);
			AssignacaoOrgaos assigorg = new AssignacaoOrgaos();
			assigorg.setId_assignacao(id_assignacao);
			novotransp.setAssigorgao(assigorg);
	/*		ServletRequestAttributes attr = (ServletRequestAttributes) RequestContextHolder.currentRequestAttributes();
			HttpSession session = attr.getRequest().getSession();
			OrgaosOferta orgaosof = new OrgaosOferta();
			orgaosof.setIdorgoferta((int)session.getAttribute("orgaodadoroferta"));
			
			Orgaos orgaos = new Orgaos();
			orgaos.setId_Orgao(rec.getUnidadetransp().getId_unidadetransplante());
			novotransp.setOrgaos(orgaos);
			
			novotransp.setOrgaosoferta(orgaosof);*/
			daotransp.adiciona(novotransp);
			
			transpdet.setCodpostaltranplantado(recdet.getCodpostalrecetor());
			transpdet.setDatanascimentotransplantado(recdet.getDatanascimento());
			transpdet.setEmailtranplantado(recdet.getEmailrecetor());
			transpdet.setLocalidadetranplantado(recdet.getLocalidaderecetor());
			transpdet.setMoradatranplantado(recdet.getMoradarecetor());
			transpdet.setNacionalidadetransplantado(recdet.getNacionalidade());
			transpdet.setNumidentificacaotransplantado(recdet.getNumidentificacao());
			transpdet.setNumidentificacaotransplantado2(recdet.getNumidentificacao2());
			transpdet.setResidenciatransplantado(recdet.getResidencia());
			transpdet.setSexotransplantado(recdet.isSexo());
			transpdet.setTelefonetransplantado(recdet.getTelefone());
			transpdet.setTelemoveltransplantado(recdet.getTelemovel());
			transpdet.setTipocidadaotransplantado(recdet.isTipocidadao());
			transpdet.setTiponumidentificacaotransplantado(recdet.getTiponumidentificacao());
			transpdet.setTiponumidentificacaotransplantado2(recdet.getTiponumidentificacao2());
			transpdet.setTranplantado(novotransp);
			
			daotranspdet.adiciona(transpdet);
		
		}
	}
	
	//-----------------------------------TRANSPLANTE PANCREAS---------------------------------------------//
		@RequestMapping(value="registahorastransplantepancreas" , produces="application/json")
		@ResponseBody
		public String registahoraspancreas(@RequestParam("tipo") int tipo, HttpSession session){

			Long id_assignacao = (Long) session.getAttribute("id_assigorgao");
			
			//String time = "";
			int horas = 0;
			int mins = 0;
			long secs = 0;
			String isqtotal = "";
			String cdah = "";
			
			Calendar calfig = Calendar.getInstance();
			
			TransplantePancreas tf = daotransppancreas.buscaTransplantePancreasAssigorgao(id_assignacao);
			
			if(tipo==1){
				tf.setInicio(calfig);
			}else if(tipo==2){
				tf.setClampvenosa(calfig);
				
			}else if(tipo==3){
				tf.setRetirargelo(calfig);
				Dador dador = (Dador)session.getAttribute("dadororgao");
				AnaliseDador analise = daoanalisedador.buscaAnaliseDoDador(dador.getId_Dador());
				ColheitaGeral cg = daocolheitageral.buscacolheitageralanalise(analise.getId_AnaliseDador());
				
				Date date1 = cg.getClampagemgeral().getTime();
				Date date2 = calfig.getTime();
				//long difference = date2.getTime() - date1.getTime(); //em milisegundos
				
				secs = (date2.getTime() - date1.getTime())/1000;

				horas = (int) (secs / 3600);    
				secs = secs % 3600;

				mins = (int) (secs / 60);
				secs = secs % 60;

				String hr = String.format("%02d", horas);
				String mi = String.format("%02d", mins);
				String sec = String.format("%02d", secs);
				
				tf.setIsqfria(hr+":"+mi+":"+sec);
			}else if(tipo==4){
				tf.setDesclampvenosa(calfig);
				
				//isq quente
				Date date1 = tf.getRetirargelo().getTime();
				Date date2 = calfig.getTime();
				
				secs = (date2.getTime() - date1.getTime())/1000;

				horas = (int) (secs / 3600);    
				secs = secs % 3600;

				mins = (int) (secs / 60);
				secs = secs % 60;

				String hrq = String.format("%02d", horas);
				String miq = String.format("%02d", mins);
				String secq = String.format("%02d", secs);
				tf.setIsqquente(hrq+":"+miq+":"+secq);
				
				//isq total
				Dador dador = (Dador)session.getAttribute("dadororgao");
				AnaliseDador analise = daoanalisedador.buscaAnaliseDoDador(dador.getId_Dador());
				ColheitaGeral cg = daocolheitageral.buscacolheitageralanalise(analise.getId_AnaliseDador());
				
				Date date1t = cg.getClampagemgeral().getTime();
				Date date2t = calfig.getTime();
				//long difference = date2.getTime() - date1.getTime(); //em milisegundos
				
				long secst = (date2t.getTime() - date1t.getTime())/1000;
				int horast = (int) (secst / 3600);    
				secst = secst % 3600;
				int minst = (int) (secst / 60);
				secst = secst % 60;
				
				String hr = String.format("%02d", horast);
				String mi = String.format("%02d", minst);
				String sec = String.format("%02d", secst);
				
				tf.setIsqtotal(hr+":"+mi+":"+sec);
				
				isqtotal = hr+":"+mi+":"+sec;
				
				Date date1ah = tf.getClampvenosa().getTime();
				Date date2ah = calfig.getTime();
				
				long secsah = (date2ah.getTime() - date1ah.getTime())/1000;
				int horasah = (int) (secsah / 3600);    
				secsah = secsah % 3600;
				int minsah = (int) (secsah / 60);
				secsah = secsah % 60;
				
				String hrah = String.format("%02d", horasah);
				String miah = String.format("%02d", minsah);
				String secah = String.format("%02d", secsah);
				
				cdah = hrah+":"+miah+":"+secah;
				
				tf.setClampdescVenosa(cdah);
			}else if(tipo==5){
				tf.setClamparterial(calfig);
			}else if(tipo==6){
				tf.setDesclamparterial(calfig);
				Date date1cd = tf.getClamparterial().getTime();
				Date date2cd = calfig.getTime();
				
				long secscd = (date2cd.getTime() - date1cd.getTime())/1000;
				int horascd = (int) (secscd / 3600);    
				secscd = secscd % 3600;
				int minscd = (int) (secscd / 60);
				secscd = secscd % 60;
				
				String hrcd = String.format("%02d", horascd);
				String micd = String.format("%02d", minscd);
				String seccd = String.format("%02d", secscd);
				
				isqtotal = hrcd+":"+micd+":"+seccd;
				
				tf.setClampdescArterial(isqtotal);
			}else if(tipo==7){
				tf.setFim(calfig);				

			}
			
			daotransppancreas.atualiza(tf);
			
			DateFormat dum = new SimpleDateFormat("dd/MM/yyyy HH:mm");
			String date = dum.format(calfig.getTime());
			return "[\""+date+"\",\""+horas+"\",\""+mins+"\",\""+secs+"\",\""+isqtotal+"\",\""+cdah+"\"]";
		}
		
		@RequestMapping(value="gravatransplantepancreas")
		@ResponseBody
		public String gravatransplantepancreas(TransplantePancreas transplante, HttpSession session){

			TransplantePancreas tf = daotransppancreas.buscaPorId(transplante.getIdtransplantepancreas());
			tf.setTransppancreas(transplante.getTransppancreas());
			tf.setImplantacao(transplante.getImplantacao());
			tf.setAnastarterial(transplante.getAnastarterial());
			tf.setOrgtotal(transplante.getOrgtotal());
			tf.setReclampart(transplante.getReclampart());
			tf.setReclampven(transplante.getReclampven());
			tf.setModalidade(transplante.getModalidade());
			tf.setDrenven(transplante.getDrenven());
			tf.setDrenexoc(transplante.getDrenexoc());
			tf.setRelatoperat(transplante.getRelatoperat());
			tf.setComplicacoes(transplante.getComplicacoes());
			
			daotransppancreas.atualiza(tf);
			
			return "OK";
		}
		
		//-------------------------------- Inicio Tabela perfus�o pancreas----------------------------------//


		@RequestMapping(value="adicionaperftransplantepancreas")
		public String adicionaperftransplantepancreas(@RequestParam("perfusao") int perfusao, @RequestParam("tipo") int tipo,  @RequestParam("volume") float volume,
				@RequestParam("inicio") String inicio, @RequestParam("fim") String fim, @RequestParam("qualidade") int qualidade, 
				@RequestParam("teste") boolean teste, Model model, HttpSession session) throws ParseException{

			Long id_assignacao = (Long) session.getAttribute("id_assigorgao");
			//colheita.setAnaliseDador(daoanalisedador.buscaPorId(id_analise));
			TransplantePancreasPerfusao perf = new TransplantePancreasPerfusao();
			
			
			AssignacaoOrgaos assig = new AssignacaoOrgaos();
			assig.setId_assignacao(id_assignacao);
			
			
			perf.setAssigorgao(assig);
			perf.setPerfusao(perfusao);
			perf.setTipo(tipo);
			perf.setVolume(volume);
			
			DateFormat df = new SimpleDateFormat("HH:mm");
			Date date = df.parse(inicio);
			Calendar in = Calendar.getInstance();
			in.setTime(date);
			perf.setInicio(in);
			
			Date date2 = df.parse(fim);
			Calendar f = Calendar.getInstance();
			f.setTime(date2);
			perf.setFim(f);
			
			perf.setQualidade(qualidade);
			perf.setIr(teste);
					
			daotransppancreasperf.adiciona(perf);
			
			model.addAttribute("pancreasperf", perf);
			return "eqtransplante/loads/carregalinhaperfusaopancreas";
		}


		@RequestMapping(value="gravaperftransplantepancreas")
		public String gravaperftransplantepancreas(@RequestParam("idperfpancreas") Long idperfpancreas, @RequestParam("perfusao") int perfusao, @RequestParam("tipo") int tipo,  
				@RequestParam("volume") float volume,	@RequestParam("inicio") String inicio, @RequestParam("fim") String fim, 
				@RequestParam("qualidade") int qualidade, @RequestParam("teste") boolean teste, Model model) throws ParseException{
			
			TransplantePancreasPerfusao perf = daotransppancreasperf.buscaPorId(idperfpancreas);
			perf.setPerfusao(perfusao);
			perf.setTipo(tipo);
			//perf.setVia(via);
			perf.setVolume(volume);
			
			DateFormat df = new SimpleDateFormat("HH:mm");
			Date date = df.parse(inicio);
			Calendar in = Calendar.getInstance();
			in.setTime(date);
			perf.setInicio(in);
			
			Date date2 = df.parse(fim);
			Calendar f = Calendar.getInstance();
			f.setTime(date2);
			perf.setFim(f);
			perf.setQualidade(qualidade);
			perf.setIr(teste);
			
			daotransppancreasperf.atualiza(perf);
			
			model.addAttribute("pancreasperf", perf);
			return "eqtransplante/loads/carregalinhaperfusaopancreas";
		}

		@RequestMapping(value="delperftransplantepancreas")
		@ResponseBody
		public void delperftransplantepancreas(@RequestParam("idperfpancreas") Long idperfpancreas, Model model){

			//colheita.setAnaliseDador(daoanalisedador.buscaPorId(id_analise));
			TransplantePancreasPerfusao perf = daotransppancreasperf.buscaPorId(idperfpancreas);

			daotransppancreasperf.remove(perf);
		}
		//-------------------------------- Fim Tabela perfus�o pancreas----------------------------------//
		
		
		//--------------------------------Inicio tabela complica��es pancreas----------------------------//


		@RequestMapping(value="adicionatranspcomplicacoespancreas")
		public String adicionatranspcomplicacoespancreas(@RequestParam("terapeutica") int terapeutica, @RequestParam("observacaoterap") String observacaoterap, Model model, HttpSession session){

			Long id_assignacao = (Long) session.getAttribute("id_assigorgao");
			//colheita.setAnaliseDador(daoanalisedador.buscaPorId(id_analise));
			TransplantePancreasComplicacoes tf = new TransplantePancreasComplicacoes();
			
			AssignacaoOrgaos assig = new AssignacaoOrgaos();
			assig.setId_assignacao(id_assignacao);
			
			tf.setAssigorgao(assig);;
			tf.setComplicacao(terapeutica);
			tf.setNotascomplicacao(observacaoterap);
			
			daotransppancreascompl.adiciona(tf);
			
			model.addAttribute("complpancreas", tf);
			return "eqtransplante/loads/carregalinhacomplpancreas";
		}



		@RequestMapping(value="gravatranspcomplicacoespancreas")
		public String gravatranspcomplicacoespancreas(@RequestParam("terapeutica") int terapeutica, @RequestParam("observacaoterap") String observacaoterap, @RequestParam("idcolheitaterap") Long idcolheitaterap, Model model){

			//colheita.setAnaliseDador(daoanalisedador.buscaPorId(id_analise));
			TransplantePancreasComplicacoes tf = daotransppancreascompl.buscaPorId(idcolheitaterap);
			tf.setComplicacao(terapeutica);
			tf.setNotascomplicacao(observacaoterap);
			
			daotransppancreascompl.atualiza(tf);
			
			model.addAttribute("complpancreas", tf);
			return "eqtransplante/loads/carregalinhacomplpancreas";
		}


		@RequestMapping(value="deltranspcomplicacoespancreas")
		@ResponseBody
		public void deltranspcomplicacoespancreas(@RequestParam("idcolheitaterap") Long idcolheitaterap, Model model){

			//colheita.setAnaliseDador(daoanalisedador.buscaPorId(id_analise));
			TransplantePancreasComplicacoes tf = daotransppancreascompl.buscaPorId(idcolheitaterap);

			daotransppancreascompl.remove(tf);
		}
		//-----------fim tabela complica��es pancreas----------------------//	
		
		//--------------------------------Inicio tabela transfus�es pancreas----------------------------//


		@RequestMapping(value="adicionatransptransfpancreas")
		public String adicionatransptransfpancreas(@RequestParam("terapeutica") int terapeutica, @RequestParam("observacaoterap") String observacaoterap,
				@RequestParam("qtd") int qtd, Model model, HttpSession session){

			Long id_assignacao = (Long) session.getAttribute("id_assigorgao");

			TransplantePancreasTransfusao tf = new TransplantePancreasTransfusao();
			
			AssignacaoOrgaos assig = new AssignacaoOrgaos();
			assig.setId_assignacao(id_assignacao);
			
			tf.setAssigorgao(assig);;
			tf.setTransfusao(terapeutica);
			tf.setQtd(qtd);
			tf.setObservacoestransf(observacaoterap);
			
			daotransppancreastransf.adiciona(tf);
			
			model.addAttribute("transfpancreas", tf);
			return "eqtransplante/loads/carregalinhatransfusaopancreas";
		}



		@RequestMapping(value="gravatransptransfpancreas")
		public String gravatransptransfpancreas(@RequestParam("terapeutica") int terapeutica, @RequestParam("observacaoterap") String observacaoterap, 
				@RequestParam("qtd") int qtd, @RequestParam("idcolheitaterap") Long idcolheitaterap, Model model){

			//colheita.setAnaliseDador(daoanalisedador.buscaPorId(id_analise));
			TransplantePancreasTransfusao tf = daotransppancreastransf.buscaPorId(idcolheitaterap);
			tf.setTransfusao(terapeutica);
			tf.setQtd(qtd);
			tf.setObservacoestransf(observacaoterap);
			
			daotransppancreastransf.atualiza(tf);
			
			model.addAttribute("transfpancreas", tf);
			return "eqtransplante/loads/carregalinhatransfusaopancreas";
		}


		@RequestMapping(value="deltransptransfpancreas")
		@ResponseBody
		public void deltransptransfpancreas(@RequestParam("idcolheitaterap") Long idcolheitaterap, Model model){

			//colheita.setAnaliseDador(daoanalisedador.buscaPorId(id_analise));
			TransplantePancreasTransfusao tf = daotransppancreastransf.buscaPorId(idcolheitaterap);

			daotransppancreastransf.remove(tf);
		}
		//-----------fim tabela transfus�es pancreas----------------------//	
		
		
		@SuppressWarnings("rawtypes")
		@RequestMapping(value="gravatransplanteestadopancreas")
		@ResponseBody
		public String gravatransplanteestadopancreas(int estado, HttpSession session){

			Long id_assignacao = (Long) session.getAttribute("id_assigorgao");

			TransplantePancreas tf = daotransppancreas.buscaTransplantePancreasAssigorgao(id_assignacao);

			tf.setEstado(estado);
			
			daotransppancreas.atualiza(tf);
			
			//passar para transplantado em todas as inscri��es nos hospitais onde estiver para mesmo org�o
			AnaliseRecetor ar = daoanaliserec.buscaAnaliseRecetorAssigOrg(id_assignacao);
			Recetores rec = daorecetor.buscaPorId(ar.getRecetor().getId_recetor());
			
			if(!daotransp.verificajafoitransplantado(rec.getId_recetor(), id_assignacao)){
			
					int snsrec = rec.getSns();
					Long unidadetr = rec.getUnidadetransp().getId_unidadetransplante();
					List<AnaliseRecetor> analisesrec= daorecetor.atualizainscricoestransplantado(snsrec, unidadetr, estado);
					if(!analisesrec.isEmpty()){
						Long idanaliserec = 0L;
						for (Iterator i = analisesrec.iterator(); i.hasNext();) {  
							AnaliseRecetor values = (AnaliseRecetor) i.next();
				        	idanaliserec =  values.getId_analiserecetor();
				        	
				        	EstadoRecetor estrec = new EstadoRecetor();
				    		AnaliseRecetor analiserec = new AnaliseRecetor();
				    		analiserec.setId_analiserecetor(idanaliserec);
				    		
				    		estrec.setAnaliserecetor(analiserec);
				    		estrec.setEstado(5);
				    		String notas = "";
				    		 if(estado==1){
				    				notas = "Vivo com enxerto";
				    			}else if(estado==2){
				    				notas = "Vivo sem enxerto";
				    			}else if(estado==3){
				    				notas = "Falecido";
				    			}
				    		estrec.setNotas(notas);
				    		estrec.setData(Calendar.getInstance());
				    		Utilizador user = new Utilizador();
				    		user.setID_Utilizador((Long)session.getAttribute("iduser"));
				    		estrec.setUser(user);
				        	
				        	daoestadorecetor.adiciona(estrec);
				        }
					}
			
			
			mudaestadorecetor(ar.getRecetor().getId_recetor(), id_assignacao);
			}
			return "OK";
		}
		//---------------FIM TRANSPLANTE PANCREAS-------------------------------//
	
		//-----------------------------------TRANSPLANTE CORACAO---------------------------------------------//
		@RequestMapping(value="registahorastransplantecoracao" , produces="application/json")
		@ResponseBody
		public String registahorascoracao(@RequestParam("tipo") int tipo, HttpSession session){

			Long id_assignacao = (Long) session.getAttribute("id_assigorgao");
			
			//String time = "";
			int horas = 0;
			int mins = 0;
			long secs = 0;
			
			Calendar calfig = Calendar.getInstance();
			
			TransplanteCoracao tf = daotranspcoracao.buscaTransplanteCoracaoAssigorgao(id_assignacao);
			
			if(tipo==1){
				tf.setInicio(calfig);
			}else if(tipo==2){
				tf.setClampaorta(calfig);
				
			}else if(tipo==3){
				tf.setReperfusao(calfig);
				Dador dador = (Dador)session.getAttribute("dadororgao");
				AnaliseDador analise = daoanalisedador.buscaAnaliseDoDador(dador.getId_Dador());
				ColheitaGeral cg = daocolheitageral.buscacolheitageralanalise(analise.getId_AnaliseDador());
				
				Date date1 = cg.getClampagemgeral().getTime();
				Date date2 = calfig.getTime();
				//long difference = date2.getTime() - date1.getTime(); //em milisegundos
				
				secs = (date2.getTime() - date1.getTime())/1000;

				horas = (int) (secs / 3600);    
				secs = secs % 3600;

				mins = (int) (secs / 60);
				secs = secs % 60;

				String hr = String.format("%02d", horas);
				String mi = String.format("%02d", mins);
				String sec = String.format("%02d", secs);
				
				tf.setIsquemia(hr+":"+mi+":"+sec);
			
			}else if(tipo==4){
				tf.setFim(calfig);				

			}
			
			daotranspcoracao.atualiza(tf);
			
			DateFormat dum = new SimpleDateFormat("dd/MM/yyyy HH:mm");
			String date = dum.format(calfig.getTime());
			return "[\""+date+"\",\""+horas+"\",\""+mins+"\",\""+secs+"\"]";

		}
		
		@RequestMapping(value="gravatransplantecoracao")
		@ResponseBody
		public String gravatransplantecoracao(TransplanteCoracao transplante, HttpSession session){

			TransplanteCoracao tf = daotranspcoracao.buscaPorId(transplante.getIdtransplantecoracao());
			tf.setReesterno(transplante.getReesterno());
			tf.setRecetor(transplante.getRecetor());
			tf.setInotropicos(transplante.getInotropicos());
			tf.setAssistencia(transplante.getAssistencia());
			tf.setEcmo(transplante.getEcmo());
			tf.setUniventric(transplante.getUniventric());
			tf.setTecnica(transplante.getTecnica());
			tf.setBalao(transplante.getBalao());
			tf.setCirculextra(transplante.getCirculextra());
			tf.setProcextra(transplante.getProcextra());
			tf.setHemorragia(transplante.isHemorragia());
			tf.setFalencenxerto(transplante.isFalencenxerto());
			tf.setHipertensao(transplante.isHipertensao());
			tf.setOutra(transplante.isOutra());
			tf.setNotas(transplante.getNotas());
			tf.setSaidarecetor(transplante.getSaidarecetor());
			tf.setSaidasuporte(transplante.getSaidasuporte());
			tf.setSaidano(transplante.getSaidano());
			tf.setSaidapacing(transplante.getSaidapacing());
			tf.setSaidabalao(transplante.getSaidabalao());
			tf.setSaidaecmo(transplante.getSaidaecmo());
			tf.setSaidaobs(transplante.getSaidaobs());			
			tf.setComplicacoes(transplante.getComplicacoes());
			tf.setEntrada(transplante.getEntrada());
			tf.setSaida(transplante.getSaida());
			
			daotranspcoracao.atualiza(tf);
			
			return "OK";
		}
		
		//--------------------------------Inicio tabela complica��es coracao----------------------------//


		@RequestMapping(value="adicionatranspcomplicacoescoracao")
		public String adicionatranspcomplicacoescoracao(@RequestParam("terapeutica") int terapeutica, @RequestParam("observacaoterap") String observacaoterap, Model model, HttpSession session){

			Long id_assignacao = (Long) session.getAttribute("id_assigorgao");
			//colheita.setAnaliseDador(daoanalisedador.buscaPorId(id_analise));
			TransplanteCoracaoComplicacoes tf = new TransplanteCoracaoComplicacoes();
			
			AssignacaoOrgaos assig = new AssignacaoOrgaos();
			assig.setId_assignacao(id_assignacao);
			
			tf.setAssigorgao(assig);;
			tf.setComplicacao(terapeutica);
			tf.setNotascomplicacao(observacaoterap);
			
			daotranspcoracaocompl.adiciona(tf);
			
			model.addAttribute("complcoracao", tf);
			return "eqtransplante/loads/carregalinhacomplcoracao";
		}



		@RequestMapping(value="gravatranspcomplicacoescoracao")
		public String gravatranspcomplicacoescoracao(@RequestParam("terapeutica") int terapeutica, @RequestParam("observacaoterap") String observacaoterap, @RequestParam("idcolheitaterap") Long idcolheitaterap, Model model){

			//colheita.setAnaliseDador(daoanalisedador.buscaPorId(id_analise));
			TransplanteCoracaoComplicacoes tf = daotranspcoracaocompl.buscaPorId(idcolheitaterap);
			tf.setComplicacao(terapeutica);
			tf.setNotascomplicacao(observacaoterap);
			
			daotranspcoracaocompl.atualiza(tf);
			
			model.addAttribute("complcoracao", tf);
			return "eqtransplante/loads/carregalinhacomplcoracao";
		}


		@RequestMapping(value="deltranspcomplicacoescoracao")
		@ResponseBody
		public void deltranspcomplicacoescoracao(@RequestParam("idcolheitaterap") Long idcolheitaterap, Model model){

			//colheita.setAnaliseDador(daoanalisedador.buscaPorId(id_analise));
			TransplanteCoracaoComplicacoes tf = daotranspcoracaocompl.buscaPorId(idcolheitaterap);

			daotranspcoracaocompl.remove(tf);
		}
		//-----------fim tabela complica��es coracao----------------------//	
		
		@SuppressWarnings("rawtypes")
		@RequestMapping(value="gravatransplanteestadocoracao")
		@ResponseBody
		public String gravatransplanteestadocoracao(int estado, HttpSession session){

			Long id_assignacao = (Long) session.getAttribute("id_assigorgao");

			TransplanteCoracao tf = daotranspcoracao.buscaTransplanteCoracaoAssigorgao(id_assignacao);

			tf.setEstado(estado);
			
			daotranspcoracao.atualiza(tf);
			
			AnaliseRecetor ar = daoanaliserec.buscaAnaliseRecetorAssigOrg(id_assignacao);
			Recetores rec = daorecetor.buscaPorId(ar.getRecetor().getId_recetor());
			
			if(!daotransp.verificajafoitransplantado(rec.getId_recetor(), id_assignacao)){
					int snsrec = rec.getSns();
					Long unidadetr = rec.getUnidadetransp().getId_unidadetransplante();
					List<AnaliseRecetor> analisesrec= daorecetor.atualizainscricoestransplantado(snsrec, unidadetr, estado);
					if(!analisesrec.isEmpty()){
						Long idanaliserec = 0L;
						for (Iterator i = analisesrec.iterator(); i.hasNext();) {  
							AnaliseRecetor values = (AnaliseRecetor) i.next();
				        	idanaliserec =  values.getId_analiserecetor();
				        	
				        	EstadoRecetor estrec = new EstadoRecetor();
				    		AnaliseRecetor analiserec = new AnaliseRecetor();
				    		analiserec.setId_analiserecetor(idanaliserec);
				    		
				    		estrec.setAnaliserecetor(analiserec);
				    		estrec.setEstado(5);
				    		String notas = "";
				    		 if(estado==1){
				    				notas = "Vivo com enxerto";
				    			}else if(estado==2){
				    				notas = "Falecido";
				    			}
				    		estrec.setNotas(notas);
				    		estrec.setData(Calendar.getInstance());
				    		Utilizador user = new Utilizador();
				    		user.setID_Utilizador((Long)session.getAttribute("iduser"));
				    		estrec.setUser(user);
				        	
				        	daoestadorecetor.adiciona(estrec);
				        }
					}
			
			mudaestadorecetor(ar.getRecetor().getId_recetor(), id_assignacao);
			}
			return "OK";
		}
		
		//---------------FIM TRANSPLANTE CORACAO-------------------------------//
		
//---------------------------INICIO TRANSPLANTE PULMOES-------------------------------------------------//	
		@RequestMapping(value="registahorastransplantepulmoes" , produces="application/json")
		@ResponseBody
		public String registahoraspulmoes(@RequestParam("tipo") int tipo, HttpSession session){

			Long id_assignacao = (Long) session.getAttribute("id_assigorgao");
			
			//String time = "";
			int horas = 0;
			int mins = 0;
			long secs = 0;
			
			Calendar calfig = Calendar.getInstance();
			
			TransplantePulmoes tp = daotransppulmoes.buscaTransplantePulmoesAssigorgao(id_assignacao);
			
			if(tipo==1){
				tp.setInicio(calfig);
			}else if(tipo==2){
				tp.setFim(calfig);
			}else if(tipo==3){
				Dador dador = (Dador)session.getAttribute("dadororgao");
				AnaliseDador analise = daoanalisedador.buscaAnaliseDoDador(dador.getId_Dador());
				ColheitaGeral cg = daocolheitageral.buscacolheitageralanalise(analise.getId_AnaliseDador());
				
				Date date1 = cg.getClampagemgeral().getTime();
				Date date2 = calfig.getTime();
				//long difference = date2.getTime() - date1.getTime(); //em milisegundos
				
				secs = (date2.getTime() - date1.getTime())/1000;

				horas = (int) (secs / 3600);    
				secs = secs % 3600;

				mins = (int) (secs / 60);
				secs = secs % 60;

				String hr = String.format("%02d", horas);
				String mi = String.format("%02d", mins);
				String sec = String.format("%02d", secs);
				tp.setIsqdrt(hr+":"+mi+":"+sec);
			
			}else if(tipo==4){
				Dador dador = (Dador)session.getAttribute("dadororgao");
				AnaliseDador analise = daoanalisedador.buscaAnaliseDoDador(dador.getId_Dador());
				ColheitaGeral cg = daocolheitageral.buscacolheitageralanalise(analise.getId_AnaliseDador());
				
				Date date1 = cg.getClampagemgeral().getTime();
				Date date2 = calfig.getTime();
				//long difference = date2.getTime() - date1.getTime(); //em milisegundos
				
				secs = (date2.getTime() - date1.getTime())/1000;

				horas = (int) (secs / 3600);    
				secs = secs % 3600;

				mins = (int) (secs / 60);
				secs = secs % 60;

				String hr = String.format("%02d", horas);
				String mi = String.format("%02d", mins);
				String sec = String.format("%02d", secs);
				tp.setIsqesq(hr+":"+mi+":"+sec);				

			}
			
			daotransppulmoes.atualiza(tp);
			
			DateFormat dum = new SimpleDateFormat("dd/MM/yyyy HH:mm");
			String date = dum.format(calfig.getTime());
			return "[\""+date+"\",\""+horas+"\",\""+mins+"\",\""+secs+"\"]";

		}
		
		@RequestMapping(value="gravatransplantepulmoes")
		@ResponseBody
		public String gravatransplantepulmoes(TransplantePulmoes transplante, HttpSession session){

			TransplantePulmoes tp = daotransppulmoes.buscaPorId(transplante.getIdtransplantepulmoes());
			transplante.setInicio(tp.getInicio());
			transplante.setFim(tp.getFim());
			transplante.setIsqdrt(tp.getIsqdrt());
			transplante.setIsqesq(tp.getIsqesq());
			transplante.setEstado(tp.getEstado());
			
			daotransppulmoes.atualiza(transplante);
			
			return "OK";
		}
		
		
		@SuppressWarnings("rawtypes")
		@RequestMapping(value="gravatransplanteestadopulmoes")
		@ResponseBody
		public String gravatransplanteestadopulmoes(int estado, HttpSession session){

			Long id_assignacao = (Long) session.getAttribute("id_assigorgao");

			TransplantePulmoes tf = daotransppulmoes.buscaTransplantePulmoesAssigorgao(id_assignacao);

			tf.setEstado(estado);
			
			daotransppulmoes.atualiza(tf);
			
			
			AnaliseRecetor ar = daoanaliserec.buscaAnaliseRecetorAssigOrg(id_assignacao);
			Recetores rec = daorecetor.buscaPorId(ar.getRecetor().getId_recetor());
			
			if(!daotransp.verificajafoitransplantado(rec.getId_recetor(), id_assignacao)){
					int snsrec = rec.getSns();
					Long unidadetr = rec.getUnidadetransp().getId_unidadetransplante();
					List<AnaliseRecetor> analisesrec= daorecetor.atualizainscricoestransplantado(snsrec, unidadetr, estado);
					if(!analisesrec.isEmpty()){
						Long idanaliserec = 0L;
						for (Iterator i = analisesrec.iterator(); i.hasNext();) {  
							AnaliseRecetor values = (AnaliseRecetor) i.next();
				        	idanaliserec =  values.getId_analiserecetor();
				        	
				        	EstadoRecetor estrec = new EstadoRecetor();
				    		AnaliseRecetor analiserec = new AnaliseRecetor();
				    		analiserec.setId_analiserecetor(idanaliserec);
				    		
				    		estrec.setAnaliserecetor(analiserec);
				    		estrec.setEstado(5);
				    		String notas = "";
				    		 if(estado==1){
				    				notas = "Vivo com enxerto";
				    			}else if(estado==2){
				    				notas = "Falecido";
				    			}
				    		estrec.setNotas(notas);
				    		estrec.setData(Calendar.getInstance());
				    		Utilizador user = new Utilizador();
				    		user.setID_Utilizador((Long)session.getAttribute("iduser"));
				    		estrec.setUser(user);
				        	
				        	daoestadorecetor.adiciona(estrec);
				        }
					}
			
			mudaestadorecetor(ar.getRecetor().getId_recetor(), id_assignacao);
			}
			return "OK";
		}	
		
		//--------------------------------Inicio tabela transfus�es pulmoes----------------------------//


				@RequestMapping(value="adicionatransptransfpulmoes")
				public String adicionatransptransfpulmoes(@RequestParam("terapeutica") int terapeutica, @RequestParam("observacaoterap") String observacaoterap,
						@RequestParam("qtd") int qtd, Model model, HttpSession session){

					Long id_assignacao = (Long) session.getAttribute("id_assigorgao");

					TransplantePulmoesTransfusao tf = new TransplantePulmoesTransfusao();
					
					AssignacaoOrgaos assig = new AssignacaoOrgaos();
					assig.setId_assignacao(id_assignacao);
					
					tf.setAssigorgao(assig);;
					tf.setTransfusao(terapeutica);
					tf.setQtd(qtd);
					tf.setObservacoestransf(observacaoterap);
					
					daotransppulmoestransf.adiciona(tf);
					
					model.addAttribute("transfpulmoes", tf);
					return "eqtransplante/loads/carregalinhatransfusaopulmoes";
				}



				@RequestMapping(value="gravatransptransfpulmoes")
				public String gravatransptransfpulmoes(@RequestParam("terapeutica") int terapeutica, @RequestParam("observacaoterap") String observacaoterap, 
						@RequestParam("qtd") int qtd, @RequestParam("idcolheitaterap") Long idcolheitaterap, Model model){

					//colheita.setAnaliseDador(daoanalisedador.buscaPorId(id_analise));
					TransplantePulmoesTransfusao tf = daotransppulmoestransf.buscaPorId(idcolheitaterap);
					tf.setTransfusao(terapeutica);
					tf.setQtd(qtd);
					tf.setObservacoestransf(observacaoterap);
					
					daotransppulmoestransf.atualiza(tf);
					
					model.addAttribute("transfpulmoes", tf);
					return "eqtransplante/loads/carregalinhatransfusaopulmoes";
				}


				@RequestMapping(value="deltransptransfpulmoes")
				@ResponseBody
				public void deltransptransfpulmoes(@RequestParam("idcolheitaterap") Long idcolheitaterap, Model model){

					//colheita.setAnaliseDador(daoanalisedador.buscaPorId(id_analise));
					TransplantePulmoesTransfusao tf = daotransppulmoestransf.buscaPorId(idcolheitaterap);

					daotransppulmoestransf.remove(tf);
				}
				//-----------fim tabela transfus�es pulmoes----------------------//
				
				//--------------------------------Inicio tabela complica��es pulmoes----------------------------//


				@RequestMapping(value="adicionatranspcomplicacoespulmoes")
				public String adicionatranspcomplicacoespulmoes(@RequestParam("terapeutica") int terapeutica, @RequestParam("observacaoterap") String observacaoterap, Model model, HttpSession session){

					Long id_assignacao = (Long) session.getAttribute("id_assigorgao");
					//colheita.setAnaliseDador(daoanalisedador.buscaPorId(id_analise));
					TransplantePulmoesComplicacoes tf = new TransplantePulmoesComplicacoes();
					
					AssignacaoOrgaos assig = new AssignacaoOrgaos();
					assig.setId_assignacao(id_assignacao);
					
					tf.setAssigorgao(assig);;
					tf.setComplicacao(terapeutica);
					tf.setNotascomplicacao(observacaoterap);
					
					daotransppulmoescompl.adiciona(tf);
					
					model.addAttribute("complpulmoes", tf);
					return "eqtransplante/loads/carregalinhacomplpulmoes";
				}



				@RequestMapping(value="gravatranspcomplicacoespulmoes")
				public String gravatranspcomplicacoespulmoes(@RequestParam("terapeutica") int terapeutica, @RequestParam("observacaoterap") String observacaoterap, @RequestParam("idcolheitaterap") Long idcolheitaterap, Model model){

					//colheita.setAnaliseDador(daoanalisedador.buscaPorId(id_analise));
					TransplantePulmoesComplicacoes tf = daotransppulmoescompl.buscaPorId(idcolheitaterap);
					tf.setComplicacao(terapeutica);
					tf.setNotascomplicacao(observacaoterap);
					
					daotransppulmoescompl.atualiza(tf);
					
					model.addAttribute("complpulmoes", tf);
					return "eqtransplante/loads/carregalinhacomplpulmoes";
				}


				@RequestMapping(value="deltranspcomplicacoespulmoes")
				@ResponseBody
				public void deltranspcomplicacoespulmoes(@RequestParam("idcolheitaterap") Long idcolheitaterap, Model model){

					//colheita.setAnaliseDador(daoanalisedador.buscaPorId(id_analise));
					TransplantePulmoesComplicacoes tf = daotransppulmoescompl.buscaPorId(idcolheitaterap);

					daotransppulmoescompl.remove(tf);
				}
				//-----------fim tabela complica��es pulmoes----------------------//	
				
				//--------------------------------Inicio tabela complica��es uci pulmoes----------------------------//


				@RequestMapping(value="adicionatranspcomplicacoespulmoesuci")
				public String adicionatranspcomplicacoespulmoesuci(@RequestParam("terapeutica") int terapeutica, @RequestParam("observacaoterap") String observacaoterap, Model model, HttpSession session){

					Long id_assignacao = (Long) session.getAttribute("id_assigorgao");
					//colheita.setAnaliseDador(daoanalisedador.buscaPorId(id_analise));
					TransplantePulmoesComplicacoesUCI tf = new TransplantePulmoesComplicacoesUCI();
					
					AssignacaoOrgaos assig = new AssignacaoOrgaos();
					assig.setId_assignacao(id_assignacao);
					
					tf.setAssigorgao(assig);;
					tf.setComplicacao(terapeutica);
					tf.setNotascomplicacao(observacaoterap);
					
					daotransppulmoescompluci.adiciona(tf);
					
					model.addAttribute("complpulmoes", tf);
					return "eqtransplante/loads/carregalinhacomplpulmoesuci";
				}



				@RequestMapping(value="gravatranspcomplicacoespulmoesuci")
				public String gravatranspcomplicacoespulmoesuci(@RequestParam("terapeutica") int terapeutica, @RequestParam("observacaoterap") String observacaoterap, @RequestParam("idcolheitaterap") Long idcolheitaterap, Model model){

					//colheita.setAnaliseDador(daoanalisedador.buscaPorId(id_analise));
					TransplantePulmoesComplicacoesUCI tf = daotransppulmoescompluci.buscaPorId(idcolheitaterap);
					tf.setComplicacao(terapeutica);
					tf.setNotascomplicacao(observacaoterap);
					
					daotransppulmoescompluci.atualiza(tf);
					
					model.addAttribute("complpulmoes", tf);
					return "eqtransplante/loads/carregalinhacomplpulmoesuci";
				}


				@RequestMapping(value="deltranspcomplicacoespulmoesuci")
				@ResponseBody
				public void deltranspcomplicacoespulmoesuci(@RequestParam("idcolheitaterap") Long idcolheitaterap, Model model){

					//colheita.setAnaliseDador(daoanalisedador.buscaPorId(id_analise));
					TransplantePulmoesComplicacoesUCI tf = daotransppulmoescompluci.buscaPorId(idcolheitaterap);

					daotransppulmoescompluci.remove(tf);
				}
				//-----------fim tabela complica��es uci pulmoes----------------------//	
				
//------------------------------FIM TRANSPLANTE PULMOES-------------------------------------------------//	
				
//------------------------------INICIO TRANSPLANTE RINS-------------------------------------------------//	
				@RequestMapping(value="registahorastransplanterins" , produces="application/json")
				@ResponseBody
				public String registahorasrins(@RequestParam("tipo") int tipo, HttpSession session){

					Long id_assignacao = (Long) session.getAttribute("id_assigorgao");
					
					//String time = "";
					int horas = 0;
					int mins = 0;
					long secs = 0;
					String isqtotal = "";
					String cdah = "";
					
					Calendar calfig = Calendar.getInstance();
					
					TransplanteRins tf = daotransprins.buscaTransplanteRinsAssigorgao(id_assignacao);
					
					if(tipo==1){
						tf.setInicio(calfig);
					}else if(tipo==2){
						tf.setClampvenosa(calfig);
					}else if(tipo==3){
						tf.setRetirargelo(calfig);
						Dador dador = (Dador)session.getAttribute("dadororgao");
						AnaliseDador analise = daoanalisedador.buscaAnaliseDoDador(dador.getId_Dador());
						ColheitaGeral cg = daocolheitageral.buscacolheitageralanalise(analise.getId_AnaliseDador());
						
						Date date1 = cg.getClampagemgeral().getTime();
						Date date2 = calfig.getTime();
						//long difference = date2.getTime() - date1.getTime(); //em milisegundos
						
						secs = (date2.getTime() - date1.getTime())/1000;

						horas = (int) (secs / 3600);    
						secs = secs % 3600;

						mins = (int) (secs / 60);
						secs = secs % 60;

						String hr = String.format("%02d", horas);
						String mi = String.format("%02d", mins);
						String sec = String.format("%02d", secs);
						
						tf.setIsqfria(hr+":"+mi+":"+sec);
					}else if(tipo==4){
						tf.setDesclampvenosa(calfig);
						
						//isq quente
						Date date1 = tf.getRetirargelo().getTime();
						Date date2 = calfig.getTime();
						
						secs = (date2.getTime() - date1.getTime())/1000;

						horas = (int) (secs / 3600);    
						secs = secs % 3600;

						mins = (int) (secs / 60);
						secs = secs % 60;

						String hrq = String.format("%02d", horas);
						String miq = String.format("%02d", mins);
						String secq = String.format("%02d", secs);
						tf.setIsqquente(hrq+":"+miq+":"+secq);
						
						//isq total
						Dador dador = (Dador)session.getAttribute("dadororgao");
						AnaliseDador analise = daoanalisedador.buscaAnaliseDoDador(dador.getId_Dador());
						ColheitaGeral cg = daocolheitageral.buscacolheitageralanalise(analise.getId_AnaliseDador());
						
						Date date1t = cg.getClampagemgeral().getTime();
						Date date2t = calfig.getTime();
						//long difference = date2.getTime() - date1.getTime(); //em milisegundos
						
						long secst = (date2t.getTime() - date1t.getTime())/1000;
						int horast = (int) (secst / 3600);    
						secst = secst % 3600;
						int minst = (int) (secst / 60);
						secst = secst % 60;
						
						String hr = String.format("%02d", horast);
						String mi = String.format("%02d", minst);
						String sec = String.format("%02d", secst);
						
						tf.setIsqtotal(hr+":"+mi+":"+sec);
						
						isqtotal = hr+":"+mi+":"+sec;
						
						Date date1ah = tf.getClampvenosa().getTime();
						Date date2ah = calfig.getTime();
						
						long secsah = (date2ah.getTime() - date1ah.getTime())/1000;
						int horasah = (int) (secsah / 3600);    
						secsah = secsah % 3600;
						int minsah = (int) (secsah / 60);
						secsah = secsah % 60;
						
						String hrah = String.format("%02d", horasah);
						String miah = String.format("%02d", minsah);
						String secah = String.format("%02d", secsah);
						
						cdah = hrah+":"+miah+":"+secah;
						
						tf.setClampdescVenosa(cdah);
					}else if(tipo==5){
						tf.setClamparterial(calfig);
					}else if(tipo==6){
						tf.setDesclamparterial(calfig);
						Date date1cd = tf.getClamparterial().getTime();
						Date date2cd = calfig.getTime();
						
						long secscd = (date2cd.getTime() - date1cd.getTime())/1000;
						int horascd = (int) (secscd / 3600);    
						secscd = secscd % 3600;
						int minscd = (int) (secscd / 60);
						secscd = secscd % 60;
						
						String hrcd = String.format("%02d", horascd);
						String micd = String.format("%02d", minscd);
						String seccd = String.format("%02d", secscd);
						
						isqtotal = hrcd+":"+micd+":"+seccd;
						
						tf.setClampdescArterial(isqtotal);
					}else if(tipo==7){
						tf.setTempourologinicio(calfig);
					}else if(tipo==8){	
						tf.setTempourologfim(calfig);
						Date date1cd = tf.getTempourologinicio().getTime();
						Date date2cd = calfig.getTime();
						
						long secscd = (date2cd.getTime() - date1cd.getTime())/1000;
						int horascd = (int) (secscd / 3600);    
						secscd = secscd % 3600;
						int minscd = (int) (secscd / 60);
						secscd = secscd % 60;
						
						String hrcd = String.format("%02d", horascd);
						String micd = String.format("%02d", minscd);
						String seccd = String.format("%02d", secscd);
						
						isqtotal = hrcd+":"+micd+":"+seccd;
						
						tf.setTempourologico(isqtotal);
						
					}else if(tipo==9){	
						tf.setFim(calfig);				
					}
					
					daotransprins.atualiza(tf);
					
					DateFormat dum = new SimpleDateFormat("dd/MM/yyyy HH:mm");
					String date = dum.format(calfig.getTime());
					return "[\""+date+"\",\""+horas+"\",\""+mins+"\",\""+secs+"\",\""+isqtotal+"\",\""+cdah+"\"]";
				}
				
				@RequestMapping(value="gravatransplanterins")
				@ResponseBody
				public String gravatransplanterins(TransplanteRins transplante, HttpSession session){

					TransplanteRins tp = daotransprins.buscaPorId(transplante.getIdtransplanterins());
					transplante.setInicio(tp.getInicio());
					transplante.setClampvenosa(tp.getClampvenosa());
					transplante.setRetirargelo(tp.getRetirargelo());
					transplante.setDesclampvenosa(tp.getDesclampvenosa());
					transplante.setClamparterial(tp.getClamparterial());
					transplante.setDesclamparterial(tp.getDesclamparterial());
					transplante.setTempourologinicio(tp.getTempourologinicio());
					transplante.setTempourologfim(tp.getTempourologfim());
					transplante.setFim(tp.getFim());
					transplante.setIsqfria(tp.getIsqfria());
					transplante.setIsqquente(tp.getIsqquente());
					transplante.setIsqtotal(tp.getIsqtotal());
					transplante.setClampdescArterial(tp.getClampdescArterial());
					transplante.setClampdescVenosa(tp.getClampdescVenosa());
					transplante.setTempourologico(tp.getTempourologico());
					
					daotransprins.atualiza(transplante);
					
					return "OK";
				}
				
				
				@SuppressWarnings("rawtypes")
				@RequestMapping(value="gravatransplanteestadorins")
				@ResponseBody
				public String gravatransplanteestadorins(int estado, HttpSession session){

					Long id_assignacao = (Long) session.getAttribute("id_assigorgao");

					TransplanteRins tf = daotransprins.buscaTransplanteRinsAssigorgao(id_assignacao);

					tf.setEstado(estado);
					
					daotransprins.atualiza(tf);
					
					
					AnaliseRecetor ar = daoanaliserec.buscaAnaliseRecetorAssigOrg(id_assignacao);
					Recetores rec = daorecetor.buscaPorId(ar.getRecetor().getId_recetor());
					
					if(!daotransp.verificajafoitransplantado(rec.getId_recetor(), id_assignacao)){
							int snsrec = rec.getSns();
							Long unidadetr = rec.getUnidadetransp().getId_unidadetransplante();
							List<AnaliseRecetor> analisesrec= daorecetor.atualizainscricoestransplantado(snsrec, unidadetr, estado);
							if(!analisesrec.isEmpty()){
								Long idanaliserec = 0L;
								for (Iterator i = analisesrec.iterator(); i.hasNext();) {  
									AnaliseRecetor values = (AnaliseRecetor) i.next();
						        	idanaliserec =  values.getId_analiserecetor();
						        	
						        	EstadoRecetor estrec = new EstadoRecetor();
						    		AnaliseRecetor analiserec = new AnaliseRecetor();
						    		analiserec.setId_analiserecetor(idanaliserec);
						    		
						    		estrec.setAnaliserecetor(analiserec);
						    		estrec.setEstado(5);
						    		String notas = "";
						    		 if(estado==1){
						    				notas = "Vivo com enxerto";
						    			}else if(estado==2){
						    				notas = "Vivo sem enxerto";
						    			}else if(estado==3){
						    				notas = "Falecido";
						    			}
						    		estrec.setNotas(notas);
						    		estrec.setData(Calendar.getInstance());
						    		Utilizador user = new Utilizador();
						    		user.setID_Utilizador((Long)session.getAttribute("iduser"));
						    		estrec.setUser(user);
						        	
						        	daoestadorecetor.adiciona(estrec);
						        }
							}
					
					mudaestadorecetor(ar.getRecetor().getId_recetor(), id_assignacao);
					}
					return "OK";
				}	
				//-------------------------------- Inicio Tabela perfus�o rins----------------------------------//


				@RequestMapping(value="adicionaperftransplanterins")
				public String adicionaperftransplanterins(@RequestParam("perfusao") int perfusao, @RequestParam("tipo") int tipo,  @RequestParam("volume") float volume,
						@RequestParam("inicio") String inicio, @RequestParam("fim") String fim, @RequestParam("qualidade") int qualidade, 
						@RequestParam("teste") boolean teste, Model model, HttpSession session) throws ParseException{

					Long id_assignacao = (Long) session.getAttribute("id_assigorgao");
					//colheita.setAnaliseDador(daoanalisedador.buscaPorId(id_analise));
					TransplanteRinsPerfusao perf = new TransplanteRinsPerfusao();
					
					
					AssignacaoOrgaos assig = new AssignacaoOrgaos();
					assig.setId_assignacao(id_assignacao);
					
					
					perf.setAssigorgao(assig);
					perf.setPerfusao(perfusao);
					perf.setTipo(tipo);
					perf.setVolume(volume);
					
					DateFormat df = new SimpleDateFormat("HH:mm");
					Date date = df.parse(inicio);
					Calendar in = Calendar.getInstance();
					in.setTime(date);
					perf.setInicio(in);
					
					Date date2 = df.parse(fim);
					Calendar f = Calendar.getInstance();
					f.setTime(date2);
					perf.setFim(f);
					
					perf.setQualidade(qualidade);
					perf.setIr(teste);
							
					daotransprinsperf.adiciona(perf);
					
					model.addAttribute("rinsperf", perf);
					return "eqtransplante/loads/carregalinhaperfusaorins";
				}


				@RequestMapping(value="gravaperftransplanterins")
				public String gravaperftransplanterins(@RequestParam("idperfrins") Long idperfrins, @RequestParam("perfusao") int perfusao, @RequestParam("tipo") int tipo,  
						@RequestParam("volume") float volume,	@RequestParam("inicio") String inicio, @RequestParam("fim") String fim, 
						@RequestParam("qualidade") int qualidade, @RequestParam("teste") boolean teste, Model model) throws ParseException{
					
					TransplanteRinsPerfusao perf = daotransprinsperf.buscaPorId(idperfrins);
					perf.setPerfusao(perfusao);
					perf.setTipo(tipo);
					//perf.setVia(via);
					perf.setVolume(volume);
					
					DateFormat df = new SimpleDateFormat("HH:mm");
					Date date = df.parse(inicio);
					Calendar in = Calendar.getInstance();
					in.setTime(date);
					perf.setInicio(in);
					
					Date date2 = df.parse(fim);
					Calendar f = Calendar.getInstance();
					f.setTime(date2);
					perf.setFim(f);
					perf.setQualidade(qualidade);
					perf.setIr(teste);
					
					daotransprinsperf.atualiza(perf);
					
					model.addAttribute("rinsperf", perf);
					return "eqtransplante/loads/carregalinhaperfusaorins";
				}

				@RequestMapping(value="delperftransplanterins")
				@ResponseBody
				public void delperftransplanterins(@RequestParam("idperfrins") Long idperfrins, Model model){

					//colheita.setAnaliseDador(daoanalisedador.buscaPorId(id_analise));
					TransplanteRinsPerfusao perf = daotransprinsperf.buscaPorId(idperfrins);

					daotransprinsperf.remove(perf);
				}
				//-------------------------------- Fim Tabela perfus�o rins----------------------------------//				
				
				//--------------------------------Inicio tabela complica��es rins----------------------------//


				@RequestMapping(value="adicionatranspcomplicacoesrins")
				public String adicionatranspcomplicacoesrins(@RequestParam("terapeutica") int terapeutica, @RequestParam("observacaoterap") String observacaoterap, Model model, HttpSession session){

					Long id_assignacao = (Long) session.getAttribute("id_assigorgao");
					//colheita.setAnaliseDador(daoanalisedador.buscaPorId(id_analise));
					TransplanteRinsComplicacoes tf = new TransplanteRinsComplicacoes();
					
					AssignacaoOrgaos assig = new AssignacaoOrgaos();
					assig.setId_assignacao(id_assignacao);
					
					tf.setAssigorgao(assig);;
					tf.setComplicacao(terapeutica);
					tf.setNotascomplicacao(observacaoterap);
					
					daotransprinscompl.adiciona(tf);
					
					model.addAttribute("complrins", tf);
					return "eqtransplante/loads/carregalinhacomplrins";
				}



				@RequestMapping(value="gravatranspcomplicacoesrins")
				public String gravatranspcomplicacoesrins(@RequestParam("terapeutica") int terapeutica, @RequestParam("observacaoterap") String observacaoterap, @RequestParam("idcolheitaterap") Long idcolheitaterap, Model model){

					//colheita.setAnaliseDador(daoanalisedador.buscaPorId(id_analise));
					TransplanteRinsComplicacoes tf = daotransprinscompl.buscaPorId(idcolheitaterap);
					tf.setComplicacao(terapeutica);
					tf.setNotascomplicacao(observacaoterap);
					
					daotransprinscompl.atualiza(tf);
					
					model.addAttribute("complrins", tf);
					return "eqtransplante/loads/carregalinhacomplrins";
				}


				@RequestMapping(value="deltranspcomplicacoesrins")
				@ResponseBody
				public void deltranspcomplicacoesrins(@RequestParam("idcolheitaterap") Long idcolheitaterap, Model model){

					//colheita.setAnaliseDador(daoanalisedador.buscaPorId(id_analise));
					TransplanteRinsComplicacoes tf = daotransprinscompl.buscaPorId(idcolheitaterap);

					daotransprinscompl.remove(tf);
				}
				//-----------fim tabela complica��es rins----------------------//	
				
				//--------------------------------Inicio tabela transfus�es rins----------------------------//


				@RequestMapping(value="adicionatransptransfrins")
				public String adicionatransptransfrins(@RequestParam("terapeutica") int terapeutica, @RequestParam("observacaoterap") String observacaoterap,
						@RequestParam("qtd") int qtd, Model model, HttpSession session){

					Long id_assignacao = (Long) session.getAttribute("id_assigorgao");

					TransplanteRinsTransfusao tf = new TransplanteRinsTransfusao();
					
					AssignacaoOrgaos assig = new AssignacaoOrgaos();
					assig.setId_assignacao(id_assignacao);
					
					tf.setAssigorgao(assig);;
					tf.setTransfusao(terapeutica);
					tf.setQtd(qtd);
					tf.setObservacoestransf(observacaoterap);
					
					daotransprinstransf.adiciona(tf);
					
					model.addAttribute("transfrins", tf);
					return "eqtransplante/loads/carregalinhatransfusaorins";
				}



				@RequestMapping(value="gravatransptransfrins")
				public String gravatransptransfrins(@RequestParam("terapeutica") int terapeutica, @RequestParam("observacaoterap") String observacaoterap, 
						@RequestParam("qtd") int qtd, @RequestParam("idcolheitaterap") Long idcolheitaterap, Model model){

					//colheita.setAnaliseDador(daoanalisedador.buscaPorId(id_analise));
					TransplanteRinsTransfusao tf = daotransprinstransf.buscaPorId(idcolheitaterap);
					tf.setTransfusao(terapeutica);
					tf.setQtd(qtd);
					tf.setObservacoestransf(observacaoterap);
					
					daotransprinstransf.atualiza(tf);
					
					model.addAttribute("transfrins", tf);
					return "eqtransplante/loads/carregalinhatransfusaorins";
				}


				@RequestMapping(value="deltransptransfrins")
				@ResponseBody
				public void deltransptransfrins(@RequestParam("idcolheitaterap") Long idcolheitaterap, Model model){

					//colheita.setAnaliseDador(daoanalisedador.buscaPorId(id_analise));
					TransplanteRinsTransfusao tf = daotransprinstransf.buscaPorId(idcolheitaterap);

					daotransprinstransf.remove(tf);
				}
				//-----------fim tabela transfus�es rins----------------------//	
				
//------------------------------FIM TRANSPLANTE RINS-------------------------------------------------//					

				@RequestMapping(value="carregaseparadorequipatransplante")
				public String carregaseparadorequipatransplante(Model model, HttpSession session){
					
					Long id_assigorg = (Long) session.getAttribute("id_assigorgao");
			//		System.out.println("idassigorg: "+id_assigorg);
					Dador dador = (Dador)session.getAttribute("dadororgao");
					model.addAttribute("local",daohosp.ListaHospitais());
					model.addAttribute("el",daoequipalocaltransplante.buscaequipalocaltransplante(id_assigorg));
					model.addAttribute("equipacirurgia",daoequipacirurgiatransplante.buscaequipacirurgiatransplanteassigorgao(id_assigorg));
					model.addAttribute("assignacao", daoAssigOrg.ListaAssignacaoOrgaosDador(dador.getId_Dador()));
					model.addAttribute("cirurgiao", daouser.buscacirurgioes());
					model.addAttribute("equipasuporte",daoequipasuportetransplante.buscaequipacsuportetransplanteassigorgao(id_assigorg));
					model.addAttribute("idorgaooferta",daoorgaooferta.buscaPorId((int)session.getAttribute("orgaodadoroferta")));
					model.addAttribute("idhospitaluser", session.getAttribute("idlocalizacao"));
					//return "eqtransplante/divseparadorequipatransplanteleitura";
					if((boolean)session.getAttribute("leituraescritaeqcirurgica")){
					return "eqtransplante/divseparadorequipatransplante";
					}else{
						return "eqtransplante/divseparadorequipatransplanteleitura";	
					}
				}
				
				
//---------------------------------------------ACEITA��O REJEI��O DE ORG�OS-------------------------------------------//	
				
				@SuppressWarnings("unchecked")
				@RequestMapping(value="aceitatransplante", method = RequestMethod.POST)
				@ResponseBody
				public void aceitatransplante(@RequestParam("aceita") boolean aceita, Model model, HttpSession session){			
					Long id_assigorg = (Long) session.getAttribute("id_assigorgao");
					Long idhosp = (Long) session.getAttribute("idlocalizacao");
					Dador d = (Dador)session.getAttribute("dadororgao");
					
					if(aceita==true){
						
					daoAssighosp.atualizacaoaceitacaoorgao(id_assigorg, idhosp, 3); //3- Estado Aceite
					//passar os outros a recusado
					daoAssighosp.rejeitaosoutroshospitais(id_assigorg, idhosp);
					//insere rejei��o nos outros que n�o o que aceitou para esse org�o desse dador
					daohistorico.insererejeicaohistoricoaposaceitacao(id_assigorg, idhosp, d.getId_Dador());
					daohistorico.insereaceitacaoorgaohistorico(id_assigorg, idhosp, d.getId_Dador(), 3);
					
					
					}else if (aceita==false){
						daoAssighosp.atualizacaoaceitacaoorgao(id_assigorg, idhosp, 2); //2- Estado N�o Aceite
						daohistorico.insereaceitacaoorgaohistorico(id_assigorg, idhosp, d.getId_Dador(), 2);
						
						
//						notificacao org�o recusado:
							OrgaosOferta orgao = daoorgaooferta.buscaPorId((int)session.getAttribute("orgaodadoroferta"));
							Hospital h = daohosp.buscaPorId(idhosp);
							List<Long> users = daouser.buscausershospitalorgaorecusado(idhosp, d.getId_Dador());
							NotificationsController notificacao = new NotificationsController();
							JSONArray perfis = new JSONArray();
						//	perfis.add("EC");
						//	perfis.add("ECT");
							perfis.add("IPST");	
							// perfis.add("GCCT");
							String msg = h.getNomeHospital()+" recusou " +orgao.getNomeorgaooferta()+ " no processo "+ d.getCodigoDador();
							notificacao.envianotificacao(users, 10, perfis, orgao.getNomeorgaooferta(), msg, d.getCodigoDador(), 3);
					}
				}		
				
//-----------------------------------------FIM DE ACEITA��O DE ORG�OS---------------------------------//
				
				
				@RequestMapping(value="carreganomedocrelatoriocst", method = RequestMethod.POST)
				public String carreganomedocrelatoriocst(@RequestParam("id_analiserecetortransp") Long id, Model model) {
					model.addAttribute("analiserectransp", daoanaliserectransp.buscaPorId(id));
					return "eqtransplante/caminhodocrelatoriocst";
					}
//-----------------ESTADO DO CANDIDATO-----------------//
				
				
				@SuppressWarnings("unchecked")
				@RequestMapping(value="atualizaestadocandidato", method = RequestMethod.POST)
				public String atualizaestadocandidatoanaliserectransp(@RequestParam("idrecetor") Long id, @RequestParam("estado") int estado, Model model, HttpSession session) {

					//atualizar estado candidato
					Long idassigorg = (Long) session.getAttribute("id_assigorgao");
					
					EstadoAnaliseRecetor ear = new EstadoAnaliseRecetor();
					ear.setIdestadoanalise(estado);
					
					AnaliseRecetorTransplante art = daoanaliserectransp.buscaAnaliseRecetorTransplanteOrgao(id, idassigorg);
					art.setEstadoanaliserecetor(ear);
					daoanaliserectransp.atualiza(art);
					
					Long id_hospital = (Long)session.getAttribute("idlocalizacao");
					
					//carregar recetores desse org�o
					int idorgaooferta =  (int) session.getAttribute("orgaodadoroferta");
					
					
/*					if(estado == 3){//escolhido
						//atualizar restantes para em espera
						
						daorecetor.atualizarestantescandidatosespera(idorgaooferta, id_hospital, rec.getId_recetor());
					}*/
					
					if(estado == 2){
						String orgao = "";
				        switch (idorgaooferta) {
			            case 1:  orgao = "Cora��o";
			                     break;
			            case 2:  orgao = "Figado";
			                     break;
			            case 3:  orgao = "Pulm�es";
			            		break;
			            case 4:  orgao = "Pulm�o esquerdo";
	                    		break;
			            case 5:  orgao = "Pulm�o direito";
	                    		break;
			            case 6:  orgao = "P�ncreas";
			            		break;
			            case 7:  orgao = "Rins";
	            				break;
			            case 8:  orgao = "Rim esquerdo";
	            				break;
			            default: orgao = "Rim direito";
	                    		break;
				        }
	//					notificacao novo candidato em analise:
						Dador d = (Dador)session.getAttribute("dadororgao");
						//System.out.println("coddador: "+d.getCodigoDador()+" , org�o: "+orgao);
						Hospital h = daohosp.buscaPorId(id_hospital);
						List<Long> users = daouser.buscausershospitalcandidatoanalise(id_hospital);
						NotificationsController notificacao = new NotificationsController();
						JSONArray perfis = new JSONArray();
						/*perfis.add("EC");*/
						perfis.add("IPST");			
						String msg = "Candidato adicionado para org�o " +orgao+ " no hospital "+h.getNomeHospital();
						notificacao.envianotificacao(users, 7, perfis, "", msg, d.getCodigoDador(), 2);
					
					}
					
					if(estado == 3){

	//					notificacao candidato seleccionado:
						Dador d = (Dador)session.getAttribute("dadororgao");

						List<Long> users = daouser.buscausershospitalcandidatoseleccionado(id_hospital, d.getId_Dador());
						NotificationsController notificacao = new NotificationsController();
						JSONArray perfis = new JSONArray();
/*						perfis.add("GCCT");
						perfis.add("EC");
						perfis.add("ECT");*/
						perfis.add("IPST");			
						String msg = "Candidato "+d.getCodigoDador()+" seleccionado." ;
						notificacao.envianotificacao(users, 9, perfis, "", msg, d.getCodigoDador(), 2);
						
						
					//	notificacao candidato seleccionado em outro hospital:
					//	buscar se esse sns est� inscrito em outros hospitais e n�o consta no estadorecetor como transplantado
						Recetores rec = daorecetor.buscaPorId(id);
						List<Long> users2 = daouser.buscausershospitalonderecetoroutrasinscricoes(id_hospital, idorgaooferta, rec.getSns());
						if(users2.size()>0){
							NotificationsController notificacao2 = new NotificationsController();
							JSONArray perfis2 = new JSONArray();
							perfis2.add("");
							String orgao2 = "";
					        switch (idorgaooferta) {
				            case 1:  orgao2 = "Cora��o";
				                     break;
				            case 2:  orgao2 = "Figado";
				                     break;
				            case 3:  orgao2 = "Pulm�es";
				            		break;
				            case 4:  orgao2 = "Pulm�o esquerdo";
		                    		break;
				            case 5:  orgao2 = "Pulm�o direito";
		                    		break;
				            case 6:  orgao2 = "P�ncreas";
				            		break;
				            case 7:  orgao2 = "Rins";
		            				break;
				            case 8:  orgao2 = "Rim esquerdo";
		            				break;
				            default: orgao2 = "Rim direito";
		                    		break;
					        }
							String msg2 = orgao2+" do processo "+d.getCodigoDador()+" j� n�o est� dispon�vel";
							notificacao2.envianotificacao(users2, 11, perfis2, orgao2, msg2, d.getCodigoDador(), 3);
						}
					}
					if(idorgaooferta==1){
						//carrega candidatos cora��o UT1
						model.addAttribute("candidatos", daorecetor.buscacandidatosorgaohospital(1L, id_hospital, idassigorg, idorgaooferta));
						
						return "eqtransplante/tabelacandidatos";	
					}else
					if(idorgaooferta==2){
							//carrega candidatos figado UT2
						model.addAttribute("candidatos", daorecetor.buscacandidatosorgaohospital(2L, id_hospital, idassigorg, idorgaooferta));
							
						return "eqtransplante/tabelacandidatos";		
					}else
					if(idorgaooferta==3 || idorgaooferta==4 || idorgaooferta==5){
						//carrega candidatos pulm�o UT3
						model.addAttribute("candidatos", daorecetor.buscacandidatosorgaohospital(3L, id_hospital, idassigorg, idorgaooferta));
						
						return "eqtransplante/tabelacandidatos";	
						
					}else
						if(idorgaooferta==6){
							//carrega candidatos p�ncreas UT4
							model.addAttribute("candidatos", daorecetor.buscacandidatosorgaohospital(4L, id_hospital, idassigorg, idorgaooferta));	
							return "eqtransplante/tabelacandidatos";	
					
					}else{
						//carrega candidatos rins UT5
						model.addAttribute("candidatos", daorecetor.buscacandidatosorgaohospital(5L, id_hospital, idassigorg, idorgaooferta));
						return "eqtransplante/rins/tabelacandidatosrins";
					}
					
					
			}
				//------------------------------ CRIA NOVO REGISTO DE TRANSPLANTE --------------------------------//
				

				@RequestMapping(value="crianovotransplante")
				@ResponseBody
				public String crianovotransplante(@RequestParam("tipo") int tipo, Model model, HttpSession session)
				{
					Dador dador = (Dador)session.getAttribute("dadororgao");
					AnaliseDador analise = daoanalisedador.buscaAnaliseDoDador(dador.getId_Dador());
										
					String orgao = "";
					
					OrgaosOferta org = daoorgaooferta.buscaPorId((int) session.getAttribute("orgaodadoroferta"));
					
					orgao = org.getNomeorgaooferta();

					if(!daogcctcolheita.verificaexisteanaliseorgao(analise.getId_AnaliseDador(), orgao)){
						//System.out.println("1");
					GCCTColheita gcc = new GCCTColheita();
					gcc.setAto("Transplante");
					gcc.setAnaliseDador(analise);
					gcc.setCodigodador(dador.getCodigoDador());
					gcc.setDador(dador);
					gcc.setDatacolheita(Calendar.getInstance());
					gcc.setEstado(0);
					gcc.setHospital(daohosp.buscaPorId(daoDador.buscaIdHospital(dador.getId_Dador())));
					
					gcc.setEntidade(daoentidade.buscaPorId(daohosp.buscaIdEntidade(daoDador.buscaIdHospital(dador.getId_Dador()))));
					
					gcc.setTipo(orgao);
					
					daogcctcolheita.adiciona(gcc);
					
					GCCTColheitaDetalhe gct = new GCCTColheitaDetalhe();
					gct.setEstado(0);
					gct.setGcctcolheita(gcc);
					

					gct.setOrgao(orgao);
					
					daogcctcolheitadet.adiciona(gct);
					}
					return "true";
				}
							
			//------------------------------ FIM NOVO REGISTO DE TRANSPLANTE --------------------------------//		
				
//----------------------------------------FILTRAR TABELA TRANSPLANTES------------------//		
				@RequestMapping(value="filtratransplantes", method = RequestMethod.POST)
				public String filtradadores(@RequestParam("tipo") int tipo, @RequestParam("dataum") String dataum, @RequestParam("datadois") String datadois, Model model, RedirectAttributes ra, HttpSession session) throws ParseException
				{
					DateFormat di = new SimpleDateFormat("dd/MM/yyyy");
					DateFormat df = new SimpleDateFormat("dd/MM/yyyy");
					
					Date datei = di.parse(dataum);
					Calendar cal = Calendar.getInstance();
					cal.setTime(datei);
					
					Date datef = df.parse(datadois);
					Calendar cal2 = Calendar.getInstance();
					cal2.setTime(datef);
					
					Long idhospital = (Long)session.getAttribute("idlocalizacao");
							
				//	model.addAttribute("transplantes",daoDador.ListaDadorPermissaoFiltrado((Long)session.getAttribute("idposicao"), (Long)session.getAttribute("iduser"), tipo, cal, cal2,(Long)session.getAttribute("idlocalizacao")));
					if(tipo != 1){
						model.addAttribute("transplantes",daoeqtransplantes.carregatransplanteshospitalfiltro(cal, cal2, idhospital));
						
					}else{
						model.addAttribute("transplantes", daoeqtransplantes.carregatransplanteshospital(idhospital));
					}
					
					
					return "eqtransplante/loads/tabelatransplantes";
				}			
				
}
