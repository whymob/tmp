package pt.iconic.ipst.modelo;

import java.util.Calendar;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import org.springframework.format.annotation.DateTimeFormat;

@Entity
@Table(name = "TRANSPLANTE_POS_OPERATORIO")
public class TransplantePosOperatorio {

	private Long idtransplanteposop;
	private int complicacoes;
	private int th;
	private int diasuci;
	private int dialise;
	private int urina;
	private int biopsia;
	private int reducreatina;
	private int centrodialise;
	private float creatinina;
	private Calendar reinicio;
	private Calendar data;
	private AssignacaoOrgaos assigorgao;
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="ID_TRANSP_POS_OP")
	public Long getIdtransplanteposop() {
		return idtransplanteposop;
	}
	public void setIdtransplanteposop(Long idtransplanteposop) {
		this.idtransplanteposop = idtransplanteposop;
	}
	
	@Column(name="COMPLICACOES")
	public int getComplicacoes() {
		return complicacoes;
	}
	public void setComplicacoes(int complicacoes) {
		this.complicacoes = complicacoes;
	}
	
	@Column(name="TH")
	public int getTh() {
		return th;
	}
	public void setTh(int th) {
		this.th = th;
	}
	
	@Column(name="DIAS_UCI")
	public int getDiasuci() {
		return diasuci;
	}
	public void setDiasuci(int diasuci) {
		this.diasuci = diasuci;
	}
	
	@Column(name="DIALISE")
	public int getDialise() {
		return dialise;
	}
	public void setDialise(int dialise) {
		this.dialise = dialise;
	}
	
	@Column(name="URINA")
	public int getUrina() {
		return urina;
	}
	public void setUrina(int urina) {
		this.urina = urina;
	}
	
	@Column(name="BIOPSIA")
	public int getBiopsia() {
		return biopsia;
	}
	public void setBiopsia(int biopsia) {
		this.biopsia = biopsia;
	}
	
	@Column(name="REDU_CREATINA")
	public int getReducreatina() {
		return reducreatina;
	}
	public void setReducreatina(int reducreatina) {
		this.reducreatina = reducreatina;
	}
	
	@Column(name="CENTRO_DIALISE")
	public int getCentrodialise() {
		return centrodialise;
	}
	public void setCentrodialise(int centrodialise) {
		this.centrodialise = centrodialise;
	}
	
	@Column(name="CREATININA")
	public float getCreatinina() {
		return creatinina;
	}
	public void setCreatinina(float creatinina) {
		this.creatinina = creatinina;
	}
	
	@DateTimeFormat(pattern = "dd/MM/yyyy")
	@Column(name="REINICIO")
	public Calendar getReinicio() {
		return reinicio;
	}
	public void setReinicio(Calendar reinicio) {
		this.reinicio = reinicio;
	}
	
	@DateTimeFormat(pattern = "dd/MM/yyyy")
	@Column(name="DATA")
	public Calendar getData() {
		return data;
	}
	public void setData(Calendar data) {
		this.data = data;
	}
	
	@OneToOne(fetch=FetchType.EAGER)
	@JoinColumn(name="ID_ASSIGNACAO_ORGAOS")
	public AssignacaoOrgaos getAssigorgao() {
		return assigorgao;
	}
	public void setAssigorgao(AssignacaoOrgaos assigorgao) {
		this.assigorgao = assigorgao;
	}
	
	
}
