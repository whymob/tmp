package pt.iconic.ipst.modelo;

import java.util.Calendar;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name = "PREMIOS")
public class Premios {

	private Long id_premio;
	private int ano;
	private Entidade entidade;
	private Hospital hospital;
	private OrgaosOferta orgao;
	private float valor;
	private String compromisso;
	private String fatura;
	private Calendar pagamento;
	private String notas;
	
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="ID_PREMIO")
	public Long getId_premio() {
		return id_premio;
	}
	public void setId_premio(Long id_premio) {
		this.id_premio = id_premio;
	}
	
	@Column(name="ANO")
	public int getAno() {
		return ano;
	}
	public void setAno(int ano) {
		this.ano = ano;
	}
	
    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "ID_ENTIDADE")
	public Entidade getEntidade() {
		return entidade;
	}
	public void setEntidade(Entidade entidade) {
		this.entidade = entidade;
	}
	
    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "ID_HOSPITAL")
	public Hospital getHospital() {
		return hospital;
	}
	public void setHospital(Hospital hospital) {
		this.hospital = hospital;
	}
	
    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "ID_ORGAO_OFERTA")
	public OrgaosOferta getOrgao() {
		return orgao;
	}
	public void setOrgao(OrgaosOferta orgao) {
		this.orgao = orgao;
	}
	
	@Column(name="VALOR")
	public float getValor() {
		return valor;
	}
	public void setValor(float valor) {
		this.valor = valor;
	}
	
	@Column(name="COMPROMISSO")
	public String getCompromisso() {
		return compromisso;
	}
	public void setCompromisso(String compromisso) {
		this.compromisso = compromisso;
	}
	
	@Column(name="FATURA")
	public String getFatura() {
		return fatura;
	}
	public void setFatura(String fatura) {
		this.fatura = fatura;
	}
	
	@Column(name="PAGAMENTO")
	public Calendar getPagamento() {
		return pagamento;
	}
	public void setPagamento(Calendar pagamento) {
		this.pagamento = pagamento;
	}
	
	@Column(name="NOTAS")
	public String getNotas() {
		return notas;
	}
	public void setNotas(String notas) {
		this.notas = notas;
	}
	
}
