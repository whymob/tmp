package pt.iconic.ipst.modelo;

import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;


@Entity
@Table(name="TIPOVIROLOGIA")
public class TipoVirologia {

	
	private Long id_tipovirologia;
	private String desctipovirologia;
	private List<Virologia> virologia;
	private List<VirologiaRecetor> virologiarecetor;
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="ID_TIPOVIROLOGIA")
	public Long getId_tipovirologia() {
		return id_tipovirologia;
	}
	public void setId_tipovirologia(Long id_tipovirologia) {
		this.id_tipovirologia = id_tipovirologia;
	}
	
	@Column(name="DESCTIPOVIROLOGIA")
	public String getDesctipovirologia() {
		return desctipovirologia;
	}
	public void setDesctipovirologia(String desctipovirologia) {
		this.desctipovirologia = desctipovirologia;
	}
	
	@OneToMany(fetch = FetchType.LAZY, mappedBy = "tipoVirologia")
	public List<Virologia> getVirologia() {
		return virologia;
	}
	public void setVirologia(List<Virologia> virologia) {
		this.virologia = virologia;
	}
	
	@OneToMany(fetch = FetchType.LAZY, mappedBy = "tipoVirologia")
	public List<VirologiaRecetor> getVirologiarecetor() {
		return virologiarecetor;
	}
	public void setVirologiarecetor(List<VirologiaRecetor> virologiarecetor) {
		this.virologiarecetor = virologiarecetor;
	}
	
	
	
}
