package pt.iconic.ipst.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import pt.iconic.ipst.modelo.ColheitaGeralPerfOrgTorax;


@Repository
@Transactional
public class ColheitaGeralPerfOrgToraxDAO {

	@PersistenceContext
	private EntityManager manager;
	
	
	public void adiciona(ColheitaGeralPerfOrgTorax colheita){
		manager.persist(colheita);	
	}
	

	public void atualiza(ColheitaGeralPerfOrgTorax colheita){
		manager.merge(colheita);
	}
	

/*	@SuppressWarnings("unchecked")
	public List<ColheitaGeralPerfOrgTorax> ListaColheitaGeralPerfOrgTorax(){
		return manager.createQuery("select a from ColheitaGeralPerfOrgTorax a").getResultList();
	}*/
	
	public ColheitaGeralPerfOrgTorax buscaPorId(Long id){
		return manager.find(ColheitaGeralPerfOrgTorax.class, id);
	}
	
	
	public void remove(ColheitaGeralPerfOrgTorax colheita){
		ColheitaGeralPerfOrgTorax colheitaARemover = buscaPorId(colheita.getIdperftoracica());
		manager.remove(colheitaARemover);
		
	}
	
	@SuppressWarnings("unchecked")
	public List<ColheitaGeralPerfOrgTorax> ListaColheitaGeralPerfOrgToraxanalise(Long idanalise){
		
		Query query = manager.createQuery("select b from ColheitaGeralPerfOrgTorax b JOIN b.analiseDador a WHERE a.id_AnaliseDador =:idanalise");
		query.setParameter("idanalise", idanalise);
		
		List<ColheitaGeralPerfOrgTorax> results = query.getResultList();

		return results;
		
	}
}
