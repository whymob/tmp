package pt.iconic.ipst.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import pt.iconic.ipst.modelo.TransplanteRins;

@Repository
@Transactional
public class TransplanteRinsDAO {

	@PersistenceContext
	private EntityManager manager;
	
	public void adiciona(TransplanteRins transplante){
		manager.persist(transplante);	
	}
	
	public void atualiza(TransplanteRins transplante){
		manager.merge(transplante);
	}
	
	@SuppressWarnings("unchecked")
	public List<TransplanteRins> ListaTransplanteRins(){
		return manager.createQuery("select a from TransplanteRins a").getResultList();
	}
	
	public TransplanteRins buscaPorId(Long id){
		return manager.find(TransplanteRins.class, id);
	}
	
	public void remove(TransplanteRins transplante){
		TransplanteRins transplanteARemover = buscaPorId(transplante.getIdtransplanterins());
		manager.remove(transplanteARemover);
	}
	
	@SuppressWarnings("unchecked")
	public TransplanteRins buscaTransplanteRinsAssigorgao(Long idassigorg){
		
		Query query = manager.createQuery("select p from TransplanteRins p JOIN p.assigorgao a WHERE a.id_assignacao =:idassigorg");
		query.setParameter("idassigorg", idassigorg);
		
		List<TransplanteRins> results = query.getResultList();
		TransplanteRins transplante = null;
		if(!results.isEmpty()){
			transplante = (TransplanteRins) results.get(0);
		}
		return transplante;
	}
}
