package pt.iconic.ipst.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import pt.iconic.ipst.modelo.TransplantePosOperatorioComplicacoes;

@Repository
@Transactional
public class TransplantePosOperatorioComplicacoesDAO {

	@PersistenceContext
	private EntityManager manager;
	
	
	public void adiciona(TransplantePosOperatorioComplicacoes transplante){
		manager.persist(transplante);	
	}
	

	public void atualiza(TransplantePosOperatorioComplicacoes transplante){
		manager.merge(transplante);
	}
	

/*	@SuppressWarnings("unchecked")
	public List<TransplantePosOperatorioComplicacoes> ListaTranspPosOperatorioComplicacoes(){
		return manager.createQuery("select a from TransplantePosOperatorioComplicacoes a").getResultList();
	}*/
	
	public TransplantePosOperatorioComplicacoes buscaPorId(Long id){
		return manager.find(TransplantePosOperatorioComplicacoes.class, id);
	}
	
	
	public void remove(TransplantePosOperatorioComplicacoes transplante){
		TransplantePosOperatorioComplicacoes transplanteARemover = buscaPorId(transplante.getIdtranspposopcompl());
		manager.remove(transplanteARemover);
		
	}
	
	@SuppressWarnings("unchecked")
	public List<TransplantePosOperatorioComplicacoes> listaTranspPosOperatoriocomplassig(Long idassigorg){
		
		Query query = manager.createQuery("select b from TransplantePosOperatorioComplicacoes b JOIN b.assigorgao a WHERE a.id_assignacao =:idassigorg");
		query.setParameter("idassigorg", idassigorg);
		
		List<TransplantePosOperatorioComplicacoes> results = query.getResultList();
		return results;
		
	}
}
