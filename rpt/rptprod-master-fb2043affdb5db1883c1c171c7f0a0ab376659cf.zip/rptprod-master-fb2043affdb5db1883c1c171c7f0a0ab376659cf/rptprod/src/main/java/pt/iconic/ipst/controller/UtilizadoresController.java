package pt.iconic.ipst.controller;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

import javax.mail.MessagingException;
import javax.mail.internet.MimeMessage;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import pt.iconic.ipst.dao.EspecialidadesDAO;
import pt.iconic.ipst.dao.HospitalDAO;
import pt.iconic.ipst.dao.PermissaoAuxDAO;
import pt.iconic.ipst.dao.PermissaoDAO;
import pt.iconic.ipst.dao.PosicaoDAO;
import pt.iconic.ipst.dao.UtilizadorBDAO;
import pt.iconic.ipst.dao.UtilizadorDAO;
import pt.iconic.ipst.modelo.Especialidade;
import pt.iconic.ipst.modelo.Hospital;
import pt.iconic.ipst.modelo.PermissaoLocalizacao;
import pt.iconic.ipst.modelo.Posicao;
import pt.iconic.ipst.modelo.Utilizador;
import pt.iconic.ipst.modelo.UtilizadorB;

@Controller
public class UtilizadoresController {

	private UtilizadorDAO daouser;
	private HospitalDAO daoHosp;
	private PermissaoAuxDAO daopermaux;
	private EspecialidadesDAO daoespec;
	private UtilizadorBDAO daouserb;
	private PermissaoDAO daoperm;
	private PosicaoDAO daopos;
		
	@Autowired
	public UtilizadoresController(UtilizadorDAO daouser, HospitalDAO daoHosp, PermissaoAuxDAO daopermaux, EspecialidadesDAO daoespec, UtilizadorBDAO daouserb, PermissaoDAO daoperm, PosicaoDAO daopos) {
	this.daouser = daouser;
	this.daoHosp = daoHosp;
	this.daopermaux = daopermaux;
	this.daoespec = daoespec;
	this.daouserb = daouserb;
	this.daoperm = daoperm;
	this.daopos = daopos;
	}
	
    @Autowired
    private JavaMailSender mailSender;
	
	@RequestMapping("utilizadores")
	public String utilizadores(Model model, HttpSession session) {
//	System.out.println("Enviar para Admin Utilizadores");
	//System.out.println("Lista:"+Arrays.toString(daouser.ListaUtilizadorActividadeRecente().toArray()));
	//System.out.println("Linha: "+daouser.ListaUtilizadorActividadeRecente().get(0).toString().getClass());
	//model.addAttribute("utilizadores",daouser.ListaUtilizadores());
	//model.addAttribute("pin", gerapin());
	model.addAttribute("Utilizador", session.getAttribute("Utilizador"));
	model.addAttribute("utilizadores",daouser.ListaUtilizadorActividadeRecente());
	//model.addAttribute("hospitais", daoHosp.ListaHospitais());
	model.addAttribute("utilizadoresB",daouserb.Lista());
	model.addAttribute("posicao",session.getAttribute("posicao"));
	model.addAttribute("idposicao", session.getAttribute("idposicao"));
	return "/admin/utilizadores";
	}
	
    private String gerapin() {
    	Random r = new Random();
    	List<Integer> codes = new ArrayList<>();
    	for (int i = 0; i < 10; i++)
    	{
    	    int x = r.nextInt(999999);
    	    while (codes.contains(x))
    	        x = r.nextInt(999999);
    	    codes.add(x);
    	}
    	String str = String.format("%06d", codes.get(0));
    	return str;
	}

    @RequestMapping("carregaformuser")
    public String caregaformnovouser(Model model,  HttpSession session){
//    	System.out.println("Carrega novo pagina utilizador");
    	model.addAttribute("pin", gerapin());
    	//se admin acesso a todos hospitais
    	if((Long)session.getAttribute("idposicao")==1L){
//        System.out.println("carrega hospitais admin");
    	model.addAttribute("hospitais", daoHosp.ListaHospitais()); 
    	}
    	else{
    	//carregar s� os hospitais a que tem permiss�o
//    	System.out.println("carrega hospitais a que tem permiss�o");
    	model.addAttribute("hospitais", daoHosp.ListaHospitaisPermissao((Long)session.getAttribute("idposicao"), (Long)session.getAttribute("iduser"))); 
    	}
    	model.addAttribute("idposicao", session.getAttribute("idposicao"));
    return "admin/formnovouser";
    }
    
    @RequestMapping("carregaformuser2")
    public String caregaformnovouser2(Model model,  HttpSession session){
//    	System.out.println("Carrega novo pagina utilizador");
    	model.addAttribute("pin", gerapin());
    	//se admin acesso a todos hospitais
    	if((Long)session.getAttribute("idposicao")==1L){
//        System.out.println("carrega hospitais admin");
    	model.addAttribute("hospitais", daoHosp.ListaHospitais()); 
    	}
    	else{
    	//carregar s� os hospitais a que tem permiss�o
//    	System.out.println("carrega hospitais a que tem permiss�o");
    	model.addAttribute("hospitais", daoHosp.ListaHospitaisPermissao((Long)session.getAttribute("idposicao"), (Long)session.getAttribute("iduser"))); 
    	}
    	model.addAttribute("idposicao", session.getAttribute("idposicao"));
    return "admin/formnovouser2";
    }
    
    @RequestMapping("voltar")
    public String voltar(Model model,  HttpSession session){
//    	System.out.println("Voltar");
    return "redirect:utilizadores";
    }
    
    
	@RequestMapping("editautilizador")
	public String editarUtilizador(Long id, Model model, Especialidade especialidade, HttpSession session) {
 //   System.out.println("ChamaPaginaEditarUtilizadpr com ID: "+id);
	model.addAttribute("utilizador", daouser.buscaPorId(id));
	model.addAttribute("especialidades", daoespec.ListaEspecialidade());
  	model.addAttribute("hospitaistodos", daoHosp.ListaHospitais());
	model.addAttribute("idposicao", session.getAttribute("idposicao"));
	
	model.addAttribute("permissaouser", daoHosp.ListaHospitaisEditaPermissao(id));
	
	return "admin/detalheUtilizador";
	}
	
	//permiss�es utilizador logado
	@RequestMapping("editautilizador2")
	public String editarUtilizador2(Model model, HttpSession session) {
 //   System.out.println("ChamaPaginaEditarUtilizadpr com ID: "+id);
	model.addAttribute("utilizador", daouser.buscaPorId((Long) session.getAttribute("iduser")));
	model.addAttribute("especialidades", daoespec.ListaEspecialidade());
	model.addAttribute("tipoalteracao", 1);
	
  	//carregar hospitais permissao do utilizador
	model.addAttribute("permissaohosp", daoperm.ListaHospitaisPermissao((Long) session.getAttribute("iduser")));
	
	//carrega posi��o para bot�o criar novo user
	model.addAttribute("idposicao", session.getAttribute("idposicao"));
	
	return "admin/detalheUtilizador2";
	}

	@RequestMapping("editautilizadorB")
	public String editarUtilizadorB(Long id, Model model) {
 //   System.out.println("ChamaPaginaEditarUtilizadpr com ID: "+id);
	model.addAttribute("utilizadorB", daouserb.buscaPorId(id));
	return "admin/detalheUtilizadorB";
	}
	

	@RequestMapping("editautilizadorB2")
	public String editarUtilizadorB2(Model model, HttpSession session) {
 //   System.out.println("ChamaPaginaEditarUtilizadpr com ID: "+id);
	model.addAttribute("utilizadorB", daouserb.buscaPorId((Long) session.getAttribute("iduser")));
	model.addAttribute("tipoalteracao", 1);
	
	return "admin/detalheUtilizadorB";
	}

    @RequestMapping("gravareditarutilizador")
	public String gravaeditarUtilizador(Utilizador utilizador, Especialidade especialidade, Model model) {	

    Utilizador user2 = daouser.buscaPorId(utilizador.getID_Utilizador());
    if(utilizador.getSenha().equals("")){
    //senha, extensao, pin, tipo utilizador e c�digo para manter pq n�o existem no formul�rio
    utilizador.setSenha(user2.getSenha());
    utilizador.setExtensao(user2.getExtensao());
    utilizador.setPin(user2.getPin());
    utilizador.setTipoUtilizador(user2.getTipoUtilizador());
    utilizador.setCodigo(user2.getCodigo());

 	daouser.atualiza(utilizador);
    }
    else{
		BCryptPasswordEncoder passwordEncoder = new BCryptPasswordEncoder();
		String hashedPassword = passwordEncoder.encode(utilizador.getSenha());
		utilizador.setSenha(hashedPassword);
    	
        utilizador.setExtensao(user2.getExtensao());
        utilizador.setPin(user2.getPin());
        utilizador.setTipoUtilizador(user2.getTipoUtilizador());
        utilizador.setCodigo(user2.getCodigo());
 	daouser.atualiza(utilizador);
 	}
    model.addAttribute("utilizadores",daouser.buscaUserActividadePorId(utilizador.getID_Utilizador()).get(0));
 	return "/admin/loads/linhaatualizadautilizador";
	}
    
    @RequestMapping("gravareditarutilizadorB")
	public String gravaeditarUtilizadorB(UtilizadorB utilizadorb, Model model) 
    {	
	    UtilizadorB user2 = daouserb.buscaPorId(utilizadorb.getId_UtilizadorB());
	    
	    if(utilizadorb.getPin() == 99999)
	    {
	    	utilizadorb.setPin(user2.getPin());
	    	utilizadorb.setCodigoOM(user2.getCodigoOM());
		 	daouserb.atualiza(utilizadorb);
	    }
	    
	   	utilizadorb.setCodigoOM(user2.getCodigoOM());
	 	daouserb.atualiza(utilizadorb);
	 	
	 	model.addAttribute("utilizadoresb",daouserb.buscaPorId(utilizadorb.getId_UtilizadorB()));
	 	return "/admin/loads/linhaatualizadautilizadorb";
	} 

@RequestMapping(value="carregatabelapermissoes")
	public String carregatabelapermissoes(Model model,  HttpSession session) {

	
    	model.addAttribute("utilizador", daouser.buscaPorId((Long) session.getAttribute("iduser")));
    	model.addAttribute("especialidades", daoespec.ListaEspecialidade());
    	model.addAttribute("tipoalteracao", 1);
    	
    	if((Long)session.getAttribute("idposicao")==1L){

      	model.addAttribute("hospitais", daoHosp.ListaHospitais()); 
      	}
      	else{
      	//carregar s� os hospitais a que tem permiss�o
      	model.addAttribute("hospitais", daoHosp.ListaHospitaisPermissao((Long)session.getAttribute("idposicao"), (Long)session.getAttribute("iduser"))); 
      	}
      	model.addAttribute("idposicao", session.getAttribute("idposicao"));
      	model.addAttribute("hospitaistodos", daoHosp.ListaHospitais());

      	//Carregar permissoes do utilizador?
      	model.addAttribute("permissoes", daoperm.ListaPermissoesUtilizador((Long) session.getAttribute("iduser")));
    	
	return "admin/loads/tabelapermissoes";
	}
    
    @RequestMapping(value="adicionarhospital", method = RequestMethod.POST)
	@ResponseBody
	public String adicionarhospital(@RequestParam("hospital") Long hospital,  @RequestParam("utilizador") Long utilizador,  @RequestParam("posicao") Long posicao) 
	{
    	Hospital h = daoHosp.buscaPorId(hospital);
    	Posicao p = daopos.buscaPorId(posicao);
    	Utilizador u = daouser.buscaPorId(utilizador);

    	PermissaoLocalizacao pl = new PermissaoLocalizacao();
  
    	pl.setPosicao(p);
    	pl.setHospital(h);
    	pl.setUtilizador(u);
    	pl.setLeituraescrita(false);
    	daoperm.adiciona(pl);
    	
    	return "true";
	}


    @RequestMapping("gravapermissoes")
	@ResponseBody
	@Transactional
    public String gravapermissao(@RequestParam(value = "valores[]") String valores, String email, String pin, String telemovel){
//    	System.out.println("array: "+valores.toString());
 //   	System.out.println("email: "+email);
//    	System.out.println("pin: "+pin);

    	//System.out.println("lista: "+valores);

    	if(daopermaux.existePermissaoaux(email)==true|| daouser.existeUtilizadoremail(email))
    		return "false";
    	else{
    	daopermaux.tratalistaadicionar(valores, email, pin, telemovel);
    	
    	//enviar sms user profissional 1:
   	if(telemovel != null && !telemovel.isEmpty()){
    		SMSController sms = new SMSController();
    		sms.sms(telemovel, pin, 1);
    	}
    	
    	
    	//enviar email
    	String recipientAddress = email;
    	String subject = "IPST - RPT - Novo registo de utilizador";
  	
		String message = "Exmo(a). Senhor(a),<br><br> Foi criado um perfil de utilizador no Registo Portugu�s de Transplanta��o (RPT) para este contacto. Para concluir o seu registo aceda ao link <a href=\"http://213.58.181.218:8080/rptprod/registouserA?email="+email
				+"\">(link de acesso)</a> e preencha todos os campos. <br><br>"
						+ "<b>Aten��o</b>, este link � v�lido por <b>24 horas</b>.<br><br> "
				+ "Em nome da Coordena��o Nacional da Transplanta��o (CNT) do Instituto Portugu�s do Sangue "
				+ "e da Transplanta��o (IPST, IP) agradecemos a sua colabora��o. <br><br> "
				+ "Qualquer  problema  t�cnico  ou  dificuldade  no  acesso  ao  RPT,  dever� ser  reportado  para  o  endere�o: rpt@IPST.min-saude.pt <br><br><br> "
				+ "Com os melhores cumprimentos, <br><br> "
				+ "A Coordena��o Nacional da Transplanta��o";

		try {
	    	// criar o objecto email
			MimeMessage mimeMessage = mailSender.createMimeMessage();
		     MimeMessageHelper helper;
			helper = new MimeMessageHelper(mimeMessage, true, "UTF-8");

	     mimeMessage.setContent(message, "text/html");
	     helper.setTo(recipientAddress);
	     helper.setSubject(subject);

        mailSender.send(mimeMessage);
		} catch (MessagingException e) {
			e.printStackTrace();
		}
    	return "true";
    	}
    }
    
    
//---------------------------edi��o de perfis administrador-----------------------------------------------------------------//    
    
    
    
    //carregar tabela de posi��es permiss�es do utilizador para o hospital seleccionado
    @RequestMapping(value="carregaedicaopermissaohospital" , method = RequestMethod.POST)
	public String carregaedicaopermissaohospital(@RequestParam("id_hospital") Long id_hospital, @RequestParam("idutilizador") Long idutilizador, Model model) {

      	model.addAttribute("posicaohospital", daopos.buscaPosicoesUtilizadorHospital(idutilizador, id_hospital));
      	
      	//combo adicionar posi��es que o user ainda n�o possui para o hospital, cuidado com a permiss�o de quem est� a adicionar
      	model.addAttribute("addposicaohospital", daopos.comboaddposicaon�oexistente(idutilizador, id_hospital));
      	
	return "admin/loads/diveditaposicaopermissao";
	}
    
    
    @RequestMapping(value="carregapermissaoposicao" , method = RequestMethod.POST)
	public String carregapermissaoposicao(@RequestParam("id_hospital") Long id_hospital, @RequestParam("idutilizador") Long idutilizador, @RequestParam("id_Posicao") Long id_Posicao, Model model) {

   // 	System.out.println(daoperm.buscapermissaoposicao(id_hospital, idutilizador, id_Posicao));
      	model.addAttribute("permissaoposicao", daoperm.buscapermissaoposicao(id_hospital, idutilizador, id_Posicao));
    	
	return "admin/loads/divpermissaoposicaohospital";
	}
    
    
    @RequestMapping(value="guardapermissaoposicao")
    @ResponseBody
	public String guardapermissaoposicao(@RequestParam("idhospital") Long idhospital, @RequestParam("idutilizador") Long idutilizador, @RequestParam("id_Posicao") Long id_Posicao,
			@RequestParam("le") boolean leituraescrita, Model model) {

    		daoperm.atualizapermissao(idhospital, idutilizador, id_Posicao, leituraescrita);
    	
	return "true";
	}
    
    
    
    @RequestMapping(value="actualizartabelapermissoes" , method = RequestMethod.POST)
	public String actualizartabelapermissoes(@RequestParam("idutilizador") Long idutilizador, Model model, HttpSession session) {

   // 	System.out.println(daoperm.buscapermissaoposicao(id_hospital, idutilizador, id_Posicao));
    	model.addAttribute("idposicao", session.getAttribute("idposicao"));
    	model.addAttribute("permissaouser", daoHosp.ListaHospitaisEditaPermissao(idutilizador));
    	
	return "admin/loads/tabeditpermissaouser";
	}
    
    
    @RequestMapping(value="adicionaposicaohospital" , method = RequestMethod.POST)
	public String adicionaposicaohospital(@RequestParam("id_hospital") Long id_hospital, @RequestParam("idutilizador") Long idutilizador, @RequestParam("posicao") Long posicao,
			@RequestParam("tipopermissao") boolean tipopermissao , Model model) {

    	//adicionar posi��o ao utilizador com leitura por defeito
    	//boolean leituraescrita = false;
    	PermissaoLocalizacao perm = new PermissaoLocalizacao();
    	perm.setHospital(daoHosp.buscaPorId(id_hospital));
    	perm.setUtilizador(daouser.buscaPorId(idutilizador));
    	perm.setPosicao(daopos.buscaPorId(posicao));
    	perm.setLeituraescrita(tipopermissao);
    	daoperm.adiciona(perm);
    	
      	model.addAttribute("posicaohospital", daopos.buscaPosicoesUtilizadorHospital(idutilizador, id_hospital));	
      	//combo adicionar posi��es que o user ainda n�o possui para o hospital, cuidado com a permiss�o de quem est� a adicionar
      	model.addAttribute("addposicaohospital", daopos.comboaddposicaon�oexistente(idutilizador, id_hospital));
      	
	return "admin/loads/diveditaposicaopermissao";
	}
    
    @RequestMapping(value="removerposicaohospital" , method = RequestMethod.POST)
	public String removerposicaohospital(@RequestParam("id_hospital") Long id_hospital, @RequestParam("idutilizador") Long idutilizador, @RequestParam("posicao") Long posicao, Model model) {

    	//adicionar posi��o ao utilizador com leitura por defeito
    	//boolean leituraescrita = false;
    	
    	//remove permiss�o
    	daoperm.remove(daoperm.buscaidpermissao(id_hospital, idutilizador, posicao));
    	
//    	PermissaoLocalizacao perm = new PermissaoLocalizacao();
//    	perm.setHospital(daoHosp.buscaPorId(id_hospital));
//    	perm.setUtilizador(daouser.buscaPorId(idutilizador));
//    	perm.setPosicao(daopos.buscaPorId(posicao));
//    	daoperm.remove(perm);
    	
      	model.addAttribute("posicaohospital", daopos.buscaPosicoesUtilizadorHospital(idutilizador, id_hospital));	
      	//combo adicionar posi��es que o user ainda n�o possui para o hospital, cuidado com a permiss�o de quem est� a adicionar
      	model.addAttribute("addposicaohospital", daopos.comboaddposicaon�oexistente(idutilizador, id_hospital));
      	
	return "admin/loads/diveditaposicaopermissao";
	}
    
    //------------HOSPITAIS A ADICIONAR �S PERMISS�ES------------------//

    @RequestMapping(value="carregahospitaisdisponiveispermissao" , method = RequestMethod.POST)
    public String hospitaisdisponiveis(@RequestParam("iduser") Long iduser, Model model){
    	
    	model.addAttribute("addhospitaluser", daouser.buscahospitaissempermissaouser(iduser));	
     	model.addAttribute("addpermissaohospital", daopos.ListaPosicoes());
     	
    	return "admin/loads/divaddhospitaluser";
    }
    
    @RequestMapping(value="adicionarhospitalpermissoesuser" , method = RequestMethod.POST)
    public String adicionarhospitalpermissoesuser(@RequestParam("iduser") Long iduser, @RequestParam("idhospital") Long idhospital,
    		@RequestParam("posicao") Long posicao, @RequestParam("permissao") boolean permissao, Model model, HttpSession session){
	
	 
		//System.out.println("iduser: "+iduser+ ", idhospital: "+idhospital+", idposicao: "+posicao+", permissao: "+permissao);
		
		PermissaoLocalizacao perm = new PermissaoLocalizacao();
		perm.setUtilizador(daouser.buscaPorId(iduser));
		perm.setHospital(daoHosp.buscaPorId(idhospital));
		perm.setPosicao(daopos.buscaPorId(posicao));
		perm.setLeituraescrita(permissao);
		daoperm.adiciona(perm);
    	
    	model.addAttribute("idposicao", session.getAttribute("idposicao"));
    	model.addAttribute("permissaouser", daoHosp.ListaHospitaisEditaPermissao(iduser));
 
    	return "admin/loads/tabeditpermissaouser";
    }
    
}