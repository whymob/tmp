package pt.iconic.ipst.modelo;

import java.util.Calendar;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

@Entity
@Table(name = "HISTORICO_ASSIGNACAO")
public class HistoricoAssignacao {
	
	private Long idhistorico;
	private AssignacaoHospital assighosp;
	private Calendar datahistorico;
	private StatusAssignacaoHospital estadoassig;
	private String observacoes;
	private Dador dador;
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="ID_HISTORICO")
	public Long getIdhistorico() {
		return idhistorico;
	}
	public void setIdhistorico(Long idhistorico) {
		this.idhistorico = idhistorico;
	}
	
    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "ID_ASSIG_HOSP")
	public AssignacaoHospital getAssighosp() {
		return assighosp;
	}
	public void setAssighosp(AssignacaoHospital assighosp) {
		this.assighosp = assighosp;
	}
	
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name="DATAHISTORICO")
    public Calendar getDatahistorico() {
		return datahistorico;
	}
	public void setDatahistorico(Calendar datahistorico) {
		this.datahistorico = datahistorico;
	}
	
	
	@ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "ID_ESTADO_ASSIG")
	public StatusAssignacaoHospital getEstadoassig() {
		return estadoassig;
	}
	public void setEstadoassig(StatusAssignacaoHospital estadoassig) {
		this.estadoassig = estadoassig;
	}
	
	@Column(name="OBSERVACOES")
	public String getObservacoes() {
		return observacoes;
	}
	public void setObservacoes(String observacoes) {
		this.observacoes = observacoes;
	}
	
    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "ID_DADOR")
	public Dador getDador() {
		return dador;
	}
	public void setDador(Dador dador) {
		this.dador = dador;
	}
	
	

}
