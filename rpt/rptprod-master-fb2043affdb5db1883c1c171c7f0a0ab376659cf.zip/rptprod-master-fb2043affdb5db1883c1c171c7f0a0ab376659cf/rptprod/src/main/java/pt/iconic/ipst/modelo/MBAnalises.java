package pt.iconic.ipst.modelo;

import java.util.Calendar;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.constraints.NotNull;

import org.springframework.format.annotation.DateTimeFormat;

@Entity
@Table(name="MBANALISES")
public class MBAnalises {

	
	private Long id_mbanalises;
//	private Microbiologia microbiologia;
	private TipoMBAnalise tipoMBAnalise;
	private int posneg;
	private Calendar datahora;
	private Calendar datahoraresult;
	private String observmicro;
	private List<Microrgmbanalisemb> Microrganismo;
	private AnaliseDador analiseDador;
	
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="ID_MBANALISES")
	public Long getId_mbanalises() {
		return id_mbanalises;
	}
	public void setId_mbanalises(Long id_mbanalises) {
		this.id_mbanalises = id_mbanalises;
	}
	
/*    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "ID_MICROBIOLOGIA")
	public Microbiologia getMicrobiologia() {
		return microbiologia;
	}
	public void setMicrobiologia(Microbiologia microbiologia) {
		this.microbiologia = microbiologia;
	}*/

	@ManyToOne
	@JoinColumn(name="ID_ANALISEDADOR")
    public AnaliseDador getAnaliseDador() {
		return analiseDador;
	}
	public void setAnaliseDador(AnaliseDador analiseDador) {
		this.analiseDador = analiseDador;
	}
	@ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "ID_TIPOMBANALISE")
	public TipoMBAnalise getTipoMBAnalise() {
		return tipoMBAnalise;
	}
	public void setTipoMBAnalise(TipoMBAnalise tipoMBAnalise) {
		this.tipoMBAnalise = tipoMBAnalise;
	}
	
	@NotNull
	@Column(name="POSNEG")
	public int getPosneg() {
		return posneg;
	}
	public void setPosneg(int posneg) {
		this.posneg = posneg;
	}
	
	@DateTimeFormat(pattern="dd/MM/yyyy HH:mm:ss")
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name="DATAHORA")
	public Calendar getDatahora() {
		return datahora;
	}
	public void setDatahora(Calendar datahora) {
		this.datahora = datahora;
	}
	
	@DateTimeFormat(pattern="dd/MM/yyyy HH:mm:ss")
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name="DATAHORARESULT")
	public Calendar getDatahoraresult() {
		return datahoraresult;
	}
	public void setDatahoraresult(Calendar datahoraresult) {
		this.datahoraresult = datahoraresult;
	}
	@Column(name="OBSERVACOES")
	public String getObservmicro() {
		return observmicro;
	}
	public void setObservmicro(String observmicro) {
		this.observmicro = observmicro;
	}
	
    @OneToMany(fetch = FetchType.LAZY, mappedBy = "mbAnalises", cascade=CascadeType.REMOVE)
	public List<Microrgmbanalisemb> getMicrorganismo() {
		return Microrganismo;
	}
	public void setMicrorganismo(List<Microrgmbanalisemb> microrganismo) {
		Microrganismo = microrganismo;
	}
	
	
}
