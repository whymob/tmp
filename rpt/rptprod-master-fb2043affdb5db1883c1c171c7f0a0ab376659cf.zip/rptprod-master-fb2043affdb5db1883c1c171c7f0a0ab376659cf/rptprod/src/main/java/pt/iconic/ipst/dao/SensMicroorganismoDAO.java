package pt.iconic.ipst.dao;


import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import pt.iconic.ipst.modelo.SensMicroorganalise;



@Repository
@Transactional
public class SensMicroorganismoDAO {

	@PersistenceContext
	private EntityManager manager;
	

	public void adiciona(SensMicroorganalise sensibilidades){
		manager.persist(sensibilidades);	
	}
	

	public void atualiza(SensMicroorganalise sensibilidades){
		manager.merge(sensibilidades);
	}
	

/*	@SuppressWarnings("unchecked")
	public List<SensMicroorganalise> ListaSensMicroorganalise(){
		return manager.createQuery("select s from SensMicroorganalise s").getResultList();
	}*/
	
	public SensMicroorganalise buscaPorId(Long id){
		return manager.find(SensMicroorganalise.class, id);
	}
	
	
/*	public void remove(SensMicroorganalise sensibilidades){
		SensMicroorganalise causamorteARemover = buscaPorId(sensibilidades.getId_sensmicroorganalise());
		manager.remove(causamorteARemover);
	}*/
	
	


	@SuppressWarnings("unchecked")
	public List<Object[]> ListaSensibilidadesOrganismoAnalise(Long idmicrorgmbanalise){

			
			List<Object[]> out = null;
			
			String sql = "select sm.ID_MICROORGANISMOANALISE,  case sm.VALORSENS when 1 then 'true' else 'false' end as VALOR, sm.ID_SENSIBILIDADE, s.SENSDESCRICAO, sm.ID_SENSMICROORGANISMO from SENSMICROORGANALISE sm "
					+ "inner join SENSIBILIDADE s on (sm.ID_SENSIBILIDADE = s.ID_SENSIBILIDADE) where sm.ID_MICROORGANISMOANALISE = :idmicrorgmbanalise "
					+ "union "
					+ "select :idmicrorgmbanalise ,'false',s.ID_SENSIBILIDADE, s.SENSDESCRICAO, NULL from SENSIBILIDADE s "
					+ "where s.ID_SENSIBILIDADE not in (select sm.ID_SENSIBILIDADE from SENSMICROORGANALISE sm inner join SENSIBILIDADE s on (sm.ID_SENSIBILIDADE = s.ID_SENSIBILIDADE) "
					+ "where sm.ID_MICROORGANISMOANALISE = :idmicrorgmbanalise) "
					+ "Order by SENSDESCRICAO ASC";

			Query query = manager.createNativeQuery(sql);
			query.setParameter("idmicrorgmbanalise", idmicrorgmbanalise);
				
			out = query.getResultList();
//			int count = 0;  
//			for (Iterator i = out.iterator(); i.hasNext();) {  
//			    Object[] values = (Object[]) i.next();  
//			    System.out.println(++count + ": " + values[0] + ", " + values[1] + " ," + values[2] +"," + values[3] +"," + values[4] +"<br />");  
//			}

			return out;
		
		
	}

	public void removesensibilidadedomicrorganismoremovido(Long mbanalise) {
	    Query query = manager.createNativeQuery("update SENSMICROORGANALISE set VALORSENS = 'false' "
	    		+ "where ID_MICROORGANISMOANALISE = :id_mbanalise");
	        query.setParameter("id_mbanalise", mbanalise);
	        query.executeUpdate();
	}
}
