package pt.iconic.ipst.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import pt.iconic.ipst.modelo.GCCTColheitaDetalhe;

@Repository
@Transactional
public class GCCTColheitaDetalheDAO 
{
	@PersistenceContext
	private EntityManager manager;
	
	public void adiciona(GCCTColheitaDetalhe gcct){
		manager.persist(gcct);	
	}
	
	public void atualiza(GCCTColheitaDetalhe gcct){
		manager.merge(gcct);
	}
	
/*	@SuppressWarnings("unchecked")
	public List<GCCTColheitaDetalhe> ListaGCCTColheitaDetalhe(){
		return manager.createQuery("select d from GCCTColheitaDetalhe d").getResultList();
	}*/
	
	public GCCTColheitaDetalhe buscaPorId(Long id){
		return manager.find(GCCTColheitaDetalhe.class, id);
	}
	
/*	public void remove(GCCTColheitaDetalhe gcct){
		GCCTColheitaDetalhe gcctARemover = buscaPorId(gcct.getIdgcctcolheitadetalhe());
		manager.remove(gcctARemover);
	}*/
	
	@SuppressWarnings("unchecked")
	public List<GCCTColheitaDetalhe> buscagcctcolheitadetalhe(Long idgcct)
	{
		Query query = manager.createQuery("select b from GCCTColheitaDetalhe b JOIN b.gcctcolheita gcctcolheita WHERE gcctcolheita.idgcctcolheita =:idgcct");
		query.setParameter("idgcct", idgcct);
		
		List<GCCTColheitaDetalhe> results = query.getResultList();

		return results;
	}
	
	@SuppressWarnings("unchecked")
	public List<GCCTColheitaDetalhe> buscagcctcolheitadetalheorgaos(Long idgcct)
	{
		Query query = manager.createQuery("select b from GCCTColheitaDetalhe b JOIN b.gcctcolheita gcctcolheita WHERE gcctcolheita.idgcctcolheita =:idgcct and b.estado = 1");
		query.setParameter("idgcct", idgcct);
		
		List<GCCTColheitaDetalhe> results = query.getResultList();

		return results;
	}
}
