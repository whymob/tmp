package pt.iconic.ipst.modelo;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name = "PPHEPATICODIAGNOSTICO")
public class PPHepaticoDiagnostico {

	private Long id_pphepaticodiagnostico;
	private AnaliseRecetor analiserecetor;
	private TipoDiagnostico tipodiagnostico;
//	private int diagnostico;
	private boolean esc;
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="ID_PPHEPATICO_DIAGNOSTICO")
	public Long getId_pphepaticodiagnostico() {
		return id_pphepaticodiagnostico;
	}
	public void setId_pphepaticodiagnostico(Long id_pphepaticodiagnostico) {
		this.id_pphepaticodiagnostico = id_pphepaticodiagnostico;
	}
	
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="ID_ANALISERECETOR")
	public AnaliseRecetor getAnaliserecetor() {
		return analiserecetor;
	}
	public void setAnaliserecetor(AnaliseRecetor analiserecetor) {
		this.analiserecetor = analiserecetor;
	}
	
	@ManyToOne(fetch=FetchType.EAGER)
	@JoinColumn(name="ID_TIPODIAGNOSTICO")
	public TipoDiagnostico getTipodiagnostico() {
		return tipodiagnostico;
	}
	public void setTipodiagnostico(TipoDiagnostico tipodiagnostico) {
		this.tipodiagnostico = tipodiagnostico;
	}
	
//	@Column(name="DIAGNOSTICO")
//	public int getDiagnostico() {
//		return diagnostico;
//	}
//	public void setDiagnostico(int diagnostico) {
//		this.diagnostico = diagnostico;
//	}
	
	@Column(name="ESC")
	public boolean isEsc() {
		return esc;
	}
	public void setEsc(boolean esc) {
		this.esc = esc;
	}
	
}
