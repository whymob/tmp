package pt.iconic.ipst.modelo;

import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name="TIPOMBANALISE")
public class TipoMBAnalise {

	private Long id_tipombanalise;
	private String descricaomb;
	private List<MBAnalises> MicrobioAnalises;
	

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="ID_TIPOMBANALISE")
	public Long getId_tipombanalise() {
		return id_tipombanalise;
	}
	public void setId_tipombanalise(Long id_tipombanalise) {
		this.id_tipombanalise = id_tipombanalise;
	}
	
	@Column(name="DESCRICAO")
	public String getDescricaomb() {
		return descricaomb;
	}
	public void setDescricaomb(String descricaomb) {
		this.descricaomb = descricaomb;
	}
	
    @OneToMany(fetch = FetchType.LAZY, mappedBy = "tipoMBAnalise")
	public List<MBAnalises> getMicrobioAnalises() {
		return MicrobioAnalises;
	}
	public void setMicrobioAnalises(List<MBAnalises> microbioAnalises) {
		MicrobioAnalises = microbioAnalises;
	}

	
}
