package pt.iconic.ipst.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;

import pt.iconic.ipst.modelo.Posicao;

@Repository
public class PosicaoDAO {

	
	@PersistenceContext
	private EntityManager manager;

	
	@SuppressWarnings("unchecked")
	public List<Posicao> ListaPosicoes(){
		return manager.createQuery("select p from Posicao p").getResultList();
	}
	
	public Posicao buscaPorId(Long id){
		return manager.find(Posicao.class, id);
	}
		
	@SuppressWarnings("unchecked")
	public List<Posicao> buscaPosicoesUtilizador(Long idutilizador){
		
		List<Posicao> out = null;
		//Query query = manager.createNativeQuery("select * from Posicao inner join utilizador_posicao on (utilizador_posicao.Id_Posicao = posicao.Id_Posicao) where utilizador_posicao.id_utilizador = :idutilizador");
		//Query query = manager.createQuery("select p from Posicao p join p.utilizadores utilizador WHERE utilizador.ID_Utilizador =:idutilizador");
		//Query query = manager.createQuery("select p from Posicao p join p.utilizadorposicoes utilizadorpos WHERE utilizadorpos.utilizador.ID_Utilizador =:idutilizador");
		String sql = "select distinct POSICAO.* from POSICAO inner join PERMISSAO_LOCALIZACAO on (PERMISSAO_LOCALIZACAO.ID_POSICAO = POSICAO.ID_POSICAO) "
				+ "inner join UTILIZADOR on (PERMISSAO_LOCALIZACAO.ID_UTILIZADOR = UTILIZADOR.ID_UTILIZADOR) "
				+ "where UTILIZADOR.ID_UTILIZADOR = :idutilizador";
		Query query = manager.createNativeQuery(sql, Posicao.class);
		query.setParameter("idutilizador", idutilizador);
		out = query.getResultList();
		/*int count = 0;  
		for (Iterator i = out.iterator(); i.hasNext();) {  
		    Posicao[] values = (Posicao[]) i.next();  
		    System.out.println("Posicoes: "+count + ": " + values[0] + ", " + values[1] +"<br />");  
		}*/
		return out;
		
	}
	
	@SuppressWarnings("unchecked")
	public List<Posicao> buscaPosicoesUtilizadorHospital(Long idutilizador, Long idhospital){
		
		List<Posicao> out = null;
		//Query query = manager.createNativeQuery("select * from Posicao inner join utilizador_posicao on (utilizador_posicao.Id_Posicao = posicao.Id_Posicao) where utilizador_posicao.id_utilizador = :idutilizador");
		//Query query = manager.createQuery("select p from Posicao p join p.utilizadores utilizador WHERE utilizador.ID_Utilizador =:idutilizador");
		//Query query = manager.createQuery("select p from Posicao p join p.utilizadorposicoes utilizadorpos WHERE utilizadorpos.utilizador.ID_Utilizador =:idutilizador");
		String sql = "select distinct POSICAO.* from POSICAO inner join PERMISSAO_LOCALIZACAO on (PERMISSAO_LOCALIZACAO.ID_POSICAO = POSICAO.ID_POSICAO) "
				+ "inner join UTILIZADOR on (PERMISSAO_LOCALIZACAO.ID_UTILIZADOR = UTILIZADOR.ID_UTILIZADOR) "
				+ "where UTILIZADOR.ID_UTILIZADOR = :idutilizador AND PERMISSAO_LOCALIZACAO.ID_HOSPITAL = :idhospital";
		Query query = manager.createNativeQuery(sql, Posicao.class);
		query.setParameter("idutilizador", idutilizador);
		query.setParameter("idhospital", idhospital);
		out = query.getResultList();

		return out;
		
	}


	@SuppressWarnings("unchecked")
	public List<Posicao> comboaddposicaon�oexistente(Long idutilizador, Long id_hospital) {

		List<Posicao> out = null;
		
		//busca posi��es existentes para o query, temos que passar j� a lista do not in como parametro sen�o d� erro
		List<Posicao> existentes = buscaPosicoesUtilizadorHospital(idutilizador, id_hospital);
		String sql = "";
		if(!existentes.isEmpty()){
			sql = "select * from POSICAO where POSICAO.ID_POSICAO <> 5 AND POSICAO.ID_POSICAO NOT IN (:posexistentes)";
			Query query = manager.createNativeQuery(sql, Posicao.class);
			query.setParameter("posexistentes", existentes);
			out = query.getResultList();
		}else{
			sql = "select * from POSICAO";	
			Query query = manager.createNativeQuery(sql, Posicao.class);
			out = query.getResultList();
		}
		
		
		
		return out;
	}
	
}
