package pt.iconic.ipst.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;

import pt.iconic.ipst.modelo.Quadrantes;



@Repository
public class QuadrantesDAO {

	@PersistenceContext
	private EntityManager manager;
	
	
	public void adiciona(Quadrantes quadrantes){
		manager.persist(quadrantes);	
	}
	
	public void atualiza(Quadrantes quadrantes){
		manager.merge(quadrantes);
	}
	

/*	@SuppressWarnings("unchecked")
	public List<Quadrantes> ListaQuadrantes(){
		return manager.createQuery("select c from Quadrantes c").getResultList();
	}*/
	
/*	public Quadrantes buscaPorId(Long id){
		return manager.find(Quadrantes.class, id);
	}
	
	
	public void remove(Quadrantes quadrantes){
		Quadrantes quadrantesARemover = buscaPorId(quadrantes.getId_Quadrantes());
		manager.remove(quadrantesARemover);
	}*/
	
	@SuppressWarnings("unchecked")
	public Quadrantes buscaquadrantesanalise(Long idanalise){
		
		Query query = manager.createQuery("select q from Quadrantes q JOIN q.hcexamefisico h JOIN h.analisedador a WHERE a.id_AnaliseDador =:idanalise");
		query.setParameter("idanalise", idanalise);
		
		List<Quadrantes> results = query.getResultList();
		Quadrantes quadrantes = null;
		if(!results.isEmpty()){
			quadrantes = (Quadrantes) results.get(0);
		}
		return quadrantes;
		
	}
	
}
