package pt.iconic.ipst.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import pt.iconic.ipst.modelo.Microorganismos;

@Repository
@Transactional
public class MicroorganismosDAO
{
	@PersistenceContext
	private EntityManager manager;	
	
	public void adiciona(Microorganismos micro){
		manager.persist(micro);	
	}
	
	public void atualiza(Microorganismos micro){
		manager.merge(micro);
	}

	@SuppressWarnings("unchecked")
	public List<Microorganismos> ListaMicroorganismos(){
		return manager.createQuery("select s from Microorganismos s").getResultList();
	}
	
	public Microorganismos buscaPorId(Long id){
		return manager.find(Microorganismos.class, id);
	}
		
	public void remove(Microorganismos micro){
		Microorganismos microremove = buscaPorId(micro.getId_Microorganismos());
		manager.remove(microremove);
	}
	
	public boolean trataadicionar(String desc)
	{
		Query query = manager.createQuery("SELECT e FROM Microorganismos e WHERE e.microDescricao =:desc");
		query.setParameter("desc", desc);
		
		if(query.getResultList().isEmpty())
		{
			Microorganismos micro = new Microorganismos();
			micro.setMicroDescricao(desc);
			adiciona(micro);
			
			return true;
		}
		else
		{
			return false;
		}
	}
	
	public boolean trataalterar(Long id, String desc)
	{
		Query query = manager.createQuery("SELECT e FROM Microorganismos e WHERE e.microDescricao =:desc");
		query.setParameter("desc", desc);
		
		if(query.getResultList().isEmpty())
		{
			Microorganismos micro = new Microorganismos();
			micro.setMicroDescricao(desc);
			micro.setId_Microorganismos(id);
			atualiza(micro);
				
			return true;
		}
		else
		{
			return false;
		}
	}
	
	public boolean remover(Long id) 
	{
		Microorganismos micro = new Microorganismos();
		micro = buscaPorId(id);

		remove(micro);
		return true;
	}
}