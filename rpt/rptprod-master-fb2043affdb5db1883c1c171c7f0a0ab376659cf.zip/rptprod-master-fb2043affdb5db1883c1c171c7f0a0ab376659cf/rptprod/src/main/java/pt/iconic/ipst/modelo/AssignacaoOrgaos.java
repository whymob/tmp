package pt.iconic.ipst.modelo;


import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name = "ASSIGNACAO_ORGAOS")
public class AssignacaoOrgaos {

	private Long id_assignacao;
	private OrgaosOferta orgoferta;
	private Dador dadoroferta;
	private List<AssignacaoHospital> assignacaohospital;
	private StatusAssignacaoOrgaos statusassignacao;
	private List<EquipaCirurgia> equipacirurgia;
	private List<EquipaCirurgiaTransplante> equipacirurgiatransplante;
	private Preoperatorio preoperatorio;
	private List<PreopTerapeuticas> preopterapeuticas;
	private TransplanteFigado transpfigado;
	private List<TransplanteFigadoPerfusao> transpfigadoperfusao;
	private List<TransplanteFigadoComplicacoes> transpfigadocompl;
	private List<TransplanteFigadoTransfusao> tanspfigadotransf;
	private TransplantePancreas transppancreas;
	private List<TransplantePancreasPerfusao> transppancreasperfusao;
	private List<TransplantePancreasComplicacoes> transppancreascompl;
	private List<TransplantePancreasTransfusao> tansppancreastransf;
	private TransplanteCoracao transpcoracao;
	private List<TransplanteCoracaoComplicacoes> transppcoracaocompl;
	private TransplantePulmoes transppulmoes;
	private List<TransplantePulmoesTransfusao> tansppulmoestransf;
	private List<TransplantePulmoesComplicacoes> transppulmoescompl;
	private List<TransplantePulmoesComplicacoesUCI> transppulmoescompluci;
	private TransplanteRins transprins;
	private List<TransplanteRinsPerfusao> transprinsperfusao;
	private List<TransplanteRinsComplicacoes> transprinscompl;
	private List<TransplanteRinsTransfusao> tansprinstransf;
	private EquipaLocalTransplante equipalocaltransplante;
	private List<EquipaSuporteTransplante> equipasuportetransplante;
	private TransplantePosOperatorio transpposop;
	private List<TransplantePosOperatorioComplicacoes> transpposopcompl;
	private List<TransplantePosOperatorioTerapeuticas> transpposopterap;
	private List<TransplantePosOperatorioAnalises> transpposopanalise;
	private List<AnaliseRecetorTransplante> analiserecetortransp;
	private Transplantes transplante;
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="ID_ASSIGNACAO_ORGAOS")
	public Long getId_assignacao() {
		return id_assignacao;
	}
	public void setId_assignacao(Long id_assignacao) {
		this.id_assignacao = id_assignacao;
	}
	
    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "ID_ORGAOOFERTA")
	public OrgaosOferta getOrgoferta() {
		return orgoferta;
	}
	public void setOrgoferta(OrgaosOferta orgoferta) {
		this.orgoferta = orgoferta;
	}
	
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "ID_DADOR")
	public Dador getDadoroferta() {
		return dadoroferta;
	}
    
	public void setDadoroferta(Dador dadoroferta) {
		this.dadoroferta = dadoroferta;
	}
	
	
	@OneToMany(fetch = FetchType.LAZY, mappedBy = "assignacaoorgao")
	public List<AssignacaoHospital> getAssignacaohospital() {
		return assignacaohospital;
	}
	public void setAssignacaohospital(List<AssignacaoHospital> assignacaohospital) {
		this.assignacaohospital = assignacaohospital;
	}
	
    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "ID_STATUS")
	public StatusAssignacaoOrgaos getStatusassignacao() {
		return statusassignacao;
	}
	public void setStatusassignacao(StatusAssignacaoOrgaos statusassignacao) {
		this.statusassignacao = statusassignacao;
	}
	
	@OneToMany(fetch = FetchType.LAZY, mappedBy = "assigorgao")
	public List<EquipaCirurgia> getEquipacirurgia() {
		return equipacirurgia;
	}
	public void setEquipacirurgia(List<EquipaCirurgia> equipacirurgia) {
		this.equipacirurgia = equipacirurgia;
	}
	
	@OneToMany(fetch = FetchType.LAZY, mappedBy = "assigorgao")
	public List<EquipaCirurgiaTransplante> getEquipacirurgiatransplante() {
		return equipacirurgiatransplante;
	}
	public void setEquipacirurgiatransplante(
			List<EquipaCirurgiaTransplante> equipacirurgiatransplante) {
		this.equipacirurgiatransplante = equipacirurgiatransplante;
	}
	
	@OneToOne(fetch = FetchType.LAZY, mappedBy = "assigorgao")
	public Preoperatorio getPreoperatorio() {
		return preoperatorio;
	}
	public void setPreoperatorio(Preoperatorio preoperatorio) {
		this.preoperatorio = preoperatorio;
	}
	
	@OneToMany(fetch = FetchType.LAZY, mappedBy = "assigorgao")
	public List<PreopTerapeuticas> getPreopterapeuticas() {
		return preopterapeuticas;
	}
	public void setPreopterapeuticas(List<PreopTerapeuticas> preopterapeuticas) {
		this.preopterapeuticas = preopterapeuticas;
	}
	
	@OneToOne(fetch = FetchType.LAZY, mappedBy = "assigorgao")
	public TransplanteFigado getTranspfigado() {
		return transpfigado;
	}
	public void setTranspfigado(TransplanteFigado transpfigado) {
		this.transpfigado = transpfigado;
	}
	
	@OneToMany(fetch = FetchType.LAZY, mappedBy = "assigorgao")
	public List<TransplanteFigadoPerfusao> getTranspfigadoperfusao() {
		return transpfigadoperfusao;
	}
	public void setTranspfigadoperfusao(List<TransplanteFigadoPerfusao> transpfigadoperfusao) {
		this.transpfigadoperfusao = transpfigadoperfusao;
	}
	
	@OneToMany(fetch = FetchType.LAZY, mappedBy = "assigorgao")
	public List<TransplanteFigadoComplicacoes> getTranspfigadocompl() {
		return transpfigadocompl;
	}
	public void setTranspfigadocompl(List<TransplanteFigadoComplicacoes> transpfigadocompl) {
		this.transpfigadocompl = transpfigadocompl;
	}
	
	@OneToMany(fetch = FetchType.LAZY, mappedBy = "assigorgao")
	public List<TransplanteFigadoTransfusao> getTanspfigadotransf() {
		return tanspfigadotransf;
	}
	public void setTanspfigadotransf(List<TransplanteFigadoTransfusao> tanspfigadotransf) {
		this.tanspfigadotransf = tanspfigadotransf;
	}
	
	@OneToOne(fetch = FetchType.LAZY, mappedBy = "assigorgao")
	public TransplantePancreas getTransppancreas() {
		return transppancreas;
	}
	public void setTransppancreas(TransplantePancreas transppancreas) {
		this.transppancreas = transppancreas;
	}
	
	@OneToMany(fetch = FetchType.LAZY, mappedBy = "assigorgao")
	public List<TransplantePancreasPerfusao> getTransppancreasperfusao() {
		return transppancreasperfusao;
	}
	public void setTransppancreasperfusao(List<TransplantePancreasPerfusao> transppancreasperfusao) {
		this.transppancreasperfusao = transppancreasperfusao;
	}
	
	@OneToMany(fetch = FetchType.LAZY, mappedBy = "assigorgao")
	public List<TransplantePancreasComplicacoes> getTransppancreascompl() {
		return transppancreascompl;
	}
	public void setTransppancreascompl(List<TransplantePancreasComplicacoes> transppancreascompl) {
		this.transppancreascompl = transppancreascompl;
	}
	
	@OneToMany(fetch = FetchType.LAZY, mappedBy = "assigorgao")
	public List<TransplantePancreasTransfusao> getTansppancreastransf() {
		return tansppancreastransf;
	}
	public void setTansppancreastransf(List<TransplantePancreasTransfusao> tansppancreastransf) {
		this.tansppancreastransf = tansppancreastransf;
	}
	
	@OneToOne(fetch = FetchType.LAZY, mappedBy = "assigorgao")
	public TransplanteCoracao getTranspcoracao() {
		return transpcoracao;
	}
	public void setTranspcoracao(TransplanteCoracao transpcoracao) {
		this.transpcoracao = transpcoracao;
	}
	
	@OneToMany(fetch = FetchType.LAZY, mappedBy = "assigorgao")
	public List<TransplanteCoracaoComplicacoes> getTransppcoracaocompl() {
		return transppcoracaocompl;
	}
	public void setTransppcoracaocompl(List<TransplanteCoracaoComplicacoes> transppcoracaocompl) {
		this.transppcoracaocompl = transppcoracaocompl;
	}
	
	@OneToOne(fetch = FetchType.LAZY, mappedBy = "assigorgao")
	public TransplantePulmoes getTransppulmoes() {
		return transppulmoes;
	}
	public void setTransppulmoes(TransplantePulmoes transppulmoes) {
		this.transppulmoes = transppulmoes;
	}
	
	@OneToMany(fetch = FetchType.LAZY, mappedBy = "assigorgao")
	public List<TransplantePulmoesTransfusao> getTansppulmoestransf() {
		return tansppulmoestransf;
	}
	public void setTansppulmoestransf(List<TransplantePulmoesTransfusao> tansppulmoestransf) {
		this.tansppulmoestransf = tansppulmoestransf;
	}
	
	@OneToMany(fetch = FetchType.LAZY, mappedBy = "assigorgao")
	public List<TransplantePulmoesComplicacoes> getTransppulmoescompl() {
		return transppulmoescompl;
	}
	public void setTransppulmoescompl(List<TransplantePulmoesComplicacoes> transppulmoescompl) {
		this.transppulmoescompl = transppulmoescompl;
	}
	
	@OneToMany(fetch = FetchType.LAZY, mappedBy = "assigorgao")
	public List<TransplantePulmoesComplicacoesUCI> getTransppulmoescompluci() {
		return transppulmoescompluci;
	}
	public void setTransppulmoescompluci(List<TransplantePulmoesComplicacoesUCI> transppulmoescompluci) {
		this.transppulmoescompluci = transppulmoescompluci;
	}
	
	@OneToOne(fetch = FetchType.LAZY, mappedBy = "assigorgao")
	public TransplanteRins getTransprins() {
		return transprins;
	}
	public void setTransprins(TransplanteRins transprins) {
		this.transprins = transprins;
	}
	
	@OneToMany(fetch = FetchType.LAZY, mappedBy = "assigorgao")
	public List<TransplanteRinsPerfusao> getTransprinsperfusao() {
		return transprinsperfusao;
	}
	public void setTransprinsperfusao(List<TransplanteRinsPerfusao> transprinsperfusao) {
		this.transprinsperfusao = transprinsperfusao;
	}
	
	@OneToMany(fetch = FetchType.LAZY, mappedBy = "assigorgao")
	public List<TransplanteRinsComplicacoes> getTransprinscompl() {
		return transprinscompl;
	}
	public void setTransprinscompl(List<TransplanteRinsComplicacoes> transprinscompl) {
		this.transprinscompl = transprinscompl;
	}
	
	@OneToMany(fetch = FetchType.LAZY, mappedBy = "assigorgao")
	public List<TransplanteRinsTransfusao> getTansprinstransf() {
		return tansprinstransf;
	}
	public void setTansprinstransf(List<TransplanteRinsTransfusao> tansprinstransf) {
		this.tansprinstransf = tansprinstransf;
	}
	
	@OneToOne(fetch = FetchType.LAZY, mappedBy = "assigorgao")
	public EquipaLocalTransplante getEquipalocaltransplante() {
		return equipalocaltransplante;
	}
	public void setEquipalocaltransplante(EquipaLocalTransplante equipalocaltransplante) {
		this.equipalocaltransplante = equipalocaltransplante;
	}
	
	@OneToMany(fetch = FetchType.LAZY, mappedBy = "assigorgao")
	public List<EquipaSuporteTransplante> getEquipasuportetransplante() {
		return equipasuportetransplante;
	}
	public void setEquipasuportetransplante(List<EquipaSuporteTransplante> equipasuportetransplante) {
		this.equipasuportetransplante = equipasuportetransplante;
	}
	
	@OneToOne(fetch = FetchType.LAZY, mappedBy = "assigorgao")
	public TransplantePosOperatorio getTranspposop() {
		return transpposop;
	}
	public void setTranspposop(TransplantePosOperatorio transpposop) {
		this.transpposop = transpposop;
	}
	
	@OneToMany(fetch = FetchType.LAZY, mappedBy = "assigorgao")
	public List<TransplantePosOperatorioComplicacoes> getTranspposopcompl() {
		return transpposopcompl;
	}
	public void setTranspposopcompl(List<TransplantePosOperatorioComplicacoes> transpposopcompl) {
		this.transpposopcompl = transpposopcompl;
	}
	
	@OneToMany(fetch = FetchType.LAZY, mappedBy = "assigorgao")
	public List<TransplantePosOperatorioTerapeuticas> getTranspposopterap() {
		return transpposopterap;
	}
	public void setTranspposopterap(List<TransplantePosOperatorioTerapeuticas> transpposopterap) {
		this.transpposopterap = transpposopterap;
	}
	
	@OneToMany(fetch = FetchType.LAZY, mappedBy = "assigorgao")
	public List<TransplantePosOperatorioAnalises> getTranspposopanalise() {
		return transpposopanalise;
	}
	public void setTranspposopanalise(List<TransplantePosOperatorioAnalises> transpposopanalise) {
		this.transpposopanalise = transpposopanalise;
	}
	
	@OneToMany(fetch = FetchType.LAZY, mappedBy = "assigorgao")
	public List<AnaliseRecetorTransplante> getAnaliserecetortransp() {
		return analiserecetortransp;
	}
	public void setAnaliserecetortransp(List<AnaliseRecetorTransplante> analiserecetortransp) {
		this.analiserecetortransp = analiserecetortransp;
	}
	
	@OneToOne(fetch = FetchType.LAZY, mappedBy = "assigorgao")
	public Transplantes getTransplante() {
		return transplante;
	}
	public void setTransplante(Transplantes transplante) {
		this.transplante = transplante;
	}
	
}
