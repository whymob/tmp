package pt.iconic.ipst.modelo;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name = "LESOESRADIOGRAFIA")
public class LesoesRadiografia 
{	
	private Long Id_LesaoRadiografia;
	private String Lesao;
	private boolean PE;
	private boolean PD;
	private boolean M;
	private AnaliseDador analiseDador;
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="ID_LESAORADIOGRAFIA")
	public Long getId_LesaoRadiografia() {
		return Id_LesaoRadiografia;
	}
	public void setId_LesaoRadiografia(Long id_LesaoRadiografia) {
		Id_LesaoRadiografia = id_LesaoRadiografia;
	}
	
	@Column(name="LESAO")
	public String getLesao() {
		return Lesao;
	}
	public void setLesao(String lesao) {
		Lesao = lesao;
	}
	
	@Column(name="PE")
	public boolean isPE() {
		return PE;
	}
	public void setPE(boolean pE) {
		PE = pE;
	}
	
	@Column(name="PD")
	public boolean isPD() {
		return PD;
	}
	public void setPD(boolean pD) {
		PD = pD;
	}

	@Column(name="M")
	public boolean isM() {
		return M;
	}
	public void setM(boolean m) {
		M = m;
	}
	
	@ManyToOne
	@JoinColumn(name="ID_ANALISEDADOR")
	public AnaliseDador getAnaliseDador() {
		return analiseDador;
	}
	public void setAnaliseDador(AnaliseDador analiseDador) {
		this.analiseDador = analiseDador;
	}
}