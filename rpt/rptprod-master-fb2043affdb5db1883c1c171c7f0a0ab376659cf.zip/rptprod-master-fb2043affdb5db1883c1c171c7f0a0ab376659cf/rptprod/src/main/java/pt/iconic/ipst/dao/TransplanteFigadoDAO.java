package pt.iconic.ipst.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import pt.iconic.ipst.modelo.TransplanteFigado;


@Repository
@Transactional
public class TransplanteFigadoDAO {

	@PersistenceContext
	private EntityManager manager;
	
	public void adiciona(TransplanteFigado transplante){
		manager.persist(transplante);	
	}
	
	public void atualiza(TransplanteFigado transplante){
		manager.merge(transplante);
	}
	
/*	@SuppressWarnings("unchecked")
	public List<TransplanteFigado> ListaTransplanteFigado(){
		return manager.createQuery("select a from TransplanteFigado a").getResultList();
	}*/
	
	public TransplanteFigado buscaPorId(Long id){
		return manager.find(TransplanteFigado.class, id);
	}
/*	
	public void remove(TransplanteFigado transplante){
		TransplanteFigado transplanteARemover = buscaPorId(transplante.getIdtransplantefigado());
		manager.remove(transplanteARemover);
	}*/
	
	@SuppressWarnings("unchecked")
	public TransplanteFigado buscaTransplanteFigadoAssigorgao(Long idassigorg){
		
		Query query = manager.createQuery("select p from TransplanteFigado p JOIN p.assigorgao a WHERE a.id_assignacao =:idassigorg");
		query.setParameter("idassigorg", idassigorg);
		
		List<TransplanteFigado> results = query.getResultList();
		TransplanteFigado transplante = null;
		if(!results.isEmpty()){
			transplante = (TransplanteFigado) results.get(0);
		}
		return transplante;
	}
}
