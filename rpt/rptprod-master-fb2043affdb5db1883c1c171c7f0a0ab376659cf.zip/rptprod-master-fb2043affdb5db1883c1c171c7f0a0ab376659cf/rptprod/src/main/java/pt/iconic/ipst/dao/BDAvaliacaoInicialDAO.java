package pt.iconic.ipst.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import pt.iconic.ipst.modelo.BDAvaliacaoInicial;;

@Repository
public class BDAvaliacaoInicialDAO {

	
	@PersistenceContext
	private EntityManager manager;
	
	
	public void adiciona(BDAvaliacaoInicial bdavaliacaoinicial){
		manager.persist(bdavaliacaoinicial);	
	}
	
	@Transactional
	public void atualiza(BDAvaliacaoInicial bdavaliacaoinicial){
		manager.merge(bdavaliacaoinicial);
	}
	

/*	@SuppressWarnings("unchecked")
	public List<BDAvaliacaoInicial> ListaBDAvaliacaoInicial(){
		return manager.createQuery("select d from BDAvaliacaoInicial d").getResultList();
	}*/
	
	public BDAvaliacaoInicial buscaPorId(Long id){
		return manager.find(BDAvaliacaoInicial.class, id);
	}
	
	
/*	public void remove(BDAvaliacaoInicial bdavaliacaoinicial){
		BDAvaliacaoInicial bdavaliacaoinicialARemover = buscaPorId(bdavaliacaoinicial.getId_BDAvaliacaoInicial());
		manager.remove(bdavaliacaoinicialARemover);
		
	}*/
	
	@SuppressWarnings("unchecked")
	public BDAvaliacaoInicial buscaavaliacaoinicial(Long idanalise){
		
		Query query = manager.createQuery("select b from BDAvaliacaoInicial b JOIN b.analiseDador a WHERE a.id_AnaliseDador =:idanalise");
		query.setParameter("idanalise", idanalise);
		
		List<BDAvaliacaoInicial> results = query.getResultList();
		BDAvaliacaoInicial avalinicial = null;
		if(!results.isEmpty()){
			avalinicial = (BDAvaliacaoInicial) results.get(0);
		}
		return avalinicial;
		
	}
}
