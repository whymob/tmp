package pt.iconic.ipst.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import pt.iconic.ipst.modelo.TransplantePosOperatorioAnalises;

@Repository
@Transactional
public class TransplantePosOperatorioAnalisesDAO {

	@PersistenceContext
	private EntityManager manager;
	
	
	public void adiciona(TransplantePosOperatorioAnalises transplante){
		manager.persist(transplante);	
	}
	

	public void atualiza(TransplantePosOperatorioAnalises transplante){
		manager.merge(transplante);
	}
	

/*	@SuppressWarnings("unchecked")
	public List<TransplantePosOperatorioAnalises> ListaTranspPosOperatorioAnalises(){
		return manager.createQuery("select a from TransplantePosOperatorioAnalises a").getResultList();
	}*/
	
	public TransplantePosOperatorioAnalises buscaPorId(Long id){
		return manager.find(TransplantePosOperatorioAnalises.class, id);
	}
	
	
	public void remove(TransplantePosOperatorioAnalises transplante){
		TransplantePosOperatorioAnalises transplanteARemover = buscaPorId(transplante.getIdtranspposopanalise());
		manager.remove(transplanteARemover);
		
	}
	
	@SuppressWarnings("unchecked")
	public List<TransplantePosOperatorioAnalises> listaTranspPosOperatorioanalisesassig(Long idassigorg){
		
		Query query = manager.createQuery("select b from TransplantePosOperatorioAnalises b JOIN b.assigorgao a WHERE a.id_assignacao =:idassigorg");
		query.setParameter("idassigorg", idassigorg);
		
		List<TransplantePosOperatorioAnalises> results = query.getResultList();
		return results;
		
	}
}
