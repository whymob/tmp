package pt.iconic.ipst.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import pt.iconic.ipst.modelo.AnaliseDador;
import pt.iconic.ipst.modelo.DadosAbdFigado;

@Repository
@Transactional
public class DadosAbdFigadoDAO 
{
	@PersistenceContext
	private EntityManager manager;
	
/*	public void adiciona(DadosAbdFigado dadoseco){
		manager.persist(dadoseco);	
	}*/
	
	@Transactional
	public void atualiza(DadosAbdFigado dadoseco){
		manager.merge(dadoseco);
	}

/*	@SuppressWarnings("unchecked")
	public List<DadosAbdFigado> DadosAbdFigado(){
		return manager.createQuery("select d from LesoesRadiografia d").getResultList();
	}*/
	
	public DadosAbdFigado buscaPorId(Long id){
		return manager.find(DadosAbdFigado.class, id);
	}
	
	public void remove(DadosAbdFigado dadoseco){
		DadosAbdFigado lesoes = buscaPorId(dadoseco.getId_DadosAbdFigado());
		manager.remove(lesoes);
	}
	
	//adiciona a lesao � tabela
	@Transactional
	public boolean adicionalesao(String lesao, int numero, int segmento, String notas, Long id_analise)
	{
		AnaliseDador analise = manager.find(AnaliseDador.class, id_analise);
		
		DadosAbdFigado lesoes = new DadosAbdFigado();
		lesoes.setAnaliseDador(analise);
		lesoes.setNumero(numero);
		lesoes.setObservacoes(notas);
		lesoes.setSegmento(segmento);
		lesoes.setTipo(lesao);

		manager.persist(lesoes);
					
		return true;
	}
	
	//carrega as lesoes quando insere a ultima lesao para que as da ultima apare�am em cima
	@SuppressWarnings("unchecked")
	public List<DadosAbdFigado> buscalesoesDescendente(Long idanalise)
	{		
		Query query = manager.createQuery("select a from DadosAbdFigado a JOIN a.analiseDador an WHERE an.id_AnaliseDador =:idanalise");
		query.setParameter("idanalise", idanalise);

		List<DadosAbdFigado> results = query.getResultList();

		return results;
	}
}