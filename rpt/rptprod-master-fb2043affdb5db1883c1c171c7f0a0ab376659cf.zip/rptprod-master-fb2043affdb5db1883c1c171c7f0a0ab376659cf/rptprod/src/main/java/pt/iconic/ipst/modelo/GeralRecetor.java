package pt.iconic.ipst.modelo;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name = "GERALRECETOR")
public class GeralRecetor 
{
	private Long id_geralrecetor;
	private boolean hospitalizado;
	private int capacidadefisica;
	private int tipoatividade;
	private int tipotrabalho;
	private int tipoacademica;
	private boolean tratamentoiv;
	private boolean eventocerebrovascular;
	private boolean dialise;
	private boolean desfimplantado;
	private boolean intcardant;
	private boolean intpulmant;
	private boolean supventant;
	private boolean outros;
	private String notasgeral;
	private AnaliseRecetor analiserecetor;
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="ID_RECETORGERAL")
	public Long getId_geralrecetor() {
		return id_geralrecetor;
	}
	public void setId_geralrecetor(Long id_geralrecetor) {
		this.id_geralrecetor = id_geralrecetor;
	}
	
	@Column(name="HOSPITALIZADO")
	public boolean isHospitalizado() {
		return hospitalizado;
	}
	public void setHospitalizado(boolean hospitalizado) {
		this.hospitalizado = hospitalizado;
	}
	
	@Column(name="CAPACIDADEFISICA")
	public int getCapacidadefisica() {
		return capacidadefisica;
	}
	public void setCapacidadefisica(int capacidadefisica) {
		this.capacidadefisica = capacidadefisica;
	}
	
	@Column(name="TIPOATIVIDADE")
	public int getTipoatividade() {
		return tipoatividade;
	}
	public void setTipoatividade(int tipoatividade) {
		this.tipoatividade = tipoatividade;
	}
	
	@Column(name="TIPOTRABALHO")
	public int getTipotrabalho() {
		return tipotrabalho;
	}
	public void setTipotrabalho(int tipotrabalho) {
		this.tipotrabalho = tipotrabalho;
	}
	
	@Column(name="TIPOACADEMICA")
	public int getTipoacademica() {
		return tipoacademica;
	}
	public void setTipoacademica(int tipoacademica) {
		this.tipoacademica = tipoacademica;
	}
	
	@Column(name="TRATAMENTOIV")
	public boolean isTratamentoiv() {
		return tratamentoiv;
	}
	public void setTratamentoiv(boolean tratamentoiv) {
		this.tratamentoiv = tratamentoiv;
	}
	
	@Column(name="EVENTOCEREBROVASC")
	public boolean isEventocerebrovascular() {
		return eventocerebrovascular;
	}
	public void setEventocerebrovascular(boolean eventocerebrovascular) {
		this.eventocerebrovascular = eventocerebrovascular;
	}
	
	@Column(name="DIALISE")
	public boolean isDialise() {
		return dialise;
	}
	public void setDialise(boolean dialise) {
		this.dialise = dialise;
	}
	
	@Column(name="DESFIMP")
	public boolean isDesfimplantado() {
		return desfimplantado;
	}
	public void setDesfimplantado(boolean desfimplantado) {
		this.desfimplantado = desfimplantado;
	}
	
	@Column(name="INTCARDANT")
	public boolean isIntcardant() {
		return intcardant;
	}
	public void setIntcardant(boolean intcardant) {
		this.intcardant = intcardant;
	}
	
	@Column(name="INTPULMANT")
	public boolean isIntpulmant() {
		return intpulmant;
	}
	public void setIntpulmant(boolean intpulmant) {
		this.intpulmant = intpulmant;
	}
	
	@Column(name="SUPVENTANT")
	public boolean isSupventant() {
		return supventant;
	}
	public void setSupventant(boolean supventant) {
		this.supventant = supventant;
	}
	
	@Column(name="OUTROS")
	public boolean isOutros() {
		return outros;
	}
	public void setOutros(boolean outros) {
		this.outros = outros;
	}
	
	@Column(name="NOTAS")
	public String getNotasgeral() {
		return notasgeral;
	}
	public void setNotasgeral(String notasgeral) {
		this.notasgeral = notasgeral;
	}

	@OneToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="ID_ANALISERECETOR")
	public AnaliseRecetor getAnaliserecetor() {
		return analiserecetor;
	}
	public void setAnaliserecetor(AnaliseRecetor analiserecetor) {
		this.analiserecetor = analiserecetor;
	}
}