package pt.iconic.ipst.modelo;

import java.util.Calendar;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name = "PPPANCREATICO")
public class PPPancreatico 
{
	private Long id_pppancreatico;
	private AnaliseRecetor analiserecetor;
//	private double pesopancreatico;
//	private int alturapancreatico;
//	private Etnia etniapancreatico;
	private int transfusoespancreatico;
	private int gestacoespancreatico;
	private float imcpancreatico;
	private int pertoraxicopancreatico;
	private Calendar ulimatransfusaopancreatico;
	//private boolean hbpancreatico;
	//private boolean hcpancreatico;
//	private boolean rhpancreatico;
//	private int abopancreatico;
	private int diagnosticopancreatico;
	private String observacoespancreatico;
//	private boolean retransplantadopancreatico;
	private Calendar datadiagnostico;
	private String duracao;
	private boolean retinopatia;
	private String retinonotas;
	private boolean arteriopatia;
	private String arterionotas;
	private boolean neuropatia;
	private String neuronotas;
	private int candidatoa;
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="ID_PPPANCREATICO")
	public Long getId_pppancreatico() {
		return id_pppancreatico;
	}
	public void setId_pppancreatico(Long id_pppancreatico) {
		this.id_pppancreatico = id_pppancreatico;
	}
	
	@OneToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="ID_ANALISERECETOR")
	public AnaliseRecetor getAnaliserecetor() {
		return analiserecetor;
	}
	public void setAnaliserecetor(AnaliseRecetor analiserecetor) {
		this.analiserecetor = analiserecetor;
	}
	
//	@Column(name="PESO")
//	public double getPesopancreatico() {
//		return pesopancreatico;
//	}
//	public void setPesopancreatico(double pesopancreatico) {
//		this.pesopancreatico = pesopancreatico;
//	}
//	
//	@Column(name="ALTURA")
//	public int getAlturapancreatico() {
//		return alturapancreatico;
//	}
//	public void setAlturapancreatico(int alturapancreatico) {
//		this.alturapancreatico = alturapancreatico;
//	}
//	
//	@OneToOne(fetch = FetchType.EAGER)
//    @JoinColumn(name = "ID_ETNIA")
//	public Etnia getEtniapancreatico() {
//		return etniapancreatico;
//	}
//	public void setEtniapancreatico(Etnia etniapancreatico) {
//		this.etniapancreatico = etniapancreatico;
//	}
	
	@Column(name="TRANSFUSOES")
	public int getTransfusoespancreatico() {
		return transfusoespancreatico;
	}
	public void setTransfusoespancreatico(int transfusoespancreatico) {
		this.transfusoespancreatico = transfusoespancreatico;
	}
	
	@Column(name="GESTACOES")
	public int getGestacoespancreatico() {
		return gestacoespancreatico;
	}
	public void setGestacoespancreatico(int gestacoespancreatico) {
		this.gestacoespancreatico = gestacoespancreatico;
	}
	
	@Column(name="IMC")
	public float getImcpancreatico() {
		return imcpancreatico;
	}
	public void setImcpancreatico(float imcpancreatico) {
		this.imcpancreatico = imcpancreatico;
	}
	
	@Column(name="PERTORAXICO")
	public int getPertoraxicopancreatico() {
		return pertoraxicopancreatico;
	}
	public void setPertoraxicopancreatico(int pertoraxicopancreatico) {
		this.pertoraxicopancreatico = pertoraxicopancreatico;
	}
	
	@Column(name="ULTIMATRANSFUSAO")
	public Calendar getUlimatransfusaopancreatico() {
		return ulimatransfusaopancreatico;
	}
	public void setUlimatransfusaopancreatico(Calendar ulimatransfusaopancreatico) {
		this.ulimatransfusaopancreatico = ulimatransfusaopancreatico;
	}
	
//	@Column(name="HB")
//	public boolean isHbpancreatico() {
//		return hbpancreatico;
//	}
//	public void setHbpancreatico(boolean hbpancreatico) {
//		this.hbpancreatico = hbpancreatico;
//	}
//	
//	@Column(name="HC")
//	public boolean isHcpancreatico() {
//		return hcpancreatico;
//	}
//	public void setHcpancreatico(boolean hcpancreatico) {
//		this.hcpancreatico = hcpancreatico;
//	}
	
//	@Column(name="RH")
//	public boolean isRhpancreatico() {
//		return rhpancreatico;
//	}
//	public void setRhpancreatico(boolean rhpancreatico) {
//		this.rhpancreatico = rhpancreatico;
//	}
//	
//	@Column(name="ABO")
//	public int getAbopancreatico() {
//		return abopancreatico;
//	}
//	public void setAbopancreatico(int abopancreatico) {
//		this.abopancreatico = abopancreatico;
//	}
	
	@Column(name="DIAGNOSTICO")
	public int getDiagnosticopancreatico() {
		return diagnosticopancreatico;
	}
	public void setDiagnosticopancreatico(int diagnosticopancreatico) {
		this.diagnosticopancreatico = diagnosticopancreatico;
	}
	
	@Column(name="OBSERVACOES")
	public String getObservacoespancreatico() {
		return observacoespancreatico;
	}
	public void setObservacoespancreatico(String observacoespancreatico) {
		this.observacoespancreatico = observacoespancreatico;
	}
	
//	@Column(name="RETRANSPLANTADO")
//	public boolean isRetransplantadopancreatico() {
//		return retransplantadopancreatico;
//	}
//	public void setRetransplantadopancreatico(boolean retransplantadopancreatico) {
//		this.retransplantadopancreatico = retransplantadopancreatico;
//	}
	
	@Column(name="DATADIAGNOSTICO")
	public Calendar getDatadiagnostico() {
		return datadiagnostico;
	}
	public void setDatadiagnostico(Calendar datadiagnostico) {
		this.datadiagnostico = datadiagnostico;
	}
	
	@Column(name="DURACAO")
	public String getDuracao() {
		return duracao;
	}
	public void setDuracao(String duracao) {
		this.duracao = duracao;
	}
	
	@Column(name="RETINOPATIA")
	public boolean isRetinopatia() {
		return retinopatia;
	}
	public void setRetinopatia(boolean retinopatia) {
		this.retinopatia = retinopatia;
	}
	
	@Column(name="RETINONOTAS")
	public String getRetinonotas() {
		return retinonotas;
	}
	public void setRetinonotas(String retinonotas) {
		this.retinonotas = retinonotas;
	}
	
	@Column(name="ARTERIOPATIA")
	public boolean isArteriopatia() {
		return arteriopatia;
	}
	public void setArteriopatia(boolean arteriopatia) {
		this.arteriopatia = arteriopatia;
	}
	
	@Column(name="ARTERIONOTAS")
	public String getArterionotas() {
		return arterionotas;
	}
	public void setArterionotas(String arterionotas) {
		this.arterionotas = arterionotas;
	}
	
	@Column(name="NEUROPATIA")
	public boolean isNeuropatia() {
		return neuropatia;
	}
	public void setNeuropatia(boolean neuropatia) {
		this.neuropatia = neuropatia;
	}
	
	@Column(name="NEURONOTAS")
	public String getNeuronotas() {
		return neuronotas;
	}
	public void setNeuronotas(String neuronotas) {
		this.neuronotas = neuronotas;
	}
	
	@Column(name="CANDIDATOA")
	public int getCandidatoa() {
		return candidatoa;
	}
	public void setCandidatoa(int candidatoa) {
		this.candidatoa = candidatoa;
	}	
}