package pt.iconic.ipst.modelo;

import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name = "ANALISERECETOR")
public class AnaliseRecetor 
{
	private Long id_analiserecetor;
	private Recetores recetor;
	private GeralRecetor geralrecetor;
	private List<ContatosRecetor> contatosrecetor;
	private List<GravidadeRecetor> gravidaderecetor;
	private List<PPAnalisesRecetor> ppanalisesrecetor;
	private List<EstadoRecetor> estadorecetor;
	private List<VirologiaRecetor> virologia;
	private List<PPHepaticoComorbilidades> pphepaticocomorbilidades;
	private List<PPHepaticoDiagnostico> pphepaticodiagnostico;
	private List<PPHepaticoComplicacoes> pphepaticocomplicacao;
//	private Preoperatorio preoperatorio;
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="ID_ANALISERECETOR")
	public Long getId_analiserecetor() {
		return id_analiserecetor;
	}
	public void setId_analiserecetor(Long id_analiserecetor) {
		this.id_analiserecetor = id_analiserecetor;
	}
	
	@OneToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "ID_RECETOR")
	public Recetores getRecetor() {
		return recetor;
	}
	public void setRecetor(Recetores recetor) {
		this.recetor = recetor;
	}
	
	@OneToOne(fetch = FetchType.LAZY, mappedBy = "analiserecetor")
	public GeralRecetor getGeralrecetor() {
		return geralrecetor;
	}
	public void setGeralrecetor(GeralRecetor geralrecetor) {
		this.geralrecetor = geralrecetor;
	}
	
	@OneToMany(fetch = FetchType.LAZY, mappedBy = "analiserecetor")
	public List<ContatosRecetor> getContatosrecetor() {
		return contatosrecetor;
	}
	public void setContatosrecetor(List<ContatosRecetor> contatosrecetor) {
		this.contatosrecetor = contatosrecetor;
	}
	
	@OneToMany(fetch = FetchType.LAZY, mappedBy = "analiserecetor")
	public List<GravidadeRecetor> getGravidaderecetor() {
		return gravidaderecetor;
	}
	public void setGravidaderecetor(List<GravidadeRecetor> gravidaderecetor) {
		this.gravidaderecetor = gravidaderecetor;
	}
	
	@OneToMany(fetch = FetchType.LAZY, mappedBy = "analiserecetor")
	public List<PPAnalisesRecetor> getPpanalisesrecetor() {
		return ppanalisesrecetor;
	}
	public void setPpanalisesrecetor(List<PPAnalisesRecetor> ppanalisesrecetor) {
		this.ppanalisesrecetor = ppanalisesrecetor;
	}	
	
	@OneToMany(fetch = FetchType.LAZY, mappedBy = "analiserecetor")
	public List<EstadoRecetor> getEstadorecetor() {
		return estadorecetor;
	}
	public void setEstadorecetor(List<EstadoRecetor> estadorecetor) {
		this.estadorecetor = estadorecetor;
	}
	
	@OneToMany(fetch = FetchType.LAZY, mappedBy = "analiserecetor")
	public List<VirologiaRecetor> getVirologia() {
		return virologia;
	}
	public void setVirologia(List<VirologiaRecetor> virologia) {
		this.virologia = virologia;
	}
	
	@OneToMany(fetch = FetchType.LAZY, mappedBy = "analiserecetor")
	public List<PPHepaticoComorbilidades> getPphepaticocomorbilidades() {
		return pphepaticocomorbilidades;
	}
	public void setPphepaticocomorbilidades(List<PPHepaticoComorbilidades> pphepaticocomorbilidades) {
		this.pphepaticocomorbilidades = pphepaticocomorbilidades;
	}
	
	@OneToMany(fetch = FetchType.LAZY, mappedBy = "analiserecetor")
	public List<PPHepaticoDiagnostico> getPphepaticodiagnostico() {
		return pphepaticodiagnostico;
	}
	public void setPphepaticodiagnostico(List<PPHepaticoDiagnostico> pphepaticodiagnostico) {
		this.pphepaticodiagnostico = pphepaticodiagnostico;
	}
	
	@OneToMany(fetch = FetchType.LAZY, mappedBy = "analiserecetor")
	public List<PPHepaticoComplicacoes> getPphepaticocomplicacao() {
		return pphepaticocomplicacao;
	}
	public void setPphepaticocomplicacao(List<PPHepaticoComplicacoes> pphepaticocomplicacao) {
		this.pphepaticocomplicacao = pphepaticocomplicacao;
	}
	
//	@OneToOne(fetch = FetchType.LAZY, mappedBy = "analiseRecetor")
//	public Preoperatorio getPreoperatorio() {
//		return preoperatorio;
//	}
//	public void setPreoperatorio(Preoperatorio preoperatorio) {
//		this.preoperatorio = preoperatorio;
//	}
}