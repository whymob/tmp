package pt.iconic.ipst.controller;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import javax.servlet.http.HttpSession;

import org.json.simple.JSONArray;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import pt.iconic.ipst.dao.DadorDAO;
import pt.iconic.ipst.dao.DadorDetalhesDAO;
import pt.iconic.ipst.dao.EstadoDadorDAO;
import pt.iconic.ipst.dao.EtniaDAO;
import pt.iconic.ipst.dao.GlasgowCommaDAO;
import pt.iconic.ipst.dao.HospitalDAO;
import pt.iconic.ipst.dao.PaisesDAO;
import pt.iconic.ipst.dao.UtilizadorBDAO;
import pt.iconic.ipst.dao.UtilizadorDAO;
import pt.iconic.ipst.modelo.Dador;
import pt.iconic.ipst.modelo.DadorDetalhes;
import pt.iconic.ipst.modelo.EstadoDador;
import pt.iconic.ipst.modelo.GlasgowComma;
import pt.iconic.ipst.modelo.Hospital;
import pt.iconic.ipst.modelo.TipoDador;
import pt.iconic.ipst.modelo.Utilizador;
import pt.iconic.ipst.modelo.UtilizadorB;

@Controller
public class ReferenciarController 
{
	private DadorDAO daoDador;
	private GlasgowCommaDAO daoglasgow;
	private HospitalDAO daohospital;
	private EtniaDAO daoetnia;
	private PaisesDAO daopaises;
	private UtilizadorDAO daouser;
	private UtilizadorBDAO daouserb;
	private DadorDetalhesDAO daodadordet;
	private EstadoDadorDAO daoestado;

	
	@Autowired
	public ReferenciarController(DadorDAO daoDador, GlasgowCommaDAO daoglasgow, HospitalDAO daohospital, EtniaDAO daoetnia, PaisesDAO daopaises, UtilizadorDAO daouser, UtilizadorBDAO daouserb,
			DadorDetalhesDAO daodadordet, EstadoDadorDAO daoestado)
	{
		this.daoDador = daoDador;
		this.daoglasgow = daoglasgow;
		this.daohospital = daohospital;
		this.daoetnia = daoetnia;
		this.daopaises = daopaises;
		this.daouser = daouser;
		this.daouserb = daouserb;
		this.daodadordet = daodadordet;
		this.daoestado = daoestado;
	}
	
	@RequestMapping(value="referenciarutenteb", method = RequestMethod.POST)
	@ResponseBody
	public String referenciarutenteb(@RequestParam("nome") String nome,  @RequestParam("sns") int sns,  @RequestParam("hospital") Long hospital,  @RequestParam("uci") String uci,  @RequestParam("glasgow") Long glasgow, @RequestParam("sexo") String sexo,  HttpSession session) 
	{
		String tipoutilizador =	(String) session.getAttribute("tipoutilizador");
		Long idutilizador = (Long) session.getAttribute("iduser");
		
		GlasgowComma g = daoglasgow.buscaPorId(glasgow);
		Hospital h = daohospital.buscaPorId(hospital);
		
		TipoDador t = new TipoDador();
		EstadoDador e = new EstadoDador();
		Dador dador = new Dador();
		
		dador.setUCI(uci);
		dador.setNomeDador(nome);
		dador.setSns(sns);
		dador.setGlasgowComma(g);
		dador.setHospital(h);
		
		e.setId_EstadoDador(1);
		t.setId_TipoDador(1L);
		dador.setTipoDador(t);
		dador.setEstadoDador(e);
		
		if(tipoutilizador.equalsIgnoreCase("a") == true)
		{
			Utilizador uti = new Utilizador();
			uti.setID_Utilizador(idutilizador);
			
			dador.setUtilizador(uti);
		}
		else
		{
			UtilizadorB uti = new UtilizadorB();
			uti.setId_UtilizadorB(idutilizador);
			
			dador.setUtilizadorb(uti);
		}
		
		if(sexo.equalsIgnoreCase("M") == true)
			dador.setSexo(true);
		else
			dador.setSexo(false);
		
		daoDador.adiciona(dador);

/*		//buscar utilizadores com CHD ou IPST desse hospital
		List<Long> users = daouser.buscausershospitalperfilCHDouIPST(h.getId_Hospital());
		NotificationsController notificacao = new NotificationsController();
		JSONArray perfis = new JSONArray();
		perfis.add("CHD");
		perfis.add("IPST");
		String msg = "Dador "+dador.getCodigoDador()+" referenciado";
		notificacao.envianotificacao(users, 1, perfis, "", msg, dador.getCodigoDador(), 2);*/
		return "true";	
	}


	@RequestMapping(value="referenciarutente", method = RequestMethod.POST)
	@ResponseBody
	public String referenciarutente(@RequestParam("nome") String nome,  @RequestParam("sns") int sns,  @RequestParam("hospital") Long hospital,  @RequestParam("uci") String uci,  @RequestParam("glasgow") Long glasgow, @RequestParam("sexo") String sexo,  HttpSession session) 
	{
		String tipoutilizador =	(String) session.getAttribute("tipoutilizador");
		Long idutilizador = (Long) session.getAttribute("iduser");
		
		GlasgowComma g = daoglasgow.buscaPorId(glasgow);
		Hospital h = daohospital.buscaPorId(hospital);
		TipoDador t = new TipoDador();
		Dador dador = new Dador();
		
		dador.setUCI(uci);
		dador.setNomeDador(nome);
		dador.setSns(sns);
		dador.setGlasgowComma(g);
		dador.setHospital(h);
		dador.setTipoDador(t);
		t.setId_TipoDador(1L);
		
		if(tipoutilizador.equalsIgnoreCase("a") == true)
		{
			Utilizador uti = new Utilizador();
			uti.setID_Utilizador(idutilizador);
			
			dador.setUtilizador(uti);
		}
		else
		{
			UtilizadorB uti = new UtilizadorB();
			uti.setId_UtilizadorB(idutilizador);
			
			dador.setUtilizadorb(uti);
		}
		
		if(sexo.equalsIgnoreCase("M") == true)
			dador.setSexo(true);
		else
			dador.setSexo(false);
		
		daoDador.adiciona(dador);

/*		//buscar utilizadores com CHD ou IPST desse hospital
		List<Long> users = daouser.buscausershospitalperfilCHDouIPST(h.getId_Hospital());
		NotificationsController notificacao = new NotificationsController();
		JSONArray perfis = new JSONArray();
		perfis.add("CHD");
		perfis.add("IPST");
		String msg = "Dador "+dador.getCodigoDador()+" referenciado";
		notificacao.envianotificacao(users, 1, perfis, "", msg, dador.getCodigoDador(), 2);*/
		
		return "true";	
	}
	
	
	
	@RequestMapping(value="inseredadormanual")
	public String inseredadormanual(Model model, HttpSession session){
		model.addAttribute("etnia", daoetnia.ListaEtnia());
		model.addAttribute("paises", daopaises.ListaPaises());
		model.addAttribute("hospitaisuser", daohospital.ListaHospitais());
		model.addAttribute("glasgowcommadador", daoglasgow.ListaGlasgowComma());
		
		
		if(session.getAttribute("tipoutilizador")=="a"){
			model.addAttribute("hospital",(Long)session.getAttribute("idlocalizacao"));
			return "admin/divinseredadormanual";
		}else{

			return "admin/divinseredadormanualb";
		}
		
		
		
		

	}
	
	
	
	@SuppressWarnings("unchecked")
	@RequestMapping(value="registardadormanual" , method = RequestMethod.POST)
	@Transactional
	public String registardadormanual(@RequestParam("sexo") boolean sexo, 
			@RequestParam("nsns") int sns, @RequestParam("nif") int nif, @RequestParam("nomedador") String nome, @RequestParam("nacionalidadedador") String nacionalidade,
			@RequestParam("tipodociddador") int tipodociddador, @RequestParam("numdociddador") int numdociddador, @RequestParam("ucidadormanual") String ucidadormanual,
			@RequestParam("moradadador") String moradadador, @RequestParam("moradacontdador") String moradacontdador, @RequestParam("localidadedador") String localidadedador,
			@RequestParam("emaildador") String emaildador, @RequestParam("telemoveldador") int telemoveldador, @RequestParam("telefonedador") int telefonedador,
			@RequestParam("codpostaldador") String codpostaldador, @RequestParam("pesodador") int pesodador, @RequestParam("alturadador") int alturadador, 
			@RequestParam("datanascimentodador2") String datanascimentodador,
			@RequestParam("hospitaisuser") Long hospitaisuser,
			//@RequestParam("glasgowcommadador") Long glasgowcommadador,
			@RequestParam("etniadador") Long etniadador, @RequestParam("paises") int paises, Model model, HttpSession session) throws ParseException{
		
	//datanascimentodador

		Dador d = new Dador();
		if(session.getAttribute("tipoutilizador")=="a"){

			d.setUtilizador(daouser.buscaPorId((Long)session.getAttribute("iduser")));

		}else{
			
			System.out.println("Utilizador B");
			d.setUtilizadorb(daouserb.buscaPorId((Long)session.getAttribute("iduser")));
			
		}
		
		
	//gerar codigo dador
		
		int ano = Calendar.getInstance().get(Calendar.YEAR);
		
		String a = daoDador.buscaultimocodigodador2(ano);
		if(a==null)
		{
			a="0";
		}
		int codigo = Integer.parseInt(a);
		
		String somacodigo = leftPad(codigo+1, 6);
		String novocodigoDador = "PT"+ano+"/"+somacodigo;
		
		//daoDador.buscaultimocodigodador();	
		
		d.setCodigoDador(novocodigoDador);

		
		Calendar calhoje = Calendar.getInstance();
		d.setUCI(ucidadormanual);

		d.setDataregisto(calhoje);
		
		if(!datanascimentodador.equals("")){
			DateFormat df = new SimpleDateFormat("dd/MM/yyyy");
			Date date = df.parse(datanascimentodador);
			Calendar cal = Calendar.getInstance();
			cal.setTime(date);
			d.setDataNascimento(cal);
		}
		d.setNacionalidade(nacionalidade);
		d.setNomeDador(nome);
		d.setSexo(sexo);
		d.setSns(sns);
		
		Hospital h = daohospital.buscaPorId(hospitaisuser);
		d.setHospital(h);
		
		if(paises==0)
		{
			d.setPais(daopaises.buscaPorId(83));
		}else{
			d.setPais(daopaises.buscaPorId(paises));
		}
		
		d.setEstadoDador(daoestado.buscaPorId(1));
		
		TipoDador tipodador = new TipoDador();
		tipodador.setId_TipoDador(1L);
		d.setTipoDador(tipodador);
		
		//Adicionadador
		daoDador.adiciona(d);
		
		//criar detalhe do dador
		DadorDetalhes dd = new DadorDetalhes();
		dd.setDador(d);
		dd.setAltura(alturadador);
		dd.setCodpostal(codpostaldador);
		dd.setEmail(emaildador);
		dd.setLocalidade(localidadedador);
		dd.setMorada(moradadador);
		dd.setMoradacont(moradacontdador);
		dd.setNif(nif);
		dd.setPeso(pesodador);
		dd.setTelefone(telefonedador);
		dd.setTelemovel(telemoveldador);
		dd.setEtnia(daoetnia.buscaPorId(etniadador));
		daodadordet.adiciona(dd);
		
    	if((Long)session.getAttribute("idposicao")==1){
 //   		System.out.println("Dadores completos  administrador");	
    		model.addAttribute("dadores",daoDador.ListaDador());
    	}
    	else{
	
    		model.addAttribute("dadores",daoDador.ListaDadorPermissao((Long)session.getAttribute("idposicao"), (Long)session.getAttribute("iduser"), (Long)session.getAttribute("idlocalizacao")));	
    	}
		
		//buscar utilizadores com CHD ou IPST desse hospital
		List<Long> users = daouser.buscausershospitaldadorreferenciado(hospitaisuser);

		NotificationsController notificacao = new NotificationsController();
		JSONArray perfis = new JSONArray();
/*		perfis.add("CHD");*/
		perfis.add("IPST");
/*	    perfis.add("GCCT");
		perfis.add("EC"); */
		String msg = "Novo potencial dador no "+h.getNomeHospital()+" referenciado �s " +new SimpleDateFormat("HH:mm").format(calhoje.getTime());
		notificacao.envianotificacao(users, 1, perfis, "", msg, d.getCodigoDador(), 2);
    	
    	
		return "admin/loads/tabeladadores";
	}
	
	
	public static String leftPad(int n, int padding) {
	    return String.format("%0" + padding + "d", n);
	}
	
	
	@SuppressWarnings("unchecked")
	@RequestMapping(value="registardadormanualb" , method = RequestMethod.POST)
	@ResponseBody
	@Transactional
	public String registardadormanualb(@RequestParam("sexo") boolean sexo, 
			@RequestParam("nsns") int sns, @RequestParam("nif") int nif, @RequestParam("nomedador") String nome, @RequestParam("nacionalidadedador") String nacionalidade,
			@RequestParam("tipodociddador") int tipodociddador, @RequestParam("numdociddador") int numdociddador, @RequestParam("ucidadormanual") String ucidadormanual,
			@RequestParam("moradadador") String moradadador, @RequestParam("moradacontdador") String moradacontdador, @RequestParam("localidadedador") String localidadedador,
			@RequestParam("emaildador") String emaildador, @RequestParam("telemoveldador") int telemoveldador, @RequestParam("telefonedador") int telefonedador,
			@RequestParam("codpostaldador") String codpostaldador, @RequestParam("pesodador") int pesodador, @RequestParam("alturadador") int alturadador, 
			@RequestParam("datanascimentodador2") String datanascimentodador,
			@RequestParam("hospitaisuser") Long hospitaisuser, 
			//@RequestParam("glasgowcommadador") Long glasgowcommadador,
			@RequestParam("etniadador") Long etniadador, @RequestParam("paises") int paises, Model model, HttpSession session) throws ParseException{
		
	//datanascimentodador

		Dador d = new Dador();

			d.setUtilizadorb(daouserb.buscaPorId((Long)session.getAttribute("iduser")));
		

	//gerar codigo dador
		int ano = Calendar.getInstance().get(Calendar.YEAR);
		String a = daoDador.buscaultimocodigodador2(ano);
		if(a==null)
		{
			a="0";
		}
		int codigo = Integer.parseInt(a);
		String somacodigo = leftPad(codigo+1, 6);
		String novocodigoDador = "PT"+ano+"/"+somacodigo;	
		d.setCodigoDador(novocodigoDador);

		Calendar calhoje = Calendar.getInstance();
		d.setUCI(ucidadormanual);

		d.setDataregisto(calhoje);
		
		if(!datanascimentodador.equals("")){
			DateFormat df = new SimpleDateFormat("dd/MM/yyyy");
			Date date = df.parse(datanascimentodador);
			Calendar cal = Calendar.getInstance();
			cal.setTime(date);
			d.setDataNascimento(cal);
		}
		
		d.setNacionalidade(nacionalidade);
		d.setNomeDador(nome);
		d.setSexo(sexo);
		d.setSns(sns);
		//d.setGlasgowComma(daoglasgow.buscaPorId(glasgowcommadador));
		Hospital h = daohospital.buscaPorId(hospitaisuser);
		d.setHospital(h);
		if(paises==0)
		{
			d.setPais(daopaises.buscaPorId(83));
		}else{
			d.setPais(daopaises.buscaPorId(paises));
		}
		
		d.setEstadoDador(daoestado.buscaPorId(1));
		
		TipoDador tipodador = new TipoDador();
		tipodador.setId_TipoDador(1L);
		d.setTipoDador(tipodador);
		
		//Adicionadador
		daoDador.adiciona(d);
		
		//criar detalhe do dador
		DadorDetalhes dd = new DadorDetalhes();
		dd.setDador(d);
		dd.setAltura(alturadador);
		dd.setCodpostal(codpostaldador);
		dd.setEmail(emaildador);
		dd.setLocalidade(localidadedador);
		dd.setMorada(moradadador);
		dd.setMoradacont(moradacontdador);
		dd.setNif(nif);
		dd.setPeso(pesodador);
		dd.setTelefone(telefonedador);
		dd.setTelemovel(telemoveldador);
		dd.setEtnia(daoetnia.buscaPorId(etniadador));
		daodadordet.adiciona(dd);
		
		//buscar utilizadores com CHD ou IPST desse hospital
		List<Long> users = daouser.buscausershospitaldadorreferenciado(hospitaisuser);
		
		NotificationsController notificacao = new NotificationsController();
		JSONArray perfis = new JSONArray();
	/*	perfis.add("CHD");*/
		perfis.add("IPST");
/*		perfis.add("GCCT");
		perfis.add("EC");*/
		String msg = "Novo potencial dador no "+h.getNomeHospital()+" referenciado �s " +new SimpleDateFormat("HH:mm").format(calhoje.getTime());
	//	String msg = "Dador "+d.getCodigoDador()+" referenciado";
		notificacao.envianotificacao(users, 1, perfis, "", msg, d.getCodigoDador(), 2);
		
		return "true";
	}
}
