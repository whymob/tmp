package pt.iconic.ipst.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import pt.iconic.ipst.modelo.HistoricoAssignacao;;

@Repository
@Transactional
public class HistoricoAssignacaoDAO {

	@PersistenceContext
	private EntityManager manager;
	
	
	public void adiciona(HistoricoAssignacao historico){
		manager.persist(historico);	
	}
	
/*	public void atualiza(HistoricoAssignacao historico){
		manager.merge(historico);
	}*/
	

/*	@SuppressWarnings("unchecked")
	public List<HistoricoAssignacao> ListaHistoricoAssignacao(){
		return manager.createQuery("select a from HistoricoAssignacao a").getResultList();
	}*/
	
/*	public HistoricoAssignacao buscaPorId(Long id){
		return manager.find(HistoricoAssignacao.class, id);
	}
	
	
	public void remove(HistoricoAssignacao historico){
		HistoricoAssignacao historicoARemover = buscaPorId(historico.getIdhistorico());
		manager.remove(historicoARemover);
	}*/
	
	@SuppressWarnings("unchecked")
	public List<HistoricoAssignacao> ListaHistoricoAssignacaoDador(Long iddador){
		
		Query query = manager.createQuery("select h from HistoricoAssignacao h join h.dador d where d.id_Dador =:iddador ORDER BY h.datahistorico DESC");
		query.setParameter("iddador", iddador);
		
		List<HistoricoAssignacao> out = query.getResultList();
		
/*        int count = 0;  
        for (Iterator i = out.iterator(); i.hasNext();) {  
        	AssignacaoOrgaos values = (AssignacaoOrgaos) i.next();  
            System.out.println(++count + ": " + values.getDadoroferta().getId_Dador() + ", " + values.getOrgoferta().getIdorgoferta() + ", " + values.getStatusassignacao().getIdstatus() + "<br />");  
        } */
		return out;
	}
	
	public void InsereRegistosEstadoOrgaoHistoricoAssignacao(Long iddador, int id_estado_assig_hospital, Long idassigorg, int estadoavaliacaoorgao){
		
		String msg = "";
		
		if(estadoavaliacaoorgao==1){
			msg = "Org�o Validado";
		}else if (estadoavaliacaoorgao==2){
			msg = "Org�o Condicional";
		}else if(estadoavaliacaoorgao==3){
			msg = "Org�o Inv�lido";
			
		}
		
		Query query = manager.createNativeQuery("Insert into HISTORICO_ASSIGNACAO "
				+ "select GETDATE() as 'DATAHISTORICO', :msg as 'OBSERVACOES', ID_ASSIGNACAO_HOSPITAL, :iddador as 'ID_DADOR', :id_estado_assig_hospital AS 'ID_ESTADO_ASSIG' "
				+ "from ASSIGNACAO_HOSPITAL where ID_ASSIGNACAO_ORGAO = :idassigorg AND SELECCIONADO = 'True'");
			query.setParameter("msg", msg);
	        query.setParameter("iddador", iddador);
	        query.setParameter("id_estado_assig_hospital", id_estado_assig_hospital);
	        query.setParameter("idassigorg", idassigorg);
	        query.executeUpdate();
		
	}

	public void insereaceitacaoorgaohistorico(Long id_assigorg, Long id_Hospital, Long id_Dador, int id_estado_assig_hospital) {
		String msg = "";
		if(id_estado_assig_hospital==2){
			msg = "Org�o n�o aceite pelo Hospital";
		}else if(id_estado_assig_hospital==3){
			msg = "Org�o aceite pelo Hospital";
		}
		
		Query query = manager.createNativeQuery("Insert into HISTORICO_ASSIGNACAO "
				+ "select GETDATE() as 'DATAHISTORICO', :msg as 'OBSERVACOES', ID_ASSIGNACAO_HOSPITAL, :iddador as 'ID_DADOR', :id_estado_assig_hospital AS 'ID_ESTADO_ASSIG' "
				+ "from ASSIGNACAO_HOSPITAL where ID_ASSIGNACAO_ORGAO = :idassigorg AND ID_HOSPITAL= :idhospital");
			query.setParameter("msg", msg);
	        query.setParameter("iddador", id_Dador);
	        query.setParameter("id_estado_assig_hospital", id_estado_assig_hospital);
	        query.setParameter("idassigorg", id_assigorg);
	        query.setParameter("idhospital", id_Hospital);
	        query.executeUpdate();
	}
	
	public void insererejeicaohistoricoaposaceitacao(Long id_assigorg, Long id_Hospital, Long id_Dador) {
		String msg = "Org�o aceite por outro hospital: ";

		
		Query query = manager.createNativeQuery("Insert into HISTORICO_ASSIGNACAO "
				+ "select GETDATE() as 'DATAHISTORICO', :msg +(select d.NOMEHOSPITAL from HOSPITAL d where d.ID_HOSPITAL= :idhospital) as 'OBSERVACOES', ah.ID_ASSIGNACAO_HOSPITAL, :iddador as 'ID_DADOR', 7 AS 'ID_ESTADO_ASSIG' "
				+ "from ASSIGNACAO_HOSPITAL  ah "
				+ "inner join HOSPITAL h on(ah.ID_HOSPITAL = h.ID_HOSPITAL)"
				+ "where ah.ID_ASSIGNACAO_ORGAO = :idassigorg AND ah.ID_HOSPITAL<> :idhospital");
			query.setParameter("msg", msg);
	        query.setParameter("iddador", id_Dador);
	        query.setParameter("idassigorg", id_assigorg);
	        query.setParameter("idhospital", id_Hospital);
	        query.executeUpdate();
	}
	
}
