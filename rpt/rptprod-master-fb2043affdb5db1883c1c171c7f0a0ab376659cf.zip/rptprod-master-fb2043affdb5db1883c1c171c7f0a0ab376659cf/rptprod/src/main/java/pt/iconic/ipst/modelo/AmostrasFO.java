package pt.iconic.ipst.modelo;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;


@Entity
@Table(name = "AMOSTRASFO")
public class AmostrasFO {

	private Long id_amostrafo;
	private String nomeamostra;
	private List<AmostrasFuncoesOrgao> amostrasfo;
	private List<PPAnalisesRecetor> analiserecetor;
	private List<UnidadesAmostrasFO> unidadesAmostrasFO;
	private List<PPAnalisesFollowUp> analisefollowup;
	private List<TransplantePosOperatorioAnalises> analisetranspposop;
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="ID_AMOSTRAFO")
	public Long getId_amostrafo() {
		return id_amostrafo;
	}
	public void setId_amostrafo(Long id_amostrafo) {
		this.id_amostrafo = id_amostrafo;
	}
	
	@Column(name="NOMEAMOSTRA")
	public String getNomeamostra() {
		return nomeamostra;
	}
	public void setNomeamostra(String nomeamostra) {
		this.nomeamostra = nomeamostra;
	}
	
	@OneToMany(fetch = FetchType.LAZY, mappedBy = "amostra")
	public List<AmostrasFuncoesOrgao> getAmostrasfo() {
		return amostrasfo;
	}
	public void setAmostrasfo(List<AmostrasFuncoesOrgao> amostrasfo) {
		this.amostrasfo = amostrasfo;
	}
	
	@OneToMany(fetch = FetchType.EAGER, mappedBy = "amostraFO", cascade=CascadeType.REMOVE)
	public List<UnidadesAmostrasFO> getUnidadesAmostrasFO() {
		return unidadesAmostrasFO;
	}
	public void setUnidadesAmostrasFO(List<UnidadesAmostrasFO> unidadesAmostrasFO) {
		this.unidadesAmostrasFO = unidadesAmostrasFO;
	}
	
	@OneToMany(fetch = FetchType.LAZY, mappedBy = "amostra")
	public List<PPAnalisesRecetor> getAnaliserecetor() {
		return analiserecetor;
	}
	public void setAnaliserecetor(List<PPAnalisesRecetor> analiserecetor) {
		this.analiserecetor = analiserecetor;
	}
	
	@OneToMany(fetch = FetchType.LAZY, mappedBy = "amostra")
	public List<PPAnalisesFollowUp> getAnalisefollowup() {
		return analisefollowup;
	}
	public void setAnalisefollowup(List<PPAnalisesFollowUp> analisefollowup) {
		this.analisefollowup = analisefollowup;
	}
	
	@OneToMany(fetch = FetchType.LAZY, mappedBy = "analise")
	public List<TransplantePosOperatorioAnalises> getAnalisetranspposop() {
		return analisetranspposop;
	}
	public void setAnalisetranspposop(List<TransplantePosOperatorioAnalises> analisetranspposop) {
		this.analisetranspposop = analisetranspposop;
	}
	
	
}
