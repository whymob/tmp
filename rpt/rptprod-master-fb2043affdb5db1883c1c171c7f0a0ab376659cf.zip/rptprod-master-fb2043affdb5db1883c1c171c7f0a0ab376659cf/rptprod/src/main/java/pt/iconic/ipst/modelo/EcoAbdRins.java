package pt.iconic.ipst.modelo;

import java.util.Calendar;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name = "ECOABDRINS")
public class EcoAbdRins 
{
	private Long Id_Ecoabdrins;
	private Calendar DataEco;
	private boolean calculos;
	private boolean obstrucoes;
	private int comprimento;
	private int largura;
	private int espessura;
	private int morfologia;
	private boolean calculos2;
	private boolean obstrucoes2;
	private int comprimento2;
	private int largura2;
	private int espessura2;
	private int morfologia2;	
	private boolean Lesoes;
	private String notas;
	private AnaliseDador analiseDador;
	private boolean statusharmecorins;
	private Calendar datagravacao;
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="ID_ECOABDRINS")
	public Long getId_Ecoabdrins() {
		return Id_Ecoabdrins;
	}
	public void setId_Ecoabdrins(Long id_Ecoabdrins) {
		Id_Ecoabdrins = id_Ecoabdrins;
	}
	
	@Column(name="DATAECORINS")
	public Calendar getDataEco() {
		return DataEco;
	}
	public void setDataEco(Calendar dataEco) {
		DataEco = dataEco;
	}
	
	@Column(name="CALCULOS")
	public boolean isCalculos() {
		return calculos;
	}
	public void setCalculos(boolean calculos) {
		this.calculos = calculos;
	}
	
	@Column(name="OBSTRUCOES")
	public boolean isObstrucoes() {
		return obstrucoes;
	}
	public void setObstrucoes(boolean obstrucoes) {
		this.obstrucoes = obstrucoes;
	}
	
	@Column(name="LESOES")
	public boolean isLesoes() {
		return Lesoes;
	}
	public void setLesoes(boolean lesoes) {
		Lesoes = lesoes;
	}
	
	@Column(name="NOTAS")
	public String getNotas() {
		return notas;
	}
	public void setNotas(String notas) {
		this.notas = notas;
	}

	@OneToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="ID_ANALISEDADOR")
	public AnaliseDador getAnaliseDador() {
		return analiseDador;
	}
	public void setAnaliseDador(AnaliseDador analiseDador) {
		this.analiseDador = analiseDador;
	}
	
	@Column(name="COMPRIMENTO")
	public int getComprimento() {
		return comprimento;
	}
	public void setComprimento(int comprimento) {
		this.comprimento = comprimento;
	}
	
	@Column(name="LARGURA")
	public int getLargura() {
		return largura;
	}
	public void setLargura(int largura) {
		this.largura = largura;
	}
	
	@Column(name="ESPESSURA")
	public int getEspessura() {
		return espessura;
	}
	public void setEspessura(int espessura) {
		this.espessura = espessura;
	}
	
	@Column(name="MORFOLOGIA")
	public int getMorfologia() {
		return morfologia;
	}
	public void setMorfologia(int morfologia) {
		this.morfologia = morfologia;
	}
	
	@Column(name="CALCULOS2")
	public boolean isCalculos2() {
		return calculos2;
	}
	public void setCalculos2(boolean calculos2) {
		this.calculos2 = calculos2;
	}
	
	@Column(name="OBSTRUCOES2")
	public boolean isObstrucoes2() {
		return obstrucoes2;
	}
	public void setObstrucoes2(boolean obstrucoes2) {
		this.obstrucoes2 = obstrucoes2;
	}
	
	@Column(name="COMPRIMENTO2")
	public int getComprimento2() {
		return comprimento2;
	}
	public void setComprimento2(int comprimento2) {
		this.comprimento2 = comprimento2;
	}
	
	@Column(name="LARGURA2")
	public int getLargura2() {
		return largura2;
	}
	public void setLargura2(int largura2) {
		this.largura2 = largura2;
	}
	
	@Column(name="ESPESSURA2")
	public int getEspessura2() {
		return espessura2;
	}
	public void setEspessura2(int espessura2) {
		this.espessura2 = espessura2;
	}
	
	@Column(name="MORFOLOGIA2")
	public int getMorfologia2() {
		return morfologia2;
	}
	public void setMorfologia2(int morfologia2) {
		this.morfologia2 = morfologia2;
	}
	
	@Column(name="STATUSHARMONIO")
	public boolean isStatusharmecorins() {
		return statusharmecorins;
	}
	public void setStatusharmecorins(boolean statusharmecorins) {
		this.statusharmecorins = statusharmecorins;
	}	
	
	@Column(name="DATAGRAVACAO")
	public Calendar getDatagravacao() {
		return datagravacao;
	}

	public void setDatagravacao(Calendar datagravacao) {
		this.datagravacao = datagravacao;
	}
}