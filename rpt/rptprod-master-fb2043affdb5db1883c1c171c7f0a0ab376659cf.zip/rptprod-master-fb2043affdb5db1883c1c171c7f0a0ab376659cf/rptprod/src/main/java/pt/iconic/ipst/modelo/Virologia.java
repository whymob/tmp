package pt.iconic.ipst.modelo;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;


@Entity
@Table(name="VIROLOGIA")
public class Virologia {
	
	private Long id_virologia;
	private AnaliseDador analiseDador;
	private boolean prepostransfusao;
	private int hospradio;
	private float hospvalor;
	private String hospobs;
	private int cstradio;
	private float cstvalor;
	private String cstobs;
	private TipoVirologia tipoVirologia;
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="ID_VIROLOGIA")
	public Long getId_virologia() {
		return id_virologia;
	}
	public void setId_virologia(Long id_virologia) {
		this.id_virologia = id_virologia;
	}
	
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name="ID_ANALISEDADOR")
	public AnaliseDador getAnaliseDador() {
		return analiseDador;
	}
	public void setAnaliseDador(AnaliseDador analiseDador) {
		this.analiseDador = analiseDador;
	}
	
	@Column(name="PREPOSTRANSFUSAO")
	public boolean isPrepostransfusao() {
		return prepostransfusao;
	}
	public void setPrepostransfusao(boolean prepostransfusao) {
		this.prepostransfusao = prepostransfusao;
	}
	
    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "ID_TIPOVIROLOGIA")
	public TipoVirologia getTipoVirologia() {
		return tipoVirologia;
	}
	public void setTipoVirologia(TipoVirologia tipoVirologia) {
		this.tipoVirologia = tipoVirologia;
	}
	
	@Column(name="HOSPRADIO")
	public int getHospradio() {
		return hospradio;
	}
	public void setHospradio(int hospradio) {
		this.hospradio = hospradio;
	}
	
	@Column(name="HOSPVALOR")
	public float getHospvalor() {
		return hospvalor;
	}
	public void setHospvalor(float hospvalor) {
		this.hospvalor = hospvalor;
	}
	
	@Column(name="HOSPOBS")
	public String getHospobs() {
		return hospobs;
	}
	public void setHospobs(String hospobs) {
		this.hospobs = hospobs;
	}
	
	@Column(name="CSTRADIO")
	public int getCstradio() {
		return cstradio;
	}
	public void setCstradio(int cstradio) {
		this.cstradio = cstradio;
	}
	
	@Column(name="CSTVALOR")
	public float getCstvalor() {
		return cstvalor;
	}
	public void setCstvalor(float cstvalor) {
		this.cstvalor = cstvalor;
	}
	
	@Column(name="CSTOBS")
	public String getCstobs() {
		return cstobs;
	}
	public void setCstobs(String cstobs) {
		this.cstobs = cstobs;
	}
	
	
		
}
