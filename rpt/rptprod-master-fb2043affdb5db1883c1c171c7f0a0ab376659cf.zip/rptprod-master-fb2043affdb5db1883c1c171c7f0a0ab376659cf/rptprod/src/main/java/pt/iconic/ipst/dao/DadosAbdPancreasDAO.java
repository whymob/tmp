package pt.iconic.ipst.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import pt.iconic.ipst.modelo.AnaliseDador;
import pt.iconic.ipst.modelo.DadosAbdPancreas;

@Repository
@Transactional
public class DadosAbdPancreasDAO
{
	@PersistenceContext
	private EntityManager manager;
	
/*	public void adiciona(DadosAbdPancreas dadoseco){
		manager.persist(dadoseco);	
	}*/
	
	@Transactional
	public void atualiza(DadosAbdPancreas dadoseco){
		manager.merge(dadoseco);
	}

/*	@SuppressWarnings("unchecked")
	public List<DadosAbdPancreas> DadosAbdPancreas(){
		return manager.createQuery("select d from DadosAbdPancreas d").getResultList();
	}*/
	
	public DadosAbdPancreas buscaPorId(Long id){
		return manager.find(DadosAbdPancreas.class, id);
	}
	
	public void remove(DadosAbdPancreas dadoseco){
		DadosAbdPancreas lesoes = buscaPorId(dadoseco.getId_DadosAbdPancreas());
		manager.remove(lesoes);
	}
	
	//adiciona a lesao � tabela
	@Transactional
	public boolean adicionalesao(String tipo, String localizacao, String notas, Long id_analise)
	{
		AnaliseDador analise = manager.find(AnaliseDador.class, id_analise);
			
		DadosAbdPancreas lesoes = new DadosAbdPancreas();
		lesoes.setTipo(tipo);
		lesoes.setNotas(notas);
		lesoes.setLocalizacao(localizacao);
		lesoes.setAnaliseDador(analise);

		manager.persist(lesoes);
							
		return true;
	}
	
	//carrega as lesoes quando insere a ultima lesao para que as da ultima apare�am em cima
	@SuppressWarnings("unchecked")
	public List<DadosAbdPancreas> buscalesoesDescendente(Long idanalise)
	{		
		Query query = manager.createQuery("select a from DadosAbdPancreas a JOIN a.analiseDador an WHERE an.id_AnaliseDador =:idanalise");
		query.setParameter("idanalise", idanalise);
		
		List<DadosAbdPancreas> results = query.getResultList();

		return results;
	}
}