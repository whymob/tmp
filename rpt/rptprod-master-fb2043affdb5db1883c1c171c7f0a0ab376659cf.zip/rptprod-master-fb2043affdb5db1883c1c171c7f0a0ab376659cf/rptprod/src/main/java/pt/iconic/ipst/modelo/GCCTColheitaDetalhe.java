package pt.iconic.ipst.modelo;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name = "GCCTCOLHEITADETALHE")
public class GCCTColheitaDetalhe 
{
	private Long idgcctcolheitadetalhe;
	private String orgao;
	private String observacoes;
	private int estado;
	private GCCTColheita gcctcolheita;
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="ID_GCCTCOLHEITADETALHE")
	public Long getIdgcctcolheitadetalhe() {
		return idgcctcolheitadetalhe;
	}
	public void setIdgcctcolheitadetalhe(Long idgcctcolheitadetalhe) {
		this.idgcctcolheitadetalhe = idgcctcolheitadetalhe;
	}
	
	@Column(name="ORGAO")
	public String getOrgao() {
		return orgao;
	}
	public void setOrgao(String orgao) {
		this.orgao = orgao;
	}
	
	@Column(name="OBSERVACOES")
	public String getObservacoes() {
		return observacoes;
	}
	public void setObservacoes(String observacoes) {
		this.observacoes = observacoes;
	}

	@Column(name="ESTADO")
	public int getEstado() {
		return estado;
	}
	public void setEstado(int estado) {
		this.estado = estado;
	}
	
	@ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "ID_GCCTCOLHEITA")
	public GCCTColheita getGcctcolheita() {
		return gcctcolheita;
	}
	public void setGcctcolheita(GCCTColheita gcctcolheita) {
		this.gcctcolheita = gcctcolheita;
	}
}
