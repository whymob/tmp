package pt.iconic.ipst.dao;


import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import pt.iconic.ipst.modelo.Transfusoes;

@Repository
public class TransfusoesDAO {

	@PersistenceContext
	private EntityManager manager;
	
	@Transactional
	public void adiciona(Transfusoes transfusoes){
		manager.persist(transfusoes);	
	}
	
	@Transactional
	public void atualiza(Transfusoes transfusoes){
		manager.merge(transfusoes);
	}
	
/*	@SuppressWarnings("unchecked")
	public List<Transfusoes> ListaTransfusoes(){
		return manager.createQuery("select c from Transfusoes c").getResultList();
	}*/
	
	public Transfusoes buscaPorId(Long id){
		return manager.find(Transfusoes.class, id);
	}
	
	public void remove(Transfusoes transfusoes){
		Transfusoes transfusoesARemover = buscaPorId(transfusoes.getId_transfusao());
		manager.remove(transfusoesARemover);
	}
	
	@SuppressWarnings("unchecked")
	public List<Transfusoes> buscatransfusoesanalise(Long idanalise){
		Query query = manager.createQuery("select a from Transfusoes a JOIN a.analiseDador an  WHERE an.id_AnaliseDador =:idanalise");
		query.setParameter("idanalise", idanalise);
		
		List<Transfusoes> results = query.getResultList();
		
		return results;
	}
	

	public Long calculahemodiluicaoA(Long idanalise){
		
		Long Total;
		
		TypedQuery<Long> query = manager.createQuery("select SUM(a.volunidade) from Transfusoes a JOIN a.analiseDador an  JOIN a.nomeTransfusoes nome JOIN nome.tipoTransf tipo  WHERE an.id_AnaliseDador =:idanalise AND tipo.valor = 'A'",Long.class);
		query.setParameter("idanalise", idanalise);
		
		Long resultado = query.getSingleResult();
		
		if(resultado==null){
			Total = 0L;
		}
		else{
		Total = resultado.longValue();
		//System.out.println("Total: "+Total);
		}
		return Total;
	}

	public Long calculahemodiluicaoB(Long idanalise){
		
		Long Total;
		
		TypedQuery<Long> query = manager.createQuery("select SUM(a.volunidade) from Transfusoes a JOIN a.analiseDador an  JOIN a.nomeTransfusoes nome JOIN nome.tipoTransf tipo  WHERE an.id_AnaliseDador =:idanalise AND tipo.valor = 'B'",Long.class);
		query.setParameter("idanalise", idanalise);
		
		Long resultado = query.getSingleResult();
		
		if(resultado==null){
			Total = 0L;
		}
		else{
		Total = resultado.longValue();
	//	System.out.println("Total: "+Total);
		}
		return Total;
	}
	
	public Long calculahemodiluicaoC(Long idanalise){
		
		Long Total;
		
		TypedQuery<Long> query = manager.createQuery("select SUM(a.volunidade) from Transfusoes a JOIN a.analiseDador an  JOIN a.nomeTransfusoes nome JOIN nome.tipoTransf tipo  WHERE an.id_AnaliseDador =:idanalise AND tipo.valor = 'C'",Long.class);
		query.setParameter("idanalise", idanalise);
		
		Long resultado = query.getSingleResult();
		
		if(resultado==null){
			Total = 0L;
		}
		else{
		Total = resultado.longValue();
	//	System.out.println("Total: "+Total);
		}
		return Total;
	}
	
	public List<Float> buscaalbuminaproteinatransfusao(Long idanalise, Long tipoamostra){
		
		TypedQuery<Float> query = manager.createQuery("select a.valoramostra from AmostrasFuncoesOrgao a Join a.amostra b Join a.tipoAmostra tipo JOIN a.analiseDador an JOIN a.tipoAmostra t  WHERE (an.id_AnaliseDador =:idanalise and tipo.id_tipoamostra = :tipoamostra and b.nomeamostra = 'Albumina') or (an.id_AnaliseDador =:idanalise and tipo.id_tipoamostra = :tipoamostra and b.nomeamostra = 'Prote�nas Totais') ORDER BY b.nomeamostra",Float.class);
		query.setParameter("idanalise", idanalise);
		query.setParameter("tipoamostra", tipoamostra);
		
		List<Float> results = query.getResultList();
		
		
		
//		List<Integer> valores = new ArrayList<Integer>();
//		if(!results.isEmpty()){
//		    // ignores multiple results
//			valores.add(results.get(0));
//			valores.add(results.get(1));
//		}
		

	//	return valores;
		return results;
		
	}
	
}
