package pt.iconic.ipst.modelo;

import java.util.Calendar;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;



@Entity
@Table(name = "COLHEITA_FIGADO")
public class ColheitaFigado {

	private Long idcolheitafigado;
	private Calendar iniciofigado;
	private Calendar fimfigado;
	private int aspecto;
	private int consistencia;
	private int infiltrgorda;
	private int tamanho;
	private boolean morfonormal;
	private boolean morfobordorombo;
	private boolean morfodismorf;
	private String notasmorfo;
	private boolean artesqgasesq;
	private boolean dirmesentsup;
	private boolean heptroncceliaco;
	private boolean hepatcomum;
	private boolean hepatpropria;
	private boolean outras;
	private int patch;
	private String notas;
	private boolean vasosreconst;
	private int estadofigado;
	private AnaliseDador analiseDador;
	private String codfigado;
	private boolean critexpand;
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="ID_COLHEITA_FIGADO")
	public Long getIdcolheitafigado() {
		return idcolheitafigado;
	}
	public void setIdcolheitafigado(Long idcolheitafigado) {
		this.idcolheitafigado = idcolheitafigado;
	}
	
	@Column(name="INICIO")
	public Calendar getIniciofigado() {
		return iniciofigado;
	}
	public void setIniciofigado(Calendar iniciofigado) {
		this.iniciofigado = iniciofigado;
	}
	
	@Column(name="FIM")
	public Calendar getFimfigado() {
		return fimfigado;
	}
	public void setFimfigado(Calendar fimfigado) {
		this.fimfigado = fimfigado;
	}
	
	@Column(name="ASPECTO")
	public int getAspecto() {
		return aspecto;
	}
	public void setAspecto(int aspecto) {
		this.aspecto = aspecto;
	}
	
	@Column(name="CONSISTENCIA")
	public int getConsistencia() {
		return consistencia;
	}
	public void setConsistencia(int consistencia) {
		this.consistencia = consistencia;
	}
	
	@Column(name="INFILTRACAO_GORDA")
	public int getInfiltrgorda() {
		return infiltrgorda;
	}
	public void setInfiltrgorda(int infiltrgorda) {
		this.infiltrgorda = infiltrgorda;
	}
	
	@Column(name="TAMANHO")
	public int getTamanho() {
		return tamanho;
	}
	public void setTamanho(int tamanho) {
		this.tamanho = tamanho;
	}
	
	@Column(name="MORFO_NORMAL")
	public boolean isMorfonormal() {
		return morfonormal;
	}
	public void setMorfonormal(boolean morfonormal) {
		this.morfonormal = morfonormal;
	}
	
	@Column(name="MORFO_BORDO_ROMBO")
	public boolean isMorfobordorombo() {
		return morfobordorombo;
	}
	public void setMorfobordorombo(boolean morfobordorombo) {
		this.morfobordorombo = morfobordorombo;
	}
	
	@Column(name="MORFO_DISMORFIAS")
	public boolean isMorfodismorf() {
		return morfodismorf;
	}
	public void setMorfodismorf(boolean morfodismorf) {
		this.morfodismorf = morfodismorf;
	}
	
	@Column(name="NOTAS_MORFO")
	public String getNotasmorfo() {
		return notasmorfo;
	}
	public void setNotasmorfo(String notasmorfo) {
		this.notasmorfo = notasmorfo;
	}
	@Column(name="ARTERIAS_ESQ_GAS_ESQ")
	public boolean isArtesqgasesq() {
		return artesqgasesq;
	}
	public void setArtesqgasesq(boolean artesqgasesq) {
		this.artesqgasesq = artesqgasesq;
	}
	
	@Column(name="DIR_MESENT_SUPERIOR")
	public boolean isDirmesentsup() {
		return dirmesentsup;
	}
	public void setDirmesentsup(boolean dirmesentsup) {
		this.dirmesentsup = dirmesentsup;
	}
	
	@Column(name="HEP_TRONC_CELIACO")
	public boolean isHeptroncceliaco() {
		return heptroncceliaco;
	}
	public void setHeptroncceliaco(boolean heptroncceliaco) {
		this.heptroncceliaco = heptroncceliaco;
	}
	
	@Column(name="HEP_COMUM")
	public boolean isHepatcomum() {
		return hepatcomum;
	}
	public void setHepatcomum(boolean hepatcomum) {
		this.hepatcomum = hepatcomum;
	}
	
	@Column(name="HEP_PROPRIA")
	public boolean isHepatpropria() {
		return hepatpropria;
	}
	public void setHepatpropria(boolean hepatpropria) {
		this.hepatpropria = hepatpropria;
	}
	
	@Column(name="OUTRAS")
	public boolean isOutras() {
		return outras;
	}
	public void setOutras(boolean outras) {
		this.outras = outras;
	}
	
	@Column(name="PATCH")
	public int getPatch() {
		return patch;
	}
	public void setPatch(int patch) {
		this.patch = patch;
	}
	
	@Column(name="NOTAS")
	public String getNotas() {
		return notas;
	}
	public void setNotas(String notas) {
		this.notas = notas;
	}
	
	@Column(name="VASOS_RECONSTR")
	public boolean isVasosreconst() {
		return vasosreconst;
	}
	public void setVasosreconst(boolean vasosreconst) {
		this.vasosreconst = vasosreconst;
	}
	
	@Column(name="ESTADO_FIGADO")
	public int getEstadofigado() {
		return estadofigado;
	}
	public void setEstadofigado(int estadofigado) {
		this.estadofigado = estadofigado;
	}
	
	@OneToOne(fetch=FetchType.EAGER)
	@JoinColumn(name="ID_ANALISEDADOR")
	public AnaliseDador getAnaliseDador() {
		return analiseDador;
	}
	public void setAnaliseDador(AnaliseDador analiseDador) {
		this.analiseDador = analiseDador;
	}
	
	@Column(name="COD_FIGADO")
	public String getCodfigado() {
		return codfigado;
	}
	public void setCodfigado(String codfigado) {
		this.codfigado = codfigado;
	}
	
	@Column(name="CRITER_EXPAND")
	public boolean isCritexpand() {
		return critexpand;
	}
	public void setCritexpand(boolean critexpand) {
		this.critexpand = critexpand;
	}
	
}
