package pt.iconic.ipst.modelo;

import java.util.Calendar;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name = "PPULMONAR")
public class PPPulmonar 
{
	private Long id_pppulmonar;
	private AnaliseRecetor analiserecetor;
//	private double pesopulmonar;
//	private int alturapulmonar;
//	private Etnia etniapulmonar;
	private int transfusoespulmonar;
	private int gestacoespulmonar;
	private float imcpulmonar;
	private int pertoraxicopulmonar;
	private Calendar ulimatransfusaopulmonar;
//	private boolean hbpulmonar;
//	private boolean hcpulmonar;
//	private boolean rhpulmonar;
//	private int abopulmonar;
	private int diagnosticopulmonar;
	private String observacoespulmonar;
//	private boolean retransplantadopulmonar;
	private int classefunc;
	private int fev;
	private boolean colonizacao;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="ID_PPPULMONAR")
	public Long getId_pppulmonar() {
		return id_pppulmonar;
	}
	public void setId_pppulmonar(Long id_pppulmonar) {
		this.id_pppulmonar = id_pppulmonar;
	}
	
	@OneToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="ID_ANALISERECETOR")
	public AnaliseRecetor getAnaliserecetor() {
		return analiserecetor;
	}
	public void setAnaliserecetor(AnaliseRecetor analiserecetor) {
		this.analiserecetor = analiserecetor;
	}
	
//	@Column(name="PESO")
//	public double getPesopulmonar() {
//		return pesopulmonar;
//	}
//	public void setPesopulmonar(double pesopulmonar) {
//		this.pesopulmonar = pesopulmonar;
//	}
//	
//	@Column(name="ALTURA")
//	public int getAlturapulmonar() {
//		return alturapulmonar;
//	}
//	public void setAlturapulmonar(int alturapulmonar) {
//		this.alturapulmonar = alturapulmonar;
//	}
//
//	@OneToOne(fetch = FetchType.EAGER)
//    @JoinColumn(name = "ID_ETNIA")
//	public Etnia getEtniapulmonar() {
//		return etniapulmonar;
//	}
//	public void setEtniapulmonar(Etnia etniapulmonar) {
//		this.etniapulmonar = etniapulmonar;
//	}
	
	@Column(name="TRANSFUSOES")
	public int getTransfusoespulmonar() {
		return transfusoespulmonar;
	}
	public void setTransfusoespulmonar(int transfusoespulmonar) {
		this.transfusoespulmonar = transfusoespulmonar;
	}
	
	@Column(name="GESTACOES")
	public int getGestacoespulmonar() {
		return gestacoespulmonar;
	}
	public void setGestacoespulmonar(int gestacoespulmonar) {
		this.gestacoespulmonar = gestacoespulmonar;
	}
	
	@Column(name="IMC")
	public float getImcpulmonar() {
		return imcpulmonar;
	}
	public void setImcpulmonar(float imcpulmonar) {
		this.imcpulmonar = imcpulmonar;
	}
	
	@Column(name="PERTORAXICO")
	public int getPertoraxicopulmonar() {
		return pertoraxicopulmonar;
	}
	public void setPertoraxicopulmonar(int pertoraxicopulmonar) {
		this.pertoraxicopulmonar = pertoraxicopulmonar;
	}
	
	@Column(name="ULTIMATRANSFUSAO")
	public Calendar getUlimatransfusaopulmonar() {
		return ulimatransfusaopulmonar;
	}
	public void setUlimatransfusaopulmonar(Calendar ulimatransfusaopulmonar) {
		this.ulimatransfusaopulmonar = ulimatransfusaopulmonar;
	}
	
//	@Column(name="HB")
//	public boolean isHbpulmonar() {
//		return hbpulmonar;
//	}
//	public void setHbpulmonar(boolean hbpulmonar) {
//		this.hbpulmonar = hbpulmonar;
//	}
//	
//	@Column(name="HC")
//	public boolean isHcpulmonar() {
//		return hcpulmonar;
//	}
//	public void setHcpulmonar(boolean hcpulmonar) {
//		this.hcpulmonar = hcpulmonar;
//	}
	
//	@Column(name="RH")
//	public boolean isRhpulmonar() {
//		return rhpulmonar;
//	}
//	public void setRhpulmonar(boolean rhpulmonar) {
//		this.rhpulmonar = rhpulmonar;
//	}
//	
//	@Column(name="ABO")
//	public int getAbopulmonar() {
//		return abopulmonar;
//	}
//	public void setAbopulmonar(int abopulmonar) {
//		this.abopulmonar = abopulmonar;
//	}
	
	@Column(name="DIAGNOSTICO")
	public int getDiagnosticopulmonar() {
		return diagnosticopulmonar;
	}
	public void setDiagnosticopulmonar(int diagnosticopulmonar) {
		this.diagnosticopulmonar = diagnosticopulmonar;
	}
	
	@Column(name="OBSERVACOES")
	public String getObservacoespulmonar() {
		return observacoespulmonar;
	}
	public void setObservacoespulmonar(String observacoespulmonar) {
		this.observacoespulmonar = observacoespulmonar;
	}
	
	@Column(name="CLASSE_FUNCIONAL")
	public int getClassefunc() {
		return classefunc;
	}
	public void setClassefunc(int classefunc) {
		this.classefunc = classefunc;
	}
	
	@Column(name="FEV")
	public int getFev() {
		return fev;
	}
	public void setFev(int fev) {
		this.fev = fev;
	}
	
	@Column(name="COLONIZACAO")
	public boolean isColonizacao() {
		return colonizacao;
	}
	public void setColonizacao(boolean colonizacao) {
		this.colonizacao = colonizacao;
	}
	
//	@Column(name="RETRANSPLANTADO")
//	public boolean isRetransplantadopulmonar() {
//		return retransplantadopulmonar;
//	}
//	public void setRetransplantadopulmonar(boolean retransplantadopulmonar) {
//		this.retransplantadopulmonar = retransplantadopulmonar;
//	}
}