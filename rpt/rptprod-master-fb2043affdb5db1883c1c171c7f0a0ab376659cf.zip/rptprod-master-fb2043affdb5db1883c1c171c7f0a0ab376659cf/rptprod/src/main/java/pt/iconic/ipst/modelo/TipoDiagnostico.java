package pt.iconic.ipst.modelo;

import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name = "TIPODIAGNOSTICO")
public class TipoDiagnostico {

	private int idtipodiagnostico;
	private String descricao;
	private List<PPHepaticoDiagnostico> pphepaticodiagnostico;
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="ID_TIPODIAGNOSTICO")
	public int getIdtipodiagnostico() {
		return idtipodiagnostico;
	}
	public void setIdtipodiagnostico(int idtipodiagnostico) {
		this.idtipodiagnostico = idtipodiagnostico;
	}
	
	@Column(name="DESCRICAO")
	public String getDescricao() {
		return descricao;
	}
	public void setDescricao(String descricao) {
		this.descricao = descricao;
	}
	
	@OneToMany(fetch = FetchType.LAZY, mappedBy = "tipodiagnostico")
	public List<PPHepaticoDiagnostico> getPphepaticodiagnostico() {
		return pphepaticodiagnostico;
	}
	public void setPphepaticodiagnostico(
			List<PPHepaticoDiagnostico> pphepaticodiagnostico) {
		this.pphepaticodiagnostico = pphepaticodiagnostico;
	}
}
