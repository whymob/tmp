package pt.iconic.ipst.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import pt.iconic.ipst.modelo.AnaliseRecetor;

@Repository
public class AnaliseRecetorDAO 
{
	@PersistenceContext
	private EntityManager manager;
	
	@Transactional
	public void adiciona(AnaliseRecetor analiserecetor){
		manager.persist(analiserecetor);	
	}
	
/*	@Transactional
	public void atualiza(AnaliseRecetor analiserecetor){
		manager.merge(analiserecetor);
	}*/

/*	@SuppressWarnings("unchecked")
	public List<AnaliseRecetor> ListaAnaliseRecetor(){
		return manager.createQuery("select d from AnaliseRecetor d").getResultList();
	}*/
	
	public AnaliseRecetor buscaPorId(Long id){
		return manager.find(AnaliseRecetor.class, id);
	}
	
/*	public void remove(AnaliseRecetor analiserecetor){
		AnaliseRecetor analiserecetorrem = buscaPorId(analiserecetor.getId_analiserecetor());
		manager.remove(analiserecetorrem);
	}*/
	
	@SuppressWarnings("unchecked")
	public AnaliseRecetor buscaAnaliseRecetor(Long id){
		
		Query query = manager.createQuery("select a from AnaliseRecetor a JOIN a.recetor recetor WHERE recetor.id_recetor =:idrecetor");
		query.setParameter("idrecetor", id);
		
		List<AnaliseRecetor> results = query.getResultList();
		AnaliseRecetor analiserecetor = null;
		
		if(!results.isEmpty()){
			analiserecetor = (AnaliseRecetor) results.get(0);
		}
		return analiserecetor;
	}

	@SuppressWarnings("unchecked")
	public AnaliseRecetor buscaAnaliseRecetorAssigOrg(Long id_assignacao) {
		Query query = manager.createNativeQuery("select * from ANALISERECETOR ar where ar.ID_RECETOR = (select art.ID_RECETOR from ANALISE_RECETOR_TRANSPLANTE art where art.ID_ASSIGORG = :id_assignacao and art.ID_ESTADO_ANALISE_RECETOR = 3)", AnaliseRecetor.class);
		query.setParameter("id_assignacao", id_assignacao);
		
		List<AnaliseRecetor> results = query.getResultList();
		AnaliseRecetor analiserecetor = null;
		
		if(!results.isEmpty()){
			analiserecetor = (AnaliseRecetor) results.get(0);
		}
		return analiserecetor;
		
	}
}
