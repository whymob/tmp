package pt.iconic.ipst.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import pt.iconic.ipst.modelo.GasVent;



@Repository
public class GasVentDAO {

	
	@PersistenceContext
	private EntityManager manager;
	
	@Transactional
	public void adiciona(GasVent gasvent){
		manager.persist(gasvent);	
	}
	
	@Transactional
	public void atualiza(GasVent gasvent){
		manager.merge(gasvent);
	}
	

/*	@SuppressWarnings("unchecked")
	public List<GasVent> ListaGasVent(){
		return manager.createQuery("select c from GasVent c").getResultList();
	}*/
	
	public GasVent buscaPorId(Long id){
		return manager.find(GasVent.class, id);
	}
	
	
	public void remove(GasVent gasvent){
		GasVent gasventARemover = buscaPorId(gasvent.getId_gasvent());
		manager.remove(gasventARemover);
	}

	@SuppressWarnings("unchecked")
	public List<GasVent> ListaGasVentAnalise(Long idanalise) {
		Query query = manager.createQuery("select a from GasVent a JOIN a.analiseDador an WHERE an.id_AnaliseDador =:idanalise ");
		query.setParameter("idanalise", idanalise);
		List<GasVent> results = query.getResultList();

		return results;
	}
}
