package pt.iconic.ipst.modelo;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name = "SENSMICROORGANALISE")
public class SensMicroorganalise {

	
	private Long id_sensmicroorganalise;
	private Microrgmbanalisemb microrganismoanalise;
	private Sensibilidade sensibilidade;
//	private String SensDescricao;
	private boolean valorsens;
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="ID_SENSMICROORGANISMO")
	public Long getId_sensmicroorganalise() {
		return id_sensmicroorganalise;
	}
	public void setId_sensmicroorganalise(Long id_sensmicroorganalise) {
		this.id_sensmicroorganalise = id_sensmicroorganalise;
	}
	
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "ID_MICROORGANISMOANALISE")
	public Microrgmbanalisemb getMicrorganismoanalise() {
		return microrganismoanalise;
	}
	public void setMicrorganismoanalise(Microrgmbanalisemb microrganismoanalise) {
		this.microrganismoanalise = microrganismoanalise;
	}
	
    @OneToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "ID_SENSIBILIDADE")
	public Sensibilidade getSensibilidade() {
		return sensibilidade;
	}
	public void setSensibilidade(Sensibilidade sensibilidade) {
		this.sensibilidade = sensibilidade;
	}
//	@NotNull
//	@Column(name="SENSDESCRICAO")
//	public String getSensDescricao() {
//		return SensDescricao;
//	}
//	public void setSensDescricao(String sensDescricao) {
//		SensDescricao = sensDescricao;
//	}
	
	@Column(name="VALORSENS")
	public boolean isValorsens() {
		return valorsens;
	}
	public void setValorsens(boolean valorsens) {
		this.valorsens = valorsens;
	}
	
}
