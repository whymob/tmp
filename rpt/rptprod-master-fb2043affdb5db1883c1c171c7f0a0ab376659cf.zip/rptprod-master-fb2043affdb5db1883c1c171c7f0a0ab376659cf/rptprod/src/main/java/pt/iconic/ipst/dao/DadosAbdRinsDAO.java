package pt.iconic.ipst.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import pt.iconic.ipst.modelo.AnaliseDador;
import pt.iconic.ipst.modelo.DadosAbdRins;

@Repository
@Transactional
public class DadosAbdRinsDAO 
{
	@PersistenceContext
	private EntityManager manager;
	
/*	public void adiciona(DadosAbdRins dadoseco){
		manager.persist(dadoseco);	
	}*/
	
	@Transactional
	public void atualiza(DadosAbdRins dadoseco){
		manager.merge(dadoseco);
	}

/*	@SuppressWarnings("unchecked")
	public List<DadosAbdRins> DadosAbdRins(){
		return manager.createQuery("select d from DadosAbdRins d").getResultList();
	}*/
	
	public DadosAbdRins buscaPorId(Long id){
		return manager.find(DadosAbdRins.class, id);
	}
	
	public void remove(DadosAbdRins dadoseco){
		DadosAbdRins lesoes = buscaPorId(dadoseco.getId_DadosAbdRins());
		manager.remove(lesoes);
	}
	
	//adiciona a lesao � tabela
	@Transactional
	public boolean adicionalesao(String tipo, String localizacao, String notas, Long id_analise)
	{
		AnaliseDador analise = manager.find(AnaliseDador.class, id_analise);
			
		DadosAbdRins lesoes = new DadosAbdRins();
		lesoes.setTipo(tipo);
		lesoes.setNotas(notas);
		lesoes.setLocalizacao(localizacao);
		lesoes.setAnaliseDador(analise);

		manager.persist(lesoes);
						
		return true;
	}
	
	//carrega as lesoes quando insere a ultima lesao para que as da ultima apare�am em cima
	@SuppressWarnings("unchecked")
	public List<DadosAbdRins> buscalesoesDescendente(Long idanalise)
	{		
		Query query = manager.createQuery("select a from DadosAbdRins a JOIN a.analiseDador an WHERE an.id_AnaliseDador =:idanalise");
		query.setParameter("idanalise", idanalise);
		
		List<DadosAbdRins> results = query.getResultList();

		return results;
	}
}