package pt.iconic.ipst.modelo;

import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name = "STATUS_ASSIGNACAO_ORGAOS")
public class StatusAssignacaoOrgaos {
	
	private int idstatus;
	private String status;
	private List<AssignacaoOrgaos> assignacaoorg;
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="ID_STATUS")
	public int getIdstatus() {
		return idstatus;
	}
	public void setIdstatus(int idstatus) {
		this.idstatus = idstatus;
	}
	
	@Column(name="STATUS")
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	
	@OneToMany(fetch = FetchType.LAZY, mappedBy = "statusassignacao")
	public List<AssignacaoOrgaos> getAssignacaoorg() {
		return assignacaoorg;
	}
	public void setAssignacaoorg(List<AssignacaoOrgaos> assignacaoorg) {
		this.assignacaoorg = assignacaoorg;
	}
	
	

}
