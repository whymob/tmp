package pt.iconic.ipst.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import pt.iconic.ipst.modelo.Eletrocardiograma;

@Repository
@Transactional
public class EletrocardiogramaDAO 
{
	@PersistenceContext
	private EntityManager manager;
	
	public void adiciona(Eletrocardiograma eletro){
		manager.persist(eletro);	
	}
	
	public void atualiza(Eletrocardiograma eletro){
		manager.merge(eletro);
	}


	@SuppressWarnings("rawtypes")
	public Eletrocardiograma ListaEletrocardiograma(Long id)
	{
		Query query = manager.createQuery("select e from Eletrocardiograma e JOIN e.analiseDador analisedador WHERE analisedador.id_AnaliseDador =:idanalise");
		query.setParameter("idanalise", id);

		List results = query.getResultList();
		Eletrocardiograma eletro = null;
		
		if(!results.isEmpty())
		{
			eletro = (Eletrocardiograma) results.get(0);
		}
		
		return eletro;
	}

	public Eletrocardiograma buscaPorId(Long id){
		return manager.find(Eletrocardiograma.class, id);
	}
	
/*	public void remove(Eletrocardiograma eletro){
		Eletrocardiograma eletrocardiograma = buscaPorId(eletro.getId_Eletrocardiograma());
		manager.remove(eletrocardiograma);
	}*/
}