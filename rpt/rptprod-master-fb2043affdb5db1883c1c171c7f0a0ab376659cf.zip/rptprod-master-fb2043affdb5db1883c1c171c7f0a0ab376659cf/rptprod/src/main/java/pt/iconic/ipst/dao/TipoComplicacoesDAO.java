package pt.iconic.ipst.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import pt.iconic.ipst.modelo.TipoComplicacoes;

@Repository
@Transactional
public class TipoComplicacoesDAO {

	@PersistenceContext
	private EntityManager manager;
	
	
	public void adiciona(TipoComplicacoes tipocompl){
		manager.persist(tipocompl);	
	}
	
	public void atualiza(TipoComplicacoes tipocompl){
		manager.merge(tipocompl);
	}
	

	@SuppressWarnings("unchecked")
	public List<TipoComplicacoes> ListaTipoComplicacoes(){
		return manager.createQuery("select c from TipoComplicacoes c").getResultList();
	}
	
	public TipoComplicacoes buscaPorId(int id){
		return manager.find(TipoComplicacoes.class, id);
	}
	
	
	public void remove(TipoComplicacoes tipocompl){
		TipoComplicacoes tipocomplARemover = buscaPorId(tipocompl.getIdtipocomplicacao());
		manager.remove(tipocomplARemover);
	}
	
	public boolean trataadicionar(String desc)
	{
		Query query = manager.createQuery("SELECT t FROM TipoComplicacoes t WHERE t.descricao =:desc");
		query.setParameter("desc", desc);
		
		if(query.getResultList().isEmpty())
		{
			TipoComplicacoes tipocompl = new TipoComplicacoes();
			tipocompl.setDescricao(desc);
			adiciona(tipocompl);
			
			return true;
		}
		else
		{
			return false;
		}
	}
	
	public boolean trataalterar(int id, String desc)
	{
		TipoComplicacoes tipocompl = new TipoComplicacoes();
		tipocompl.setIdtipocomplicacao(id);
		tipocompl.setDescricao(desc);
		atualiza(tipocompl);
			
		return true;
	}
	
	public boolean remover(int id)
	{
		TipoComplicacoes tipocompl = buscaPorId(id);
		
		remove(tipocompl);
		return true;
	}
}
