package pt.iconic.ipst.dao;


import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import pt.iconic.ipst.modelo.AnaliseRecetor;
import pt.iconic.ipst.modelo.GravidadeOrgao;
import pt.iconic.ipst.modelo.Recetores;
import pt.iconic.ipst.modelo.TipoComplicacoes;
import pt.iconic.ipst.modelo.TipoDiagnostico;

@Repository
@Transactional
public class RecetoresDAO 
{
	@PersistenceContext
	private EntityManager manager;
	
	public void adiciona(Recetores recetor){
		manager.persist(recetor);	
	}
	
	public void atualiza(Recetores recetor){
		manager.merge(recetor);
	}
	
/*	@SuppressWarnings("unchecked")
	public List<Recetores> ListaRecetores(){
		return manager.createQuery("select d from Recetores d").getResultList();
	}*/
	
	public Recetores buscaPorId(Long id){
		return manager.find(Recetores.class, id);
	}
	
/*	public void remove(Recetores recetor){
		Recetores recetorrem = buscaPorId(recetor.getId_recetor());
		manager.remove(recetorrem);
	}*/
	
	
	@SuppressWarnings("unchecked")
	public List<Recetores> buscarecetoreshospital(Long idhosp)
	{		
		
		Query query = manager.createNativeQuery("select distinct RECETOR.ID_RECETOR, RECETOR.CODIGORECETOR, RECETOR.NOMERECETOR, RECETOR.DATAREGISTO, ORGAOS_OFERTA.NOME_ORGAO,"
				+ " (select top 1 estadorecetor.estado from estadorecetor where estadorecetor.id_analiserecetor = ANALISERECETOR.ID_ANALISERECETOR order by estadorecetor.ID_ESTADORECETOR desc) as Estado, "
				+ "(select top 1 GRAVIDADEORGAO.GRAVIDADE from GRAVIDADEORGAO where GRAVIDADEORGAO.ID_GRAVIDADEORGAO = "
				+ "(select top 1 GRAVIDADERECETOR.ID_GRAVIDADEORGAO "
				+ "from GRAVIDADERECETOR where GRAVIDADERECETOR.ID_ANALISERECETOR = ANALISERECETOR.ID_ANALISERECETOR order by GRAVIDADERECETOR.ID_GRAVIDADERECETOR desc)) as Gravidade"
				+ " from RECETOR "
				+ "left join ANALISERECETOR on (ANALISERECETOR.ID_RECETOR = RECETOR.ID_RECETOR) "
				+ "left join UNIDADETRANSPLANTE on (RECETOR.ID_UNIDADETRANSP = UNIDADETRANSPLANTE.ID_UNIDADETRANSP) "
				+ "left join ORGAOS_OFERTA on (ORGAOS_OFERTA.ID_ORGAO_OFERTA = RECETOR.ID_ORGAO) "
				+ "left join GRAVIDADERECETOR on (GRAVIDADERECETOR.ID_ANALISERECETOR = ANALISERECETOR.ID_ANALISERECETOR) "
				+ "WHERE RECETOR.ID_HOSPITAL = :idhosp"); 
		query.setParameter("idhosp", idhosp);

		List<Recetores> results = query.getResultList();

		return results;
	}
	
/*	@SuppressWarnings("unchecked")
	public List<Recetores> buscarecetorestransplantados(Long idhosp)
	{		
		Query query = manager.createQuery("select a from Recetores a JOIN a.hospital hosp WHERE hosp.id_Hospital =:idhosp");
		query.setParameter("idhosp", idhosp);
		
		List<Recetores> results = query.getResultList();

		return results;
	}*/
	
	
	public int buscaidorgaorecetor(Long idrec)
	{		
	//	Query query = manager.createQuery("select org.idorgoferta from OrgaosOferta org JOIN org.unidadetransp un JOIN un.recetor rec WHERE rec.id_recetor =:idrec");
		Query query = manager.createQuery("select org.idorgoferta from Recetores rec JOIN rec.orgao org WHERE rec.id_recetor =:idrec");
		query.setParameter("idrec", idrec);
		
		return (int) query.getSingleResult();
	}
	
	public boolean verificainscricoeshospitais(int idorgao, int sns)
	{
		Query query = manager.createNativeQuery("select count(*) from RECETOR "
				+ "left join UNIDADETRANSPLANTE on (RECETOR.ID_UNIDADETRANSP = UNIDADETRANSPLANTE.ID_UNIDADETRANSP) "
				+ "left join ORGAOS_OFERTA on (ORGAOS_OFERTA.ID_UNIDADE_TRANSP = UNIDADETRANSPLANTE.ID_UNIDADETRANSP) "
				+ " WHERE ORGAOS_OFERTA.ID_ORGAO_OFERTA =:idorgao and RECETOR.SNS =:sns");
		query.setParameter("idorgao", idorgao);
		query.setParameter("sns", sns);
		
		int inscricoes = (int) query.getSingleResult();
		
		if(inscricoes >= 2)
		{
			return true;
		}
		else
			return false;
	}
	
	public boolean verificainscricoes(Long idhosp, int idorgao, int sns)
	{

		Query query = manager.createNativeQuery("select count(*) from RECETOR "
				+ "left join UNIDADETRANSPLANTE on (RECETOR.ID_UNIDADETRANSP = UNIDADETRANSPLANTE.ID_UNIDADETRANSP) "
				+ "left join ORGAOS_OFERTA on (ORGAOS_OFERTA.ID_UNIDADE_TRANSP = UNIDADETRANSPLANTE.ID_UNIDADETRANSP)  "
				+ " WHERE RECETOR.ID_HOSPITAL =:idhosp and ORGAOS_OFERTA.ID_ORGAO_OFERTA = :idorgao and RECETOR.SNS =:sns");
		query.setParameter("idhosp", idhosp);
		query.setParameter("idorgao", idorgao);
		query.setParameter("sns", sns);
		
		int inscricoes = (int) query.getSingleResult();

		if(inscricoes >= 1)
			return true;
		else
			return false;
	}
	
	public boolean pesquisahistorico(Long idhosp, String idorgao, int sns)
	{
		Query query = manager.createNativeQuery("select count(*) from RECETOR "
				//+ "left join UNIDADETRANSPLANTE on (RECETOR.ID_UNIDADETRANSP = UNIDADETRANSPLANTE.ID_UNIDADETRANSP) "
				//+ "left join ORGAOS on (ORGAOS.ID_UNIDADETRANSP = UNIDADETRANSPLANTE.ID_UNIDADETRANSP) "
				+ "inner join ORGAOS_OFERTA on (ORGAOS_OFERTA.ID_ORGAO_OFERTA= RECETOR.ID_ORGAO) "
				+ "WHERE RECETOR.ID_HOSPITAL <>:idhosp and ORGAOS_OFERTA.NOME_ORGAO LIKE :idorgao and RECETOR.SNS =:sns");
		query.setParameter("idhosp", idhosp);
		query.setParameter("idorgao", idorgao);
		query.setParameter("sns", sns);
		
		int inscricoes = (int) query.getSingleResult();

		if(inscricoes == 1)
			return true;
		else
			return false;
	}
	
	@SuppressWarnings("rawtypes")
	public String listaHistorico(Long idhosp, String idorgao, int sns)
	{		
		Query query = manager.createNativeQuery("select TOP 1 gor.GRAVIDADE from RECETOR "
				+ "inner join ANALISERECETOR on (ANALISERECETOR.ID_RECETOR = RECETOR.ID_RECETOR) "
				+ "inner join GRAVIDADERECETOR gr on (gr.ID_ANALISERECETOR = ANALISERECETOR.ID_ANALISERECETOR) "
				+ "inner join GRAVIDADEORGAO gor on (gor.ID_GRAVIDADEORGAO = gr.ID_GRAVIDADEORGAO) "
				+ "WHERE RECETOR.ID_HOSPITAL <>:idhosp and RECETOR.SNS =:sns AND gr.DATAGRAVIDADE = (select MAX(gr.DATAGRAVIDADE) from RECETOR "
				+ "inner join ANALISERECETOR on (ANALISERECETOR.ID_RECETOR = RECETOR.ID_RECETOR) "
				+ "inner join GRAVIDADERECETOR gr on (gr.ID_ANALISERECETOR = ANALISERECETOR.ID_ANALISERECETOR) "
				+ "inner join GRAVIDADEORGAO gor on (gor.ID_GRAVIDADEORGAO = gr.ID_GRAVIDADEORGAO) WHERE RECETOR.ID_HOSPITAL <>:idhosp AND RECETOR.SNS =:sns) "
				+ "ORDER BY gr.ID_GRAVIDADERECETOR DESC");
		query.setParameter("idhosp", idhosp);
		query.setParameter("sns", sns);

		List results = query.getResultList();
		String resultado = "";
		if(!results.isEmpty()){
			resultado = results.get(0).toString();
		}
		
		return resultado;
	}
	
	public String listaHistoricodata(Long idhosp, String idorgao, int sns)
	{		
		Query query = manager.createNativeQuery("select RECETOR.DATAREGISTO from RECETOR "
/*				+ "left join UNIDADETRANSPLANTE on (RECETOR.ID_UNIDADETRANSP = UNIDADETRANSPLANTE.ID_UNIDADETRANSP) "
				+ "left join ORGAOS on (ORGAOS.ID_UNIDADETRANSP = UNIDADETRANSPLANTE.ID_UNIDADETRANSP) "*/
				+ "inner join ORGAOS_OFERTA on (ORGAOS_OFERTA.ID_ORGAO_OFERTA= RECETOR.ID_ORGAO) "
				+ "WHERE RECETOR.ID_HOSPITAL <>:idhosp and ORGAOS_OFERTA.NOME_ORGAO LIKE :idorgao and RECETOR.SNS =:sns");
				
		query.setParameter("idhosp", idhosp);
		query.setParameter("idorgao", idorgao);
		query.setParameter("sns", sns);

		return query.getSingleResult().toString();
	}
	
	public String listaHistoricounidade(Long idhosp, int sns, Long idrecetor, String orgao, Long idhospital)
	{		
		Query query = manager.createNativeQuery("select distinct HOSPITAL.NOMEHOSPITAL + ' - ' + UNIDADETRANSPLANTE.NOME from RECETOR "
				+ "left join UNIDADETRANSPLANTE on (RECETOR.ID_UNIDADETRANSP = UNIDADETRANSPLANTE.ID_UNIDADETRANSP) "
				+ "left join HOSPITAL on (HOSPITAL.ID_HOSPITAL = RECETOR.ID_HOSPITAL) "
				+ "	where HOSPITAL.ID_HOSPITAL <> :idhospital AND RECETOR.ID_RECETOR IN (select distinct RECETOR.ID_RECETOR from RECETOR"
				+ "	inner join ORGAOS_OFERTA on (ORGAOS_OFERTA.ID_ORGAO_OFERTA= RECETOR.ID_ORGAO) "
				+ "	where ORGAOS_OFERTA.NOME_ORGAO LIKE :orgao and RECETOR.ID_RECETOR <>:idrecetor and RECETOR.SNS =:sns)");
		query.setParameter("sns", sns);
		query.setParameter("idrecetor", idrecetor);
		query.setParameter("orgao", orgao);
		query.setParameter("idhospital", idhospital);
		
		return query.getSingleResult().toString();
	}
	
	public boolean verificaestado(Long idhosp)
	{		
		Query query = manager.createNativeQuery("select COUNT(ESTADORECETOR.ID_ESTADORECETOR) from estadorecetor, RECETOR, ANALISERECETOR where estadorecetor.ID_ANALISERECETOR = ANALISERECETOR.ID_ANALISERECETOR and ESTADORECETOR.ESTADO = 4 and ANALISERECETOR.ID_RECETOR = RECETOR.ID_RECETOR and ESTADORECETOR.ID_ANALISERECETOR = ANALISERECETOR.ID_ANALISERECETOR and RECETOR.ID_HOSPITAL =:idhosp");
		query.setParameter("idhosp", idhosp);
		
		int estado = (int) query.getSingleResult();

		if(estado >= 1)
			return true;
		else
			return false;
	}

	@SuppressWarnings({ "unchecked" })
	public List<Object> buscacandidatosorgaohospital(Long idunidadetransplante, Long idhosp, Long idassigorg, int idorgaooferta) {
				
		Query query = manager.createNativeQuery("select r.ID_RECETOR, r.SNS, r.NOMERECETOR, rd.ABO, rd.RH, (select gro.GRAVIDADE from GRAVIDADEORGAO gro inner join GRAVIDADERECETOR gr on (gr.ID_GRAVIDADEORGAO = gro.ID_GRAVIDADEORGAO) "
				+ "right join ANALISERECETOR ar on (ar.ID_ANALISERECETOR = gr.ID_ANALISERECETOR) "
				+ "right join RECETOR re on (re.ID_RECETOR = ar.ID_RECETOR) "
				+ "where re.ID_RECETOR = r.ID_RECETOR AND "
				+ "gr.ID_GRAVIDADERECETOR = (select MAX(gr.ID_GRAVIDADERECETOR) "
				+ "from GRAVIDADEORGAO gro inner join GRAVIDADERECETOR gr on (gr.ID_GRAVIDADEORGAO = gro.ID_GRAVIDADEORGAO)	"
				+ "right join ANALISERECETOR on (ANALISERECETOR.ID_ANALISERECETOR = gr.ID_ANALISERECETOR) "
				+ "right join RECETOR on (RECETOR.ID_RECETOR = r.ID_RECETOR))) AS GRAVIDADE, "
				+ "rd.PESO, "
				+ "DATEDIFF(YEAR,rd.DATANASCIMENTORECETOR,GETDATE())-(CASE WHEN DATEADD(YY,DATEDIFF(YEAR,rd.DATANASCIMENTORECETOR,GETDATE()),rd.DATANASCIMENTORECETOR) > GETDATE() THEN 1 ELSE 0 END) AS IDADE,	"
				+ "Case When (select COUNT(DISTINCT(rec.ID_UNIDADETRANSP)) from RECETOR rec where rec.SNS = r.SNS)>1 Then 'SIM' ELSE 'N�O' END AS MULTIORGAOS, 0, '' AS ID_ESTADO_ANALISE , '' AS ID_ANALISE_RECETOR_TRANSP "
				+ "from RECETOR r "
				+ "inner join RECETORDETALHES rd on (rd.ID_RECETOR = r.ID_RECETOR) "
				+ "inner join HOSPITAL h on (h.ID_HOSPITAL = r.ID_HOSPITAL) "
				+ "inner join UNIDADETRANSPLANTE ut on (ut.ID_UNIDADETRANSP = r.ID_UNIDADETRANSP) "
				+ "where h.ID_HOSPITAL = :idhosp AND ut.ID_UNIDADETRANSP = :idunidadetransplante and r.ID_ORGAO = :idorgaooferta and r.ID_RECETOR not in "
				+ "(select art.ID_RECETOR from ANALISE_RECETOR_TRANSPLANTE art where art.ID_ASSIGORG = :idassigorg OR art.ID_ESTADO_ANALISE_RECETOR = 3)"
				+ "UNION "
				+ "select r.ID_RECETOR, r.SNS, r.NOMERECETOR, rd.ABO, rd.RH, "
				+ "(select gro.GRAVIDADE from GRAVIDADEORGAO gro inner join GRAVIDADERECETOR gr on (gr.ID_GRAVIDADEORGAO = gro.ID_GRAVIDADEORGAO) "
				+ "right join ANALISERECETOR ar on (ar.ID_ANALISERECETOR = gr.ID_ANALISERECETOR) "
				+ "right join RECETOR re on (re.ID_RECETOR = ar.ID_RECETOR) "
				+ "where re.ID_RECETOR = r.ID_RECETOR AND "
				+ "gr.ID_GRAVIDADERECETOR = (select MAX(gr.ID_GRAVIDADERECETOR) "
				+ "from GRAVIDADEORGAO gro inner join GRAVIDADERECETOR gr on (gr.ID_GRAVIDADEORGAO = gro.ID_GRAVIDADEORGAO)	"
				+ "right join ANALISERECETOR on (ANALISERECETOR.ID_ANALISERECETOR = gr.ID_ANALISERECETOR) "
				+ "right join RECETOR on (RECETOR.ID_RECETOR = r.ID_RECETOR))) AS GRAVIDADE, "
				+ "rd.PESO, "
				+ "DATEDIFF(YEAR,rd.DATANASCIMENTORECETOR,GETDATE())-(CASE WHEN DATEADD(YY,DATEDIFF(YEAR,rd.DATANASCIMENTORECETOR,GETDATE()),rd.DATANASCIMENTORECETOR) > GETDATE() THEN 1 ELSE 0 END) AS IDADE,	"
				+ "Case When (select COUNT(DISTINCT(rec.ID_UNIDADETRANSP)) from RECETOR rec where rec.SNS = r.SNS)>1 Then 'SIM' ELSE 'N�O' END AS MULTIORGAOS, art.POSICAO, ear.ID_ESTADO_ANALISE , art.ID_ANALISE_RECETOR_TRANSP "
				+ "from RECETOR r "
				+ "left join ANALISE_RECETOR_TRANSPLANTE art on (r.ID_RECETOR = art.ID_RECETOR) "
				+ "left join ESTADO_ANALISE_RECETOR ear on (ear.ID_ESTADO_ANALISE = art.ID_ESTADO_ANALISE_RECETOR) "
				+ "inner join RECETORDETALHES rd on (rd.ID_RECETOR = r.ID_RECETOR) "
				+ "inner join HOSPITAL h on (h.ID_HOSPITAL = r.ID_HOSPITAL) "
				+ "inner join UNIDADETRANSPLANTE ut on (ut.ID_UNIDADETRANSP = r.ID_UNIDADETRANSP) "
				+ "where art.ID_ASSIGORG = :idassigorg and r.ID_HOSPITAL = :idhosp and art.ID_RECETOR not in (select a.ID_RECETOR from ANALISE_RECETOR_TRANSPLANTE a where a.ID_ESTADO_ANALISE_RECETOR = 3 and a.ID_ASSIGORG <> :idassigorg)");

		
		query.setParameter("idhosp", idhosp);
		query.setParameter("idunidadetransplante", idunidadetransplante);
		query.setParameter("idassigorg", idassigorg);
		query.setParameter("idorgaooferta", idorgaooferta);
		List<Object> results = query.getResultList();
		

		return results;
	}

	@SuppressWarnings("rawtypes")
	public GravidadeOrgao buscagravidaderecetor(Long idrecetor) {
		
		Query query = manager.createNativeQuery("select gro.* "
				+ "from GRAVIDADEORGAO gro "
				+ "inner join GRAVIDADERECETOR gr on (gr.ID_GRAVIDADEORGAO = gro.ID_GRAVIDADEORGAO) "
				+ "where gr.ID_GRAVIDADERECETOR = ( "
				+ "select MAX(gr.ID_GRAVIDADERECETOR) "
				+ "from GRAVIDADERECETOR gr "
				+ "right join ANALISERECETOR on (ANALISERECETOR.ID_ANALISERECETOR = gr.ID_ANALISERECETOR) "
				+ "right join RECETOR on (RECETOR.ID_RECETOR = ANALISERECETOR.ID_RECETOR) "
				+ "where RECETOR.ID_RECETOR = :idrecetor)", GravidadeOrgao.class);
		
		query.setParameter("idrecetor", idrecetor);
		
		List results = query.getResultList();
		GravidadeOrgao gravidade = null;
		if(!results.isEmpty()){
			gravidade = (GravidadeOrgao) results.get(0);
		}
		return gravidade;
	}

	@SuppressWarnings({ "unchecked" })
	public List<TipoDiagnostico> buscadiagnosticohepatico(Long idanaliserec) {
		
		Query query = manager.createNativeQuery("select td.* "
				+ "From PPHEPATICODIAGNOSTICO diag "
				+ "inner join TIPODIAGNOSTICO td on (td.ID_TIPODIAGNOSTICO = diag.ID_TIPODIAGNOSTICO) "
				+ "where diag.ID_ANALISERECETOR = :idanaliserec and diag.ESC = 'True'", TipoDiagnostico.class);
		
		query.setParameter("idanaliserec", idanaliserec);
		
		List<TipoDiagnostico> results = query.getResultList();
		
		if((results.isEmpty())){
			TipoDiagnostico tipo = new TipoDiagnostico();
			tipo.setDescricao("Sem complica��es");
			results.add(tipo);
			
		}
		
		
		return results;
	}

	@SuppressWarnings({ "unchecked" })
	public List<TipoComplicacoes> buscacomplicacaohepatico(Long idanaliserec) {
		
		Query query = manager.createNativeQuery("select tc.* "
				+ "From PPHEPATICOCOMPLICACOES compl "
				+ "inner join TIPOCOMPLICACOES tc on (tc.ID_TIPOCOMPLICACAO = compl.ID_TIPOCOMPLICACAO) "
				+ "where compl.ID_ANALISERECETOR = :idanaliserec and compl.ESC = 'True'", TipoComplicacoes.class);
		
		query.setParameter("idanaliserec", idanaliserec);
		
		List<TipoComplicacoes> results = query.getResultList();
	
		if((results.isEmpty())){
			TipoComplicacoes tipo = new TipoComplicacoes();
			tipo.setDescricao("Sem complica��es");
			results.add(tipo);
			
		}
		
		return results;
	}
	
/*	public void atualizarestantescandidatosespera(Long idassigorg, Long idrecetor) {
		

		Query query = manager.createNativeQuery("UPDATE ART "
				+ "SET ART.ID_ESTADO_ANALISE_RECETOR = 1 "
				+ "FROM ANALISE_RECETOR_TRANSPLANTE ART "
				+ "where ART.ID_ASSIGORG = :idassigorg AND ART.ID_RECETOR <> :idrecetor");
		query.setParameter("idassigorg", idassigorg);
		query.setParameter("idrecetor", idrecetor);
		query.executeUpdate();
		
	}*/

	@SuppressWarnings({ "unchecked" })
	public List<AnaliseRecetor> atualizainscricoestransplantado(int snsrec, Long unidadetr, int estado) {
		
		//Inserir novo estado transplantado em todos as inscri��es para esse org�o
		
		Query query = manager.createNativeQuery("select ar.* "
				+ "from RECETOR r "
				+ "inner join ANALISERECETOR ar on (ar.ID_RECETOR = r.ID_RECETOR) "
				+ "where r.SNS = :snsrec and r.ID_UNIDADETRANSP = :unidadetr ", AnaliseRecetor.class);
		query.setParameter("snsrec", snsrec);
		query.setParameter("unidadetr", unidadetr);
		
		List<AnaliseRecetor> out = query.getResultList();
		return out;		
		
	}

}
