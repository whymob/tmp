package pt.iconic.ipst.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import pt.iconic.ipst.modelo.UtilizadorB;


@Repository
public class UtilizadorBDAO {

	
	
	@PersistenceContext
	private EntityManager manager;
	
	@Transactional
	public void adiciona(UtilizadorB utilizador){
		manager.persist(utilizador);	
	}
	
	@Transactional
	public void atualiza(UtilizadorB utilizador){
		manager.merge(utilizador);
	}
	

	@SuppressWarnings("unchecked")
	public List<UtilizadorB> Lista(){
		return manager.createQuery("select u from UtilizadorB u").getResultList();
	}
	
	public UtilizadorB buscaPorId(Long id){
		return manager.find(UtilizadorB.class, id);
	}
	
	
/*	public void remove(UtilizadorB utilizador){
		UtilizadorB utilizadorARemover = buscaPorId(utilizador.getId_UtilizadorB());
		manager.remove(utilizadorARemover);
	}*/

	public boolean existeUtilizador(UtilizadorB utilizador) {


			Query query = manager.createQuery("SELECT u FROM UtilizadorB u WHERE u.codigoOM =:codigoOM AND u.pin =:pin");
			query.setParameter("codigoOM", utilizador.getCodigoOM());
			query.setParameter("pin", utilizador.getPin());
			if(query.getResultList().isEmpty()){
//				System.out.println("N�o existe utilizador");
				return false;
			}else{
//				System.out.println("Existe utilizador");
				return true;
			}

	}
	
	public boolean existeUtilizadoremail(String email) {

		Query query = manager.createQuery("SELECT u FROM UtilizadorB u WHERE u.email =:email");
		query.setParameter("email", email) ;
		if(query.getResultList().isEmpty()){
			//System.out.println("N�o existe utilizador");
			return false;
		}else{
			//System.out.println("Existe utilizador");
			return true;
		}


	}
	
	public boolean existeUtilizadorLogin(int codigoOM) {

		Query query = manager.createQuery("SELECT u FROM UtilizadorB u WHERE u.codigoOM =:codigoOM");
		query.setParameter("codigoOM", codigoOM) ;
		if(query.getResultList().isEmpty()){
			//System.out.println("N�o existe utilizador");
			return false;
		}else{
			//System.out.println("Existe utilizador");
			return true;
		}


	}
	
	public boolean existeUtilizadorcodigoUUIDB(String codigo) {

		Query query = manager.createQuery("SELECT u FROM UtilizadorB u WHERE u.codigoUUID =:codigo");
		query.setParameter("codigo", codigo) ;
		if(query.getResultList().isEmpty()){
			//System.out.println("N�o existe utilizador");
			return false;
		}else{
			//System.out.println("Existe utilizador");
			return true;
		}


	}
	
	public UtilizadorB buscaPorLogin(int codigoOM){
		
		Query query = manager.createQuery("select u from UtilizadorB u WHERE u.codigoOM =:codigoOM");
		query.setParameter("codigoOM", codigoOM) ;
		
		return (UtilizadorB) query.getSingleResult();
	}
	
	public UtilizadorB buscaPorCodigo(String codigo){
		
		Query query = manager.createQuery("select u from UtilizadorB u WHERE u.codigoUUID =:codigo");
		query.setParameter("codigo", codigo) ;
		
		return (UtilizadorB) query.getSingleResult();
	}
	
	public Long buscaIdUserB(UtilizadorB utilizadorb){

		String query = "select u.id_UtilizadorB from UtilizadorB u WHERE u.codigoOM =:codigoOM";
		TypedQuery<Long> query2 = manager.createQuery(query,Long.class);
		query2.setParameter("codigoOM", utilizadorb.getCodigoOM());
		Long id = query2.getSingleResult().longValue();	
		
		return id;
	}
	
	public String buscaNomeUserB(UtilizadorB utilizadorb){
		String out = "";
		Query query = manager.createQuery("select u.nome from UtilizadorB u WHERE u.pin =:pin And u.codigoOM =:codigoOM");
		query.setParameter("pin", utilizadorb.getPin());
		query.setParameter("codigoOM", utilizadorb.getCodigoOM());		
		out = query.getSingleResult().toString();
		//System.out.println("O resultado do query �: "+out);
		return out;
	}
	
	public int CalculaVidasSalvasReferenciadorB(Long id_utilizadorb){
		
		Query query = manager.createNativeQuery("select count(r.ID_RECETOR) "
				+ "from DADOR d "
				+ "inner join ASSIGNACAO_ORGAOS ao on (ao.ID_DADOR = d.ID_DADOR) "
				+ "inner join ANALISE_RECETOR_TRANSPLANTE art on (art.ID_ASSIGORG = ao.ID_ASSIGNACAO_ORGAOS) "
				+ "inner join RECETOR r on (r.ID_RECETOR = art.ID_RECETOR) "
				+ "left join TRANSPLANTE_CORACAO tc on (tc.ID_ASSIGNACAO_ORGAOS = art.ID_ASSIGORG) "
				+ "left join TRANSPLANTE_FIGADO tf on (tf.ID_ASSIGNACAO_ORGAOS = art.ID_ASSIGORG) "
				+ "left join TRANSPLANTE_PANCREAS tp on (tp.ID_ASSIGNACAO_ORGAOS = art.ID_ASSIGORG) "
				+ "left join TRANSPLANTE_PULMOES tpu on (tpu.ID_ASSIGNACAO_ORGAOS = art.ID_ASSIGORG) "
				+ "left join TRANSPLANTE_PULMOES tr on (tr.ID_ASSIGNACAO_ORGAOS = art.ID_ASSIGORG) "
				+ "where d.ID_UTILIZADORB =:id_utilizadorb and art.ID_ESTADO_ANALISE_RECETOR = 3 and "
				+ "(tc.ESTADO = 1 OR (tf.ESTADO = 1 OR tf.ESTADO = 2) OR (tp.ESTADO = 1 OR tp.ESTADO = 2) "
				+ "OR (tpu.ESTADO = 1) OR (tr.ESTADO = 1 OR tr.ESTADO = 2))");
		query.setParameter("id_utilizadorb", id_utilizadorb);
		int num =  (int) query.getSingleResult();
		
		return num;
	}
	
	@SuppressWarnings("unchecked")
	public List<Object> CarregadadoresreferenciadosorgaostransplantadosB(Long id_utilizadorb){
		
		Query query = manager.createNativeQuery("select d.CODIGODADOR, d.DATAREGISTO, oo.NOME_ORGAO "
				+ "from DADOR d "
				+ "inner join ASSIGNACAO_ORGAOS ao on (ao.ID_DADOR = d.ID_DADOR) "
				+ "inner join ORGAOS_OFERTA oo on (ao.ID_ORGAOOFERTA = oo.ID_ORGAO_OFERTA) "
				+ "left join ANALISE_RECETOR_TRANSPLANTE art on (art.ID_ASSIGORG = ao.ID_ASSIGNACAO_ORGAOS) "
				+ "left join RECETOR r on (r.ID_RECETOR = art.ID_RECETOR) "
				+ "left join TRANSPLANTE_CORACAO tc on (tc.ID_ASSIGNACAO_ORGAOS = art.ID_ASSIGORG) "
				+ "left join TRANSPLANTE_FIGADO tf on (tf.ID_ASSIGNACAO_ORGAOS = art.ID_ASSIGORG) "
				+ "left join TRANSPLANTE_PANCREAS tp on (tp.ID_ASSIGNACAO_ORGAOS = art.ID_ASSIGORG) "
				+ "left join TRANSPLANTE_PULMOES tpu on (tpu.ID_ASSIGNACAO_ORGAOS = art.ID_ASSIGORG) "
				+ "left join TRANSPLANTE_PULMOES tr on (tr.ID_ASSIGNACAO_ORGAOS = art.ID_ASSIGORG) "
				+ "where d.ID_UTILIZADORB = :id_utilizadorb "
				+ "and art.ID_ESTADO_ANALISE_RECETOR = 3 "
				+ "and (tc.ESTADO = 1 OR (tf.ESTADO = 1 OR tf.ESTADO = 2) OR (tp.ESTADO = 1 OR tp.ESTADO = 2) "
				+ "OR (tpu.ESTADO = 1) OR (tr.ESTADO = 1 OR tr.ESTADO = 2))");
		query.setParameter("id_utilizadorb", id_utilizadorb);
		List<Object> out = query.getResultList();
		return out;
	}	
	
}
