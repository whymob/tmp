package pt.iconic.ipst.modelo;

import java.util.Calendar;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;


@Entity
@Table(name = "COLHEITA_PANCREAS")
public class ColheitaPancreas {

	
	private Long idcolheitapancreas;
	private Calendar iniciopancreas;
	private Calendar fimpancreas;
	private int cor;
	private int consist1;
	private int consist2;
	private boolean infiltrapancreatica;
	private boolean infiltraextrapancreatica;
	private int descontaminduodenal;
	private int anomalvasculares;
	private String notasanomalvasculares;
	private int outrasanomal;
	private String notasoutrasanomal;
	private String notas;
	private String pdri;
	private String pass;
	private boolean critexpand;
	private int estadopancreas;
	private AnaliseDador analiseDador;
	private String codpancreas;
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="ID_COLHEITA_PANCREAS")
	public Long getIdcolheitapancreas() {
		return idcolheitapancreas;
	}
	public void setIdcolheitapancreas(Long idcolheitapancreas) {
		this.idcolheitapancreas = idcolheitapancreas;
	}
	
	@Column(name="INICIO")
	public Calendar getIniciopancreas() {
		return iniciopancreas;
	}
	public void setIniciopancreas(Calendar iniciopancreas) {
		this.iniciopancreas = iniciopancreas;
	}
	
	@Column(name="FIM")
	public Calendar getFimpancreas() {
		return fimpancreas;
	}
	public void setFimpancreas(Calendar fimpancreas) {
		this.fimpancreas = fimpancreas;
	}
	
	@Column(name="COR")
	public int getCor() {
		return cor;
	}
	public void setCor(int cor) {
		this.cor = cor;
	}
	
	@Column(name="CONSISTENCIA1")
	public int getConsist1() {
		return consist1;
	}
	public void setConsist1(int consist1) {
		this.consist1 = consist1;
	}
	
	@Column(name="CONSISTENCIA2")
	public int getConsist2() {
		return consist2;
	}
	public void setConsist2(int consist2) {
		this.consist2 = consist2;
	}
	
	@Column(name="INFILTRACAO_PANCR")
	public boolean isInfiltrapancreatica() {
		return infiltrapancreatica;
	}
	public void setInfiltrapancreatica(boolean infiltrapancreatica) {
		this.infiltrapancreatica = infiltrapancreatica;
	}
	
	@Column(name="INFILTRACAO_EXTRA_PANCR")
	public boolean isInfiltraextrapancreatica() {
		return infiltraextrapancreatica;
	}
	public void setInfiltraextrapancreatica(boolean infiltraextrapancreatica) {
		this.infiltraextrapancreatica = infiltraextrapancreatica;
	}
	
	@Column(name="DESCONTAMINACAO_DUODENAL")
	public int getDescontaminduodenal() {
		return descontaminduodenal;
	}
	public void setDescontaminduodenal(int descontaminduodenal) {
		this.descontaminduodenal = descontaminduodenal;
	}
	
	@Column(name="ANOMALIAS_VASCULARES")
	public int getAnomalvasculares() {
		return anomalvasculares;
	}
	public void setAnomalvasculares(int anomalvasculares) {
		this.anomalvasculares = anomalvasculares;
	}
	
	@Column(name="NOTAS_ANOMALVASCULARES")
	public String getNotasanomalvasculares() {
		return notasanomalvasculares;
	}
	public void setNotasanomalvasculares(String notasanomalvasculares) {
		this.notasanomalvasculares = notasanomalvasculares;
	}
	
	@Column(name="OUTRAS_ANOMALIAS")
	public int getOutrasanomal() {
		return outrasanomal;
	}
	public void setOutrasanomal(int outrasanomal) {
		this.outrasanomal = outrasanomal;
	}
	
	@Column(name="NOTAS_OUTR_ANOMAL")
	public String getNotasoutrasanomal() {
		return notasoutrasanomal;
	}
	public void setNotasoutrasanomal(String notasoutrasanomal) {
		this.notasoutrasanomal = notasoutrasanomal;
	}
	
	@Column(name="NOTAS")
	public String getNotas() {
		return notas;
	}
	public void setNotas(String notas) {
		this.notas = notas;
	}
	
	@Column(name="PDRI")
	public String getPdri() {
		return pdri;
	}
	public void setPdri(String pdri) {
		this.pdri = pdri;
	}
	
	@Column(name="PASS")
	public String getPass() {
		return pass;
	}
	public void setPass(String pass) {
		this.pass = pass;
	}
	
	@Column(name="CRITER_EXPAND")
	public boolean isCritexpand() {
		return critexpand;
	}
	public void setCritexpand(boolean critexpand) {
		this.critexpand = critexpand;
	}
	
	@Column(name="ESTADO_PANCREAS")
	public int getEstadopancreas() {
		return estadopancreas;
	}
	public void setEstadopancreas(int estadopancreas) {
		this.estadopancreas = estadopancreas;
	}
	
	@OneToOne(fetch=FetchType.EAGER)
	@JoinColumn(name="ID_ANALISEDADOR")
	public AnaliseDador getAnaliseDador() {
		return analiseDador;
	}
	public void setAnaliseDador(AnaliseDador analiseDador) {
		this.analiseDador = analiseDador;
	}
	
	@Column(name="COD_PANCREAS")
	public String getCodpancreas() {
		return codpancreas;
	}
	public void setCodpancreas(String codpancreas) {
		this.codpancreas = codpancreas;
	}
	
	
}
