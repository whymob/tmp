package pt.iconic.ipst.modelo;

import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name="TIPOTRANSFUSOES")
public class TipoTransfusoes {

	private Long id_tipotransfusoes;
	private String valor;
	private List<NomeTransfusoes> transfusoes;
	
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="ID_TIPOTRANSFUSOES")
	public Long getId_tipotransfusoes() {
		return id_tipotransfusoes;
	}
	public void setId_tipotransfusoes(Long id_tipotransfusoes) {
		this.id_tipotransfusoes = id_tipotransfusoes;
	}
	
	@Column(name="VALOR")
	public String getValor() {
		return valor;
	}
	public void setValor(String valor) {
		this.valor = valor;
	}
	
	@OneToMany(fetch = FetchType.LAZY, mappedBy = "tipoTransf")
	public List<NomeTransfusoes> getTransfusoes() {
		return transfusoes;
	}
	public void setTransfusoes(List<NomeTransfusoes> transfusoes) {
		this.transfusoes = transfusoes;
	}

	
}
