package pt.iconic.ipst.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import pt.iconic.ipst.modelo.Etnia;;

@Repository
@Transactional
public class EtniaDAO {

	@PersistenceContext
	private EntityManager manager;
	
	public void adiciona(Etnia etnia){
		manager.persist(etnia);	
	}
	
	@Transactional
	public void atualiza(Etnia etnia){
		manager.merge(etnia);
	}
	
	@SuppressWarnings("unchecked")
	public List<Etnia> ListaEtnia(){
		return manager.createQuery("select e from Etnia e").getResultList();
	}
	
	public Etnia buscaPorId(Long id){
		return manager.find(Etnia.class, id);
	}

	public void remove(Etnia etnia)
	{
		Etnia etniaARemover = buscaPorId(etnia.getId_Etnia());
		manager.remove(etniaARemover);
	}
	
	public boolean trataadicionar(String desc)
	{
		Query query = manager.createQuery("SELECT e FROM Etnia e WHERE e.etnia =:desc");
		query.setParameter("desc", desc);
		
		if(query.getResultList().isEmpty())
		{
			Etnia etnia = new Etnia();
			etnia.setEtnia(desc);
			adiciona(etnia);
			
			return true;
		}
		else
		{
			return false;
		}
	}
	
	public boolean trataalterar(Long id, String desc)
	{
		Etnia etnia = new Etnia();
		etnia.setId_Etnia(id);
		etnia.setEtnia(desc);
		atualiza(etnia);
			
		return true;
	}
	
	public boolean remover(Long id)
	{
		Etnia etnia = new Etnia();
		etnia = buscaPorId(id);
		
		remove(etnia);
		return true;
	}
}