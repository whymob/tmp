package pt.iconic.ipst.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import pt.iconic.ipst.modelo.HCExameFisico;



@Repository
public class HCExameFisicoDAO {

	
	@PersistenceContext
	private EntityManager manager;
	
	public void adiciona(HCExameFisico examefisico){
		manager.persist(examefisico);	
	}
	
	@Transactional
	public void atualiza(HCExameFisico examefisico){
		manager.merge(examefisico);
	}
	
/*	@SuppressWarnings("unchecked")
	public List<HCExameFisico> ListaHCExameFisico(){
		return manager.createQuery("select e from HCExameFisico e").getResultList();
	}
	
	public HCExameFisico buscaPorId(Long id){
		return manager.find(HCExameFisico.class, id);
	}

	public void remove(HCExameFisico examefisico)
	{
		HCExameFisico examefisicoARemover = buscaPorId(examefisico.getId_exameFisico());
		manager.remove(examefisicoARemover);
	}*/
	
	@SuppressWarnings("unchecked")
	public HCExameFisico buscaexamefisico(Long idanalise){
		
		Query query = manager.createQuery("select b from HCExameFisico b JOIN b.analisedador a WHERE a.id_AnaliseDador =:idanalise");
		query.setParameter("idanalise", idanalise);
		
		List<HCExameFisico> results = query.getResultList();
		HCExameFisico exame = null;
		if(!results.isEmpty()){
			exame = (HCExameFisico) results.get(0);
		}
		return exame;
		
	}
	
}
