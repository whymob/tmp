package pt.iconic.ipst.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import pt.iconic.ipst.modelo.MedicamentosFollowUp;

@Repository
@Transactional
public class MedicamentosFollowUpDAO {

	@PersistenceContext
	private EntityManager manager;
	
	public void adiciona(MedicamentosFollowUp med){
		manager.persist(med);	
	}
	
	public void atualiza(MedicamentosFollowUp med){
		manager.merge(med);
	}

/*	@SuppressWarnings("unchecked")
	public List<MedicamentosFollowUp> ListaMedicamentosFollowUp(){
		return manager.createQuery("select d from MedicamentosFollowUp d").getResultList();
	}*/
	
	public MedicamentosFollowUp buscaPorId(Long id){
		return manager.find(MedicamentosFollowUp.class, id);
	}
	
	public void remove(MedicamentosFollowUp med){
		MedicamentosFollowUp medrem = buscaPorId(med.getIdmedicamento());
		manager.remove(medrem);
	}

	@SuppressWarnings("unchecked")
	public List<MedicamentosFollowUp> buscamedicamentosmarcacaofollowup(Long id_followup) {
	
		Query query = manager.createQuery("select a from MedicamentosFollowUp a JOIN a.marcacao marc WHERE marc.id_followup =:id_followup", MedicamentosFollowUp.class);
		query.setParameter("id_followup", id_followup);
		
		List<MedicamentosFollowUp> results = query.getResultList();

		return results;
	}
}
