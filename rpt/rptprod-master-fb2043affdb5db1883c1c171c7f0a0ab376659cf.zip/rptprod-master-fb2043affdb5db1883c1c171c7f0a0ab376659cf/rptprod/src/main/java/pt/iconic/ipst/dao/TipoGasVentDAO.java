package pt.iconic.ipst.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import pt.iconic.ipst.modelo.TipoGasVent;
import pt.iconic.ipst.modelo.UnidadesGeral;

@Repository
@Transactional
public class TipoGasVentDAO 
{	
	@PersistenceContext
	private EntityManager manager;
	
	
	public void adiciona(TipoGasVent tipogasvent){
		manager.persist(tipogasvent);	
	}
	
	public void atualiza(TipoGasVent tipogasvent){
		manager.merge(tipogasvent);
	}
	

	@SuppressWarnings("unchecked")
	public List<TipoGasVent> ListaTipoGasVent(){
		return manager.createQuery("select t from TipoGasVent t").getResultList();
	}
	
	public TipoGasVent buscaPorId(Long id){
		return manager.find(TipoGasVent.class, id);
	}
	
	
	public void remove(TipoGasVent tipogasvent){
		TipoGasVent tipogasventARemover = buscaPorId(tipogasvent.getId_tipogasvent());
		manager.remove(tipogasventARemover);
	}
	
	public boolean trataadicionar(String desc, Long combo)
	{
		Query query = manager.createQuery("SELECT t FROM TipoGasVent t WHERE t.desctipogasvent =:desc");
		query.setParameter("desc", desc);
		
		if(query.getResultList().isEmpty())
		{
			
			UnidadesGeral unid = manager.find(UnidadesGeral.class, combo);
			
			TipoGasVent gasi = new TipoGasVent();
			gasi.setDesctipogasvent(desc);
			gasi.setUnidades(unid);
			adiciona(gasi);
			
			return true;
		}
		else
		{
			return false;
		}
	}
	
	public boolean trataalterar(Long id, String desc, Long combo)
	{
		if(combo!=0){
		UnidadesGeral unid = new UnidadesGeral();
		unid.setId_unidades(combo);
		
		TipoGasVent gasi = new TipoGasVent();
		gasi.setId_tipogasvent(id);
		gasi.setDesctipogasvent(desc);
		gasi.setUnidades(unid);
		atualiza(gasi);
		
		return true;
		}	else
		{
//			UnidadesGeral unid = new UnidadesGeral();
//			unid.setId_unidades(combo);
			
			TipoGasVent gasi = new TipoGasVent();
			gasi.setId_tipogasvent(id);
			gasi.setDesctipogasvent(desc);
		//	gasi.setUnidades(unid);
			atualiza(gasi);
			
			return true;	
		}
	}
	
	public boolean remover(Long id)
	{
		TipoGasVent gasi = new TipoGasVent();
		gasi = buscaPorId(id);
		remove(gasi);
			
		return true;
	}
}
