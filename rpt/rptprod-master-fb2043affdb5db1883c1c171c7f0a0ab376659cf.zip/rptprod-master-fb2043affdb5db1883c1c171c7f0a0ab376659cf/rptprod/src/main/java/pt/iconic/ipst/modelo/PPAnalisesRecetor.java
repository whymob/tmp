package pt.iconic.ipst.modelo;

import java.util.Calendar;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name = "PPANALISERECETOR")
public class PPAnalisesRecetor 
{
	
	private Long id_analiserecetor;
//	private TipoAmostraFO tipoAmostra; //Basal, Amostra2, Amostra3, Amostra4
	private AmostrasFO amostra; //nome das amostras
	private float valoramostra;
	private UnidadesGeral unidades;
	private Calendar datahora;
	private String observamostras;
	private AnaliseRecetor analiserecetor;
	

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "ID_PPANALISERECETOR")
	public Long getId_analiserecetor() {
		return id_analiserecetor;
	}
	public void setId_analiserecetor(Long id_analiserecetor) {
		this.id_analiserecetor = id_analiserecetor;
	}
	
//    @ManyToOne(fetch = FetchType.EAGER)
//    @JoinColumn(name = "ID_TIPOAMOSTRA")
//	public TipoAmostraFO getTipoAmostra() {
//		return tipoAmostra;
//	}
//	public void setTipoAmostra(TipoAmostraFO tipoAmostra) {
//		this.tipoAmostra = tipoAmostra;
//	}
	
    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "ID_AMOSTRA")
	public AmostrasFO getAmostra() {
		return amostra;
	}
	public void setAmostra(AmostrasFO amostra) {
		this.amostra = amostra;
	}
	
	@Column(name="VALORAMOSTRA")
	public float getValoramostra() {
		return valoramostra;
	}
	public void setValoramostra(float valoramostra) {
		this.valoramostra = valoramostra;
	}
	
    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "ID_UNIDADES")
	public UnidadesGeral getUnidades() {
		return unidades;
	}
	public void setUnidades(UnidadesGeral unidades) {
		this.unidades = unidades;
	}
	
	@Column(name = "DATAANALISE")
	public Calendar getDatahora() {
		return datahora;
	}
	public void setDatahora(Calendar datahora) {
		this.datahora = datahora;
	}
	
	@Column(name="OBSERVAMOSTRAS")
	public String getObservamostras() {
		return observamostras;
	}
	public void setObservamostras(String observamostras) {
		this.observamostras = observamostras;
	}
	
	@ManyToOne
	@JoinColumn(name="ID_ANALISERECETOR")
	public AnaliseRecetor getAnaliserecetor() {
		return analiserecetor;
	}
	public void setAnaliserecetor(AnaliseRecetor analiserecetor) {
		this.analiserecetor = analiserecetor;
	}

	
	
	
	
//	private Long id_analiserecetor;
//	private Calendar dataanalise;
//	private String analise;
//	private int valor;
//	private String unidade;
//	private String observacoes;
//	private AnaliseRecetor analiserecetor;
//	
//	@Id
//	@GeneratedValue(strategy = GenerationType.IDENTITY)
//	@Column(name = "ID_PPANALISERECETOR")
//	public Long getId_analiserecetor() {
//		return id_analiserecetor;
//	}
//	public void setId_analiserecetor(Long id_analiserecetor) {
//		this.id_analiserecetor = id_analiserecetor;
//	}
//	
//	@Column(name = "DATAANALISE")
//	public Calendar getDataanalise() {
//		return dataanalise;
//	}
//	public void setDataanalise(Calendar dataanalise) {
//		this.dataanalise = dataanalise;
//	}
//	
//	@Column(name = "ANALISE")
//	public String getAnalise() {
//		return analise;
//	}
//	public void setAnalise(String analise) {
//		this.analise = analise;
//	}
//	
//	@Column(name = "VALOR")
//	public int getValor() {
//		return valor;
//	}
//	public void setValor(int valor) {
//		this.valor = valor;
//	}
//	
//	@Column(name = "UNIDADE")
//	public String getUnidade() {
//		return unidade;
//	}
//	
//	public void setUnidade(String unidade) {
//		this.unidade = unidade;
//	}
//	
//	@Column(name = "OBSERVACOES")
//	public String getObservacoes() {
//		return observacoes;
//	}
//	public void setObservacoes(String observacoes) {
//		this.observacoes = observacoes;
//	}
//	
//	@ManyToOne(fetch = FetchType.LAZY)
//	@JoinColumn(name="ID_ANALISERECETOR")
//	public AnaliseRecetor getAnaliserecetor() {
//		return analiserecetor;
//	}
//	public void setAnaliserecetor(AnaliseRecetor analiserecetor) {
//		this.analiserecetor = analiserecetor;
//	}
}