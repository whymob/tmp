package pt.iconic.ipst.dao;


import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import pt.iconic.ipst.modelo.UnidadesGeral;

@Repository
@Transactional
public class UnidadesDAO {

	@PersistenceContext
	private EntityManager manager;
	
	public void adiciona(UnidadesGeral unidades){
		manager.persist(unidades);	
	}
	
	public void atualiza(UnidadesGeral unidades){
		manager.merge(unidades);
	}

	public UnidadesGeral buscaPorId(Long id){
		return manager.find(UnidadesGeral.class, id);
	}
	
	public void remove(UnidadesGeral unidades){
		UnidadesGeral unidadesaremover = buscaPorId(unidades.getId_unidades());
		manager.remove(unidadesaremover);
	}
	


	@SuppressWarnings("unchecked")
	public List<UnidadesGeral> ListaUnidadesGeral()
	{

			return manager.createQuery("select u from UnidadesGeral u").getResultList();

	}

	@SuppressWarnings("unchecked")
	public List<UnidadesGeral> loadunidadesterapeutica(Long id_tipoterapeutica) {
		Query query = manager.createQuery("select u from UnidadesGeral u JOIN u.tipoTerapeuticas tipo WHERE tipo.id_TipoTerapeuticas = :id_tipo");
		query.setParameter("id_tipo", id_tipoterapeutica);
		
		List<UnidadesGeral> results = query.getResultList();

		return results;
	}
	
	@SuppressWarnings("unchecked")
	public List<UnidadesGeral> loadunidadesgasvent(Long id_gasvent) {
		Query query = manager.createQuery("select u from UnidadesGeral u JOIN u.tipoGasVent tipo WHERE tipo.id_tipogasvent = :id_tipo");
		query.setParameter("id_tipo", id_gasvent);
		
		List<UnidadesGeral> results = query.getResultList();

		//System.out.println(results.size());
//        int count = 0;  
//        for (Iterator i = results.iterator(); i.hasNext();) {  
//        	UnidadesGeral values = (UnidadesGeral) i.next();  
//            System.out.println(++count + ": " + values.getId_unidades() + ", " + values.getDescricao() + "<br />");  
//
//        } 
		
		return results;
	}
	
	@SuppressWarnings("unchecked")
	public List<UnidadesGeral> ListaUnidadesAmostraFO(Long idamostra) {
		Query query = manager.createQuery("select u from UnidadesGeral u JOIN u.unidadesAmostrasFO ua JOIN ua.amostraFO amostra WHERE amostra.id_amostrafo = :idamostra");
		
		query.setParameter("idamostra", idamostra);
		
		List<UnidadesGeral> results = query.getResultList();

		return results;
	}
	
	
	public boolean trataadicionar(String desc)
	{
		Query query = manager.createQuery("SELECT e FROM UnidadesGeral e WHERE e.descricao =:desc");
		query.setParameter("desc", desc);
		
		if(query.getResultList().isEmpty())
		{
			UnidadesGeral unid = new UnidadesGeral();
			unid.setDescricao(desc);
			adiciona(unid);
			
			return true;
		}
		else
		{
			return false;
		}
	}
	
	public boolean trataalterar(Long id, String desc)
	{
		UnidadesGeral etnia = new UnidadesGeral();
		etnia.setId_unidades(id);
		etnia.setDescricao(desc);
		atualiza(etnia);
			
		return true;
	}
	
	public boolean remover(Long id)
	{
		UnidadesGeral unid = new UnidadesGeral();
		unid = buscaPorId(id);
		
		remove(unid);
		return true;
	}
}
