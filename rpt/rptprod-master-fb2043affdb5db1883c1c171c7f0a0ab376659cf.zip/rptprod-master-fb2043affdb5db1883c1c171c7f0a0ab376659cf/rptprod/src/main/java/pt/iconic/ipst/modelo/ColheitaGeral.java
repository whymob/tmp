package pt.iconic.ipst.modelo;

import java.util.Calendar;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name = "COLHEITA_GERAL")
public class ColheitaGeral {

	
	private Long idcolheitageral;
	private Calendar iniciogeral;
	private Calendar clampagemgeral;
	private Calendar fimgeral;
//	private boolean coracaoparado;
	private int tecnica;
	private String notastecnica;
	private int inspcavidadeabdom;
	private boolean neoplasia;
	private boolean contaminacao;
	private boolean traumatismo;
	private boolean outrasabdom;
	private String notasicabdom;
	private int colheitageral;
	private String notascolheita;
	private boolean ganglios;
	private boolean baco;
	private boolean outrosprodtipagem;
	private String notasprodtipagem;
	private AnaliseDador analiseDador;
	
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="ID_COLHEITA_GERAL")
	public Long getIdcolheitageral() {
		return idcolheitageral;
	}
	public void setIdcolheitageral(Long idcolheitageral) {
		this.idcolheitageral = idcolheitageral;
	}
	
	@OneToOne(fetch=FetchType.EAGER)
	@JoinColumn(name="ID_ANALISEDADOR")
	public AnaliseDador getAnaliseDador() {
		return analiseDador;
	}
	public void setAnaliseDador(AnaliseDador analiseDador) {
		this.analiseDador = analiseDador;
	}
	
	@Column(name="INICIO_GERAL")
	public Calendar getIniciogeral() {
		return iniciogeral;
	}
	public void setIniciogeral(Calendar iniciogeral) {
		this.iniciogeral = iniciogeral;
	}
	
	@Column(name="CLAMPAGEM_GERAL")
	public Calendar getClampagemgeral() {
		return clampagemgeral;
	}
	public void setClampagemgeral(Calendar clampagemgeral) {
		this.clampagemgeral = clampagemgeral;
	}
	
	@Column(name="FIM_GERAL")
	public Calendar getFimgeral() {
		return fimgeral;
	}
	public void setFimgeral(Calendar fimgeral) {
		this.fimgeral = fimgeral;
	}
	
/*	@Column(name="CORACAO_PARADO")
	public boolean isCoracaoparado() {
		return coracaoparado;
	}
	public void setCoracaoparado(boolean coracaoparado) {
		this.coracaoparado = coracaoparado;
	}*/
	
	@Column(name="TECNICA")
	public int getTecnica() {
		return tecnica;
	}
	public void setTecnica(int tecnica) {
		this.tecnica = tecnica;
	}
	
	@Column(name="NOTAS_TECNICA")
	public String getNotastecnica() {
		return notastecnica;
	}
	public void setNotastecnica(String notastecnica) {
		this.notastecnica = notastecnica;
	}
	
	@Column(name="INSP_CAV_ABDOMINAL")
	public int getInspcavidadeabdom() {
		return inspcavidadeabdom;
	}
	public void setInspcavidadeabdom(int inspcavidadeabdom) {
		this.inspcavidadeabdom = inspcavidadeabdom;
	}
	
	@Column(name="NEOPLASIA")
	public boolean isNeoplasia() {
		return neoplasia;
	}
	public void setNeoplasia(boolean neoplasia) {
		this.neoplasia = neoplasia;
	}
	
	@Column(name="CONTAMINACAO")
	public boolean isContaminacao() {
		return contaminacao;
	}
	public void setContaminacao(boolean contaminacao) {
		this.contaminacao = contaminacao;
	}
	
	@Column(name="TRAUMATISMO")
	public boolean isTraumatismo() {
		return traumatismo;
	}
	public void setTraumatismo(boolean traumatismo) {
		this.traumatismo = traumatismo;
	}
	
	@Column(name="OUTRAS_ABDOMINAL")
	public boolean isOutrasabdom() {
		return outrasabdom;
	}
	public void setOutrasabdom(boolean outrasabdom) {
		this.outrasabdom = outrasabdom;
	}
	
	@Column(name="NOTAS_INSP_CAV_ABDOMINAL")
	public String getNotasicabdom() {
		return notasicabdom;
	}
	public void setNotasicabdom(String notasicabdom) {
		this.notasicabdom = notasicabdom;
	}
	
	@Column(name="COLHEITA_GERAL")
	public int getColheitageral() {
		return colheitageral;
	}
	public void setColheitageral(int colheitageral) {
		this.colheitageral = colheitageral;
	}
	
	@Column(name="NOTAS_COLHEITA")
	public String getNotascolheita() {
		return notascolheita;
	}
	public void setNotascolheita(String notascolheita) {
		this.notascolheita = notascolheita;
	}
	
	@Column(name="GANGLIOS")
	public boolean isGanglios() {
		return ganglios;
	}
	public void setGanglios(boolean ganglios) {
		this.ganglios = ganglios;
	}
	
	@Column(name="BACO")
	public boolean isBaco() {
		return baco;
	}
	public void setBaco(boolean baco) {
		this.baco = baco;
	}
	
	@Column(name="OUTROS_PROD_TIPAGEM")
	public boolean isOutrosprodtipagem() {
		return outrosprodtipagem;
	}
	public void setOutrosprodtipagem(boolean outrosprodtipagem) {
		this.outrosprodtipagem = outrosprodtipagem;
	}
	
	@Column(name="NOTAS_PROD_TIPAGEM")
	public String getNotasprodtipagem() {
		return notasprodtipagem;
	}
	public void setNotasprodtipagem(String notasprodtipagem) {
		this.notasprodtipagem = notasprodtipagem;
	}
	
	
	
}
