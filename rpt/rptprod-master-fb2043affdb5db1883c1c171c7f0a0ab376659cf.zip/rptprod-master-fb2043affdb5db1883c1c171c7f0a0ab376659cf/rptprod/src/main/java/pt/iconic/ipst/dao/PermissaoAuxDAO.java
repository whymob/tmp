package pt.iconic.ipst.dao;


import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.concurrent.TimeUnit;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import pt.iconic.ipst.modelo.Hospital;
import pt.iconic.ipst.modelo.PermissaoAux;
import pt.iconic.ipst.modelo.PermissaoLocalizacao;
import pt.iconic.ipst.modelo.Posicao;
import pt.iconic.ipst.modelo.Utilizador;


@Repository
@Transactional
public class PermissaoAuxDAO {

	
	@PersistenceContext
	private EntityManager manager;
		
	
	public void adiciona(PermissaoAux permissaoaux){
		manager.persist(permissaoaux);	
	}
	
	

	public void transferePermissaoAuxPermissao(Utilizador utilizador){
//		System.out.println("utilizador: "+utilizador.getID_Utilizador());
//		System.out.println("email: "+utilizador.getEmail());
		
		//seleciona lista de permissoes para esse email
		List<PermissaoAux> permaux = ListaPermissaoAuxEmail(utilizador.getEmail());
	
//		System.out.println("tamanho permissoes: "+permaux.size());
		for(int i=0; i<permaux.size(); i++){
			
			
			
			PermissaoLocalizacao permissao = new PermissaoLocalizacao();
			permissao.setUtilizador(utilizador);
			

//			Long hosp = permaux.get(i).getId_hospital();
//			System.out.println("id_hospital "+hosp);
			
			permissao.setHospital(manager.find(Hospital.class, permaux.get(i).getId_hospital()));
			
//			Long pos = permaux.get(i).getId_posicao();
//			System.out.println("posicao �:  "+pos);
			
			permissao.setPosicao(manager.find(Posicao.class,permaux.get(i).getId_posicao()));
			permissao.setLeituraescrita(permaux.get(i).isLeituraescrita());

			manager.persist(permissao);
	
			manager.remove(permaux.get(i));
		}
		
	
		
	}
	
	@SuppressWarnings("unchecked")
	public List<PermissaoAux> ListaPermissaoAuxEmail(String email){
			
			List<PermissaoAux> out = null;
			
			Query query = manager.createQuery("SELECT p FROM PermissaoAux p WHERE p.email =:email");
			query.setParameter("email", email) ;
			out = query.getResultList();
			return out;
		}
	
	public boolean verificapin(String email, int pin){
		Query query = manager.createQuery("SELECT p FROM PermissaoAux p WHERE p.email =:email AND p.pin =:pin");
		query.setParameter("email", email) ;
		query.setParameter("pin", pin) ;
		
		if(query.getResultList().isEmpty()){
//			System.out.println("N�o existe correspond�ncia de pin");
			return false;
		}else{
//			System.out.println("Pin corresponde a esse email");
			return true;
		}
	}
	
	
	public void tratalistaadicionar(String valores, String email, String pin, String telemovel){
		
		boolean leituraescrita;
		String str = valores;
    	String delims = "[,]";
    	String[] lista = str.split(delims);
    	//System.out.println("Tamanho : "+lista.length);

    	for(int i=0; i<lista.length;i++)
    	{
//        System.out.println("Lista : "+lista[i]);
		String valor = 	lista[i];
		String delimitador = "[_]";
		String[] hospital = valor.split(delimitador);
		
		PermissaoAux permissao = new PermissaoAux();

//		System.out.println("id hospital: "+permissao.getId_hospital());	
		
		String delimitador2 = "[:]";
		String[] posicao = valor.split(delimitador2);		
	    int startIndex = lista[i].indexOf('_');
	    int endIndex = lista[i].indexOf(':');

//	    System.out.println("id posicao: "+posicao[0].substring(startIndex + 1, endIndex));
	    
	    
	    int startLE = lista[i].indexOf(':');
	    String leitesc = String.valueOf(lista[i].charAt(startLE+1));
	    int le = Integer.parseInt(leitesc);
	    if(le==1){
	    	  leituraescrita = false;
	    }
	    else {
	    	  leituraescrita = true;
	    }
	    
//	    System.out.println("valor da leitura escrita: "+leituraescrita);
//	    System.out.println("PIN :"+pin);
	    Calendar dataParaGravar = Calendar.getInstance();
//		System.out.println("data: "+dataParaGravar.getTime().toString());
		
		permissao.setData(dataParaGravar);
		permissao.setId_posicao(Long.parseLong(posicao[0].substring(startIndex + 1, endIndex)));
		permissao.setId_hospital(Long.parseLong(hospital[0]));
		permissao.setLeituraescrita(leituraescrita);
		permissao.setEmail(email);
		permissao.setPin(Integer.parseInt(pin));
		if(telemovel != null && !telemovel.isEmpty()){
		permissao.setTelemovel(telemovel);
		}
		adiciona(permissao);
		
//		Timestamp ts = new Timestamp(dataParaGravar.getTimeInMillis());  
//		DateFormat df = new SimpleDateFormat("dd/MM/yyyy HH:mm");  
//		System.out.println(df.format(ts));
    	}
	}
	
	@SuppressWarnings("rawtypes")
	public boolean existePermissaoaux(String email) {

		Query query = manager.createQuery("SELECT p FROM PermissaoAux p WHERE p.email =:email");
		query.setParameter("email", email) ;
		List results = query.getResultList();
		if(results.isEmpty()){
//			System.out.println("N�o existe permissao auxiliar");
			return false;
		}else{

			//Verificar se j� passaram as 24horas, se sim, remover as desse user e dar false
			PermissaoAux perm = (PermissaoAux) results.get(0);
			//data atual
			Calendar currentDate = Calendar.getInstance();
			SimpleDateFormat formatter= new SimpleDateFormat("dd/MM/yyyy HH:mm:ss");
			String dateNow = formatter.format(currentDate.getTime());
			//data reg permissao
			String dataperm = formatter.format(perm.getData().getTime());
			
			try {
			    Date date1 = formatter.parse(dateNow);
			    Date date2 = formatter.parse(dataperm);
			    long diff = date1.getTime() - date2.getTime();
//			    System.out.println ("Dias: " + TimeUnit.DAYS.convert(diff, TimeUnit.MILLISECONDS));
			    if(TimeUnit.DAYS.convert(diff, TimeUnit.MILLISECONDS) >= 1){
			    	
					//List<PermissaoAux> permaux = ListaPermissaoAuxEmail(email);
					
					for(int i=0; i<results.size(); i++){
						manager.remove(results.get(i));
					}
			    	return false;
			    }   
			} catch (ParseException e) {
			    e.printStackTrace();
			}
			
			return true;
		}
	}
	
	@SuppressWarnings("rawtypes")
	public boolean existePermissaoauxregisto(String email) {

		Query query = manager.createQuery("SELECT p FROM PermissaoAux p WHERE p.email =:email");
		query.setParameter("email", email) ;
		List results = query.getResultList();
		if(results.isEmpty()){
			return false;
		}else{
			PermissaoAux perm = null;
			if(!results.isEmpty()){
				perm = (PermissaoAux) results.get(0);
				
				//data atual
				Calendar currentDate = Calendar.getInstance();
				SimpleDateFormat formatter= new SimpleDateFormat("dd/MM/yyyy HH:mm:ss");
				String dateNow = formatter.format(currentDate.getTime());
				
				String dataperm = formatter.format(perm.getData().getTime());
				
				//VSess�o para colocar o contato no formul�rio de registo, � eliminada no controlador antes de devolver a p�gina
				ServletRequestAttributes attr = (ServletRequestAttributes) RequestContextHolder.currentRequestAttributes();
				HttpSession session = attr.getRequest().getSession();
				session.setAttribute("contato", perm.getTelemovel());
				
				
				try {
				    Date date1 = formatter.parse(dateNow);
				    Date date2 = formatter.parse(dataperm);
				    long diff = date1.getTime() - date2.getTime();
	//			    System.out.println ("Dias: " + TimeUnit.DAYS.convert(diff, TimeUnit.MILLISECONDS));
				    if(TimeUnit.DAYS.convert(diff, TimeUnit.MILLISECONDS) >= 1){
				    	
						List<PermissaoAux> permaux = ListaPermissaoAuxEmail(email);
						
						for(int i=0; i<permaux.size(); i++){
							manager.remove(permaux.get(i));
						}
				    	return false;
				    }   
				} catch (ParseException e) {
				    e.printStackTrace();
				}
				
				//System.out.println("data registo:"+perm.getData()+"|||||||||| dataatual: "+currentDate+", ////////" +dateNow);
			}
			
			return true;
		}
	}
		
}
