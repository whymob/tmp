package pt.iconic.ipst.modelo;

import java.util.Calendar;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import org.springframework.format.annotation.DateTimeFormat;

@Entity
@Table(name = "COMPROMISSO")
public class Compromisso 
{
	private Long idcompromisso;
	private Entidade entidade;
	private Calendar data;
	private double valor;
	private String compromisso;
	private List<ACSSDetalheColheita> acss;
	private FaturaACSS fatura;
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="ID_COMPROMISSO")
	public Long getIdcompromisso() {
		return idcompromisso;
	}
	public void setIdcompromisso(Long idcompromisso) {
		this.idcompromisso = idcompromisso;
	}
	
	@ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "ID_ENTIDADE")
	public Entidade getEntidade() {
		return entidade;
	}
	public void setEntidade(Entidade entidade) {
		this.entidade = entidade;
	}
	
	@DateTimeFormat(pattern="dd/MM/yyyy")
	@Temporal(TemporalType.DATE)
	@Column(name="DATA")
	public Calendar getData() {
		return data;
	}
	public void setData(Calendar data) {
		this.data = data;
	}
	
	@Column(name="VALOR")
	public double getValor() {
		//DecimalFormat decim = new DecimalFormat("#.00");
		return round(valor, 2); 
	}
	public void setValor(double valor) {
		this.valor = valor;
	}
	
	@Column(name="COMPROMISSO")
	public String getCompromisso() {
		return compromisso;
	}
	public void setCompromisso(String compromisso) {
		this.compromisso = compromisso;
	}
	
	@OneToMany(fetch = FetchType.EAGER, mappedBy = "compromisso")
	public List<ACSSDetalheColheita> getAcss() {
		return acss;
	}
	public void setAcss(List<ACSSDetalheColheita> acss) {
		this.acss = acss;
	}
	
	@OneToOne(fetch = FetchType.EAGER, mappedBy = "compromisso")
	public FaturaACSS getFatura() {
		return fatura;
	}
	public void setFatura(FaturaACSS fatura) {
		this.fatura = fatura;
	}
	
	public static double round(double value, int places) {
	    if (places < 0) throw new IllegalArgumentException();

	    long factor = (long) Math.pow(10, places);
	    value = value * factor;
	    long tmp = Math.round(value);
	    return (double) tmp / factor;
	}
}