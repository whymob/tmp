package pt.iconic.ipst.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import pt.iconic.ipst.modelo.PPPancreatico;

@Repository
public class PPPancreaticoDAO 
{
	@PersistenceContext
	private EntityManager manager;
	
	public void adiciona(PPPancreatico panc){
		manager.persist(panc);	
	}
	
	@Transactional
	public void atualiza(PPPancreatico panc){
		manager.merge(panc);
	}
	
/*	@SuppressWarnings("unchecked")
	public List<PPPancreatico> ListaPPPancreatico(){
		return manager.createQuery("select p from PPPancreatico p").getResultList();
	}*/
	
/*	public PPPancreatico buscaPorId(Long id){
		return manager.find(PPPancreatico.class, id);
	}*/
	
/*	public void remove(PPPancreatico panc){
		PPPancreatico pancrem = buscaPorId(panc.getId_pppancreatico());
		manager.remove(pancrem);
	}*/
	
	@SuppressWarnings("rawtypes")
	public PPPancreatico ListaPPPancreaticoAnalise(Long id)
	{
		Query query = manager.createQuery("select e from PPPancreatico e JOIN e.analiserecetor analiserecetor WHERE analiserecetor.id_analiserecetor =:idanalise");
		query.setParameter("idanalise", id);

		List results = query.getResultList();
		PPPancreatico rad = null;
		
		if(!results.isEmpty())
		{
			rad = (PPPancreatico) results.get(0);
		}
		
		return rad;
	}
}
