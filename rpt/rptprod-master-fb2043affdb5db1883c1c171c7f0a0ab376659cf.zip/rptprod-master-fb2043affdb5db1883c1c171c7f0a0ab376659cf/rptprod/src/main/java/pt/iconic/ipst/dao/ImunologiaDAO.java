package pt.iconic.ipst.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import pt.iconic.ipst.modelo.Imunologia;


@Repository
public class ImunologiaDAO {

	
	@PersistenceContext
	private EntityManager manager;
	
	
	public void adiciona(Imunologia imunologia){
		manager.persist(imunologia);	
	}
	
	@Transactional
	public void atualiza(Imunologia imunologia){
		manager.merge(imunologia);
	}
	

/*	@SuppressWarnings("unchecked")
	public List<Imunologia> ListaImunologia(){
		return manager.createQuery("select a from Imunologia a").getResultList();
	}
	
	public Imunologia buscaPorId(Long id){
		return manager.find(Imunologia.class, id);
	}
	
	
	public void remove(Imunologia imunologia){
		Imunologia imunologiaARemover = buscaPorId(imunologia.getId_Imunologia());
		manager.remove(imunologiaARemover);
		
	}*/
	
	@SuppressWarnings("unchecked")
	public Imunologia buscaImunologiaAnalise(Long idanalise){
		
		Query query = manager.createQuery("select b from Imunologia b JOIN b.analiseDador a WHERE a.id_AnaliseDador =:idanalise");
		query.setParameter("idanalise", idanalise);
		
		List<Imunologia> results = query.getResultList();
		Imunologia imunologia = null;
		if(!results.isEmpty()){
			imunologia = (Imunologia) results.get(0);
		}
		
		return imunologia;
	}
}
