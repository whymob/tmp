package pt.iconic.ipst.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import pt.iconic.ipst.modelo.GravidadeRecetor;

@Repository
@Transactional
public class GravidadeRecetorDAO 
{
	@PersistenceContext
	private EntityManager manager;
	
	
	public void adiciona(GravidadeRecetor grav){
		manager.persist(grav);	
	}
	

	public void atualiza(GravidadeRecetor grav){
		manager.merge(grav);
	}

/*	@SuppressWarnings("unchecked")
	public List<GravidadeRecetor> ListaGravidade(){
		return manager.createQuery("select d from GravidadeRecetor d").getResultList();
	}*/
	
	public GravidadeRecetor buscaPorId(Long id){
		return manager.find(GravidadeRecetor.class, id);
	}
	
	public void remove(GravidadeRecetor grav){
		GravidadeRecetor gravrem = buscaPorId(grav.getId_gravidaderecetor());
		manager.remove(gravrem);
	}
	
	@SuppressWarnings("unchecked")
	public List<GravidadeRecetor> buscagravidaderecetor(Long analiserecetor)
	{		
		Query query = manager.createNativeQuery("select GRAVIDADERECETOR.ID_GRAVIDADERECETOR, GRAVIDADERECETOR.DATAGRAVIDADE, GRAVIDADERECETOR.NOTASGRAVIDADE, GRAVIDADEORGAO.GRAVIDADE, GRAVIDADEORGAO.ID_GRAVIDADEORGAO from GRAVIDADERECETOR, ANALISERECETOR, GRAVIDADEORGAO where GRAVIDADERECETOR.ID_GRAVIDADEORGAO = GRAVIDADEORGAO.ID_GRAVIDADEORGAO AND GRAVIDADERECETOR.ID_ANALISERECETOR =  ANALISERECETOR.ID_ANALISERECETOR AND GRAVIDADERECETOR.ID_ANALISERECETOR =:analiserecetor order by GRAVIDADERECETOR.ID_GRAVIDADERECETOR desc");
		query.setParameter("analiserecetor", analiserecetor);
		
		List<GravidadeRecetor> results = query.getResultList();

		return results;
	}
	
	@SuppressWarnings("unchecked")
	public List<GravidadeRecetor> buscaUltimaGravidadeRecetor(Long analiserecetor)
	{		
		Query query = manager.createQuery("select g from GravidadeRecetor g JOIN g.analiserecetor an where an.id_analiserecetor =:analiserecetor order by g.id_gravidaderecetor desc");
		query.setParameter("analiserecetor", analiserecetor);
		
		List<GravidadeRecetor> results = query.getResultList();

		return results;
	}
}