package pt.iconic.ipst.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import pt.iconic.ipst.modelo.UnidadeTransplante;

@Repository
@Transactional
public class UnidadeTransplanteDAO 
{
	@PersistenceContext
	private EntityManager manager;
	
	public void adiciona(UnidadeTransplante unid){
		manager.persist(unid);	
	}
	
	public void atualiza(UnidadeTransplante unid){
		manager.merge(unid);

	}
	
	@SuppressWarnings("unchecked")
	public List<UnidadeTransplante> ListaUnidadeTransplante(){
		return manager.createQuery("select u from UnidadeTransplante u").getResultList();
	}
	
//	@SuppressWarnings("unchecked")
//	public List<UnidadeTransplante> ListaUnidadeTransplanteHospital(){
//		return manager.createQuery("select u from Unidade_Hospital u").getResultList();
//	}
	
	public UnidadeTransplante buscaPorId(Long id){
		return manager.find(UnidadeTransplante.class, id);
	}
	
	public void remove(UnidadeTransplante unid){
		UnidadeTransplante unidARemover = buscaPorId(unid.getId_unidadetransplante());
		manager.remove(unidARemover);
	}
	
//	@SuppressWarnings("unchecked")
//	public List<UnidadeTransplante> buscaUnidadesporHosp(Long idhosp)
//	{
//		Query query = manager.createQuery("select u from UnidadeTransplante u JOIN u.hosp h WHERE h.id_Hospital =:idhosp");
//		query.setParameter("idhosp", idhosp);
//		
//		List<UnidadeTransplante> results = query.getResultList();
//		
//		return results;
//	}

	@SuppressWarnings("unchecked")
	public List<UnidadeTransplante> buscaUnidadesporHosp(Long idhosp)
	{
		Query query = manager.createQuery("select u from UnidadeTransplante u join u.hosp uo JOIN uo.hosp h WHERE h.id_Hospital =:idhosp");
		query.setParameter("idhosp", idhosp);
		
		List<UnidadeTransplante> results = query.getResultList();
		
		return results;
	}
	
	public boolean trataadicionar(String desc)
	{
		Query query = manager.createQuery("SELECT e FROM UnidadeTransplante e WHERE e.nome =:desc");
		query.setParameter("desc", desc);
		
		if(query.getResultList().isEmpty())
		{
			
			UnidadeTransplante ut = new UnidadeTransplante();
			ut.setNome(desc);
			adiciona(ut);
			
			return true;
		}
		else
		{
			return false;
		}
	}

	public boolean trataalterar(Long id, String desc)
	{

		

			
			UnidadeTransplante ut = new UnidadeTransplante();
			ut.setNome(desc);
			ut.setId_unidadetransplante(id);
			atualiza(ut);
				
			return true;
	}
	

	public boolean remover(Long id) 
	{
		UnidadeTransplante ut = buscaPorId(id);
		remove(ut);
		return true;
	}
}
