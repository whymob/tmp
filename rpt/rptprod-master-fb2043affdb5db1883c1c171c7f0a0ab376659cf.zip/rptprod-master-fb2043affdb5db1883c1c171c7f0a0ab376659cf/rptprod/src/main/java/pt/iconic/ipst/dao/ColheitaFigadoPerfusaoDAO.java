package pt.iconic.ipst.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import pt.iconic.ipst.modelo.ColheitaFigadoPerfusao;

@Repository
@Transactional
public class ColheitaFigadoPerfusaoDAO {

	@PersistenceContext
	private EntityManager manager;
	
	
	public void adiciona(ColheitaFigadoPerfusao colheita){
		manager.persist(colheita);	
	}
	

	public void atualiza(ColheitaFigadoPerfusao colheita){
		manager.merge(colheita);
	}
	

/*	@SuppressWarnings("unchecked")
	public List<ColheitaFigadoPerfusao> ListaColheitaFigadoPerfusao(){
		return manager.createQuery("select a from ColheitaFigadoPerfusao a").getResultList();
	}*/
	
	public ColheitaFigadoPerfusao buscaPorId(Long id){
		return manager.find(ColheitaFigadoPerfusao.class, id);
	}
	
	
	public void remove(ColheitaFigadoPerfusao colheita){
		ColheitaFigadoPerfusao colheitaARemover = buscaPorId(colheita.getIdperfusaofigado());
		manager.remove(colheitaARemover);
		
	}
	
	@SuppressWarnings("unchecked")
	public List<ColheitaFigadoPerfusao> ListaColheitaFigadoPerfusaoanalise(Long idanalise){
		
		Query query = manager.createQuery("select b from ColheitaFigadoPerfusao b JOIN b.analiseDador a WHERE a.id_AnaliseDador =:idanalise");
		query.setParameter("idanalise", idanalise);
		
		List<ColheitaFigadoPerfusao> results = query.getResultList();

		return results;
		
	}
}
