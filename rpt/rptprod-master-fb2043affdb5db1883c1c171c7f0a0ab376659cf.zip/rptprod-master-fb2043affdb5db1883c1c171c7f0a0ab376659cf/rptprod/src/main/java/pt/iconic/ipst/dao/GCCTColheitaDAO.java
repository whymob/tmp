package pt.iconic.ipst.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import pt.iconic.ipst.modelo.GCCTColheita;

@Repository
@Transactional
public class GCCTColheitaDAO 
{
	@PersistenceContext
	private EntityManager manager;
	
	
	public void adiciona(GCCTColheita gcct){
		manager.persist(gcct);	
	}
	
	public void atualiza(GCCTColheita gcct){
		manager.merge(gcct);
	}
	
	@SuppressWarnings("unchecked")
	public List<GCCTColheita> ListaGCCTColheita(){
		return manager.createQuery("select d from GCCTColheita d").getResultList();
	}
	
	public GCCTColheita buscaPorId(Long id){
		return manager.find(GCCTColheita.class, id);
	}
	
/*	public void remove(GCCTColheita gcct){
		GCCTColheita gcctARemover = buscaPorId(gcct.getIdgcctcolheita());
		manager.remove(gcctARemover);
	}*/
	
	@SuppressWarnings("unchecked")
	public boolean existegcctcolheitaanalise(Long idanalise)
	{
		Query query = manager.createQuery("select b from GCCTColheita b JOIN b.analiseDador analisedador WHERE analisedador.id_AnaliseDador =:idanalise");
		query.setParameter("idanalise", idanalise);
		
		List<GCCTColheita> results = query.getResultList();
		
		if(results.isEmpty())
			return false;
		else
			return true;
	}
	
/*	@SuppressWarnings("unchecked")
	public GCCTColheita buscagcctcolheitaanalise(Long id_analise)
	{
		Query query = manager.createQuery("select b from GCCTColheita b JOIN b.analiseDador analisedador WHERE analisedador.id_AnaliseDador =:idanalise");
		query.setParameter("idanalise", id_analise);
		
		List<GCCTColheita> results = query.getResultList();

		GCCTColheita gcc = null;
		
		if(!results.isEmpty())
		{
			gcc = (GCCTColheita) results.get(0);
		}
		
		return gcc;
	}*/
	
	@SuppressWarnings("unchecked")
	public List<GCCTColheita> buscagcctcolheitafiltrado(int ano, int mes)
	{
		Query query = manager.createQuery("select g from GCCTColheita g WHERE YEAR(g.datacolheita) =:ano and MONTH(g.datacolheita) =:mes");
		query.setParameter("ano", ano);
		query.setParameter("mes", mes);
		
		List<GCCTColheita> results = query.getResultList();

		return results;
	}
	
	@SuppressWarnings("unchecked")
	public List<GCCTColheita> buscagcctcolheitafiltradoipst(int ano, int mes)
	{
		Query query = manager.createNativeQuery("select GCCTCOLHEITA.ID_GCCTCOLHEITA, ENTIDADE.NOME, HOSPITAL.NOMEHOSPITAL, GCCTCOLHEITA.DATA, GCCTCOLHEITA.ATO, GCCTCOLHEITA.TIPO, GCCTCOLHEITA.CODIGODADOR, GCCTCOLHEITA.ESTADO, GCCT.NOMEGCCT from GCCTCOLHEITA join HOSPITAL on (GCCTCOLHEITA.ID_HOSPITAL = HOSPITAL.ID_HOSPITAL) join GCCT on (HOSPITAL.ID_GCCT = GCCT.ID_GCCT) join ENTIDADE on (GCCTCOLHEITA.ID_ENTIDADE = ENTIDADE.ID_ENTIDADE) where year(GCCTCOLHEITA.DATA) =:ano and MONTH(GCCTCOLHEITA.DATA) =:mes");
		query.setParameter("ano", ano);
		query.setParameter("mes", mes);
		
		List<GCCTColheita> results = query.getResultList();

		return results;
	}
	
	@SuppressWarnings("unchecked")
	public List<GCCTColheita> buscagcctcolheitanaovalidadofiltrado()
	{
		Query query = manager.createQuery("select g from GCCTColheita g WHERE g.estado = 0");
		
		List<GCCTColheita> results = query.getResultList();

		return results;
	}
	
	@SuppressWarnings("unchecked")
	public List<GCCTColheita> buscagcctcolheitanaoaprovadofiltrado()
	{
		Query query = manager.createNativeQuery("select GCCTCOLHEITA.ID_GCCTCOLHEITA, ENTIDADE.NOME, HOSPITAL.NOMEHOSPITAL, GCCTCOLHEITA.DATA, GCCTCOLHEITA.ATO, GCCTCOLHEITA.TIPO, GCCTCOLHEITA.CODIGODADOR, GCCTCOLHEITA.ESTADO, GCCT.NOMEGCCT from GCCTCOLHEITA join HOSPITAL on (GCCTCOLHEITA.ID_HOSPITAL = HOSPITAL.ID_HOSPITAL) join GCCT on (HOSPITAL.ID_GCCT = GCCT.ID_GCCT) join ENTIDADE on (GCCTCOLHEITA.ID_ENTIDADE = ENTIDADE.ID_ENTIDADE) where GCCTCOLHEITA.ESTADO = 1");
		
		List<GCCTColheita> results = query.getResultList();

		return results;
	}
	
	@SuppressWarnings("unchecked")
	public List<Object> buscagcctcolheitaIPST()
	{
		List<Object> out = null;
		
		Query query = manager.createNativeQuery("select GCCTCOLHEITA.ID_GCCTCOLHEITA, ENTIDADE.NOME, HOSPITAL.NOMEHOSPITAL, GCCTCOLHEITA.DATA, GCCTCOLHEITA.ATO, GCCTCOLHEITA.TIPO, GCCTCOLHEITA.CODIGODADOR, GCCTCOLHEITA.ESTADO, GCCT.NOMEGCCT from GCCTCOLHEITA join HOSPITAL on (GCCTCOLHEITA.ID_HOSPITAL = HOSPITAL.ID_HOSPITAL) join GCCT on (HOSPITAL.ID_GCCT = GCCT.ID_GCCT) join ENTIDADE on (GCCTCOLHEITA.ID_ENTIDADE = ENTIDADE.ID_ENTIDADE)");
		
		out = query.getResultList();

		return out;
	}
	
	public Object buscagcctcolheitaIPSTLinha(Long id)
	{
		Object out = null;
		
		Query query = manager.createNativeQuery("select GCCTCOLHEITA.ID_GCCTCOLHEITA, ENTIDADE.NOME, HOSPITAL.NOMEHOSPITAL, GCCTCOLHEITA.DATA, GCCTCOLHEITA.ATO, GCCTCOLHEITA.TIPO, GCCTCOLHEITA.CODIGODADOR, GCCTCOLHEITA.ESTADO, GCCT.NOMEGCCT from GCCTCOLHEITA join HOSPITAL on (GCCTCOLHEITA.ID_HOSPITAL = HOSPITAL.ID_HOSPITAL) join GCCT on (HOSPITAL.ID_GCCT = GCCT.ID_GCCT) join ENTIDADE on (GCCTCOLHEITA.ID_ENTIDADE = ENTIDADE.ID_ENTIDADE) where GCCTCOLHEITA.ID_GCCTCOLHEITA =:id");
		query.setParameter("id", id);
		
		out = query.getResultList().get(0);

		return out;
	}
	
	
	
	@SuppressWarnings("unchecked")
	public List<Object> buscagcctcolheitaACSS()
	{
		List<Object> out = null;
		
		Query query = manager.createNativeQuery("select GCCTCOLHEITA.ID_GCCTCOLHEITA, GCCT.NOMEGCCT, ENTIDADE.NOME, HOSPITAL.NOMEHOSPITAL, GCCTCOLHEITA.DATA, GCCTCOLHEITA.ATO, GCCTCOLHEITA.TIPO, GCCTCOLHEITA.CODIGODADOR from GCCTCOLHEITA join HOSPITAL on (GCCTCOLHEITA.ID_HOSPITAL = HOSPITAL.ID_HOSPITAL) join GCCT on (HOSPITAL.ID_GCCT = GCCT.ID_GCCT) join ENTIDADE on (GCCTCOLHEITA.ID_ENTIDADE = ENTIDADE.ID_ENTIDADE) where GCCTCOLHEITA.ESTADO = 2");
		
		out = query.getResultList();

		return out;
	}
	
	@SuppressWarnings("unchecked")
	public List<Integer> buscaAnosgcctcolheitaanalise()
	{
		Query query = manager.createNativeQuery("select distinct year(GCCTCOLHEITA.DATA) from GCCTCOLHEITA");
		
		List<Integer> results = query.getResultList();

		return results;
	}
	
	@SuppressWarnings("unchecked")
	public List<GCCTColheita> buscacolheitafiltradaacss(int ano, int mes)
	{
		Query query = manager.createNativeQuery("select GCCTCOLHEITA.ID_GCCTCOLHEITA, GCCT.NOMEGCCT, ENTIDADE.NOME, HOSPITAL.NOMEHOSPITAL, GCCTCOLHEITA.DATA, GCCTCOLHEITA.ATO, GCCTCOLHEITA.TIPO, GCCTCOLHEITA.CODIGODADOR from GCCTCOLHEITA join HOSPITAL on (GCCTCOLHEITA.ID_HOSPITAL = HOSPITAL.ID_HOSPITAL) join GCCT on (HOSPITAL.ID_GCCT = GCCT.ID_GCCT) join ENTIDADE on (GCCTCOLHEITA.ID_ENTIDADE = ENTIDADE.ID_ENTIDADE) where year(GCCTCOLHEITA.DATA) =:ano and MONTH(GCCTCOLHEITA.DATA) =:mes");
		query.setParameter("ano", ano);
		query.setParameter("mes", mes);
		
		List<GCCTColheita> results = query.getResultList();

		return results;
	}

	public boolean verificaexisteanaliseorgao(Long id_AnaliseDador, String orgao) {
		
		Query query = manager.createNativeQuery("select gc.ID_GCCTCOLHEITA from GCCTCOLHEITA gc "
				+ "where gc.ID_ANALISEDADOR = :id_AnaliseDador and gc.TIPO = :orgao");
		query.setParameter("id_AnaliseDador", id_AnaliseDador);
		query.setParameter("orgao", orgao);
		if(query.getResultList().isEmpty()){
			return false;
		}else{
			return true;
		}
	}
}
