package pt.iconic.ipst.modelo;

import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name = "POSICAO")
public class Posicao {

	
	private Long Id_Posicao;
	private String Posicao;
//	private List<UtilizadorPosicao> utilizadorposicoes;
	private List<PermissaoLocalizacao> permissoes;
	
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="ID_POSICAO")
	public Long getId_Posicao() {
		return Id_Posicao;
	}
	public void setId_Posicao(Long id_Posicao) {
		Id_Posicao = id_Posicao;
	}
	
	@Column(name="POSICAO")
	public String getPosicao() {
		return Posicao;
	}
	public void setPosicao(String posicao) {
		Posicao = posicao;
	}
	
/*	@OneToMany(fetch = FetchType.LAZY, mappedBy = "posicao")
	public List<UtilizadorPosicao> getUtilizadorposicoes() {
		return utilizadorposicoes;
	}
	public void setUtilizadorposicoes(List<UtilizadorPosicao> utilizadorposicoes) {
		this.utilizadorposicoes = utilizadorposicoes;
	}*/
	
	@OneToMany(fetch = FetchType.LAZY, mappedBy = "posicao")
	public List<PermissaoLocalizacao> getPermissoes() {
		return permissoes;
	}
	public void setPermissoes(List<PermissaoLocalizacao> permissoes) {
		this.permissoes = permissoes;
	}

	
	
	
}
