package pt.iconic.ipst.modelo;

import java.util.Calendar;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name = "CORONOGRAFIA")
public class Coronografia 
{
	private Long Id_Coronografia;
	private Calendar DataCoronografia;
	private String Notas;
	private String caminho;
	private String nomedoc;
	private AnaliseDador analiseDador;
	private boolean statusharmcoron;
	private Calendar datagravacao;
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="ID_CORONOGRAFIA")
	public Long getId_Coronografia() {
		return Id_Coronografia;
	}
	public void setId_Coronografia(Long id_Coronografia) {
		Id_Coronografia = id_Coronografia;
	}
	
	@Column(name="DATACORONOGRAFIA")
	public Calendar getDataCoronografia() {
		return DataCoronografia;
	}
	public void setDataCoronografia(Calendar dataCoronografia) {
		DataCoronografia = dataCoronografia;
	}
	
	@Column(name="NOTAS")
	public String getNotas() {
		return Notas;
	}
	public void setNotas(String notas) {
		Notas = notas;
	}

	@OneToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="ID_ANALISEDADOR")
	public AnaliseDador getAnaliseDador() {
		return analiseDador;
	}
	public void setAnaliseDador(AnaliseDador analiseDador) {
		this.analiseDador = analiseDador;
	}
	
	@Column(name="CAMINHODOC")
	public String getCaminho() {
		return caminho;
	}
	public void setCaminho(String caminho) {
		this.caminho = caminho;
	}
	
	@Column(name="NOMEDOC")
	public String getNomedoc() {
		return nomedoc;
	}
	public void setNomedoc(String nomedoc) {
		this.nomedoc = nomedoc;
	}
	
	@Column(name="STATUSHARMONIO")
	public boolean isStatusharmcoron() {
		return statusharmcoron;
	}
	public void setStatusharmcoron(boolean statusharmcoron) {
		this.statusharmcoron = statusharmcoron;
	}	
	
	@Column(name="DATAGRAVACAO")
	public Calendar getDatagravacao() {
		return datagravacao;
	}


	public void setDatagravacao(Calendar datagravacao) {
		this.datagravacao = datagravacao;
	}
}