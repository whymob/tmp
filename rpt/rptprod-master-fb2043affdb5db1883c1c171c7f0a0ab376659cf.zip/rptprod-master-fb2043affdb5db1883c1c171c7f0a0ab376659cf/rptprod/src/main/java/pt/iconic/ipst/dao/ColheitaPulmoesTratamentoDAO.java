package pt.iconic.ipst.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import pt.iconic.ipst.modelo.ColheitaPulmoesTratamento;

@Repository
@Transactional
public class ColheitaPulmoesTratamentoDAO {

	@PersistenceContext
	private EntityManager manager;
	
	
	public void adiciona(ColheitaPulmoesTratamento colheita){
		manager.persist(colheita);	
	}
	

	public void atualiza(ColheitaPulmoesTratamento colheita){
		manager.merge(colheita);
	}
	

/*	@SuppressWarnings("unchecked")
	public List<ColheitaPulmoesTratamento> ListaColheitaPulmoesTratamento(){
		return manager.createQuery("select a from ColheitaPulmoesTratamento a").getResultList();
	}*/
	
	public ColheitaPulmoesTratamento buscaPorId(Long id){
		return manager.find(ColheitaPulmoesTratamento.class, id);
	}
	
	
	public void remove(ColheitaPulmoesTratamento colheita){
		ColheitaPulmoesTratamento colheitaARemover = buscaPorId(colheita.getIdcolheitatratpulmoes());
		manager.remove(colheitaARemover);
		
	}
	
	@SuppressWarnings("unchecked")
	public List<ColheitaPulmoesTratamento> listacolheitapulmoestratamentoanalise(Long idanalise){
		
		Query query = manager.createQuery("select b from ColheitaPulmoesTratamento b JOIN b.analiseDador a WHERE a.id_AnaliseDador =:idanalise");
		query.setParameter("idanalise", idanalise);
		
		List<ColheitaPulmoesTratamento> results = query.getResultList();
		return results;
		
	}
}
