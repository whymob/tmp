package pt.iconic.ipst.modelo;

import java.util.Calendar;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name = "TRANSPLANTE_FIGADO_PERFUSAO")
public class TransplanteFigadoPerfusao {

	private Long idperfusaofigado;
	private int perfusao;
	private int tipo;
	private int via;
	private float volume;
	private Calendar inicio;
	private Calendar fim;
	private int qualidade;
	private boolean ir;
	private AssignacaoOrgaos assigorgao;
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="ID_PERFUSAO_FIGADO")
	public Long getIdperfusaofigado() {
		return idperfusaofigado;
	}
	public void setIdperfusaofigado(Long idperfusaofigado) {
		this.idperfusaofigado = idperfusaofigado;
	}
	
	@Column(name="PERFUSAO")
	public int getPerfusao() {
		return perfusao;
	}
	public void setPerfusao(int perfusao) {
		this.perfusao = perfusao;
	}
	
	@Column(name="TIPO")
	public int getTipo() {
		return tipo;
	}
	public void setTipo(int tipo) {
		this.tipo = tipo;
	}
	
	@Column(name="VIA")
	public int getVia() {
		return via;
	}
	public void setVia(int via) {
		this.via = via;
	}
	
	@Column(name="VOLUME")
	public float getVolume() {
		return volume;
	}
	public void setVolume(float volume) {
		this.volume = volume;
	}
	
	@Column(name="INICIO")
	public Calendar getInicio() {
		return inicio;
	}
	public void setInicio(Calendar inicio) {
		this.inicio = inicio;
	}
	
	@Column(name="FIM")
	public Calendar getFim() {
		return fim;
	}
	public void setFim(Calendar fim) {
		this.fim = fim;
	}
	
	@Column(name="QUALIDADE")
	public int getQualidade() {
		return qualidade;
	}
	public void setQualidade(int qualidade) {
		this.qualidade = qualidade;
	}
	
	
	@Column(name="SIND_IR")
	public boolean isIr() {
		return ir;
	}
	public void setIr(boolean ir) {
		this.ir = ir;
	}
	
	@ManyToOne(fetch=FetchType.EAGER)
	@JoinColumn(name="ID_ASSIGNACAO_ORGAOS")
	public AssignacaoOrgaos getAssigorgao() {
		return assigorgao;
	}
	public void setAssigorgao(AssignacaoOrgaos assigorgao) {
		this.assigorgao = assigorgao;
	}
	
}
