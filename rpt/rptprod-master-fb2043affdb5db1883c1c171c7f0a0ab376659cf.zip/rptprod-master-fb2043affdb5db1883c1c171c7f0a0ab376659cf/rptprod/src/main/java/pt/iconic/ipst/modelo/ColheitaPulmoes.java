package pt.iconic.ipst.modelo;

import java.util.Calendar;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name = "COLHEITA_PULMOES")
public class ColheitaPulmoes {

	private Long idcolheitapulmoes;
	private Calendar iniciopulmoes;
	private Calendar fimpulmoes;
	private boolean colheitablocopulmoes;
	private int morfpulmesq;
	private String notaspulmesq;
	private int tipoperfesq;
	private int pressaoesq;
	private float volesq;
	private boolean viaantrogradaesq;
	private boolean viaretrogradaesq;
	private int morfpulmdir;
	private String notaspulmdir;
	//ficou s� um pulm�o na perfus�o
	/*private int tipoperfdir;
	private int pressaodir;
	private float voldir;
	private boolean viaantrogradadir;
	private boolean viaretrogradadir;*/
	private String notasperftrat;
	private int estadopulmaoesq;
	private int estadopulmaodir;
	private AnaliseDador analiseDador;
	private String codpulmesq;
	private String codpulmdir;
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="ID_COLHEITA_PULMOES")
	public Long getIdcolheitapulmoes() {
		return idcolheitapulmoes;
	}
	public void setIdcolheitapulmoes(Long idcolheitapulmoes) {
		this.idcolheitapulmoes = idcolheitapulmoes;
	}
	
	@Column(name="INICIO")
	public Calendar getIniciopulmoes() {
		return iniciopulmoes;
	}
	public void setIniciopulmoes(Calendar iniciopulmoes) {
		this.iniciopulmoes = iniciopulmoes;
	}
	
	@Column(name="FIM")
	public Calendar getFimpulmoes() {
		return fimpulmoes;
	}
	public void setFimpulmoes(Calendar fimpulmoes) {
		this.fimpulmoes = fimpulmoes;
	}
	
	@Column(name="COLHEITA_BLOCO")
	public boolean isColheitablocopulmoes() {
		return colheitablocopulmoes;
	}
	public void setColheitablocopulmoes(boolean colheitablocopulmoes) {
		this.colheitablocopulmoes = colheitablocopulmoes;
	}
	
	@Column(name="MORF_PULM_ESQ")
	public int getMorfpulmesq() {
		return morfpulmesq;
	}
	public void setMorfpulmesq(int morfpulmesq) {
		this.morfpulmesq = morfpulmesq;
	}
	
	@Column(name="NOTAS_PULM_ESQ")
	public String getNotaspulmesq() {
		return notaspulmesq;
	}
	public void setNotaspulmesq(String notaspulmesq) {
		this.notaspulmesq = notaspulmesq;
	}
	
	@Column(name="TIPO_PERF_PULM_ESQ")
	public int getTipoperfesq() {
		return tipoperfesq;
	}
	public void setTipoperfesq(int tipoperfesq) {
		this.tipoperfesq = tipoperfesq;
	}
	
	@Column(name="PRESSAO_PULM_ESQ")
	public int getPressaoesq() {
		return pressaoesq;
	}
	public void setPressaoesq(int pressaoesq) {
		this.pressaoesq = pressaoesq;
	}
	
	@Column(name="VOLUME_PULM_ESQ")
	public float getVolesq() {
		return volesq;
	}
	public void setVolesq(float volesq) {
		this.volesq = volesq;
	}
	
	@Column(name="VIA_ANTROGRADA_ESQ")
	public boolean isViaantrogradaesq() {
		return viaantrogradaesq;
	}
	public void setViaantrogradaesq(boolean viaantrogradaesq) {
		this.viaantrogradaesq = viaantrogradaesq;
	}
	
	@Column(name="VIA_RETROGRADA_ESQ")
	public boolean isViaretrogradaesq() {
		return viaretrogradaesq;
	}
	public void setViaretrogradaesq(boolean viaretrogradaesq) {
		this.viaretrogradaesq = viaretrogradaesq;
	}
	
	@Column(name="MORF_PULM_DIR")
	public int getMorfpulmdir() {
		return morfpulmdir;
	}
	public void setMorfpulmdir(int morfpulmdir) {
		this.morfpulmdir = morfpulmdir;
	}
	
	@Column(name="NOTAS_PULM_DIR")
	public String getNotaspulmdir() {
		return notaspulmdir;
	}
	public void setNotaspulmdir(String notaspulmdir) {
		this.notaspulmdir = notaspulmdir;
	}
	
/*	@Column(name="TIPO_PERF_PULM_DIR")
	public int getTipoperfdir() {
		return tipoperfdir;
	}
	public void setTipoperfdir(int tipoperfdir) {
		this.tipoperfdir = tipoperfdir;
	}
	
	@Column(name="PRESSAO_PULM_DIR")
	public int getPressaodir() {
		return pressaodir;
	}
	public void setPressaodir(int pressaodir) {
		this.pressaodir = pressaodir;
	}
	
	@Column(name="VOLUME_PULM_DIR")
	public float getVoldir() {
		return voldir;
	}
	public void setVoldir(float voldir) {
		this.voldir = voldir;
	}
	
	@Column(name="VIA_ANTROGRADA_DIR")
	public boolean isViaantrogradadir() {
		return viaantrogradadir;
	}
	public void setViaantrogradadir(boolean viaantrogradadir) {
		this.viaantrogradadir = viaantrogradadir;
	}
	
	@Column(name="VIA_RETROGRADA_DIR")
	public boolean isViaretrogradadir() {
		return viaretrogradadir;
	}
	public void setViaretrogradadir(boolean viaretrogradadir) {
		this.viaretrogradadir = viaretrogradadir;
	}*/
	
	
	@Column(name="NOTAS_PERF_TRAT")
	public String getNotasperftrat() {
		return notasperftrat;
	}
	public void setNotasperftrat(String notasperftrat) {
		this.notasperftrat = notasperftrat;
	}
	@Column(name="ESTADO_PULM_ESQ")
	public int getEstadopulmaoesq() {
		return estadopulmaoesq;
	}
	public void setEstadopulmaoesq(int estadopulmaoesq) {
		this.estadopulmaoesq = estadopulmaoesq;
	}
	
	@Column(name="ESTADO_PULM_DIR")
	public int getEstadopulmaodir() {
		return estadopulmaodir;
	}
	public void setEstadopulmaodir(int estadopulmaodir) {
		this.estadopulmaodir = estadopulmaodir;
	}
	
	@OneToOne(fetch=FetchType.EAGER)
	@JoinColumn(name="ID_ANALISEDADOR")
	public AnaliseDador getAnaliseDador() {
		return analiseDador;
	}
	public void setAnaliseDador(AnaliseDador analiseDador) {
		this.analiseDador = analiseDador;
	}
	
	@Column(name="COD_PULM_ESQ")
	public String getCodpulmesq() {
		return codpulmesq;
	}
	public void setCodpulmesq(String codpulmesq) {
		this.codpulmesq = codpulmesq;
	}
	
	@Column(name="COD_PULM_DIR")
	public String getCodpulmdir() {
		return codpulmdir;
	}
	public void setCodpulmdir(String codpulmdir) {
		this.codpulmdir = codpulmdir;
	}
	
}
