package pt.iconic.ipst.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import pt.iconic.ipst.modelo.PosOperatorioExplante;

@Repository
@Transactional
public class PosOperatorioExplanteDAO {

	@PersistenceContext
	private EntityManager manager;
	
	
	public void adiciona(PosOperatorioExplante po){
		manager.persist(po);	
	}
	
	public void atualiza(PosOperatorioExplante po){
		manager.merge(po);
	}
	

/*	@SuppressWarnings("unchecked")
	public List<PosOperatorioExplante> ListaPosOperatorioExplante(){
		return manager.createQuery("select p from PosOperatorioExplante p").getResultList();
	}*/
	
/*	public PosOperatorioExplante buscaPorId(Long id){
		return manager.find(PosOperatorioExplante.class, id);
	}
	
	
	public void remove(PosOperatorioExplante po){
		PosOperatorioExplante poARemover = buscaPorId(po.getId_posoperatexplante());
		manager.remove(poARemover);
	}*/
	
	
	@SuppressWarnings("unchecked")
	public PosOperatorioExplante buscaPosOperatorioExplante(Long idanalise){
		
		Query query = manager.createQuery("select p from PosOperatorioExplante p JOIN p.analiseDador a WHERE a.id_AnaliseDador =:idanalise");
		query.setParameter("idanalise", idanalise);
		
		List<PosOperatorioExplante> results = query.getResultList();
		PosOperatorioExplante colheita = null;
		if(!results.isEmpty()){
			colheita = (PosOperatorioExplante) results.get(0);
		}
		return colheita;
		
	}
}
