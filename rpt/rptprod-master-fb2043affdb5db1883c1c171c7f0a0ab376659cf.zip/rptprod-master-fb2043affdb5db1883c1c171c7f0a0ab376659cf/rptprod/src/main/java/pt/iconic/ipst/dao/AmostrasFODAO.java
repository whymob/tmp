package pt.iconic.ipst.dao;

import java.math.BigInteger;
import java.util.Iterator;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import pt.iconic.ipst.modelo.AmostrasFO;
import pt.iconic.ipst.modelo.CausaMorte;

@Repository
@Transactional
public class AmostrasFODAO {

	
	@PersistenceContext
	private EntityManager manager;
	
	
	public void adiciona(AmostrasFO amostrasfo){
		manager.persist(amostrasfo);	
	}
	

	public void atualiza(AmostrasFO amostrasfo){
		manager.merge(amostrasfo);
	}
	

	@SuppressWarnings("unchecked")
	public List<AmostrasFO> ListaAmostrasFO(){
		return manager.createQuery("select a from AmostrasFO a ORDER BY a.nomeamostra").getResultList();
	}
	
	public AmostrasFO buscaPorId(Long id){
		return manager.find(AmostrasFO.class, id);
	}
	
	
	public void remove(AmostrasFO amostrasfo){
		AmostrasFO amostrasfoARemover = buscaPorId(amostrasfo.getId_amostrafo());
		manager.remove(amostrasfoARemover);
		
	}
	
	@SuppressWarnings("unchecked")
	public List<AmostrasFO> ListaAmostrasAnalise(Long idanalise){
		
		Query query = manager.createQuery("select DISTINCT a from AmostrasFO a JOIN a.amostrasfo afo JOIN afo.analiseDador an WHERE an.id_AnaliseDador =:idanalise ORDER BY a.nomeamostra");
		query.setParameter("idanalise", idanalise);
		List<AmostrasFO> results = query.getResultList();

		return results;
	}

	public boolean trataadicionar(String desc)
	{
		Query query = manager.createQuery("SELECT e FROM AmostrasFO e WHERE e.nomeamostra =:desc");
		query.setParameter("desc", desc);
		
		if(query.getResultList().isEmpty())
		{
			AmostrasFO amostra = new AmostrasFO();
			amostra.setNomeamostra(desc);
			adiciona(amostra);
			
			return true;
		}
		else
		{
			return false;
		}
	}


/*	public boolean trataalterar(Long id, String desc)
	{
		Query query = manager.createQuery("SELECT e FROM AmostrasFO e WHERE e.nomeamostra =:desc");
		query.setParameter("desc", desc);
		
		if(query.getResultList().isEmpty())
		{
			AmostrasFO amostra = new AmostrasFO();
			amostra.setNomeamostra(desc);;
			amostra.setId_amostrafo(id);;
			atualiza(amostra);
				
			return true;
		}
		else
		{
			return false;
		}
	}*/
	
	public boolean trataalterar(Long id, String desc)
	{
		AmostrasFO amostra = new AmostrasFO();
		amostra.setNomeamostra(desc);;
		amostra.setId_amostrafo(id);;
		atualiza(amostra);
			
		return true;
	}
	
	public boolean remover(Long id) 
	{
		AmostrasFO amostra = new AmostrasFO();
		amostra = buscaPorId(id);

		remove(amostra);
		return true;
	}


	@SuppressWarnings({ "unchecked", "rawtypes" })
	public Double[] buscacreatininaproteinuria(Long id_analise) {
		
		Query query = manager.createNativeQuery("select a.VALORAMOSTRA , a.ID_AMOSTRAFO from AMOSTRASFUNCOESORGAOTAB a "
				+ "where (a.ID_ANALISEDADOR = :id_analise and a.ID_TIPOAMOSTRA = (select MAX(t.ID_TIPOAMOSTRA) from AMOSTRASFUNCOESORGAOTAB t where t.ID_ANALISEDADOR= :id_analise)) "
				+ "and  (a.ID_AMOSTRAFO=41 OR a.ID_AMOSTRAFO = 12) order by a.ID_AMOSTRAFO asc");
		query.setParameter("id_analise", id_analise);
		List<Object> out = query.getResultList();
		 
		Double[] valores = {(double) 0,(double) 0};
		
		for (Iterator i = out.iterator(); i.hasNext();) {  
		    Object[] values = (Object[]) i.next();  
		    if(((BigInteger) values[1]).longValue() == 12L){
		    	//creatinina
		    	valores[0] =  (Double) values[0];
		    }
		    else if(((BigInteger) values[1]).longValue() ==  41L){
		    	//proteinuria
		    	valores[1] =  (Double) values[0];		
		    }
		}
		return valores;
	}
	
}
