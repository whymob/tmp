package pt.iconic.ipst.modelo;

import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name = "ESTADODADOR")
public class EstadoDador {

	private int Id_EstadoDador;
	private String Estado;
	private List<Dador> Dadores;
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="ID_ESTADODADOR")
	public int getId_EstadoDador() {
		return Id_EstadoDador;
	}
	public void setId_EstadoDador(int id_EstadoDador) {
		Id_EstadoDador = id_EstadoDador;
	}
	
	@Column(name="ESTADO")
	public String getEstado() {
		return Estado;
	}
	public void setEstado(String estado) {
		Estado = estado;
	}
	
	@OneToMany(fetch = FetchType.LAZY, mappedBy = "estadoDador")
	public List<Dador> getDadores() {
		return Dadores;
	}
	public void setDadores(List<Dador> dadores) {
		Dadores = dadores;
	}
	
	
	
}
