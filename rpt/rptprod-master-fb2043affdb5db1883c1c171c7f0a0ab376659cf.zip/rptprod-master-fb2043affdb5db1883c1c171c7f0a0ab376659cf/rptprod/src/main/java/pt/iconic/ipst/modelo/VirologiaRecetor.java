package pt.iconic.ipst.modelo;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name="VIROLOGIARECETOR")
public class VirologiaRecetor {

	private Long id_virologia;
	private AnaliseRecetor analiserecetor;
	private boolean prepostransfusao;
	private int cstradio;
	private float cstvalor;
	private String cstobs;
	private TipoVirologia tipoVirologia;
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="ID_VIROLOGIA")
	public Long getId_virologia() {
		return id_virologia;
	}
	public void setId_virologia(Long id_virologia) {
		this.id_virologia = id_virologia;
	}
	
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="ID_ANALISERECETOR")
	public AnaliseRecetor getAnaliserecetor() {
		return analiserecetor;
	}
	public void setAnaliserecetor(AnaliseRecetor analiserecetor) {
		this.analiserecetor = analiserecetor;
	}
	
	@Column(name="PREPOSTRANSFUSAO")
	public boolean isPrepostransfusao() {
		return prepostransfusao;
	}
	public void setPrepostransfusao(boolean prepostransfusao) {
		this.prepostransfusao = prepostransfusao;
	}
	
    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "ID_TIPOVIROLOGIA")
	public TipoVirologia getTipoVirologia() {
		return tipoVirologia;
	}
	public void setTipoVirologia(TipoVirologia tipoVirologia) {
		this.tipoVirologia = tipoVirologia;
	}
	
	@Column(name="CSTRADIO")
	public int getCstradio() {
		return cstradio;
	}
	public void setCstradio(int cstradio) {
		this.cstradio = cstradio;
	}
	
	@Column(name="CSTVALOR")
	public float getCstvalor() {
		return cstvalor;
	}
	public void setCstvalor(float cstvalor) {
		this.cstvalor = cstvalor;
	}
	
	@Column(name="CSTOBS")
	public String getCstobs() {
		return cstobs;
	}
	public void setCstobs(String cstobs) {
		this.cstobs = cstobs;
	}
	
}
