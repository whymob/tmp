package pt.iconic.ipst.modelo;

import java.util.Calendar;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
import javax.persistence.PrePersist;
import javax.persistence.Table;

@Entity
@Table(name = "BDAVALIACAOINICIAL")
public class BDAvaliacaoInicial {

	
	private Long Id_BDAvaliacaoInicial;
	//private BaseDador BaseDador;
	private AnaliseDador analiseDador;
	private GlasgowComma glasgowComma;
	private CausaMorte causaMorte;
	private MecanismoMorte mecanismoMorte;
	private int STATUSRENNDA;
	private Calendar DataConsultaRENNDA;
	private String caminho;
	private String nomedoc;
	private String observacoes;
	private boolean statusharmonio;
	private int estado;
	private Calendar datagravacao;
//	private DocumentoAvalInicial DocumentoRennda;
	
	
	@PrePersist
	void preInsercao() {
		BDAvaliacaoInicial.this.setSTATUSRENNDA(0);
	}
	
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="ID_BDAVALIACAOINICIAL")
	public Long getId_BDAvaliacaoInicial() {
		return Id_BDAvaliacaoInicial;
	}
	public void setId_BDAvaliacaoInicial(Long id_BDAvaliacaoInicial) {
		Id_BDAvaliacaoInicial = id_BDAvaliacaoInicial;
	}
	
	@OneToOne
	@JoinColumn(name="ID_ANALISEDADOR")
	public AnaliseDador getAnaliseDador() {
		return analiseDador;
	}
	public void setAnaliseDador(AnaliseDador analiseDador) {
		this.analiseDador = analiseDador;
	}
/*	@OneToOne
	@JoinColumn(name="ID_BASEDADOR")
	public BaseDador getBaseDador() {
		return BaseDador;
	}
	public void setBaseDador(BaseDador baseDador) {
		BaseDador = baseDador;
	}*/
	
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "ID_GLASGOWCOMMA")
	public GlasgowComma getGlasgowComma() {
		return glasgowComma;
	}
	public void setGlasgowComma(GlasgowComma glasgowComma) {
		this.glasgowComma = glasgowComma;
	}
	
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "ID_CAUSAMORTE")
	public CausaMorte getCausaMorte() {
		return causaMorte;
	}
	public void setCausaMorte(CausaMorte causaMorte) {
		this.causaMorte = causaMorte;
	}
	
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "ID_MECANISMOMORTE")
	public MecanismoMorte getMecanismoMorte() {
		return mecanismoMorte;
	}
	public void setMecanismoMorte(MecanismoMorte mecanismoMorte) {
		this.mecanismoMorte = mecanismoMorte;
	}
	
	@Column(name="STATUSRENNDA")
	public int getSTATUSRENNDA() {
		return STATUSRENNDA;
	}
	public void setSTATUSRENNDA(int sTATUSRENNDA) {
		STATUSRENNDA = sTATUSRENNDA;
	}
	@Column(name="DATACONSULTARENNDA")
	public Calendar getDataConsultaRENNDA() {
		return DataConsultaRENNDA;
	}
	public void setDataConsultaRENNDA(Calendar dataConsultaRENNDA) {
		DataConsultaRENNDA = dataConsultaRENNDA;
	}

	@Column(name="CAMINHODOC")
	public String getCaminho() {
		return caminho;
	}


	public void setCaminho(String caminho) {
		this.caminho = caminho;
	}

	@Column(name="NOMEDOC")
	public String getNomedoc() {
		return nomedoc;
	}

	public void setNomedoc(String nomedoc) {
		this.nomedoc = nomedoc;
	}
	

	@Column(name="OBSERVACOES")
	public String getObservacoes() {
		return observacoes;
	}

	public void setObservacoes(String observacoes) {
		this.observacoes = observacoes;
	}

	@Column(name="STATUSHARMONIO")
	public boolean isStatusharmonio() {
		return statusharmonio;
	}

	public void setStatusharmonio(boolean statusharmonio) {
		this.statusharmonio = statusharmonio;
	}

	@Column(name="ESTADO")
	public int getEstado() {
		return estado;
	}

	public void setEstado(int estado) {
		this.estado = estado;
	}

	@Column(name="DATAGRAVACAO")
	public Calendar getDatagravacao() {
		return datagravacao;
	}


	public void setDatagravacao(Calendar datagravacao) {
		this.datagravacao = datagravacao;
	}

/*	@OneToOne(fetch = FetchType.LAZY, mappedBy = "bdAvaliacaoInicial")
	public DocumentoAvalInicial getDocumentoRennda() {
		return DocumentoRennda;
	}
	public void setDocumentoRennda(DocumentoAvalInicial documentoRennda) {
		DocumentoRennda = documentoRennda;
	}
	*/


	
	
	
	
}
