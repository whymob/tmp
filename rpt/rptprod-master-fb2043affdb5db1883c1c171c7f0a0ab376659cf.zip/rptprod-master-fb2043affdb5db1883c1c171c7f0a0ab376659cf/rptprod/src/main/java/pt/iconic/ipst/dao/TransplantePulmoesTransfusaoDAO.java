package pt.iconic.ipst.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import pt.iconic.ipst.modelo.TransplantePulmoesTransfusao;

@Repository
@Transactional
public class TransplantePulmoesTransfusaoDAO {

	@PersistenceContext
	private EntityManager manager;
	
	
	public void adiciona(TransplantePulmoesTransfusao transplante){
		manager.persist(transplante);	
	}
	

	public void atualiza(TransplantePulmoesTransfusao transplante){
		manager.merge(transplante);
	}
	

/*	@SuppressWarnings("unchecked")
	public List<TransplantePulmoesTransfusao> ListaTransplantePulmoesTransfusao(){
		return manager.createQuery("select a from TransplantePulmoesTransfusao a").getResultList();
	}*/
	
	public TransplantePulmoesTransfusao buscaPorId(Long id){
		return manager.find(TransplantePulmoesTransfusao.class, id);
	}
	
	
	public void remove(TransplantePulmoesTransfusao transplante){
		TransplantePulmoesTransfusao transplanteARemover = buscaPorId(transplante.getIdpulmoestransf());
		manager.remove(transplanteARemover);
		
	}
	
	@SuppressWarnings("unchecked")
	public List<TransplantePulmoesTransfusao> ListaTransplantePulmoesTransfusaoassig(Long idassigorg){
		
		Query query = manager.createQuery("select p from TransplantePulmoesTransfusao p JOIN p.assigorgao a WHERE a.id_assignacao =:idassigorg");
		query.setParameter("idassigorg", idassigorg);
		
		List<TransplantePulmoesTransfusao> results = query.getResultList();

		return results;
		
	}
}
