package pt.iconic.ipst.modelo;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name = "PREOP_TERAPEUTICA")
public class PreopTerapeuticas {

	private Long id_preopterap;
	private int tipo;
	private int terapeutica;
	private String observacoes;
	private AssignacaoOrgaos assigorgao;
	
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="ID_PREOP_TERAPEUTICA")
	public Long getId_preopterap() {
		return id_preopterap;
	}
	public void setId_preopterap(Long id_preopterap) {
		this.id_preopterap = id_preopterap;
	}
	
	@Column(name="TIPO")
	public int getTipo() {
		return tipo;
	}
	public void setTipo(int tipo) {
		this.tipo = tipo;
	}
	
	@Column(name="TERAPEUTICA")
	public int getTerapeutica() {
		return terapeutica;
	}
	public void setTerapeutica(int terapeutica) {
		this.terapeutica = terapeutica;
	}
	
	@Column(name="OBSERVACOES")
	public String getObservacoes() {
		return observacoes;
	}
	public void setObservacoes(String observacoes) {
		this.observacoes = observacoes;
	}
	
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "ID_ASSIGNACAO_ORGAOS")
	public AssignacaoOrgaos getAssigorgao() {
		return assigorgao;
	}
	public void setAssigorgao(AssignacaoOrgaos assigorgao) {
		this.assigorgao = assigorgao;
	}
}
