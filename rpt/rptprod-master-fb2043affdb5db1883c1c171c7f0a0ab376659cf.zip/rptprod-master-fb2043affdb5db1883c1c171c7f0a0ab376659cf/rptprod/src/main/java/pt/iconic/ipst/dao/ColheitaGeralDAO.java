package pt.iconic.ipst.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import pt.iconic.ipst.modelo.ColheitaGeral;


@Repository
@Transactional
public class ColheitaGeralDAO {

	@PersistenceContext
	private EntityManager manager;
	
	
	public void adiciona(ColheitaGeral colheita){
		manager.persist(colheita);	
	}
	

	public void atualiza(ColheitaGeral colheita){
		manager.merge(colheita);
	}
	

/*	@SuppressWarnings("unchecked")
	public List<ColheitaGeral> ListaColheitaGeral(){
		return manager.createQuery("select a from ColheitaGeral a").getResultList();
	}
	
	public ColheitaGeral buscaPorId(Long id){
		return manager.find(ColheitaGeral.class, id);
	}
	
	
	public void remove(ColheitaGeral colheita){
		ColheitaGeral colheitaARemover = buscaPorId(colheita.getIdcolheitageral());
		manager.remove(colheitaARemover);
		
	}*/
	
	@SuppressWarnings("unchecked")
	public ColheitaGeral buscacolheitageralanalise(Long idanalise){
		
		Query query = manager.createQuery("select b from ColheitaGeral b JOIN b.analiseDador a WHERE a.id_AnaliseDador =:idanalise");
		query.setParameter("idanalise", idanalise);
		
		List<ColheitaGeral> results = query.getResultList();
		ColheitaGeral colheita = null;
		if(!results.isEmpty()){
			colheita = (ColheitaGeral) results.get(0);
		}
		return colheita;
		
	}
	
	
	public int contaCodOrgao(Long idanalise)
	{	
		Query query = manager.createNativeQuery("select "
		+ "(select count(COLHEITA_CORACAO.COD_CORACAO) from COLHEITA_CORACAO where (len(COLHEITA_CORACAO.COD_CORACAO) > 0) and COLHEITA_CORACAO.ID_ANALISEDADOR =:idanalise) + "
		+ "(select COUNT(COLHEITA_FIGADO.COD_FIGADO) from COLHEITA_FIGADO where (len(COLHEITA_FIGADO.COD_FIGADO) > 0) and COLHEITA_FIGADO.ID_ANALISEDADOR =:idanalise) + "
		+ "(select COUNT(COLHEITA_VASOS.COD_VASOS) from COLHEITA_VASOS where (len(COLHEITA_VASOS.COD_VASOS) > 0) and COLHEITA_VASOS.ID_ANALISEDADOR =:idanalise) + "
		+ "(select COUNT(COLHEITA_CORNEAS.COD_CORNEAS) from COLHEITA_CORNEAS where (len(COLHEITA_CORNEAS.COD_CORNEAS) > 0) and COLHEITA_CORNEAS.ID_ANALISEDADOR =:idanalise) + "
		+ "(select COUNT(COLHEITA_PELE.COD_PELE) from COLHEITA_PELE where (len(COLHEITA_PELE.COD_PELE) > 0) and COLHEITA_PELE.ID_ANALISEDADOR =:idanalise) + "
		+ "(select COUNT(COLHEITA_PANCREAS.COD_PANCREAS) from COLHEITA_PANCREAS where (len(COLHEITA_PANCREAS.COD_PANCREAS) > 0) and COLHEITA_PANCREAS.ID_ANALISEDADOR =:idanalise) + "
		+ "(select COUNT(COLHEITA_TC.COD_TC) from COLHEITA_TC where (len(COLHEITA_TC.COD_TC) > 0) and COLHEITA_TC.ID_ANALISEDADOR =:idanalise) + "
		+ "(select COUNT(COLHEITA_TME.COD_TME) from COLHEITA_TME where (len(COLHEITA_TME.COD_TME) > 0) and COLHEITA_TME.ID_ANALISEDADOR =:idanalise) + "
		+ "(select COUNT(COLHEITA_PULMOES.COD_PULM_DIR) from COLHEITA_PULMOES where (len(COLHEITA_PULMOES.COD_PULM_DIR) > 0) and COLHEITA_PULMOES.ID_ANALISEDADOR =:idanalise) + "
		+ "(select COUNT(COLHEITA_PULMOES.COD_PULM_ESQ) from COLHEITA_PULMOES where (len(COLHEITA_PULMOES.COD_PULM_ESQ) > 0) and COLHEITA_PULMOES.ID_ANALISEDADOR =:idanalise) + "
		+ "(select COUNT(COLHEITA_RINS.COD_RIM_DIR) from COLHEITA_RINS where (len(COLHEITA_RINS.COD_RIM_DIR) > 0) and COLHEITA_RINS.ID_ANALISEDADOR =:idanalise) + "
		+ "(select COUNT(COLHEITA_RINS.COD_RIM_ESQ) from COLHEITA_RINS where (len(COLHEITA_RINS.COD_RIM_ESQ) > 0) and COLHEITA_RINS.ID_ANALISEDADOR =:idanalise) as total");
		query.setParameter("idanalise", idanalise);
		
		int out = (int) query.getSingleResult();

		return out;
	}
	
	public int contaCodOrgaoCoracao(Long idanalise)
	{	
		Query query = manager.createNativeQuery("select COUNT(COLHEITA_CORACAO.ID_COLHEITA_CORACAO) from COLHEITA_CORACAO where COLHEITA_CORACAO.ESTADO_CORACAO = 1 and (len(COLHEITA_CORACAO.COD_CORACAO) > 0) and COLHEITA_CORACAO.ID_ANALISEDADOR =:idanalise");
		query.setParameter("idanalise", idanalise);
		
		int out = (int) query.getSingleResult();

		return out;
	}
	
	public int contaCodOrgaoFigado(Long idanalise)
	{	
		Query query = manager.createNativeQuery("select COUNT(COLHEITA_FIGADO.ID_COLHEITA_FIGADO) from COLHEITA_FIGADO where ((COLHEITA_FIGADO.ESTADO_FIGADO = 1) OR (COLHEITA_FIGADO.ESTADO_FIGADO = 2)) and (len(COLHEITA_FIGADO.COD_FIGADO) > 0) and COLHEITA_FIGADO.ID_ANALISEDADOR =:idanalise");
		query.setParameter("idanalise", idanalise);
		
		int out = (int) query.getSingleResult();

		return out;
	}
	
	public int contaCodOrgaoCorneaDir(Long idanalise)
	{	
		Query query = manager.createNativeQuery("select COUNT(COLHEITA_CORNEAS.ID_COLHEITA_CORNEAS) from COLHEITA_CORNEAS where (len(COLHEITA_CORNEAS.CORNEA_DIR_CODIGO) > 0) and COLHEITA_CORNEAS.CORNEA_DIR_RETIRADA = 1 and COLHEITA_CORNEAS.ID_ANALISEDADOR =:idanalise");
		query.setParameter("idanalise", idanalise);
		
		int out = (int) query.getSingleResult();

		return out;
	}
	
	public int contaCodOrgaoCorneaEsq(Long idanalise)
	{	
		Query query = manager.createNativeQuery("select COUNT(COLHEITA_CORNEAS.ID_COLHEITA_CORNEAS) from COLHEITA_CORNEAS where (len(COLHEITA_CORNEAS.CORNEA_ESQ_CODIGO) > 0) and COLHEITA_CORNEAS.CORNEA_ESQ_RETIRADA = 1 and COLHEITA_CORNEAS.ID_ANALISEDADOR =:idanalise");
		query.setParameter("idanalise", idanalise);
		
		int out = (int) query.getSingleResult();

		return out;
	}
	
	public int contaCodOrgaoPancreas(Long idanalise)
	{	
		Query query = manager.createNativeQuery("select COUNT(COLHEITA_PANCREAS.ID_COLHEITA_PANCREAS) from COLHEITA_PANCREAS where ((COLHEITA_PANCREAS.ESTADO_PANCREAS = 1) OR (COLHEITA_PANCREAS.ESTADO_PANCREAS = 1)) and (len(COLHEITA_PANCREAS.COD_PANCREAS) > 0) and COLHEITA_PANCREAS.ID_ANALISEDADOR =:idanalise");
		query.setParameter("idanalise", idanalise);
		
		int out = (int) query.getSingleResult();

		return out;
	}
	
	public int contaCodOrgaoPele(Long idanalise)
	{	
		Query query = manager.createNativeQuery("select COUNT(COLHEITA_PELE.ID_COLHEITA_PELE) from COLHEITA_PELE where (len(COLHEITA_PELE.COD_PELE) > 0) and COLHEITA_PELE.ID_ANALISEDADOR =:idanalise");
		query.setParameter("idanalise", idanalise);
		
		int out = (int) query.getSingleResult();

		return out;
	}
	
	public int contaCodOrgaoPulmaoDir(Long idanalise)
	{	
		Query query = manager.createNativeQuery("select COUNT(COLHEITA_PULMOES.ID_COLHEITA_PULMOES) from COLHEITA_PULMOES where ((COLHEITA_PULMOES.ESTADO_PULM_DIR = 1) OR (COLHEITA_PULMOES.ESTADO_PULM_DIR = 2)) and (len(COLHEITA_PULMOES.COD_PULM_DIR) > 0) and COLHEITA_PULMOES.ID_ANALISEDADOR =:idanalise");
		query.setParameter("idanalise", idanalise);
		
		int out = (int) query.getSingleResult();

		return out;
	}
	
	public int contaCodOrgaoPulmaoEsq(Long idanalise)
	{	
		Query query = manager.createNativeQuery("select COUNT(COLHEITA_PULMOES.ID_COLHEITA_PULMOES) from COLHEITA_PULMOES where ((COLHEITA_PULMOES.ESTADO_PULM_ESQ = 1) OR (COLHEITA_PULMOES.ESTADO_PULM_ESQ = 2)) and (len(COLHEITA_PULMOES.COD_PULM_ESQ) > 0) and COLHEITA_PULMOES.ID_ANALISEDADOR =:idanalise");
		query.setParameter("idanalise", idanalise);
		
		int out = (int) query.getSingleResult();

		return out;
	}
	
	public int contaCodOrgaoRimDir(Long idanalise)
	{	
		Query query = manager.createNativeQuery("select COUNT(COLHEITA_RINS.ID_COLHEITA_RINS) from COLHEITA_RINS where ((COLHEITA_RINS.ESTADO_RIM_DIR = 1) OR (COLHEITA_RINS.ESTADO_RIM_DIR = 2)) and (len(COLHEITA_RINS.COD_RIM_DIR) > 0) and COLHEITA_RINS.ID_ANALISEDADOR =:idanalise");
		query.setParameter("idanalise", idanalise);
		
		int out = (int) query.getSingleResult();

		return out;
	}
	
	public int contaCodOrgaoRimEsq(Long idanalise)
	{	
		Query query = manager.createNativeQuery("select COUNT(COLHEITA_RINS.ID_COLHEITA_RINS) from COLHEITA_RINS where ((COLHEITA_RINS.ESTADO_RIM_ESQ = 1) OR (COLHEITA_RINS.ESTADO_RIM_ESQ = 2)) and (len(COLHEITA_RINS.COD_RIM_ESQ) > 0) and COLHEITA_RINS.ID_ANALISEDADOR =:idanalise");
		query.setParameter("idanalise", idanalise);
		
		int out = (int) query.getSingleResult();

		return out;
	}
	
	public int contaCodOrgaoTC(Long idanalise)
	{	
		Query query = manager.createNativeQuery("select COUNT(COLHEITA_TC.ID_COLHEITA_TC) from COLHEITA_TC where (len(COLHEITA_TC.COD_TC) > 0) and COLHEITA_TC.ID_ANALISEDADOR =:idanalise");
		query.setParameter("idanalise", idanalise);
		
		int out = (int) query.getSingleResult();

		return out;
	}
	
	public int contaCodOrgaoTME(Long idanalise)
	{	
		Query query = manager.createNativeQuery("select COUNT(COLHEITA_TME.ID_COLHEITA_TME) from COLHEITA_TME where (len(COLHEITA_TME.COD_TME) > 0) and COLHEITA_TME.ID_ANALISEDADOR =:idanalise");
		query.setParameter("idanalise", idanalise);
		
		int out = (int) query.getSingleResult();

		return out;
	}
	
	public int contaCodOrgaoVasos(Long idanalise)
	{	
		Query query = manager.createNativeQuery("select COUNT(COLHEITA_VASOS.ID_COLHEITA_VASOS) from COLHEITA_VASOS where (len(COLHEITA_VASOS.COD_VASOS) > 0) and COLHEITA_VASOS.ID_ANALISEDADOR =:idanalise");
		query.setParameter("idanalise", idanalise);
		
		int out = (int) query.getSingleResult();

		return out;
	}


	public int contaCodOrgaoSolidos(Long idanalise) {

		Query query = manager.createNativeQuery("select "
		+ "(select count(COLHEITA_CORACAO.COD_CORACAO) from COLHEITA_CORACAO where (len(COLHEITA_CORACAO.COD_CORACAO) > 0) and COLHEITA_CORACAO.ID_ANALISEDADOR =:idanalise) + "
		+ "(select COUNT(COLHEITA_FIGADO.COD_FIGADO) from COLHEITA_FIGADO where (len(COLHEITA_FIGADO.COD_FIGADO) > 0) and COLHEITA_FIGADO.ID_ANALISEDADOR =:idanalise) + "
		+ "(select COUNT(COLHEITA_PANCREAS.COD_PANCREAS) from COLHEITA_PANCREAS where (len(COLHEITA_PANCREAS.COD_PANCREAS) > 0) and COLHEITA_PANCREAS.ID_ANALISEDADOR =:idanalise) + "
		+ "(select case when ((select COUNT(COLHEITA_PULMOES.COD_PULM_DIR) from COLHEITA_PULMOES where (len(COLHEITA_PULMOES.COD_PULM_DIR) > 0) and COLHEITA_PULMOES.ID_ANALISEDADOR =:idanalise)>0) "
		+ "or "
		+ "((select COUNT(COLHEITA_PULMOES.COD_PULM_ESQ) from COLHEITA_PULMOES where (len(COLHEITA_PULMOES.COD_PULM_ESQ) > 0) and COLHEITA_PULMOES.ID_ANALISEDADOR =:idanalise)>0) "
		+ "then 1 else 0 end) + "
		+ "(select case when ((select COUNT(COLHEITA_RINS.COD_RIM_DIR) from COLHEITA_RINS where (len(COLHEITA_RINS.COD_RIM_DIR) > 0) and COLHEITA_RINS.ID_ANALISEDADOR =:idanalise)>0) "
		+ "or "
		+ "((select COUNT(COLHEITA_RINS.COD_RIM_ESQ) from COLHEITA_RINS where (len(COLHEITA_RINS.COD_RIM_ESQ) > 0) and COLHEITA_RINS.ID_ANALISEDADOR =:idanalise)>0) "
		+ "then 1 else 0 end) ");
		query.setParameter("idanalise", idanalise);
	
		int out = (int) query.getSingleResult();
				
		return out;
	}
}
