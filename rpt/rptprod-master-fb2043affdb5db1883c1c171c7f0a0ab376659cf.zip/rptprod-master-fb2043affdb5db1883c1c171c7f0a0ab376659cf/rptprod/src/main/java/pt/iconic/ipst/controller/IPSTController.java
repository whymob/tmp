package pt.iconic.ipst.controller;




import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import pt.iconic.ipst.dao.UtilizadorDAO;
import pt.iconic.ipst.modelo.Utilizador;


@Controller
public class IPSTController {

	private UtilizadorDAO daouser;
	
	@Autowired
	public IPSTController(UtilizadorDAO daouser) 
	{
		this.daouser = daouser;
	}
	
	
	
	@RequestMapping(value = "/", method = RequestMethod.GET)
	public String index() {
//	System.out.println("Efectuar verifica��o de login Master");
	verificausermaster();
	return "login";
	}
	
	private void verificausermaster() {
		Utilizador user = new Utilizador();
		user.setLogin("Master");
		user.setSenha("12345");
		user.setEmail("master@ipst.pt");
		user.setUtilizador("Master");
		if(!daouser.existeUtilizadorLogin(user.getLogin())){
			daouser.iniciamaster(user);
		}
		
	}

	@RequestMapping("login")
	public String login(Model model) {
	//System.out.println("Enviar para login");
	//verificar se existe utilizador master, se n�o existir criar com acesso a todos os hospitais, tem que existir j� as tabelas mestre na BD
	//	SMSController sms = new SMSController();
	//	sms.sms("963451065", "123456", 1);
	return "login";
	}
	
	@RequestMapping("errorpage")
	public String paginaerro() {
	return "errorpage";
	}
	
}
