package pt.iconic.ipst.controller;


import java.util.List;

import org.json.simple.JSONObject;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Controller;
import org.springframework.web.client.RestTemplate;

@Controller
public class NotificationsController {

	//@RequestMapping(value="notificacao", headers="RPTKey=2B306C9D4F692771DA39B5D04A3475078559D8DD, Content-Type = application/json")
	@SuppressWarnings("unchecked")
	public void envianotificacao(List<Long> users, int tipo, List<String> perfis, String orgao, String msg, String codprocesso, int refresca){
	

		String type = "";
		
        switch (tipo) {
            case 1:  type = "DonorReferenced";
                     break;
            case 2:  type = "DonorApproved";
                     break;
            case 3:  type = "DonorDisapproved";
                     break;
            case 4:  type = "InitialEvaluation";
                     break;
            case 5:  type = "HarvestStarted";
                     break;
            case 6:  type = "HarvestFinished";
                     break;
            case 7:  type = "NewCandidateAnalyzed";
                     break;
            case 8:  type = "CandidateAnalysisAvailable";
                     break;
            case 9:  type = "CandidateSelected";
                     break;
            case 10: type = "OrganRefused";
                     break;
            case 11: type = "CandidateSelectedAnotherHospital";
                     break;
            case 12: type = "HarvestTeamAssigned";
                     break;
            case 13: type = "HarvestLocalSaved";
            		break;
            case 14: type = "HarvestDateTimeSaved";
            		break;
            case 15: type = "TransplantTeamAssigned";
            		break;
            case 16: type = "TransplantLocalSaved";
            		break;
            case 17: type = "TransplantDateTImeSaved";
            		break;
            case 18: type = "OrganHarvestValid";
            		break;
            case 19: type = "OrganHarvestInvalid";
    				break;
            default: type = "DonorReferenced";
                     break;
        }
		
		
		

		
		String refresh = "None";
		if(refresca == 2){
			refresh = "Processes";
		}
		if(refresca == 3){
			refresh = "Process";
		}
 
		
		final String url = "http://rpt-mobile-dev.azurewebsites.net/api/Notification";
		
		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_JSON);
		headers.set("RPTKey", "2B306C9D4F692771DA39B5D04A3475078559D8EE");
		
		
		JSONObject body = new JSONObject();
		
		body.put("UserIds", users);
		
		body.put("Type", type);
		

		body.put("Profiles", perfis);
		
		body.put("Organ", orgao);
		
		body.put("Message", msg);
		
		body.put("ProcessId", codprocesso);
		
		body.put("Refresh", refresh);
		
//		 RestTemplate restTemplate = new RestTemplate();
		
//		 HttpEntity<JSONObject> request = new HttpEntity<JSONObject>(body, headers);

//System.out.println("JSON: "+request);
	//	 restTemplate.postForLocation(url, request);   
		 
	
	}
}
